#!/usr/bin/env python3
import os, re, json, shutil, zipfile, datetime, subprocess
from pathlib import Path

def main():
    assets_ext = Path("app/src/main/assets/pocketleads")
    assets_core = Path("app/src/main/assets/android_core")
    if not assets_ext.exists():
        return

    if assets_core.exists():
        for f in assets_core.iterdir():
            if f.is_file():
                shutil.copyfile(f, assets_ext / f.name)

    acc_p = assets_ext / "libs" / "account.js"
    if acc_p.exists():
        atxt = acc_p.read_text(encoding="utf-8", errors="ignore")
        atxt = atxt.replace(
            "const worker = typeof document === 'undefined';",
            "const worker = typeof document === 'undefined' || !!(g && (g.__plInProcessAndroid || g.AndroidChromeBridge || (g.location && g.location.hostname === 'pocketleads.local')));",
            1
        )
        acc_p.write_text(atxt, encoding="utf-8")

    rj_p = assets_ext / "libs" / "request-journal.js"
    if rj_p.exists():
        rtxt = rj_p.read_text(encoding="utf-8", errors="ignore")
        old_s = "return {get:k=>transact('readonly',s=>s.get(k)),put:v=>transact('readwrite',s=>s.put(v))};"
        new_s = "const mem=new Map();return {get:k=>transact('readonly',s=>s.get(k)).catch(()=>mem.get(k)),put:v=>transact('readwrite',s=>s.put(v)).catch(()=>{if(v&&v.slot)mem.set(v.slot,v);})};"
        if old_s in rtxt:
            rtxt = rtxt.replace(old_s, new_s, 1)
            rj_p.write_text(rtxt, encoding="utf-8")

    for ctrl_rel in ["controllers/TaskManagerContainer.js", "controllers/background.js"]:
        cp = assets_ext / ctrl_rel
        if cp.exists():
            ctxt = cp.read_text(encoding="utf-8", errors="ignore")
            if "__plInProcessAndroid" not in ctxt:
                ctxt = "if (!(typeof document !== 'undefined' && typeof location !== 'undefined' && location.protocol === 'chrome-extension:' && !window.__plInProcessAndroid)) {
" + ctxt + "
}
"
                cp.write_text(ctxt, encoding="utf-8")

    inproc_tags = """    <script defer src="/libs/result-query.js"></script>
    <script defer src="/libs/request-journal.js"></script>
    <script defer src="/libs/ghost-parser.js"></script>
    <script defer src="/libs/profile-tab.js"></script>
    <script defer src="/libs/TaskManager.js"></script>
    <script defer src="/controllers/TaskManagerContainer.js"></script>
    <script defer src="/controllers/background.js"></script>
    <script data-load-minify defer type="text/javascript" src="/controllers/index.js"></script>"""

    for html_file in assets_ext.rglob("*.html"):
        rel_str = str(html_file.relative_to(assets_ext)).replace("\", "/")
        htxt = html_file.read_text(encoding="utf-8", errors="ignore")
        htxt = htxt.replace("/libs/FoxCommon.js", "/libs/foxCommon.js")
        if "<head>" in htxt:
            if "chrome-ota-patch.js" not in htxt:
                inj = "<head>
<!-- chrome-android-polyfill.js -->"
                if 'name="viewport"' not in htxt:
                    inj += '
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">'
                inj += '
<script src="/chrome-ota-patch.js"></script>'
                htxt = htxt.replace("<head>", inj, 1)
            elif "chrome-android-polyfill.js" not in htxt:
                htxt = htxt.replace("<head>", "<head>
<!-- chrome-android-polyfill.js -->", 1)
            if rel_str == "views/index.html" and "/controllers/TaskManagerContainer.js" not in htxt:
                htxt = htxt.replace(
                    '    <script data-load-minify defer type="text/javascript" src="/controllers/index.js"></script>',
                    inproc_tags,
                    1
                )
        else:
            # Strip any <meta viewport> and <script chrome-android-polyfill.js> that an old workflow prepended to partials!
            htxt = re.sub(r'(?is)<meta[^>]*viewport[^>]*>\s*', '', htxt)
            htxt = re.sub(r'(?is)<script[^>]*chrome-(?:android-polyfill|ota-patch)\.js[^>]*>\s*</script>\s*', '', htxt)
            if "chrome-android-polyfill.js" not in htxt:
                htxt = "<!-- chrome-android-polyfill.js -->
" + htxt
        html_file.write_text(htxt, encoding="utf-8")

    zip_path = Path("PocketLeads-latest.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(assets_ext):
            for f in files:
                full_p = Path(root) / f
                rel_p = full_p.relative_to(assets_ext)
                zf.write(full_p, arcname=str(rel_p))

    manifest_data = json.loads((assets_ext / "manifest.json").read_text(encoding="utf-8"))
    ver = manifest_data.get("version", "10.19.3")
    ts = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S")
    bid = f"{ver}-{ts}-v6"
    ota_meta = {
        "version": ver,
        "buildId": bid,
        "zipFile": f"PocketLeads-latest.zip?v={bid}",
        "updatedAt": datetime.datetime.utcnow().isoformat() + "Z"
    }
    Path("ota-version.json").write_text(json.dumps(ota_meta, indent=2), encoding="utf-8")

    # Also auto-upgrade .github/workflows/main.yml if it has the old v1 partial bug
    for wf_rel in [".github/workflows/main.yml", ".github/workflows/build-apk.yml"]:
        wf_p = Path(wf_rel)
        if wf_p.exists():
            wtxt = wf_p.read_text(encoding="utf-8", errors="ignore")
            if "else:
                txt = polyfill_tag" in wtxt or "rglob("*.html")" in wtxt:
                wtxt = wtxt.replace(
                    "else:
                txt = polyfill_tag + "\n" + txt",
                    "else:
                txt = "<!-- chrome-android-polyfill.js -->\n" + txt"
                )
                wf_p.write_text(wtxt, encoding="utf-8")

    if os.environ.get("GITHUB_ACTIONS") == "true":
        subprocess.run(["git", "config", "user.name", "PocketLeads Auto-Updater"], check=False)
        subprocess.run(["git", "config", "user.email", "actions@github.com"], check=False)
        subprocess.run(["git", "add", "ota-version.json", "PocketLeads-latest.zip"], check=False)
        for wf_rel in [".github/workflows/main.yml", ".github/workflows/build-apk.yml"]:
            if Path(wf_rel).exists():
                subprocess.run(["git", "add", wf_rel], check=False)
        diff_res = subprocess.run(["git", "diff", "--cached", "--quiet"], check=False)
        if diff_res.returncode != 0:
            subprocess.run(["git", "commit", "-m", "chore(ota): auto-heal v6 OTA package [skip ci]"], check=False)
            subprocess.run(["git", "push"], check=False)

if __name__ == "__main__":
    main()
