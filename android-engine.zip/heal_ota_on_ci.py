#!/usr/bin/env python3
import os, re, json, shutil, zipfile, datetime, subprocess
from pathlib import Path

def main():
    assets_ext = Path("app/src/main/assets/pocketleads")
    assets_core = Path("app/src/main/assets/android_core")
    if not assets_ext.exists():
        return

    if assets_core.exists():
        for f in assets_core.iterdir():
            if f.is_file():
                shutil.copyfile(f, assets_ext / f.name)

    acc_p = assets_ext / "libs" / "account.js"
    if acc_p.exists():
        atxt = acc_p.read_text(encoding="utf-8", errors="ignore")
        atxt = atxt.replace(
            "const worker = typeof document === 'undefined';",
            "const worker = typeof document === 'undefined' || !!(g && (g.__plInProcessAndroid || g.AndroidChromeBridge || (g.location && g.location.hostname === 'pocketleads.local')));",
            1
        )
        acc_p.write_text(atxt, encoding="utf-8")

    rj_p = assets_ext / "libs" / "request-journal.js"
    if rj_p.exists():
        rtxt = rj_p.read_text(encoding="utf-8", errors="ignore")
        old_s = "return {get:k=>transact('readonly',s=>s.get(k)),put:v=>transact('readwrite',s=>s.put(v))};"
        new_s = "const mem=new Map();return {get:k=>transact('readonly',s=>s.get(k)).catch(()=>mem.get(k)),put:v=>transact('readwrite',s=>s.put(v)).catch(()=>{if(v&&v.slot)mem.set(v.slot,v);})};"
        if old_s in rtxt:
            rtxt = rtxt.replace(old_s, new_s, 1)
            rj_p.write_text(rtxt, encoding="utf-8")

    for ctrl_rel in ["controllers/TaskManagerContainer.js", "controllers/background.js"]:
        cp = assets_ext / ctrl_rel
        if cp.exists():
            ctxt = cp.read_text(encoding="utf-8", errors="ignore")
            if "__plInProcessAndroid" not in ctxt:
                ctxt = "if (!(typeof document !== 'undefined' && typeof location !== 'undefined' && /^(chrome|kiwi|edge|brave|opera|moz)-extension:$/i.test(location.protocol) && !window.__plInProcessAndroid)) {
" + ctxt + "
}
"
                cp.write_text(ctxt, encoding="utf-8")

    inproc_tags = """    <script defer src="/libs/result-query.js"></script>
    <script defer src="/libs/request-journal.js"></script>
    <script defer src="/libs/ghost-parser.js"></script>
    <script defer src="/libs/profile-tab.js"></script>
    <script defer src="/libs/TaskManager.js"></script>
    <script defer src="/controllers/TaskManagerContainer.js"></script>
    <script defer src="/controllers/background.js"></script>
    <script data-load-minify defer type="text/javascript" src="/controllers/index.js"></script>"""

    for html_file in assets_ext.rglob("*.html"):
        rel_str = str(html_file.relative_to(assets_ext)).replace("\", "/")
        htxt = html_file.read_text(encoding="utf-8", errors="ignore")
        htxt = htxt.replace("/libs/FoxCommon.js", "/libs/foxCommon.js")
        if "<head>" in htxt:
            if "chrome-ota-patch.js" not in htxt:
                inj = "<head>
<!-- chrome-android-polyfill.js -->"
                if 'name="viewport"' not in htxt:
                    inj += '
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">'
                inj += '
<script src="/chrome-ota-v8-runtime.js"></script>
<script src="/chrome-ota-patch.js"></script>'
                htxt = htxt.replace("<head>", inj, 1)
            elif "chrome-android-polyfill.js" not in htxt:
                htxt = htxt.replace("<head>", "<head>
<!-- chrome-android-polyfill.js -->", 1)
            if rel_str == "views/index.html" and "/controllers/TaskManagerContainer.js" not in htxt:
                htxt = htxt.replace(
                    '    <script data-load-minify defer type="text/javascript" src="/controllers/index.js"></script>',
                    inproc_tags,
                    1
                )
        else:
            # Strip any <meta viewport> and <script chrome-android-polyfill.js> that an old workflow prepended to partials!
            htxt = re.sub(r'(?is)<meta[^>]*viewport[^>]*>\s*', '', htxt)
            htxt = re.sub(r'(?is)<script[^>]*chrome-(?:android-polyfill|ota-patch)\.js[^>]*>\s*</script>\s*', '', htxt)
            if "chrome-android-polyfill.js" not in htxt:
                htxt = "<!-- chrome-android-polyfill.js -->
" + htxt
        html_file.write_text(htxt, encoding="utf-8")

    zip_path = Path("PocketLeads-latest.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(assets_ext):
            for f in files:
                full_p = Path(root) / f
                rel_p = full_p.relative_to(assets_ext)
                zf.write(full_p, arcname=str(rel_p))

    manifest_data = json.loads((assets_ext / "manifest.json").read_text(encoding="utf-8"))
    ver = manifest_data.get("version", "10.19.3")
    ts = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S")
    bid = f"{ver}-{ts}-v6"
    ota_meta = {
        "version": ver,
        "buildId": bid,
        "zipFile": f"PocketLeads-latest.zip?v={bid}",
        "updatedAt": datetime.datetime.utcnow().isoformat() + "Z"
    }
    Path("ota-version.json").write_text(json.dumps(ota_meta, indent=2), encoding="utf-8")

    # Auto-upgrade .github/workflows/main.yml & build-apk.yml to build BOTH Android APK & Windows Desktop .EXE
    desktop_job_marker = "PocketLeads-PRO-Windows-Desktop-EXE"
    desktop_job_yaml = """
  build-windows-exe:
    runs-on: windows-latest
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4

      - name: Setup Node.js 20
        uses: actions/setup-node@v4
        with:
          node-version: '20'

      - name: Unpack Desktop Engine & Sync PocketLeads-latest.zip
        shell: python
        run: |
          import os, shutil, zipfile
          from pathlib import Path

          with zipfile.ZipFile("desktop-engine.zip", "r") as zf:
              zf.extractall(".")

          app_dir = Path("desktop_app")
          ext_dest = app_dir / "pocketleads"
          core_dest = app_dir / "android_core"
          if ext_dest.exists():
              shutil.rmtree(ext_dest)

          tmp_ext = Path("tmp_ext_win")
          if tmp_ext.exists():
              shutil.rmtree(tmp_ext)
          tmp_ext.mkdir(parents=True)
          with zipfile.ZipFile("PocketLeads-latest.zip", "r") as zf:
              zf.extractall(tmp_ext)
          manifests = list(tmp_ext.rglob("manifest.json"))
          ext_root = manifests[0].parent if manifests else tmp_ext
          shutil.copytree(ext_root, ext_dest)

          if Path("android-engine.zip").exists():
              tmp_eng = Path("tmp_eng_win")
              with zipfile.ZipFile("android-engine.zip", "r") as zf:
                  zf.extractall(tmp_eng)
              src_core = tmp_eng / "app" / "src" / "main" / "assets" / "android_core"
              if src_core.exists():
                  if core_dest.exists():
                      shutil.rmtree(core_dest)
                  shutil.copytree(src_core, core_dest)

      - name: Build Windows Desktop .EXE (Setup + Portable)
        working-directory: desktop_app
        run: |
          npm install
          npx electron-builder --win nsis portable

      - name: Upload Ready-to-Install Windows Desktop .EXE
        uses: actions/upload-artifact@v4
        with:
          name: PocketLeads-PRO-Windows-Desktop-EXE
          path: |
            desktop_app/dist/*.exe
"""
    for wf_rel in [".github/workflows/main.yml", ".github/workflows/build-apk.yml"]:
        wf_p = Path(wf_rel)
        if wf_p.exists():
            wtxt = wf_p.read_text(encoding="utf-8", errors="ignore")
            if "else:
                txt = polyfill_tag" in wtxt or "rglob("*.html")" in wtxt:
                wtxt = wtxt.replace(
                    "else:
                txt = polyfill_tag + "\n" + txt",
                    "else:
                txt = "<!-- chrome-android-polyfill.js -->\n" + txt"
                )
            if desktop_job_marker not in wtxt:
                wtxt = wtxt.rstrip() + "
" + desktop_job_yaml
            wf_p.write_text(wtxt, encoding="utf-8")

    if os.environ.get("GITHUB_ACTIONS") == "true":
        subprocess.run(["git", "config", "user.name", "PocketLeads Auto-Updater"], check=False)
        subprocess.run(["git", "config", "user.email", "actions@github.com"], check=False)
        subprocess.run(["git", "add", "ota-version.json", "PocketLeads-latest.zip"], check=False)

        diff_res = subprocess.run(["git", "diff", "--cached", "--quiet"], check=False)
        if diff_res.returncode != 0:
            subprocess.run(["git", "commit", "-m", "chore(ota): auto-heal v6 OTA package [skip ci]"], check=False)
            subprocess.run(["git", "push"], check=False)

if __name__ == "__main__":
    main()
