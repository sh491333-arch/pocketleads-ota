const { app, BrowserWindow, ipcMain, session, Notification, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const http = require('http');
const { execFile } = require('child_process');

const VIRTUAL_ORIGIN = 'https://pocketleads.local';
const DASHBOARD_START_URL = VIRTUAL_ORIGIN + '/views/index.html';
const DEFAULT_GITHUB_RAW_BASE = 'https://raw.githubusercontent.com/sh491333-arch/pocketleads-ota/main';
const DESKTOP_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

let mainWindow = null;
let waWindow = null;
let waTabId = -1;
let nextTabId = 100;
const ghostTabs = new Map();
let lastDownloadedFilePath = '';
let otaCheckInProgress = false;
let lastOtaCheckAtMs = 0;

function getUserDataDir() {
  return app.getPath('userData');
}

function getOtaLiveDir() {
  return path.join(getUserDataDir(), 'ota_extension_live');
}

function getBundledExtDir() {
  return path.join(__dirname, 'pocketleads');
}

function getCoreDir() {
  return path.join(__dirname, 'android_core');
}

function getStorageFilePath() {
  return path.join(getUserDataDir(), 'pocketleads_chrome_storage.json');
}

function getOtaMetaFilePath() {
  return path.join(getUserDataDir(), 'pocketleads_ota_state.json');
}

function readOtaState() {
  try {
    const p = getOtaMetaFilePath();
    if (fs.existsSync(p)) return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch (_) {}
  return {};
}

function writeOtaState(state) {
  try {
    fs.writeFileSync(getOtaMetaFilePath(), JSON.stringify(state || {}, null, 2), 'utf8');
  } catch (_) {}
}

function findFileIgnoreCase(baseDir, relPath) {
  if (!baseDir || !fs.existsSync(baseDir)) return null;
  const cleanRel = String(relPath || '').replace(/^\/+/, '').replace(/\\/g, '/');
  const direct = path.join(baseDir, cleanRel);
  if (fs.existsSync(direct) && fs.statSync(direct).isFile()) return direct;

  const parts = cleanRel.split('/').filter(Boolean);
  let cur = baseDir;
  for (const part of parts) {
    const exact = path.join(cur, part);
    if (fs.existsSync(exact)) {
      cur = exact;
      continue;
    }
    if (!fs.existsSync(cur) || !fs.statSync(cur).isDirectory()) return null;
    const children = fs.readdirSync(cur);
    const match = children.find(c => c.toLowerCase() === part.toLowerCase());
    if (!match) return null;
    cur = path.join(cur, match);
  }
  return (fs.existsSync(cur) && fs.statSync(cur).isFile()) ? cur : null;
}

function resolveExtensionFilePath(cleanPath) {
  const baseName = path.posix.basename(cleanPath);
  const otaFile = findFileIgnoreCase(getOtaLiveDir(), cleanPath);
  if (otaFile) return otaFile;

  const bundledFile = findFileIgnoreCase(getBundledExtDir(), cleanPath);
  if (bundledFile) return bundledFile;

  const coreFile = findFileIgnoreCase(getCoreDir(), baseName);
  if (coreFile) return coreFile;

  return null;
}

function readExtensionText(cleanPath) {
  try {
    const fp = resolveExtensionFilePath(cleanPath);
    if (fp && fs.existsSync(fp)) return fs.readFileSync(fp, 'utf8');
  } catch (_) {}
  return null;
}

function guessMimeType(filePath) {
  const lower = String(filePath || '').toLowerCase();
  if (lower.endsWith('.html')) return 'text/html; charset=utf-8';
  if (lower.endsWith('.js')) return 'application/javascript; charset=utf-8';
  if (lower.endsWith('.css')) return 'text/css; charset=utf-8';
  if (lower.endsWith('.json')) return 'application/json; charset=utf-8';
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
  if (lower.endsWith('.gif')) return 'image/gif';
  if (lower.endsWith('.svg')) return 'image/svg+xml';
  if (lower.endsWith('.woff2')) return 'font/woff2';
  if (lower.endsWith('.woff')) return 'font/woff';
  if (lower.endsWith('.ttf')) return 'font/ttf';
  return 'application/octet-stream';
}

function buildServedAssetBuffer(rawPath) {
  const cleanPath = (!rawPath || rawPath === '/') ? 'views/index.html' : String(rawPath).replace(/^\/+/, '');
  const lowerPath = cleanPath.toLowerCase();
  const mimeType = guessMimeType(cleanPath);

  if (lowerPath.endsWith('.html')) {
    let html = readExtensionText(cleanPath);
    if (html != null) {
      html = html.replace(/\/libs\/FoxCommon\.js/g, '/libs/foxCommon.js')
                 .replace(/libs\/FoxCommon\.js/g, 'libs/foxCommon.js');
      if (html.includes('<head>')) {
        let headInject = '<head>\n<script>window.__plIsDesktopApp = true;</script>';
        if (!html.includes('chrome-ota-v8-runtime.js')) {
          headInject += '\n<script src="/chrome-ota-v8-runtime.js"></script>';
        }
        if (!html.includes('chrome-ota-patch.js') && !html.includes('chrome-android-polyfill.js')) {
          headInject += '\n<script src="/chrome-ota-patch.js"></script>';
        }
        html = html.replace('<head>', headInject);
      } else {
        html = html.replace(/<meta[^>]*viewport[^>]*>\s*/gi, '');
        html = html.replace(/<script[^>]*chrome-(?:android-polyfill|ota-patch|ota-v8-runtime)\.js[^>]*>\s*<\/script>\s*/gi, '');
      }

      if (cleanPath.toLowerCase() === 'views/index.html' && !html.includes('/controllers/TaskManagerContainer.js')) {
        const requiredBgScripts = [
          '/libs/result-query.js',
          '/libs/request-journal.js',
          '/libs/ghost-parser.js',
          '/libs/profile-tab.js',
          '/libs/TaskManager.js',
          '/controllers/TaskManagerContainer.js',
          '/controllers/background.js'
        ];
        let tags = '';
        for (const s of requiredBgScripts) {
          if (readExtensionText(s.slice(1)) != null && !html.includes('src="' + s + '"')) {
            tags += '    <script defer src="' + s + '"></script>\n';
          }
        }
        const idxPos = html.indexOf('/controllers/index.js');
        if (idxPos > 0) {
          const scriptStart = html.lastIndexOf('<script', idxPos);
          if (scriptStart >= 0) {
            html = html.slice(0, scriptStart) + tags + html.slice(scriptStart);
          }
        } else if (html.includes('</body>')) {
          html = html.replace('</body>', tags + '\n</body>');
        }
      }
      return { statusCode: 200, mimeType, buffer: Buffer.from(html, 'utf8') };
    }
  }

  if (lowerPath === 'libs/account.js' || lowerPath === 'libs/request-journal.js' || lowerPath === 'controllers/background.js') {
    let js = readExtensionText(cleanPath);
    if (js != null) {
      if (lowerPath === 'libs/account.js') {
        js = js.replace("const worker = typeof document === 'undefined';", "const worker = true;");
      } else if (lowerPath === 'libs/request-journal.js') {
        js = js.replace(
          "return {get:k=>transact('readonly',s=>s.get(k)),put:v=>transact('readwrite',s=>s.put(v))};",
          "const mem=new Map();return {get:k=>transact('readonly',s=>s.get(k)).catch(()=>mem.get(k)),put:v=>transact('readwrite',s=>s.put(v)).catch(()=>{if(v&&v.slot)mem.set(v.slot,v);})};"
        );
      } else if (lowerPath === 'controllers/background.js') {
        js = js.replace(
          "Math.min(6000,Number(payload&&payload.timeoutMs)||5500)",
          "Math.min(18000,Number(payload&&payload.timeoutMs)||14000)"
        );
      }
      return { statusCode: 200, mimeType, buffer: Buffer.from(js, 'utf8') };
    }
  }

  const fp = resolveExtensionFilePath(cleanPath);
  if (fp && fs.existsSync(fp)) {
    return { statusCode: 200, mimeType, buffer: fs.readFileSync(fp) };
  }
  return { statusCode: 404, mimeType: 'text/plain', buffer: Buffer.from('Not Found', 'utf8') };
}

function downloadUrlBuffer(urlStr, timeoutMs = 20000) {
  return new Promise((resolve) => {
    const fetchStep = (currentUrl, redirectsLeft) => {
      if (redirectsLeft <= 0) return resolve(null);
      try {
        const u = new URL(currentUrl);
        const mod = u.protocol === 'https:' ? https : http;
        const req = mod.get(u, {
          timeout: timeoutMs,
          headers: {
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache',
            'User-Agent': 'PocketLeads-Desktop-OTA/10.0',
            ...(currentUrl.includes('api.github.com') ? { 'Accept': 'application/vnd.github.v3+json' } : {})
          }
        }, (res) => {
          if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
            res.resume();
            const nextUrl = new URL(res.headers.location, u).toString();
            return fetchStep(nextUrl, redirectsLeft - 1);
          }
          if (res.statusCode !== 200) {
            res.resume();
            return resolve(null);
          }
          const chunks = [];
          res.on('data', c => chunks.push(c));
          res.on('end', () => resolve(Buffer.concat(chunks)));
        });
        req.on('error', () => resolve(null));
        req.on('timeout', () => { req.destroy(); resolve(null); });
      } catch (_) {
        resolve(null);
      }
    };
    fetchStep(urlStr, 5);
  });
}

function extractZipBufferToDir(zipBuffer, destDir) {
  // Pure Node.js ZIP extractor (supports STORE=0 and DEFLATE=8)
  const zlib = require('zlib');
  try {
    if (fs.existsSync(destDir)) fs.rmSync(destDir, { recursive: true, force: true });
    fs.mkdirSync(destDir, { recursive: true });

    // Find End of Central Directory (EOCD)
    let eocdOffset = -1;
    for (let i = zipBuffer.length - 22; i >= Math.max(0, zipBuffer.length - 65557); i--) {
      if (zipBuffer.readUInt32LE(i) === 0x06054b50) {
        eocdOffset = i;
        break;
      }
    }
    if (eocdOffset < 0) return false;

    const totalEntries = zipBuffer.readUInt16LE(eocdOffset + 10);
    const cdOffset = zipBuffer.readUInt32LE(eocdOffset + 16);

    const entries = [];
    let ptr = cdOffset;
    for (let i = 0; i < totalEntries; i++) {
      if (ptr + 46 > zipBuffer.length || zipBuffer.readUInt32LE(ptr) !== 0x02014b50) break;
      const method = zipBuffer.readUInt16LE(ptr + 10);
      const compSize = zipBuffer.readUInt32LE(ptr + 20);
      const nameLen = zipBuffer.readUInt16LE(ptr + 28);
      const extraLen = zipBuffer.readUInt16LE(ptr + 30);
      const commentLen = zipBuffer.readUInt16LE(ptr + 32);
      const localHeaderOffset = zipBuffer.readUInt32LE(ptr + 42);
      const rawName = zipBuffer.slice(ptr + 46, ptr + 46 + nameLen).toString('utf8').replace(/\\/g, '/');
      entries.push({ rawName, method, compSize, localHeaderOffset });
      ptr += 46 + nameLen + extraLen + commentLen;
    }

    let stripPrefix = '';
    for (const e of entries) {
      if (!e.rawName.endsWith('/') && (e.rawName === 'manifest.json' || e.rawName.endsWith('/manifest.json'))) {
        stripPrefix = e.rawName.slice(0, e.rawName.lastIndexOf('manifest.json'));
        break;
      }
    }

    for (const e of entries) {
      if (e.rawName.includes('..') || e.rawName.startsWith('__MACOSX')) continue;
      let relName = (stripPrefix && e.rawName.startsWith(stripPrefix))
        ? e.rawName.slice(stripPrefix.length)
        : e.rawName;
      relName = relName.replace(/^\/+/, '');
      if (!relName) continue;

      const outPath = path.join(destDir, relName);
      if (e.rawName.endsWith('/')) {
        fs.mkdirSync(outPath, { recursive: true });
        continue;
      }
      const lh = e.localHeaderOffset;
      if (lh + 30 > zipBuffer.length || zipBuffer.readUInt32LE(lh) !== 0x04034b50) continue;
      const lhNameLen = zipBuffer.readUInt16LE(lh + 26);
      const lhExtraLen = zipBuffer.readUInt16LE(lh + 28);
      const dataStart = lh + 30 + lhNameLen + lhExtraLen;
      const compData = zipBuffer.slice(dataStart, dataStart + e.compSize);

      let fileData = null;
      if (e.method === 0) {
        fileData = compData;
      } else if (e.method === 8) {
        fileData = zlib.inflateRawSync(compData);
      } else {
        continue;
      }
      fs.mkdirSync(path.dirname(outPath), { recursive: true });
      fs.writeFileSync(outPath, fileData);
    }

    return fs.existsSync(path.join(destDir, 'manifest.json'));
  } catch (err) {
    console.warn('[PocketLeads-Desktop] OTA ZIP extract error:', err);
    return false;
  }
}

async function checkForOtaExtensionUpdate() {
  if (otaCheckInProgress) return;
  if (Date.now() - lastOtaCheckAtMs < 10000) return;
  otaCheckInProgress = true;
  lastOtaCheckAtMs = Date.now();

  try {
    const otaState = readOtaState();
    const baseUrl = (otaState.customBaseUrl || DEFAULT_GITHUB_RAW_BASE).replace(/\/+$/, '');
    let remoteBuildId = '';
    let remoteVersion = '';
    let zipUrl = '';

    if (baseUrl.includes('raw.githubusercontent.com/')) {
      const afterHost = baseUrl.slice(baseUrl.indexOf('raw.githubusercontent.com/') + 'raw.githubusercontent.com/'.length);
      const parts = afterHost.split('/');
      if (parts.length >= 3) {
        const [owner, repo, branch] = parts;
        const ghApiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/PocketLeads-latest.zip?ref=${branch}&t=${Date.now()}`;
        const ghBuf = await downloadUrlBuffer(ghApiUrl, 10000);
        if (ghBuf) {
          try {
            const ghJson = JSON.parse(ghBuf.toString('utf8'));
            const sha = String(ghJson.sha || '').trim();
            const dlUrl = String(ghJson.download_url || '').trim();
            if (sha) {
              remoteBuildId = 'sha-' + sha;
              zipUrl = (dlUrl || (baseUrl + '/PocketLeads-latest.zip')) + '?v=' + sha;
            }
          } catch (_) {}
        }
      }
    }

    if (!remoteBuildId) {
      const verBuf = await downloadUrlBuffer(`${baseUrl}/ota-version.json?t=${Date.now()}`, 10000);
      if (verBuf) {
        try {
          const meta = JSON.parse(verBuf.toString('utf8'));
          remoteBuildId = String(meta.buildId || meta.version || '').trim();
          remoteVersion = String(meta.version || '').trim();
          const zipName = String(meta.zipFile || 'PocketLeads-latest.zip').trim();
          zipUrl = zipName.startsWith('http') ? zipName : `${baseUrl}/${zipName.replace(/^\/+/, '')}`;
        } catch (_) {}
      }
    }

    if (!remoteBuildId || !zipUrl) return;

    const liveManifest = path.join(getOtaLiveDir(), 'manifest.json');
    if (remoteBuildId === otaState.installedBuildId && fs.existsSync(liveManifest)) {
      return;
    }

    const zipBuf = await downloadUrlBuffer(zipUrl, 60000);
    if (!zipBuf || zipBuf.length < 1000) return;

    const stagingDir = path.join(getUserDataDir(), 'ota_extension_staging');
    if (extractZipBufferToDir(zipBuf, stagingDir)) {
      const liveDir = getOtaLiveDir();
      if (fs.existsSync(liveDir)) fs.rmSync(liveDir, { recursive: true, force: true });
      fs.renameSync(stagingDir, liveDir);

      try {
        const mObj = JSON.parse(fs.readFileSync(path.join(liveDir, 'manifest.json'), 'utf8'));
        remoteVersion = mObj.version || remoteVersion;
      } catch (_) {}

      writeOtaState({
        ...otaState,
        installedBuildId: remoteBuildId,
        installedVersion: remoteVersion || 'Latest',
        updatedAt: new Date().toISOString()
      });

      if (Notification.isSupported()) {
        new Notification({
          title: 'PocketLeads PRO Auto-Updated!',
          body: `Live OTA Update applied (v${remoteVersion || 'Latest'}). Reloading dashboard...`
        }).show();
      }

      if (mainWindow && !mainWindow.isDestroyed()) {
        await mainWindow.webContents.session.clearCache();
        mainWindow.webContents.loadURL(DASHBOARD_START_URL);
      }
    }
  } catch (err) {
    console.warn('[PocketLeads-Desktop] OTA check warning:', err);
  } finally {
    otaCheckInProgress = false;
  }
}

function invokeDashboardCallback(cbId, payloadJson) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('pl:bridgeCallback', cbId, payloadJson);
  }
}

function createGhostWorkerWindow(tabId, initialUrl) {
  const win = new BrowserWindow({
    width: 1280,
    height: 900,
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: false,
      backgroundThrottling: false,
      images: false
    }
  });
  win.webContents.setUserAgent(DESKTOP_USER_AGENT);
  win.webContents.setAudioMuted(true);

  const entry = { id: tabId, win, url: initialUrl, status: 'loading', isWhatsApp: false };
  ghostTabs.set(tabId, entry);

  win.webContents.on('did-start-loading', () => {
    entry.status = 'loading';
    entry.url = win.webContents.getURL() || entry.url;
  });

  win.webContents.on('did-finish-load', () => {
    entry.status = 'complete';
    entry.url = win.webContents.getURL() || entry.url;
    const parserCode = readExtensionText('libs/ghost-parser.js');
    if (parserCode) {
      win.webContents.executeJavaScript(parserCode).catch(() => {});
    }
  });

  win.on('closed', () => {
    ghostTabs.delete(tabId);
  });

  win.loadURL(initialUrl).catch(() => {});
  return entry;
}

function openOrUpdateWhatsAppWindow(tabId, url) {
  if (!waWindow || waWindow.isDestroyed()) {
    waWindow = new BrowserWindow({
      width: 1100,
      height: 780,
      title: 'PocketLeads PRO — WhatsApp Web Session (Keep logged in for WA Verification)',
      autoHideMenuBar: true,
      webPreferences: {
        preload: path.join(__dirname, 'preload-wa.js'),
        nodeIntegration: false,
        contextIsolation: false,
        backgroundThrottling: false
      }
    });
    waWindow.webContents.setUserAgent(DESKTOP_USER_AGENT);

    waWindow.webContents.on('did-finish-load', () => {
      const entry = ghostTabs.get(waTabId);
      if (entry) {
        entry.url = waWindow.webContents.getURL();
        entry.status = 'complete';
      }
      const scripts = [
        'chrome-wa-tab-bridge.js',
        'whatsapp/wa_preload.js',
        'whatsapp/wa.js',
        'whatsapp/pageBridge.js',
        'whatsapp/inject.js'
      ];
      for (const rel of scripts) {
        const code = readExtensionText(rel);
        if (code) waWindow.webContents.executeJavaScript(code).catch(() => {});
      }
    });

    waWindow.on('closed', () => {
      ghostTabs.delete(waTabId);
      waWindow = null;
    });
  }

  const entry = { id: tabId, win: waWindow, url, status: 'loading', isWhatsApp: true };
  ghostTabs.set(tabId, entry);
  waWindow.show();
  waWindow.loadURL(url).catch(() => {});
  return entry;
}

function registerIpcHandlers() {
  ipcMain.on('pl:getManifestJson', (event) => {
    event.returnValue = readExtensionText('manifest.json') || '{}';
  });

  ipcMain.on('pl:getAllStorageJson', (event) => {
    try {
      const p = getStorageFilePath();
      if (fs.existsSync(p)) {
        event.returnValue = fs.readFileSync(p, 'utf8');
        return;
      }
    } catch (_) {}
    event.returnValue = '{}';
  });

  ipcMain.on('pl:saveAllStorageJson', (_event, jsonStr) => {
    try {
      fs.writeFileSync(getStorageFilePath(), String(jsonStr || '{}'), 'utf8');
    } catch (_) {}
  });

  ipcMain.on('pl:createTab', (event, url, _active) => {
    const isWa = String(url || '').toLowerCase().includes('whatsapp.com');
    const tabId = (isWa && waTabId > 0) ? waTabId : (++nextTabId);
    if (isWa) {
      waTabId = tabId;
      openOrUpdateWhatsAppWindow(tabId, url);
    } else {
      createGhostWorkerWindow(tabId, url);
    }
    event.returnValue = JSON.stringify({ id: tabId, url, active: false, status: 'loading' });
  });

  ipcMain.on('pl:getTab', (event, tabId) => {
    const entry = ghostTabs.get(Number(tabId));
    if (!entry) {
      event.returnValue = 'null';
      return;
    }
    event.returnValue = JSON.stringify({
      id: entry.id,
      url: entry.url || '',
      active: false,
      status: entry.status || 'complete'
    });
  });

  ipcMain.on('pl:updateTab', (event, tabId, updatePropsJson) => {
    const entry = ghostTabs.get(Number(tabId));
    if (!entry) {
      event.returnValue = 'null';
      return;
    }
    try {
      const props = JSON.parse(updatePropsJson || '{}');
      if (props.url && entry.win && !entry.win.isDestroyed()) {
        entry.url = props.url;
        entry.status = 'loading';
        entry.win.loadURL(props.url).catch(() => {});
      }
    } catch (_) {}
    event.returnValue = JSON.stringify({
      id: entry.id,
      url: entry.url || '',
      active: false,
      status: entry.status || 'loading'
    });
  });

  ipcMain.on('pl:removeTab', (_event, tabId) => {
    const entry = ghostTabs.get(Number(tabId));
    ghostTabs.delete(Number(tabId));
    if (entry && entry.win && !entry.win.isDestroyed()) {
      try { entry.win.destroy(); } catch (_) {}
    }
  });

  ipcMain.on('pl:reloadTab', (_event, tabId) => {
    const entry = ghostTabs.get(Number(tabId));
    if (entry && entry.win && !entry.win.isDestroyed()) {
      try { entry.win.webContents.reload(); } catch (_) {}
    }
  });

  ipcMain.on('pl:queryTabs', (event) => {
    const arr = [];
    for (const entry of ghostTabs.values()) {
      arr.push({ id: entry.id, url: entry.url || '', active: false, status: entry.status || 'complete' });
    }
    event.returnValue = JSON.stringify(arr);
  });

  ipcMain.on('pl:executeScriptInTab', async (_event, tabId, funcSource, argsJson, filesJson, cbId) => {
    const entry = ghostTabs.get(Number(tabId));
    if (!entry || !entry.win || entry.win.isDestroyed()) {
      invokeDashboardCallback(cbId, 'null');
      return;
    }
    try {
      const files = JSON.parse(filesJson || '[]');
      for (const f of files) {
        if (f) {
          const code = readExtensionText(String(f).replace(/^\/+/, ''));
          if (code) await entry.win.webContents.executeJavaScript(code).catch(() => {});
        }
      }
      if (!funcSource || !funcSource.trim()) {
        invokeDashboardCallback(cbId, 'null');
        return;
      }
      const iife = `(function(){ try { var __fn = (${funcSource}); var __res = __fn.apply(window, ${argsJson || '[]'}); return (__res === undefined) ? null : __res; } catch(e) { return null; } })()`;
      const result = await entry.win.webContents.executeJavaScript(iife);
      invokeDashboardCallback(cbId, JSON.stringify(result === undefined ? null : result));
    } catch (_) {
      invokeDashboardCallback(cbId, 'null');
    }
  });

  ipcMain.on('pl:sendMessageToTab', (_event, tabId, messageJson, cbId) => {
    const entry = ghostTabs.get(Number(tabId));
    if (!entry || !entry.win || entry.win.isDestroyed()) {
      invokeDashboardCallback(cbId, 'null');
      return;
    }
    const js = `window.__plDispatchTabMessage && window.__plDispatchTabMessage(${messageJson}, ${JSON.stringify(cbId)});`;
    entry.win.webContents.executeJavaScript(js).catch(() => invokeDashboardCallback(cbId, 'null'));
  });

  ipcMain.on('pl:waTabMessageResponse', (_event, cbId, responseJson) => {
    invokeDashboardCallback(cbId, responseJson);
  });

  ipcMain.on('pl:nativeFetchAsync', async (_event, urlStr, method, headersJson, body, timeoutMs, cbId) => {
    try {
      const headers = JSON.parse(headersJson || '{}');
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), Math.max(5000, Number(timeoutMs) || 65000));
      const resp = await fetch(urlStr, {
        method: method || 'GET',
        headers: { 'User-Agent': DESKTOP_USER_AGENT, ...headers },
        body: (method === 'POST' || method === 'PUT') ? body : undefined,
        signal: controller.signal
      });
      clearTimeout(timer);
      const text = await resp.text();
      invokeDashboardCallback(cbId, JSON.stringify({
        ok: resp.ok,
        status: resp.status,
        finalUrl: resp.url || urlStr,
        body: text
      }));
    } catch (err) {
      invokeDashboardCallback(cbId, JSON.stringify({
        ok: false,
        status: 0,
        error: err && err.message ? err.message : 'Fetch error'
      }));
    }
  });

  ipcMain.on('pl:saveDownloadedFile', (_event, filename, _mimeType, base64Data) => {
    try {
      const cleanName = (filename || `PocketLeads_Export_${Date.now()}.xlsx`).replace(/[^a-zA-Z0-9._-]/g, '_');
      const downloadsDir = app.getPath('downloads');
      const outPath = path.join(downloadsDir, cleanName);
      fs.writeFileSync(outPath, Buffer.from(base64Data, 'base64'));
      lastDownloadedFilePath = outPath;

      if (Notification.isSupported()) {
        const notif = new Notification({
          title: '⬇ Download Complete: ' + cleanName,
          body: 'Saved to Downloads folder • Click to open in Excel'
        });
        notif.on('click', () => {
          shell.openPath(outPath);
        });
        notif.show();
      }
    } catch (err) {
      console.warn('[PocketLeads-Desktop] Save download error:', err);
    }
  });

  ipcMain.on('pl:openLastDownloadedFile', () => {
    if (lastDownloadedFilePath && fs.existsSync(lastDownloadedFilePath)) {
      shell.openPath(lastDownloadedFilePath);
    } else {
      shell.openPath(app.getPath('downloads'));
    }
  });

  ipcMain.on('pl:showNotification', (_event, id, title, message) => {
    if (Notification.isSupported()) {
      const notif = new Notification({
        title: title || 'PocketLeads PRO',
        body: message || ''
      });
      notif.on('click', () => {
        if (mainWindow && !mainWindow.isDestroyed()) {
          if (mainWindow.isMinimized()) mainWindow.restore();
          mainWindow.focus();
          if ( String(id || '').startsWith('dl_') && lastDownloadedFilePath && fs.existsSync(lastDownloadedFilePath)) {
            shell.openPath(lastDownloadedFilePath);
          } else {
            mainWindow.webContents.send('pl:notificationClicked', id, title, message);
          }
        }
      });
      notif.show();
    }
  });
}

app.whenReady().then(async () => {
  Menu.setApplicationMenu(null);
  registerIpcHandlers();

  // Intercept https://pocketleads.local/* and serve from OTA or bundled extension
  session.defaultSession.protocol.handle('https', (request) => {
    try {
      const u = new URL(request.url);
      if (u.hostname.toLowerCase() === 'pocketleads.local') {
        const served = buildServedAssetBuffer(u.pathname);
        return new Response(served.buffer, {
          status: served.statusCode,
          headers: {
            'Content-Type': served.mimeType,
            'Access-Control-Allow-Origin': '*',
            'Cache-Control': 'no-store, no-cache, must-revalidate'
          }
        });
      }
    } catch (_) {}
    return fetch(request);
  });

  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 960,
    minHeight: 640,
    title: 'PocketLeads PRO',
    backgroundColor: '#070B24',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: false,
      backgroundThrottling: false
    }
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.includes('pocketleads.local')) {
      shell.openExternal(url);
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });

  mainWindow.on('focus', () => {
    checkForOtaExtensionUpdate();
  });

  await mainWindow.loadURL(DASHBOARD_START_URL);
  checkForOtaExtensionUpdate();
});

app.on('window-all-closed', () => {
  app.quit();
});
