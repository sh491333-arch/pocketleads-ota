const { ipcRenderer } = require('electron');

window.__plIsDesktopApp = true;

window.AndroidChromeBridge = {
  getManifestJson: function() {
    return ipcRenderer.sendSync('pl:getManifestJson');
  },
  getAllStorageJson: function() {
    return ipcRenderer.sendSync('pl:getAllStorageJson');
  },
  saveAllStorageJson: function(jsonStr) {
    ipcRenderer.send('pl:saveAllStorageJson', String(jsonStr || '{}'));
  },
  createTab: function(url, active) {
    return ipcRenderer.sendSync('pl:createTab', String(url || ''), !!active);
  },
  getTab: function(tabId) {
    return ipcRenderer.sendSync('pl:getTab', Number(tabId));
  },
  updateTab: function(tabId, updatePropsJson) {
    return ipcRenderer.sendSync('pl:updateTab', Number(tabId), String(updatePropsJson || '{}'));
  },
  removeTab: function(tabId) {
    ipcRenderer.send('pl:removeTab', Number(tabId));
  },
  reloadTab: function(tabId) {
    ipcRenderer.send('pl:reloadTab', Number(tabId));
  },
  queryTabs: function(queryInfoJson) {
    return ipcRenderer.sendSync('pl:queryTabs', String(queryInfoJson || '{}'));
  },
  executeScriptInTab: function(tabId, funcSource, argsJson, filesJson, cbId) {
    ipcRenderer.send('pl:executeScriptInTab', Number(tabId), String(funcSource || ''), String(argsJson || '[]'), String(filesJson || '[]'), String(cbId || ''));
  },
  sendMessageToTab: function(tabId, messageJson, cbId) {
    ipcRenderer.send('pl:sendMessageToTab', Number(tabId), String(messageJson || '{}'), String(cbId || ''));
  },
  nativeFetchAsync: function(urlStr, method, headersJson, body, timeoutMs, cbId) {
    ipcRenderer.send('pl:nativeFetchAsync', String(urlStr || ''), String(method || 'GET'), String(headersJson || '{}'), String(body || ''), Number(timeoutMs || 65000), String(cbId || ''));
  },
  hasNativeDownloadNotification: function() {
    return true;
  },
  saveDownloadedFile: function(filename, mimeType, base64Data) {
    ipcRenderer.send('pl:saveDownloadedFile', String(filename || ''), String(mimeType || ''), String(base64Data || ''));
  },
  openLastDownloadedFile: function() {
    ipcRenderer.send('pl:openLastDownloadedFile');
  },
  showNotification: function(id, title, message) {
    ipcRenderer.send('pl:showNotification', String(id || ''), String(title || 'PocketLeads PRO'), String(message || ''));
  }
};

ipcRenderer.on('pl:bridgeCallback', (_event, cbId, payloadJson) => {
  if (typeof window.__onAndroidBridgeCallback === 'function') {
    window.__onAndroidBridgeCallback(cbId, payloadJson);
  }
});

ipcRenderer.on('pl:notificationClicked', (_event, id, title, message) => {
  if (typeof window.__onAndroidNotificationClicked === 'function') {
    window.__onAndroidNotificationClicked(id, title, message);
  }
});
