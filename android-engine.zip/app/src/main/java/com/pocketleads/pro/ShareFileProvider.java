package com.pocketleads.pro;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileNotFoundException;

public class ShareFileProvider extends ContentProvider {

    public static final String AUTHORITY = "com.pocketleads.pro.fileprovider";

    public static Uri getUriForFile(File file) {
        return new Uri.Builder()
                .scheme("content")
                .authority(AUTHORITY)
                .appendPath("exports")
                .appendPath(file.getName())
                .build();
    }

    private File resolveSharedFile(Uri uri) throws FileNotFoundException {
        if (uri == null || getContext() == null) {
            throw new FileNotFoundException("Invalid URI");
        }
        String fileName = uri.getLastPathSegment();
        if (fileName == null || fileName.isEmpty() || fileName.contains("..") || fileName.contains("/")) {
            throw new FileNotFoundException("Invalid file name");
        }
        File dir = new File(getContext().getCacheDir(), "shared_exports");
        File target = new File(dir, fileName);
        if (!target.exists() || !target.isFile()) {
            throw new FileNotFoundException("File not found: " + fileName);
        }
        return target;
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        try {
            File file = resolveSharedFile(uri);
            if (projection == null || projection.length == 0) {
                projection = new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
            }
            String[] cols = new String[projection.length];
            Object[] values = new Object[projection.length];
            int i = 0;
            for (String col : projection) {
                if (OpenableColumns.DISPLAY_NAME.equals(col)) {
                    cols[i] = OpenableColumns.DISPLAY_NAME;
                    values[i++] = file.getName();
                } else if (OpenableColumns.SIZE.equals(col)) {
                    cols[i] = OpenableColumns.SIZE;
                    values[i++] = file.length();
                }
            }
            String[] finalCols = new String[i];
            Object[] finalVals = new Object[i];
            System.arraycopy(cols, 0, finalCols, 0, i);
            System.arraycopy(values, 0, finalVals, 0, i);
            MatrixCursor cursor = new MatrixCursor(finalCols, 1);
            cursor.addRow(finalVals);
            return cursor;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public String getType(Uri uri) {
        try {
            File file = resolveSharedFile(uri);
            String name = file.getName().toLowerCase();
            if (name.endsWith(".csv")) return "text/csv";
            if (name.endsWith(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            if (name.endsWith(".html") || name.endsWith(".htm")) return "text/html";
            if (name.endsWith(".json")) return "application/json";
            if (name.endsWith(".txt")) return "text/plain";
            String ext = MimeTypeMap.getFileExtensionFromUrl(name);
            if (ext != null) {
                String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                if (mime != null) return mime;
            }
        } catch (Exception ignored) {}
        return "application/octet-stream";
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File file = resolveSharedFile(uri);
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException("No external inserts");
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("No external updates");
    }
}
