package com.pocketleads.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * PocketLeads PRO v10.23.00 — Persistent Native Android Background Push JobService
 * Runs cleanly on Android 13, 14 & 15 even when the APK is backgrounded or swiped closed from Recent Apps!
 */
public class PocketLeadsPushJobService extends JobService {
    public static final int PUSH_JOB_ID = 9301;
    public static final String CHANNEL_ID = "pocketleads_alerts_v2";
    private static final String PUSH_FEED_URL = "https://pocketleads-edge.samimn7890.workers.dev/exec?action=getphonepush";

    public static void schedulePeriodicPushJob(Context ctx) {
        try {
            JobScheduler js = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;
            ComponentName cn = new ComponentName(ctx, PocketLeadsPushJobService.class);
            JobInfo.Builder b = new JobInfo.Builder(PUSH_JOB_ID, cn)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                b.setPeriodic(15 * 60 * 1000L, 5 * 60 * 1000L);
            } else {
                b.setPeriodic(15 * 60 * 1000L);
            }
            js.schedule(b.build());
        } catch (Exception ignored) {}
    }

    public static void showBrandedBigPictureNotification(Context ctx, String title, String message, String imageUrl, String ctaText, String ctaUrl) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL_ID, "PocketLeads Alerts & Offers", NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("Official PocketLeads offers, updates & important alerts");
                ch.enableVibration(true);
                ch.setShowBadge(true);
                nm.createNotificationChannel(ch);
            }

            Bitmap bannerBmp = decodeSafeBannerBitmap(imageUrl);
            String safeTitle = (title != null && !title.trim().isEmpty()) ? title.trim() : "PocketLeads PRO";
            String safeMsg = (message != null && !message.trim().isEmpty()) ? message.trim() : "Tap to open PocketLeads PRO";

            Bitmap appIcon = BitmapFactory.decodeResource(ctx.getResources(), R.mipmap.ic_launcher);
            Notification.Builder nb = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    ? new Notification.Builder(ctx, CHANNEL_ID)
                    : new Notification.Builder(ctx);

            nb.setSmallIcon(R.mipmap.ic_launcher)
              .setLargeIcon(appIcon)
              .setContentTitle(safeTitle)
              .setContentText(safeMsg)
              .setShowWhen(true)
              .setWhen(System.currentTimeMillis())
              .setAutoCancel(true)
              .setVisibility(Notification.VISIBILITY_PUBLIC);

            if (bannerBmp != null) {
                nb.setStyle(new Notification.BigPictureStyle()
                        .bigPicture(bannerBmp)
                        .bigLargeIcon((Bitmap) null)
                        .setBigContentTitle(safeTitle)
                        .setSummaryText(safeMsg));
            } else {
                // Always attach BigTextStyle so Android shows the expand/collapse chevron-down arrow on every notification
                nb.setStyle(new Notification.BigTextStyle()
                        .setBigContentTitle(safeTitle)
                        .bigText(safeMsg));
            }

            Intent openIntent = new Intent(ctx, MainActivity.class);
            openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            openIntent.putExtra("pl_push_opened", true);
            if (ctaUrl != null && !ctaUrl.isEmpty()) openIntent.putExtra("pl_push_cta_url", ctaUrl);

            int pFlags = Build.VERSION.SDK_INT >= 23
                    ? (PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE)
                    : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent openPi = PendingIntent.getActivity(ctx, (int) (System.currentTimeMillis() & 0x7FFF), openIntent, pFlags);
            nb.setContentIntent(openPi);

            String btnLabel = (ctaText != null && !ctaText.trim().isEmpty()) ? ctaText.trim() : "Open PocketLeads";
            nb.addAction(0, btnLabel, openPi);

            nm.notify((int) (System.currentTimeMillis() & 0xFFFF), nb.build());
        } catch (Exception ignored) {}
    }

    @Override
    public boolean onStartJob(final JobParameters params) {
        new Thread(() -> {
            try {
                SharedPreferences userPrefs = getSharedPreferences("pl_push_prefs", MODE_PRIVATE);
                String savedPhone = userPrefs.getString("phone10", "");
                String fullUrl = PUSH_FEED_URL + (savedPhone != null && !savedPhone.isEmpty() ? ("&phone=" + Uri.encode(savedPhone)) : "");
                URL u = new URL(fullUrl);
                HttpURLConnection conn = (HttpURLConnection) u.openConnection();
                conn.setConnectTimeout(6000);
                conn.setReadTimeout(8000);
                if (conn.getResponseCode() == 200) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    try (InputStream is = conn.getInputStream()) {
                        byte[] buf = new byte[4096];
                        int r;
                        while ((r = is.read(buf)) != -1) bos.write(buf, 0, r);
                    }
                    JSONObject root = new JSONObject(new String(bos.toByteArray(), StandardCharsets.UTF_8));
                    JSONArray arr = root.optJSONArray("pushes");
                    if (arr != null && arr.length() > 0) {
                        SharedPreferences prefs = getSharedPreferences("pl_phone_push_seen", MODE_PRIVATE);
                        for (int i = arr.length() - 1; i >= 0; i--) {
                            JSONObject p = arr.optJSONObject(i);
                            if (p == null) continue;
                            String pid = p.optString("id", "");
                            if (pid.isEmpty() || prefs.getBoolean("seen_" + pid, false)) continue;
                            prefs.edit().putBoolean("seen_" + pid, true).apply();
                            showBrandedBigPictureNotification(
                                    PocketLeadsPushJobService.this,
                                    p.optString("title", "PocketLeads PRO"),
                                    p.optString("message", ""),
                                    p.optString("imageUrl", ""),
                                    p.optString("ctaText", "Open Now"),
                                    p.optString("ctaUrl", "")
                            );
                        }
                    }
                }
            } catch (Exception ignored) {
            } finally {
                jobFinished(params, false);
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return true;
    }
}
