package com.pocketleads.pro;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * PocketLeads PRO v10.24.12 — Native Android NotificationCompat BigPictureStyle / BigTextStyle Engine
 * Guarantees expand/collapse chevron-down arrow and full-width banner image on Android 8–15 (ColorOS/Realme/MIUI/OneUI/Pixel).
 */
public class PocketLeadsPushJobService extends JobService {
    public static final int PUSH_JOB_ID = 9301;
    public static final String CHANNEL_ID = "pocketleads_alerts_v2";
    private static final String PUSH_FEED_URL = "https://pocketleads-edge.samimn7890.workers.dev/exec?action=getphonepush";

    private static Bitmap decodeSafeBannerBitmap(String rawUrl) {
        if (rawUrl == null || rawUrl.trim().isEmpty()) return null;
        String cleanUrl = rawUrl.trim();
        try {
            byte[] bytes = null;
            if (cleanUrl.startsWith("data:image/") && cleanUrl.contains(",")) {
                bytes = android.util.Base64.decode(cleanUrl.substring(cleanUrl.indexOf(',') + 1), android.util.Base64.DEFAULT);
            } else if (cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://")) {
                for (int attempt = 0; attempt < 2 && (bytes == null || bytes.length == 0); attempt++) {
                    HttpURLConnection conn = (HttpURLConnection) new URL(cleanUrl).openConnection();
                    conn.setInstanceFollowRedirects(true);
                    conn.setConnectTimeout(7000);
                    conn.setReadTimeout(9000);
                    conn.setRequestProperty("User-Agent", "PocketLeads-Android/10.24.14");
                    conn.setRequestProperty("Accept", "image/*,*/*");
                    int code = conn.getResponseCode();
                    if (code >= 200 && code < 300) {
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        try (InputStream is = conn.getInputStream()) {
                            byte[] buf = new byte[8192];
                            int n;
                            while ((n = is.read(buf)) != -1) bos.write(buf, 0, n);
                        }
                        bytes = bos.toByteArray();
                    }
                    conn.disconnect();
                    if ((bytes == null || bytes.length == 0) && attempt == 0) {
                        try { Thread.sleep(450); } catch (InterruptedException ignored) {}
                    }
                }
            }
            if (bytes == null || bytes.length == 0) return null;
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
            int sample = 1;
            while ((bounds.outWidth / sample) > 1024 || (bounds.outHeight / sample) > 512) {
                sample *= 2;
            }
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap rawBmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
            if (rawBmp == null) return null;
            int w = rawBmp.getWidth();
            int h = rawBmp.getHeight();
            if (w <= 0 || h <= 0) return rawBmp;
            float ratio = (float) w / (float) h;
            // Android BigPictureStyle crops to ~2:1 landscape; if image is taller than 1.85:1, fit-center on 1024x512 so ZERO text/logo is cropped!
            if (ratio < 1.85f) {
                int outW = 1024;
                int outH = 512;
                Bitmap framed = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(framed);
                canvas.drawColor(Color.parseColor("#0F172A"));
                float scale = Math.min((float) outW / w, (float) outH / h);
                float dstW = w * scale;
                float dstH = h * scale;
                float left = (outW - dstW) / 2f;
                float top = (outH - dstH) / 2f;
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                canvas.drawBitmap(rawBmp, null, new RectF(left, top, left + dstW, top + dstH), p);
                rawBmp.recycle();
                return framed;
            }
            return rawBmp;
        } catch (Exception ignored) {
            return null;
        }
    }

    public static void schedulePeriodicPushJob(Context ctx) {
        try {
            JobScheduler js = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;
            ComponentName cn = new ComponentName(ctx, PocketLeadsPushJobService.class);
            JobInfo.Builder b = new JobInfo.Builder(PUSH_JOB_ID, cn)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                b.setPeriodic(15 * 60 * 1000L, 5 * 60 * 1000L);
            } else {
                b.setPeriodic(15 * 60 * 1000L);
            }
            js.schedule(b.build());
        } catch (Exception ignored) {}
    }

    public static void showBrandedBigPictureNotification(Context ctx, String title, String message, String imageUrl, String ctaText, String ctaUrl) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL_ID, "PocketLeads Alerts & Offers", NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("Official PocketLeads offers, updates & important alerts");
                ch.enableVibration(true);
                ch.setShowBadge(true);
                nm.createNotificationChannel(ch);
            }

            Bitmap bannerBmp = decodeSafeBannerBitmap(imageUrl);
            String safeTitle = (title != null && !title.trim().isEmpty()) ? title.trim() : "PocketLeads PRO";
            String safeMsg = (message != null && !message.trim().isEmpty()) ? message.trim() : "Tap to open PocketLeads PRO";

            Bitmap appIcon = BitmapFactory.decodeResource(ctx.getResources(), R.mipmap.ic_launcher);
            NotificationCompat.Builder nb = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setLargeIcon(bannerBmp != null ? bannerBmp : appIcon)
                    .setContentTitle(safeTitle)
                    .setContentText(safeMsg)
                    .setShowWhen(true)
                    .setWhen(System.currentTimeMillis())
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC);

            if (bannerBmp != null) {
                NotificationCompat.BigPictureStyle bps = new NotificationCompat.BigPictureStyle()
                        .bigPicture(bannerBmp)
                        .bigLargeIcon((Bitmap) null)
                        .setBigContentTitle(safeTitle)
                        .setSummaryText(safeMsg);
                if (Build.VERSION.SDK_INT >= 31) {
                    bps.showBigPictureWhenCollapsed(false);
                }
                nb.setStyle(bps);
            } else {
                // Guarantee expandable chevron-down on every notification (even short text)
                nb.setStyle(new NotificationCompat.BigTextStyle()
                        .setBigContentTitle(safeTitle)
                        .bigText(safeMsg)
                        );
            }

            Intent openIntent = new Intent(ctx, MainActivity.class);
            openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            openIntent.putExtra("pl_push_opened", true);
            if (ctaUrl != null && !ctaUrl.isEmpty()) openIntent.putExtra("pl_push_cta_url", ctaUrl);

            int pFlags = Build.VERSION.SDK_INT >= 23
                    ? (PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE)
                    : PendingIntent.FLAG_UPDATE_CURRENT;
            int reqCode = (int) (System.currentTimeMillis() & 0x7FFF);
            PendingIntent openPi = PendingIntent.getActivity(ctx, reqCode, openIntent, pFlags);
            nb.setContentIntent(openPi);

            String btnLabel = (ctaText != null && !ctaText.trim().isEmpty()) ? ctaText.trim() : "Open PocketLeads";
            nb.addAction(new NotificationCompat.Action.Builder(0, btnLabel, openPi).build());

            nm.notify((int) (System.currentTimeMillis() & 0xFFFF), nb.build());
        } catch (Exception ignored) {}
    }

    @Override
    public boolean onStartJob(final JobParameters params) {
        new Thread(() -> {
            try {
                SharedPreferences userPrefs = getSharedPreferences("pl_push_prefs", MODE_PRIVATE);
                String savedPhone = userPrefs.getString("phone10", "");
                String fullUrl = PUSH_FEED_URL + (savedPhone != null && !savedPhone.isEmpty() ? ("&phone=" + Uri.encode(savedPhone)) : "");
                URL u = new URL(fullUrl);
                HttpURLConnection conn = (HttpURLConnection) u.openConnection();
                conn.setConnectTimeout(6000);
                conn.setReadTimeout(8000);
                if (conn.getResponseCode() == 200) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    try (InputStream is = conn.getInputStream()) {
                        byte[] buf = new byte[4096];
                        int r;
                        while ((r = is.read(buf)) != -1) bos.write(buf, 0, r);
                    }
                    JSONObject root = new JSONObject(new String(bos.toByteArray(), StandardCharsets.UTF_8));
                    JSONArray arr = root.optJSONArray("pushes");
                    if (arr != null && arr.length() > 0) {
                        SharedPreferences prefs = getSharedPreferences("pl_phone_push_seen", MODE_PRIVATE);
                        for (int i = arr.length() - 1; i >= 0; i--) {
                            JSONObject p = arr.optJSONObject(i);
                            if (p == null) continue;
                            String pid = p.optString("id", "");
                            if (pid.isEmpty() || prefs.getBoolean("seen_" + pid, false)) continue;
                            prefs.edit().putBoolean("seen_" + pid, true).apply();
                            showBrandedBigPictureNotification(
                                    PocketLeadsPushJobService.this,
                                    p.optString("title", "PocketLeads PRO"),
                                    p.optString("message", ""),
                                    p.optString("imageUrl", ""),
                                    p.optString("ctaText", "Open Now"),
                                    p.optString("ctaUrl", "")
                            );
                        }
                    }
                }
            } catch (Exception ignored) {
            } finally {
                jobFinished(params, false);
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return true;
    }
}
