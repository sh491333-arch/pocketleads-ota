package com.pocketleads.pro;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * PocketLeads PRO — v5 Self-Patching Universal 1-ZIP + Instant GitHub SHA OTA Engine.
 * - Any raw Desktop Extension ZIP uploaded to GitHub as `PocketLeads-latest.zip` is detected
 *   automatically via GitHub's Contents API (`sha` fingerprint) or `ota-version.json`—even if
 *   the user ONLY uploads `PocketLeads-latest.zip` without touching `ota-version.json`!
 * - `serveExtensionAsset` transforms ANY raw Desktop Extension ZIP on-the-fly in Java RAM:
 *   injecting `/chrome-ota-patch.js` and the 7 In-Process background scripts into `views/index.html`,
 *   and patching `libs/account.js`, `libs/request-journal.js`, and `controllers/background.js`
 *   so raw Desktop ZIPs work on Android with zero blur and zero worker issues!
 */
public class MainActivity extends Activity {

    private static final String VIRTUAL_ORIGIN = "https://pocketleads.local";
    private static final String DASHBOARD_START_URL = VIRTUAL_ORIGIN + "/views/index.html";
    private static final String DEFAULT_GITHUB_RAW_BASE = "https://raw.githubusercontent.com/sh491333-arch/pocketleads-ota/main";
    private static final String DESKTOP_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private FrameLayout rootLayout;
    private FrameLayout ghostWorkerContainer;
    private WebView dashboardWebView;

    private LinearLayout waOverlayContainer;
    private WebView waWebView;
    private int waTabId = -1;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService ioPool = Executors.newCachedThreadPool();
    private final AtomicInteger nextTabId = new AtomicInteger(100);
    private final Map<Integer, GhostTabEntry> ghostTabs = new ConcurrentHashMap<>();
    private final AtomicBoolean otaCheckInProgress = new AtomicBoolean(false);
    private long lastOtaCheckAtMs = 0L;

    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_RESULT_CODE = 5102;

    private static class GhostTabEntry {
        final int id;
        volatile WebView webView;
        volatile String url;
        volatile String status;
        volatile boolean isWhatsApp;

        GhostTabEntry(int id, WebView webView, String url, boolean isWhatsApp) {
            this.id = id;
            this.webView = webView;
            this.url = url;
            this.status = "loading";
            this.isWhatsApp = isWhatsApp;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        rootLayout = new FrameLayout(this);
        rootLayout.setBackgroundColor(Color.parseColor("#070B24"));

        ghostWorkerContainer = new FrameLayout(this);
        ghostWorkerContainer.setVisibility(View.INVISIBLE);
        rootLayout.addView(ghostWorkerContainer, new FrameLayout.LayoutParams(1280, 900));

        dashboardWebView = new WebView(this);
        configureDashboardWebView(dashboardWebView);
        rootLayout.addView(dashboardWebView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        setupWhatsAppOverlay();
        setContentView(rootLayout);

        dashboardWebView.loadUrl(DASHBOARD_START_URL);
        checkForOtaExtensionUpdate();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (System.currentTimeMillis() - lastOtaCheckAtMs > 10000L) {
            checkForOtaExtensionUpdate();
        }
    }

    private File getOtaLiveDir() {
        return new File(getFilesDir(), "ota_extension_live");
    }

    private String resolveBaseOtaUrl() {
        SharedPreferences prefs = getSharedPreferences("pocketleads_ota", Context.MODE_PRIVATE);
        String customBaseUrl = prefs.getString("custom_ota_base_url", "");
        String configuredBaseUrl = getString(R.string.ota_base_url);
        String baseUrl = (customBaseUrl != null && !customBaseUrl.isEmpty()) ? customBaseUrl : configuredBaseUrl;
        if (baseUrl == null || baseUrl.isEmpty() || baseUrl.contains("__OTA_BASE_URL__")) {
            baseUrl = DEFAULT_GITHUB_RAW_BASE;
        }
        return baseUrl.replaceAll("/+$", "");
    }

    private void checkForOtaExtensionUpdate() {
        if (!otaCheckInProgress.compareAndSet(false, true)) return;
        lastOtaCheckAtMs = System.currentTimeMillis();
        ioPool.execute(() -> {
            try {
                SharedPreferences prefs = getSharedPreferences("pocketleads_ota", Context.MODE_PRIVATE);
                String baseUrl = resolveBaseOtaUrl();

                String remoteBuildId = "";
                String remoteVersion = "";
                String zipUrl = "";

                // 1. Primary Instant Check: Query GitHub Contents API for `PocketLeads-latest.zip` SHA!
                //    This detects any newly uploaded `PocketLeads-latest.zip` in <1 second EVEN IF the user
                //    did NOT update `ota-version.json` and BEFORE GitHub Actions finishes running!
                if (baseUrl.contains("raw.githubusercontent.com/")) {
                    try {
                        String afterHost = baseUrl.substring(baseUrl.indexOf("raw.githubusercontent.com/") + "raw.githubusercontent.com/".length());
                        String[] parts = afterHost.split("/");
                        if (parts.length >= 3) {
                            String owner = parts[0];
                            String repo = parts[1];
                            String branch = parts[2];
                            String ghApiUrl = "https://api.github.com/repos/" + owner + "/" + repo
                                    + "/contents/PocketLeads-latest.zip?ref=" + branch + "&t=" + System.currentTimeMillis();
                            byte[] ghBytes = downloadUrlBytes(ghApiUrl, 10000);
                            if (ghBytes != null) {
                                JSONObject ghJson = new JSONObject(new String(ghBytes, StandardCharsets.UTF_8));
                                String sha = ghJson.optString("sha", "").trim();
                                String dlUrl = ghJson.optString("download_url", "").trim();
                                if (!sha.isEmpty()) {
                                    remoteBuildId = "sha-" + sha;
                                    zipUrl = (!dlUrl.isEmpty() ? dlUrl : (baseUrl + "/PocketLeads-latest.zip")) + "?v=" + sha;
                                }
                            }
                        }
                    } catch (Exception ignored) {}
                }

                // 2. Fallback / Supplement: Also check `ota-version.json`
                if (remoteBuildId.isEmpty()) {
                    String versionUrl = baseUrl + "/ota-version.json?t=" + System.currentTimeMillis();
                    byte[] metaBytes = downloadUrlBytes(versionUrl, 10000);
                    if (metaBytes != null) {
                        JSONObject meta = new JSONObject(new String(metaBytes, StandardCharsets.UTF_8));
                        remoteBuildId = meta.optString("buildId", meta.optString("version", "")).trim();
                        remoteVersion = meta.optString("version", "").trim();
                        String zipName = meta.optString("zipFile", "PocketLeads-latest.zip").trim();
                        zipUrl = zipName.startsWith("http") ? zipName : (baseUrl + "/" + zipName.replaceFirst("^/+", ""));
                        if (!zipUrl.contains("?")) {
                            zipUrl = zipUrl + "?v=" + Uri.encode(remoteBuildId) + "&t=" + System.currentTimeMillis();
                        }
                    }
                }

                if (remoteBuildId.isEmpty() || zipUrl.isEmpty()) return;

                String installedBuildId = prefs.getString("installed_build_id", "");
                File liveManifest = new File(getOtaLiveDir(), "manifest.json");
                if (remoteBuildId.equals(installedBuildId) && liveManifest.exists()) {
                    return; // Already on this exact ZIP!
                }

                byte[] zipBytes = downloadUrlBytes(zipUrl, 60000);
                if (zipBytes == null || zipBytes.length < 1000) return;

                if (extractAndInstallOtaZip(zipBytes)) {
                    // Read version from extracted manifest.json
                    try {
                        String mTxt = readExtensionText("manifest.json");
                        if (mTxt != null) {
                            JSONObject mObj = new JSONObject(mTxt);
                            remoteVersion = mObj.optString("version", remoteVersion);
                        }
                    } catch (Exception ignored) {}

                    final String finalVer = remoteVersion.isEmpty() ? "Latest" : remoteVersion;
                    prefs.edit()
                            .putString("installed_build_id", remoteBuildId)
                            .putString("installed_version", finalVer)
                            .apply();
                    mainHandler.post(() -> {
                        Toast.makeText(
                                MainActivity.this,
                                "PocketLeads Live Auto-Updated (v" + finalVer + ")!",
                                Toast.LENGTH_LONG
                        ).show();
                        if (dashboardWebView != null) {
                            dashboardWebView.clearCache(true);
                            dashboardWebView.loadUrl(DASHBOARD_START_URL);
                        }
                    });
                }
            } catch (Exception ignored) {
            } finally {
                otaCheckInProgress.set(false);
            }
        });
    }

    private boolean extractAndInstallOtaZip(byte[] zipBytes) {
        File stagingDir = new File(getFilesDir(), "ota_extension_staging");
        deleteRecursive(stagingDir);
        stagingDir.mkdirs();

        try {
            String stripPrefix = "";
            try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
                ZipEntry entry;
                while ((entry = zis.getNextEntry()) != null) {
                    String name = entry.getName().replace("\\", "/");
                    if (!entry.isDirectory() && (name.equals("manifest.json") || name.endsWith("/manifest.json"))) {
                        int idx = name.lastIndexOf("manifest.json");
                        stripPrefix = name.substring(0, idx);
                        break;
                    }
                }
            }

            try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
                ZipEntry entry;
                byte[] buffer = new byte[8192];
                while ((entry = zis.getNextEntry()) != null) {
                    String rawName = entry.getName().replace("\\", "/");
                    if (rawName.contains("..") || rawName.startsWith("__MACOSX")) continue;
                    String relName = (!stripPrefix.isEmpty() && rawName.startsWith(stripPrefix))
                            ? rawName.substring(stripPrefix.length())
                            : rawName;
                    relName = relName.replaceFirst("^/+", "");
                    if (relName.isEmpty()) continue;

                    File outFile = new File(stagingDir, relName);
                    if (entry.isDirectory()) {
                        outFile.mkdirs();
                    } else {
                        File parent = outFile.getParentFile();
                        if (parent != null && !parent.exists()) parent.mkdirs();
                        try (FileOutputStream fos = new FileOutputStream(outFile)) {
                            int len;
                            while ((len = zis.read(buffer)) != -1) {
                                fos.write(buffer, 0, len);
                            }
                        }
                    }
                }
            }

            File checkManifest = new File(stagingDir, "manifest.json");
            if (!checkManifest.exists()) {
                deleteRecursive(stagingDir);
                return false;
            }

            File liveDir = getOtaLiveDir();
            deleteRecursive(liveDir);
            return stagingDir.renameTo(liveDir);
        } catch (Exception e) {
            deleteRecursive(stagingDir);
            return false;
        }
    }

    private void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) {
                for (File c : children) deleteRecursive(c);
            }
        }
        f.delete();
    }

    private byte[] downloadUrlBytes(String urlStr, int timeoutMs) {
        HttpURLConnection conn = null;
        try {
            String currentUrl = urlStr;
            for (int i = 0; i < 5; i++) {
                URL u = new URL(currentUrl);
                conn = (HttpURLConnection) u.openConnection();
                conn.setInstanceFollowRedirects(true);
                conn.setConnectTimeout(timeoutMs);
                conn.setReadTimeout(timeoutMs);
                conn.setUseCaches(false);
                conn.setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
                conn.setRequestProperty("Pragma", "no-cache");
                conn.setRequestProperty("User-Agent", "PocketLeads-Android-OTA/5.0");
                if (currentUrl.contains("api.github.com")) {
                    conn.setRequestProperty("Accept", "application/vnd.github.v3+json");
                }
                int code = conn.getResponseCode();
                if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                    String loc = conn.getHeaderField("Location");
                    conn.disconnect();
                    if (loc == null) return null;
                    currentUrl = new URL(u, loc).toString();
                    continue;
                }
                if (code != 200) return null;
                try (InputStream is = conn.getInputStream();
                     ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = is.read(buf)) != -1) bos.write(buf, 0, r);
                    return bos.toByteArray();
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
        return null;
    }

    // -------------------------------------------------------------------------
    // Dynamic Asset & OTA File Server with Automatic On-The-Fly Java RAM Patcher
    // -------------------------------------------------------------------------
    private File findFileIgnoreCase(File baseDir, String relPath) {
        if (baseDir == null || !baseDir.exists()) return null;
        File direct = new File(baseDir, relPath);
        if (direct.exists() && direct.isFile()) return direct;
        String[] parts = relPath.split("/");
        File cur = baseDir;
        for (int i = 0; i < parts.length; i++) {
            String part = parts[i];
            if (part.isEmpty()) continue;
            File exactChild = new File(cur, part);
            if (exactChild.exists()) {
                cur = exactChild;
                continue;
            }
            File[] children = cur.listFiles();
            File matched = null;
            if (children != null) {
                for (File c : children) {
                    if (c.getName().equalsIgnoreCase(part)) {
                        matched = c;
                        break;
                    }
                }
            }
            if (matched == null) return null;
            cur = matched;
        }
        return (cur.exists() && cur.isFile()) ? cur : null;
    }

    private InputStream openExtensionStream(String cleanPath) throws Exception {
        String baseName = cleanPath.contains("/") ? cleanPath.substring(cleanPath.lastIndexOf('/') + 1) : cleanPath;
        // 1. Always serve permanent v6 Android Core Runtime from android_core/ so ANY raw or
        //    workflow-processed Extension ZIP automatically gets the v6 Self-Healing Engine!
        if ("chrome-android-polyfill.js".equalsIgnoreCase(baseName)
                || "chrome-ota-patch.js".equalsIgnoreCase(baseName)
                || "android-bg-worker.js".equalsIgnoreCase(baseName)
                || "android-ota-worker.js".equalsIgnoreCase(baseName)
                || "chrome-wa-tab-bridge.js".equalsIgnoreCase(baseName)) {
            return getAssets().open("android_core/" + baseName.toLowerCase());
        }
        // 2. If an OTA Live Update is installed, serve extension files from ota_extension_live/ first (case-insensitive!)
        File otaFile = findFileIgnoreCase(getOtaLiveDir(), cleanPath);
        if (otaFile != null) {
            return new FileInputStream(otaFile);
        }
        // 3. Fallback to inbuilt APK assets/pocketleads/ (with case-insensitive fallback for FoxCommon.js etc.)
        try {
            return getAssets().open("pocketleads/" + cleanPath);
        } catch (Exception e) {
            int slash = cleanPath.lastIndexOf('/');
            String dir = slash >= 0 ? ("pocketleads/" + cleanPath.substring(0, slash)) : "pocketleads";
            String targetName = slash >= 0 ? cleanPath.substring(slash + 1) : cleanPath;
            String[] list = getAssets().list(dir);
            if (list != null) {
                for (String item : list) {
                    if (item.equalsIgnoreCase(targetName)) {
                        return getAssets().open(dir + "/" + item);
                    }
                }
            }
            throw e;
        }
    }

    private String readExtensionText(String cleanPath) {
        try (InputStream is = openExtensionStream(cleanPath);
             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int r;
            while ((r = is.read(buf)) != -1) bos.write(buf, 0, r);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    private WebResourceResponse serveExtensionAsset(String rawPath) {
        String cleanPath = (rawPath == null || rawPath.isEmpty() || "/".equals(rawPath))
                ? "views/index.html"
                : rawPath.replaceFirst("^/+", "");
        try {
            String mime = guessMimeType(cleanPath);
            Map<String, String> headers = new HashMap<>();
            headers.put("Access-Control-Allow-Origin", "*");
            headers.put("Cache-Control", "no-store, no-cache, must-revalidate");

            String lowerPath = cleanPath.toLowerCase();

            // A) On-The-Fly HTML Auto-Patcher & Partial Healer for ANY Old or New Extension ZIP!
            if (lowerPath.endsWith(".html")) {
                String html = readExtensionText(cleanPath);
                if (html != null) {
                    // Fix older extension ZIPs that reference capitalised /libs/FoxCommon.js
                    html = html.replace("/libs/FoxCommon.js", "/libs/foxCommon.js")
                               .replace("libs/FoxCommon.js", "libs/foxCommon.js");

                    if (html.contains("<head>")) {
                        // Full HTML document (e.g. views/index.html, popup/license.html)
                        StringBuilder headInject = new StringBuilder("<head>");
                        if (!html.contains("name=\"viewport\"")) {
                            headInject.append("\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\">");
                        }
                        if (!html.contains("chrome-ota-patch.js") && !html.contains("chrome-android-polyfill.js")) {
                            headInject.append("\n<script src=\"/chrome-ota-patch.js\"></script>");
                        }
                        html = html.replaceFirst("<head>", headInject.toString());
                    } else {
                        // AngularJS ng-include HTML partial (e.g. views/navbar.html, views/login.html)!
                        // CRITICAL: If an old GitHub Actions workflow prepended <meta viewport> or <script chrome-android-polyfill.js>
                        // to this partial, strip them out in RAM so AngularJS ng-include NEVER crashes with [$compile:tplrt]!
                        html = html.replaceAll("(?is)<meta[^>]*viewport[^>]*>\\s*", "");
                        html = html.replaceAll("(?is)<script[^>]*chrome-(?:android-polyfill|ota-patch)\\.js[^>]*>\\s*</script>\\s*", "");
                    }

                    // If serving views/index.html from a raw Desktop ZIP that doesn't have the In-Process background
                    // scripts yet, inject them right before controllers/index.js in RAM!
                    if ("views/index.html".equalsIgnoreCase(cleanPath) && !html.contains("/controllers/TaskManagerContainer.js")) {
                        StringBuilder inProcessTags = new StringBuilder();
                        String[] requiredBgScripts = new String[]{
                                "/libs/result-query.js",
                                "/libs/request-journal.js",
                                "/libs/ghost-parser.js",
                                "/libs/profile-tab.js",
                                "/libs/TaskManager.js",
                                "/controllers/TaskManagerContainer.js",
                                "/controllers/background.js"
                        };
                        for (String s : requiredBgScripts) {
                            if (readExtensionText(s.substring(1)) != null && !html.contains("src=\"" + s + "\"")) {
                                inProcessTags.append("    <script defer src=\"").append(s).append("\"></script>\n");
                            }
                        }
                        int idxPos = html.indexOf("/controllers/index.js");
                        if (idxPos > 0) {
                            int scriptStart = html.lastIndexOf("<script", idxPos);
                            if (scriptStart >= 0) {
                                html = html.substring(0, scriptStart) + inProcessTags.toString() + html.substring(scriptStart);
                            }
                        } else if (html.contains("</body>")) {
                            html = html.replaceFirst("</body>", inProcessTags.toString() + "\n</body>");
                        }
                    }

                    InputStream injectedStream = new ByteArrayInputStream(html.getBytes(StandardCharsets.UTF_8));
                    return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, injectedStream);
                }
            }

            // B) On-The-Fly JS Auto-Patcher for ANY raw Desktop Extension ZIP!
            if ("libs/account.js".equalsIgnoreCase(cleanPath)
                    || "libs/request-journal.js".equalsIgnoreCase(cleanPath)
                    || "controllers/background.js".equalsIgnoreCase(cleanPath)) {
                String js = readExtensionText(cleanPath);
                if (js != null) {
                    if ("libs/account.js".equalsIgnoreCase(cleanPath)) {
                        js = js.replace(
                                "const worker = typeof document === 'undefined';",
                                "const worker = true;"
                        );
                    } else if ("libs/request-journal.js".equalsIgnoreCase(cleanPath)) {
                        js = js.replace(
                                "return {get:k=>transact('readonly',s=>s.get(k)),put:v=>transact('readwrite',s=>s.put(v))};",
                                "const mem=new Map();return {get:k=>transact('readonly',s=>s.get(k)).catch(()=>mem.get(k)),put:v=>transact('readwrite',s=>s.put(v)).catch(()=>{if(v&&v.slot)mem.set(v.slot,v);})};"
                        );
                    } else if ("controllers/background.js".equalsIgnoreCase(cleanPath)) {
                        js = js.replace(
                                "Math.min(6000,Number(payload&&payload.timeoutMs)||5500)",
                                "Math.min(18000,Number(payload&&payload.timeoutMs)||14000)"
                        );
                    }
                    InputStream patchedJsStream = new ByteArrayInputStream(js.getBytes(StandardCharsets.UTF_8));
                    return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, patchedJsStream);
                }
            }

            InputStream is = openExtensionStream(cleanPath);
            return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, is);
        } catch (Exception e) {
            return new WebResourceResponse(
                    "text/plain",
                    "UTF-8",
                    404,
                    "Not Found",
                    null,
                    new ByteArrayInputStream("Not Found".getBytes(StandardCharsets.UTF_8))
            );
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void configureDashboardWebView(WebView webView) {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new AndroidChromeBridge(), "AndroidChromeBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri != null && "pocketleads.local".equalsIgnoreCase(uri.getHost())) {
                    return serveExtensionAsset(uri.getPath());
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return false;
                String scheme = uri.getScheme() != null ? uri.getScheme().toLowerCase() : "";
                if ("mailto".equals(scheme) || "tel".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored) {}
                    return true;
                }
                if ("pocketleads.local".equalsIgnoreCase(uri.getHost())) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {}
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_RESULT_CODE);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupWhatsAppOverlay() {
        waOverlayContainer = new LinearLayout(this);
        waOverlayContainer.setOrientation(LinearLayout.VERTICAL);
        waOverlayContainer.setBackgroundColor(Color.parseColor("#0F172A"));
        waOverlayContainer.setVisibility(View.GONE);

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(Color.parseColor("#070B24"));
        int pad = dpToPx(10);
        topBar.setPadding(pad, pad, pad, pad);

        Button backBtn = new Button(this);
        backBtn.setText("← Back to Dashboard");
        backBtn.setTextColor(Color.WHITE);
        backBtn.setBackgroundColor(Color.parseColor("#0072FF"));
        backBtn.setOnClickListener(v -> waOverlayContainer.setVisibility(View.GONE));

        TextView titleView = new TextView(this);
        titleView.setText("  WhatsApp Web Session (Keep logged in for WA Checker)");
        titleView.setTextColor(Color.parseColor("#E2E8F0"));
        titleView.setTextSize(13f);

        topBar.addView(backBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        topBar.addView(titleView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        waWebView = new WebView(this);
        WebSettings ws = waWebView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setUserAgentString(DESKTOP_USER_AGENT);
        ws.setUseWideViewPort(true);
        ws.setLoadWithOverviewMode(true);

        CookieManager.getInstance().setAcceptThirdPartyCookies(waWebView, true);
        waWebView.addJavascriptInterface(new AndroidWaTabBridge(), "AndroidWaTabBridge");

        waWebView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri != null && "pocketleads.local".equalsIgnoreCase(uri.getHost())) {
                    return serveExtensionAsset(uri.getPath());
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                GhostTabEntry entry = ghostTabs.get(waTabId);
                if (entry != null) {
                    entry.url = url;
                    entry.status = "complete";
                }
                injectExtensionScript(waWebView, "chrome-wa-tab-bridge.js");
                injectExtensionScript(waWebView, "whatsapp/wa_preload.js");
                injectExtensionScript(waWebView, "whatsapp/wa.js");
                injectExtensionScript(waWebView, "whatsapp/pageBridge.js");
                injectExtensionScript(waWebView, "whatsapp/inject.js");
            }
        });

        waOverlayContainer.addView(topBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        waOverlayContainer.addView(waWebView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        rootLayout.addView(waOverlayContainer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
    }

    @SuppressLint("SetJavaScriptEnabled")
    private WebView createGhostWorkerWebView(final int tabId) {
        WebView wv = new WebView(this);
        WebSettings ws = wv.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setUserAgentString(DESKTOP_USER_AGENT);
        ws.setBlockNetworkImage(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true);

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return false;
                String scheme = uri.getScheme() != null ? uri.getScheme().toLowerCase() : "";
                if (!"http".equals(scheme) && !"https".equals(scheme)) {
                    return true;
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                GhostTabEntry entry = ghostTabs.get(tabId);
                if (entry != null) {
                    entry.url = url;
                    entry.status = "loading";
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                GhostTabEntry entry = ghostTabs.get(tabId);
                if (entry != null) {
                    entry.url = url;
                    entry.status = "complete";
                }
                injectExtensionScript(view, "libs/ghost-parser.js");
            }
        });

        ghostWorkerContainer.addView(wv, new FrameLayout.LayoutParams(1280, 900));
        return wv;
    }

    private void injectExtensionScript(WebView targetView, String relPath) {
        String code = readExtensionText(relPath);
        if (code != null && !code.isEmpty()) {
            targetView.evaluateJavascript(code, null);
        }
    }

    private String guessMimeType(String path) {
        String lower = path.toLowerCase();
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".js")) return "application/javascript";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".gif")) return "image/gif";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".woff2")) return "font/woff2";
        if (lower.endsWith(".woff")) return "font/woff";
        if (lower.endsWith(".ttf")) return "font/ttf";
        return "application/octet-stream";
    }

    private File getStorageFile() {
        return new File(getFilesDir(), "pocketleads_chrome_storage.json");
    }

    private void invokeDashboardCallback(final String cbId, final String payloadJson) {
        mainHandler.post(() -> {
            String safeJson = payloadJson == null ? "null" : JSONObject.quote(payloadJson);
            String js = "window.__onAndroidBridgeCallback && window.__onAndroidBridgeCallback("
                    + JSONObject.quote(cbId) + ", " + safeJson + ");";
            dashboardWebView.evaluateJavascript(js, null);
        });
    }

    public class AndroidWaTabBridge {
        @JavascriptInterface
        public void onTabMessageResponse(String cbId, String responseJson) {
            invokeDashboardCallback(cbId, responseJson);
        }
    }

    public class AndroidChromeBridge {

        @JavascriptInterface
        public String getManifestJson() {
            String m = readExtensionText("manifest.json");
            return m != null ? m : "{}";
        }

        @JavascriptInterface
        public synchronized String getAllStorageJson() {
            File f = getStorageFile();
            if (!f.exists()) return "{}";
            try (FileInputStream fis = new FileInputStream(f);
                 ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int r;
                while ((r = fis.read(buf)) != -1) bos.write(buf, 0, r);
                return new String(bos.toByteArray(), StandardCharsets.UTF_8);
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public synchronized void saveAllStorageJson(String json) {
            if (json == null) return;
            File f = getStorageFile();
            try (FileOutputStream fos = new FileOutputStream(f, false)) {
                fos.write(json.getBytes(StandardCharsets.UTF_8));
                fos.flush();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String createTab(final String url, final boolean active) {
            final boolean isWa = url != null && url.toLowerCase().contains("whatsapp.com");
            final int tabId = isWa && waTabId > 0 ? waTabId : nextTabId.incrementAndGet();
            if (isWa) waTabId = tabId;

            final GhostTabEntry entry = new GhostTabEntry(tabId, isWa ? waWebView : null, url, isWa);
            ghostTabs.put(tabId, entry);

            mainHandler.post(() -> {
                if (isWa) {
                    entry.webView = waWebView;
                    waOverlayContainer.setVisibility(View.VISIBLE);
                    waWebView.loadUrl(url);
                } else {
                    WebView wv = createGhostWorkerWebView(tabId);
                    entry.webView = wv;
                    wv.loadUrl(url);
                }
            });

            try {
                JSONObject obj = new JSONObject();
                obj.put("id", tabId);
                obj.put("url", url);
                obj.put("active", false);
                obj.put("status", "loading");
                return obj.toString();
            } catch (Exception e) {
                return "{\"id\":" + tabId + ",\"active\":false}";
            }
        }

        @JavascriptInterface
        public String getTab(int tabId) {
            GhostTabEntry entry = ghostTabs.get(tabId);
            if (entry == null) return "null";
            try {
                JSONObject obj = new JSONObject();
                obj.put("id", entry.id);
                obj.put("url", entry.url != null ? entry.url : "");
                obj.put("active", false);
                obj.put("status", entry.status != null ? entry.status : "complete");
                return obj.toString();
            } catch (Exception e) {
                return "null";
            }
        }

        @JavascriptInterface
        public String updateTab(final int tabId, final String updatePropsJson) {
            final GhostTabEntry entry = ghostTabs.get(tabId);
            if (entry == null) return "null";
            try {
                JSONObject props = new JSONObject(updatePropsJson);
                final String newUrl = props.optString("url", "");
                if (!newUrl.isEmpty()) {
                    entry.url = newUrl;
                    entry.status = "loading";
                    mainHandler.post(() -> {
                        if (entry.webView != null) entry.webView.loadUrl(newUrl);
                    });
                }
                return getTab(tabId);
            } catch (Exception e) {
                return getTab(tabId);
            }
        }

        @JavascriptInterface
        public void removeTab(final int tabId) {
            final GhostTabEntry entry = ghostTabs.remove(tabId);
            if (entry == null) return;
            mainHandler.post(() -> {
                if (entry.isWhatsApp) {
                    waOverlayContainer.setVisibility(View.GONE);
                } else if (entry.webView != null) {
                    try {
                        ghostWorkerContainer.removeView(entry.webView);
                        entry.webView.stopLoading();
                        entry.webView.loadUrl("about:blank");
                        entry.webView.destroy();
                    } catch (Exception ignored) {}
                }
            });
        }

        @JavascriptInterface
        public void reloadTab(final int tabId) {
            final GhostTabEntry entry = ghostTabs.get(tabId);
            if (entry == null) return;
            mainHandler.post(() -> {
                if (entry.webView != null) entry.webView.reload();
            });
        }

        @JavascriptInterface
        public String queryTabs(String queryInfoJson) {
            JSONArray arr = new JSONArray();
            try {
                for (GhostTabEntry entry : ghostTabs.values()) {
                    JSONObject obj = new JSONObject();
                    obj.put("id", entry.id);
                    obj.put("url", entry.url != null ? entry.url : "");
                    obj.put("active", false);
                    obj.put("status", entry.status);
                    arr.put(obj);
                }
            } catch (Exception ignored) {}
            return arr.toString();
        }

        @JavascriptInterface
        public void executeScriptInTab(final int tabId, final String funcSource, final String argsJson, final String filesJson, final String cbId) {
            final GhostTabEntry entry = ghostTabs.get(tabId);
            if (entry == null) {
                invokeDashboardCallback(cbId, "null");
                return;
            }
            mainHandler.post(() -> {
                try {
                    if (entry.webView == null) {
                        invokeDashboardCallback(cbId, "null");
                        return;
                    }
                    if (filesJson != null && !filesJson.isEmpty()) {
                        JSONArray files = new JSONArray(filesJson);
                        for (int i = 0; i < files.length(); i++) {
                            String f = files.optString(i, "");
                            if (!f.isEmpty()) {
                                injectExtensionScript(entry.webView, f.replaceFirst("^/+", ""));
                            }
                        }
                    }
                    if (funcSource == null || funcSource.trim().isEmpty()) {
                        invokeDashboardCallback(cbId, "null");
                        return;
                    }
                    String iife = "(function(){ try { var __fn = (" + funcSource + "); var __res = __fn.apply(window, "
                            + (argsJson != null && !argsJson.isEmpty() ? argsJson : "[]")
                            + "); return (__res === undefined) ? null : __res; } catch(e) { return null; } })()";
                    entry.webView.evaluateJavascript(iife, value -> invokeDashboardCallback(cbId, value));
                } catch (Exception e) {
                    invokeDashboardCallback(cbId, "null");
                }
            });
        }

        @JavascriptInterface
        public void sendMessageToTab(final int tabId, final String messageJson, final String cbId) {
            final GhostTabEntry entry = ghostTabs.get(tabId);
            if (entry == null) {
                invokeDashboardCallback(cbId, "null");
                return;
            }
            mainHandler.post(() -> {
                if (entry.webView == null) {
                    invokeDashboardCallback(cbId, "null");
                    return;
                }
                String js = "window.__plDispatchTabMessage && window.__plDispatchTabMessage("
                        + messageJson + ", " + JSONObject.quote(cbId) + ");";
                entry.webView.evaluateJavascript(js, null);
            });
        }

        @JavascriptInterface
        public void nativeFetchAsync(final String urlStr, final String method, final String headersJson, final String body, final int timeoutMs, final String cbId) {
            ioPool.execute(() -> {
                JSONObject res = new JSONObject();
                HttpURLConnection conn = null;
                try {
                    String currentUrl = urlStr;
                    String currentMethod = method != null ? method.toUpperCase() : "GET";
                    String currentBody = body;

                    for (int redirects = 0; redirects < 6; redirects++) {
                        URL u = new URL(currentUrl);
                        conn = (HttpURLConnection) u.openConnection();
                        conn.setInstanceFollowRedirects(false);
                        conn.setConnectTimeout(Math.max(5000, timeoutMs));
                        conn.setReadTimeout(Math.max(5000, timeoutMs));
                        conn.setRequestMethod(currentMethod);
                        conn.setRequestProperty("User-Agent", DESKTOP_USER_AGENT);

                        if (headersJson != null && !headersJson.isEmpty()) {
                            JSONObject hObj = new JSONObject(headersJson);
                            Iterator<String> keys = hObj.keys();
                            while (keys.hasNext()) {
                                String k = keys.next();
                                conn.setRequestProperty(k, hObj.optString(k, ""));
                            }
                        }

                        if ("POST".equals(currentMethod) && currentBody != null) {
                            conn.setDoOutput(true);
                            byte[] outBytes = currentBody.getBytes(StandardCharsets.UTF_8);
                            try (OutputStream os = conn.getOutputStream()) {
                                os.write(outBytes);
                            }
                        }

                        int code = conn.getResponseCode();
                        if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                            String loc = conn.getHeaderField("Location");
                            conn.disconnect();
                            if (loc == null || loc.isEmpty()) break;
                            currentUrl = new URL(u, loc).toString();
                            if (code == 301 || code == 302 || code == 303) {
                                currentMethod = "GET";
                                currentBody = null;
                            }
                            continue;
                        }

                        InputStream is = (code >= 200 && code < 400) ? conn.getInputStream() : conn.getErrorStream();
                        String responseText = "";
                        if (is != null) {
                            ByteArrayOutputStream bos = new ByteArrayOutputStream();
                            byte[] buf = new byte[8192];
                            int r;
                            int total = 0;
                            while ((r = is.read(buf)) != -1 && total < 5000000) {
                                bos.write(buf, 0, r);
                                total += r;
                            }
                            is.close();
                            responseText = new String(bos.toByteArray(), StandardCharsets.UTF_8);
                        }
                        res.put("ok", code >= 200 && code < 300);
                        res.put("status", code);
                        res.put("finalUrl", currentUrl);
                        res.put("body", responseText);
                        break;
                    }
                } catch (Exception e) {
                    try {
                        res.put("ok", false);
                        res.put("status", 0);
                        res.put("error", e.getMessage());
                    } catch (Exception ignored) {}
                } finally {
                    if (conn != null) conn.disconnect();
                }
                invokeDashboardCallback(cbId, res.toString());
            });
        }

        @JavascriptInterface
        public void saveDownloadedFile(final String filename, final String mimeType, final String base64Data) {
            ioPool.execute(() -> {
                try {
                    byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                    String cleanName = (filename == null || filename.isEmpty())
                            ? ("PocketLeads_Export_" + System.currentTimeMillis() + ".csv")
                            : filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                    String cleanMime = (mimeType == null || mimeType.isEmpty()) ? "text/csv" : mimeType.split(";")[0];

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, cleanName);
                        values.put(MediaStore.Downloads.MIME_TYPE, cleanMime);
                        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (uri != null) {
                            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                                if (os != null) os.write(bytes);
                            }
                        }
                    } else {
                        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                        if (!dir.exists()) dir.mkdirs();
                        File outFile = new File(dir, cleanName);
                        try (FileOutputStream fos = new FileOutputStream(outFile)) {
                            fos.write(bytes);
                        }
                    }
                    mainHandler.post(() -> Toast.makeText(
                            MainActivity.this,
                            "Saved to Downloads: " + cleanName,
                            Toast.LENGTH_LONG
                    ).show());
                } catch (Exception e) {
                    mainHandler.post(() -> Toast.makeText(
                            MainActivity.this,
                            "Export failed: " + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show());
                }
            });
        }

        @JavascriptInterface
        public void showNotification(final String id, final String title, final String message) {
            mainHandler.post(() -> {
                try {
                    String channelId = "pocketleads_alerts";
                    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    if (nm != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            NotificationChannel channel = new NotificationChannel(
                                    channelId,
                                    "PocketLeads Alerts",
                                    NotificationManager.IMPORTANCE_DEFAULT
                            );
                            nm.createNotificationChannel(channel);
                            Notification notif = new Notification.Builder(MainActivity.this, channelId)
                                    .setContentTitle(title)
                                    .setContentText(message)
                                    .setSmallIcon(R.mipmap.ic_launcher)
                                    .setAutoCancel(true)
                                    .build();
                            nm.notify(id.hashCode(), notif);
                        }
                    }
                } catch (Exception ignored) {}
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_RESULT_CODE) {
            if (filePathCallback == null) return;
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (waOverlayContainer != null && waOverlayContainer.getVisibility() == View.VISIBLE) {
            waOverlayContainer.setVisibility(View.GONE);
            return;
        }
        if (dashboardWebView != null && dashboardWebView.canGoBack()) {
            dashboardWebView.goBack();
            return;
        }
        moveTaskToBack(true);
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
