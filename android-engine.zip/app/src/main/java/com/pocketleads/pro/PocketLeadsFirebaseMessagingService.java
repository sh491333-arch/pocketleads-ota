package com.pocketleads.pro;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * PocketLeads PRO v10.24.09 — Native 1-Second Firebase Cloud Messaging (FCM) Receiver
 * Delivers branded BigPictureStyle notifications (with uploaded or URL banner images)
 * even when the APK is completely closed or the device is locked.
 */
public class PocketLeadsFirebaseMessagingService extends FirebaseMessagingService {
    private static final String WORKER_EXEC_URL = "https://pocketleads-edge.samimn7890.workers.dev/exec";

    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);
        if (token == null || token.trim().isEmpty()) return;
        try {
            SharedPreferences prefs = getSharedPreferences("pl_push_prefs", MODE_PRIVATE);
            prefs.edit().putString("fcm_token", token.trim()).apply();
            String savedPhone = prefs.getString("phone10", "");
            registerFcmTokenWithWorker(getApplicationContext(), token.trim(), savedPhone);
        } catch (Exception ignored) {}
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        if (remoteMessage == null) return;
        try {
            Map<String, String> data = remoteMessage.getData();
            String pushId = data != null ? data.get("pushId") : null;
            String title = data != null ? data.get("title") : null;
            String message = data != null ? data.get("message") : null;
            String imageUrl = data != null ? data.get("imageUrl") : null;
            String ctaText = data != null ? data.get("ctaText") : null;
            String ctaUrl = data != null ? data.get("ctaUrl") : null;

            if (remoteMessage.getNotification() != null) {
                if (title == null || title.isEmpty()) title = remoteMessage.getNotification().getTitle();
                if (message == null || message.isEmpty()) message = remoteMessage.getNotification().getBody();
                if ((imageUrl == null || imageUrl.isEmpty()) && remoteMessage.getNotification().getImageUrl() != null) {
                    imageUrl = remoteMessage.getNotification().getImageUrl().toString();
                }
            }

            if (title == null || title.trim().isEmpty()) title = "PocketLeads PRO";
            if (message == null) message = "";
            if (ctaText == null || ctaText.trim().isEmpty()) ctaText = "Open PocketLeads";

            // Deduplicate against periodic JobService poller so user never sees double notification
            if (pushId != null && !pushId.trim().isEmpty()) {
                SharedPreferences seen = getSharedPreferences("pl_phone_push_seen", MODE_PRIVATE);
                if (seen.getBoolean("seen_" + pushId.trim(), false)) return;
                seen.edit().putBoolean("seen_" + pushId.trim(), true).apply();
            }

            PocketLeadsPushJobService.showBrandedBigPictureNotification(
                    getApplicationContext(),
                    title,
                    message,
                    imageUrl != null ? imageUrl : "",
                    ctaText,
                    ctaUrl != null ? ctaUrl : ""
            );
        } catch (Exception ignored) {}
    }

    public static void registerFcmTokenWithWorker(final Context ctx, final String token, final String phone10) {
        if (ctx == null || token == null || token.trim().isEmpty()) return;
        new Thread(() -> {
            try {
                String devId = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ANDROID_ID);
                if (devId == null || devId.trim().isEmpty()) devId = "android-fcm-device";
                JSONObject body = new JSONObject();
                body.put("action", "registerPushDevice");
                body.put("deviceId", devId);
                body.put("phone", phone10 != null ? phone10 : "");
                body.put("fcmToken", token.trim());
                body.put("platform", "android");
                body.put("permStatus", "granted");
                body.put("appVersion", "10.24.11");

                HttpURLConnection conn = (HttpURLConnection) new URL(WORKER_EXEC_URL).openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(6000);
                conn.setReadTimeout(8000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(bytes);
                }
                conn.getResponseCode();
                conn.disconnect();
            } catch (Exception ignored) {}
        }).start();
    }
}
