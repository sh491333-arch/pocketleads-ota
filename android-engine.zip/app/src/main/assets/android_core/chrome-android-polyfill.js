/*
 * PocketLeads PRO Android Native Runtime Polyfill (Universal Desktop + Android Edition)
 * - In Desktop Chrome (chrome://extensions): Detects native Chrome MV3 environment and does nothing.
 * - In Android APK: Emulates Chrome MV3 APIs (storage, runtime, tabs, scripting, alarms,
 *   notifications, system, offscreen) and bridges Dashboard UI <-> Web Worker <-> Native Android.
 */
(function(globalScope) {
  'use strict';
  if (globalScope.__pocketLeadsAndroidPolyfillLoaded) return;

  const IS_WORKER = typeof document === 'undefined';
  // If running inside real Desktop Chrome Extension (no AndroidChromeBridge, native chrome.storage & chrome.tabs present), do nothing!
  try {
    const isDesktopChromeExt = !globalScope.AndroidChromeBridge &&
      typeof globalScope.chrome !== 'undefined' &&
      globalScope.chrome.runtime &&
      globalScope.chrome.runtime.id &&
      globalScope.chrome.storage &&
      globalScope.chrome.storage.local &&
      globalScope.location &&
      globalScope.location.protocol === 'chrome-extension:';
    if (isDesktopChromeExt) return;
  } catch (_) {}

  globalScope.__pocketLeadsAndroidPolyfillLoaded = true;

  const EXT_ID = 'pocketleads-android-pro';
  const DEFAULT_MANIFEST = {"name": "PocketLeads", "description": "PocketLeads: assigned provider routing, common credits, recoverable scraping and a canonical IndexedDB dashboard.", "version": "10.18.5", "manifest_version": 3, "background": {"service_worker": "controllers/background.js"}, "action": {"default_icon": "assets/icons/icon32.png", "default_title": "PocketLeads Extractor"}, "icons": {"16": "assets/icons/icon16.png", "32": "assets/icons/icon32.png", "48": "assets/icons/icon48.png", "128": "assets/icons/icon.png"}, "permissions": ["tabs", "offscreen", "declarativeNetRequestWithHostAccess", "storage", "unlimitedStorage", "notifications", "contextMenus", "scripting", "alarms", "system.cpu", "system.memory", "system.storage"], "host_permissions": ["https://*.google.com/*", "https://*.google.co.in/*", "http://foxoyo.store/*", "https://foxoyo.store/*", "https://api.ipify.org/*", "https://script.google.com/*", "https://script.googleusercontent.com/*", "*://*.whatsapp.com/*", "https://wa.me/*", "<all_urls>", "https://*/*", "http://*/*"], "declarative_net_request": {"rule_resources": [{"id": "ghost_mode", "enabled": true, "path": "rules/ghost-mode.json"}]}, "content_scripts": [{"matches": ["*://*.whatsapp.com/*"], "js": ["whatsapp/inject.js"], "run_at": "document_start", "all_frames": true}], "web_accessible_resources": [{"resources": ["views/privacy.html", "views/terms.html"], "matches": ["<all_urls>"]}, {"resources": ["whatsapp/wa_preload.js", "whatsapp/wa.js", "whatsapp/api.js", "whatsapp/pageBridge.js"], "matches": ["*://*.whatsapp.com/*"]}], "version_name": "10.16.4 Single Navigation Ghost and Fast Start", "optional_host_permissions": ["<all_urls>"], "minimum_chrome_version": "109"};

  function getDynamicManifest() {
    try {
      if (!IS_WORKER && globalScope.AndroidChromeBridge && typeof globalScope.AndroidChromeBridge.getManifestJson === 'function') {
        const raw = globalScope.AndroidChromeBridge.getManifestJson();
        if (raw) return JSON.parse(raw);
      }
    } catch (_) {}
    return DEFAULT_MANIFEST;
  }

  const MANIFEST = getDynamicManifest();

  function getBaseOrigin() {
    try {
      if (globalScope.location && globalScope.location.origin && globalScope.location.origin !== 'null') {
        return globalScope.location.origin;
      }
    } catch (_) {}
    return 'https://pocketleads.local';
  }

  function resolveExtUrl(relPath) {
    const clean = String(relPath || '').replace(/^\/+/, '');
    return getBaseOrigin() + '/' + clean;
  }

  if (IS_WORKER && typeof globalScope.screen === 'undefined') {
    globalScope.screen = { width: 1280, height: 800, availWidth: 1280, availHeight: 800, colorDepth: 24, pixelDepth: 24 };
    globalScope.open = function() { return null; };
  }

  const pendingWorkerRpcs = new Map();
  let rpcCounter = 1;

  function hasNativeBridge() {
    return !IS_WORKER && typeof globalScope.AndroidChromeBridge !== 'undefined' && globalScope.AndroidChromeBridge !== null;
  }

  const STORAGE_KEY_PREFIX = '__pl_chrome_storage_local__';
  const storageCache = {};
  const storageChangeListeners = [];
  const runtimeMessageListeners = [];
  const alarmListeners = [];
  const activeAlarms = new Map();

  function loadInitialStorageCache() {
    if (IS_WORKER) return;
    try {
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.getAllStorageJson === 'function') {
        const raw = globalScope.AndroidChromeBridge.getAllStorageJson();
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed === 'object') {
            Object.assign(storageCache, parsed);
          }
        }
      }
    } catch (e) {
      console.warn('[PocketLeads-Android] Native storage init warning:', e);
    }
    try {
      const localRaw = globalScope.localStorage && globalScope.localStorage.getItem(STORAGE_KEY_PREFIX);
      if (localRaw) {
        const parsed = JSON.parse(localRaw);
        if (parsed && typeof parsed === 'object') {
          for (const k of Object.keys(parsed)) {
            if (!(k in storageCache)) storageCache[k] = parsed[k];
          }
        }
      }
    } catch (_) {}
  }
  loadInitialStorageCache();

  function persistStorageCache() {
    if (IS_WORKER) return;
    try {
      const serialized = JSON.stringify(storageCache);
      if (globalScope.localStorage) {
        globalScope.localStorage.setItem(STORAGE_KEY_PREFIX, serialized);
      }
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.saveAllStorageJson === 'function') {
        globalScope.AndroidChromeBridge.saveAllStorageJson(serialized);
      }
    } catch (e) {
      console.warn('[PocketLeads-Android] Failed to persist storage:', e);
    }
  }

  function fireStorageChanged(changes, areaName) {
    if (!changes || !Object.keys(changes).length) return;
    for (const fn of storageChangeListeners.slice()) {
      try { fn(changes, areaName || 'local'); } catch (e) { console.warn('storage.onChanged listener error', e); }
    }
  }

  function applyStorageWriteLocal(items, broadcastToPeer) {
    const changes = {};
    for (const [k, newVal] of Object.entries(items || {})) {
      const oldVal = storageCache[k];
      if (newVal === undefined) {
        delete storageCache[k];
      } else {
        storageCache[k] = newVal;
      }
      changes[k] = { oldValue: oldVal, newValue: newVal };
    }
    if (!IS_WORKER) {
      persistStorageCache();
      if (broadcastToPeer && globalScope.__plBgWorker) {
        try {
          globalScope.__plBgWorker.postMessage({ __plType: 'storage_sync', items, changes });
        } catch (_) {}
      }
    }
    fireStorageChanged(changes, 'local');
    return changes;
  }

  function applyStorageRemoveLocal(keys, broadcastToPeer) {
    const keyList = Array.isArray(keys) ? keys : [keys];
    const changes = {};
    for (const k of keyList) {
      if (k in storageCache) {
        changes[k] = { oldValue: storageCache[k], newValue: undefined };
        delete storageCache[k];
      }
    }
    if (!IS_WORKER) {
      persistStorageCache();
      if (broadcastToPeer && globalScope.__plBgWorker) {
        try {
          globalScope.__plBgWorker.postMessage({ __plType: 'storage_remove', keys: keyList, changes });
        } catch (_) {}
      }
    }
    fireStorageChanged(changes, 'local');
  }

  function readFromStorageCache(keys) {
    if (keys === null || keys === undefined) {
      return JSON.parse(JSON.stringify(storageCache));
    }
    if (typeof keys === 'string') {
      const res = {};
      if (keys in storageCache) res[keys] = JSON.parse(JSON.stringify(storageCache[keys]));
      return res;
    }
    if (Array.isArray(keys)) {
      const res = {};
      for (const k of keys) {
        if (k in storageCache) res[k] = JSON.parse(JSON.stringify(storageCache[k]));
      }
      return res;
    }
    if (typeof keys === 'object') {
      const res = {};
      for (const [k, defVal] of Object.entries(keys)) {
        res[k] = (k in storageCache) ? JSON.parse(JSON.stringify(storageCache[k])) : defVal;
      }
      return res;
    }
    return {};
  }

  function callMainThreadRpc(method, args) {
    if (!IS_WORKER) {
      return executeMainThreadRpc(method, args);
    }
    return new Promise((resolve, reject) => {
      const id = 'rpc_' + (rpcCounter++) + '_' + Date.now();
      pendingWorkerRpcs.set(id, { resolve, reject });
      globalScope.postMessage({ __plType: 'worker_rpc', id, method, args });
    });
  }

  const fallbackTabs = new Map();
  let fallbackTabCounter = 200;

  async function executeMainThreadRpc(method, args) {
    if (method === 'storage_get') {
      return readFromStorageCache(args[0]);
    }
    if (method === 'storage_set') {
      applyStorageWriteLocal(args[0] || {}, false);
      return true;
    }
    if (method === 'storage_remove') {
      applyStorageRemoveLocal(args[0], false);
      return true;
    }
    if (method === 'native_fetch') {
      const [url, httpMethod, headersObj, bodyStr, timeoutMs] = args;
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.nativeFetchAsync === 'function') {
        return new Promise((resolve) => {
          const cbId = 'fetch_' + (rpcCounter++) + '_' + Date.now();
          globalScope.__plNativeCallbacks.set(cbId, (resJson) => {
            try { resolve(JSON.parse(resJson)); }
            catch (_) { resolve({ ok: false, status: 0, error: 'Invalid native fetch JSON' }); }
          });
          globalScope.AndroidChromeBridge.nativeFetchAsync(
            String(url || ''),
            String(httpMethod || 'GET'),
            JSON.stringify(headersObj || {}),
            bodyStr == null ? '' : String(bodyStr),
            Number(timeoutMs || 25000),
            cbId
          );
        });
      }
      throw new Error('Native fetch unavailable outside APK');
    }
    if (method === 'tabs_create') {
      const props = args[0] || {};
      const url = String(props.url || 'about:blank');
      if (url.includes('/views/index.html')) {
        if (!globalScope.location.pathname.endsWith('/views/index.html')) {
          globalScope.location.href = resolveExtUrl('views/index.html');
        }
        return { id: 1, url: resolveExtUrl('views/index.html'), active: true, status: 'complete' };
      }
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.createTab === 'function') {
        const tabJson = globalScope.AndroidChromeBridge.createTab(url, !!props.active);
        return JSON.parse(tabJson);
      }
      const tabId = ++fallbackTabCounter;
      const tabObj = { id: tabId, url, active: !!props.active, status: 'complete' };
      fallbackTabs.set(tabId, tabObj);
      return tabObj;
    }
    if (method === 'tabs_get') {
      const tabId = Number(args[0]);
      if (tabId === 1) {
        return { id: 1, url: globalScope.location.href, active: true, status: 'complete' };
      }
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.getTab === 'function') {
        const tabJson = globalScope.AndroidChromeBridge.getTab(tabId);
        return tabJson ? JSON.parse(tabJson) : null;
      }
      return fallbackTabs.get(tabId) || null;
    }
    if (method === 'tabs_update') {
      const tabId = Number(args[0]);
      const updateProps = args[1] || {};
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.updateTab === 'function') {
        const tabJson = globalScope.AndroidChromeBridge.updateTab(tabId, JSON.stringify(updateProps));
        return tabJson ? JSON.parse(tabJson) : null;
      }
      const existing = fallbackTabs.get(tabId);
      if (existing) {
        if (updateProps.url) existing.url = updateProps.url;
        if (typeof updateProps.active === 'boolean') existing.active = updateProps.active;
        return existing;
      }
      return { id: tabId, url: updateProps.url || '', active: !!updateProps.active, status: 'complete' };
    }
    if (method === 'tabs_remove') {
      const tabId = Number(args[0]);
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.removeTab === 'function') {
        globalScope.AndroidChromeBridge.removeTab(tabId);
        return true;
      }
      fallbackTabs.delete(tabId);
      return true;
    }
    if (method === 'tabs_reload') {
      const tabId = Number(args[0]);
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.reloadTab === 'function') {
        globalScope.AndroidChromeBridge.reloadTab(tabId);
        return true;
      }
      return true;
    }
    if (method === 'tabs_query') {
      const queryInfo = args[0] || {};
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.queryTabs === 'function') {
        const listJson = globalScope.AndroidChromeBridge.queryTabs(JSON.stringify(queryInfo));
        return listJson ? JSON.parse(listJson) : [];
      }
      const all = [{ id: 1, url: globalScope.location.href, active: true, status: 'complete' }, ...fallbackTabs.values()];
      return all;
    }
    if (method === 'tabs_send_message') {
      const tabId = Number(args[0]);
      const message = args[1];
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.sendMessageToTab === 'function') {
        return new Promise((resolve) => {
          const cbId = 'tabmsg_' + (rpcCounter++) + '_' + Date.now();
          globalScope.__plNativeCallbacks.set(cbId, (resJson) => {
            try { resolve(resJson ? JSON.parse(resJson) : undefined); } catch (_) { resolve(undefined); }
          });
          globalScope.AndroidChromeBridge.sendMessageToTab(tabId, JSON.stringify(message), cbId);
        });
      }
      return undefined;
    }
    if (method === 'scripting_execute') {
      const opts = args[0] || {};
      const tabId = opts.target && opts.target.tabId;
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.executeScriptInTab === 'function') {
        return new Promise((resolve) => {
          const cbId = 'exec_' + (rpcCounter++) + '_' + Date.now();
          globalScope.__plNativeCallbacks.set(cbId, (resJson) => {
            try {
              const parsed = (resJson && resJson !== 'undefined') ? JSON.parse(resJson) : null;
              resolve([{ result: parsed }]);
            } catch (_) {
              resolve([{ result: null }]);
            }
          });
          globalScope.AndroidChromeBridge.executeScriptInTab(
            Number(tabId || 0),
            opts.funcSource || '',
            JSON.stringify(opts.args || []),
            JSON.stringify(opts.files || []),
            cbId
          );
        });
      }
      return [{ result: null }];
    }
    if (method === 'notify_create') {
      const notifId = String(args[0] || '');
      const opts = args[1] || {};
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.showNotification === 'function') {
        globalScope.AndroidChromeBridge.showNotification(notifId, String(opts.title || 'PocketLeads'), String(opts.message || ''));
      }
      return notifId;
    }
    return null;
  }

  if (!IS_WORKER) {
    globalScope.__plNativeCallbacks = new Map();
    globalScope.__onAndroidBridgeCallback = function(cbId, payloadJson) {
      const fn = globalScope.__plNativeCallbacks.get(cbId);
      if (fn) {
        globalScope.__plNativeCallbacks.delete(cbId);
        try { fn(payloadJson); } catch (e) { console.warn('Native callback error:', e); }
      }
    };
  }

  if (typeof globalScope.fetch === 'function') {
    const origFetch = globalScope.fetch.bind(globalScope);
    globalScope.fetch = async function(input, init) {
      const rawUrl = (typeof input === 'string') ? input : (input && input.url ? input.url : String(input));
      const isExternal = /^https?:\/\//i.test(rawUrl) && !rawUrl.startsWith(getBaseOrigin());
      try {
        return await origFetch(input, init);
      } catch (fetchErr) {
        if (!isExternal) throw fetchErr;
        try {
          const method = (init && init.method) ? String(init.method).toUpperCase() : 'GET';
          const headers = (init && init.headers) ? init.headers : {};
          const body = (init && typeof init.body === 'string') ? init.body : '';
          const nat = await callMainThreadRpc('native_fetch', [rawUrl, method, headers, body, 20000]);
          if (nat && nat.status > 0) {
            const textBody = String(nat.body || '');
            return {
              ok: nat.status >= 200 && nat.status < 300,
              status: nat.status,
              url: nat.finalUrl || rawUrl,
              text: async () => textBody,
              json: async () => JSON.parse(textBody)
            };
          }
        } catch (_) {}
        throw fetchErr;
      }
    };
  }

  const pendingRuntimeReplies = new Map();

  function dispatchRuntimeMessageLocally(message, sender) {
    let handledAsync = false;
    let responded = false;
    return new Promise((resolve) => {
      const sendResponse = (replyPayload) => {
        if (responded) return;
        responded = true;
        resolve({ responded: true, payload: replyPayload });
      };
      for (const listener of runtimeMessageListeners.slice()) {
        try {
          const ret = listener(message, sender, sendResponse);
          if (ret === true) {
            handledAsync = true;
          } else if (ret && typeof ret.then === 'function') {
            handledAsync = true;
            ret.then(sendResponse).catch(() => sendResponse(undefined));
          }
        } catch (err) {
          console.warn('[PocketLeads-Android] runtime.onMessage listener error:', err);
        }
      }
      if (!handledAsync && !responded) {
        resolve({ responded: false, payload: undefined });
      } else if (handledAsync && !responded) {
        setTimeout(() => {
          if (!responded) resolve({ responded: false, payload: undefined });
        }, 65000);
      }
    });
  }

  const chromeObj = {};

  chromeObj.runtime = {
    id: EXT_ID,
    lastError: null,
    getManifest: function() {
      return MANIFEST;
    },
    getURL: function(path) {
      return resolveExtUrl(path);
    },
    getPlatformInfo: function(cb) {
      const info = { os: 'android', arch: 'arm64', nacl_arch: 'arm' };
      if (typeof cb === 'function') setTimeout(() => cb(info), 0);
      return Promise.resolve(info);
    },
    getContexts: function() {
      return Promise.resolve([]);
    },
    onInstalled: {
      addListener: function() {}
    },
    setUninstallURL: function() {},
    onMessage: {
      addListener: function(fn) {
        if (typeof fn === 'function' && !runtimeMessageListeners.includes(fn)) {
          runtimeMessageListeners.push(fn);
        }
      },
      removeListener: function(fn) {
        const idx = runtimeMessageListeners.indexOf(fn);
        if (idx >= 0) runtimeMessageListeners.splice(idx, 1);
      }
    },
    sendMessage: function(message, arg2, arg3) {
      let callback = null;
      if (typeof arg2 === 'function') callback = arg2;
      else if (typeof arg3 === 'function') callback = arg3;

      const sender = {
        id: EXT_ID,
        url: globalScope.location ? globalScope.location.href : resolveExtUrl('views/index.html'),
        tab: { id: 1, url: globalScope.location ? globalScope.location.href : resolveExtUrl('views/index.html'), active: true }
      };

      return new Promise((resolve) => {
        const finish = (reply) => {
          chromeObj.runtime.lastError = null;
          if (typeof callback === 'function') {
            try { callback(reply); } catch (e) { console.warn('sendMessage callback error', e); }
          }
          resolve(reply);
        };

        if (IS_WORKER) {
          dispatchRuntimeMessageLocally(message, sender).then(localRes => {
            const msgId = 'rtm_' + (rpcCounter++) + '_' + Date.now();
            pendingRuntimeReplies.set(msgId, (uiReply) => {
              finish(localRes.responded ? localRes.payload : uiReply);
            });
            globalScope.postMessage({ __plType: 'runtime_message', id: msgId, message, sender });
          });
        } else {
          if (globalScope.__plBgWorker) {
            const msgId = 'rtm_' + (rpcCounter++) + '_' + Date.now();
            pendingRuntimeReplies.set(msgId, (workerReply) => {
              finish(workerReply);
            });
            globalScope.__plBgWorker.postMessage({ __plType: 'runtime_message', id: msgId, message, sender });
          } else {
            dispatchRuntimeMessageLocally(message, sender).then(res => finish(res.payload));
          }
        }
      });
    }
  };

  chromeObj.extension = {
    getBackgroundPage: function() { return undefined; },
    getURL: chromeObj.runtime.getURL
  };

  chromeObj.action = {
    onClicked: { addListener: function() {} },
    setBadgeText: function() {}
  };
  chromeObj.browserAction = chromeObj.action;

  chromeObj.storage = {
    local: {
      get: function(keys, cb) {
        const p = IS_WORKER
          ? callMainThreadRpc('storage_get', [keys])
          : Promise.resolve(readFromStorageCache(keys));
        p.then(res => {
          chromeObj.runtime.lastError = null;
          if (typeof cb === 'function') cb(res);
        });
        return p;
      },
      set: function(items, cb) {
        const p = IS_WORKER
          ? callMainThreadRpc('storage_set', [items]).then(() => { applyStorageWriteLocal(items, false); })
          : Promise.resolve().then(() => { applyStorageWriteLocal(items, true); });
        p.then(() => {
          chromeObj.runtime.lastError = null;
          if (typeof cb === 'function') cb();
        });
        return p;
      },
      remove: function(keys, cb) {
        const p = IS_WORKER
          ? callMainThreadRpc('storage_remove', [keys]).then(() => { applyStorageRemoveLocal(keys, false); })
          : Promise.resolve().then(() => { applyStorageRemoveLocal(keys, true); });
        p.then(() => {
          chromeObj.runtime.lastError = null;
          if (typeof cb === 'function') cb();
        });
        return p;
      },
      clear: function(cb) {
        const allKeys = Object.keys(storageCache);
        return chromeObj.storage.local.remove(allKeys, cb);
      }
    },
    session: {
      get: function(keys, cb) { return chromeObj.storage.local.get(keys, cb); },
      set: function(items, cb) { return chromeObj.storage.local.set(items, cb); },
      remove: function(keys, cb) { return chromeObj.storage.local.remove(keys, cb); }
    },
    onChanged: {
      addListener: function(fn) {
        if (typeof fn === 'function' && !storageChangeListeners.includes(fn)) {
          storageChangeListeners.push(fn);
        }
      },
      removeListener: function(fn) {
        const i = storageChangeListeners.indexOf(fn);
        if (i >= 0) storageChangeListeners.splice(i, 1);
      }
    }
  };

  chromeObj.tabs = {
    create: function(createProps, cb) {
      const p = callMainThreadRpc('tabs_create', [createProps || {}]);
      p.then(tab => { if (typeof cb === 'function') cb(tab); });
      return p;
    },
    get: function(tabId, cb) {
      const p = callMainThreadRpc('tabs_get', [tabId]);
      p.then(tab => { if (typeof cb === 'function') cb(tab); });
      return p;
    },
    update: function(tabId, updateProps, cb) {
      const p = callMainThreadRpc('tabs_update', [tabId, updateProps || {}]);
      p.then(tab => { if (typeof cb === 'function') cb(tab); });
      return p;
    },
    remove: function(tabIds, cb) {
      const id = Array.isArray(tabIds) ? tabIds[0] : tabIds;
      const p = callMainThreadRpc('tabs_remove', [id]);
      p.then(() => { if (typeof cb === 'function') cb(); });
      return p;
    },
    reload: function(tabId, reloadProps, cb) {
      const callback = typeof reloadProps === 'function' ? reloadProps : cb;
      const p = callMainThreadRpc('tabs_reload', [tabId]);
      p.then(() => { if (typeof callback === 'function') callback(); });
      return p;
    },
    query: function(queryInfo, cb) {
      const p = callMainThreadRpc('tabs_query', [queryInfo || {}]);
      p.then(tabs => { if (typeof cb === 'function') cb(tabs || []); });
      return p;
    },
    sendMessage: function(tabId, message, optionsOrCb, cb) {
      const callback = typeof optionsOrCb === 'function' ? optionsOrCb : cb;
      const p = callMainThreadRpc('tabs_send_message', [tabId, message]);
      p.then(res => { if (typeof callback === 'function') callback(res); });
      return p;
    }
  };

  const registeredContentScripts = new Map();
  chromeObj.scripting = {
    executeScript: function(options, cb) {
      const payload = {
        target: options && options.target || {},
        funcSource: (options && typeof options.func === 'function') ? options.func.toString() : '',
        args: (options && Array.isArray(options.args)) ? options.args : [],
        files: (options && Array.isArray(options.files)) ? options.files : [],
        world: (options && options.world) || 'MAIN'
      };
      const p = callMainThreadRpc('scripting_execute', [payload]);
      p.then(res => { if (typeof cb === 'function') cb(res); });
      return p;
    },
    registerContentScripts: function(scripts, cb) {
      for (const s of (scripts || [])) {
        if (s && s.id) registeredContentScripts.set(s.id, s);
      }
      if (typeof cb === 'function') cb();
      return Promise.resolve();
    },
    getRegisteredContentScripts: function(filter, cb) {
      const list = [...registeredContentScripts.values()];
      if (typeof cb === 'function') cb(list);
      return Promise.resolve(list);
    },
    unregisterContentScripts: function(filter, cb) {
      if (filter && Array.isArray(filter.ids)) {
        for (const id of filter.ids) registeredContentScripts.delete(id);
      } else {
        registeredContentScripts.clear();
      }
      if (typeof cb === 'function') cb();
      return Promise.resolve();
    }
  };

  chromeObj.offscreen = {
    hasDocument: function() { return Promise.resolve(true); },
    createDocument: function() { return Promise.resolve(); },
    closeDocument: function() { return Promise.resolve(); }
  };

  chromeObj.alarms = {
    create: function(name, alarmInfo) {
      const alarmName = typeof name === 'string' ? name : 'default_alarm';
      const info = (typeof name === 'object' ? name : alarmInfo) || { periodInMinutes: 1 };
      if (activeAlarms.has(alarmName)) clearInterval(activeAlarms.get(alarmName));
      const periodMs = Math.max(15000, Number(info.periodInMinutes || 1) * 60000);
      const timer = setInterval(() => {
        for (const fn of alarmListeners.slice()) {
          try { fn({ name: alarmName }); } catch (_) {}
        }
      }, periodMs);
      activeAlarms.set(alarmName, timer);
    },
    onAlarm: {
      addListener: function(fn) {
        if (typeof fn === 'function' && !alarmListeners.includes(fn)) alarmListeners.push(fn);
      }
    },
    clear: function(name, cb) {
      if (activeAlarms.has(name)) {
        clearInterval(activeAlarms.get(name));
        activeAlarms.delete(name);
      }
      if (typeof cb === 'function') cb(true);
      return Promise.resolve(true);
    }
  };

  chromeObj.notifications = {
    create: function(idOrOpts, optsOrCb, maybeCb) {
      let id = typeof idOrOpts === 'string' ? idOrOpts : ('notif_' + Date.now());
      let opts = typeof idOrOpts === 'object' ? idOrOpts : (optsOrCb || {});
      let cb = typeof optsOrCb === 'function' ? optsOrCb : maybeCb;
      callMainThreadRpc('notify_create', [id, opts]).then(() => {
        if (typeof cb === 'function') cb(id);
      });
    },
    clear: function(id, cb) {
      if (typeof cb === 'function') cb(true);
    }
  };

  chromeObj.system = {
    cpu: {
      getInfo: function(cb) {
        const info = { numOfProcessors: 8, archName: 'arm64', modelName: 'Android ARMv8 Processor', features: ['neon'] };
        if (typeof cb === 'function') setTimeout(() => cb(info), 0);
      }
    },
    memory: {
      getInfo: function(cb) {
        const info = { capacity: 8589934592, availableCapacity: 4294967296 };
        if (typeof cb === 'function') setTimeout(() => cb(info), 0);
      }
    },
    storage: {
      getInfo: function(cb) {
        const info = [{ id: 'android-internal', name: 'Internal Storage', type: 'fixed', capacity: 137438953472 }];
        if (typeof cb === 'function') setTimeout(() => cb(info), 0);
      }
    }
  };

  chromeObj.permissions = {
    contains: function(perms, cb) {
      if (typeof cb === 'function') cb(true);
      return Promise.resolve(true);
    },
    request: function(perms, cb) {
      if (typeof cb === 'function') cb(true);
      return Promise.resolve(true);
    }
  };

  chromeObj.contextMenus = {
    create: function() {},
    onClicked: { addListener: function() {} }
  };

  chromeObj.windows = {
    create: function(props, cb) {
      if (props && props.url) {
        globalScope.location.href = props.url;
      }
      if (typeof cb === 'function') cb({ id: 1 });
    }
  };

  try {
    Object.defineProperty(globalScope, 'chrome', {
      value: chromeObj,
      writable: true,
      configurable: true
    });
  } catch (_) {
    globalScope.chrome = chromeObj;
  }

  if (!IS_WORKER && typeof globalScope.URL !== 'undefined' && typeof globalScope.HTMLAnchorElement !== 'undefined') {
    const blobStore = new Map();
    const origCreateObjectURL = globalScope.URL.createObjectURL.bind(globalScope.URL);
    globalScope.URL.createObjectURL = function(obj) {
      const url = origCreateObjectURL(obj);
      if (obj instanceof Blob) {
        blobStore.set(url, obj);
      }
      return url;
    };

    const origAnchorClick = globalScope.HTMLAnchorElement.prototype.click;
    globalScope.HTMLAnchorElement.prototype.click = function() {
      const href = String(this.href || '');
      const downloadName = this.getAttribute('download') || this.download;
      if (href.startsWith('blob:') && downloadName && hasNativeBridge() && typeof globalScope.AndroidChromeBridge.saveDownloadedFile === 'function') {
        const blob = blobStore.get(href);
        if (blob) {
          const reader = new FileReader();
          reader.onloadend = function() {
            const dataUrl = String(reader.result || '');
            const base64Idx = dataUrl.indexOf('base64,');
            const base64Data = base64Idx >= 0 ? dataUrl.slice(base64Idx + 7) : '';
            globalScope.AndroidChromeBridge.saveDownloadedFile(
              String(downloadName),
              String(blob.type || 'text/csv'),
              base64Data
            );
          };
          reader.readAsDataURL(blob);
          return;
        }
      }
      return origAnchorClick.apply(this, arguments);
    };
  }

  if (!IS_WORKER) {
    try {
      const workerUrl = resolveExtUrl('android-bg-worker.js');
      const bgWorker = new Worker(workerUrl);
      globalScope.__plBgWorker = bgWorker;

      bgWorker.postMessage({ __plType: 'storage_init', items: storageCache });

      bgWorker.addEventListener('message', (event) => {
        const data = event && event.data;
        if (!data || typeof data !== 'object') return;

        if (data.__plType === 'worker_rpc') {
          executeMainThreadRpc(data.method, data.args || [])
            .then(result => {
              bgWorker.postMessage({ __plType: 'worker_rpc_reply', id: data.id, ok: true, result });
            })
            .catch(err => {
              bgWorker.postMessage({ __plType: 'worker_rpc_reply', id: data.id, ok: false, error: String(err && err.message || err) });
            });
          return;
        }

        if (data.__plType === 'runtime_message') {
          dispatchRuntimeMessageLocally(data.message, data.sender).then(res => {
            bgWorker.postMessage({ __plType: 'runtime_reply', id: data.id, payload: res.payload });
          });
          return;
        }

        if (data.__plType === 'runtime_reply') {
          const cb = pendingRuntimeReplies.get(data.id);
          if (cb) {
            pendingRuntimeReplies.delete(data.id);
            cb(data.payload);
          }
          return;
        }
      });
    } catch (workerErr) {
      console.error('[PocketLeads-Android] Failed to start background worker:', workerErr);
    }
  } else {
    globalScope.addEventListener('message', (event) => {
      const data = event && event.data;
      if (!data || typeof data !== 'object') return;

      if (data.__plType === 'storage_init') {
        Object.assign(storageCache, data.items || {});
        return;
      }
      if (data.__plType === 'storage_sync') {
        Object.assign(storageCache, data.items || {});
        fireStorageChanged(data.changes || {}, 'local');
        return;
      }
      if (data.__plType === 'storage_remove') {
        for (const k of (data.keys || [])) delete storageCache[k];
        fireStorageChanged(data.changes || {}, 'local');
        return;
      }
      if (data.__plType === 'worker_rpc_reply') {
        const entry = pendingWorkerRpcs.get(data.id);
        if (entry) {
          pendingWorkerRpcs.delete(data.id);
          if (data.ok) entry.resolve(data.result);
          else entry.reject(new Error(data.error || 'Worker RPC failed'));
        }
        return;
      }
      if (data.__plType === 'runtime_message') {
        dispatchRuntimeMessageLocally(data.message, data.sender).then(res => {
          globalScope.postMessage({ __plType: 'runtime_reply', id: data.id, payload: res.payload });
        });
        return;
      }
      if (data.__plType === 'runtime_reply') {
        const cb = pendingRuntimeReplies.get(data.id);
        if (cb) {
          pendingRuntimeReplies.delete(data.id);
          cb(data.payload);
        }
        return;
      }
    });
  }
})(typeof self !== 'undefined' ? self : window);
