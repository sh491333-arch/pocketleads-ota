/*
 * PocketLeads PRO Android Native Runtime Polyfill & In-Process Engine (v5)
 * - In Desktop Chrome (chrome://extensions): Detects native Chrome MV3 environment and exits cleanly.
 * - In Android APK (https://pocketleads.local): Emulates all Chrome MV3 APIs directly in-process on
 *   the Main Thread with ZERO Web Worker dependency, 0ms message dispatch, and direct Native Bridge access.
 */
(function(globalScope) {
  'use strict';
  if (globalScope.__pocketLeadsAndroidPolyfillV5Loaded) return;

  try {
    const isDesktopChromeExt = !globalScope.AndroidChromeBridge &&
      typeof globalScope.chrome !== 'undefined' &&
      globalScope.chrome.runtime &&
      globalScope.chrome.runtime.id &&
      globalScope.chrome.runtime.id !== 'pocketleads-android-pro' &&
      globalScope.chrome.storage &&
      globalScope.chrome.storage.local &&
      globalScope.chrome.storage.local.onChanged &&
      globalScope.location &&
      globalScope.location.protocol === 'chrome-extension:';
    if (isDesktopChromeExt) return;
  } catch (_) {}

  globalScope.__pocketLeadsAndroidPolyfillLoaded = true;
  globalScope.__pocketLeadsAndroidPolyfillV2Loaded = true;
  globalScope.__pocketLeadsAndroidPolyfillV3Loaded = true;
  globalScope.__pocketLeadsAndroidPolyfillV4Loaded = true;
  globalScope.__pocketLeadsAndroidPolyfillV5Loaded = true;
  globalScope.__plInProcessAndroid = true;

  if (globalScope.__plBgWorker) {
    try { globalScope.__plBgWorker.terminate(); } catch (_) {}
    globalScope.__plBgWorker = null;
  }

  if (typeof globalScope.importScripts !== 'function') {
    globalScope.importScripts = function() {};
  }

  const EXT_ID = 'pocketleads-android-pro';
  const DEFAULT_MANIFEST = {"name": "PocketLeads", "description": "PocketLeads: assigned provider routing, common credits, recoverable scraping and a canonical IndexedDB dashboard.", "version": "10.18.5", "manifest_version": 3, "background": {"service_worker": "controllers/background.js"}, "action": {"default_icon": "assets/icons/icon32.png", "default_title": "PocketLeads Extractor"}, "icons": {"16": "assets/icons/icon16.png", "32": "assets/icons/icon32.png", "48": "assets/icons/icon48.png", "128": "assets/icons/icon.png"}, "permissions": ["tabs", "offscreen", "declarativeNetRequestWithHostAccess", "storage", "unlimitedStorage", "notifications", "contextMenus", "scripting", "alarms", "system.cpu", "system.memory", "system.storage"], "host_permissions": ["https://*.google.com/*", "https://*.google.co.in/*", "http://foxoyo.store/*", "https://foxoyo.store/*", "https://api.ipify.org/*", "https://script.google.com/*", "https://script.googleusercontent.com/*", "*://*.whatsapp.com/*", "https://wa.me/*", "<all_urls>", "https://*/*", "http://*/*"], "declarative_net_request": {"rule_resources": [{"id": "ghost_mode", "enabled": true, "path": "rules/ghost-mode.json"}]}, "content_scripts": [{"matches": ["*://*.whatsapp.com/*"], "js": ["whatsapp/inject.js"], "run_at": "document_start", "all_frames": true}], "web_accessible_resources": [{"resources": ["views/privacy.html", "views/terms.html"], "matches": ["<all_urls>"]}, {"resources": ["whatsapp/wa_preload.js", "whatsapp/wa.js", "whatsapp/api.js", "whatsapp/pageBridge.js"], "matches": ["*://*.whatsapp.com/*"]}], "version_name": "10.16.4 Single Navigation Ghost and Fast Start", "optional_host_permissions": ["<all_urls>"], "minimum_chrome_version": "109"};

  function getDynamicManifest() {
    try {
      if (globalScope.AndroidChromeBridge && typeof globalScope.AndroidChromeBridge.getManifestJson === 'function') {
        const raw = globalScope.AndroidChromeBridge.getManifestJson();
        if (raw) return JSON.parse(raw);
      }
    } catch (_) {}
    return DEFAULT_MANIFEST;
  }

  const MANIFEST = getDynamicManifest();

  function getBaseOrigin() {
    try {
      if (globalScope.location && globalScope.location.origin && globalScope.location.origin !== 'null') {
        return globalScope.location.origin;
      }
    } catch (_) {}
    return 'https://pocketleads.local';
  }

  function resolveExtUrl(relPath) {
    const clean = String(relPath || '').replace(/^\/+/, '');
    return getBaseOrigin() + '/' + clean;
  }

  let rpcCounter = 1;

  function hasNativeBridge() {
    return typeof globalScope.AndroidChromeBridge !== 'undefined' && globalScope.AndroidChromeBridge !== null;
  }

  const STORAGE_KEY_PREFIX = '__pl_chrome_storage_local__';
  const storageCache = {};
  const storageChangeListeners = [];
  const runtimeMessageListeners = [];
  const alarmListeners = [];
  const activeAlarms = new Map();

  function loadInitialStorageCache() {
    try {
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.getAllStorageJson === 'function') {
        const raw = globalScope.AndroidChromeBridge.getAllStorageJson();
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed === 'object') {
            Object.assign(storageCache, parsed);
          }
        }
      }
    } catch (e) {
      console.warn('[PocketLeads-Android] Native storage init warning:', e);
    }
    try {
      const localRaw = globalScope.localStorage && globalScope.localStorage.getItem(STORAGE_KEY_PREFIX);
      if (localRaw) {
        const parsed = JSON.parse(localRaw);
        if (parsed && typeof parsed === 'object') {
          for (const k of Object.keys(parsed)) {
            if (!(k in storageCache)) storageCache[k] = parsed[k];
          }
        }
      }
    } catch (_) {}

    if (!storageCache.privacyAcceptance) {
      storageCache.privacyAcceptance = {
        accepted: true,
        acceptedAt: new Date().toISOString(),
        policyVersion: '2025-10-23',
        extensionVersion: (MANIFEST && MANIFEST.version) || '10.18.5'
      };
    }

  }
  loadInitialStorageCache();

  if (typeof document !== 'undefined') {
    try {
      const injectNgHideGuard = function() {
        const target = document.head || document.documentElement;
        if (!target || document.getElementById('pl-android-ng-hide-guard')) return;
        const styleEl = document.createElement('style');
        styleEl.id = 'pl-android-ng-hide-guard';
        // Only hide .ng-hide! Never hide [ng-cloak] via !important so body is never stuck blurred/blank!
        styleEl.textContent = '.ng-hide { display: none !important; }';
        target.appendChild(styleEl);
      };
      injectNgHideGuard();
      document.addEventListener('DOMContentLoaded', injectNgHideGuard);
    } catch (_) {}

    const healDashboardAndViewMode = function() {
      try {
        if (!document.body) return;
        // 1. Remove ng-cloak from body and all elements so nothing stays hidden behind the blurred backdrop
        document.body.removeAttribute('ng-cloak');
        document.body.classList.remove('ng-cloak');
        const cloaked = document.querySelectorAll('[ng-cloak], .ng-cloak');
        for (let i = 0; i < cloaked.length; i++) {
          cloaked[i].removeAttribute('ng-cloak');
          cloaked[i].classList.remove('ng-cloak');
        }

        // 2. Detect whether this extension ZIP has .pl-mobile-shell (newer ZIPs) or not (older ZIPs)
        const mobileShell = document.querySelector('.pl-mobile-shell');
        if (!mobileShell) {
          // Older extension ZIP without .pl-mobile-shell: use desktop mode so main dashboard is visible
          document.documentElement.setAttribute('data-view-mode', 'desktop');
          document.body.setAttribute('data-view-mode', 'desktop');
        } else {
          const savedMode = (globalScope.localStorage && globalScope.localStorage.getItem('pocketleads_view_mode')) || 'mobile';
          document.documentElement.setAttribute('data-view-mode', savedMode);
          document.body.setAttribute('data-view-mode', savedMode);
          if (savedMode === 'mobile') {
            const panes = mobileShell.querySelectorAll('.pl-m-tab-pane');
            if (panes.length > 0) {
              let anyVisible = false;
              for (let i = 0; i < panes.length; i++) {
                if (!panes[i].classList.contains('ng-hide') && panes[i].style.display !== 'none') {
                  anyVisible = true;
                  break;
                }
              }
              if (!anyVisible) {
                panes[0].classList.remove('ng-hide');
                panes[0].style.display = '';
              }
            }
          }
        }

        // 3. Ensure .app-container and .main-content are never stuck in .ng-hide (older ZIPs with activeTab=='login')
        const mainContainers = document.querySelectorAll('.app-container, .main-content');
        for (let i = 0; i < mainContainers.length; i++) {
          if (mainContainers[i].classList.contains('ng-hide')) {
            mainContainers[i].classList.remove('ng-hide');
          }
          if (mainContainers[i].style.display === 'none') {
            mainContainers[i].style.display = '';
          }
        }

        // 4. Sync Angular scope if available
        if (globalScope.angular && typeof globalScope.angular.element === 'function') {
          const ctrlEl = document.querySelector('[ng-controller]') || document.body;
          const scope = globalScope.angular.element(ctrlEl).scope();
          if (scope) {
            let changed = false;
            if (scope.local && (!scope.local.activeTab || scope.local.activeTab === 'login')) {
              scope.local.activeTab = 'home';
              changed = true;
            }
            if (mobileShell && !scope.mobileTab) {
              scope.mobileTab = 'home';
              changed = true;
            }
            if (storageCache.license && storageCache.license.active && !scope.licenseActive) {
              scope.licenseActive = true;
              changed = true;
            }
            if (changed && typeof scope.$applyAsync === 'function') {
              scope.$applyAsync();
            }
          }
        }
      } catch (_) {}
    };
    document.addEventListener('DOMContentLoaded', function() {
      healDashboardAndViewMode();
      setTimeout(healDashboardAndViewMode, 150);
      setTimeout(healDashboardAndViewMode, 500);
      setTimeout(healDashboardAndViewMode, 1200);
    });
    setInterval(healDashboardAndViewMode, 600);

    const installAngularSafeApply = function() {
      try {
        if (!globalScope.angular || !globalScope.angular.module) return false;
        const origModule = globalScope.angular.module;
        if (!origModule.__plSafeApplyPatched) {
          const wrappedModule = function(name, requires, configFn) {
            const mod = origModule.apply(this, arguments);
            if (requires && mod && typeof mod.config === 'function' && !mod.__plSafeApplyConfigured) {
              mod.__plSafeApplyConfigured = true;
              mod.config(['$provide', function($provide) {
                $provide.decorator('$rootScope', ['$delegate', function($delegate) {
                  const origApply = $delegate.$apply;
                  $delegate.$apply = function(fn) {
                    const phase = this.$root && this.$root.$$phase;
                    if (phase === '$apply' || phase === '$digest') {
                      if (fn) {
                        try { return this.$eval(fn); } catch (e) { console.warn('[PocketLeads-Android] safe $eval warning:', e); }
                      }
                      return;
                    }
                    return origApply.apply(this, arguments);
                  };
                  return $delegate;
                }]);
              }]);
            }
            return mod;
          };
          Object.assign(wrappedModule, origModule);
          wrappedModule.__plSafeApplyPatched = true;
          globalScope.angular.module = wrappedModule;
        }
        return true;
      } catch (_) {
        return false;
      }
    };
    installAngularSafeApply();
    const ngPoll = setInterval(function() {
      if (installAngularSafeApply()) clearInterval(ngPoll);
    }, 5);
    setTimeout(function() { clearInterval(ngPoll); }, 10000);
  }

  function persistStorageCache() {
    try {
      const serialized = JSON.stringify(storageCache);
      if (globalScope.localStorage) {
        globalScope.localStorage.setItem(STORAGE_KEY_PREFIX, serialized);
      }
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.saveAllStorageJson === 'function') {
        globalScope.AndroidChromeBridge.saveAllStorageJson(serialized);
      }
    } catch (e) {
      console.warn('[PocketLeads-Android] Failed to persist storage:', e);
    }
  }

  function fireStorageChanged(changes, areaName) {
    if (!changes || !Object.keys(changes).length) return;
    setTimeout(() => {
      for (const fn of storageChangeListeners.slice()) {
        try { fn(changes, areaName || 'local'); } catch (e) { console.warn('storage.onChanged listener error', e); }
      }
    }, 0);
  }

  function applyStorageWriteLocal(items) {
    const changes = {};
    for (const [k, newVal] of Object.entries(items || {})) {
      const oldVal = storageCache[k];
      if (newVal === undefined) {
        delete storageCache[k];
      } else {
        try {
          storageCache[k] = JSON.parse(JSON.stringify(newVal));
        } catch (_) {
          storageCache[k] = newVal;
        }
      }
      changes[k] = { oldValue: oldVal, newValue: storageCache[k] };
    }
    persistStorageCache();
    fireStorageChanged(changes, 'local');
    return changes;
  }

  function applyStorageRemoveLocal(keys) {
    const keyList = Array.isArray(keys) ? keys : [keys];
    const changes = {};
    for (const k of keyList) {
      if (k in storageCache) {
        changes[k] = { oldValue: storageCache[k], newValue: undefined };
        delete storageCache[k];
      }
    }
    persistStorageCache();
    fireStorageChanged(changes, 'local');
  }

  function readFromStorageCache(keys) {
    if (keys === null || keys === undefined) {
      return JSON.parse(JSON.stringify(storageCache));
    }
    if (typeof keys === 'string') {
      const res = {};
      if (keys in storageCache) res[keys] = JSON.parse(JSON.stringify(storageCache[keys]));
      return res;
    }
    if (Array.isArray(keys)) {
      const res = {};
      for (const k of keys) {
        if (k in storageCache) res[k] = JSON.parse(JSON.stringify(storageCache[k]));
      }
      return res;
    }
    if (typeof keys === 'object') {
      const res = {};
      for (const [k, defVal] of Object.entries(keys)) {
        res[k] = (k in storageCache) ? JSON.parse(JSON.stringify(storageCache[k])) : defVal;
      }
      return res;
    }
    return {};
  }

  const fallbackTabs = new Map();
  let fallbackTabCounter = 200;

  async function executeMainThreadRpc(method, args) {
    if (method === 'storage_get') {
      return readFromStorageCache(args[0]);
    }
    if (method === 'storage_set') {
      applyStorageWriteLocal(args[0] || {});
      return true;
    }
    if (method === 'storage_remove') {
      applyStorageRemoveLocal(args[0]);
      return true;
    }
    if (method === 'native_fetch') {
      const [url, httpMethod, headersObj, bodyStr, timeoutMs] = args;
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.nativeFetchAsync === 'function') {
        return new Promise((resolve) => {
          const cbId = 'fetch_' + (rpcCounter++) + '_' + Date.now();
          globalScope.__plNativeCallbacks.set(cbId, (resJson) => {
            try { resolve(JSON.parse(resJson)); }
            catch (_) { resolve({ ok: false, status: 0, error: 'Invalid native fetch JSON' }); }
          });
          globalScope.AndroidChromeBridge.nativeFetchAsync(
            String(url || ''),
            String(httpMethod || 'GET'),
            JSON.stringify(headersObj || {}),
            bodyStr == null ? '' : String(bodyStr),
            Number(timeoutMs || 65000),
            cbId
          );
        });
      }
      throw new Error('Native fetch unavailable outside APK');
    }
    if (method === 'tabs_create') {
      const props = args[0] || {};
      const url = String(props.url || 'about:blank');
      if (url.includes('/views/index.html')) {
        if (!globalScope.location.pathname.endsWith('/views/index.html')) {
          globalScope.location.href = resolveExtUrl('views/index.html');
        }
        return { id: 1, url: resolveExtUrl('views/index.html'), active: true, status: 'complete' };
      }
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.createTab === 'function') {
        const tabJson = globalScope.AndroidChromeBridge.createTab(url, !!props.active);
        const created = JSON.parse(tabJson);
        if (created && created.id) {
          fallbackTabs.set(Number(created.id), { id: Number(created.id), url, active: !!props.active, status: 'loading' });
        }
        return created;
      }
      const tabId = ++fallbackTabCounter;
      const tabObj = { id: tabId, url, active: !!props.active, status: 'complete' };
      fallbackTabs.set(tabId, tabObj);
      return tabObj;
    }
    if (method === 'tabs_get') {
      const tabId = Number(args[0]);
      if (tabId === 1) {
        return { id: 1, url: globalScope.location.href, active: true, status: 'complete' };
      }
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.getTab === 'function') {
        const tabJson = globalScope.AndroidChromeBridge.getTab(tabId);
        const parsed = (tabJson && tabJson !== 'null') ? JSON.parse(tabJson) : null;
        if (parsed) {
          fallbackTabs.set(tabId, parsed);
          return parsed;
        }
        return fallbackTabs.get(tabId) || null;
      }
      return fallbackTabs.get(tabId) || null;
    }
    if (method === 'tabs_update') {
      const tabId = Number(args[0]);
      const updateProps = args[1] || {};
      const cached = fallbackTabs.get(tabId);
      if (cached) {
        if (updateProps.url) cached.url = updateProps.url;
        if (typeof updateProps.active === 'boolean') cached.active = updateProps.active;
      }
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.updateTab === 'function') {
        const tabJson = globalScope.AndroidChromeBridge.updateTab(tabId, JSON.stringify(updateProps));
        const parsed = (tabJson && tabJson !== 'null') ? JSON.parse(tabJson) : null;
        return parsed || cached || { id: tabId, url: updateProps.url || '', active: !!updateProps.active, status: 'loading' };
      }
      return cached || { id: tabId, url: updateProps.url || '', active: !!updateProps.active, status: 'complete' };
    }
    if (method === 'tabs_remove') {
      const tabId = Number(args[0]);
      fallbackTabs.delete(tabId);
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.removeTab === 'function') {
        globalScope.AndroidChromeBridge.removeTab(tabId);
        return true;
      }
      return true;
    }
    if (method === 'tabs_reload') {
      const tabId = Number(args[0]);
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.reloadTab === 'function') {
        globalScope.AndroidChromeBridge.reloadTab(tabId);
        return true;
      }
      return true;
    }
    if (method === 'tabs_query') {
      const queryInfo = args[0] || {};
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.queryTabs === 'function') {
        const listJson = globalScope.AndroidChromeBridge.queryTabs(JSON.stringify(queryInfo));
        return listJson ? JSON.parse(listJson) : [];
      }
      const all = [{ id: 1, url: globalScope.location.href, active: true, status: 'complete' }, ...fallbackTabs.values()];
      return all;
    }
    if (method === 'tabs_send_message') {
      const tabId = Number(args[0]);
      const message = args[1];
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.sendMessageToTab === 'function') {
        return new Promise((resolve) => {
          const cbId = 'tabmsg_' + (rpcCounter++) + '_' + Date.now();
          globalScope.__plNativeCallbacks.set(cbId, (resJson) => {
            try { resolve(resJson ? JSON.parse(resJson) : undefined); } catch (_) { resolve(undefined); }
          });
          globalScope.AndroidChromeBridge.sendMessageToTab(tabId, JSON.stringify(message), cbId);
        });
      }
      return undefined;
    }
    if (method === 'scripting_execute') {
      const opts = args[0] || {};
      const tabId = opts.target && opts.target.tabId;
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.executeScriptInTab === 'function') {
        return new Promise((resolve) => {
          const cbId = 'exec_' + (rpcCounter++) + '_' + Date.now();
          globalScope.__plNativeCallbacks.set(cbId, (resJson) => {
            try {
              const parsed = (resJson && resJson !== 'undefined') ? JSON.parse(resJson) : null;
              resolve([{ result: parsed }]);
            } catch (_) {
              resolve([{ result: null }]);
            }
          });
          globalScope.AndroidChromeBridge.executeScriptInTab(
            Number(tabId || 0),
            opts.funcSource || '',
            JSON.stringify(opts.args || []),
            JSON.stringify(opts.files || []),
            cbId
          );
        });
      }
      return [{ result: null }];
    }
    if (method === 'notify_create') {
      const notifId = String(args[0] || '');
      const opts = args[1] || {};
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.showNotification === 'function') {
        globalScope.AndroidChromeBridge.showNotification(notifId, String(opts.title || 'PocketLeads'), String(opts.message || ''));
      }
      return notifId;
    }
    return null;
  }

  globalScope.__plNativeCallbacks = new Map();
  globalScope.__onAndroidBridgeCallback = function(cbId, payloadJson) {
    const fn = globalScope.__plNativeCallbacks.get(cbId);
    if (fn) {
      globalScope.__plNativeCallbacks.delete(cbId);
      try { fn(payloadJson); } catch (e) { console.warn('Native callback error:', e); }
    }
  };

  if (typeof globalScope.fetch === 'function' && !globalScope.fetch.__plWrappedV5) {
    const origFetch = globalScope.fetch.bind(globalScope);
    const wrappedFetch = async function(input, init) {
      const rawUrl = (typeof input === 'string') ? input : (input && input.url ? input.url : String(input));
      const isExternal = /^https?:\/\//i.test(rawUrl) && !rawUrl.startsWith(getBaseOrigin());
      try {
        return await origFetch(input, init);
      } catch (fetchErr) {
        if (!isExternal) throw fetchErr;
        try {
          const method = (init && init.method) ? String(init.method).toUpperCase() : 'GET';
          let headers = {};
          if (init && init.headers) {
            if (typeof init.headers.forEach === 'function') {
              init.headers.forEach((v, k) => { headers[k] = v; });
            } else if (typeof init.headers === 'object') {
              headers = Object.assign({}, init.headers);
            }
          }
          const body = (init && typeof init.body === 'string') ? init.body : '';
          const nat = await executeMainThreadRpc('native_fetch', [rawUrl, method, headers, body, 65000]);
          if (nat && nat.status > 0) {
            const textBody = String(nat.body || '');
            return {
              ok: nat.status >= 200 && nat.status < 300,
              status: nat.status,
              url: nat.finalUrl || rawUrl,
              text: async () => textBody,
              json: async () => JSON.parse(textBody)
            };
          }
        } catch (_) {}
        throw fetchErr;
      }
    };
    wrappedFetch.__plWrappedV5 = true;
    globalScope.fetch = wrappedFetch;
  }

  function dispatchRuntimeMessageLocally(message, sender) {
    let handledAsync = false;
    let responded = false;
    return new Promise((resolve) => {
      const sendResponse = (replyPayload) => {
        if (responded) return;
        responded = true;
        resolve({ responded: true, payload: replyPayload });
      };
      for (const listener of runtimeMessageListeners.slice()) {
        try {
          const ret = listener(message, sender, sendResponse);
          if (ret === true) {
            handledAsync = true;
          } else if (ret && typeof ret.then === 'function') {
            handledAsync = true;
            ret.then(sendResponse).catch(() => sendResponse(undefined));
          }
        } catch (err) {
          console.warn('[PocketLeads-Android] runtime.onMessage listener error:', err);
        }
      }
      if (!handledAsync && !responded) {
        resolve({ responded: false, payload: undefined });
      } else if (handledAsync && !responded) {
        setTimeout(() => {
          if (!responded) resolve({ responded: false, payload: undefined });
        }, 65000);
      }
    });
  }

  const chromeObj = {};

  chromeObj.runtime = {
    id: EXT_ID,
    lastError: null,
    getManifest: function() {
      return MANIFEST;
    },
    getURL: function(path) {
      return resolveExtUrl(path);
    },
    getPlatformInfo: function(cb) {
      const info = { os: 'android', arch: 'arm64', nacl_arch: 'arm' };
      if (typeof cb === 'function') setTimeout(() => cb(info), 0);
      return Promise.resolve(info);
    },
    getContexts: function() {
      return Promise.resolve([]);
    },
    onInstalled: {
      addListener: function() {}
    },
    setUninstallURL: function() {},
    onMessage: {
      addListener: function(fn) {
        if (typeof fn === 'function' && !runtimeMessageListeners.includes(fn)) {
          runtimeMessageListeners.push(fn);
        }
      },
      removeListener: function(fn) {
        const idx = runtimeMessageListeners.indexOf(fn);
        if (idx >= 0) runtimeMessageListeners.splice(idx, 1);
      }
    },
    sendMessage: function(message, arg2, arg3) {
      let callback = null;
      if (typeof arg2 === 'function') callback = arg2;
      else if (typeof arg3 === 'function') callback = arg3;

      const sender = {
        id: EXT_ID,
        url: resolveExtUrl('views/index.html'),
        tab: { id: 1, url: resolveExtUrl('views/index.html'), active: true }
      };

      return new Promise((resolve) => {
        const finish = (reply) => {
          chromeObj.runtime.lastError = null;
          if (typeof callback === 'function') {
            setTimeout(() => {
              try { callback(reply); } catch (e) { console.warn('sendMessage callback error', e); }
            }, 0);
          }
          resolve(reply);
        };
        setTimeout(() => {
          dispatchRuntimeMessageLocally(message, sender).then(res => finish(res.payload));
        }, 0);
      });
    }
  };

  chromeObj.extension = {
    getBackgroundPage: function() { return undefined; },
    getURL: chromeObj.runtime.getURL
  };

  chromeObj.action = {
    onClicked: { addListener: function() {} },
    setBadgeText: function() {}
  };
  chromeObj.browserAction = chromeObj.action;

  const storageOnChangedObj = {
    addListener: function(fn) {
      if (typeof fn === 'function' && !storageChangeListeners.includes(fn)) {
        storageChangeListeners.push(fn);
      }
    },
    removeListener: function(fn) {
      const i = storageChangeListeners.indexOf(fn);
      if (i >= 0) storageChangeListeners.splice(i, 1);
    },
    hasListener: function(fn) {
      return storageChangeListeners.includes(fn);
    }
  };

  chromeObj.storage = {
    local: {
      get: function(keys, cb) {
        const res = readFromStorageCache(keys);
        const p = Promise.resolve(res);
        chromeObj.runtime.lastError = null;
        if (typeof cb === 'function') setTimeout(() => cb(res), 0);
        return p;
      },
      set: function(items, cb) {
        applyStorageWriteLocal(items || {});
        const p = Promise.resolve();
        chromeObj.runtime.lastError = null;
        if (typeof cb === 'function') setTimeout(() => cb(), 0);
        return p;
      },
      remove: function(keys, cb) {
        applyStorageRemoveLocal(keys);
        const p = Promise.resolve();
        chromeObj.runtime.lastError = null;
        if (typeof cb === 'function') setTimeout(() => cb(), 0);
        return p;
      },
      clear: function(cb) {
        const allKeys = Object.keys(storageCache);
        return chromeObj.storage.local.remove(allKeys, cb);
      },
      onChanged: storageOnChangedObj
    },
    session: {
      get: function(keys, cb) { return chromeObj.storage.local.get(keys, cb); },
      set: function(items, cb) { return chromeObj.storage.local.set(items, cb); },
      remove: function(keys, cb) { return chromeObj.storage.local.remove(keys, cb); },
      clear: function(cb) { return chromeObj.storage.local.clear(cb); },
      onChanged: storageOnChangedObj
    },
    sync: {
      get: function(keys, cb) { return chromeObj.storage.local.get(keys, cb); },
      set: function(items, cb) { return chromeObj.storage.local.set(items, cb); },
      remove: function(keys, cb) { return chromeObj.storage.local.remove(keys, cb); },
      clear: function(cb) { return chromeObj.storage.local.clear(cb); },
      onChanged: storageOnChangedObj
    },
    onChanged: storageOnChangedObj
  };

  chromeObj.tabs = {
    create: function(createProps, cb) {
      const p = executeMainThreadRpc('tabs_create', [createProps || {}]);
      p.then(tab => { if (typeof cb === 'function') setTimeout(() => cb(tab), 0); });
      return p;
    },
    get: function(tabId, cb) {
      const p = executeMainThreadRpc('tabs_get', [tabId]);
      p.then(tab => { if (typeof cb === 'function') setTimeout(() => cb(tab), 0); });
      return p;
    },
    update: function(tabId, updateProps, cb) {
      const p = executeMainThreadRpc('tabs_update', [tabId, updateProps || {}]);
      p.then(tab => { if (typeof cb === 'function') setTimeout(() => cb(tab), 0); });
      return p;
    },
    remove: function(tabIds, cb) {
      const id = Array.isArray(tabIds) ? tabIds[0] : tabIds;
      const p = executeMainThreadRpc('tabs_remove', [id]);
      p.then(() => { if (typeof cb === 'function') setTimeout(() => cb(), 0); });
      return p;
    },
    reload: function(tabId, reloadProps, cb) {
      const callback = typeof reloadProps === 'function' ? reloadProps : cb;
      const p = executeMainThreadRpc('tabs_reload', [tabId]);
      p.then(() => { if (typeof callback === 'function') setTimeout(() => callback(), 0); });
      return p;
    },
    query: function(queryInfo, cb) {
      const p = executeMainThreadRpc('tabs_query', [queryInfo || {}]);
      p.then(tabs => { if (typeof cb === 'function') setTimeout(() => cb(tabs || []), 0); });
      return p;
    },
    sendMessage: function(tabId, message, optionsOrCb, cb) {
      const callback = typeof optionsOrCb === 'function' ? optionsOrCb : cb;
      const p = executeMainThreadRpc('tabs_send_message', [tabId, message]);
      p.then(res => { if (typeof callback === 'function') setTimeout(() => callback(res), 0); });
      return p;
    }
  };

  const registeredContentScripts = new Map();
  chromeObj.scripting = {
    executeScript: function(options, cb) {
      const payload = {
        target: options && options.target || {},
        funcSource: (options && typeof options.func === 'function') ? options.func.toString() : '',
        args: (options && Array.isArray(options.args)) ? options.args : [],
        files: (options && Array.isArray(options.files)) ? options.files : [],
        world: (options && options.world) || 'MAIN'
      };
      const p = executeMainThreadRpc('scripting_execute', [payload]);
      p.then(res => { if (typeof cb === 'function') setTimeout(() => cb(res), 0); });
      return p;
    },
    registerContentScripts: function(scripts, cb) {
      for (const s of (scripts || [])) {
        if (s && s.id) registeredContentScripts.set(s.id, s);
      }
      if (typeof cb === 'function') setTimeout(() => cb(), 0);
      return Promise.resolve();
    },
    getRegisteredContentScripts: function(filter, cb) {
      const list = [...registeredContentScripts.values()];
      if (typeof cb === 'function') setTimeout(() => cb(list), 0);
      return Promise.resolve(list);
    },
    unregisterContentScripts: function(filter, cb) {
      if (filter && Array.isArray(filter.ids)) {
        for (const id of filter.ids) registeredContentScripts.delete(id);
      } else {
        registeredContentScripts.clear();
      }
      if (typeof cb === 'function') setTimeout(() => cb(), 0);
      return Promise.resolve();
    }
  };

  chromeObj.offscreen = {
    hasDocument: function() { return Promise.resolve(true); },
    createDocument: function() { return Promise.resolve(); },
    closeDocument: function() { return Promise.resolve(); }
  };

  chromeObj.alarms = {
    create: function(name, alarmInfo) {
      const alarmName = typeof name === 'string' ? name : 'default_alarm';
      const info = (typeof name === 'object' ? name : alarmInfo) || { periodInMinutes: 1 };
      if (activeAlarms.has(alarmName)) clearInterval(activeAlarms.get(alarmName));
      const periodMs = Math.max(15000, Number(info.periodInMinutes || 1) * 60000);
      const timer = setInterval(() => {
        for (const fn of alarmListeners.slice()) {
          try { fn({ name: alarmName }); } catch (_) {}
        }
      }, periodMs);
      activeAlarms.set(alarmName, timer);
    },
    onAlarm: {
      addListener: function(fn) {
        if (typeof fn === 'function' && !alarmListeners.includes(fn)) alarmListeners.push(fn);
      }
    },
    clear: function(name, cb) {
      if (activeAlarms.has(name)) {
        clearInterval(activeAlarms.get(name));
        activeAlarms.delete(name);
      }
      if (typeof cb === 'function') setTimeout(() => cb(true), 0);
      return Promise.resolve(true);
    }
  };

  chromeObj.notifications = {
    create: function(idOrOpts, optsOrCb, maybeCb) {
      let id = typeof idOrOpts === 'string' ? idOrOpts : ('notif_' + Date.now());
      let opts = typeof idOrOpts === 'object' ? idOrOpts : (optsOrCb || {});
      let cb = typeof optsOrCb === 'function' ? optsOrCb : maybeCb;
      executeMainThreadRpc('notify_create', [id, opts]).then(() => {
        if (typeof cb === 'function') setTimeout(() => cb(id), 0);
      });
    },
    clear: function(id, cb) {
      if (typeof cb === 'function') setTimeout(() => cb(true), 0);
    }
  };

  chromeObj.system = {
    cpu: {
      getInfo: function(cb) {
        const info = { numOfProcessors: 8, archName: 'arm64', modelName: 'Android ARMv8 Processor', features: ['neon'] };
        if (typeof cb === 'function') setTimeout(() => cb(info), 0);
      }
    },
    memory: {
      getInfo: function(cb) {
        const info = { capacity: 8589934592, availableCapacity: 4294967296 };
        if (typeof cb === 'function') setTimeout(() => cb(info), 0);
      }
    },
    storage: {
      getInfo: function(cb) {
        const info = [{ id: 'android-internal', name: 'Internal Storage', type: 'fixed', capacity: 137438953472 }];
        if (typeof cb === 'function') setTimeout(() => cb(info), 0);
      }
    }
  };

  chromeObj.permissions = {
    contains: function(perms, cb) {
      if (typeof cb === 'function') setTimeout(() => cb(true), 0);
      return Promise.resolve(true);
    },
    request: function(perms, cb) {
      if (typeof cb === 'function') setTimeout(() => cb(true), 0);
      return Promise.resolve(true);
    }
  };

  chromeObj.contextMenus = {
    create: function() {},
    onClicked: { addListener: function() {} }
  };

  chromeObj.windows = {
    create: function(props, cb) {
      if (props && props.url) {
        globalScope.location.href = props.url;
      }
      if (typeof cb === 'function') setTimeout(() => cb({ id: 1 }), 0);
    }
  };

  try {
    Object.defineProperty(globalScope, 'chrome', {
      value: chromeObj,
      writable: true,
      configurable: true
    });
  } catch (_) {
    globalScope.chrome = chromeObj;
  }

  if (typeof globalScope.URL !== 'undefined' && typeof globalScope.HTMLAnchorElement !== 'undefined' && !globalScope.HTMLAnchorElement.prototype.click.__plWrappedV5) {
    const blobStore = new Map();
    const origCreateObjectURL = globalScope.URL.createObjectURL.bind(globalScope.URL);
    globalScope.URL.createObjectURL = function(obj) {
      const url = origCreateObjectURL(obj);
      if (obj instanceof Blob) {
        blobStore.set(url, obj);
      }
      return url;
    };

    const origAnchorClick = globalScope.HTMLAnchorElement.prototype.click;
    const wrappedAnchorClick = function() {
      const href = String(this.href || '');
      const downloadName = this.getAttribute('download') || this.download;
      if (href.startsWith('blob:') && downloadName && hasNativeBridge() && typeof globalScope.AndroidChromeBridge.saveDownloadedFile === 'function') {
        const blob = blobStore.get(href);
        if (blob) {
          const reader = new FileReader();
          reader.onloadend = function() {
            const dataUrl = String(reader.result || '');
            const base64Idx = dataUrl.indexOf('base64,');
            const base64Data = base64Idx >= 0 ? dataUrl.slice(base64Idx + 7) : '';
            globalScope.AndroidChromeBridge.saveDownloadedFile(
              String(downloadName),
              String(blob.type || 'text/csv'),
              base64Data
            );
          };
          reader.readAsDataURL(blob);
          return;
        }
      }
      return origAnchorClick.apply(this, arguments);
    };
    wrappedAnchorClick.__plWrappedV5 = true;
    globalScope.HTMLAnchorElement.prototype.click = wrappedAnchorClick;
  }

  setTimeout(function() {
    try {
      const now = new Date();
      const timeStr = now.toTimeString().slice(0, 8) + '.' + String(now.getMilliseconds()).padStart(3, '0');
      chromeObj.runtime.sendMessage({
        action: 'PL_LIVE_SPY_EVENT',
        event: {
          id: 'init-' + Date.now(),
          time: timeStr,
          iso: now.toISOString(),
          type: 'ENGINE_READY',
          level: 'info',
          message: 'PocketLeads Android Self-Patching Engine v5 Active (v' + ((MANIFEST && MANIFEST.version) || '10.18.5') + ').'
        },
        snapshot: {
          updatedAt: now.toISOString(),
          updatedTime: timeStr,
          lastEventType: 'ENGINE_READY',
          lastMessage: 'PocketLeads Android Self-Patching Engine v5 Active.'
        }
      });
    } catch (_) {}
  }, 1200);
})(typeof self !== 'undefined' ? self : window);
