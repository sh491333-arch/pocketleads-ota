/*
 * PocketLeads PRO Android Background Worker Entrypoint
 */
importScripts('/chrome-android-polyfill.js');
importScripts('/controllers/background.js');
