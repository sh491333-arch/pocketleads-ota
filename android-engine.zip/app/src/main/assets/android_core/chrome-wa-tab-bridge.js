/*
 * WhatsApp Web tab message bridge for Android APK
 */
(function() {
  if (window.__plWaTabBridgeInstalled) return;
  window.__plWaTabBridgeInstalled = true;
  const listeners = [];
  window.chrome = window.chrome || {};
  window.chrome.runtime = {
    id: 'pocketleads-android-pro',
    lastError: null,
    getURL: function(p) { return 'https://pocketleads.local/' + String(p || '').replace(/^\/+/, ''); },
    onMessage: {
      addListener: function(fn) { if (typeof fn === 'function') listeners.push(fn); }
    },
    sendMessage: function() {}
  };
  window.__plDispatchTabMessage = function(msg, cbId) {
    let done = false;
    const sendResponse = function(res) {
      if (done) return;
      done = true;
      try {
        if (window.AndroidWaTabBridge && typeof window.AndroidWaTabBridge.onTabMessageResponse === 'function') {
          window.AndroidWaTabBridge.onTabMessageResponse(cbId, JSON.stringify(res === undefined ? null : res));
        }
      } catch (e) {}
    };
    for (const fn of listeners) {
      try { fn(msg, { id: 'pocketleads-android-pro' }, sendResponse); } catch (e) {}
    }
    setTimeout(function() { if (!done) sendResponse(null); }, 9000);
  };
})();
