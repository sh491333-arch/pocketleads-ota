/* Shared runtime configuration. Version comes from manifest.json. */
globalThis.PocketLeadsConfig = Object.freeze({
  endpoint: "https://script.google.com/macros/s/AKfycbwkDaFqXqrcylo-dYkQvTTMhgKVJ4cwy5XiF3YNjqJQ7vdZlblOSJbBPJxncrLVFzokvw/exec",
  supportEmail: 'samimn7890@gmail.com',
  requireManagedRouting: true,
  accountTimeoutMs: 25000,
  refreshMs: 60000,
  version: chrome.runtime.getManifest().version
});
