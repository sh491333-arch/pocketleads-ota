# PocketLeads 10.16.3 — merged update

## Install — dono parts update karein

1. Existing extension folder ka backup lein. Is ZIP ke saare files usi folder mein replace karein, phir `chrome://extensions` par Reload karein. Sirf Apps Script replace karne se Ghost/tab fix install nahi hogi. Chrome 109+ required hai. Extension uninstall ya saved leads Clear karna zaroori nahi.
2. Root ka poora `apps_script_code.js` existing Apps Script `Code.gs` mein paste karein. Agar separately installed old `managed.gs` hai, backup ke baad duplicate PocketLeads definitions hata dein. Unrelated project files preserve karein.
3. Deploy → Manage deployments → existing deployment → Edit → New version → Deploy. Same `/exec` URL rakhein. URL badla ho toh `config/runtime.js` mein wahi URL set karein.
4. Existing licence, two management sheets, assigned API IDs, priority, credit balances aur `PL2_CONFIG`, `PL2_GENERATION`, `PL2_BILLING` retain karein. Already-configured setup dobara chalana required nahi. Billing policy missing ho toh paid search ab bhi block hogi; ye update credit/licence checks bypass nahi karti. `checkPocketLeadsSetup()` read-only diagnostic hai.
5. Dashboard dobara khol kar small search chalayein. Google first chahiye toh user Provider Priority mein `google_place` first hona chahiye. Saved old leads preserve rahenge. All-provider exhausted query ke liye new extraction shuru karein; sirf failed-final Resume se exhausted backend attempt reset nahi hota.

## Ghost / tab flow

- Pehle bounded HTML fetch (3 seconds), safe JSON/DOM parsing, phir ek hidden iframe attempt. Worker total hidden response ko 20 seconds par bound karta hai; actual successful extraction pehle return karti hai.
- Hidden embedding unavailable ho toh hidden document close karke **ek inactive Google Maps tab** create hota hai. Tab focus nahi leta. Baaki profiles us run mein seedhe isi fallback ko reuse karti hain; har profile ke liye slow hidden probe repeat nahi hota.
- Har profile navigation ke beech blank document barrier hai. Extraction exact Chrome document ID se bound hai, taaki pichhli business details next Place ID ko assign na hon.
- Tab renderer 20 profiles ya 2 minutes ke baad recycle hota hai. Normal profile pacing 2–4 seconds aur 20-profile batch gap 5 seconds retained hain. Ye pacing Scrappa/Serper API result rendering ko delay nahi karti.
- First failed hidden probe ke baad maximum two tab attempts; tab response ka total budget 25 seconds per attempt. Google consent/verification/access block par retries stop hoti hain.
- Stop/Clear/completion par extension-owned renderer/tab close hota hai. User ne tab activate/navigate kar liya ho toh extension usse overwrite/close nahi karti. Koi existing user tab scraping ke liye take over nahi hota.
- Dono extraction paths existing controller → canonical IndexedDB → dashboard/CSV flow use karte hain. Separate result store, parallel scraper or duplicate provider handler add nahi hua.
- Old iframe-only failures ko, jab unka existing attempt resumable ho, upgraded engine ek bounded retry de sakta hai. Saved Place IDs dobara extract nahi hote.

**Chrome limitation:** inactive tab tab bar mein dikh sakta hai, aur history/cache entries ho sakti hain. Offscreen bhi incognito nahi hai. Is build mein history/cache deletion ya CAPTCHA/consent bypass nahi hai.

## Faster startup

Icon click, dashboard load, activation follow-up aur Start recent verified managed route (maximum 30 seconds) share karte hain. Concurrent refresh requests coalesce hoti hain; manual Refresh fresh server request karta hai. Expired/missing/error route ko refresh kiya jata hai.

Backend mein ek locked reservation ke andar repeat licence/balance checks aur repeat assigned-key-pool reads remove hue hain. Har new paid request ab bhi authoritative licence, device, assigned priority, key limits aur common credit verify/reserve karti hai. Credit spend cached balance se nahi hota. Network/Apps Script latency ke liye instant response guarantee nahi hai.

## Preserved

Existing licence/device/expiry system, two management sheets and recovery journals, provider order and key rotation, common credit reservation/settlement, unique IndexedDB rows, table hydration/pagination, history readability, stopped timer and CSV exports.

Scrappa: **one page-0 call per query, max 200 results**. Serper pincode: **up to 7 pages**. Partial usable results do not trigger extra provider fallback. `PL2_BILLING` rates are not changed or invented.

Read `MERGE_REVIEW_10.16.3.md` for the comparison and `tests/VALIDATION_10.16.3.md` for test scope. Older version notes/reports are historical. Live Google Maps, production Sheets/provider billing and native Chrome extension injection remain deployment-side checks.
