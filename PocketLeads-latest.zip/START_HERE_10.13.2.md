> Historical document. Current release: START_HERE_10.15.0.md.

> Historical document. Current installation and behavior: START_HERE_10.14.0.md.

# PocketLeads 10.13.2 — both-engine start and routing repair

## REQUIRED: update the backend as well as the extension

1. Back up your Apps Script and spreadsheet.
2. Replace your existing Apps Script source with the included `apps_script_code.js` (backend v35_engine_routing). Preserve/review SHEET_ID.
3. Deploy a NEW VERSION of the EXISTING web-app deployment. Keep the existing web-app URL. If it changes, update config/runtime.js.
4. Replace your existing unpacked extension folder with this full package and click Reload. Keep the same extension installation to preserve saved leads/license.
5. Open the dashboard and press Start again. Start performs a fresh account/provider check. Clear Data is not required for this repair.

Replacing extension files alone cannot repair provider selection in an older deployed backend.

## Why the reported error happened

The v10.13.0/v10.13.1 backend interpreted a blank/missing API Usage Limit as zero. Valid API rows with blank limits, including the legacy Apify layout with no limit column, were excluded. This reproduces the exact message: "Service temporarily unavailable. No active provider row is currently usable."

Your live sheet was not accessible, so this is a confirmed code regression and reproduced cause, not a claim that your current sheet has been inspected. Truly missing keys, disabled rows, exhausted customer credits and invalid configuration can also cause a blocked start.

## Current quota policy

- Provider API-sheet Usage Limit blank/missing: uses DEFAULT_PROVIDER_USAGE_LIMIT in Apps Script. It defaults to no additional configured provider quota (the existing internal unlimited sentinel). This is server policy, not a fabricated customer credit balance. An administrator can change this constant or set finite row limits.
- Explicit provider Usage Limit 0: blocked.
- Malformed/negative provider Usage Limit: blocked.
- Explicit customer credit 0 or blank credit: still zero. No free credits are introduced.
- Provider Status false/0/inactive/api_blocked/auth_error: stays blocked.
- Automatic local accounting uses a separate usage_limit_reached status, which can recover after a refund/quota increase. Provider-reported failures still use blocking statuses.

If a row was already marked `limit_reached` by the old release, review Usage Count, Usage Limit and Notes. If Notes says "Auto disabled", resolve the real provider quota/auth problem first. Only an administrator who confirms that the old status was incorrect should change it to `active`. This update does not blindly reactivate existing blocked rows.

## Both engine paths

Engine 1: Scrappa / Serper / Apify -> server-selected eligible row -> secure proxy -> structured results -> authoritative credit update.
Engine 2: Google Maps -> server-selected eligible row -> Places IDs-only proxy -> existing local profile extraction pipeline -> authoritative credit update.

Automatic routing prefers eligible structured providers, then falls back to Google Maps when configured and entitled with available credits. A provider-specific request stays on that provider. A Google Maps provider key with Places access is still required; no valid configuration is invented.

## Repairs included

- Blank/missing provider limits and legacy Apify layouts are compatible again.
- Optional missing sheet headers no longer read unrelated date/source cells as quota data.
- False/0 row Status no longer behaves like active.
- Shared account service owns prepared routes; an older icon warm-up cannot independently overwrite the freshly prepared route with stale failure metadata.
- Start and controller errors retain useful configuration reasons instead of replacing all failures with a generic temporary outage.
- Finite Apify actor maxItems is clamped by customer credit, configured plan batch cap and provider remaining capacity.
- Serper alternate/nested response shapes are normalized, capped and counted before delivery; unrecognized shapes are withheld and reservations refunded.
- Concurrent result accounting/refunds restore automatically limited rows when capacity becomes available, without re-enabling explicit administrator/provider blocks.
- The 10.13.1 persistent license-race barrier remains included.

## Verification and limits

56 automated tests pass. New engine tests execute the actual backend routing/proxy/accounting functions against an in-memory spreadsheet and intercepted provider transport. Start integration exercises actual account persistence and actual getPreparedScrapeConfig for both scrappa and googlemaps. In the initial 19-test engine set, 17 failed on the old release and all passed after repair. Three further plan/retry/refund tests also pass.

All packaged JavaScript files have been syntax-checked and ZIP integrity verified. Test sources/output are included under tests.

No live customer licence, deployed-sheet access, real paid provider calls, or live browser/Maps DOM run was available. Real Google Maps profile extraction, provider billing and deployed Apps Script operation still require live testing. An Apify actor's own behavior depends on its input schema; this repair clamps the proxy's maxItems parameter, not every arbitrary actor's internal implementation. Apps Script interruption during a reserved request may still require reconciliation, as noted in previous releases.

Known unrelated audit finding remains: full export uses a fixed column schema and may omit additional nonstandard fields. Existing export tests use mocks for that column builder. This release does not claim to fix full export coverage or provide a complete security certification.

This file supersedes older UPDATE_10.13.0.md/UPDATE_10.13.1.md descriptions of quota defaults and pending engine findings.
