/* MV3 Ghost renderer. One direct Place-ID navigation per profile, no visible
 * tabs and no alternate URL/retry/fallback navigation. Bounded hidden iframe
 * lanes let the first real profile rows reach IndexedDB quickly without tabs. */
(() => {
  if (window.__pocketLeadsGhostInstalled) return;
  window.__pocketLeadsGhostInstalled = true;

  const MAX_PARALLEL_PROFILES = 4;
  let generation = 0, completed = 0, active = 0;
  const frames = new Set();
  const pending = new Map();
  const waiters = [];
  const cancelled = () => new Error('Ghost Mode request cancelled.');

  function wakeWaiters() {
    while (active < MAX_PARALLEL_PROFILES && waiters.length) {
      const waiter = waiters.shift();
      if (waiter.token !== generation) {
        waiter.reject(cancelled());
        continue;
      }
      active++;
      waiter.resolve();
    }
  }
  function acquireSlot(token) {
    if (token !== generation) return Promise.reject(cancelled());
    if (active < MAX_PARALLEL_PROFILES) {
      active++;
      return Promise.resolve();
    }
    return new Promise((resolve, reject) => waiters.push({ token, resolve, reject }));
  }
  function releaseSlot() {
    active = Math.max(0, active - 1);
    wakeWaiters();
  }
  function removeFrame(currentFrame) {
    if (!currentFrame) return;
    frames.delete(currentFrame);
    try { currentFrame.src = 'about:blank'; } catch (_) {}
    try { currentFrame.remove(); } catch (_) {}
  }
  function destroyAllFrames() {
    for (const entry of [...pending.values()]) entry.reject(cancelled());
    for (const currentFrame of [...frames]) removeFrame(currentFrame);
    for (const waiter of waiters.splice(0)) waiter.reject(cancelled());
  }
  const googleOrigin = origin => {
    try {
      const u = new URL(origin);
      return u.protocol === 'https:' && /^(www\.|maps\.)?google\.(com|co\.in)$/.test(u.hostname);
    } catch (_) { return false; }
  };

  function navigateOnce(payload, token) {
    const placeId = String(payload.placeId || '').trim();
    if (!placeId) return Promise.reject(new Error('Missing Google Place ID.'));
    if (token !== generation) return Promise.reject(cancelled());

    const nonce = crypto.randomUUID();
    const currentFrame = document.createElement('iframe');
    currentFrame.name = 'pocketleadsGhost_' + nonce;
    currentFrame.setAttribute('aria-hidden', 'true');
    currentFrame.setAttribute('title', 'PocketLeads hidden profile renderer');
    currentFrame.style.cssText = 'position:fixed;width:1280px;height:900px;left:0;top:0;border:0;pointer-events:none;opacity:0;';
    (document.body || document.documentElement).appendChild(currentFrame);
    frames.add(currentFrame);
    // This is the only URL navigated to for this Place ID.
    const url = PocketLeadsGhostParser.buildPlaceUrl({ placeId });

    return new Promise((resolve, reject) => {
      const timeoutMs = Math.max(1000, Math.min(8000, Number(payload.timeoutMs) || 6500));
      let timer = null, probe = null, settled = false;
      const finish = (error, data) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        clearInterval(probe);
        currentFrame.removeEventListener('load', onLoad);
        pending.delete(nonce);
        removeFrame(currentFrame);
        error ? reject(error) : resolve(data);
      };
      const entry = {
        nonce, payload, frame: currentFrame, ready: false, token,
        resolve: data => finish(null, data),
        reject: error => finish(error instanceof Error ? error : new Error(String(error || 'Ghost profile failed.')))
      };
      const hello = () => {
        if (settled || token !== generation) return;
        try {
          if (currentFrame.contentWindow) {
            currentFrame.contentWindow.postMessage({ type: 'PL_GHOST_HELLO', nonce }, '*');
          }
        } catch (_) {}
      };
      function onLoad() { hello(); }
      pending.set(nonce, entry);
      timer = setTimeout(() => entry.reject(new Error(
        'Ghost Mode single attempt timed out after ' + timeoutMs + ' ms. Google Maps may be slow or require consent/CAPTCHA.'
      )), timeoutMs);
      currentFrame.addEventListener('load', onLoad);
      // Fast handshake polling (60ms) so the mounted iframe starts scraping immediately.
      probe = setInterval(hello, 60);
      currentFrame.src = url;
      hello();
    });
  }

  window.addEventListener('message', event => {
    const message = event.data;
    if (!message || !/^PL_GHOST_(READY|RESULT)$/.test(message.type)) return;
    const entry = pending.get(message.nonce);
    if (!entry || !frames.has(entry.frame)) return;
    if (!googleOrigin(event.origin)) return;
    // A non-null source must be the exact iframe assigned to this request.
    if (event.source !== entry.frame.contentWindow) return;
    if (entry.token !== generation) return entry.reject(cancelled());

    if (message.type === 'PL_GHOST_READY') {
      if (typeof message.documentToken !== 'string' || !message.documentToken) return;
      if (entry.ready && entry.documentToken === message.documentToken) return;
      entry.documentToken = message.documentToken;
      entry.ready = true;
      entry.frame.contentWindow.postMessage({
        type: 'PL_GHOST_SCRAPE', nonce: message.nonce,
        documentToken: entry.documentToken, payload: entry.payload
      }, event.origin);
      return;
    }
    if (!entry.ready || message.documentToken !== entry.documentToken) return;
    if (message.ok && message.data && message.data.company_name) entry.resolve(message.data);
    else entry.reject(new Error(message.error || 'Google Maps profile was empty.'));
  });

  function notify(payload, stage, attempt, error) {
    chrome.runtime.sendMessage({
      action: 'PL_GHOST_STAGE', runEventId: payload.runEventId || '',
      placeId: payload.placeId, stage, attempt, error: error || ''
    }, () => { void chrome.runtime.lastError; });
  }

  async function scrape(payload, token) {
    await acquireSlot(token);
    const heartbeat = setInterval(() => chrome.runtime.sendMessage(
      { action: 'PL_GHOST_HEARTBEAT' }, () => { void chrome.runtime.lastError; }
    ), 20000);
    try {
      if (token !== generation) throw cancelled();
      notify(payload, 'iframe_dom', 1);
      const timeoutMs = Math.max(1000, Math.min(8000, Number(payload.timeoutMs) || 6500));
      const row = await navigateOnce(Object.assign({}, payload, { timeoutMs }), token);
      if (token !== generation) throw cancelled();
      if (!row || !row.company_name) throw new Error('Google Maps profile contained no usable business details.');
      completed++;
      return row;
    } catch (error) {
      notify(payload, 'failed', 1, String(error && error.message || error));
      // Tell the consumer this profile used its one permitted navigation attempt.
      if (error && typeof error === 'object') error.ghostAttemptsExhausted = true;
      throw error;
    } finally {
      clearInterval(heartbeat);
      releaseSlot();
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.target !== 'pocketleads_offscreen') return;
    if (sender.id !== chrome.runtime.id) return;
    if (message.action === 'PL_GHOST_PING') {
      sendResponse({ ok: true, completed, activeProfiles: active, openFrames: frames.size });
      return false;
    }
    if (message.action === 'PL_GHOST_CANCEL') {
      generation++;
      destroyAllFrames();
      sendResponse({ ok: true });
      return false;
    }
    if (message.action === 'PL_GHOST_SCRAPE_PROFILE') {
      const token = generation;
      scrape(message.payload || {}, token)
        .then(data => sendResponse({ ok: true, data, completed }))
        .catch(error => sendResponse({
          ok: false, error: String(error && error.message || error),
          ghostAttemptsExhausted: true, completed
        }));
      return true;
    }
    if (message.action === 'PL_GHOST_PREWARM') {
      sendResponse({ ok: true, completed });
      return false;
    }
  });
})();
