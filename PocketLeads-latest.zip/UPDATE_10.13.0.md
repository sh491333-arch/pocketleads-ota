> Historical document. Current release: START_HERE_10.15.0.md.

> Historical document. Current installation and behavior: START_HERE_10.14.0.md.

> Historical notes: START_HERE_10.13.2.md contains the current installation requirements, quota policy and known limitations.

> Historical release notes. Read UPDATE_10.13.1.md for current scope and known unresolved audit findings.

# PocketLeads 10.13.0 — installation and release notes

This is a complete extension based on the supplied 10.12.13 ZIP, including the updated Google Apps Script backend. It is not a small overlay patch.

## Required deployment order

1. Back up the existing Apps Script and licence/API spreadsheets.
2. Review the existing `SHEET_ID` in `apps_script_code.js`. It is preserved from the uploaded extension.
3. In your licence sheet, explicitly configure each credit bucket. Blank credits and blank purchased credits now mean **zero**, not unlimited. Use the literal `unlimited` only for accounts intentionally entitled to unlimited usage. Purchase Credit is a shared top-up pool available to either engine bucket; do not add the two displayed bucket totals together.
4. In the API sheet, set **Usage Limit** to a nonnegative integer or literal `unlimited`. Missing/blank/malformed limits now block that row; zero blocks it too. Configure this BEFORE rollout or a previously blank API row will stop serving requests.
5. Replace the existing Apps Script source with the included `apps_script_code.js`. Update the EXISTING web-app deployment to a new version. Preserve its URL and the existing execute/access settings needed by the extension. This package expects backend `v34_unified_account`.
6. If the deployment URL changes, edit only `config/runtime.js`. No provider secrets belong in the extension.
7. Extract the ZIP. Load the folder containing `manifest.json` through Chrome's Load unpacked, or replace the existing unpacked directory and Reload. Keep the same extension installation/directory to retain Chrome storage. Existing stored licenses are restored without a new activation prompt unless the server rejects them.
8. Perform the live checklist below with a test licence before releasing to customers.

## What changed

- One worker-owned account state mirrors license, credits, plan, limits, entitlements, user, support, and engine route to all extension views.
- Activation validates the licence and returns the account plus provider route in ONE response. This consolidates the requested parallel activation/account work without a racing, unauthenticated second request. Dashboard opens after that response is persisted. Support fallback is locally available immediately.
- Returning users see their cached state immediately. Background refresh, window focus and a one-minute alarm fetch updated/top-up balances. Concurrent account requests are coalesced.
- Network, timeout, server and deployment errors preserve the saved activation and show retry. Definitive expiry, inactive, missing licence or revoked device responses deactivate it.
- Server result snapshots update credits after consumption without reopening the dashboard. Older snapshots and other-account responses cannot replace the current account. Logout prevents pending refreshes from restoring released state.
- Unknown credit is displayed as unavailable; zero remains zero. Purchased credit is no longer double-counted by the profile UI.
- Scraping start checks server account, entitlement, engine availability and credits. Every paid provider request still verifies the server licence/device and plan; cached UI is not authorization.
- Credit and API-row capacity reservations happen under the server lock. Definitive provider failures refund reservations, and successful requests refund unused capacity. Remaining balance reflects the actual sheet values.
- Paid proxy transport errors are not automatically retried, because an ambiguous timeout may have consumed credits on the server.
- Download opens Full Data / Filter Columns options. Full export needs no field selector. The selector has select/deselect all, selected count, back/cancel and persistent preferences. Large exports scan all stored pages for columns rather than sampling only the first page.
- Removed the old content-script 30-second auth polling gate before completion.
- Runtime endpoint, support fallback and manifest-derived version are centralized. Replaced the legacy unconditional Auth success adapter.
- Profile exposes credits, plan/status, buy/upgrade, support and retry actions. Optional purchase URLs accept HTTPS only.

## Optional licence-sheet columns

These are exact human-readable column headings on the licence sheet. They can be changed without updating the extension.

| Column | Meaning / server default |
| --- | --- |
| Plan | Display name; default Configured plan |
| User Name | Account name |
| Email | Account email |
| Enabled Engines | Comma-separated googlemaps, serper, scrappa, apify, apifywpapi; default all supported engines |
| Scraping Enabled | false/no/off/disabled/0 disables scraping; default enabled |
| Export Enabled | false/no/off/disabled/0 disables export in the standard UI; default enabled |
| Max Results Per Request | Nonnegative integer or unlimited; default explicitly unlimited on server; zero blocks requests |
| Export Limit | Nonnegative maximum rows per export, or unlimited; default explicitly unlimited on server |
| Support Email | Overrides the server support fallback |
| Purchase URL | HTTPS URL for buy credits / upgrade; otherwise support email is used |

Existing Licence Validity, Status, Google Maps API Credit, Serper Apify API Credit and Purchase Credit columns continue to control validity/status/balance. Provider-specific technical batch sizes and queue pagination remain operational settings, not commercial balances. Max Results Per Request is a batch limit, not a daily or per-session allowance. Finite credits control cumulative paid results.

## Validation performed

- 29 automated Node regression tests passed against actual account, export and backend functions with mocked Chrome/Apps Script services.
- Syntax checks passed for all 57 JS/CJS files (including bundled vendor/provider files).
- Manifest and local HTML script references checked; all required referenced files found.
- All 99 original ZIP files inventoried with change status and SHA-256. Only generated Chrome `_metadata` is intentionally removed.
- Test sources and actual output are included under `tests/`. Run `node --test tests/*.test.cjs` from the extracted folder.

## Live checklist — not performed in this environment

No valid live test licence or backend deployment access was provided. A runnable Chromium binary was unavailable. Actual Chrome rendering, live Google Apps Script deployment, provider billing/availability and end-to-end scraping are therefore NOT certified by the automated tests.

1. Activate a test licence; verify account, credits and support appear together.
2. Close/reopen/reload the same installation; verify no activation prompt.
3. Disconnect internet; reopen; verify cached account and retry, then reconnect.
4. Set expiry/inactive; refresh; verify the UI blocks and the server rejects proxy calls.
5. Set credit and API usage limit to zero separately; Start must fail meaningfully.
6. Top up the shared purchase pool; focus/refresh and verify the new balance.
7. Run a small query on each configured provider; compare returned rows, remaining credits and API usage in the sheet.
8. Run two devices concurrently near the remaining credit/API limit; verify no negative credit or excess reservations.
9. Export Full Data, a custom selection, CSV/Excel/Copy, large data with later-page fields, and CRM/history.
10. Test support tickets, file attachment, upgrade action, logout and backend errors.

## Boundaries and operational considerations

Server enforcement protects access to the paid provider proxy and its result credits. Local JS, cached flags, device identifiers and already-downloaded data are not tamper-proof. Local export restrictions are standard-client UX restrictions; truly tamper-resistant download metering needs server-hosted result storage and export delivery. The DOM/profile-enrichment and WhatsApp components still run locally and cannot be made paid server authority merely by editing extension JS.

This update does not provide a full penetration test of the legacy provider adapters. Apps Script termination during an in-flight reservation may leave reserved credit/capacity until an admin reconciles it; do not blindly repeat a timed-out paid request. Admin spreadsheet edits during live reservations should be avoided. End-to-end service operation still requires the deployment and live checklist above.
