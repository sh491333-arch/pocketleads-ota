# PocketLeads 10.15.1 — fixes and verification

This is a complete extension package, based on the supplied 10.15.0 ZIP.
The current release number is in manifest.json. Older release notes and test
reports are retained for reference; this document describes the new build.

## Install the update

1. Export any important current leads/history as a backup.
2. Stop any active scrape, then close the dashboard.
3. Extract this ZIP. For an existing unpacked installation, copy its contents
   into the SAME extension directory, replacing the old files.
4. Open chrome://extensions and click Reload on PocketLeads. Reopen its dashboard.
   Do not uninstall the extension: that can remove extension-local data.
5. For a fresh installation, enable Developer mode and choose Load unpacked,
   selecting the extracted directory containing manifest.json.

The Apps Script backend is unchanged. No backend redeployment is required for
these fixes. This build does not change account entitlements or billing rules.

## Fixes

### Dashboard and runtime exception

The background message dispatcher incorrectly routed `result_store_query` to
HistoryStore.getAll(). The response contained `sessions`, not `rows`. The grid
assigned undefined to its row array, then crashed at `pageRows.length` during
asynchronous rendering. That also affected dashboard metric and filter queries.

The dispatcher now routes each action to the correct IndexedDB store. The grid
validates remote response shape before accepting data, keeps the last valid
page on errors, rejects stale replies and supports dynamic columns. Paging and
filters continue to query the full result store, not the 250-row UI preview.
Zero ratings/review counts display correctly.

The final CSS rules constrain the grid to its parent, keep the pager outside
the row scroller, and provide a bounded vertical viewport plus horizontal
scrolling with synchronized header/body. Native vertical wheel scrolling
consumes table rows before chaining to the page. Scroll position is clamped
when results shrink, avoiding a blank area after a refresh.

### Scraping history

The modal previously combined hard-coded pale/neon text with light-theme
backgrounds. All history surfaces now use the active theme's foreground,
background, border and focus colors. Both the history list and session table
have independently scrollable data areas. Buttons, notes and date fields use
readable colors in dark and light themes.

### Ghost Mode

The existing Place-ID URL generation is retained. The fragile window-message
handshake is replaced with extension runtime messages. Each hidden-frame
navigation receives a fresh random nonce; replies are verified against the
extension sender and frame document identity. Tracking document identity also
allows Google Maps to rewrite its URL after loading. Requests remain serialized,
with one bounded retry and periodic iframe recycling.

The hidden frame now has a 1280 x 900 layout viewport, instead of 1 x 1 pixels.
This supports desktop Maps DOM layout without opening a visible tab. Content
script registration is retained between runs to avoid a cleanup/registration
race. No arbitrary payload URL is used for navigation.

### Scrappa city/text searches

City/text searches use simple-search pages 0, 1, 2, ... without spatial tiles or
coordinate discovery. The existing selected result target and page budget still
apply. Requests stop when the target is reached, the configured page budget is
used, the provider returns no new rows, the user stops, or a provider/account
error occurs. Partial pages can continue; duplicate-only pages stop.

Pincode searches retain their single page-0 request with limit 200 and
Place-ID deduplication. The upstream simple-search endpoint documents a 1–200
limit per request and zero-based pagination:
https://scrappa.co/docs/google-maps-api/simple_search

More than 200 total city/text results are therefore requested through multiple
pages, not a larger single request. Actual unique yield depends on the provider;
the extension cannot guarantee any requested total. Existing provider/account
credit checks remain in force.

### Total scraping time

Queue terminal states and completion timestamps now override stale cached
`runState` and legacy running flags. Both `complete_with_errors` and
`completed_with_errors` are recognized. The background completion handler writes
the canonical spelling. The timer uses the recorded finish time after completion,
including when the dashboard is reopened days later. Older terminal records
without a finish timestamp use their stored elapsed time/checkpoint, not the
current date. Clear-data paths reset all timer fields. Recovery alarms also
consult the canonical run-state helper.

Historical durations already corrupted before this update cannot be precisely
reconstructed if the original completion timestamp/checkpoint was lost.

## Verification

- 113 Node tests passed: the original 92 plus 21 new regression tests.
- Syntax checks passed for all 66 JavaScript/test files.
- 10 Chromium browser checks passed with synthetic data and shipped UI code:
  600-row display, pagination beyond the preview, vertical virtualization,
  synchronized horizontal scrolling at narrow widths, search across the full
  dataset, malformed-response recovery, light/dark history contrast, session
  pagination using the real controller helpers, and no uncaught browser errors.
- History text and note fields met a 4.5:1 contrast ratio in both tested themes.
- Ghost tests run both shipped frame/offscreen scripts against simulated Maps
  DOM and Chrome runtime messaging. They cover Place-ID links, concurrent
  requests, retry, recycling, sender rejection and Maps URL changes.
- Scrappa tests simulate 600 unique rows over three pages, pincode single-call
  behavior, duplicates, empty results, errors and stopping during streaming.

Run `node --test tests/*.test.cjs` for the dependency-free regression suite.
Browser test instructions are at the top of tests/browser-recovery.cjs.
Current results: tests/TEST_RESULTS_10.15.1.txt and tests/BROWSER_RESULTS.txt.
Screenshots in tests/ are fixture screenshots, not live customer data.

## Remaining live checks

A live installed Chrome extension, authenticated backend, real Google Maps DOM
and paid Scrappa calls were NOT exercised here. Verify one known Place ID in
Ghost Mode, a city/text target above 200, one pincode, Stop/Resume, and reopening
a completed run in your installed extension. The local tests cannot establish
how live Google consent/CAPTCHA pages or upstream provider changes will behave.
