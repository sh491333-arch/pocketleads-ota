# Current build: PocketLeads 10.16.2

Read **START_HERE_10.16.2.md** first. Install all extension files and update the
complete root apps_script_code.js in your existing deployment. Ghost sessions,
HTTP/DOM extraction, redirect-safe handshakes, cancellation, profile diagnostics
and dashboard delivery were updated incrementally. Existing PL2_BILLING and
licence balances are retained. Live Google/native extension checks remain open.

Earlier release notes follow for reference.

# Current build: PocketLeads 10.16.1

Read [START_HERE_10.16.1.md](START_HERE_10.16.1.md). The root `apps_script_code.js` is the COMPLETE single-file backend. Google Ghost delivery, Resume identity and query completion have additional fixes. Deployment is performed by the owner.

---

Historical release notes follow.

# Current build: PocketLeads 10.16.0

Read [START_HERE_10.16.0.md](START_HERE_10.16.0.md) and [backend/DEPLOYMENT.md](backend/DEPLOYMENT.md) first. This build requires the included managed backend and is an integration candidate pending live validation.

---

The notes below describe earlier releases.

> Historical document. Current release: START_HERE_10.15.0.md.

> Historical document. Current installation and behavior: START_HERE_10.14.0.md.

# PocketLeads v98 Final Cleanup & Update Notes

## Completed changes

1. License activation improvements
- Added mobile-safe device identity fallback.
- Prevented device identity timeout from blocking activation.
- Reduced unnecessary activation flow delays.
- Maintained Apps Script compatibility.

2. Scrappa result streaming
- Large result sets are displayed progressively.
- Results are rendered in 20-item batches.
- Batch timers are isolated from new searches.
- Previous query queues do not affect new queries.

3. Performance improvements
- Removed obsolete backup code files.
- Reduced unnecessary project clutter.
- Improved maintainability and deployment size.
- Preserved required production files only.

4. Location filtering
- Country-aware filtering logic preserved.
- Reduced unnecessary API calls.
- Maintained result quality safeguards.

5. Dashboard improvements
- Profile panel integration.
- Theme toggle support.
- Credit display structure.
- Helpdesk/ticket workflow support.
- Apps Script ticket integration support.

## Remaining recommended improvements

- Move license validation cache fully server-side using Apps Script CacheService.
- Add ticket attachment upload retry queue.
- Add backend rate limiting for multiple users.
- Add automated extension health diagnostics.
- Add error reporting dashboard for production monitoring.


Mobile UI icon patch: replaced text-dependent material icons with embedded SVG icons for reliable mobile rendering.


## Profile / UI reliability patch
- Replaced profile and navigation Material Icon dependencies with local SVG icons.
- Fixed Profile actions, including Settings navigation.
- Unified light/dark mode to the `dashboard-theme` key and removed legacy theme-key conflicts.
- Added a stable local icon fallback for remaining legacy dashboard icons, including the three-dot options icon.
- Improved light/dark contrast for profile and navigation controls.


## v10.12.4 — Profile + Support Pro UI
- Rebuilt profile/support interaction into one consistent flow.
- Replaced remaining profile close/options glyphs with inline SVG icons.
- Added ticket refresh, validation, ticket detail view, status badges, empty/error states, and Escape/backdrop closing.
- Included licence user/email in support requests.
- Unified theme storage while preserving existing dashboard themes instead of silently converting non-light themes to dark.
- Added polished light-theme surfaces for the new profile/support components.

- Removed duplicate Settings-button event binding that could cancel the dropdown open action.
- Added standalone Terms page close button.
- Added consistent branded global card/button surface polish.


## v10.12.6 — Professional UI + Support Reliability
- Added shared PocketLeads Professional design system with light/dark brand surfaces, orange accent, smooth controls and consistent modal styling.
- Added shared pocketleads-theme.js as the single source of truth for dark/light mode.
- Updated navbar theme toggle to the supplied compact orange/white sun-moon switch pattern.
- Updated profile trigger, profile panel and support center visual hierarchy and close controls.
- Added close control to the new-ticket form and standalone settings/licence pages.
- Moved support requests through the MV3 service-worker transport to avoid Apps Script redirect/CORS response problems.
- Added ticket submission idempotency/retry protection.
- Bumped extension version to 10.12.6.


## v10.12.6 — Professional UI + Support Reliability
- Unified orange/charcoal brand system across dashboard, settings, legal and licence surfaces.
- Added transparent light/dark PocketLeads logo variants to chrome-safe UI surfaces.
- Replaced legacy theme palette conflicts with the single dark/light pill toggle.
- Added polished responsive profile trigger, modal animation, form focus, status and button states.
- Hardened support ticket submission with service-worker transport, parser tolerance, 20s timeout and server-side ScriptLock idempotency.
- Added/standardized close controls and accessibility attributes for profile/support/licence/settings flows.


v10.12.7 — Premium UI refinement: right-aligned profile/theme controls, delegated theme toggle for Angular-injected navbar, polished light/dark branding, tactile controls, consistent dialogs/close buttons, and stronger dashboard/profile visual hierarchy.


## v10.12.8 — Premium dashboard finish
- Reference-matched action button colors and tactile 3D states.
- Compact 58×32 dark/light toggle with improved sun/moon visibility.
- All 8 metric cards now have visible color accents and dimensional light-mode shadows.
- Keyword, Location, and Progress cards receive distinct accent rails and depth.
- Results grid updated to the supplied clean light-mode table language with dark-mode counterpart.
- Angular-safe delegated ripple interactions added for dynamically rendered buttons.

- Active controls use the supplied green/purple/cyan/orange/red/neutral button palette.
- Light results grid matches the supplied white table reference; dark mode keeps the same hierarchy on charcoal surfaces.
- 8 summary cards, input cards, and progress card have visible accent rails and 3D depth.
