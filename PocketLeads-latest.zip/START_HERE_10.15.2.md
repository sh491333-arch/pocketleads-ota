# PocketLeads 10.15.2

This release supersedes the search-limit and Ghost Mode behavior documented in
10.15.1. It is a complete extension package, not a patch-only ZIP.

## Requested search behavior

| Provider/search | Behavior |
| --- | --- |
| Scrappa city, text, pincode | Exactly one logical Simple Search request: page 0, limit 200. No additional pages or spatial tiles. |
| Serper pincode | Up to 7 pages, respecting a lower selected page limit. Empty/duplicate pages, Stop or provider errors can end the search earlier. |
| Google Places pincode | Existing 3-page cap retained; the requested 7-page change applies only to Serper. |

A maximum of 200 does not guarantee 200 available leads. Existing account/result
credit limits and duplicate filtering still apply. Existing backend recovery
may retry a definitive upstream 503 response; it does not request another page.
The Apps Script backend file and its billing rules are unchanged.

## Angular infinite-digest root cause

`getRowsFromHistory()` previously deep-cloned every row each time Angular
called it. `ng-repeat`'s collection watcher therefore saw 25 new objects on
every digest pass, matching the +25 increments in the reported error. Raising
the digest limit would only hide the problem.

The getter now returns stable stored row identities and a stable empty array.
The explicit restore/edit boundary makes its own copy when needed. A real
Angular 1.6.9 browser test reproduces the old `infdig` error and confirms the
shipped getter settles normally. History session paging is tested with the
actual getter and controller helpers, not a substitute rows getter.

## Ghost Mode

The working route remains:
Google Places IDs-only API -> worker -> offscreen document -> hidden Maps
iframe -> content-script DOM extraction -> worker's existing saveDatasetRows
and IndexedDB pipeline -> dashboard/export.

The Places field mask remains `places.id,nextPageToken`. No visible Maps-tab
fallback is used by the Place-ID scraper.

Repairs in this release:

- Readiness no longer depends on a query-string nonce surviving a Maps
  redirect. A fresh challenge is exchanged using postMessage after iframe load.
- A direct extension ancestor identifies the hidden frame even when redirects
  remove URL markers and reset window.name. Normal top-level Maps pages are
  excluded by the content-script guard.
- Sender origin, request nonce and iframe source are validated. Null message
  sources are allowed only with the other checks intact for privileged contexts.
  Only a non-sensitive hello challenge uses a wildcard target; profile messages
  use the verified Google/extension origin.
- Google .com and .co.in Maps routes, including `/maps?...`, are covered by
  registration and frame-header rules. Stale registrations are refreshed.
- Offscreen listener readiness is checked before a scrape is dispatched.
  Creation and cleanup are serialized to prevent overlapping lifecycle actions.
- The hidden desktop-sized iframe processes requests serially, retries a
  profile at most twice, and recycles after 8 successful profiles or 2 minutes.
  Exhausted offscreen retries are not multiplied by the outer job retry loop.
- Pending work has cancellation cleanup and sends a heartbeat while waiting so
  the worker can continue the response/save flow. A 25-second profile wait
  accommodates slower Maps rendering; failure remains bounded and reported.
- Indian city/state/pincode parsing is corrected, and output Maps links are
  built from the requested Place ID.

The DOM extractor reads business name, phone, address, city, state, pincode,
website, rating, review count, category/categories, page-visible email, status
and Maps link. Availability depends on what the page exposes. Consent/CAPTCHA
pages are not bypassed; inability to load a profile is reported as a failure.

## Validation

- 115 Node tests passed (tests/TEST_RESULTS_10.15.2.txt).
- 11 dashboard/history Chromium checks passed (tests/BROWSER_RESULTS_10.15.2.txt).
- 7 Ghost Chromium checks passed (tests/GHOST_BROWSER_RESULTS_10.15.2.txt).
- All 68 JavaScript/test files passed Node syntax checks.

Ghost browser tests execute the shipped offscreen and frame scripts using real
cross-origin iframes, redirects, postMessage and MutationObserver. Google pages
and Chrome runtime entry points are controlled fixtures. They validate field
extraction, serial processing, retry bounds, origin rejection, cancellation,
renderer recycling and absence of visible extra tabs.

Limits tests execute the actual provider controller methods: Scrappa stays at
one page-0 call even for a 600-result target; Serper requests pages 1 through 7
for pincode searches when results continue. Existing dashboard, export,
account, backend and timer regression tests also pass.

Live Google Maps DOM, native extension content-script injection, authenticated
Google Places/Scrappa/Serper requests and account-specific restrictions have NOT
been verified in this environment. The fixture checks do not establish live
provider availability. Test a known Place ID after installing this build.

Run Node tests: `node --test tests/*.test.cjs`.
Browser scripts document their Playwright and Chromium requirements at the top.
Prior release notes/reports are historical; use the 10.15.2 reports above.

## Install without removing existing data

1. Stop scraping and close the dashboard. Export important data as a backup.
2. Extract this ZIP into the SAME unpacked extension folder, replacing its files.
3. In chrome://extensions, click Reload for PocketLeads, then reopen the dashboard.
4. Confirm version 10.15.2 and run a small Google Place-ID scrape first.

Do not uninstall the existing extension or clear its storage to update it.
No Apps Script redeployment is required for these changes.
