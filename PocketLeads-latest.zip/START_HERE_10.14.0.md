> Historical document. Current release: START_HERE_10.15.0.md.

# PocketLeads 10.14.0 — Two-engine failover and credit recovery

## Install BOTH parts

1. Back up the current Apps Script source and spreadsheet.
2. Replace the Apps Script source with this package's apps_script_code.js. Keep your existing SHEET_ID.
3. Deploy a NEW VERSION of the EXISTING web-app deployment (backend 36_failover_ledger). Keep the web-app URL. If the URL changes, update config/runtime.js.
4. Replace the unpacked extension folder with this full package, then Reload the same extension installation. Do not uninstall or clear saved data.
5. Reopen the dashboard. Start runs a fresh account check. Existing validated licenses and saved leads are preserved.

Extension files alone do not activate the backend fixes. No live deployment has been performed for you.

## Routing contract

- Auto selection prefers available Scrappa rows, then Serper, then Apify. After eligible structured rows fail, Google Maps Place-ID extraction is the fallback.
- Each query excludes already attempted rows. There is no fixed 30-row ceiling. A repeated row from the backend is rejected to prevent loops.
- Google-only batch searches rotate through Google rows using the same classification/rotation methods. They never send a Google payload to another provider.
- Session cooldowns survive resumable pauses. Temporary 429 uses a 60-second cooldown; other execution failures use a five-minute client cooldown. Server cooldowns also protect other sessions (60 seconds for 429; 30 seconds for service errors).
- A known HTTP 502/503/504 gets one short retry for non-actor operations; actor launches are never blindly retried.
- Provider quota/auth failures disable that provider row with diagnostic notes. An administrator must fix credentials/quota and re-enable genuinely blocked rows.
- A successful empty response is No Results, not a failed provider.
- Unknown transport completion pauses for reconciliation. It does not launch another paid provider on the assumption the first request failed.

## Customer credits versus administrator API quotas

Existing commercial policy is preserved: structured credits and Google Maps credits remain separate buckets, with existing purchase-credit allocation. This release does NOT migrate accounts into a shared wallet.

At initial preflight, an eligible engine with a positive bucket may be selected when another bucket is empty. During a running job, a confirmed customer credit-exhaustion response stops new paid requests and opens Buy Credits; it does not silently switch billing buckets mid-error. Top up, Refresh Balance, then Resume. In-flight completed results and saved progress remain available.

A provider's own quota/auth/rate-limit error never means that the customer's balance is zero. If all sources fail, the user gets service unavailability rather than a purchase demand.

Google credits continue to be charged for unique returned Place IDs, not only successfully extracted DOM profiles. Structured credits are charged for returned billable records. This preserves the existing units; it is not a new successful-lead-only pricing system.

## Purchase popup

Optional license-sheet column: Purchase URL. Set an HTTPS checkout/purchase link for the account. The popup uses that URL; without it, Buy Credits / Upgrade opens the configured support email. This package does not create a payment processor or payment webhook.

The popup shows both balances and offers Refresh Balance, Download Saved Results, and Close. Existing export entitlement/limit checks still apply. A top-up does not automatically restart a paid job: the user explicitly resumes after refreshing.

## Request receipts and duplicate charges

The current background scraper sends deterministic SHA-256 request IDs scoped to account/run/provider/row/operation/payload. Repeated requests replay stored responses; they do not repeat the provider call or debit. Polling an Apify run remains a live read. Paid adapter calls are serialized; Maps DOM consumers remain parallel.

The backend creates two PRIVATE sheets automatically:

- PocketLeadsRequests: payload hashes, pending/done/retryable states, timestamps and response chunks. Provider secrets are not stored, but responses contain scraped business data. Do not publish this sheet.
- PocketLeadsChargedLeads: run-scoped hashed business identities, used under the credit-accounting lock. The same Place ID is not charged twice across providers in a run. If no stable Place ID exists, exact normalized name + address is used. Records lacking either reliable identity are billed normally; universal fuzzy dedup is not claimed.

Completed receipt replays refresh the account snapshot from the server. Account/license authorization is checked before lookup. An inactive/expired license cannot use recovery to bypass authorization. New paid requests still undergo normal credit checks, including during recovery.

Legacy auxiliary integrations that omit request IDs retain their previous proxy compatibility; durable request idempotency is guaranteed only for the updated background scraper paths. Provider usage counters remain factual returned-result counters even when a duplicate lead's customer charge is refunded.

## Interrupted request recovery / operations

A timeout triggers a status lookup. Resume keeps the same run and provider row, and replays completed earlier requests until it reaches the pending request. The extension will not start unrelated paid work while a saved request remains unresolved.

Apps Script can terminate between reservation, network completion and receipt commit. Such a receipt intentionally remains pending; it is NOT automatically expired and rerun. If Resume remains pending, the administrator must inspect execution/provider logs and reconcile any reservation/result before resolving the receipt. Preserve the ledger and spreadsheet backup; deleting pending rows or clearing local pending state can permit duplicate work. A ledger write failure also pauses rather than being misclassified as an ordinary provider failure. Google Sheets is not a transactional payment database.

Keep receipts for runs that can still Resume. Archive only completed, non-resumable historical runs under your retention policy. Large histories increase spreadsheet storage and accounting work; production load testing is still required. Receipt lookup searches only its identity column and then loads one matching response.

## Verification and limits

79 automated tests passed, including actual backend dispatch/accounting with fake sheets and actual controller methods with mocked transports: >30-row exhaustion to Engine 2, Google rotation, empty results, quota versus customer errors, cooldown exclusions, concurrent adapter serialization, receipt replay/conflict/pending recovery, duplicate billing across engines, zero-credit preflight, top-up, and license-race regressions. 59 JavaScript/CJS files passed node --check. See tests/TEST_RESULTS.txt.

No real customer license, live paid-provider calls, live Google Maps DOM extraction, checkout, or deployed Apps Script end-to-end run was tested. Configure and smoke-test both engines against your own authorized providers after deployment. No claim of complete production certification is made.

The previously disclosed Full Data export extra-field/schema coverage issue is unchanged by this failover release. Earlier README/update documents are historical; this file describes the current release.
