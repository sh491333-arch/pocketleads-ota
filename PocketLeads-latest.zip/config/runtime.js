/* Shared runtime configuration. Version comes from manifest.json. */
globalThis.PocketLeadsConfig = Object.freeze({
  endpoint: "https://script.google.com/macros/s/AKfycbwkDaFqXqrcylo-dYkQvTTMhgKVJ4cwy5XiF3YNjqJQ7vdZlblOSJbBPJxncrLVFzokvw/exec",
  // Solution B: Optional Cloudflare Worker Edge URL (can be set here OR in apps_script_code.js CF_WORKER_URL)
  edgeProxyUrl: "https://pocketleads-edge.samimn7890.workers.dev/exec",
  supportEmail: 'samimn7890@gmail.com',
  requireManagedRouting: true,
  accountTimeoutMs: 25000,
  refreshMs: 180000,
  version: chrome.runtime.getManifest().version
});
