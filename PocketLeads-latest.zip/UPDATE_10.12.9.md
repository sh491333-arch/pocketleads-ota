> Historical document. Current release: START_HERE_10.15.0.md.

> Historical document. Current installation and behavior: START_HERE_10.14.0.md.

# PocketLeads 10.12.9 — Brand light dashboard

Changes:
- Warm peach page background based on the existing orange/charcoal logo; cream panels and stronger borders.
- Readable primary, secondary, destructive, disabled and keyboard-focus button states.
- Larger table labels, alternating warm rows, clearer filters, pagination and filter popovers.
- Unified legacy light-theme variables with the dashboard palette.
- Local SVG icon masks replace Unicode substitutions, preserving Angular interpolation text nodes and dynamic start/stop icons.
- Responsive input cards and reduced-motion support. Existing logo PNG files preserved; no source SVG logo was supplied.

Validation completed:
- Updated JavaScript syntax checks.
- Dashboard local asset references.
- Grid store insertion, duplicate prevention and updates.
- Byte comparison confirms extraction, billing, exports, background controllers and virtual grid logic are unchanged.
- Grid CSS retains existing 42px row height.

Limitations:
Browser rendering, interaction, theme persistence and mobile viewport checks could not run because Chromium was unavailable and its download timed out. Live extraction, external APIs and billing were not tested. This is not a full logic/security audit.

Install:
1. Extract this ZIP into a permanent folder.
2. Open chrome://extensions and enable Developer mode.
3. For the existing unpacked extension, replace files in its existing folder, then click Reload. This keeps its existing extension identity.
4. For a new install, select Load unpacked and select the folder containing manifest.json.
5. Open the dashboard, select light mode, and refresh any old dashboard tabs.

Before production use, check start/stop, disabled actions, table search/filter/clear, horizontal scrolling, page controls, theme persistence, and export with your own account.
