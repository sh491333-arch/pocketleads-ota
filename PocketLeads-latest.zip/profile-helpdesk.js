(function(){
'use strict';

const APPS_SCRIPT_URL=PocketLeadsConfig.endpoint;
const $=id=>document.getElementById(id);
let accountLoadPromise=null;
let ticketsLoadPromise=null;
let initialized=false;
let ticketAttachmentFile=null;
const MAX_ATTACHMENT_BYTES=5*1024*1024;
const ALLOWED_ATTACHMENT_EXTENSIONS=/\.(png|jpe?g|webp|pdf|txt|csv|log|docx?|xlsx?|zip)$/i;

function readLicense(){
  return new Promise(resolve=>{
    try{chrome.storage.local.get('license',r=>resolve(r&&r.license||null));}
    catch(_){resolve(null);}
  });
}

function parseSupportText(text,status=200){
  const clean=String(text||'').replace(/^\uFEFF/,'').trim();
  if(!clean) throw new Error(`Support service returned an empty response (HTTP ${status}).`);
  const candidates=[clean];
  const first=clean.indexOf('{'), last=clean.lastIndexOf('}');
  if(first>=0&&last>first)candidates.push(clean.slice(first,last+1));
  for(const candidate of candidates){
    try{
      const parsed=JSON.parse(candidate);
      if(parsed && typeof parsed==='object')return parsed;
      if(typeof parsed==='string'){try{return JSON.parse(parsed);}catch(_){}}
    }catch(_){}
  }
  const title=(clean.match(/<title[^>]*>([\s\S]*?)<\/title>/i)||[])[1];
  const hint=String(title||clean).replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim().slice(0,180);
  throw new Error(`Support service returned an unexpected response (HTTP ${status}).${hint?` ${hint}`:''}`);
}

function sendSupportViaRuntime(params,method='GET'){
  return new Promise((resolve,reject)=>{
    try{
      chrome.runtime.sendMessage({action:'pocketleads_support_request',method,params},response=>{
        const runtimeError=chrome.runtime.lastError;
        if(runtimeError)return reject(new Error(runtimeError.message||'Support transport unavailable.'));
        if(!response||!response.ok)return reject(new Error(response&&response.error||'Support transport unavailable.'));
        try{resolve(parseSupportText(response.text,response.status));}catch(error){reject(error);}
      });
    }catch(error){reject(error);}
  });
}

async function directSupportRequest(params,method='GET'){
  const url=new URL(APPS_SCRIPT_URL);
  const request={method,redirect:'follow',cache:'no-store',credentials:'omit'};
  if(method==='POST'){
    request.headers={'Content-Type':'text/plain;charset=utf-8','Accept':'application/json'};
    request.body=JSON.stringify(params);
  }else{
    Object.keys(params).forEach(key=>url.searchParams.set(key,params[key]==null?'':String(params[key])));
  }
  const controller=new AbortController();request.signal=controller.signal;
  const timer=setTimeout(()=>controller.abort(),PocketLeadsConfig.accountTimeoutMs);
  let response,text;
  try{response=await fetch(url.toString(),request);text=await response.text();}finally{clearTimeout(timer);}
  if(!response.ok)throw new Error(`Support service returned HTTP ${response.status}. Verify the Apps Script deployment URL and access settings.`);
  return parseSupportText(text,response.status);
}

async function backend(action,payload){
  const license=await readLicense();
  if(!license||!license.key||!license.installationId) throw new Error('Activate your licence before using Support Center.');
  const body=Object.assign({
    action,
    key:license.key,
    deviceId:license.installationId,
    user:license.userName||license.user||'',
    email:license.email||''
  },payload||{});

  // Service-worker transport is primary. It avoids cross-origin response and
  // Google Apps Script redirect edge cases in extension pages.
  const method=action==='submitticket'?'POST':'GET';
  let data;
  let firstError=null;
  try{data=await sendSupportViaRuntime(body,method);}catch(error){firstError=error;}
  if(!data){
    try{data=await directSupportRequest(body,method);}catch(error){
      const reason=error&&error.message?error.message:String(error||'');
      if(firstError && /unexpected|empty response/i.test(reason)) throw error;
      throw new Error('Unable to connect to the support service. Check your internet connection and try again.');
    }
  }
  if(!data||data.status!=='ok'){
    const reason=data&&(data.message||data.reason||data.error);
    throw new Error(reason||'Support service rejected the request.');
  }
  return data;
}

function setSupportStatus(message,error=false,success=false){
  const node=$('plSupportStatus');
  if(!node)return;
  node.textContent=message||'';
  node.classList.toggle('is-error',!!error);
  node.classList.toggle('is-success',!!message&&!error&&!!success);
}
function formatDate(value){
  if(!value)return '—';
  const date=new Date(value);
  if(Number.isNaN(date.getTime()))return String(value);
  return new Intl.DateTimeFormat(undefined,{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(date);
}
function statusClass(status){
  const s=String(status||'open').toLowerCase();
  if(/resolved|closed|complete|done/.test(s))return 'is-closed';
  if(/pending|progress|waiting|hold/.test(s))return 'is-pending';
  return 'is-open';
}
function validateAttachment(file){
  if(!file)return;
  if(file.size>MAX_ATTACHMENT_BYTES)throw new Error('Attachment must be 5 MB or smaller.');
  if(!ALLOWED_ATTACHMENT_EXTENSIONS.test(file.name||''))throw new Error('Unsupported attachment type. Use an image, PDF, text, CSV, log, Office file or ZIP.');
}
function updateAttachmentUI(file){
  const meta=$('plTicketAttachmentMeta'),name=$('plTicketAttachmentName'),drop=$('plTicketDropZone');
  if(meta){
    meta.hidden=!file;
  }
  if(name)name.textContent=file?`${file.name} (${Math.max(1,Math.ceil(file.size/1024)).toLocaleString()} KB)`:'';
  if(drop)drop.classList.toggle('has-file',!!file);
}
function selectAttachment(file){
  try{
    validateAttachment(file);
    ticketAttachmentFile=file||null;
    updateAttachmentUI(ticketAttachmentFile);
    setSupportStatus('');
  }catch(error){
    ticketAttachmentFile=null;
    const input=$('plTicketAttachment');if(input)input.value='';
    updateAttachmentUI(null);
    setSupportStatus(error.message,true);
  }
}
function resetTicketForm(form){
  if(form)form.reset();
  ticketAttachmentFile=null;
  updateAttachmentUI(null);
}
function readAttachment(file){
  if(!file)return Promise.resolve(null);
  validateAttachment(file);
  return new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onerror=()=>reject(new Error('Could not read the selected attachment.'));
    reader.onload=()=>{
      const value=String(reader.result||''),comma=value.indexOf(',');
      if(comma<0)return reject(new Error('Could not encode the selected attachment.'));
      resolve({attachmentName:file.name,attachmentType:file.type||'application/octet-stream',attachmentData:value.slice(comma+1)});
    };
    reader.readAsDataURL(file);
  });
}
function renderTickets(tickets){
  const root=$('plSupportTicketList'),count=$('plTicketCount');
  if(!root)return;
  const list=Array.isArray(tickets)?tickets.slice(0,50):[];
  root.textContent='';
  if(count)count.textContent=list.length?`${list.length} recent request${list.length===1?'':'s'}`:'No requests yet';
  if(!list.length){
    root.innerHTML='<div class="pl-empty-tickets"><div class="pl-empty-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v8A2.5 2.5 0 0 1 17.5 17H13l-3.4 3v-3H6.5A2.5 2.5 0 0 1 4 14.5v-8Z"/><path d="M8 9h8M8 12h5"/></svg></div><strong>No support tickets yet</strong><small>Tell us what you need and your request will appear here.</small></div>';
    return;
  }
  list.forEach(ticket=>{
    const row=document.createElement('button');
    row.type='button';row.className='pl-ticket-row';
    row.innerHTML='<div class="pl-ticket-main"><div class="pl-ticket-title"></div><div class="pl-ticket-meta"><span class="pl-ticket-id"></span><span class="pl-ticket-date"></span></div><div class="pl-ticket-preview"></div></div><div class="pl-ticket-side"><span class="pl-ticket-status-badge"></span><svg class="pl-ticket-chevron" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg></div>';
    row.querySelector('.pl-ticket-title').textContent=ticket.subject||'Support ticket';
    row.querySelector('.pl-ticket-id').textContent=ticket.id||'Ticket';
    row.querySelector('.pl-ticket-date').textContent=formatDate(ticket.timestamp);
    row.querySelector('.pl-ticket-preview').textContent=ticket.message||'No message';
    const badge=row.querySelector('.pl-ticket-status-badge');badge.textContent=ticket.status||'Open';badge.classList.add(statusClass(ticket.status));
    row.addEventListener('click',()=>showTicketDetail(ticket));
    root.appendChild(row);
  });
}
function showTicketDetail(ticket){
  const modal=$('plTicketDetailModal');if(!modal)return;
  $('plTicketDetailId').textContent=ticket.id||'—';
  $('plTicketDetailDate').textContent=formatDate(ticket.timestamp);
  $('plTicketDetailSubject').textContent=ticket.subject||'Support ticket';
  $('plTicketDetailMessage').textContent=ticket.message||'No message';
  const status=$('plTicketDetailStatus');status.textContent=ticket.status||'Open';status.className='pl-detail-status '+statusClass(ticket.status);
  $('plTicketDetailRemarks').textContent=ticket.remarks||'No reply yet. Our support team will update this ticket here.';
  const attachmentWrap=$('plTicketDetailAttachmentWrap'),attachmentLink=$('plTicketDetailAttachment');
  const attachmentUrl=/^https:\/\//i.test(String(ticket.attachment||''))?String(ticket.attachment):'';
  if(attachmentWrap)attachmentWrap.hidden=!attachmentUrl;
  if(attachmentLink){attachmentLink.href=attachmentUrl||'#';attachmentLink.textContent=attachmentUrl?'Open attachment':'No attachment';}
  modal.hidden=false;
  document.body.classList.add('pl-modal-open');
}
function closeTicketDetail(){
  const modal=$('plTicketDetailModal');if(modal)modal.hidden=true;
  if(!($('plSupportModal')&&!$('plSupportModal').hidden))document.body.classList.remove('pl-modal-open');
}
function setSupportModal(open){
  const modal=$('plSupportModal'),panel=$('plProfilePanel');if(!modal)return;
  modal.hidden=!open;
  if(open){
    if(panel)setPanelOpen(panel,false);
    document.body.classList.add('pl-modal-open');
    setTicketComposer(false);
    setSupportStatus('');
    loadTickets(true);
  }else{
    closeTicketDetail();
    setTicketComposer(false);
    setSupportStatus('');
    document.body.classList.remove('pl-modal-open');
  }
}
function setTicketComposer(open){
  const form=$('plTicketFormModal'),listView=$('plTicketListView'),body=document.querySelector('#plSupportModal .pl-support-body');
  if(form)form.hidden=!open;
  if(listView)listView.hidden=!!open;
  if(!open)resetTicketForm(form);
  if(body)body.scrollTop=0;
  if(open)requestAnimationFrame(()=>$('plTicketSubjectModal')?.focus());
}
function setPanelOpen(panel,open){if(!panel)return;panel.hidden=!open;panel.classList.toggle('is-open',open);const trigger=$('openProfilePanel');if(trigger)trigger.setAttribute('aria-expanded',String(!!open));}
async function loadTickets(force=false){
  if(ticketsLoadPromise)return ticketsLoadPromise;
  ticketsLoadPromise=(async()=>{
    const refresh=$('plTicketRefreshBtn');if(refresh)refresh.classList.add('is-loading');
    const count=$('plTicketCount'),root=$('plSupportTicketList');
    if(count)count.textContent='Loading requests…';
    if(root&&!root.children.length)root.innerHTML='<div class="pl-ticket-loading"><span></span><strong>Loading tickets</strong><small>Syncing your support history…</small></div>';
    try{const result=await backend('getsupporttickets');if($('plSupportStatus')?.classList.contains('is-error'))setSupportStatus('');renderTickets(result.tickets||[]);return result.tickets||[];}
    catch(error){setSupportStatus(error.message,true);if(count)count.textContent='Sync failed';if(root)root.innerHTML='<div class="pl-ticket-error"><strong>Could not load tickets</strong><small>You can still create a new ticket, or verify the Apps Script deployment and press Refresh.</small></div>';return[];}
    finally{if(refresh)refresh.classList.remove('is-loading');ticketsLoadPromise=null;}
  })();
  return ticketsLoadPromise;
}
function renderAccount(account,license){
  const a=account||{}, l=license||{};
  const fmt=v=>v==='unlimited'?'Unlimited':v==null?'Unavailable':Number(v).toLocaleString();
  const put=(id,text)=>{if($(id))$(id).textContent=text;};
  put('plCreditAvailable',fmt(a.availableCredit));
  put('plCreditTotal',fmt(a.purchasedCredit));
  put('plPlanName',a.plan||'Plan unavailable');
  put('plAccountStatus',a.syncState==='error'?'Refresh failed — Retry':l.active?(a.expiryDate?'Active until '+a.expiryDate:'License active'):'License inactive');
  put('plUserName',a.userName||l.userName||'PocketLeads User');
  const trigger=document.querySelector('.pl-profile-trigger-name');if(trigger)trigger.textContent=a.userName||'My Profile';
  const retry=$('plAccountRetry');if(retry)retry.hidden=a.syncState!=='error';
  const support=$('plAccountSupport');if(support)support.href='mailto:'+(a.supportEmail||PocketLeadsConfig.supportEmail);
  const upgrade=$('plAccountUpgrade');if(upgrade){let url;try{url=new URL(a.purchaseUrl);}catch(_){}upgrade.href=url?.protocol==='https:'?url.href:'mailto:'+(a.supportEmail||PocketLeadsConfig.supportEmail)+'?subject=PocketLeads%20credits%20and%20upgrade';}
}
async function loadAccount(force=false){
 if(accountLoadPromise)return accountLoadPromise;
 accountLoadPromise=(async()=>{
  const cached=await PocketLeadsAccount.read();renderAccount(cached.pocketleadsAccount,cached.license);
  if(!cached.license?.active)return;
  if(!force && cached.pocketleadsAccount?.syncState==='ready' && Date.now()-cached.pocketleadsAccount.syncedAt<30000)return;
  try{await PocketLeadsAccount.refresh();}catch(e){if($('plAccountStatus'))$('plAccountStatus').textContent=e.message;if($('plAccountRetry'))$('plAccountRetry').hidden=false;}
  const latest=await PocketLeadsAccount.read();renderAccount(latest.pocketleadsAccount,latest.license);
 })().finally(()=>{accountLoadPromise=null;});return accountLoadPromise;
}
if(typeof chrome!=='undefined'&&chrome.storage&&chrome.storage.onChanged){chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&(changes.pocketleadsAccount||changes.license))PocketLeadsAccount.read().then(v=>renderAccount(v.pocketleadsAccount,v.license));});}
async function submitModalTicket(event){
  event.preventDefault();
  const subject=$('plTicketSubjectModal')?.value.trim()||'';
  const message=$('plTicketMessageModal')?.value.trim()||'';
  if(subject.length<3){setSupportStatus('Please enter a subject of at least 3 characters.',true);$('plTicketSubjectModal')?.focus();return;}
  if(message.length<10){setSupportStatus('Please describe the issue with at least 10 characters.',true);$('plTicketMessageModal')?.focus();return;}
  const button=$('plTicketSubmitModal');if(button){button.disabled=true;button.classList.add('is-loading');}
  setSupportStatus('Submitting your ticket…');
  try{
    const requestId=(crypto&&crypto.randomUUID)?crypto.randomUUID():`req-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    const attachment=await readAttachment(ticketAttachmentFile);
    const result=await backend('submitticket',Object.assign({subject,message,requestId},attachment||{}));
    setTicketComposer(false);
    setSupportStatus(`Ticket ${result.ticketId||'created'} created successfully. Your reference is ${result.ticketId||'available in the list'}.`,false,true);
    await loadTickets(true);
  }catch(error){setSupportStatus(error.message,true);const body=document.querySelector('#plSupportModal .pl-support-body');if(body)body.scrollTo({top:0,behavior:'smooth'});}
  finally{if(button){button.disabled=false;button.classList.remove('is-loading');}}
}
function init(){
  if(initialized)return;initialized=true;
  const panel=$('plProfilePanel');
  if(!panel){initialized=false;setTimeout(init,100);return;}


// ============================================================================
// Admin Broadcast Notifications & Ads (Google Sheets Live Sync)
// ============================================================================
const ADMIN_SHEET_ID = '1nyVn-59Wu98UkIY8Alek5U9tMdYjteR8NZVrLC14oqY';
const NOTIF_STORAGE_KEY = 'pocketleadsAdminNotificationsV1';
const NOTIF_READ_KEY = 'pocketleadsReadNotifIdsV1';
let currentNotifications = [];
let readNotifIds = new Set();
let activeNotifFilter = 'all';
let notifLoading = false;

const DEFAULT_ADMIN_NOTIFICATIONS = [
  {
    id: 'pl-welcome-1017',
    title: 'PocketLeads Pro v10.17 — Emails & Socials Upgraded!',
    message: 'Click "Scrape Emails & Socials" above the table to automatically extract business emails plus Facebook, Instagram, LinkedIn, X/Twitter, and YouTube links.',
    type: 'update',
    ctaText: '',
    ctaUrl: '',
    imageUrl: '',
    createdAt: 'Just now'
  },
  {
    id: 'pl-offer-1017',
    title: 'Special Admin Offer — High-Speed Bulk Credits & Multi-PC Plan',
    message: 'Want to scale your agency outreach? Upgrade your licence for extra structured API credits and priority support directly from admin.',
    type: 'offer',
    ctaText: 'Contact Admin / Upgrade',
    ctaUrl: 'mailto:' + (PocketLeadsConfig.supportEmail || 'samimn7890@gmail.com') + '?subject=PocketLeads%20Pro%20Offer',
    imageUrl: '',
    createdAt: 'Featured Offer'
  }
];

function loadNotifStorage() {
  return new Promise(resolve => {
    try {
      chrome.storage.local.get([NOTIF_STORAGE_KEY, NOTIF_READ_KEY], res => {
        const saved = res && Array.isArray(res[NOTIF_STORAGE_KEY]) ? res[NOTIF_STORAGE_KEY] : [];
        const reads = res && Array.isArray(res[NOTIF_READ_KEY]) ? res[NOTIF_READ_KEY] : [];
        readNotifIds = new Set(reads.map(String));
        if (saved.length) currentNotifications = saved;
        else currentNotifications = DEFAULT_ADMIN_NOTIFICATIONS.slice();
        resolve();
      });
    } catch (e) {
      currentNotifications = DEFAULT_ADMIN_NOTIFICATIONS.slice();
      resolve();
    }
  });
}

function saveNotifStorage() {
  try {
    chrome.storage.local.set({
      [NOTIF_STORAGE_KEY]: currentNotifications,
      [NOTIF_READ_KEY]: [...readNotifIds]
    });
  } catch (e) {}
}

function normalizeNotifCategory(type) {
  const t = String(type || '').toLowerCase();
  if (/offer|ad|ads|promo|deal|discount|sale|sponsor/.test(t)) return 'offer';
  if (/important|urgent|alert|critical|warning/.test(t)) return 'important';
  return 'update';
}

function updateNotifBadgeUI() {
  const badge = $('plNotifBadge');
  const btn = $('openNotificationsBtn');
  if (!badge) { setTimeout(updateNotifBadgeUI, 150); return; }
  const unreadCount = currentNotifications.filter(n => n && n.id && !readNotifIds.has(String(n.id))).length;
  if (unreadCount > 0) {
    badge.hidden = false;
    badge.textContent = unreadCount > 9 ? '9+' : String(unreadCount);
    if (btn) btn.classList.add('has-unread');
  } else {
    badge.hidden = true;
    badge.textContent = '0';
    if (btn) btn.classList.remove('has-unread');
  }
}

function renderNotificationsList() {
  const listEl = $('plNotifList');
  if (!listEl) return;
  const filtered = currentNotifications.filter(item => {
    if (!item) return false;
    const cat = normalizeNotifCategory(item.type);
    if (activeNotifFilter === 'offer') return cat === 'offer';
    if (activeNotifFilter === 'update') return cat === 'update' || cat === 'important';
    return true;
  });

  if (!filtered.length) {
    listEl.innerHTML = '<div class="pl-notif-empty"><strong>No notifications in this tab</strong><small>New offers, ads &amp; important updates from Admin Google Sheets will appear here.</small></div>';
    return;
  }

  listEl.innerHTML = '';
  filtered.forEach(item => {
    const id = String(item.id || item.title || '');
    const isUnread = !readNotifIds.has(id);
    const cat = normalizeNotifCategory(item.type);
    const badgeLabel = cat === 'offer' ? '🔥 SPECIAL OFFER / AD' : (cat === 'important' ? '⚡ IMPORTANT UPDATE' : '✨ NEW UPDATE');

    const card = document.createElement('article');
    card.className = 'pl-notif-card is-' + cat + (isUnread ? ' is-unread' : '');
    const topRow = document.createElement('div');
    topRow.className = 'pl-notif-card-top';

    const tag = document.createElement('span');
    tag.className = 'pl-notif-type-pill is-' + cat;
    tag.textContent = badgeLabel;
    topRow.appendChild(tag);

    const rightMeta = document.createElement('div');
    rightMeta.className = 'pl-notif-meta-right';
    if (item.createdAt) {
      const timeSpan = document.createElement('span');
      timeSpan.className = 'pl-notif-date';
      timeSpan.textContent = formatDate(item.createdAt);
      rightMeta.appendChild(timeSpan);
    }
    if (isUnread) {
      const dot = document.createElement('span');
      dot.className = 'pl-notif-unread-dot';
      dot.title = 'Unread';
      rightMeta.appendChild(dot);
    }
    topRow.appendChild(rightMeta);
    card.appendChild(topRow);

    const titleEl = document.createElement('h4');
    titleEl.className = 'pl-notif-card-title';
    titleEl.textContent = item.title || 'Announcement';
    card.appendChild(titleEl);

    if (item.message) {
      const msgEl = document.createElement('p');
      msgEl.className = 'pl-notif-card-msg';
      msgEl.textContent = item.message;
      card.appendChild(msgEl);
    }

    if (item.imageUrl && /^https?:\/\//i.test(String(item.imageUrl).trim())) {
      const imgWrap = document.createElement('div');
      imgWrap.className = 'pl-notif-banner-wrap';
      const img = document.createElement('img');
      img.className = 'pl-notif-banner-img';
      img.src = String(item.imageUrl).trim();
      img.alt = item.title || 'Notification banner';
      img.loading = 'lazy';
      img.onerror = () => { imgWrap.style.display = 'none'; };
      imgWrap.appendChild(img);
      card.appendChild(imgWrap);
    }

    if (item.ctaUrl && /^(https?:\/\/|mailto:)/i.test(String(item.ctaUrl).trim())) {
      const cta = document.createElement('a');
      cta.className = 'pl-notif-cta-btn is-' + cat;
      cta.href = String(item.ctaUrl).trim();
      cta.target = '_blank';
      cta.rel = 'noopener noreferrer';
      cta.textContent = item.ctaText || (cat === 'offer' ? 'Claim Offer →' : 'Learn More →');
      cta.addEventListener('click', () => {
        readNotifIds.add(id);
        saveNotifStorage();
        updateNotifBadgeUI();
        card.classList.remove('is-unread');
      });
      card.appendChild(cta);
    }

    card.addEventListener('click', () => {
      if (!readNotifIds.has(id)) {
        readNotifIds.add(id);
        saveNotifStorage();
        updateNotifBadgeUI();
        card.classList.remove('is-unread');
        const d = card.querySelector('.pl-notif-unread-dot');
        if (d) d.remove();
      }
    });

    listEl.appendChild(card);
  });
}

async function fetchDirectSheetNotificationsFallback() {
  // Fallback: if the Google Sheet has a 'Notifications' tab shared for viewing, parse via Google Visualization JSON
  const gvizUrl = `https://docs.google.com/spreadsheets/d/${ADMIN_SHEET_ID}/gviz/tq?tqx=out:json&sheet=Notifications`;
  const resp = await fetch(gvizUrl, { method: 'GET', cache: 'no-store', credentials: 'omit' });
  if (!resp.ok) throw new Error('Sheet gviz unavailable');
  const text = await resp.text();
  const match = text.match(/google\.visualization\.Query\.setResponse\(([\s\S]+)\);?\s*$/);
  if (!match) throw new Error('Invalid gviz format');
  const json = JSON.parse(match[1]);
  const table = json && json.table;
  if (!table || !Array.isArray(table.rows) || !table.rows.length) return [];
  const cols = (table.cols || []).map(c => String((c && c.label) || '').trim().toLowerCase().replace(/[^a-z0-9]/g, ''));
  const cellVal = (row, idx) => (row && row.c && row.c[idx] && (row.c[idx].f || row.c[idx].v) != null) ? String(row.c[idx].f || row.c[idx].v).trim() : '';
  const hasHeaders = cols.some(Boolean);
  const idx = (names, fb) => {
    if (hasHeaders) {
      for (const n of names) { const p = cols.indexOf(n); if (p >= 0) return p; }
    }
    return fb;
  };
  const out = [];
  table.rows.forEach((r, i) => {
    const title = cellVal(r, idx(['title', 'heading', 'subject'], 1));
    const message = cellVal(r, idx(['message', 'body', 'description'], 2));
    if (!title && !message) return;
    if (/^(title|heading)$/i.test(title) && /^(message|body|description)$/i.test(message)) return;
    const active = cellVal(r, idx(['active', 'status', 'enabled'], 7)).toLowerCase();
    if (/^(no|false|0|off|inactive|disabled|hidden)$/.test(active)) return;
    out.push({
      id: cellVal(r, idx(['id', 'notifid'], 0)) || ('sheet-' + i),
      title: title || 'Announcement',
      message,
      type: cellVal(r, idx(['type', 'category', 'tag'], 3)) || 'update',
      ctaText: cellVal(r, idx(['ctatext', 'buttontext', 'button'], 4)),
      ctaUrl: cellVal(r, idx(['ctaurl', 'url', 'link'], 5)),
      imageUrl: cellVal(r, idx(['imageurl', 'image', 'banner'], 6)),
      createdAt: cellVal(r, idx(['createdat', 'date', 'timestamp'], 8))
    });
  });
  return out.reverse();
}

async function syncAdminNotifications(force = false) {
  if (notifLoading) return;
  notifLoading = true;
  const refreshBtn = $('plNotifRefreshBtn');
  const syncLbl = $('plNotifSyncLabel');
  if (refreshBtn) refreshBtn.classList.add('is-loading');
  if (syncLbl && force) syncLbl.textContent = 'Syncing with Admin Google Sheet…';
  try {
    let fetched = null;
    try {
      const res = await sendSupportViaRuntime({ action: 'getnotifications' }, 'GET');
      if (res && Array.isArray(res.notifications) && res.notifications.length) fetched = res.notifications;
    } catch (e) {}
    if (!fetched) {
      try {
        const res2 = await directSupportRequest({ action: 'getnotifications' }, 'GET');
        if (res2 && Array.isArray(res2.notifications) && res2.notifications.length) fetched = res2.notifications;
      } catch (e) {}
    }
    if (!fetched) {
      try {
        const gvizItems = await fetchDirectSheetNotificationsFallback();
        if (Array.isArray(gvizItems) && gvizItems.length) fetched = gvizItems;
      } catch (e) {}
    }
    if (Array.isArray(fetched) && fetched.length) {
      currentNotifications = fetched;
      saveNotifStorage();
      if (syncLbl) syncLbl.textContent = 'Synced with Admin Google Sheet · ' + fetched.length + ' active';
    } else {
      if (!currentNotifications.length) currentNotifications = DEFAULT_ADMIN_NOTIFICATIONS.slice();
      if (syncLbl) syncLbl.textContent = 'Admin Broadcasts · Google Sheets Ready';
    }
  } catch (e) {
    if (syncLbl) syncLbl.textContent = 'Admin Broadcasts · Offline Cache';
  } finally {
    notifLoading = false;
    if (refreshBtn) refreshBtn.classList.remove('is-loading');
    updateNotifBadgeUI();
    renderNotificationsList();
  }
}

function setNotifPanelOpen(open) {
  const notifPanel = $('plNotificationsPanel');
  const profilePanel = $('plProfilePanel');
  const trigger = $('openNotificationsBtn');
  if (!notifPanel) return;
  notifPanel.hidden = !open;
  notifPanel.classList.toggle('is-open', !!open);
  if (trigger) trigger.setAttribute('aria-expanded', String(!!open));
  if (open) {
    if (profilePanel && !profilePanel.hidden) setPanelOpen(profilePanel, false);
    renderNotificationsList();
    syncAdminNotifications(false);
  }
}

  loadNotifStorage().then(() => {
    updateNotifBadgeUI();
    renderNotificationsList();
    syncAdminNotifications(false);
  });

  // Navbar is rendered asynchronously through Angular ng-include.
  // Use delegated handling so the profile trigger always works even when
  // the button is inserted after this script has initialised.
  document.addEventListener('click',function(e){
    const notifTrigger=e.target.closest && e.target.closest('#openNotificationsBtn');
    const notifPanel=$('plNotificationsPanel');
    if(notifTrigger && notifPanel){
      e.preventDefault();
      e.stopPropagation();
      setNotifPanelOpen(notifPanel.hidden);
      return;
    }

    const notifTab=e.target.closest && e.target.closest('[data-notif-filter]');
    if(notifTab && notifPanel && notifPanel.contains(notifTab)){
      e.preventDefault();
      e.stopPropagation();
      activeNotifFilter=notifTab.getAttribute('data-notif-filter')||'all';
      notifPanel.querySelectorAll('.pl-notif-tab').forEach(btn=>btn.classList.toggle('is-active',btn===notifTab));
      renderNotificationsList();
      return;
    }

    const trigger=e.target.closest && e.target.closest('#openProfilePanel');
    if(trigger){
      e.preventDefault();
      e.stopPropagation();
      if(notifPanel&&!notifPanel.hidden)setNotifPanelOpen(false);
      const shouldOpen=panel.hidden;
      setPanelOpen(panel,shouldOpen);
      if(shouldOpen)loadAccount();
      return;
    }

    const openTrigger=$('openProfilePanel');
    if(panel&&!panel.hidden&&!panel.contains(e.target)&&e.target!==openTrigger)setPanelOpen(panel,false);
    const openNotifBtn=$('openNotificationsBtn');
    if(notifPanel&&!notifPanel.hidden&&!notifPanel.contains(e.target)&&e.target!==openNotifBtn)setNotifPanelOpen(false);
  });
  document.addEventListener('click',event=>{
    const item=event.target.closest('[data-profile-action]');if(!item||!panel.contains(item))return;
    event.preventDefault();event.stopPropagation();
    const action=item.getAttribute('data-profile-action');
    if(action==='close'){setPanelOpen(panel,false);return;}
    panel.querySelectorAll('.pl-profile-menu-item').forEach(btn=>btn.classList.toggle('is-active',btn===item));
    if(action==='profile'){loadAccount();return;}
    if(action==='support'){setSupportModal(true);return;}
    if(action==='settings'){window.open(chrome.runtime.getURL('settings-page.html'),'_blank');setPanelOpen(panel,false);return;}
    if(action==='privacy'){window.open(chrome.runtime.getURL('views/privacy.html'),'_blank');setPanelOpen(panel,false);return;}
    if(action==='terms'){window.open(chrome.runtime.getURL('views/terms.html'),'_blank');setPanelOpen(panel,false);return;}
    if(action==='guide'){const guideUrl=window.POCKETLEADS_GUIDE_URL||'';if(guideUrl){window.open(guideUrl,'_blank','noopener');setPanelOpen(panel,false);}else{setSupportStatus('Guide video is not configured for this build.');}return;}
    if(action==='logout'){$('logoutButtonModal')?.click();setPanelOpen(panel,false);return;}
  });
  $('plNotifCloseBtn')?.addEventListener('click',()=>setNotifPanelOpen(false));
  $('plNotifRefreshBtn')?.addEventListener('click',()=>syncAdminNotifications(true));
  $('plNotifMarkReadBtn')?.addEventListener('click',()=>{
    currentNotifications.forEach(n=>{if(n&&n.id)readNotifIds.add(String(n.id));});
    saveNotifStorage();
    updateNotifBadgeUI();
    renderNotificationsList();
  });
  $('plNewTicketBtn')?.addEventListener('click',()=>{setSupportStatus('');setTicketComposer(true);});
  $('plTicketRefreshBtn')?.addEventListener('click',()=>loadTickets(true));
  $('plTicketFormModal')?.addEventListener('submit',submitModalTicket);
  $('plTicketFormModal')?.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();setTicketComposer(false);setSupportStatus('');}});
  $('plTicketCancelModal')?.addEventListener('click',()=>{setTicketComposer(false);setSupportStatus('');});
  $('plTicketFormCloseBtn')?.addEventListener('click',()=>{setTicketComposer(false);setSupportStatus('');});
  const attachmentInput=$('plTicketAttachment'),dropZone=$('plTicketDropZone');
  attachmentInput?.addEventListener('change',()=>selectAttachment(attachmentInput.files&&attachmentInput.files[0]));
  dropZone?.addEventListener('click',event=>{event.preventDefault();attachmentInput?.click();});
  dropZone?.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();attachmentInput?.click();}});
  ['dragenter','dragover'].forEach(type=>dropZone?.addEventListener(type,event=>{event.preventDefault();dropZone.classList.add('is-dragging');}));
  ['dragleave','drop'].forEach(type=>dropZone?.addEventListener(type,event=>{event.preventDefault();dropZone.classList.remove('is-dragging');if(type==='drop')selectAttachment(event.dataTransfer&&event.dataTransfer.files&&event.dataTransfer.files[0]);}));
  $('plTicketAttachmentRemove')?.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();ticketAttachmentFile=null;if(attachmentInput)attachmentInput.value='';updateAttachmentUI(null);});
  $('plSupportCloseBtn')?.addEventListener('click',()=>setSupportModal(false));
  $('plSupportBackdrop')?.addEventListener('click',()=>setSupportModal(false));
  $('plTicketDetailClose')?.addEventListener('click',closeTicketDetail);
  $('plTicketDetailBackdrop')?.addEventListener('click',closeTicketDetail);
  document.addEventListener('keydown',e=>{
    if(e.key!=='Escape')return;
    if($('plTicketDetailModal')&&!$('plTicketDetailModal').hidden)closeTicketDetail();
    else if($('plSupportModal')&&!$('plSupportModal').hidden)setSupportModal(false);
    else if(!panel.hidden)setPanelOpen(panel,false);
  });
  $('plAccountRetry')?.addEventListener('click',()=>loadAccount(true));
  window.addEventListener('focus',()=>loadAccount(true));
  loadAccount();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
