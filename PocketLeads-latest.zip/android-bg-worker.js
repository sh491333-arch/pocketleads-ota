/*
 * PocketLeads PRO Android OTA Worker Entrypoint (v3)
 */
importScripts('/chrome-ota-patch.js');
importScripts('/controllers/background.js');
if (typeof self.__notifyPlWorkerReady === 'function') {
  self.__notifyPlWorkerReady();
}
