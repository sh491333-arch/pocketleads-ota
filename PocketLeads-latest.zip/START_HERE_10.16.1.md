# PocketLeads 10.16.1 — full extension + single-file Apps Script

This incremental update includes the complete extension and the updated
`apps_script_code.js`. Existing licence/device/expiry logic remains in that
file. **Copy the entire file into Code.gs; no separate managed.gs is needed.**

## Aapko kya deploy karna hai

1. Existing Apps Script project ka backup lein. `Code.gs` mein root folder ka
   **poora apps_script_code.js** paste karein. Agar purana separate `managed.gs`
   install kiya tha, backup ke baad uski duplicate PocketLeads definitions hata
   dein. Unrelated scripts preserve karein.
2. Services mein **Google Sheets API v4**, identifier **Sheets**, enable karein.
   Manifest settings ke liye `backend/appsscript.json` reference hai.
3. Editor se `setupPocketLeadsManaged()` run karein. Existing `User & API
   Assignment` aur `API Key Management` tabs reuse honge; balances reset nahi
   honge. Required cache triggers aur durable journals configure honge.
4. Script Properties mein **PL2_BILLING** configure karein. Format
   `backend/billing-policy.example.json` mein hai. Apne actual provider billing
   ke reserve/success/failure units verify karke confirmed=true karein.
   Template disabled hai; missing/unconfirmed policy par paid calls stop honge.
5. Ghost Mode pehle chalane ke liye user ki **Provider Priority** mein
   `google_place,serper,scrappa` rakhein. **Maps API IDs** mein us user's assigned
   ID, e.g. `GM001`, ho; API Key Management mein matching active Google Places
   key ho. Positive Available Credit aur valid activated licence required hain.
   Sirf UI mein Google select karna server-side provider priority ko override
   nahi karta.
6. Existing web-app deployment ko **New version** se update karein, same URL
   retain karein. Phir existing extension directory mein ZIP ke files replace
   karke `chrome://extensions` se Reload karein. Extension uninstall na karein.
7. Management workbook ki sharing **Restricted** rakhein. Inspection mein
   "Anyone with the link — no sign-in required" sharing enabled thi.

Full configuration/recovery details: `backend/DEPLOYMENT.md`.

## Ghost result delivery fixes

- Places API se IDs; existing hidden offscreen iframe se business details.
- Phone fields, Place ID, CID, Maps URL and scrape timestamp dashboard/CSV ke
  canonical fields mein save hote hain. Empty profile success nahi maana jata.
- Profile ko saved mark karne se pehle actual persistence verify hoti hai.
- Saved job label ke peeche missing IndexedDB row ho toh Resume usko recover
  karta hai. Already persisted Place IDs dobara extract nahi hote.
- Stop unfinished query ko queue se remove nahi karta.
- Resume ka paid-request ID stable rehta hai even if UI run ID changes.
- Final task complete hone par API/producer/consumer counters settle hote hain;
  finished extraction false "paused" state mein nahi atakti.
- Progressive rows dashboard grid mein aati hain aur reopen par actual saved
  IndexedDB rows hydrate hoti hain.

## Validation

159 automated tests and 33 local Chromium fixture checks passed. The new Ghost
delivery browser test runs the shipped controller, save method, real IndexedDB
and real dashboard grid, with controlled Place-ID/profile inputs. Separate
hidden-frame tests exercise postMessage, MutationObserver and bounded retry.

**Real Google Maps and paid provider calls were not tested live.** Google may
change page markup or block framing/access. The extension reports profile-load,
consent or CAPTCHA failures instead of creating false result rows. Use a small
permitted live query after deployment before a larger run. No live deployment
was performed; you will deploy this package yourself.

Older START_HERE and report files are historical. This document supersedes the
two-file installation instructions in 10.16.0.
