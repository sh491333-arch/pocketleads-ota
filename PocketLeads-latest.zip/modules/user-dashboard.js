(function (g) {
  'use strict';

  // MODULE 2: USER DASHBOARD UI & REAL-TIME DELIVERY ENGINE
  const S = () => g.PocketLeadsShared;
  const DISMISSED_NOTIF_KEY = 'pl_dismissed_rich_notif_id_v1';
  const PENDING_GUIDE_KEY = 'pl_show_login_guide_pending';

  // 1. APK Usage Instructions Dashboard — Shown after EVERY successful OTP login!
  let obStep = 0;
  function renderObStep() {
    const slides = document.querySelectorAll('#plOnboardingModal .pl-ob-slide');
    const dots = document.querySelectorAll('#plOnboardingModal .pl-ob-dot');
    const nextBtn = document.getElementById('plObNextBtn');
    slides.forEach((s, i) => { s.hidden = i !== obStep; });
    dots.forEach((d, i) => { d.classList.toggle('is-active', i === obStep); });
    if (nextBtn) nextBtn.textContent = obStep >= 2 ? "Start Using App" : 'Next →';
  }

  function openUsageInstructions() {
    const modal = document.getElementById('plOnboardingModal');
    if (!modal) return;
    obStep = 0;
    renderObStep();
    modal.hidden = false;
  }

  function closeUsageInstructions() {
    const modal = document.getElementById('plOnboardingModal');
    if (modal) modal.hidden = true;
    try { localStorage.removeItem(PENDING_GUIDE_KEY); } catch (_) {}
    if (S()) S().haptic('success');
  }

  // 2. Android Big-Picture Floating Notification Card (Exact sample layout from image_d83c43.jpg!)
  //    + Real Native Android System Notification bridge (`AndroidChromeBridge.showRichNotification`)
  function showBigPictureNotificationPopup(notif) {
    if (!notif || !notif.id) return;
    try {
      if (localStorage.getItem(DISMISSED_NOTIF_KEY) === String(notif.id)) return;
    } catch (_) {}

    const card = document.getElementById('plBigPicNotifCard');
    if (!card) return;
    const tEl = document.getElementById('plBigPicTitle');
    const mEl = document.getElementById('plBigPicMsg');
    const timeEl = document.getElementById('plBigPicTime');
    const imgWrap = document.getElementById('plBigPicImgWrap');
    const imgEl = document.getElementById('plBigPicImg');
    const viewBtn = document.getElementById('plBigPicViewBtn');

    if (tEl) tEl.textContent = notif.title || 'New Alert';
    if (mEl) mEl.textContent = notif.message || '';
    if (timeEl) timeEl.textContent = notif.timeLabel || 'now';
    const imgUrl = String(notif.imageUrl || notif.image || '').trim();
    if (imgUrl && imgWrap && imgEl) {
      imgEl.src = imgUrl;
      imgWrap.hidden = false;
    } else if (imgWrap) {
      imgWrap.hidden = true;
    }
    card.dataset.notifId = String(notif.id);
    card.dataset.ctaUrl = String(notif.ctaUrl || imgUrl || '');
    if (viewBtn) viewBtn.textContent = notif.ctaText || 'View';
    card.hidden = false;
    if (S()) S().haptic('success');

    // Also fire REAL Android System Big-Picture Notification in status bar on APK!
    try {
      if (g.AndroidChromeBridge && typeof g.AndroidChromeBridge.showRichNotification === 'function') {
        const sentKey = 'pl_native_notif_sent_' + String(notif.id);
        if (!localStorage.getItem(sentKey)) {
          localStorage.setItem(sentKey, '1');
          g.AndroidChromeBridge.showRichNotification(
            String(notif.title || 'PocketLeads Alert'),
            String(notif.message || ''),
            imgUrl,
            String(notif.ctaUrl || '')
          );
        }
      }
    } catch (_) {}
  }

  // Real Cross-Device Notification & Broadcast Sync (runs on launch, focus, and every 60s on APK & EXE!)
  async function syncLiveNotificationsAndBroadcast() {
    if (!S()) return;
    try {
      const [bcRes, notifRes] = await Promise.allSettled([
        S().postApi('getBroadcastBanner', {}),
        fetch(S().getApiBase() + '?action=getnotifications', { method: 'GET' }).then(r => r.json())
      ]);

      // 1) Check Broadcast Banner
      const banner = (bcRes.status === 'fulfilled' && bcRes.value && bcRes.value.banner) ? bcRes.value.banner : null;
      const bcBox = document.getElementById('plBroadcastBanner');
      if (bcBox) {
        if (banner && banner.active && localStorage.getItem('pl_dismissed_broadcast_id') !== banner.id) {
          bcBox.className = 'pl-broadcast-banner is-' + (banner.tone || 'orange');
          const tEl = document.getElementById('plBroadcastTitle');
          const mEl = document.getElementById('plBroadcastMsg');
          if (tEl) tEl.textContent = banner.title || 'Announcement';
          if (mEl) mEl.textContent = banner.message || '';
          bcBox.dataset.bcId = banner.id;
          bcBox.hidden = false;
        } else {
          bcBox.hidden = true;
        }
      }

      // 2) Check Latest Rich Notification (Text + Photo) -> Show Big-Picture Popup matching sample!
      const notifs = (notifRes.status === 'fulfilled' && notifRes.value && Array.isArray(notifRes.value.notifications))
        ? notifRes.value.notifications : [];
      if (notifs.length) {
        const latest = notifs[0];
        const nid = String(latest.id || latest.ID || '');
        const title = String(latest.title || latest.Title || '');
        const message = String(latest.message || latest.Message || '');
        const imageUrl = String(latest.imageUrl || latest.Image_URL || latest.image || '');
        const ctaText = String(latest.ctaText || latest.CTA_Text || 'View');
        const ctaUrl = String(latest.ctaUrl || latest.CTA_URL || '');
        if (nid && (title || message)) {
          showBigPictureNotificationPopup({ id: nid, title, message, imageUrl, ctaText, ctaUrl, timeLabel: 'now' });
        }
      }
    } catch (_) {}
  }

  // 3. Cloudflare PL_KV 7-Day Credit Usage Chart (Accurate across devices & strictly isolated per active user!)
  async function renderKv7DayChart(containerId, overridePhone) {
    const el = document.getElementById(containerId);
    if (!el || !S()) return;
    try {
      const ctx = await S().getActiveUserContext();
      const targetPhone = overridePhone || ctx.phone10 || ctx.key;
      let res = null;
      if (!overridePhone && S().prefetchCache.credit7d && S().prefetchCache.credit7d.user === targetPhone) {
        res = S().prefetchCache.credit7d;
      } else if (targetPhone) {
        res = await S().postApi('getCreditUsage7d', { key: ctx.key, phone: targetPhone, targetPhone });
      }
      const days = (res && Array.isArray(res.days) && res.days.length) ? res.days : [
        { label: 'Mon', used: 0 }, { label: 'Tue', used: 0 }, { label: 'Wed', used: 0 },
        { label: 'Thu', used: 0 }, { label: 'Fri', used: 0 }, { label: 'Sat', used: 0 }, { label: 'Sun', used: 0 }
      ];
      const maxV = Math.max(10, ...days.map(d => Number(d.used) || 0));
      const total7 = days.reduce((a, d) => a + (Number(d.used) || 0), 0);
      el.innerHTML =
        '<div class="pl-chart-head"><span>7-Day Credit Usage (Cloud Sync)</span><strong>' + total7.toLocaleString('en-IN') + ' used</strong></div>' +
        '<div class="pl-chart-bars">' +
        days.map((d, idx) => {
          const v = Number(d.used) || 0;
          const h = Math.max(8, Math.round((v / maxV) * 100));
          const isToday = idx === days.length - 1;
          return '<div class="pl-chart-col">' +
            '<div class="pl-chart-bar-wrap"><div class="pl-chart-bar' + (isToday ? ' is-today' : '') + '" style="height:' + h + '%;" title="' + d.label + ': ' + v + '"></div></div>' +
            '<span class="pl-chart-lbl">' + S().esc(d.label) + '</span></div>';
        }).join('') +
        '</div>';
    } catch (_) {}
  }

  // 4. Sync Active User's Own Assigned Partner into Profile Drawer (Zero leak from Super Admin!)
  async function syncProfileAssignedPartner() {
    if (!S()) return;
    const ctx = await S().getActiveUserContext();
    const acc = ctx.account || {};
    const row = document.getElementById('plAssignedPartnerRow');
    const val = document.getElementById('plAssignedPartnerVal');
    if (row && val) {
      const pName = String(acc.assignedPartnerName || '').trim();
      const pPhone = String(acc.assignedPartnerPhone || '').trim();
      if (pName || pPhone) {
        val.textContent = pPhone && pName !== pPhone ? (pName + ' (' + pPhone + ')') : (pName || pPhone);
        row.hidden = false;
      } else {
        val.textContent = 'Direct (PocketLeads)';
        row.hidden = false;
      }
    }
  }

  // 5. Native Swipe-Down Gesture on Rounded Profile Bottom Sheet
  function initSwipeDownProfileSheet() {
    const sheet = document.querySelector('.pl-profile-sheet, .pl-profile-dropdown, #plProfileDropdown, #plProfileMenu');
    if (!sheet || sheet.__plSwipeBound) return;
    sheet.__plSwipeBound = true;
    let startY = 0, dy = 0, active = false;
    sheet.addEventListener('touchstart', (e) => {
      if (sheet.scrollTop <= 2 && e.touches && e.touches.length === 1) {
        startY = e.touches[0].clientY;
        active = true;
        dy = 0;
      }
    }, { passive: true });
    sheet.addEventListener('touchmove', (e) => {
      if (!active || !e.touches || !e.touches.length) return;
      dy = e.touches[0].clientY - startY;
      if (dy > 8 && sheet.scrollTop <= 2) {
        sheet.style.transform = 'translateY(' + Math.min(220, dy) + 'px)';
      }
    }, { passive: true });
    sheet.addEventListener('touchend', () => {
      if (!active) return;
      active = false;
      sheet.style.transform = '';
      if (dy > 85) {
        const closeBtn = document.querySelector('#plProfileCloseBtn, .pl-profile-close, [data-profile-close]');
        if (closeBtn) closeBtn.click();
      }
    }, { passive: true });
  }

  // 6. Live Extraction Speed & ETA Meter
  let extStartTs = 0, lastLeadCount = 0;
  function fmtEta(sec) {
    if (!Number.isFinite(sec) || sec <= 0 || sec > 36000) return '--';
    const m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m > 0 ? (m + 'm ' + s + 's') : (s + 's');
  }
  function updateSpeedEta() {
    const box = document.getElementById('plLiveSpeedEtaBar');
    if (!box) return;
    let leads = 0, pct = 0, running = false;
    try {
      const sc = g.angular && document.body ? g.angular.element(document.body).scope() : null;
      if (sc) {
        leads = Array.isArray(sc.allLeads) ? sc.allLeads.length : (Number(sc.extractedCount) || 0);
        pct = Number(sc.progressPercent) || 0;
        running = !!(sc.isExtracting || sc.extracting || sc.scraping);
      }
    } catch (_) {}
    if ((leads > lastLeadCount || running) && !extStartTs) extStartTs = Date.now();
    if (!running && leads === 0) { extStartTs = 0; lastLeadCount = 0; }
    lastLeadCount = leads;
    if (leads > 0 || running) {
      box.hidden = false;
      const elSec = Math.max(1, (Date.now() - (extStartTs || Date.now())) / 1000);
      const lpm = Math.round((leads / elSec) * 60);
      const eta = (pct > 2 && pct < 100) ? ((elSec / pct) * (100 - pct)) : 0;
      const sp = document.getElementById('plEtaSpeedVal');
      const tm = document.getElementById('plEtaElapsedVal');
      const et = document.getElementById('plEtaRemainVal');
      if (sp) sp.textContent = lpm + ' / min';
      if (tm) tm.textContent = fmtEta(elSec);
      if (et) et.textContent = pct >= 100 ? 'Done' : (eta > 0 ? ('~' + fmtEta(eta)) : 'Active');
    } else {
      box.hidden = true;
    }
  }

  function initUserDashboardModule() {
    // Bind Big-Picture Notification Card buttons (View, Dismiss, Collapse ^)
    const dismissBtn = document.getElementById('plBigPicDismissBtn');
    const collapseBtn = document.getElementById('plBigPicCollapseBtn');
    const viewBtn = document.getElementById('plBigPicViewBtn');
    const dismissBigPic = () => {
      const card = document.getElementById('plBigPicNotifCard');
      if (!card) return;
      try { if (card.dataset.notifId) localStorage.setItem(DISMISSED_NOTIF_KEY, card.dataset.notifId); } catch (_) {}
      card.hidden = true;
    };
    if (dismissBtn) dismissBtn.addEventListener('click', dismissBigPic);
    if (collapseBtn) collapseBtn.addEventListener('click', dismissBigPic);
    if (viewBtn) {
      viewBtn.addEventListener('click', () => {
        const card = document.getElementById('plBigPicNotifCard');
        const url = card ? String(card.dataset.ctaUrl || '') : '';
        dismissBigPic();
        if (url && /^https?:\/\//i.test(url)) {
          window.open(url, '_blank');
        } else {
          const bell = document.getElementById('openNotificationsBtn');
          if (bell) bell.click();
        }
      });
    }

    // Bind Broadcast Dismiss
    const bcClose = document.getElementById('plBroadcastCloseBtn');
    if (bcClose) {
      bcClose.addEventListener('click', () => {
        const box = document.getElementById('plBroadcastBanner');
        if (box) {
          try { if (box.dataset.bcId) localStorage.setItem('pl_dismissed_broadcast_id', box.dataset.bcId); } catch (_) {}
          box.hidden = true;
        }
      });
    }

    // Bind Usage Instructions Modal (Next / Skip / Touch Swipe)
    const obNext = document.getElementById('plObNextBtn');
    const obSkip = document.getElementById('plObSkipBtn');
    const obModal = document.getElementById('plOnboardingModal');
    if (obNext) obNext.addEventListener('click', () => {
      if (S()) S().haptic('tap');
      if (obStep < 2) { obStep++; renderObStep(); } else closeUsageInstructions();
    });
    if (obSkip) obSkip.addEventListener('click', closeUsageInstructions);
    if (obModal) {
      let sx = 0;
      obModal.addEventListener('touchstart', (e) => { if (e.touches && e.touches[0]) sx = e.touches[0].clientX; }, { passive: true });
      obModal.addEventListener('touchend', (e) => {
        if (!e.changedTouches || !e.changedTouches[0]) return;
        const dx = e.changedTouches[0].clientX - sx;
        if (dx < -45 && obStep < 2) { obStep++; renderObStep(); }
        else if (dx > 45 && obStep > 0) { obStep--; renderObStep(); }
      }, { passive: true });
    }

    // Show APK Usage Instructions after EVERY successful OTP login!
    try {
      if (localStorage.getItem(PENDING_GUIDE_KEY) === '1') {
        setTimeout(openUsageInstructions, 700);
      }
    } catch (_) {}

    // Silent Background Prefetch -> Instant Charts, Notifications, Broadcast & Partner Summary!
    setTimeout(async () => {
      if (S()) await S().runBackgroundPrefetch();
      syncProfileAssignedPartner();
      renderKv7DayChart('plUser7DayChart');
      renderKv7DayChart('sa7DayChart');
      syncLiveNotificationsAndBroadcast();
      initSwipeDownProfileSheet();
    }, 550);

    // Poll notifications & broadcast every 60s + on window focus for real cross-device delivery!
    setInterval(syncLiveNotificationsAndBroadcast, 60000);
    setInterval(updateSpeedEta, 1500);
    window.addEventListener('focus', () => { syncLiveNotificationsAndBroadcast(); renderKv7DayChart('plUser7DayChart'); });
  }

  document.addEventListener('DOMContentLoaded', initUserDashboardModule);

  g.PocketLeadsUserUI = {
    openInstructions: openUsageInstructions,
    syncNotifications: syncLiveNotificationsAndBroadcast,
    render7DayChart: renderKv7DayChart,
    syncAssignedPartner: syncProfileAssignedPartner
  };
  g.PocketLeadsUX = {
    haptic: (t) => S() && S().haptic(t),
    openTour: openUsageInstructions,
    refreshBroadcast: syncLiveNotificationsAndBroadcast,
    renderCharts: () => { renderKv7DayChart('plUser7DayChart'); renderKv7DayChart('sa7DayChart'); }
  };
})(globalThis);
