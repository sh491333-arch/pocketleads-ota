(function (g) {
  'use strict';

  // MODULE 2: USER DASHBOARD UI
  // - APK Usage Instructions shown after EVERY successful OTP login
  // - In-App Broadcast Popup: ONLY on fresh app open, NEVER interrupts extraction, max ONCE per 24h per user!
  // - Phone Push Notifications are strictly handled by Android System NotificationManager (never shown as in-app card!)
  // - Cloudflare PL_KV 7-Day Credit Usage Chart (strictly per active user)
  // - Assigned Partner isolation + Native Swipe-Down Profile Bottom Sheet + Live Speed/ETA
  const S = () => g.PocketLeadsShared;
  const PENDING_GUIDE_KEY = 'pl_show_login_guide_pending';
  const BROADCAST_COOLDOWN_MS = 24 * 60 * 60 * 1000; // 24 hours
  let freshOpenBroadcastChecked = false;

  function isExtractionActive() {
    try {
      const sc = g.angular && document.body ? g.angular.element(document.body).scope() : null;
      if (sc && (sc.isExtracting || sc.extracting || sc.scraping || sc.waApiRunning)) return true;
    } catch (_) {}
    return false;
  }

  // 1. APK Usage Instructions Dashboard — Shown after EVERY successful OTP login!
  let obStep = 0;
  function renderObStep() {
    const slides = document.querySelectorAll('#plOnboardingModal .pl-ob-slide');
    const dots = document.querySelectorAll('#plOnboardingModal .pl-ob-dot');
    const nextBtn = document.getElementById('plObNextBtn');
    slides.forEach((s, i) => { s.hidden = i !== obStep; });
    dots.forEach((d, i) => { d.classList.toggle('is-active', i === obStep); });
    if (nextBtn) nextBtn.textContent = obStep >= 2 ? 'Start Using App' : 'Next →';
  }

  function openUsageInstructions() {
    const modal = document.getElementById('plOnboardingModal');
    if (!modal) return;
    obStep = 0;
    renderObStep();
    modal.hidden = false;
  }

  function closeUsageInstructions() {
    const modal = document.getElementById('plOnboardingModal');
    if (modal) modal.hidden = true;
    try { localStorage.removeItem(PENDING_GUIDE_KEY); } catch (_) {}
    if (S()) S().haptic('success');
  }

  // 2. In-App Broadcast Popup (Fresh Open ONLY, Never During Extraction, Max Once Per 24h Per User!)
  async function checkFreshOpenBroadcastPopup() {
    if (freshOpenBroadcastChecked || !S()) return;
    freshOpenBroadcastChecked = true;
    // Rule: Never interrupt active extraction! Postpone until next fresh open.
    if (isExtractionActive()) return;
    // Also don't stack over login instructions modal
    const obModal = document.getElementById('plOnboardingModal');
    if (obModal && !obModal.hidden) return;

    try {
      const ctx = await S().getActiveUserContext();
      const userKey = ctx.phone10 || ctx.key || 'guest';
      const res = await S().postApi('getBroadcastBanner', {});
      const bc = res && res.status === 'ok' ? res.banner : null;
      if (!bc || !bc.active || !bc.id) return;

      // Check schedule time client-side too
      if (bc.scheduledAt) {
        const dueMs = Date.parse(bc.scheduledAt);
        if (Number.isFinite(dueMs) && Date.now() < dueMs) return;
      }

      // Rule: Display at most ONCE per 24 hours per user!
      const seenKey = 'pl_bc_seen_' + userKey + '_' + bc.id;
      const lastSeen = Number(localStorage.getItem(seenKey) || 0);
      if (lastSeen && (Date.now() - lastSeen) < BROADCAST_COOLDOWN_MS) return;

      // Re-check extraction right before showing
      if (isExtractionActive()) return;

      const modal = document.getElementById('plBroadcastPopupModal');
      if (!modal) return;
      const tEl = document.getElementById('plBcPopupTitle');
      const mEl = document.getElementById('plBcPopupMsg');
      const badgeEl = document.getElementById('plBcPopupBadge');
      if (tEl) tEl.textContent = bc.title || 'Announcement';
      if (mEl) mEl.textContent = bc.message || '';
      if (badgeEl) badgeEl.textContent = bc.audience === 'partners' ? 'PARTNER BROADCAST' : 'OFFICIAL BROADCAST';
      modal.dataset.seenKey = seenKey;
      modal.hidden = false;
      localStorage.setItem(seenKey, String(Date.now()));
      S().haptic('tap');
    } catch (_) {}
  }

  // 3. Cloudflare PL_KV 7-Day Credit Usage Chart (Cross-Device & Strictly Isolated Per Active User!)
  async function renderKv7DayChart(containerId, overridePhone) {
    const el = document.getElementById(containerId);
    if (!el || !S()) return;
    try {
      const ctx = await S().getActiveUserContext();
      const targetPhone = overridePhone || ctx.phone10 || ctx.key;
      let res = null;
      if (targetPhone) {
        res = await S().postApi('getCreditUsage7d', { key: ctx.key, phone: targetPhone, targetPhone });
      }
      const days = (res && Array.isArray(res.days) && res.days.length) ? res.days : [
        { label: 'Mon', used: 0 }, { label: 'Tue', used: 0 }, { label: 'Wed', used: 0 },
        { label: 'Thu', used: 0 }, { label: 'Fri', used: 0 }, { label: 'Sat', used: 0 }, { label: 'Sun', used: 0 }
      ];
      const maxV = Math.max(10, ...days.map(d => Number(d.used) || 0));
      const total7 = days.reduce((a, d) => a + (Number(d.used) || 0), 0);
      el.innerHTML =
        '<div class="pl-chart-head"><span>7-Day Credit Usage (Cloud Sync)</span><strong>' + total7.toLocaleString('en-IN') + ' used</strong></div>' +
        '<div class="pl-chart-bars">' +
        days.map((d, idx) => {
          const v = Number(d.used) || 0;
          const h = Math.max(8, Math.round((v / maxV) * 100));
          const isToday = idx === days.length - 1;
          return '<div class="pl-chart-col">' +
            '<div class="pl-chart-bar-wrap"><div class="pl-chart-bar' + (isToday ? ' is-today' : '') + '" style="height:' + h + '%;" title="' + d.label + ': ' + v + '"></div></div>' +
            '<span class="pl-chart-lbl">' + S().esc(d.label) + '</span></div>';
        }).join('') +
        '</div>';
    } catch (_) {}
  }

  // 4. Sync Active User's Own Assigned Partner into Profile Drawer
  async function syncProfileAssignedPartner() {
    if (!S()) return;
    const ctx = await S().getActiveUserContext();
    const acc = ctx.account || {};
    const row = document.getElementById('plAssignedPartnerRow');
    const val = document.getElementById('plAssignedPartnerVal');
    if (row && val) {
      const pName = String(acc.assignedPartnerName || '').trim();
      const pPhone = String(acc.assignedPartnerPhone || '').trim();
      val.textContent = (pName || pPhone)
        ? (pPhone && pName !== pPhone ? (pName + ' (' + pPhone + ')') : (pName || pPhone))
        : 'Direct (PocketLeads)';
      row.hidden = false;
    }
  }

  // 5. Native Swipe-Down Profile Bottom Sheet
  function initSwipeDownProfileSheet() {
    const sheet = document.querySelector('.pl-profile-sheet, .pl-profile-dropdown, #plProfileDropdown, #plProfileMenu');
    if (!sheet || sheet.__plSwipeBound) return;
    sheet.__plSwipeBound = true;
    let startY = 0, dy = 0, active = false;
    sheet.addEventListener('touchstart', (e) => {
      if (sheet.scrollTop <= 2 && e.touches && e.touches.length === 1) { startY = e.touches[0].clientY; active = true; dy = 0; }
    }, { passive: true });
    sheet.addEventListener('touchmove', (e) => {
      if (!active || !e.touches || !e.touches.length) return;
      dy = e.touches[0].clientY - startY;
      if (dy > 8 && sheet.scrollTop <= 2) sheet.style.transform = 'translateY(' + Math.min(220, dy) + 'px)';
    }, { passive: true });
    sheet.addEventListener('touchend', () => {
      if (!active) return;
      active = false;
      sheet.style.transform = '';
      if (dy > 85) {
        const closeBtn = document.querySelector('#plProfileCloseBtn, .pl-profile-close, [data-profile-close]');
        if (closeBtn) closeBtn.click();
      }
    }, { passive: true });
  }

  // 6. Live Extraction Speed & ETA Meter
  let extStartTs = 0, lastLeadCount = 0;
  function fmtEta(sec) {
    if (!Number.isFinite(sec) || sec <= 0 || sec > 36000) return '--';
    const m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m > 0 ? (m + 'm ' + s + 's') : (s + 's');
  }
  function updateSpeedEta() {
    const box = document.getElementById('plLiveSpeedEtaBar');
    if (!box) return;
    let leads = 0, pct = 0, running = false;
    try {
      const sc = g.angular && document.body ? g.angular.element(document.body).scope() : null;
      if (sc) {
        leads = Array.isArray(sc.allLeads) ? sc.allLeads.length : (Number(sc.extractedCount) || 0);
        pct = Number(sc.progressPercent) || 0;
        running = !!(sc.isExtracting || sc.extracting || sc.scraping);
      }
    } catch (_) {}
    if ((leads > lastLeadCount || running) && !extStartTs) extStartTs = Date.now();
    if (!running && leads === 0) { extStartTs = 0; lastLeadCount = 0; }
    lastLeadCount = leads;
    if (leads > 0 || running) {
      box.hidden = false;
      const elSec = Math.max(1, (Date.now() - (extStartTs || Date.now())) / 1000);
      const lpm = Math.round((leads / elSec) * 60);
      const eta = (pct > 2 && pct < 100) ? ((elSec / pct) * (100 - pct)) : 0;
      const sp = document.getElementById('plEtaSpeedVal');
      const tm = document.getElementById('plEtaElapsedVal');
      const et = document.getElementById('plEtaRemainVal');
      if (sp) sp.textContent = lpm + ' / min';
      if (tm) tm.textContent = fmtEta(elSec);
      if (et) et.textContent = pct >= 100 ? 'Done' : (eta > 0 ? ('~' + fmtEta(eta)) : 'Active');
    } else {
      box.hidden = true;
    }
  }


  // 7. Smart Android 13/14/15 Notification Permission Handler (Install / Login / OTA Update — 7-day snooze if declined!)
  const NOTIF_SNOOZE_KEY = 'pl_notif_perm_snooze_until_v1';
  async function syncPushDeviceRegistration(permStatus) {
    if (!S()) return;
    try {
      const ctx = await S().getActiveUserContext();
      if (!ctx.deviceId) return;
      await S().postApi('registerPushDevice', {
        deviceId: ctx.deviceId,
        phone: ctx.phone10 || ctx.key || '',
        platform: (g.AndroidChromeBridge ? 'android' : 'web'),
        permStatus: permStatus || 'granted',
        appVersion: '10.23.00'
      });
    } catch (_) {}
  }

  function checkAndPromptNotificationPermission() {
    try {
      if (!g.AndroidChromeBridge || typeof g.AndroidChromeBridge.getNotificationPermissionStatus !== 'function') return;
      const st = String(g.AndroidChromeBridge.getNotificationPermissionStatus() || 'granted');
      syncPushDeviceRegistration(st);
      if (st === 'granted') return;
      const snoozeUntil = Number(localStorage.getItem(NOTIF_SNOOZE_KEY) || 0);
      if (snoozeUntil && Date.now() < snoozeUntil) return;
      const modal = document.getElementById('plNotifPermModal');
      const allowBtn = document.getElementById('plNotifPermAllowBtn');
      const msgEl = document.getElementById('plNotifPermMsg');
      if (!modal) return;
      if (st === 'disabled' && msgEl && allowBtn) {
        msgEl.textContent = 'Notifications are currently disabled in Android Settings. Tap below to enable alerts & offers.';
        allowBtn.textContent = 'Open Settings';
        allowBtn.dataset.mode = 'settings';
      } else if (allowBtn) {
        allowBtn.textContent = 'Allow Notifications';
        allowBtn.dataset.mode = 'request';
      }
      modal.hidden = false;
    } catch (_) {}
  }

  function initUserDashboardModule() {
    // Bind Notification Permission Modal Buttons
    const npLater = document.getElementById('plNotifPermLaterBtn');
    const npAllow = document.getElementById('plNotifPermAllowBtn');
    const npModal = document.getElementById('plNotifPermModal');
    if (npLater) npLater.addEventListener('click', () => {
      try { localStorage.setItem(NOTIF_SNOOZE_KEY, String(Date.now() + 7 * 86400 * 1000)); } catch (_) {}
      if (npModal) npModal.hidden = true;
    });
    if (npAllow) npAllow.addEventListener('click', () => {
      if (npModal) npModal.hidden = true;
      try {
        if (npAllow.dataset.mode === 'settings' && g.AndroidChromeBridge && g.AndroidChromeBridge.openNotificationSettings) {
          g.AndroidChromeBridge.openNotificationSettings();
        } else if (g.AndroidChromeBridge && g.AndroidChromeBridge.requestNotificationPermission) {
          g.AndroidChromeBridge.requestNotificationPermission();
        }
      } catch (_) {}
    });

    // Bind Broadcast Popup Close
    const bcClose = document.getElementById('plBcPopupCloseBtn');
    const bcOk = document.getElementById('plBcPopupOkBtn');
    const closeBcPopup = () => {
      const m = document.getElementById('plBroadcastPopupModal');
      if (m) m.hidden = true;
    };
    if (bcClose) bcClose.addEventListener('click', closeBcPopup);
    if (bcOk) bcOk.addEventListener('click', closeBcPopup);

    // Bind Usage Instructions Modal
    const obNext = document.getElementById('plObNextBtn');
    const obSkip = document.getElementById('plObSkipBtn');
    const obModal = document.getElementById('plOnboardingModal');
    if (obNext) obNext.addEventListener('click', () => {
      if (S()) S().haptic('tap');
      if (obStep < 2) { obStep++; renderObStep(); } else closeUsageInstructions();
    });
    if (obSkip) obSkip.addEventListener('click', closeUsageInstructions);
    if (obModal) {
      let sx = 0;
      obModal.addEventListener('touchstart', (e) => { if (e.touches && e.touches[0]) sx = e.touches[0].clientX; }, { passive: true });
      obModal.addEventListener('touchend', (e) => {
        if (!e.changedTouches || !e.changedTouches[0]) return;
        const dx = e.changedTouches[0].clientX - sx;
        if (dx < -45 && obStep < 2) { obStep++; renderObStep(); }
        else if (dx > 45 && obStep > 0) { obStep--; renderObStep(); }
      }, { passive: true });
    }

    // Show APK Usage Instructions after EVERY successful OTP login!
    try {
      if (localStorage.getItem(PENDING_GUIDE_KEY) === '1') {
        setTimeout(openUsageInstructions, 650);
      }
    } catch (_) {}

    // Silent Background Prefetch + Fresh-Open Broadcast Popup Check (after 1.6s)
    setTimeout(async () => {
      if (S()) await S().runBackgroundPrefetch();
      syncProfileAssignedPartner();
      renderKv7DayChart('plUser7DayChart');
      initSwipeDownProfileSheet();
      checkFreshOpenBroadcastPopup();
      setTimeout(checkAndPromptNotificationPermission, 2200);
    }, 1200);

    setInterval(updateSpeedEta, 1500);
    window.addEventListener('focus', () => { renderKv7DayChart('plUser7DayChart'); try { if (g.AndroidChromeBridge && g.AndroidChromeBridge.getNotificationPermissionStatus) syncPushDeviceRegistration(g.AndroidChromeBridge.getNotificationPermissionStatus()); } catch (_) {} });
  }

  document.addEventListener('DOMContentLoaded', initUserDashboardModule);

  g.PocketLeadsUserUI = {
    openInstructions: openUsageInstructions,
    checkBroadcastPopup: checkFreshOpenBroadcastPopup,
    render7DayChart: renderKv7DayChart,
    syncAssignedPartner: syncProfileAssignedPartner,
    isExtractionActive
  };
  g.PocketLeadsUX = {
    haptic: (t) => S() && S().haptic(t),
    openTour: openUsageInstructions,
    refreshBroadcast: () => {},
    renderCharts: () => { renderKv7DayChart('plUser7DayChart'); }
  };
})(globalThis);
