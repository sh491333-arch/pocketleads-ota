(function (g) {
  'use strict';

  // MODULE 2: USER DASHBOARD UI
  // - APK Usage Instructions shown after EVERY successful OTP login
  // - In-App Broadcast Popup: ONLY on fresh app open, NEVER interrupts extraction, max ONCE per 24h per user!
  // - Phone Push Notifications are strictly handled by Android System NotificationManager (never shown as in-app card!)
  // - Cloudflare PL_KV 7-Day Credit Usage Chart (strictly per active user)
  // - Assigned Partner isolation + Native Swipe-Down Profile Bottom Sheet + Live Speed/ETA
  const S = () => g.PocketLeadsShared;
  const PENDING_GUIDE_KEY = 'pl_show_login_guide_pending';
  const BROADCAST_COOLDOWN_MS = 24 * 60 * 60 * 1000; // 24 hours
  let freshOpenBroadcastChecked = false;

  function isExtractionActive() {
    try {
      const sc = g.angular && document.body ? g.angular.element(document.body).scope() : null;
      if (sc && (sc.isExtracting || sc.extracting || sc.scraping || sc.waApiRunning)) return true;
    } catch (_) {}
    return false;
  }

  // 1. Detailed Scrollable Setup & Usage Guide — Shown after OTP login & accessible anytime from Profile!
  function openUsageInstructions() {
    const modal = document.getElementById('plOnboardingModal');
    if (!modal) return;
    const body = document.getElementById('plObScrollBody');
    if (body) body.scrollTop = 0;
    modal.hidden = false;
  }

  function closeUsageInstructions() {
    const modal = document.getElementById('plOnboardingModal');
    if (modal) modal.hidden = true;
    try { localStorage.removeItem(PENDING_GUIDE_KEY); } catch (_) {}
    if (S()) S().haptic('success');
  }

  // 2. In-App Broadcast Popup (Fresh Open ONLY, Never During Extraction, Max Once Per 24h Per User!)
  async function checkFreshOpenBroadcastPopup() {
    if (freshOpenBroadcastChecked || !S()) return;
    freshOpenBroadcastChecked = true;
    // Rule: Never interrupt active extraction! Postpone until next fresh open.
    if (isExtractionActive()) return;
    // Also don't stack over login instructions modal
    const obModal = document.getElementById('plOnboardingModal');
    if (obModal && !obModal.hidden) return;

    try {
      const ctx = await S().getActiveUserContext();
      const userKey = ctx.phone10 || ctx.key || 'guest';
      const res = await S().postApi('getBroadcastBanner', {});
      const bc = res && res.status === 'ok' ? res.banner : null;
      if (!bc || !bc.active || !bc.id) return;

      // Check schedule time client-side too
      if (bc.scheduledAt) {
        const dueMs = Date.parse(bc.scheduledAt);
        if (Number.isFinite(dueMs) && Date.now() < dueMs) return;
      }

      // Rule: Display at most ONCE per 24 hours per user!
      const seenKey = 'pl_bc_seen_' + userKey + '_' + bc.id;
      const lastSeen = Number(localStorage.getItem(seenKey) || 0);
      if (lastSeen && (Date.now() - lastSeen) < BROADCAST_COOLDOWN_MS) return;

      // Re-check extraction right before showing
      if (isExtractionActive()) return;

      const modal = document.getElementById('plBroadcastPopupModal');
      if (!modal) return;
      const tEl = document.getElementById('plBcPopupTitle');
      const mEl = document.getElementById('plBcPopupMsg');
      const badgeEl = document.getElementById('plBcPopupBadge');
      const imgWrap = document.getElementById('plBcPopupImgWrap');
      const imgEl = document.getElementById('plBcPopupImg');
      const ctaBtn = document.getElementById('plBcPopupCtaBtn');
      const cat = String(bc.category || 'announcement').toLowerCase();
      const catMap = {
        offer: '🔥 EXCLUSIVE OFFER',
        update: '✨ NEW UPDATE',
        instruction: '📋 IMPORTANT GUIDE',
        announcement: bc.audience === 'partners' ? '🤝 PARTNER BROADCAST' : '📢 OFFICIAL ANNOUNCEMENT'
      };
      if (tEl) tEl.textContent = bc.title || 'PocketLeads Update';
      if (mEl) mEl.textContent = bc.message || '';
      if (badgeEl) {
        badgeEl.textContent = catMap[cat] || catMap.announcement;
        badgeEl.className = 'pl-bc-popup-badge is-' + cat;
      }
      if (imgWrap && imgEl) {
        if (bc.imageUrl && String(bc.imageUrl).trim()) {
          imgEl.src = String(bc.imageUrl).trim();
          imgWrap.hidden = false;
        } else {
          imgEl.removeAttribute('src');
          imgWrap.hidden = true;
        }
      }
      if (ctaBtn) {
        const cleanUrl = String(bc.ctaUrl || '').trim();
        if (cleanUrl) {
          ctaBtn.textContent = String(bc.ctaText || 'Learn More').trim() || 'Learn More';
          ctaBtn.href = /^https?:\/\//i.test(cleanUrl) ? cleanUrl : ('https://' + cleanUrl);
          ctaBtn.hidden = false;
        } else {
          ctaBtn.hidden = true;
        }
      }
      modal.dataset.seenKey = seenKey;
      modal.hidden = false;
      localStorage.setItem(seenKey, String(Date.now()));
      S().haptic('tap');
    } catch (_) {}
  }

  // 3. Cloudflare PL_KV 7-Day Credit Usage Chart (Cross-Device & Strictly Isolated Per Active User!)
  function fmtUsageCount(n) {
    const v = Math.max(0, Math.floor(Number(n) || 0));
    if (v >= 100000) return (v / 1000).toFixed(0) + 'K';
    if (v >= 10000) return (v / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    return v.toLocaleString('en-IN');
  }

  let kv7DayRefreshTimer = null;
  function scheduleKv7DayChartRefresh(delayMs) {
    if (kv7DayRefreshTimer) clearTimeout(kv7DayRefreshTimer);
    kv7DayRefreshTimer = setTimeout(() => { renderKv7DayChart('plUser7DayChart'); }, delayMs || 450);
  }

  function getTodayIstIsoClient() {
    const d = new Date(Date.now() + 5.5 * 3600 * 1000);
    return d.getUTCFullYear() + '-' + String(d.getUTCMonth() + 1).padStart(2, '0') + '-' + String(d.getUTCDate()).padStart(2, '0');
  }

  function buildLast7FallbackDays() {
    const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const out = [];
    const istNow = Date.now() + 5.5 * 3600 * 1000;
    for (let i = 6; i >= 0; i--) {
      const d = new Date(istNow - i * 86400000);
      const iso = d.getUTCFullYear() + '-' + String(d.getUTCMonth() + 1).padStart(2, '0') + '-' + String(d.getUTCDate()).padStart(2, '0');
      out.push({ date: iso, label: names[d.getUTCDay()], used: 0 });
    }
    return out;
  }

  function getLocalUsageBucketKey(userHint) {
    const clean = String(userHint || '').trim().toUpperCase();
    return 'pl_local_usage_7d_' + (clean || 'ACTIVE');
  }

  function readLocalUsageMap(userHint) {
    try {
      const raw = localStorage.getItem(getLocalUsageBucketKey(userHint));
      const obj = raw ? JSON.parse(raw) : {};
      return (obj && typeof obj === 'object') ? obj : {};
    } catch (_) { return {}; }
  }

  function recordLocalUsageDelta(userHint, delta) {
    const amt = Math.max(0, Math.floor(Number(delta) || 0));
    if (amt <= 0) return;
    try {
      const k = getLocalUsageBucketKey(userHint);
      const map = readLocalUsageMap(userHint);
      const today = getTodayIstIsoClient();
      map[today] = (Number(map[today]) || 0) + amt;
      const validDates = new Set(buildLast7FallbackDays().map(x => x.date));
      for (const dk of Object.keys(map)) {
        if (!validDates.has(dk)) delete map[dk];
      }
      localStorage.setItem(k, JSON.stringify(map));
    } catch (_) {}
  }

  function mergeDaysWithLocal(days, userHint) {
    const base = (Array.isArray(days) && days.length) ? days.map(d => Object.assign({}, d)) : buildLast7FallbackDays();
    const localMap = readLocalUsageMap(userHint);
    const activeMap = readLocalUsageMap('ACTIVE');
    for (let i = 0; i < base.length; i++) {
      const iso = base[i].date;
      const kvVal = Math.max(0, Math.floor(Number(base[i].used) || 0));
      const locVal = iso ? Math.max(Number(localMap[iso]) || 0, (!userHint ? (Number(activeMap[iso]) || 0) : 0)) : 0;
      base[i].used = Math.max(kvVal, locVal);
    }
    return base;
  }

  function paintKv7DayChartHtml(el, days, todayUsedOverride, userHint) {
    const list = mergeDaysWithLocal(days, userHint);
    const maxV = Math.max(10, ...list.map(d => Number(d.used) || 0));
    const total7 = list.reduce((a, d) => a + (Number(d.used) || 0), 0);
    const lastDayVal = list.length ? (Number(list[list.length - 1].used) || 0) : 0;
    const todayV = Math.max(Number(todayUsedOverride) || 0, lastDayVal);
    const escFn = (S() && S().esc) ? S().esc : (v => String(v == null ? '' : v));
    el.hidden = false;
    el.style.display = 'block';
    el.innerHTML =
      '<div class="pl-chart-head"><span>7-Day Credit Usage (Live)</span><strong>Today: ' + todayV.toLocaleString('en-IN') + ' &bull; 7d: ' + total7.toLocaleString('en-IN') + '</strong></div>' +
      '<div class="pl-chart-bars">' +
      list.map((d, idx) => {
        const v = Number(d.used) || 0;
        const h = v > 0 ? Math.max(14, Math.round((v / maxV) * 100)) : 8;
        const isToday = idx === list.length - 1;
        return '<div class="pl-chart-col" title="' + escFn(d.date || d.label) + ': ' + v.toLocaleString('en-IN') + ' credits">' +
          '<span class="pl-chart-val' + (v > 0 ? ' has-val' : '') + (isToday ? ' is-today' : '') + '">' + fmtUsageCount(v) + '</span>' +
          '<div class="pl-chart-bar-wrap"><div class="pl-chart-bar' + (isToday ? ' is-today' : '') + '" style="height:' + h + '%;"></div></div>' +
          '<span class="pl-chart-lbl' + (isToday ? ' is-today' : '') + '">' + escFn(d.label) + '</span></div>';
      }).join('') +
      '</div>';
  }

  async function renderKv7DayChart(containerId, overridePhone) {
    const el = document.getElementById(containerId || 'plUser7DayChart');
    if (!el) return;
    const pref = S() && S().prefetchCache && S().prefetchCache.credit7d;
    let targetPhone = overridePhone || '';
    let ctxKey = '';
    if (S()) {
      try {
        const ctx = await S().getActiveUserContext();
        ctxKey = ctx.key || '';
        if (!targetPhone) targetPhone = ctx.phone10 || ctx.key || '';
      } catch (_) {}
    }
    const userHint = targetPhone || ctxKey;
    if (!el.dataset.plChartPainted) {
      el.dataset.plChartPainted = '1';
      paintKv7DayChartHtml(el, pref && pref.days, pref && pref.todayUsed, userHint);
    }
    if (!S()) return;
    try {
      let res = null;
      if (targetPhone || ctxKey) {
        res = await S().postApi('getCreditUsage7d', { key: ctxKey || targetPhone, phone: targetPhone, targetPhone });
      }
      if (res && Array.isArray(res.days) && res.days.length) {
        if (S().prefetchCache) S().prefetchCache.credit7d = res;
        paintKv7DayChartHtml(el, res.days, res.todayUsed, userHint);
      } else {
        paintKv7DayChartHtml(el, null, 0, userHint);
      }
    } catch (_) {
      paintKv7DayChartHtml(el, pref && pref.days, pref && pref.todayUsed, userHint);
    }
  }

  // 4. Sync Active User's Own Assigned Partner into Profile Drawer
  async function syncProfileAssignedPartner() {
    if (!S()) return;
    const ctx = await S().getActiveUserContext();
    const acc = ctx.account || {};
    const row = document.getElementById('plAssignedPartnerRow');
    const val = document.getElementById('plAssignedPartnerVal');
    if (row && val) {
      const pName = String(acc.assignedPartnerName || '').trim();
      const pPhone = String(acc.assignedPartnerPhone || '').trim();
      val.textContent = (pName || pPhone)
        ? (pPhone && pName !== pPhone ? (pName + ' (' + pPhone + ')') : (pName || pPhone))
        : 'Direct (PocketLeads)';
      row.hidden = false;
    }
  }

  // 5. Native Swipe-Down Profile Bottom Sheet
  function initSwipeDownProfileSheet() {
    const sheet = document.querySelector('.pl-profile-sheet, .pl-profile-dropdown, #plProfileDropdown, #plProfileMenu');
    if (!sheet || sheet.__plSwipeBound) return;
    sheet.__plSwipeBound = true;
    let startY = 0, dy = 0, active = false;
    sheet.addEventListener('touchstart', (e) => {
      if (sheet.scrollTop <= 2 && e.touches && e.touches.length === 1) { startY = e.touches[0].clientY; active = true; dy = 0; }
    }, { passive: true });
    sheet.addEventListener('touchmove', (e) => {
      if (!active || !e.touches || !e.touches.length) return;
      dy = e.touches[0].clientY - startY;
      if (dy > 8 && sheet.scrollTop <= 2) sheet.style.transform = 'translateY(' + Math.min(220, dy) + 'px)';
    }, { passive: true });
    sheet.addEventListener('touchend', () => {
      if (!active) return;
      active = false;
      sheet.style.transform = '';
      if (dy > 85) {
        const closeBtn = document.querySelector('#plProfileCloseBtn, .pl-profile-close, [data-profile-close]');
        if (closeBtn) closeBtn.click();
      }
    }, { passive: true });
  }

  // 6. Live Extraction Speed & ETA Meter
  let extStartTs = 0, lastLeadCount = 0;
  function fmtEta(sec) {
    if (!Number.isFinite(sec) || sec <= 0 || sec > 36000) return '--';
    const m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m > 0 ? (m + 'm ' + s + 's') : (s + 's');
  }
  function updateSpeedEta() {
    const box = document.getElementById('plLiveSpeedEtaBar');
    if (!box) return;
    let leads = 0, pct = 0, running = false;
    try {
      const sc = g.angular && document.body ? g.angular.element(document.body).scope() : null;
      if (sc) {
        leads = Array.isArray(sc.allLeads) ? sc.allLeads.length : (Number(sc.extractedCount) || 0);
        pct = Number(sc.progressPercent) || 0;
        running = !!(sc.isExtracting || sc.extracting || sc.scraping);
      }
    } catch (_) {}
    if ((leads > lastLeadCount || running) && !extStartTs) extStartTs = Date.now();
    if (!running && leads === 0) { extStartTs = 0; lastLeadCount = 0; }
    lastLeadCount = leads;
    if (leads > 0 || running) {
      box.hidden = false;
      const elSec = Math.max(1, (Date.now() - (extStartTs || Date.now())) / 1000);
      const lpm = Math.round((leads / elSec) * 60);
      const eta = (pct > 2 && pct < 100) ? ((elSec / pct) * (100 - pct)) : 0;
      const sp = document.getElementById('plEtaSpeedVal');
      const tm = document.getElementById('plEtaElapsedVal');
      const et = document.getElementById('plEtaRemainVal');
      if (sp) sp.textContent = lpm + ' / min';
      if (tm) tm.textContent = fmtEta(elSec);
      if (et) et.textContent = pct >= 100 ? 'Done' : (eta > 0 ? ('~' + fmtEta(eta)) : 'Active');
    } else {
      box.hidden = true;
    }
  }


  // 7. Smart Android 13/14/15 Notification Permission Handler (Install / Login / OTA Update — 7-day snooze if declined!)
  const NOTIF_SNOOZE_KEY = 'pl_notif_perm_snooze_until_v1';
  async function pollForegroundPhonePushes() {
    try {
      if (!S()) return;
      const bridge = g.AndroidChromeBridge;
      if (!bridge || typeof bridge.showRichNotification !== 'function') return;
      const ctx = await S().getActiveUserContext();
      const p10 = ctx.phone10 || '';
      if (p10 && typeof bridge.setPushUserPhone === 'function') {
        try { bridge.setPushUserPhone(p10); } catch (_) {}
      }
      const res = await S().postApi('getPhonePush', { phone: p10, key: ctx.key || p10 });
      const list = (res && Array.isArray(res.pushes)) ? res.pushes : [];
      for (let i = list.length - 1; i >= 0; i--) {
        const p = list[i];
        if (!p || !p.id) continue;
        const lsKey = 'pl_fg_push_seen_' + p.id;
        if (localStorage.getItem(lsKey) === '1') continue;
        let isNew = true;
        if (typeof bridge.markPushSeenIfNew === 'function') {
          try { isNew = !!bridge.markPushSeenIfNew(String(p.id)); } catch (_) {}
        }
        localStorage.setItem(lsKey, '1');
        if (isNew) {
          bridge.showRichNotification(p.title || 'PocketLeads PRO', p.message || '', p.imageUrl || '', p.ctaUrl || '');
        }
      }
    } catch (_) {}
  }

  async function syncPushDeviceRegistration(permStatus) {
    if (!S()) return;
    try {
      const ctx = await S().getActiveUserContext();
      if (!ctx.deviceId) return;
      if (ctx.phone10 && g.AndroidChromeBridge && typeof g.AndroidChromeBridge.setPushUserPhone === 'function') {
        try { g.AndroidChromeBridge.setPushUserPhone(ctx.phone10); } catch (_) {}
      }
      await S().postApi('registerPushDevice', {
        deviceId: ctx.deviceId,
        phone: ctx.phone10 || ctx.key || '',
        platform: (g.AndroidChromeBridge ? 'android' : 'web'),
        permStatus: permStatus || 'granted',
        appVersion: '10.23.00'
      });
    } catch (_) {}
  }

  function checkAndPromptNotificationPermission() {
    try {
      if (!g.AndroidChromeBridge || typeof g.AndroidChromeBridge.getNotificationPermissionStatus !== 'function') return;
      const st = String(g.AndroidChromeBridge.getNotificationPermissionStatus() || 'granted');
      syncPushDeviceRegistration(st);
      if (st === 'granted') return;
      const snoozeUntil = Number(localStorage.getItem(NOTIF_SNOOZE_KEY) || 0);
      if (snoozeUntil && Date.now() < snoozeUntil) return;
      const modal = document.getElementById('plNotifPermModal');
      const allowBtn = document.getElementById('plNotifPermAllowBtn');
      const msgEl = document.getElementById('plNotifPermMsg');
      if (!modal) return;
      if (st === 'disabled' && msgEl && allowBtn) {
        msgEl.textContent = 'Notifications are currently disabled in Android Settings. Tap below to enable alerts & offers.';
        allowBtn.textContent = 'Open Settings';
        allowBtn.dataset.mode = 'settings';
      } else if (allowBtn) {
        allowBtn.textContent = 'Allow Notifications';
        allowBtn.dataset.mode = 'request';
      }
      modal.hidden = false;
    } catch (_) {}
  }

  function initUserDashboardModule() {
    // Bind Notification Permission Modal Buttons
    const npLater = document.getElementById('plNotifPermLaterBtn');
    const npAllow = document.getElementById('plNotifPermAllowBtn');
    const npModal = document.getElementById('plNotifPermModal');
    if (npLater) npLater.addEventListener('click', () => {
      try { localStorage.setItem(NOTIF_SNOOZE_KEY, String(Date.now() + 7 * 86400 * 1000)); } catch (_) {}
      if (npModal) npModal.hidden = true;
    });
    if (npAllow) npAllow.addEventListener('click', () => {
      if (npModal) npModal.hidden = true;
      try {
        if (npAllow.dataset.mode === 'settings' && g.AndroidChromeBridge && g.AndroidChromeBridge.openNotificationSettings) {
          g.AndroidChromeBridge.openNotificationSettings();
        } else if (g.AndroidChromeBridge && g.AndroidChromeBridge.requestNotificationPermission) {
          g.AndroidChromeBridge.requestNotificationPermission();
        }
      } catch (_) {}
    });

    // Bind Broadcast Popup Close
    const bcClose = document.getElementById('plBcPopupCloseBtn');
    const bcOk = document.getElementById('plBcPopupOkBtn');
    const closeBcPopup = () => {
      const m = document.getElementById('plBroadcastPopupModal');
      if (m) m.hidden = true;
    };
    if (bcClose) bcClose.addEventListener('click', closeBcPopup);
    if (bcOk) bcOk.addEventListener('click', closeBcPopup);

    // Bind Scrollable Setup & Usage Guide Modal
    const obNext = document.getElementById('plObNextBtn');
    const obSkip = document.getElementById('plObSkipBtn');
    const obModal = document.getElementById('plOnboardingModal');
    if (obNext) obNext.addEventListener('click', closeUsageInstructions);
    if (obSkip) obSkip.addEventListener('click', closeUsageInstructions);
    if (obModal) {
      obModal.addEventListener('click', (e) => {
        if (e.target === obModal) closeUsageInstructions();
      });
    }
    const profGuideBtn = document.getElementById('plProfileSetupGuideBtn');
    if (profGuideBtn) {
      profGuideBtn.addEventListener('click', () => {
        const panel = document.getElementById('plProfilePanel');
        if (panel) panel.hidden = true;
        openUsageInstructions();
      });
    }
    // Observe #plProfilePanel visibility so 7-day usage chart ALWAYS refreshes live whenever Profile opens!
    const profPanel = document.getElementById('plProfilePanel');
    if (profPanel && typeof MutationObserver !== 'undefined') {
      const obs = new MutationObserver(() => {
        if (!profPanel.hidden) {
          syncProfileAssignedPartner();
          scheduleKv7DayChartRefresh(60);
        }
      });
      obs.observe(profPanel, { attributes: true, attributeFilter: ['hidden', 'class', 'style'] });
    }

    // Show APK Usage Instructions after EVERY successful OTP login!
    try {
      if (localStorage.getItem(PENDING_GUIDE_KEY) === '1') {
        setTimeout(openUsageInstructions, 650);
      }
    } catch (_) {}

    // Silent Background Prefetch + Fresh-Open Broadcast Popup Check (after 1.6s)
    setTimeout(async () => {
      if (S()) await S().runBackgroundPrefetch();
      syncProfileAssignedPartner();
      renderKv7DayChart('plUser7DayChart');
      initSwipeDownProfileSheet();
      checkFreshOpenBroadcastPopup();
      setTimeout(checkAndPromptNotificationPermission, 2200);
      setTimeout(pollForegroundPhonePushes, 3500);
    }, 1200);
    setInterval(pollForegroundPhonePushes, 45000);

    setInterval(updateSpeedEta, 1500);
    window.addEventListener('pl:credit-used', async (ev) => {
      try {
        const delta = Math.max(0, Math.floor(Number(ev && ev.detail && ev.detail.amount) || 0));
        if (delta > 0) {
          let uHint = '';
          if (S()) {
            const ctx = await S().getActiveUserContext();
            uHint = ctx.phone10 || ctx.key || '';
          }
          recordLocalUsageDelta(uHint || 'ACTIVE', delta);
          const el = document.getElementById('plUser7DayChart');
          const pref = S() && S().prefetchCache && S().prefetchCache.credit7d;
          if (el) paintKv7DayChartHtml(el, pref && pref.days, null, uHint);
        }
      } catch (_) {}
      scheduleKv7DayChartRefresh(650);
    });
    document.addEventListener('click', (ev) => {
      const trigger = ev.target && ev.target.closest && ev.target.closest('#plProfileBtn, #plProfileTrigger, .pl-profile-trigger, .pl-profile-btn, .pl-avatar-btn, [data-profile-toggle]');
      if (trigger) scheduleKv7DayChartRefresh(120);
    }, true);
    window.addEventListener('focus', () => { renderKv7DayChart('plUser7DayChart'); try { if (g.AndroidChromeBridge && g.AndroidChromeBridge.getNotificationPermissionStatus) syncPushDeviceRegistration(g.AndroidChromeBridge.getNotificationPermissionStatus()); } catch (_) {} });
  }

  document.addEventListener('DOMContentLoaded', initUserDashboardModule);

  g.PocketLeadsUserUI = {
    openInstructions: openUsageInstructions,
    checkBroadcastPopup: checkFreshOpenBroadcastPopup,
    render7DayChart: renderKv7DayChart,
    syncAssignedPartner: syncProfileAssignedPartner,
    isExtractionActive
  };
  g.PocketLeadsUX = {
    haptic: (t) => S() && S().haptic(t),
    openTour: openUsageInstructions,
    refreshBroadcast: () => {},
    renderCharts: () => { renderKv7DayChart('plUser7DayChart'); }
  };
})(globalThis);
