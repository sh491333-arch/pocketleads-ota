(function () {
  'use strict';

  // v10.22.01 CLEAN, VERIFIED SUPER ADMIN MODULE
  // - Zero hardcoded phone numbers in frontend
  // - 100% working Phone Push (Real-Time + Scheduled + Photo Upload) & In-App Broadcast
  // - 100% accurate Login as User <-> Return to Super Admin (`superAdminReturnSelf`)
  const SA_TOKEN_KEY = 'pl_super_admin_token';
  const SA_FLAG_KEY = 'pl_is_super_admin';
  const IMPERSONATE_BACKUP_KEY = 'pl_sa_impersonate_backup';
  const SA_CACHE_KEY = 'pl_sa_dash_cache_v3';

  let saData = null;
  let saActiveTab = 'users';
  let saTabHistory = ['users'];
  let saRoleFilter = 'all';
  let saPartnerFilter = 'all';
  let saSearchText = '';
  let saBound = false;
  let saQuickMode = null;
  let uploadedPushImg = '';
  let uploadedBellImg = '';
  let uploadedBcImg = '';

  function normOptionalUrl(raw) {
    const s = String(raw || '').trim();
    if (!s) return '';
    return /^https?:\/\//i.test(s) ? s : ('https://' + s);
  }

  function bindImageCompressor(fileId, prevId, wrapId, clearId, onSet) {
    const fEl = document.getElementById(fileId);
    const pEl = document.getElementById(prevId);
    const wEl = document.getElementById(wrapId);
    const cEl = document.getElementById(clearId);
    if (fEl) {
      fEl.addEventListener('change', () => {
        const f = fEl.files && fEl.files[0];
        if (!f) return;
        const rd = new FileReader();
        rd.onload = () => {
          const im = new Image();
          im.onload = () => {
            const maxW = 900;
            const sc = im.width > maxW ? (maxW / im.width) : 1;
            const cv = document.createElement('canvas');
            cv.width = Math.max(1, Math.round(im.width * sc));
            cv.height = Math.max(1, Math.round(im.height * sc));
            cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
            const dataUri = cv.toDataURL('image/jpeg', 0.78);
            onSet(dataUri);
            if (pEl) pEl.src = dataUri;
            if (wEl) wEl.hidden = false;
            showToast('Banner image attached (' + Math.round(dataUri.length / 1024) + ' KB)', 'ok');
          };
          im.src = String(rd.result || '');
        };
        rd.readAsDataURL(f);
      });
    }
    if (cEl) cEl.addEventListener('click', () => { onSet(''); if (fEl) fEl.value = ''; if (wEl) wEl.hidden = true; });
  }

  const S = () => window.PocketLeadsShared;
  const esc = (v) => (S() ? S().esc(v) : String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'));
  const normPhone10 = (v) => (S() ? S().normPhone10(v) : String(v || '').replace(/\D+/g, '').slice(-10));
  const formatDisplayPhone = (v) => (S() ? S().formatPhone(v) : String(v || ''));
  const showToast = (m, t) => (S() ? S().toast(m, t) : null);
  const setBtnLoading = (b, l, txt) => (S() ? S().setBtnLoading(b, l, txt) : null);

  function getAdminToken() {
    try {
      const direct = String(localStorage.getItem(SA_TOKEN_KEY) || '').trim();
      if (direct && direct.includes('.')) return direct;
      const rawImp = localStorage.getItem(IMPERSONATE_BACKUP_KEY);
      if (rawImp) {
        const parsed = JSON.parse(rawImp);
        if (parsed && parsed.adminToken && String(parsed.adminToken).includes('.')) return String(parsed.adminToken);
      }
    } catch (_) {}
    return '';
  }

  function clearAdminToken() {
    try {
      localStorage.removeItem(SA_TOKEN_KEY);
      localStorage.removeItem(SA_FLAG_KEY);
      localStorage.removeItem(SA_CACHE_KEY);
    } catch (_) {}
  }

  function setSyncPill(visible, text) {
    const pill = document.getElementById('saSyncPill');
    if (!pill) return;
    if (visible) {
      pill.hidden = false;
      pill.innerHTML = '<span class="pl-btn-spin" aria-hidden="true"></span> ' + esc(text || 'Syncing...');
    } else {
      pill.hidden = true;
    }
  }

  function setSaStatus(msg, type) {
    const el = document.getElementById('saStatusBanner');
    if (!el) return;
    if (!msg) { el.hidden = true; el.textContent = ''; return; }
    el.hidden = false;
    el.className = 'sa-status' + (type === 'err' ? ' is-err' : (type === 'ok' ? ' is-ok' : ''));
    el.textContent = msg;
  }

  async function isAuthorizedSuperAdmin() {
    return !!getAdminToken();
  }

  function applyImpersonationMenuUI() {
    const banner = document.getElementById('plImpersonateBanner');
    if (banner) banner.hidden = true;
    document.body.classList.remove('pl-impersonating');

    let imp = null;
    try {
      const raw = localStorage.getItem(IMPERSONATE_BACKUP_KEY);
      if (raw) imp = JSON.parse(raw);
    } catch (_) {}

    const backBtn = document.getElementById('plProfileBackToAdminMenuBtn');
    const backSub = document.getElementById('plProfileBackToAdminSub');
    const showBack = !!(getAdminToken() && imp && imp.targetKey);
    if (backBtn) {
      backBtn.hidden = !showBack;
      backBtn.style.setProperty('display', showBack ? 'flex' : 'none', 'important');
    }
    if (showBack && backSub) {
      const labelName = String(imp.targetName || imp.targetPhone || 'User').trim();
      backSub.textContent = 'Viewing: ' + labelName + ' • Tap to return to Super Admin';
    }
  }

  async function syncSuperAdminVisibility() {
    const allowed = await isAuthorizedSuperAdmin();
    const btn = document.getElementById('plProfileSuperAdminMenuBtn');
    if (btn) {
      btn.hidden = !allowed;
      btn.style.setProperty('display', allowed ? 'flex' : 'none', 'important');
    }
    applyImpersonationMenuUI();
  }

  async function saApiCall(action, extra) {
    const token = getAdminToken();
    if (!token) throw new Error('Super Admin OTP session required. Please sign in with OTP.');
    const ctx = S() ? await S().getActiveUserContext() : { key: '', deviceId: 'android-admin' };
    const base = S() ? S().getApiBase() : 'https://pocketleads-edge.samimn7890.workers.dev/exec';
    const payload = Object.assign({
      action: action,
      adminToken: token,
      deviceId: ctx.deviceId || 'android-admin'
    }, extra || {});

    const res = await fetch(base, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Admin-Token': token },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data && data.reason === 'super_admin_token_required') {
      clearAdminToken();
      syncSuperAdminVisibility();
      throw new Error('Super Admin OTP session expired. Please sign out and log in again with OTP.');
    }
    if (!res.ok || !data || (data.status && data.status !== 'ok')) {
      throw new Error((data && (data.message || data.reason)) || ('HTTP ' + res.status));
    }
    return data;
  }

  function roleBadge(role) {
    if (role === 'super_admin') return '<span class="sa-badge sa-badge-admin">SUPER ADMIN</span>';
    if (role === 'partner') return '<span class="sa-badge sa-badge-partner">PARTNER</span>';
    if (role === 'partner_user' || role === 'partner_customer') return '<span class="sa-badge sa-badge-puser">PARTNER USER</span>';
    return '<span class="sa-badge sa-badge-normal">NORMAL USER</span>';
  }

  function renderUsersList() {
    const container = document.getElementById('saUsersList');
    if (!container) return;
    if (!saData) {
      container.innerHTML = [1, 2, 3].map(() => '<div class="pl-skel-card"><div class="pl-skel-line w-60"></div><div class="pl-skel-line w-40"></div><div class="pl-skel-line w-90"></div></div>').join('');
      return;
    }
    let list = (saData.users || []).slice();
    if (saRoleFilter === 'normal_user') list = list.filter(u => u.role === 'normal_user' || u.role === 'normal' || u.role === 'super_admin');
    else if (saRoleFilter === 'partner') list = list.filter(u => u.role === 'partner' || u.isPartner);
    else if (saRoleFilter === 'partner_user') list = list.filter(u => u.role === 'partner_user' || u.role === 'partner_customer');
    if (saPartnerFilter && saPartnerFilter !== 'all') {
      list = list.filter(u => u.partnerPhone === saPartnerFilter || u.phone10 === saPartnerFilter);
    }
    if (saSearchText) {
      const q = saSearchText.toLowerCase();
      list = list.filter(u =>
        String(u.name || '').toLowerCase().includes(q) ||
        String(u.phone || '').toLowerCase().includes(q) ||
        String(u.email || '').toLowerCase().includes(q) ||
        String(u.partnerName || '').toLowerCase().includes(q)
      );
    }
    if (!list.length) {
      container.innerHTML = '<div class="sa-empty">No users match the selected filter.</div>';
      return;
    }
    const adminSelfPhone = normPhone10(saData.superAdminPhone || '');
    container.innerHTML = list.map(u => {
      const isUnlimAvail = String(u.availableCredit || '').toLowerCase() === 'unlimited' || Number(u.availableCredit) >= 999999999;
      const isUnlimPurch = String(u.purchasedCredit || '').toLowerCase() === 'unlimited' || Number(u.purchasedCredit) >= 999999999;
      const availNum = isUnlimAvail ? 0 : Math.max(0, Number(u.availableCredit) || 0);
      const purchNum = isUnlimPurch ? 0 : Math.max(0, Number(u.purchasedCredit) || 0);
      const usedNum = (!isUnlimAvail && !isUnlimPurch) ? Math.max(0, purchNum - availNum) : 0;
      const availStr = isUnlimAvail ? 'Unlimited' : availNum.toLocaleString('en-IN');
      const purchStr = isUnlimPurch ? 'Unlimited' : purchNum.toLocaleString('en-IN');
      const usedStr = (!isUnlimAvail && !isUnlimPurch) ? usedNum.toLocaleString('en-IN') : 'Unlimited';
      const isAct = String(u.status || 'active').toLowerCase() === 'active';
      const targetId = u.phone10 || u.phone || '';
      const isSelfAdmin = u.role === 'super_admin' || (adminSelfPhone && normPhone10(targetId) === adminSelfPhone);
      const partnerMeta = u.partnerPhone && !isSelfAdmin
        ? `<div class="sa-user-partner-tag">Under Partner: <strong>${esc(u.partnerName || u.partnerPhone)}</strong> (${esc(u.partnerPhone)})</div>`
        : '';
      const partnerSlotMeta = u.isPartner
        ? `<div class="sa-user-partner-tag is-gold">Partner Slots: <strong>${u.partnerAvailableSlots || 0} Avail</strong> &bull; ${u.partnerUsedSlots || 0} Sold &bull; ${u.partnerTotalSlots || 0} Total</div>`
        : '';
      return `<div class="sa-user-card">
        <div class="sa-user-top">
          <div class="sa-user-ident">
            <div class="sa-avatar">${esc((u.name || 'U').slice(0, 2).toUpperCase())}</div>
            <div>
              <div class="sa-user-name">${esc(u.name || 'User')} ${roleBadge(u.role)}</div>
              <div class="sa-user-sub">${esc(formatDisplayPhone(targetId))}${u.email ? ' &bull; ' + esc(u.email) : ''}</div>
            </div>
          </div>
          <span class="sa-status-dot ${isAct ? 'is-active' : 'is-inactive'}">${esc(u.status || 'Active')}</span>
        </div>
        ${partnerMeta}
        ${partnerSlotMeta}
        <div class="sa-meta-grid">
          <div class="sa-metric-box"><span>Available Credit</span><strong class="is-orange">${availStr}</strong></div>
          <div class="sa-metric-box"><span>Used / Purchased</span><strong>${usedStr} / ${purchStr}</strong></div>
          <div class="sa-metric-box"><span>API Mode</span><strong>${esc(u.apiMode || 'Central')}</strong></div>
          <div class="sa-metric-box"><span>Validity</span><strong>${esc(u.validityDate || 'Active')}</strong></div>
        </div>
        <div class="sa-actions">
          ${isSelfAdmin
            ? `<button type="button" class="sa-btn" data-sa-return-self="1">Your Admin Account (Return)</button>`
            : `<button type="button" class="sa-btn is-primary" data-sa-login="${esc(targetId)}" data-sa-name="${esc(u.name || 'User')}">Login as User (No OTP)</button>`}
          <button type="button" class="sa-btn" data-sa-edit="${esc(targetId)}">Edit Credit / Status</button>
          <button type="button" class="sa-btn is-gold" data-sa-grant="${esc(targetId)}" data-sa-name="${esc(u.name || 'Partner')}">+ Grant Slots</button>
        </div>
      </div>`;
    }).join('');
  }

  let saGlobal7dSummary = { total7d: 0, todayUsed: 0 };

  function renderSaTrendAreaSvg(days, total7dOverride, todayUsedOverride) {
    const wrap = document.getElementById('saTrendSvgWrap');
    if (!wrap) return;
    const pts = (Array.isArray(days) && days.length) ? days : [
      { label: 'Mon', used: 0 }, { label: 'Tue', used: 0 }, { label: 'Wed', used: 0 },
      { label: 'Thu', used: 0 }, { label: 'Fri', used: 0 }, { label: 'Sat', used: 0 }, { label: 'Sun', used: 0 }
    ];
    const total7d = total7dOverride != null ? (Number(total7dOverride) || 0) : pts.reduce((a, d) => a + (Number(d.used) || 0), 0);
    const todayUsed = todayUsedOverride != null ? (Number(todayUsedOverride) || 0) : (Number(pts[pts.length - 1] && pts[pts.length - 1].used) || 0);
    saGlobal7dSummary = { total7d, todayUsed };

    const badge = document.getElementById('saTrendTotalBadge');
    if (badge) {
      badge.textContent = 'All Users: ' + total7d.toLocaleString('en-IN') + ' used (Today: ' + todayUsed.toLocaleString('en-IN') + ')';
    }
    const rep7d = document.getElementById('saReports7dUsed');
    if (rep7d) rep7d.textContent = total7d.toLocaleString('en-IN') + ' (Today: ' + todayUsed.toLocaleString('en-IN') + ')';

    const maxV = Math.max(10, ...pts.map(d => Number(d.used) || 0));
    const W = 420, H = 148, padX = 28, padTop = 24, padBot = 26;
    const stepX = (W - padX * 2) / Math.max(1, pts.length - 1);
    const coords = pts.map((d, i) => ({
      x: Math.round(padX + i * stepX),
      y: Math.round(padTop + (H - padTop - padBot) * (1 - (Number(d.used) || 0) / maxV)),
      label: d.label,
      date: d.date || '',
      used: Number(d.used) || 0,
      isToday: i === pts.length - 1
    }));
    const lineD = coords.map((c, i) => (i === 0 ? 'M' : 'L') + c.x + ',' + c.y).join(' ');
    const areaD = lineD + ' L' + coords[coords.length - 1].x + ',' + (H - padBot) + ' L' + coords[0].x + ',' + (H - padBot) + ' Z';
    wrap.innerHTML = `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;display:block;">
      <defs><linearGradient id="saAreaGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#f97316" stop-opacity="0.45"/><stop offset="100%" stop-color="#f97316" stop-opacity="0.02"/></linearGradient></defs>
      <path d="${areaD}" fill="url(#saAreaGrad)"/>
      <path d="${lineD}" fill="none" stroke="#f97316" stroke-width="2.6" stroke-linecap="round"/>
      ${coords.map(c => `<circle cx="${c.x}" cy="${c.y}" r="${c.isToday ? '4.8' : '3.8'}" fill="${c.isToday ? '#fbbf24' : '#fff'}" stroke="#f97316" stroke-width="2"/><text x="${c.x}" y="${c.y - 9}" text-anchor="middle" fill="${c.used > 0 ? '#fdba74' : '#64748b'}" font-size="9.5" font-weight="700">${c.used.toLocaleString('en-IN')}</text><text x="${c.x}" y="${H - 7}" text-anchor="middle" fill="${c.isToday ? '#fbbf24' : '#94a3b8'}" font-size="10" font-weight="${c.isToday ? '700' : '500'}">${esc(c.label)}</text>`).join('')}
    </svg>`;
  }

  async function loadPhonePushHistory() {
    try {
      const res = await saApiCall('superAdminListPhonePushes', {});
      const list = res.pushes || [];
      const hist = document.getElementById('saPushHistoryList');
      if (!hist) return;
      if (!list.length) {
        hist.innerHTML = '<div class="sa-empty">No phone pushes sent yet.</div>';
        return;
      }
      hist.innerHTML = list.map(p => {
        const isInactive = p.active === false || p.deliveryStatus === 'Inactive';
        const isSched = !isInactive && p.deliveryStatus === 'Scheduled';
        return `<div class="sa-user-card" style="padding:10px 12px;">
          <div class="sa-push-row" style="padding:0;border:none;">
            ${p.imageUrl ? `<img class="sa-push-thumb" src="${esc(p.imageUrl)}" alt="" />` : '<div class="sa-push-thumb" style="display:flex;align-items:center;justify-content:center;">&#128241;</div>'}
            <div style="flex:1;min-width:0;">
              <div style="font-size:13px;font-weight:800;color:#fff;">${esc(p.title)}</div>
              <div style="font-size:11.5px;color:#94a3b8;">${esc(p.message)}</div>
              ${p.scheduledAt ? `<div style="font-size:10.5px;color:#fcd34d;margin-top:2px;">Scheduled: ${esc(p.scheduledAt)}</div>` : ''}
            </div>
            <span class="sa-status-dot ${(isInactive || isSched) ? 'is-inactive' : 'is-active'}">${esc(p.deliveryStatus || (isInactive ? 'Inactive' : 'Sent'))}</span>
          </div>
          <div class="sa-actions" style="margin-top:8px;">
            <button type="button" class="sa-btn ${isInactive ? 'is-green' : ''}" data-sa-push-toggle="${esc(p.id)}">${isInactive ? 'Activate' : 'Set Inactive'}</button>
            <button type="button" class="sa-btn" style="border-color:rgba(248,113,113,0.45);color:#fca5a5;" data-sa-push-del="${esc(p.id)}">Remove</button>
          </div>
        </div>`;
      }).join('');
    } catch (_) {}
  }

  async function loadBellNotificationsHistory() {
    const listEl = document.getElementById('saBellHistoryList');
    if (!listEl) return;
    listEl.innerHTML = [1, 2].map(() => '<div class="pl-skel-card"><div class="pl-skel-line w-60"></div><div class="pl-skel-line w-90"></div></div>').join('');
    try {
      const res = await saApiCall('superAdminListNotifications', {});
      const list = res.notifications || [];
      if (!list.length) {
        listEl.innerHTML = '<div class="sa-empty">No In-App Bell notifications published yet.</div>';
        return;
      }
      listEl.innerHTML = list.map(n => `
        <div class="sa-user-card" style="padding:10px 12px;">
          <div class="sa-push-row" style="padding:0;border:none;">
            ${n.imageUrl ? `<img class="sa-push-thumb" src="${esc(n.imageUrl)}" alt="" />` : '<div class="sa-push-thumb" style="display:flex;align-items:center;justify-content:center;">&#128276;</div>'}
            <div style="flex:1;min-width:0;">
              <div style="font-size:13px;font-weight:800;color:#fff;">${esc(n.title)} <span class="sa-badge">${esc(String(n.type || 'offer').toUpperCase())}</span></div>
              <div style="font-size:11.5px;color:#94a3b8;">${esc(n.message)}</div>
              ${n.createdAt ? `<div style="font-size:10px;color:#64748b;margin-top:2px;">${esc(n.createdAt)}</div>` : ''}
            </div>
            <span class="sa-status-dot ${n.active ? 'is-active' : 'is-inactive'}">${n.active ? 'Active' : 'Inactive'}</span>
          </div>
          <div class="sa-actions" style="margin-top:8px;">
            <button type="button" class="sa-btn ${n.active ? '' : 'is-green'}" data-sa-bell-toggle="${esc(n.id)}">${n.active ? 'Set Inactive' : 'Activate'}</button>
            <button type="button" class="sa-btn" style="border-color:rgba(248,113,113,0.45);color:#fca5a5;" data-sa-bell-del="${esc(n.id)}">Remove</button>
          </div>
        </div>`).join('');
    } catch (_) {
      listEl.innerHTML = '<div class="sa-empty">Could not load bell notifications.</div>';
    }
  }

  async function loadBroadcastStatusCard() {
    const box = document.getElementById('saBroadcastActiveCard');
    if (!box || !S()) return;
    try {
      const res = await S().postApi('getBroadcastBanner', {});
      const bc = res && res.banner;
      if (!bc || !bc.id) {
        box.innerHTML = '<div class="sa-empty">No dashboard popup configured right now.</div>';
        return;
      }
      box.innerHTML = `<div class="sa-user-card" style="padding:10px 12px;border-color:${bc.active ? 'rgba(249,115,22,0.5)' : 'rgba(148,163,184,0.28)'};">
        <div class="sa-push-row" style="padding:0;border:none;">
          ${bc.imageUrl ? `<img class="sa-push-thumb" src="${esc(bc.imageUrl)}" alt="" />` : '<div class="sa-push-thumb" style="display:flex;align-items:center;justify-content:center;">&#128226;</div>'}
          <div style="flex:1;min-width:0;">
            <div style="font-size:13px;font-weight:800;color:#fff;">${esc(bc.title)} <span class="sa-badge">${esc(String(bc.category || 'announcement').toUpperCase())}</span></div>
            <div style="font-size:11.5px;color:#94a3b8;">${esc(bc.message)}</div>
            ${bc.scheduledAt ? `<div style="font-size:10.5px;color:#fcd34d;margin-top:2px;">Scheduled: ${esc(bc.scheduledAt)}</div>` : ''}
          </div>
          <span class="sa-status-dot ${bc.active ? 'is-active' : 'is-inactive'}">${bc.active ? 'Active' : 'Paused'}</span>
        </div>
        <div class="sa-actions" style="margin-top:8px;">
          <button type="button" class="sa-btn ${bc.active ? '' : 'is-green'}" data-sa-bc-toggle="1">${bc.active ? 'Set Inactive (Pause)' : 'Activate Popup'}</button>
          <button type="button" class="sa-btn" style="border-color:rgba(248,113,113,0.45);color:#fca5a5;" data-sa-bc-remove="1">Remove Popup</button>
        </div>
      </div>`;
    } catch (_) {
      box.innerHTML = '<div class="sa-empty">Could not load current popup status.</div>';
    }
  }


  async function loadSaTickets(triggerBtn) {
    const listEl = document.getElementById('saTicketsList');
    if (triggerBtn) setBtnLoading(triggerBtn, true, 'Loading...');
    if (listEl) listEl.innerHTML = [1,2,3].map(() => '<div class="pl-skel-card"><div class="pl-skel-line w-60"></div><div class="pl-skel-line w-90"></div><div class="pl-skel-line w-40"></div></div>').join('');
    try {
      const res = await saApiCall('superAdminListTickets', {});
      const list = res.tickets || [];
      if (!list.length) {
        if (listEl) listEl.innerHTML = '<div class="sa-empty">No support tickets submitted yet.</div>';
      } else if (listEl) {
        listEl.innerHTML = list.map(t => {
          const isRes = /resolv|replied|closed/i.test(String(t.status || ''));
          return `<div class="sa-user-card">
            <div class="sa-user-top">
              <div>
                <div class="sa-user-name">${esc(t.ticketId)} &bull; ${esc(t.subject)}</div>
                <div class="sa-user-sub">${esc(formatDisplayPhone(t.phone))} &bull; ${esc(t.createdAt)}</div>
              </div>
              <span class="sa-status-dot ${isRes ? 'is-active' : 'is-inactive'}">${esc(t.status || 'Open')}</span>
            </div>
            <div style="font-size:12.5px;color:#e2e8f0;margin-bottom:8px;">${esc(t.message)}</div>
            ${t.adminReply ? `<div class="sa-user-partner-tag is-gold"><strong>Admin Reply:</strong> ${esc(t.adminReply)}</div>` : ''}
            <div style="display:flex;gap:6px;margin-top:8px;">
              <input type="text" class="sa-input" data-sa-ticket-input="${esc(t.ticketId)}" style="flex:1;" placeholder="Write reply to user..." value="${esc(t.adminReply || '')}" />
              <button type="button" class="sa-btn is-primary" data-sa-reply-ticket="${esc(t.ticketId)}">Send Reply</button>
            </div>
          </div>`;
        }).join('');
      }
      if (triggerBtn) showToast('Loaded ' + list.length + ' tickets', 'ok');
    } catch (err) {
      if (listEl) listEl.innerHTML = '<div class="sa-empty">Failed: ' + esc(err.message) + '</div>';
      showToast('Tickets failed: ' + err.message, 'err');
    } finally {
      if (triggerBtn) setBtnLoading(triggerBtn, false);
    }
  }

  async function loadSaErrorLogs(triggerBtn) {
    const listEl = document.getElementById('saErrorsList');
    const phInput = document.getElementById('saErrorPhoneFilter');
    const phFilter = phInput ? phInput.value.trim() : '';
    if (triggerBtn) setBtnLoading(triggerBtn, true, 'Loading...');
    if (listEl) listEl.innerHTML = [1,2,3].map(() => '<div class="pl-skel-card"><div class="pl-skel-line w-60"></div><div class="pl-skel-line w-90"></div></div>').join('');
    try {
      const res = await saApiCall('superAdminErrorLogs', { targetPhone: phFilter, limit: 60 });
      const logs = res.logs || [];
      if (!logs.length) {
        if (listEl) listEl.innerHTML = '<div class="sa-empty">No API errors recorded' + (phFilter ? (' for ' + esc(phFilter)) : '') + '.</div>';
      } else if (listEl) {
        listEl.innerHTML = logs.map(l => `<div class="sa-err-card">
          <div class="sa-err-top">
            <span class="sa-err-phone">${esc(formatDisplayPhone(l.phone) || 'Unknown')} &bull; ${esc(l.provider || 'API')} ${l.code ? ('[' + esc(l.code) + ']') : ''}</span>
            <span class="sa-err-time">${esc(l.timestamp || '')}</span>
          </div>
          <div class="sa-err-msg">${esc(l.message || 'No detail')}</div>
        </div>`).join('');
      }
      if (triggerBtn) showToast('Loaded ' + logs.length + ' error logs', 'ok');
    } catch (err) {
      if (listEl) listEl.innerHTML = '<div class="sa-empty">Failed: ' + esc(err.message) + '</div>';
      showToast('Error logs failed: ' + err.message, 'err');
    } finally {
      if (triggerBtn) setBtnLoading(triggerBtn, false);
    }
  }

  function renderSaDashboard(data) {
    saData = data;
    const s = data.summary || {};
    const users = data.users || [];
    const partners = (data.partners || []).filter(p => p && (normPhone10(p.phone10 || p.phone) || String(p.name || '').trim()));
    const pendingOrders = data.pendingOrders || data.orders || [];

    const setT = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = String(v); };
    setT('saKpiTotal', s.totalUsers != null ? s.totalUsers : users.length);
    setT('saKpiPartners', s.totalPartners != null ? s.totalPartners : partners.length);
    setT('saKpiPartnerUsers', s.partnerUsers != null ? s.partnerUsers : users.filter(u => u.role === 'partner_user').length);
    setT('saKpiPending', s.pendingOrders != null ? s.pendingOrders : pendingOrders.length);
    setT('saOvActiveUsers', users.filter(u => String(u.status || 'active').toLowerCase() === 'active').length);
    setT('saOvActivePartners', partners.length);

    const pf = document.getElementById('saPartnerFilter');
    if (pf) {
      const cur = pf.value || 'all';
      pf.innerHTML = '<option value="all">All Partners</option>' +
        partners.map(p => `<option value="${esc(p.phone10)}">${esc(p.name || p.phone10)} (${esc(p.phone10)} &bull; ${p.soldUsersCount || p.usedSlots || 0} sold)</option>`).join('');
      pf.value = cur;
    }

    renderUsersList();

    const pList = document.getElementById('saPartnersList');
    if (pList) {
      pList.innerHTML = !partners.length ? '<div class="sa-empty">No partners registered yet.</div>' : partners.map(p => `
        <div class="sa-user-card">
          <div class="sa-user-top">
            <div class="sa-user-ident">
              <div class="sa-avatar is-gold">${esc((p.name || 'P').slice(0, 2).toUpperCase())}</div>
              <div>
                <div class="sa-user-name">${esc(p.name || 'Partner')} <span class="sa-badge sa-badge-partner">PARTNER</span></div>
                <div class="sa-user-sub">${esc(formatDisplayPhone(p.phone10))}</div>
              </div>
            </div>
            <span class="sa-status-dot is-active">${esc(p.status || 'Active')}</span>
          </div>
          <div class="sa-meta-grid">
            <div class="sa-metric-box"><span>Total Slots</span><strong>${p.totalSlots || 0}</strong></div>
            <div class="sa-metric-box"><span>Available</span><strong class="is-orange">${p.availableSlots || 0}</strong></div>
            <div class="sa-metric-box"><span>Sold Users</span><strong>${p.soldUsersCount != null ? p.soldUsersCount : (p.usedSlots || 0)}</strong></div>
            <div class="sa-metric-box"><span>Est. Profit</span><strong class="is-green">&#8377;${Number(p.estimatedProfitInr || ((p.usedSlots || 0) * 804)).toLocaleString('en-IN')}</strong></div>
          </div>
          <div class="sa-actions">
            <button type="button" class="sa-btn is-primary" data-sa-filter-partner="${esc(p.phone10)}">View Users</button>
            <button type="button" class="sa-btn is-gold" data-sa-grant="${esc(p.phone10)}" data-sa-name="${esc(p.name || 'Partner')}">+ Grant Slots</button>
            <button type="button" class="sa-btn" data-sa-login="${esc(p.phone10)}" data-sa-name="${esc(p.name || 'Partner')}">Login as Partner</button>
          </div>
        </div>`).join('');
    }

    const oList = document.getElementById('saOrdersList');
    if (oList) {
      oList.innerHTML = !pendingOrders.length ? '<div class="sa-empty">No pending partner slot orders.</div>' : pendingOrders.map(o => {
        const slots = o.packSlots || o.slots || 0;
        const amt = o.amount || o.amountInr || 0;
        return `<div class="sa-user-card">
          <div class="sa-user-top">
            <div>
              <div class="sa-user-name">${esc(o.orderId)} &bull; ${slots} Slot${slots > 1 ? 's' : ''} (&#8377;${Number(amt).toLocaleString('en-IN')})</div>
              <div class="sa-user-sub">Partner: ${esc(o.partnerName || '')} ${esc(formatDisplayPhone(o.partnerPhone))} &bull; Ref: ${esc(o.paymentRef || 'Pending')}</div>
            </div>
            <span class="sa-status-dot is-inactive">${esc(o.status || 'Pending')}</span>
          </div>
          <div class="sa-actions"><button type="button" class="sa-btn is-primary" data-sa-approve-order="${esc(o.orderId)}">Approve &amp; Credit ${slots} Slots</button></div>
        </div>`;
      }).join('');
    }

    const rBox = document.getElementById('saReportsSummary');
    if (rBox) {
      const isFin = (v) => String(v || '').toLowerCase() !== 'unlimited' && Number(v) < 999999999;
      const totalAvail = users.reduce((sum, u) => sum + (isFin(u.availableCredit) ? Math.max(0, Number(u.availableCredit) || 0) : 0), 0);
      const totalPurch = users.reduce((sum, u) => sum + (isFin(u.purchasedCredit) ? Math.max(0, Number(u.purchasedCredit) || 0) : 0), 0);
      const totalUsedAllUsers = users.reduce((sum, u) => {
        if (!isFin(u.availableCredit) || !isFin(u.purchasedCredit)) return sum;
        return sum + Math.max(0, (Number(u.purchasedCredit) || 0) - (Number(u.availableCredit) || 0));
      }, 0);
      rBox.innerHTML = `<div class="sa-meta-grid">
        <div class="sa-metric-box"><span>Total Used Credits (All Users)</span><strong class="is-orange">${totalUsedAllUsers.toLocaleString('en-IN')}</strong></div>
        <div class="sa-metric-box"><span>7-Day Live Usage (All Users)</span><strong id="saReports7dUsed" class="is-green">${saGlobal7dSummary.total7d.toLocaleString('en-IN')} (Today: ${saGlobal7dSummary.todayUsed.toLocaleString('en-IN')})</strong></div>
        <div class="sa-metric-box"><span>Total Active Pool Credits</span><strong>${totalAvail.toLocaleString('en-IN')}</strong></div>
        <div class="sa-metric-box"><span>Total Purchased Credits</span><strong>${totalPurch.toLocaleString('en-IN')}</strong></div>
        <div class="sa-metric-box"><span>Direct Users</span><strong>${users.filter(u => u.role === 'normal_user' || u.role === 'super_admin').length}</strong></div>
        <div class="sa-metric-box"><span>Partner Users / Partners</span><strong>${users.filter(u => u.role === 'partner_user').length} / ${partners.length}</strong></div>
      </div>`;
    }
    if (S()) {
      saApiCall('getCreditUsage7d', { scope: 'all', allUsers: '1', phone: data.superAdminPhone || '' })
        .then(r => renderSaTrendAreaSvg(r && r.days, r && r.total7d, r && r.todayUsed))
        .catch(() => renderSaTrendAreaSvg([], 0, 0));
    }
    loadPhonePushHistory();
  }

  async function refreshSaDashboard(forceFresh, triggerBtn) {
    if (triggerBtn) { setSyncPill(false); setBtnLoading(triggerBtn, true, 'Syncing...'); }
    else { setSyncPill(true, 'Syncing...'); }
    if (!saData) {
      try {
        const cachedRaw = localStorage.getItem(SA_CACHE_KEY);
        if (cachedRaw) { const p = JSON.parse(cachedRaw); if (p && p.users) renderSaDashboard(p); }
      } catch (_) {}
    }
    try {
      const data = await saApiCall('superAdminDashboard', forceFresh ? { force: '1' } : {});
      renderSaDashboard(data);
      try { localStorage.setItem(SA_CACHE_KEY, JSON.stringify(data)); } catch (_) {}
      setSaStatus('', 'info');
      if (triggerBtn) showToast('Super Admin synced!', 'ok');
    } catch (err) {
      setSaStatus('Sync failed: ' + err.message, 'err');
      showToast('Sync failed: ' + err.message, 'err');
    } finally {
      setSyncPill(false);
      if (triggerBtn) setBtnLoading(triggerBtn, false);
    }
  }

  function syncSaKpiActiveState() {
    document.querySelectorAll('#plSuperAdminModal [data-sakpi]').forEach(card => {
      const k = card.getAttribute('data-sakpi');
      const active =
        (k === 'total_users' && saActiveTab === 'users' && saRoleFilter === 'all') ||
        (k === 'partners' && saActiveTab === 'partners') ||
        (k === 'partner_users' && saActiveTab === 'users' && saRoleFilter === 'partner_user') ||
        (k === 'pending_orders' && saActiveTab === 'orders');
      card.classList.toggle('is-kpi-active', active);
    });
  }

  function handleSaKpiClick(kpiKey) {
    if (S()) S().haptic('tap');
    const rf = document.getElementById('saRoleFilter');
    const pf = document.getElementById('saPartnerFilter');
    if (kpiKey === 'total_users') {
      saRoleFilter = 'all';
      saPartnerFilter = 'all';
      if (rf) rf.value = 'all';
      if (pf) pf.value = 'all';
      switchSaTab('users');
      renderUsersList();
    } else if (kpiKey === 'partners') {
      switchSaTab('partners');
    } else if (kpiKey === 'partner_users') {
      saRoleFilter = 'partner_user';
      saPartnerFilter = 'all';
      if (rf) rf.value = 'partner_user';
      if (pf) pf.value = 'all';
      switchSaTab('users');
      renderUsersList();
    } else if (kpiKey === 'pending_orders') {
      switchSaTab('orders');
    }
    syncSaKpiActiveState();
    const activePane = document.querySelector('#plSuperAdminModal [data-sapane="' + saActiveTab + '"]');
    if (activePane && typeof activePane.scrollIntoView === 'function') {
      activePane.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  function switchSaTab(tab, skipHistory) {
    const nextTab = tab || 'users';
    if (!skipHistory && nextTab !== saActiveTab) {
      saTabHistory = (saTabHistory || ['users']).slice(-10);
      saTabHistory.push(nextTab);
    }
    saActiveTab = nextTab;
    document.querySelectorAll('#plSuperAdminModal [data-satab]').forEach(b => {
      b.classList.toggle('is-active', b.getAttribute('data-satab') === saActiveTab);
    });
    document.querySelectorAll('#plSuperAdminModal [data-sapane]').forEach(p => {
      p.hidden = p.getAttribute('data-sapane') !== saActiveTab;
    });
    syncSaKpiActiveState();
    if (saActiveTab === 'errors') loadSaErrorLogs();
    if (saActiveTab === 'tickets') loadSaTickets();
    if (saActiveTab === 'phonepush') loadPhonePushHistory();
    if (saActiveTab === 'inappnotif') loadBellNotificationsHistory();
    if (saActiveTab === 'broadcast') loadBroadcastStatusCard();
  }

  function stepBackSuperAdmin() {
    const qOverlay = document.getElementById('saQuickOverlay');
    if (qOverlay && !qOverlay.hidden) { closeQuickModal(); return 'handled'; }
    if (saTabHistory.length > 1) {
      saTabHistory.pop();
      const prev = saTabHistory[saTabHistory.length - 1] || 'users';
      switchSaTab(prev, true);
      return 'handled';
    }
    if (saActiveTab && saActiveTab !== 'users') {
      saTabHistory = ['users'];
      switchSaTab('users', true);
      return 'handled';
    }
    closeSuperAdmin();
    return 'handled';
  }

  // CLEAN, 100% ACCURATE LOGIN AS USER (NEVER overwrites Super Admin identity!)
  async function loginAsUserWithoutOtp(targetPhone, targetName, triggerBtn) {
    setBtnLoading(triggerBtn, true, 'Switching...');
    setSaStatus('Switching to ' + (targetName || targetPhone) + ' (No OTP)...', 'info');
    try {
      const ctx = S() ? await S().getActiveUserContext() : { deviceId: 'android-admin' };
      const res = await saApiCall('superAdminImpersonate', {
        targetId: targetPhone,
        targetPhone: targetPhone,
        deviceId: ctx.deviceId
      });
      const adminToken = getAdminToken();
      // Store ONLY target metadata + adminToken (Return ALWAYS uses server-verified superAdminReturnSelf!)
      localStorage.setItem(IMPERSONATE_BACKUP_KEY, JSON.stringify({
        adminToken: adminToken,
        deviceId: ctx.deviceId,
        targetKey: res.key || targetPhone,
        targetPhone: res.phone || targetPhone,
        targetName: (res.account && (res.account.userName || res.account.name)) || targetName || targetPhone,
        at: Date.now()
      }));
      const targetKey = String(res.key || targetPhone).trim();
      if (window.PocketLeadsAccount && typeof window.PocketLeadsAccount.applyImpersonatedSession === 'function') {
        await window.PocketLeadsAccount.applyImpersonatedSession(res, targetKey, ctx.deviceId);
      }
      closeSuperAdmin();
      applyImpersonationMenuUI();
      showToast('Logged into ' + (targetName || targetPhone) + '!', 'ok');
      setTimeout(() => { window.location.reload(); }, 180);
    } catch (err) {
      setBtnLoading(triggerBtn, false);
      setSaStatus('Login failed: ' + err.message, 'err');
      showToast('Login failed: ' + err.message, 'err');
    }
  }

  // CLEAN, 100% ACCURATE RETURN TO SUPER ADMIN (Uses dedicated server `superAdminReturnSelf`!)
  async function returnToSuperAdminSession(triggerBtn) {
    setBtnLoading(triggerBtn, true, 'Returning...');
    try {
      const ctx = S() ? await S().getActiveUserContext() : { deviceId: 'android-admin' };
      const adminToken = getAdminToken();
      const resBack = await saApiCall('superAdminReturnSelf', { deviceId: ctx.deviceId });
      if (adminToken) {
        localStorage.setItem(SA_TOKEN_KEY, adminToken);
        localStorage.setItem(SA_FLAG_KEY, '1');
      }
      localStorage.removeItem(IMPERSONATE_BACKUP_KEY);
      if (window.PocketLeadsAccount && typeof window.PocketLeadsAccount.applyImpersonatedSession === 'function') {
        await window.PocketLeadsAccount.applyImpersonatedSession(resBack, resBack.key, ctx.deviceId);
      }
      showToast('Returned to Super Admin account!', 'ok');
      setTimeout(() => { window.location.reload(); }, 160);
    } catch (err) {
      setBtnLoading(triggerBtn, false);
      showToast('Return failed: ' + err.message, 'err');
    }
  }

  function openQuickModal(mode) {
    saQuickMode = mode;
    const overlay = document.getElementById('saQuickOverlay');
    if (!overlay) return;
    const title = document.getElementById('saQuickTitle');
    const sub = document.getElementById('saQuickSub');
    const editFields = document.getElementById('saQuickEditFields');
    const grantFields = document.getElementById('saQuickGrantFields');
    const saveBtn = document.getElementById('saQuickSaveBtn');
    if (mode.type === 'edit') {
      const u = (saData && saData.users || []).find(x => (x.phone10 || x.phone) === mode.phone);
      if (title) title.textContent = 'Edit User Account';
      if (sub) sub.textContent = (u ? u.name : mode.phone) + ' (' + formatDisplayPhone(mode.phone) + ')';
      if (editFields) editFields.hidden = false;
      if (grantFields) grantFields.hidden = true;
      const cr = document.getElementById('saQuickCreditInput');
      const st = document.getElementById('saQuickStatusSelect');
      const am = document.getElementById('saQuickApiModeSelect');
      if (cr) cr.value = u ? String(u.availableCredit || 0) : '100000';
      if (st) st.value = (u && /^inactive$/i.test(u.status)) ? 'Inactive' : ((u && /^suspended$/i.test(u.status)) ? 'Suspended' : 'Active');
      if (am) am.value = (u && /^individual$/i.test(u.apiMode)) ? 'Individual' : 'Central';
      if (saveBtn) saveBtn.textContent = 'Save Changes';
    } else {
      if (title) title.textContent = 'Grant Partner Slots';
      if (sub) sub.textContent = (mode.name || 'Partner') + ' (' + formatDisplayPhone(mode.phone) + ')';
      if (editFields) editFields.hidden = true;
      if (grantFields) grantFields.hidden = false;
      const sl = document.getElementById('saQuickSlotsInput');
      if (sl) sl.value = '5';
      if (saveBtn) saveBtn.textContent = '+ Grant Slots Now';
    }
    overlay.hidden = false;
  }

  function closeQuickModal() {
    const overlay = document.getElementById('saQuickOverlay');
    if (overlay) overlay.hidden = true;
    saQuickMode = null;
  }

  function exportSaUsersCsv() {
    const users = (saData && saData.users) || [];
    if (!users.length) { showToast('No users loaded to export.', 'err'); return; }
    const rows = [['Name','Phone','Email','Role','Status','AvailableCredit','PurchasedCredit','APIMode','Partner']];
    users.forEach(u => rows.push([u.name||'', u.phone10||u.phone||'', u.email||'', u.role||'', u.status||'', u.availableCredit||0, u.purchasedCredit||0, u.apiMode||'', u.partnerName||'']));
    const csv = rows.map(r => r.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
    a.download = 'PocketLeads_Users_Report.csv';
    a.click();
    showToast('Users CSV exported!', 'ok');
  }

  async function openSuperAdmin() {
    if (!(await isAuthorizedSuperAdmin())) { showToast('Super Admin OTP login required.', 'err'); return; }
    const modal = document.getElementById('plSuperAdminModal');
    if (!modal) return;
    modal.hidden = false;
    document.body.style.overflow = 'hidden';
    bindSaEvents();
    switchSaTab('users');
    await refreshSaDashboard(false);
  }

  function closeSuperAdmin() {
    const modal = document.getElementById('plSuperAdminModal');
    if (modal) modal.hidden = true;
    closeQuickModal();
    document.body.style.overflow = '';
  }

  function bindSaEvents() {
    if (saBound) return;
    saBound = true;
    const modal = document.getElementById('plSuperAdminModal');
    if (!modal) return;

    const closeBtn = document.getElementById('saCloseBtn');
    if (closeBtn) closeBtn.addEventListener('click', stepBackSuperAdmin);
    const refBtn = document.getElementById('saRefreshBtn');
    if (refBtn) refBtn.addEventListener('click', () => refreshSaDashboard(true, refBtn));
    const tktBtn = document.getElementById('saLoadTicketsBtn');
    if (tktBtn) tktBtn.addEventListener('click', () => loadSaTickets(tktBtn));
    const errBtn = document.getElementById('saLoadErrorsBtn');
    if (errBtn) errBtn.addEventListener('click', () => loadSaErrorLogs(errBtn));
    const expBtn = document.getElementById('saExportCsvBtn');
    if (expBtn) expBtn.addEventListener('click', exportSaUsersCsv);

    modal.querySelectorAll('[data-sakpi]').forEach(card => {
      const kpiKey = card.getAttribute('data-sakpi');
      card.addEventListener('click', () => handleSaKpiClick(kpiKey));
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handleSaKpiClick(kpiKey); }
      });
    });

    modal.querySelectorAll('[data-satab]').forEach(b => {
      b.addEventListener('click', () => switchSaTab(b.getAttribute('data-satab')));
    });

    const srch = document.getElementById('saUserSearch');
    if (srch) srch.addEventListener('input', () => { saSearchText = srch.value.trim(); renderUsersList(); });
    const rf = document.getElementById('saRoleFilter');
    if (rf) rf.addEventListener('change', () => { saRoleFilter = rf.value || 'all'; syncSaKpiActiveState(); renderUsersList(); });
    const pf = document.getElementById('saPartnerFilter');
    if (pf) pf.addEventListener('change', () => { saPartnerFilter = pf.value || 'all'; renderUsersList(); });

    // 1. PHONE PUSH FORM (Photo Upload + Real-Time / Scheduled!) — 100% WIRED!
    const pFile = document.getElementById('saPushImageFile');
    const pWrap = document.getElementById('saPushImgPreviewWrap');
    const pPrev = document.getElementById('saPushImgPreview');
    const pClr = document.getElementById('saPushClearImgBtn');
    if (pFile) {
      pFile.addEventListener('change', (ev) => {
        const f = ev.target && ev.target.files && ev.target.files[0];
        if (!f) return;
        const rd = new FileReader();
        rd.onload = () => {
          const im = new Image();
          im.onload = () => {
            const sc = im.width > 720 ? (720 / im.width) : 1;
            const cv = document.createElement('canvas');
            cv.width = Math.max(1, Math.round(im.width * sc));
            cv.height = Math.max(1, Math.round(im.height * sc));
            cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
            uploadedPushImg = cv.toDataURL('image/jpeg', 0.76);
            if (pPrev) pPrev.src = uploadedPushImg;
            if (pWrap) pWrap.hidden = false;
            showToast('Banner photo attached (' + Math.round(uploadedPushImg.length / 1024) + ' KB)', 'ok');
          };
          im.src = String(rd.result || '');
        };
        rd.readAsDataURL(f);
      });
    }
    if (pClr) pClr.addEventListener('click', () => { uploadedPushImg = ''; if (pFile) pFile.value = ''; if (pWrap) pWrap.hidden = true; });

    const pushForm = document.getElementById('saPhonePushForm');
    if (pushForm) {
      pushForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('saPushSubmitBtn');
        setBtnLoading(btn, true, 'Sending Push...');
        try {
          const schedRaw = (document.getElementById('saPushScheduleAt') || {}).value || '';
          const res = await saApiCall('superAdminSendPhonePush', {
            segment: (document.getElementById('saPushSegment') || {}).value || 'all',
            title: (document.getElementById('saPushTitle') || {}).value || '',
            message: (document.getElementById('saPushMessage') || {}).value || '',
            imageUrl: normOptionalUrl((document.getElementById('saPushImageUrl') || {}).value),
            imageData: uploadedPushImg || '',
            ctaText: (document.getElementById('saPushCtaText') || {}).value || 'Open Now',
            ctaUrl: normOptionalUrl((document.getElementById('saPushCtaUrl') || {}).value),
            scheduledAt: schedRaw ? new Date(schedRaw).toISOString() : ''
          });
          pushForm.reset();
          uploadedPushImg = '';
          if (pWrap) pWrap.hidden = true;
          if (window.plHaptic) window.plHaptic('success');
          showToast(res.message || 'Phone Push dispatched!', 'ok');
          loadPhonePushHistory();
        } catch (err) {
          showToast('Push failed: ' + err.message, 'err');
        } finally {
          setBtnLoading(btn, false);
        }
      });
    }

    // CHANNEL 2: IN-APP BELL NOTIFICATION FORM (Inside APK Bell Drawer)
    bindImageCompressor('saBellImageFile', 'saBellImgPreview', 'saBellImgPreviewWrap', 'saBellClearImgBtn', v => { uploadedBellImg = v; });
    const bellForm = document.getElementById('saInAppNotifForm');
    if (bellForm) {
      bellForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('saBellSubmitBtn');
        setBtnLoading(btn, true, 'Publishing...');
        try {
          const res = await saApiCall('superAdminSendNotification', {
            type: (document.getElementById('saBellType') || {}).value || 'offer',
            title: (document.getElementById('saBellTitle') || {}).value || '',
            message: (document.getElementById('saBellMessage') || {}).value || '',
            imageData: uploadedBellImg || '',
            ctaText: (document.getElementById('saBellCtaText') || {}).value || '',
            ctaUrl: normOptionalUrl((document.getElementById('saBellCtaUrl') || {}).value)
          });
          bellForm.reset();
          uploadedBellImg = '';
          const bw = document.getElementById('saBellImgPreviewWrap');
          if (bw) bw.hidden = true;
          if (window.plHaptic) window.plHaptic('success');
          showToast(res.message || 'Published to In-App Bell!', 'ok');
          loadBellNotificationsHistory();
        } catch (err) {
          showToast('Bell publish failed: ' + err.message, 'err');
        } finally {
          setBtnLoading(btn, false);
        }
      });
    }

    // CHANNEL 3: USER DASHBOARD POPUP FORM (With Banner Image + Category + Optional CTA)
    bindImageCompressor('saBcImageFile', 'saBcImgPreview', 'saBcImgPreviewWrap', 'saBcClearImgBtn', v => { uploadedBcImg = v; });
    const bcForm = document.getElementById('saBroadcastForm');
    if (bcForm) {
      bcForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('saBcPublishBtn');
        setBtnLoading(btn, true, 'Publishing...');
        try {
          const schedRaw = (document.getElementById('saBcScheduleAt') || {}).value || '';
          const res = await saApiCall('superAdminPublishBroadcast', {
            category: (document.getElementById('saBcCategory') || {}).value || 'announcement',
            title: (document.getElementById('saBcTitle') || {}).value || '',
            message: (document.getElementById('saBcMessage') || {}).value || '',
            imageData: uploadedBcImg || '',
            ctaText: (document.getElementById('saBcCtaText') || {}).value || '',
            ctaUrl: normOptionalUrl((document.getElementById('saBcCtaUrl') || {}).value),
            audience: (document.getElementById('saBcAudience') || {}).value || 'all',
            tone: 'orange',
            scheduledAt: schedRaw ? new Date(schedRaw).toISOString() : ''
          });
          bcForm.reset();
          uploadedBcImg = '';
          const bcw = document.getElementById('saBcImgPreviewWrap');
          if (bcw) bcw.hidden = true;
          if (window.plHaptic) window.plHaptic('success');
          showToast(res.message || 'Broadcast published!', 'ok');
          loadBroadcastStatusCard();
        } catch (err) {
          showToast('Broadcast failed: ' + err.message, 'err');
        } finally {
          setBtnLoading(btn, false);
        }
      });
    }
    const bcClear = document.getElementById('saBcClearBtn');
    if (bcClear) {
      bcClear.addEventListener('click', async () => {
        setBtnLoading(bcClear, true, 'Clearing...');
        try {
          const res = await saApiCall('superAdminClearBroadcast', {});
          showToast(res.message || 'Broadcast cleared!', 'ok');
        } catch (err) {
          showToast('Clear failed: ' + err.message, 'err');
        } finally {
          setBtnLoading(bcClear, false);
        }
      });
    }

    // 3. GRANT SLOTS FORM
    const grantForm = document.getElementById('saGrantSlotsForm');
    if (grantForm) {
      grantForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const phone = String((document.getElementById('saGrantPhone') || {}).value || '').trim();
        const slots = parseInt(String((document.getElementById('saGrantCount') || {}).value || '0'), 10);
        const btn = grantForm.querySelector('button[type="submit"]');
        if (!normPhone10(phone) || !slots || slots <= 0) { showToast('Enter valid 10-digit phone & slots.', 'err'); return; }
        setBtnLoading(btn, true, 'Granting...');
        try {
          const res = await saApiCall('superAdminGrantPartnerSlots', { partnerPhone: phone, slots: slots });
          grantForm.reset();
          showToast(res.message || ('Granted ' + slots + ' slots!'), 'ok');
          await refreshSaDashboard(true);
        } catch (err) { showToast('Grant failed: ' + err.message, 'err'); }
        finally { setBtnLoading(btn, false); }
      });
    }

    // 4. CREATE USER FORM
    const roleSel = document.getElementById('saNewRole');
    if (roleSel) {
      roleSel.addEventListener('change', () => {
        const v = roleSel.value;
        const sWrap = document.getElementById('saNewSlotsWrap');
        const pWrap = document.getElementById('saAssignPartnerWrap');
        if (sWrap) sWrap.style.display = v === 'partner' ? 'block' : 'none';
        if (pWrap) pWrap.style.display = v === 'partner_user' ? 'block' : 'none';
      });
    }
    const createForm = document.getElementById('saCreateUserForm');
    if (createForm) {
      createForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('saCreateSubmitBtn');
        setBtnLoading(btn, true, 'Creating...');
        try {
          const res = await saApiCall('superAdminCreateUser', {
            name: (document.getElementById('saNewName') || {}).value || '',
            phone: (document.getElementById('saNewPhone') || {}).value || '',
            email: (document.getElementById('saNewEmail') || {}).value || '',
            role: (document.getElementById('saNewRole') || {}).value || 'normal_user',
            credits: Number((document.getElementById('saNewCredits') || {}).value || 100000),
            validity: (document.getElementById('saNewValidity') || {}).value || '1 year',
            apiMode: (document.getElementById('saNewApiMode') || {}).value || 'Central',
            initialSlots: Number((document.getElementById('saNewSlots') || {}).value || 0),
            partnerPhone: (document.getElementById('saAssignPartnerPhone') || {}).value || ''
          });
          createForm.reset();
          showToast(res.message || 'Account created!', 'ok');
          await refreshSaDashboard(true);
          switchSaTab('users');
        } catch (err) { showToast('Create failed: ' + err.message, 'err'); }
        finally { setBtnLoading(btn, false); }
      });
    }

    // 5. QUICK CREDIT TOP-UP FORM
    const qCredForm = document.getElementById('saQuickCreditForm');
    if (qCredForm) {
      qCredForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('saCredSubmitBtn');
        setBtnLoading(btn, true, 'Updating...');
        try {
          const res = await saApiCall('superAdminUpdateUser', {
            targetPhone: (document.getElementById('saCredPhone') || {}).value || '',
            availableCredit: Number((document.getElementById('saCredAmount') || {}).value || 0)
          });
          qCredForm.reset();
          showToast(res.message || 'Credits updated!', 'ok');
          await refreshSaDashboard(true);
        } catch (err) { showToast('Update failed: ' + err.message, 'err'); }
        finally { setBtnLoading(btn, false); }
      });
    }

    // 6. BUILT-IN QUICK MODAL (Edit Credit / Grant Slots)
    const qCancel = document.getElementById('saQuickCancelBtn');
    if (qCancel) qCancel.addEventListener('click', closeQuickModal);
    const qOverlay = document.getElementById('saQuickOverlay');
    if (qOverlay) {
      qOverlay.addEventListener('click', (e) => {
        if (e.target === qOverlay) closeQuickModal();
        const chip = e.target.closest('[data-sa-slot-chip]');
        if (chip) { const sl = document.getElementById('saQuickSlotsInput'); if (sl) sl.value = chip.getAttribute('data-sa-slot-chip'); }
      });
    }
    const qSave = document.getElementById('saQuickSaveBtn');
    if (qSave) {
      qSave.addEventListener('click', async () => {
        if (!saQuickMode) return;
        setBtnLoading(qSave, true, 'Saving...');
        try {
          if (saQuickMode.type === 'edit') {
            const res = await saApiCall('superAdminUpdateUser', {
              targetPhone: saQuickMode.phone,
              availableCredit: Number((document.getElementById('saQuickCreditInput') || {}).value || 0),
              status: (document.getElementById('saQuickStatusSelect') || {}).value || 'Active',
              apiMode: (document.getElementById('saQuickApiModeSelect') || {}).value || 'Central'
            });
            closeQuickModal();
            showToast(res.message || 'User updated!', 'ok');
            await refreshSaDashboard(true);
          } else {
            const slots = parseInt(String((document.getElementById('saQuickSlotsInput') || {}).value || '0'), 10);
            if (!slots || slots <= 0) throw new Error('Enter valid slot count');
            const res = await saApiCall('superAdminGrantPartnerSlots', { partnerPhone: saQuickMode.phone, slots: slots });
            closeQuickModal();
            showToast(res.message || ('Granted ' + slots + ' slots!'), 'ok');
            await refreshSaDashboard(true);
          }
        } catch (err) { showToast(err.message || 'Action failed', 'err'); }
        finally { setBtnLoading(qSave, false); }
      });
    }

    // 7. DELEGATED CARD ACTIONS
    modal.addEventListener('click', async (e) => {
      const retSelf = e.target.closest('[data-sa-return-self]');
      if (retSelf) { await returnToSuperAdminSession(retSelf); return; }
      const loginBtn = e.target.closest('[data-sa-login]');
      if (loginBtn) { await loginAsUserWithoutOtp(loginBtn.getAttribute('data-sa-login'), loginBtn.getAttribute('data-sa-name'), loginBtn); return; }
      const editBtn = e.target.closest('[data-sa-edit]');
      if (editBtn) { openQuickModal({ type: 'edit', phone: editBtn.getAttribute('data-sa-edit') }); return; }
      const grantBtn = e.target.closest('[data-sa-grant]');
      if (grantBtn) { openQuickModal({ type: 'grant', phone: grantBtn.getAttribute('data-sa-grant'), name: grantBtn.getAttribute('data-sa-name') }); return; }
      const filterP = e.target.closest('[data-sa-filter-partner]');
      if (filterP) {
        saPartnerFilter = filterP.getAttribute('data-sa-filter-partner');
        saRoleFilter = 'all';
        const pfSel = document.getElementById('saPartnerFilter');
        const rfSel = document.getElementById('saRoleFilter');
        if (pfSel) pfSel.value = saPartnerFilter;
        if (rfSel) rfSel.value = 'all';
        switchSaTab('users');
        renderUsersList();
        return;
      }
      const repTkt = e.target.closest('[data-sa-reply-ticket]');
      if (repTkt) {
        const tid = repTkt.getAttribute('data-sa-reply-ticket');
        const inp = modal.querySelector('[data-sa-ticket-input="' + tid + '"]');
        const txt = inp ? inp.value.trim() : '';
        if (!txt) { showToast('Please enter a reply message.', 'err'); return; }
        setBtnLoading(repTkt, true, 'Sending...');
        try {
          const res = await saApiCall('superAdminReplyTicket', { ticketId: tid, reply: txt, status: 'Resolved' });
          showToast(res.message || 'Reply sent!', 'ok');
          await loadSaTickets();
        } catch (err) { showToast('Reply failed: ' + err.message, 'err'); }
        finally { setBtnLoading(repTkt, false); }
        return;
      }
      const pushTog = e.target.closest('[data-sa-push-toggle]');
      if (pushTog) {
        setBtnLoading(pushTog, true, 'Updating...');
        try {
          const r = await saApiCall('superAdminManagePhonePush', { id: pushTog.getAttribute('data-sa-push-toggle'), op: 'toggle' });
          showToast(r.message || 'Updated!', 'ok');
          loadPhonePushHistory();
        } catch (err) { showToast('Failed: ' + err.message, 'err'); }
        finally { setBtnLoading(pushTog, false); }
        return;
      }
      const pushDel = e.target.closest('[data-sa-push-del]');
      if (pushDel) {
        setBtnLoading(pushDel, true, 'Removing...');
        try {
          const r = await saApiCall('superAdminManagePhonePush', { id: pushDel.getAttribute('data-sa-push-del'), op: 'delete' });
          showToast(r.message || 'Removed!', 'ok');
          loadPhonePushHistory();
        } catch (err) { showToast('Failed: ' + err.message, 'err'); }
        finally { setBtnLoading(pushDel, false); }
        return;
      }
      const bellTog = e.target.closest('[data-sa-bell-toggle]');
      if (bellTog) {
        setBtnLoading(bellTog, true, 'Updating...');
        try {
          const r = await saApiCall('superAdminManageNotification', { id: bellTog.getAttribute('data-sa-bell-toggle'), op: 'toggle' });
          showToast(r.message || 'Updated!', 'ok');
          loadBellNotificationsHistory();
        } catch (err) { showToast('Failed: ' + err.message, 'err'); }
        finally { setBtnLoading(bellTog, false); }
        return;
      }
      const bellDel = e.target.closest('[data-sa-bell-del]');
      if (bellDel) {
        setBtnLoading(bellDel, true, 'Removing...');
        try {
          const r = await saApiCall('superAdminManageNotification', { id: bellDel.getAttribute('data-sa-bell-del'), op: 'delete' });
          showToast(r.message || 'Removed!', 'ok');
          loadBellNotificationsHistory();
        } catch (err) { showToast('Failed: ' + err.message, 'err'); }
        finally { setBtnLoading(bellDel, false); }
        return;
      }
      const bcTog = e.target.closest('[data-sa-bc-toggle]');
      if (bcTog) {
        setBtnLoading(bcTog, true, 'Updating...');
        try {
          const r = await saApiCall('superAdminToggleBroadcast', {});
          showToast(r.message || 'Popup updated!', 'ok');
          loadBroadcastStatusCard();
        } catch (err) { showToast('Failed: ' + err.message, 'err'); }
        finally { setBtnLoading(bcTog, false); }
        return;
      }
      const bcRem = e.target.closest('[data-sa-bc-remove]');
      if (bcRem) {
        setBtnLoading(bcRem, true, 'Removing...');
        try {
          const r = await saApiCall('superAdminClearBroadcast', {});
          showToast(r.message || 'Popup removed!', 'ok');
          loadBroadcastStatusCard();
        } catch (err) { showToast('Failed: ' + err.message, 'err'); }
        finally { setBtnLoading(bcRem, false); }
        return;
      }

      const appOrd = e.target.closest('[data-sa-approve-order]');
      if (appOrd) {
        setBtnLoading(appOrd, true, 'Approving...');
        try {
          const res = await saApiCall('superAdminApproveOrder', { orderId: appOrd.getAttribute('data-sa-approve-order') });
          showToast(res.message || 'Order approved!', 'ok');
          await refreshSaDashboard(true);
        } catch (err) { showToast('Approve failed: ' + err.message, 'err'); }
        finally { setBtnLoading(appOrd, false); }
      }
    });
  }

  // Global 1-Step Android Hardware Back Button Handler
  function installAndroidBackStepHandler() {
    const prevHandler = typeof window.__handleAndroidBackButton === 'function' ? window.__handleAndroidBackButton : null;
    if (prevHandler && prevHandler.__plV22Wrapped) return;
    const wrapped = function () {
      try {
        const obModal = document.getElementById('plOnboardingModal');
        if (obModal && !obModal.hidden) { obModal.hidden = true; return 'handled'; }
        const bcModal = document.getElementById('plBroadcastPopupModal');
        if (bcModal && !bcModal.hidden) { bcModal.hidden = true; return 'handled'; }
        const qOverlay = document.getElementById('saQuickOverlay');
        if (qOverlay && !qOverlay.hidden) { closeQuickModal(); return 'handled'; }
        const saModal = document.getElementById('plSuperAdminModal');
        if (saModal && !saModal.hidden) {
          return stepBackSuperAdmin();
        }
        const pModal = document.getElementById('plPartnerModal');
        if (pModal && !pModal.hidden) {
          if (window.PocketLeadsPartner && typeof window.PocketLeadsPartner.stepBack === 'function') {
            return window.PocketLeadsPartner.stepBack();
          }
          const ovPane = pModal.querySelector('[data-pview-pane="overview"]');
          if (ovPane && ovPane.hidden) {
            const ovBtn = pModal.querySelector('[data-pview="overview"]');
            if (ovBtn) ovBtn.click();
            return 'handled';
          }
          if (window.PocketLeadsPartner && typeof window.PocketLeadsPartner.close === 'function') window.PocketLeadsPartner.close();
          else pModal.hidden = true;
          return 'handled';
        }
      } catch (_) {}
      return prevHandler ? prevHandler() : 'exit';
    };
    wrapped.__plV22Wrapped = true;
    window.__handleAndroidBackButton = wrapped;
  }

  document.addEventListener('DOMContentLoaded', () => {
    installAndroidBackStepHandler();
    setTimeout(installAndroidBackStepHandler, 900);
    document.addEventListener('click', (e) => {
      const b = e.target && e.target.closest ? e.target.closest('#plProfileBackToAdminMenuBtn') : null;
      if (b) { e.preventDefault(); e.stopPropagation(); returnToSuperAdminSession(b); }
    }, true);
    syncSuperAdminVisibility();
    setTimeout(syncSuperAdminVisibility, 1200);
    setTimeout(syncSuperAdminVisibility, 3200);
  });

  window.PocketLeadsSuperAdmin = {
    open: openSuperAdmin,
    close: closeSuperAdmin,
    refresh: () => refreshSaDashboard(true),
    returnToAdmin: returnToSuperAdminSession,
    syncVisibility: syncSuperAdminVisibility,
    isAuthorized: isAuthorizedSuperAdmin,
    toast: showToast
  };
})();
