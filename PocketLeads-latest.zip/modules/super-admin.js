(function () {
  'use strict';

  // v10.20.10 ZERO-TRUST SUPER ADMIN CONTROLLER
  // - Zero hardcoded phone numbers in frontend
  // - 100% matched to views/index.html IDs & apps_script_code.js response schema
  // - Built-in modal sheet for Edit Credit/Status & Grant Slots (zero blocked window.prompt on Android!)
  // - Single clean spinner (never double spinner) + instant SWR cache + floating toasts
  const SA_TOKEN_KEY = 'pl_super_admin_token';
  const SA_FLAG_KEY = 'pl_is_super_admin';
  const IMPERSONATE_BACKUP_KEY = 'pl_sa_impersonate_backup';
  const SA_CACHE_KEY = 'pl_sa_dash_cache_v2';

  let saData = null;
  let saActiveTab = 'users';
  let saRoleFilter = 'all';
  let saPartnerFilter = 'all';
  let saSearchText = '';
  let saBound = false;
  let saToastTimer = null;
  let saQuickMode = null; // { type: 'edit'|'grant', phone, name }

  function normPhone10(v) {
    const d = String(v || '').replace(/\D+/g, '');
    if (d.length === 10 && /^[6-9]/.test(d)) return d;
    if (d.length === 12 && d.startsWith('91') && /^[6-9]/.test(d.slice(2))) return d.slice(2);
    if (d.length === 11 && d.startsWith('0') && /^[6-9]/.test(d.slice(1))) return d.slice(1);
    return '';
  }

  function formatDisplayPhone(raw) {
    const p10 = normPhone10(raw);
    if (p10) return '+91 ' + p10;
    return String(raw || '').trim();
  }

  function esc(v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function getAdminToken() {
    try {
      const direct = String(localStorage.getItem(SA_TOKEN_KEY) || '').trim();
      if (direct && direct.includes('.')) return direct;
      const rawImp = localStorage.getItem(IMPERSONATE_BACKUP_KEY);
      if (rawImp) {
        const parsed = JSON.parse(rawImp);
        if (parsed && parsed.adminToken && String(parsed.adminToken).includes('.')) {
          return String(parsed.adminToken);
        }
      }
    } catch (_) {}
    return '';
  }

  function clearAdminToken() {
    try {
      localStorage.removeItem(SA_TOKEN_KEY);
      localStorage.removeItem(SA_FLAG_KEY);
      localStorage.removeItem(SA_CACHE_KEY);
    } catch (_) {}
  }

  function showToast(msg, type) {
    try {
      let el = document.getElementById('plGlobalToast');
      if (!el) {
        el = document.createElement('div');
        el.id = 'plGlobalToast';
        document.body.appendChild(el);
      }
      el.className = 'pl-global-toast is-' + (type || 'info') + ' is-show';
      el.textContent = String(msg || '');
      if (saToastTimer) clearTimeout(saToastTimer);
      saToastTimer = setTimeout(() => el.classList.remove('is-show'), 2600);
    } catch (_) {}
  }

  function setBtnLoading(btn, loading, loadingText) {
    if (!btn) return;
    if (loading) {
      if (!btn.dataset.origHtml) btn.dataset.origHtml = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="pl-btn-spin" aria-hidden="true"></span> ' + esc(loadingText || 'Working...');
    } else {
      btn.disabled = false;
      if (btn.dataset.origHtml) {
        btn.innerHTML = btn.dataset.origHtml;
        delete btn.dataset.origHtml;
      }
    }
  }

  function setSyncPill(visible, text) {
    const pill = document.getElementById('saSyncPill');
    if (!pill) return;
    if (visible) {
      pill.hidden = false;
      pill.innerHTML = '<span class="pl-btn-spin" aria-hidden="true"></span> ' + esc(text || 'Syncing...');
    } else {
      pill.hidden = true;
    }
  }

  function setSaStatus(msg, type) {
    const el = document.getElementById('saStatusBanner');
    if (!el) return;
    if (!msg) { el.hidden = true; el.textContent = ''; return; }
    el.hidden = false;
    el.className = 'sa-status' + (type === 'err' ? ' is-err' : (type === 'ok' ? ' is-ok' : ''));
    el.textContent = msg;
  }

  async function getCurrentSession() {
    let key = '', deviceId = '';
    try {
      if (window.PocketLeadsAccount && typeof window.PocketLeadsAccount.read === 'function') {
        const st = await window.PocketLeadsAccount.read();
        const lic = (st && st.license) || st || {};
        key = String(lic.key || lic.licenceKey || (st && st.pocketleadsAccount && st.pocketleadsAccount.key) || '').trim();
        deviceId = String(lic.installationId || lic.deviceId || '').trim();
      } else if (window.PocketLeadsAccount && typeof window.PocketLeadsAccount.getState === 'function') {
        const st = await window.PocketLeadsAccount.getState();
        key = String((st && (st.key || st.licenceKey || (st.account && st.account.key))) || '').trim();
        deviceId = String((st && (st.deviceId || st.installationId)) || '').trim();
      }
    } catch (_) {}
    if (!deviceId) {
      try {
        if (window.PocketLeadsAccount && typeof window.PocketLeadsAccount.getDeviceId === 'function') {
          deviceId = String((await window.PocketLeadsAccount.getDeviceId()) || '').trim();
        }
      } catch (_) {}
    }
    if (!key) {
      try { key = String(localStorage.getItem('licenceKey') || localStorage.getItem('pl_licence_key') || '').trim(); } catch (_) {}
    }
    if (!deviceId) {
      try { deviceId = String(localStorage.getItem('deviceId') || localStorage.getItem('pl_device_id') || localStorage.getItem('pl_installation_id') || '').trim(); } catch (_) {}
    }
    return { key, phone10: normPhone10(key), deviceId: deviceId || 'android-admin' };
  }

  async function isAuthorizedSuperAdmin() {
    return !!getAdminToken();
  }

  function applyImpersonationBannerUI() {
    const banner = document.getElementById('plImpersonateBanner');
    if (banner) banner.hidden = true;
    document.body.classList.remove('pl-impersonating');

    let imp = null;
    try {
      const raw = localStorage.getItem(IMPERSONATE_BACKUP_KEY);
      if (raw) imp = JSON.parse(raw);
    } catch (_) {}

    const backBtn = document.getElementById('plProfileBackToAdminMenuBtn');
    const backSub = document.getElementById('plProfileBackToAdminSub');
    const hasToken = !!getAdminToken();
    const showBack = !!(hasToken && imp && imp.targetKey);
    if (backBtn) {
      backBtn.hidden = !showBack;
      backBtn.style.setProperty('display', showBack ? 'flex' : 'none', 'important');
    }
    if (showBack && backSub) {
      const labelName = String(imp.targetName || imp.targetPhone || 'User').trim();
      backSub.textContent = 'Viewing: ' + labelName + ' • Tap to return';
    }
  }

  async function syncSuperAdminVisibility() {
    const allowed = await isAuthorizedSuperAdmin();
    const btn = document.getElementById('plProfileSuperAdminMenuBtn');
    if (btn) {
      btn.hidden = !allowed;
      btn.style.setProperty('display', allowed ? 'flex' : 'none', 'important');
    }
    applyImpersonationBannerUI();
  }

  async function saApiCall(action, extra) {
    const token = getAdminToken();
    if (!token) {
      throw new Error('Super Admin OTP session required. Please sign in with OTP.');
    }
    const sess = await getCurrentSession();
    const base = (window.POCKETLEADS_CONFIG && window.POCKETLEADS_CONFIG.API_BASE_URL)
      || 'https://pocketleads-edge.samimn7890.workers.dev/exec';
    const payload = Object.assign({
      action: action,
      key: sess.phone10 || sess.key || '',
      adminToken: token,
      deviceId: sess.deviceId || 'android-admin'
    }, extra || {});

    const res = await fetch(base, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Admin-Token': token
      },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data && data.reason === 'super_admin_token_required') {
      clearAdminToken();
      syncSuperAdminVisibility();
      throw new Error('Super Admin OTP session expired. Please sign out and log in again with OTP.');
    }
    if (!res.ok || !data || (data.status && data.status !== 'ok')) {
      throw new Error((data && (data.message || data.reason)) || ('HTTP ' + res.status));
    }
    return data;
  }

  function roleBadge(role) {
    if (role === 'super_admin') return '<span class="sa-badge sa-badge-admin">SUPER ADMIN</span>';
    if (role === 'partner') return '<span class="sa-badge sa-badge-partner">PARTNER</span>';
    if (role === 'partner_user' || role === 'partner_customer') return '<span class="sa-badge sa-badge-puser">PARTNER USER</span>';
    return '<span class="sa-badge sa-badge-normal">NORMAL USER</span>';
  }

  function renderUsersList() {
    const container = document.getElementById('saUsersList');
    if (!container) return;
    if (!saData) {
      container.innerHTML = [1, 2, 3].map(() => '<div class="pl-skel-card"><div class="pl-skel-line w-60"></div><div class="pl-skel-line w-40"></div><div class="pl-skel-line w-90"></div></div>').join('');
      return;
    }
    let list = (saData.users || []).slice();
    if (saRoleFilter === 'normal_user') list = list.filter(u => u.role === 'normal_user' || u.role === 'normal' || u.role === 'super_admin');
    else if (saRoleFilter === 'partner') list = list.filter(u => u.role === 'partner' || u.isPartner);
    else if (saRoleFilter === 'partner_user') list = list.filter(u => u.role === 'partner_user' || u.role === 'partner_customer');

    if (saPartnerFilter && saPartnerFilter !== 'all') {
      list = list.filter(u => u.partnerPhone === saPartnerFilter || u.phone10 === saPartnerFilter);
    }
    if (saSearchText) {
      const q = saSearchText.toLowerCase();
      list = list.filter(u =>
        String(u.name || '').toLowerCase().includes(q) ||
        String(u.phone || '').toLowerCase().includes(q) ||
        String(u.email || '').toLowerCase().includes(q) ||
        String(u.partnerName || '').toLowerCase().includes(q)
      );
    }

    if (!list.length) {
      container.innerHTML = '<div class="sa-empty">No users match the selected filter.</div>';
      return;
    }

    container.innerHTML = list.map(u => {
      const availStr = Number(u.availableCredit) >= 999999999 ? 'Unlimited' : Number(u.availableCredit || 0).toLocaleString('en-IN');
      const purchStr = Number(u.purchasedCredit) >= 999999999 ? 'Unlimited' : Number(u.purchasedCredit || 0).toLocaleString('en-IN');
      const isAct = String(u.status || 'active').toLowerCase() === 'active';
      const partnerMeta = u.partnerPhone
        ? `<div class="sa-user-partner-tag">Under Partner: <strong>${esc(u.partnerName || u.partnerPhone)}</strong> (${esc(u.partnerPhone)})</div>`
        : '';
      const partnerSlotMeta = u.isPartner
        ? `<div class="sa-user-partner-tag is-gold">Partner Slots: <strong>${u.partnerAvailableSlots || 0} Avail</strong> &bull; ${u.partnerUsedSlots || 0} Sold &bull; ${u.partnerTotalSlots || 0} Total</div>`
        : '';
      const dispPhone = formatDisplayPhone(u.phone || u.phone10);
      const targetId = u.phone10 || u.phone || '';

      return `<div class="sa-user-card">
        <div class="sa-user-top">
          <div class="sa-user-ident">
            <div class="sa-avatar">${esc((u.name || 'U').slice(0, 2).toUpperCase())}</div>
            <div>
              <div class="sa-user-name">${esc(u.name || 'User')} ${roleBadge(u.role)}</div>
              <div class="sa-user-sub">${esc(dispPhone)}${u.email ? ' &bull; ' + esc(u.email) : ''}</div>
            </div>
          </div>
          <span class="sa-status-dot ${isAct ? 'is-active' : 'is-inactive'}">${esc(u.status || 'Active')}</span>
        </div>
        ${partnerMeta}
        ${partnerSlotMeta}
        <div class="sa-meta-grid">
          <div class="sa-metric-box"><span>Available Credit</span><strong class="is-orange">${availStr}</strong></div>
          <div class="sa-metric-box"><span>Purchased</span><strong>${purchStr}</strong></div>
          <div class="sa-metric-box"><span>API Mode</span><strong>${esc(u.apiMode || 'Central')}</strong></div>
          <div class="sa-metric-box"><span>Validity</span><strong>${esc(u.validityDate || 'Active')}</strong></div>
        </div>
        <div class="sa-actions">
          <button type="button" class="sa-btn is-primary" data-sa-login="${esc(targetId)}" data-sa-name="${esc(u.name || 'User')}">Login as User (No OTP)</button>
          <button type="button" class="sa-btn" data-sa-edit="${esc(targetId)}">Edit Credit / Status</button>
          <button type="button" class="sa-btn is-gold" data-sa-grant="${esc(targetId)}" data-sa-name="${esc(u.name || 'Partner')}">+ Grant Slots</button>
        </div>
      </div>`;
    }).join('');
  }

  function renderSaDashboard(data) {
    saData = data;
    const s = data.summary || {};
    const users = data.users || [];
    const partners = (data.partners || []).filter(p => p && (normPhone10(p.phone10 || p.phone) || String(p.name || '').trim()));
    const pendingOrders = data.pendingOrders || data.orders || [];

    const setT = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = String(v); };
    setT('saKpiTotal', s.totalUsers != null ? s.totalUsers : users.length);
    setT('saKpiPartners', s.totalPartners != null ? s.totalPartners : partners.length);
    setT('saKpiPartnerUsers', s.partnerUsers != null ? s.partnerUsers : users.filter(u => u.role === 'partner_user').length);
    setT('saKpiPending', s.pendingOrders != null ? s.pendingOrders : pendingOrders.length);

    // Populate Partner Filter Dropdown (#saPartnerFilter)
    const pf = document.getElementById('saPartnerFilter');
    if (pf) {
      const cur = pf.value || 'all';
      pf.innerHTML = '<option value="all">All Partners</option>' +
        partners.map(p => `<option value="${esc(p.phone10)}">${esc(p.name || p.phone10)} (${esc(p.phone10)} &bull; ${p.soldUsersCount || p.usedSlots || 0} sold)</option>`).join('');
      pf.value = cur;
    }

    renderUsersList();

    // Render Partners Tab (#saPartnersList)
    const pList = document.getElementById('saPartnersList');
    if (pList) {
      if (!partners.length) {
        pList.innerHTML = '<div class="sa-empty">No partners registered yet.</div>';
      } else {
        pList.innerHTML = partners.map(p => `
          <div class="sa-user-card">
            <div class="sa-user-top">
              <div class="sa-user-ident">
                <div class="sa-avatar is-gold">${esc((p.name || 'P').slice(0, 2).toUpperCase())}</div>
                <div>
                  <div class="sa-user-name">${esc(p.name || 'Partner')} <span class="sa-badge sa-badge-partner">PARTNER</span></div>
                  <div class="sa-user-sub">${esc(formatDisplayPhone(p.phone10))}${p.email ? ' &bull; ' + esc(p.email) : ''}</div>
                </div>
              </div>
              <span class="sa-status-dot is-active">${esc(p.status || 'Active')}</span>
            </div>
            <div class="sa-meta-grid">
              <div class="sa-metric-box"><span>Total Slots</span><strong>${p.totalSlots || 0}</strong></div>
              <div class="sa-metric-box"><span>Available</span><strong class="is-orange">${p.availableSlots || 0}</strong></div>
              <div class="sa-metric-box"><span>Sold Users</span><strong>${p.soldUsersCount != null ? p.soldUsersCount : (p.usedSlots || 0)}</strong></div>
              <div class="sa-metric-box"><span>Est. Profit</span><strong class="is-green">&#8377;${Number(p.estimatedProfitInr || ((p.usedSlots || 0) * 804)).toLocaleString('en-IN')}</strong></div>
            </div>
            <div class="sa-actions">
              <button type="button" class="sa-btn is-primary" data-sa-filter-partner="${esc(p.phone10)}">View Users</button>
              <button type="button" class="sa-btn is-gold" data-sa-grant="${esc(p.phone10)}" data-sa-name="${esc(p.name || 'Partner')}">+ Grant Slots</button>
              <button type="button" class="sa-btn" data-sa-login="${esc(p.phone10)}" data-sa-name="${esc(p.name || 'Partner')}">Login as Partner</button>
            </div>
          </div>
        `).join('');
      }
    }

    // Render Pending Orders Tab (#saOrdersList)
    const oList = document.getElementById('saOrdersList');
    if (oList) {
      if (!pendingOrders.length) {
        oList.innerHTML = '<div class="sa-empty">No pending partner slot orders.</div>';
      } else {
        oList.innerHTML = pendingOrders.map(o => {
          const slots = o.packSlots || o.slots || 0;
          const amt = o.amount || o.amountInr || 0;
          return `<div class="sa-user-card">
            <div class="sa-user-top">
              <div>
                <div class="sa-user-name">${esc(o.orderId)} &bull; ${slots} Slot${slots > 1 ? 's' : ''} (&#8377;${Number(amt).toLocaleString('en-IN')})</div>
                <div class="sa-user-sub">Partner: ${esc(o.partnerName || '')} ${esc(formatDisplayPhone(o.partnerPhone))} &bull; Ref: ${esc(o.paymentRef || 'Pending')}</div>
              </div>
              <span class="sa-status-dot is-inactive">${esc(o.status || 'Pending')}</span>
            </div>
            <div class="sa-actions">
              <button type="button" class="sa-btn is-primary" data-sa-approve-order="${esc(o.orderId)}">Approve &amp; Credit ${slots} Slots</button>
            </div>
          </div>`;
        }).join('');
      }
    }
  }

  async function refreshSaDashboard(forceFresh, triggerBtn) {
    // SINGLE SPINNER RULE: If user clicked Refresh button, spin ONLY the button (never double spinner with pill!)
    if (triggerBtn) {
      setSyncPill(false);
      setBtnLoading(triggerBtn, true, 'Syncing...');
    } else {
      setSyncPill(true, 'Syncing...');
    }

    if (!saData) {
      try {
        const cachedRaw = localStorage.getItem(SA_CACHE_KEY);
        if (cachedRaw) {
          const parsed = JSON.parse(cachedRaw);
          if (parsed && parsed.users) renderSaDashboard(parsed);
        }
      } catch (_) {}
    }

    try {
      const data = await saApiCall('superAdminDashboard', forceFresh ? { force: '1' } : {});
      renderSaDashboard(data);
      try { localStorage.setItem(SA_CACHE_KEY, JSON.stringify(data)); } catch (_) {}
      setSaStatus('', 'info');
      if (triggerBtn) showToast('Super Admin synced!', 'ok');
    } catch (err) {
      setSaStatus('Sync failed: ' + err.message, 'err');
      showToast('Sync failed: ' + err.message, 'err');
    } finally {
      setSyncPill(false);
      if (triggerBtn) setBtnLoading(triggerBtn, false);
    }
  }


  async function loadSaErrorLogs(triggerBtn) {
    const listEl = document.getElementById('saErrorsList');
    const phInput = document.getElementById('saErrorPhoneFilter');
    const phFilter = phInput ? phInput.value.trim() : '';
    if (triggerBtn) setBtnLoading(triggerBtn, true, 'Loading...');
    if (listEl) listEl.innerHTML = '<div class="sa-empty"><span class="pl-btn-spin" aria-hidden="true"></span> Fetching live API error logs...</div>';
    try {
      const res = await saApiCall('superAdminErrorLogs', { targetPhone: phFilter, limit: 60 });
      const logs = res.logs || [];
      if (!logs.length) {
        if (listEl) listEl.innerHTML = '<div class="sa-empty">No API errors recorded' + (phFilter ? (' for ' + esc(phFilter)) : '') + '.</div>';
      } else if (listEl) {
        listEl.innerHTML = logs.map(l => `<div class="sa-err-card">
          <div class="sa-err-top">
            <span class="sa-err-phone">${esc(formatDisplayPhone(l.phone) || 'Unknown User')} &bull; ${esc(l.provider || 'API')} ${l.code ? ('[' + esc(l.code) + ']') : ''}</span>
            <span class="sa-err-time">${esc(l.timestamp || '')}</span>
          </div>
          <div class="sa-err-msg">${esc(l.message || 'No error detail')}</div>
        </div>`).join('');
      }
      if (triggerBtn) showToast('Loaded ' + logs.length + ' error logs', 'ok');
    } catch (err) {
      if (listEl) listEl.innerHTML = '<div class="sa-empty">Failed to load error logs: ' + esc(err.message) + '</div>';
      showToast('Error logs failed: ' + err.message, 'err');
    } finally {
      if (triggerBtn) setBtnLoading(triggerBtn, false);
    }
  }

  function switchSaTab(tab) {
    saActiveTab = tab || 'users';
    document.querySelectorAll('#plSuperAdminModal [data-satab]').forEach(b => {
      b.classList.toggle('is-active', b.getAttribute('data-satab') === saActiveTab);
    });
    document.querySelectorAll('#plSuperAdminModal [data-sapane]').forEach(p => {
      p.hidden = p.getAttribute('data-sapane') !== saActiveTab;
    });
    if (saActiveTab === 'errors') loadSaErrorLogs();
  }

  function openQuickModal(mode) {
    saQuickMode = mode;
    const overlay = document.getElementById('saQuickOverlay');
    const title = document.getElementById('saQuickTitle');
    const sub = document.getElementById('saQuickSub');
    const editFields = document.getElementById('saQuickEditFields');
    const grantFields = document.getElementById('saQuickGrantFields');
    const saveBtn = document.getElementById('saQuickSaveBtn');
    if (!overlay) return;

    if (mode.type === 'edit') {
      const u = (saData && saData.users || []).find(x => (x.phone10 || x.phone) === mode.phone);
      if (title) title.textContent = 'Edit User Account';
      if (sub) sub.textContent = (u ? u.name : mode.phone) + ' (' + formatDisplayPhone(mode.phone) + ')';
      if (editFields) editFields.hidden = false;
      if (grantFields) grantFields.hidden = true;
      const cr = document.getElementById('saQuickCreditInput');
      const st = document.getElementById('saQuickStatusSelect');
      const am = document.getElementById('saQuickApiModeSelect');
      if (cr) cr.value = u ? String(u.availableCredit || 0) : '100000';
      if (st) st.value = (u && /^inactive$/i.test(u.status)) ? 'Inactive' : ((u && /^suspended$/i.test(u.status)) ? 'Suspended' : 'Active');
      if (am) am.value = (u && /^individual$/i.test(u.apiMode)) ? 'Individual' : 'Central';
      if (saveBtn) saveBtn.textContent = 'Save Changes';
    } else {
      if (title) title.textContent = 'Grant Partner Slots';
      if (sub) sub.textContent = (mode.name || 'Partner') + ' (' + formatDisplayPhone(mode.phone) + ')';
      if (editFields) editFields.hidden = true;
      if (grantFields) grantFields.hidden = false;
      const sl = document.getElementById('saQuickSlotsInput');
      if (sl) sl.value = '5';
      if (saveBtn) saveBtn.textContent = '+ Grant Slots Now';
    }
    overlay.hidden = false;
  }

  function closeQuickModal() {
    const overlay = document.getElementById('saQuickOverlay');
    if (overlay) overlay.hidden = true;
    saQuickMode = null;
  }

  async function loginAsUserWithoutOtp(targetPhone, targetName, triggerBtn) {
    setBtnLoading(triggerBtn, true, 'Logging in...');
    setSaStatus('Switching to ' + (targetName || targetPhone) + ' (No OTP)...', 'info');
    try {
      const res = await saApiCall('superAdminImpersonate', { targetId: targetPhone, targetPhone: targetPhone });
      const sess = await getCurrentSession();
      const adminToken = getAdminToken();
      const backup = {
        adminKey: sess.key || sess.phone10 || '',
        adminPhone: sess.phone10 || '',
        adminToken: adminToken,
        deviceId: sess.deviceId || 'android-admin',
        targetKey: res.key || targetPhone,
        targetPhone: res.phone10 || targetPhone,
        targetName: (res.account && res.account.name) || targetName || targetPhone,
        at: Date.now()
      };
      localStorage.setItem(IMPERSONATE_BACKUP_KEY, JSON.stringify(backup));

      const targetKey = String(res.key || targetPhone).trim();
      try {
        localStorage.setItem('licenceKey', targetKey);
        localStorage.setItem('pl_licence_key', targetKey);
        localStorage.setItem('pl_active_phone', String(res.phone10 || targetPhone));
      } catch (_) {}

      try {
        if (window.chrome && chrome.storage && chrome.storage.local) {
          await new Promise(r => chrome.storage.local.set({
            licenceKey: targetKey,
            pl_licence_key: targetKey,
            pl_account_cache: res.account || null
          }, r));
        }
      } catch (_) {}

      if (window.PocketLeadsAccount && typeof window.PocketLeadsAccount.applyImpersonatedSession === 'function') {
        await window.PocketLeadsAccount.applyImpersonatedSession(res, targetKey, sess.deviceId);
      }

      closeSuperAdmin();
      applyImpersonationBannerUI();
      showToast('Switched to ' + backup.targetName + '!', 'ok');
      setTimeout(() => { window.location.reload(); }, 180);
    } catch (err) {
      setBtnLoading(triggerBtn, false);
      setSaStatus('Login failed: ' + err.message, 'err');
      showToast('Login failed: ' + err.message, 'err');
    }
  }

  async function returnToSuperAdminSession(triggerBtn) {
    setBtnLoading(triggerBtn, true, 'Returning...');
    let backup = null;
    try {
      const raw = localStorage.getItem(IMPERSONATE_BACKUP_KEY);
      if (raw) backup = JSON.parse(raw);
    } catch (_) {}

    const adminKey = (backup && (backup.adminKey || backup.adminPhone)) || '';
    const adminToken = (backup && backup.adminToken) || getAdminToken();
    try {
      if (adminToken) {
        localStorage.setItem(SA_TOKEN_KEY, adminToken);
        localStorage.setItem(SA_FLAG_KEY, '1');
      }
      localStorage.removeItem(IMPERSONATE_BACKUP_KEY);
      if (adminKey) {
        localStorage.setItem('licenceKey', adminKey);
        localStorage.setItem('pl_licence_key', adminKey);
        localStorage.setItem('pl_active_phone', adminKey);
      }
    } catch (_) {}
    try {
      if (adminKey && window.PocketLeadsAccount && typeof window.PocketLeadsAccount.applyImpersonatedSession === 'function') {
        const resBack = await saApiCall('superAdminImpersonate', { targetId: adminKey, targetPhone: adminKey }).catch(() => null);
        await window.PocketLeadsAccount.applyImpersonatedSession(resBack || { status: 'ok', key: adminKey }, adminKey, (backup && backup.deviceId) || '');
      } else if (adminKey && window.chrome && chrome.storage && chrome.storage.local) {
        await new Promise(r => chrome.storage.local.set({ licenceKey: adminKey, pl_licence_key: adminKey }, r));
      }
    } catch (_) {}
    document.body.classList.remove('pl-impersonating');
    showToast('Returned to Super Admin', 'ok');
    setTimeout(() => { window.location.reload(); }, 150);
  }

  async function openSuperAdmin() {
    const allowed = await isAuthorizedSuperAdmin();
    if (!allowed) {
      showToast('Super Admin OTP login required.', 'err');
      return;
    }
    const modal = document.getElementById('plSuperAdminModal');
    if (!modal) return;
    modal.hidden = false;
    document.body.style.overflow = 'hidden';
    bindSaEvents();
    switchSaTab('users');
    await refreshSaDashboard(false);
  }

  function closeSuperAdmin() {
    const modal = document.getElementById('plSuperAdminModal');
    if (modal) modal.hidden = true;
    closeQuickModal();
    document.body.style.overflow = '';
  }

  function bindSaEvents() {
    if (saBound) return;
    saBound = true;

    const modal = document.getElementById('plSuperAdminModal');
    if (!modal) return;

    const closeBtn = document.getElementById('saCloseBtn');
    if (closeBtn) closeBtn.addEventListener('click', closeSuperAdmin);
    const refBtn = document.getElementById('saRefreshBtn');
    if (refBtn) refBtn.addEventListener('click', () => refreshSaDashboard(true, refBtn));



    // Photo Upload + Client-Side Canvas Compression (max 720px JPEG ~30KB) for Rich Notifications!
    let uploadedNotifImageData = '';
    const fileInput = document.getElementById('saNotifImageFile');
    const prevWrap = document.getElementById('saNotifImgPreviewWrap');
    const prevImg = document.getElementById('saNotifImgPreview');
    const clearImgBtn = document.getElementById('saNotifClearImgBtn');
    if (fileInput) {
      fileInput.addEventListener('change', (ev) => {
        const f = ev.target && ev.target.files && ev.target.files[0];
        if (!f) return;
        const reader = new FileReader();
        reader.onload = () => {
          const img = new Image();
          img.onload = () => {
            const maxW = 720;
            const scale = img.width > maxW ? (maxW / img.width) : 1;
            const c = document.createElement('canvas');
            c.width = Math.max(1, Math.round(img.width * scale));
            c.height = Math.max(1, Math.round(img.height * scale));
            const ctx2 = c.getContext('2d');
            ctx2.drawImage(img, 0, 0, c.width, c.height);
            uploadedNotifImageData = c.toDataURL('image/jpeg', 0.76);
            if (prevImg) prevImg.src = uploadedNotifImageData;
            if (prevWrap) prevWrap.hidden = false;
            showToast('Photo attached (' + Math.round(uploadedNotifImageData.length / 1024) + ' KB)', 'ok');
          };
          img.src = String(reader.result || '');
        };
        reader.readAsDataURL(f);
      });
    }
    if (clearImgBtn) {
      clearImgBtn.addEventListener('click', () => {
        uploadedNotifImageData = '';
        if (fileInput) fileInput.value = '';
        if (prevWrap) prevWrap.hidden = true;
      });
    }

    // Rich Text + Image Notification Sender (#saSendNotifForm)
    const notifForm = document.getElementById('saSendNotifForm');
    if (notifForm) {
      notifForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('saNotifSubmitBtn');
        setBtnLoading(btn, true, 'Sending...');
        try {
          const res = await saApiCall('superAdminSendNotification', {
            title: (document.getElementById('saNotifTitle') || {}).value || '',
            message: (document.getElementById('saNotifMessage') || {}).value || '',
            type: (document.getElementById('saNotifType') || {}).value || 'offer',
            imageUrl: (document.getElementById('saNotifImageUrl') || {}).value || '',
            imageData: uploadedNotifImageData || '',
            ctaText: (document.getElementById('saNotifCtaText') || {}).value || '',
            ctaUrl: (document.getElementById('saNotifCtaUrl') || {}).value || ''
          });
          notifForm.reset(); uploadedNotifImageData = ''; if (prevWrap) prevWrap.hidden = true; if (window.PocketLeadsUserUI) window.PocketLeadsUserUI.syncNotifications();
          if (window.plHaptic) window.plHaptic('success');
          showToast(res.message || 'Notification sent to all users!', 'ok');
        } catch (err) {
          showToast('Notification failed: ' + err.message, 'err');
        } finally {
          setBtnLoading(btn, false);
        }
      });
    }

    // Broadcast Publish & Clear Form (#saBroadcastForm)
    const bcForm = document.getElementById('saBroadcastForm');
    if (bcForm) {
      bcForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('saBcPublishBtn');
        setBtnLoading(btn, true, 'Publishing...');
        try {
          const res = await saApiCall('superAdminPublishBroadcast', {
            title: (document.getElementById('saBcTitle') || {}).value || '',
            message: (document.getElementById('saBcMessage') || {}).value || '',
            audience: (document.getElementById('saBcAudience') || {}).value || 'all',
            tone: (document.getElementById('saBcTone') || {}).value || 'orange'
          });
          if (window.plHaptic) window.plHaptic('success');
          showToast(res.message || 'Broadcast published live!', 'ok');
          if (window.PocketLeadsUX) window.PocketLeadsUX.refreshBroadcast();
        } catch (err) {
          showToast('Broadcast failed: ' + err.message, 'err');
        } finally {
          setBtnLoading(btn, false);
        }
      });
    }
    const bcClear = document.getElementById('saBcClearBtn');
    if (bcClear) {
      bcClear.addEventListener('click', async () => {
        setBtnLoading(bcClear, true, 'Clearing...');
        try {
          const res = await saApiCall('superAdminClearBroadcast', {});
          if (window.plHaptic) window.plHaptic('tap');
          showToast(res.message || 'Broadcast cleared!', 'ok');
          if (window.PocketLeadsUX) window.PocketLeadsUX.refreshBroadcast();
        } catch (err) {
          showToast('Clear failed: ' + err.message, 'err');
        } finally {
          setBtnLoading(bcClear, false);
        }
      });
    }

    const errBtn = document.getElementById('saLoadErrorsBtn');
    if (errBtn) errBtn.addEventListener('click', () => loadSaErrorLogs(errBtn));

    // Tabs (exact attribute: data-satab)
    modal.querySelectorAll('[data-satab]').forEach(b => {
      b.addEventListener('click', () => switchSaTab(b.getAttribute('data-satab')));
    });

    // Filters (exact IDs: saUserSearch, saRoleFilter, saPartnerFilter)
    const srch = document.getElementById('saUserSearch');
    if (srch) srch.addEventListener('input', () => { saSearchText = srch.value.trim(); renderUsersList(); });
    const rf = document.getElementById('saRoleFilter');
    if (rf) rf.addEventListener('change', () => { saRoleFilter = rf.value || 'all'; renderUsersList(); });
    const pf = document.getElementById('saPartnerFilter');
    if (pf) pf.addEventListener('change', () => { saPartnerFilter = pf.value || 'all'; renderUsersList(); });

    // Direct Grant Slots Form (#saGrantSlotsForm)
    const grantForm = document.getElementById('saGrantSlotsForm');
    if (grantForm) {
      grantForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const phone = String((document.getElementById('saGrantPhone') || {}).value || '').trim();
        const slots = parseInt(String((document.getElementById('saGrantCount') || {}).value || '0'), 10);
        const btn = grantForm.querySelector('button[type="submit"]');
        if (!normPhone10(phone) || !slots || slots <= 0) {
          showToast('Enter a valid 10-digit partner phone & slots.', 'err');
          return;
        }
        setBtnLoading(btn, true, 'Granting...');
        try {
          const res = await saApiCall('superAdminGrantPartnerSlots', { partnerPhone: phone, slots: slots });
          grantForm.reset();
          showToast(res.message || ('Granted ' + slots + ' slots!'), 'ok');
          await refreshSaDashboard(true);
        } catch (err) {
          showToast('Grant failed: ' + err.message, 'err');
        } finally {
          setBtnLoading(btn, false);
        }
      });
    }

    // Create User Role dynamic fields (#saNewRole -> #saNewSlotsWrap & #saAssignPartnerWrap)
    const roleSel = document.getElementById('saNewRole');
    if (roleSel) {
      roleSel.addEventListener('change', () => {
        const v = roleSel.value;
        const sWrap = document.getElementById('saNewSlotsWrap');
        const pWrap = document.getElementById('saAssignPartnerWrap');
        if (sWrap) sWrap.style.display = v === 'partner' ? 'block' : 'none';
        if (pWrap) pWrap.style.display = v === 'partner_user' ? 'block' : 'none';
      });
    }

    // Create User Form Submit (#saCreateUserForm)
    const form = document.getElementById('saCreateUserForm');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('saCreateSubmitBtn');
        setBtnLoading(btn, true, 'Creating...');
        try {
          const res = await saApiCall('superAdminCreateUser', {
            name: (document.getElementById('saNewName') || {}).value || '',
            phone: (document.getElementById('saNewPhone') || {}).value || '',
            email: (document.getElementById('saNewEmail') || {}).value || '',
            role: (document.getElementById('saNewRole') || {}).value || 'normal_user',
            credits: Number((document.getElementById('saNewCredits') || {}).value || 100000),
            validity: (document.getElementById('saNewValidity') || {}).value || '1 year',
            apiMode: (document.getElementById('saNewApiMode') || {}).value || 'Central',
            initialSlots: Number((document.getElementById('saNewSlots') || {}).value || 0),
            partnerPhone: (document.getElementById('saAssignPartnerPhone') || {}).value || ''
          });
          form.reset();
          showToast(res.message || 'Account created!', 'ok');
          await refreshSaDashboard(true);
          switchSaTab('users');
        } catch (err) {
          showToast('Create failed: ' + err.message, 'err');
        } finally {
          setBtnLoading(btn, false);
        }
      });
    }

    // Built-in Quick Modal buttons (Cancel, Slot Chips, Save)
    const qCancel = document.getElementById('saQuickCancelBtn');
    if (qCancel) qCancel.addEventListener('click', closeQuickModal);
    const qOverlay = document.getElementById('saQuickOverlay');
    if (qOverlay) {
      qOverlay.addEventListener('click', (e) => {
        if (e.target === qOverlay) closeQuickModal();
        const chip = e.target.closest('[data-sa-slot-chip]');
        if (chip) {
          const sl = document.getElementById('saQuickSlotsInput');
          if (sl) sl.value = chip.getAttribute('data-sa-slot-chip');
        }
      });
    }
    const qSave = document.getElementById('saQuickSaveBtn');
    if (qSave) {
      qSave.addEventListener('click', async () => {
        if (!saQuickMode) return;
        setBtnLoading(qSave, true, 'Saving...');
        try {
          if (saQuickMode.type === 'edit') {
            const cred = Number((document.getElementById('saQuickCreditInput') || {}).value || 0);
            const status = (document.getElementById('saQuickStatusSelect') || {}).value || 'Active';
            const apiMode = (document.getElementById('saQuickApiModeSelect') || {}).value || 'Central';
            const res = await saApiCall('superAdminUpdateUser', {
              targetPhone: saQuickMode.phone,
              availableCredit: cred,
              status: status,
              apiMode: apiMode
            });
            closeQuickModal();
            showToast(res.message || 'User updated!', 'ok');
            await refreshSaDashboard(true);
          } else {
            const slots = parseInt(String((document.getElementById('saQuickSlotsInput') || {}).value || '0'), 10);
            if (!slots || slots <= 0) throw new Error('Enter valid slot count');
            const res = await saApiCall('superAdminGrantPartnerSlots', {
              partnerPhone: saQuickMode.phone,
              slots: slots
            });
            closeQuickModal();
            showToast(res.message || ('Granted ' + slots + ' slots!'), 'ok');
            await refreshSaDashboard(true);
          }
        } catch (err) {
          showToast(err.message || 'Action failed', 'err');
        } finally {
          setBtnLoading(qSave, false);
        }
      });
    }

    // Delegated clicks inside Super Admin modal
    modal.addEventListener('click', async (e) => {
      const loginBtn = e.target.closest('[data-sa-login]');
      if (loginBtn) {
        await loginAsUserWithoutOtp(loginBtn.getAttribute('data-sa-login'), loginBtn.getAttribute('data-sa-name'), loginBtn);
        return;
      }
      const editBtn = e.target.closest('[data-sa-edit]');
      if (editBtn) {
        openQuickModal({ type: 'edit', phone: editBtn.getAttribute('data-sa-edit') });
        return;
      }
      const grantBtn = e.target.closest('[data-sa-grant]');
      if (grantBtn) {
        openQuickModal({ type: 'grant', phone: grantBtn.getAttribute('data-sa-grant'), name: grantBtn.getAttribute('data-sa-name') });
        return;
      }
      const filterP = e.target.closest('[data-sa-filter-partner]');
      if (filterP) {
        const pp = filterP.getAttribute('data-sa-filter-partner');
        saPartnerFilter = pp;
        saRoleFilter = 'all';
        const pfSel = document.getElementById('saPartnerFilter');
        const rfSel = document.getElementById('saRoleFilter');
        if (pfSel) pfSel.value = pp;
        if (rfSel) rfSel.value = 'all';
        switchSaTab('users');
        renderUsersList();
        return;
      }
      const appOrd = e.target.closest('[data-sa-approve-order]');
      if (appOrd) {
        const oid = appOrd.getAttribute('data-sa-approve-order');
        setBtnLoading(appOrd, true, 'Approving...');
        try {
          const res = await saApiCall('superAdminApproveOrder', { orderId: oid });
          showToast(res.message || 'Order approved!', 'ok');
          await refreshSaDashboard(true);
        } catch (err) {
          showToast('Approve failed: ' + err.message, 'err');
        } finally {
          setBtnLoading(appOrd, false);
        }
      }
    });
  }


  // v10.20.12: Global 1-Step Android Hardware Back Button Handler (Never accidentally closes APK!)
  function installAndroidBackStepHandler() {
    const prevHandler = typeof window.__handleAndroidBackButton === 'function' ? window.__handleAndroidBackButton : null;
    if (prevHandler && prevHandler.__plV12Wrapped) return;
    const wrapped = function () {
      try {
        const qOverlay = document.getElementById('saQuickOverlay');
        if (qOverlay && !qOverlay.hidden) { closeQuickModal(); return 'handled'; }

        const saModal = document.getElementById('plSuperAdminModal');
        if (saModal && !saModal.hidden) {
          if (saActiveTab && saActiveTab !== 'users') { switchSaTab('users'); return 'handled'; }
          closeSuperAdmin();
          return 'handled';
        }

        const pAdd = document.getElementById('pwAddCustomerDrawer');
        if (pAdd && !pAdd.hidden && pAdd.classList.contains('is-open')) {
          const closeAdd = document.getElementById('pwCloseAddDrawerBtn');
          if (closeAdd) closeAdd.click(); else pAdd.hidden = true;
          return 'handled';
        }

        const pSide = document.getElementById('pwSidebar');
        if (pSide && pSide.classList.contains('is-open')) {
          const closeSide = document.getElementById('pwDrawerCloseBtn');
          if (closeSide) closeSide.click(); else pSide.classList.remove('is-open');
          return 'handled';
        }

        const pModal = document.getElementById('plPartnerModal');
        if (pModal && !pModal.hidden) {
          const activeOv = pModal.querySelector('.pw-bnav-btn[data-pview="overview"].is-active');
          const ovPane = pModal.querySelector('[data-ppane="overview"]');
          const onOverview = ovPane ? !ovPane.hidden : !!activeOv;
          if (!onOverview) {
            const ovBtn = pModal.querySelector('[data-pview="overview"]');
            if (ovBtn) ovBtn.click();
            return 'handled';
          }
          if (window.PocketLeadsPartner && typeof window.PocketLeadsPartner.close === 'function') {
            window.PocketLeadsPartner.close();
          } else {
            pModal.hidden = true;
          }
          return 'handled';
        }
      } catch (_) {}
      if (prevHandler) {
        try { return prevHandler(); } catch (_) {}
      }
      return 'exit';
    };
    wrapped.__plV12Wrapped = true;
    window.__handleAndroidBackButton = wrapped;
  }

  document.addEventListener('DOMContentLoaded', () => {
    installAndroidBackStepHandler();
    setTimeout(installAndroidBackStepHandler, 900);
    setTimeout(installAndroidBackStepHandler, 2500);
    document.addEventListener('click', (e) => {
      const b = e.target && e.target.closest ? e.target.closest('#plProfileBackToAdminMenuBtn') : null;
      if (b) { e.preventDefault(); e.stopPropagation(); returnToSuperAdminSession(b); }
    }, true);
    syncSuperAdminVisibility();
    setTimeout(syncSuperAdminVisibility, 1200);
    setTimeout(syncSuperAdminVisibility, 3200);
  });

  window.PocketLeadsSuperAdmin = {
    open: openSuperAdmin,
    close: closeSuperAdmin,
    refresh: () => refreshSaDashboard(true),
    returnToAdmin: returnToSuperAdminSession,
    syncVisibility: syncSuperAdminVisibility,
    isAuthorized: isAuthorizedSuperAdmin,
    toast: showToast
  };
})();
