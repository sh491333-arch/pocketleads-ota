(function (g) {
  'use strict';

  // MODULE 1: SHARED SERVICES & APIS (Zero UI coupling)
  const SA_TOKEN_KEY = 'pl_super_admin_token';
  const IMPERSONATE_BACKUP_KEY = 'pl_sa_impersonate_backup';
  let toastTimer = null;

  function getApiBase() {
    const C = g.PocketLeadsConfig || g.POCKETLEADS_CONFIG || {};
    return C.edgeProxyUrl || C.API_BASE_URL || C.endpoint || 'https://pocketleads-edge.samimn7890.workers.dev/exec';
  }

  function normPhone10(v) {
    const d = String(v || '').replace(/\D+/g, '');
    if (d.length === 10 && /^[6-9]/.test(d)) return d;
    if (d.length === 12 && d.startsWith('91') && /^[6-9]/.test(d.slice(2))) return d.slice(2);
    if (d.length === 11 && d.startsWith('0') && /^[6-9]/.test(d.slice(1))) return d.slice(1);
    return '';
  }

  function formatPhone(raw) {
    const p10 = normPhone10(raw);
    return p10 ? ('+91 ' + p10) : String(raw || '').trim();
  }

  function esc(v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function haptic(type) {
    try {
      if (!navigator || typeof navigator.vibrate !== 'function') return;
      if (type === 'success') navigator.vibrate([22, 42, 30]);
      else if (type === 'warn') navigator.vibrate([35, 30, 35]);
      else navigator.vibrate(16);
    } catch (_) {}
  }

  function toast(msg, type) {
    try {
      let el = document.getElementById('plGlobalToast');
      if (!el) {
        el = document.createElement('div');
        el.id = 'plGlobalToast';
        document.body.appendChild(el);
      }
      el.className = 'pl-global-toast is-' + (type || 'info') + ' is-show';
      el.textContent = String(msg || '');
      if (toastTimer) clearTimeout(toastTimer);
      toastTimer = setTimeout(() => el.classList.remove('is-show'), 2600);
    } catch (_) {}
  }

  function setBtnLoading(btn, loading, text) {
    if (!btn) return;
    if (loading) {
      if (!btn.dataset.origHtml) btn.dataset.origHtml = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="pl-btn-spin" aria-hidden="true"></span> ' + esc(text || 'Working...');
    } else {
      btn.disabled = false;
      if (btn.dataset.origHtml) {
        btn.innerHTML = btn.dataset.origHtml;
        delete btn.dataset.origHtml;
      }
    }
  }

  // Strictly reads the CURRENTLY ACTIVE USER'S context (never leaks Super Admin identity!)
  async function getActiveUserContext() {
    let key = '', phone10 = '', deviceId = '', account = null;
    try {
      if (g.PocketLeadsAccount && typeof g.PocketLeadsAccount.read === 'function') {
        const saved = await g.PocketLeadsAccount.read();
        const lic = (saved && saved.license) || {};
        account = (saved && saved.pocketleadsAccount) || lic || null;
        key = String(lic.key || (account && account.key) || '').trim();
        phone10 = normPhone10(lic.phone || key);
        deviceId = String(lic.installationId || (account && account.deviceId) || '').trim();
      }
    } catch (_) {}
    if (!deviceId && g.PocketLeadsAccount && typeof g.PocketLeadsAccount.getDeviceId === 'function') {
      try { deviceId = String((await g.PocketLeadsAccount.getDeviceId()) || '').trim(); } catch (_) {}
    }
    if (!key) {
      try { key = String(localStorage.getItem('licenceKey') || localStorage.getItem('pl_licence_key') || '').trim(); } catch (_) {}
      phone10 = normPhone10(key);
    }
    return { key, phone10, deviceId: deviceId || 'android-client', account };
  }

  // Strictly isolated Super Admin Auth Token (completely separate from active user context!)
  function getSuperAdminToken() {
    try {
      const direct = String(localStorage.getItem(SA_TOKEN_KEY) || '').trim();
      if (direct && direct.includes('.')) return direct;
      const rawImp = localStorage.getItem(IMPERSONATE_BACKUP_KEY);
      if (rawImp) {
        const parsed = JSON.parse(rawImp);
        if (parsed && parsed.adminToken && String(parsed.adminToken).includes('.')) return String(parsed.adminToken);
      }
    } catch (_) {}
    return '';
  }

  async function postApi(action, payload, headers) {
    const res = await fetch(getApiBase(), {
      method: 'POST',
      headers: Object.assign({ 'Content-Type': 'application/json' }, headers || {}),
      body: JSON.stringify(Object.assign({ action }, payload || {}))
    });
    const data = await res.json();
    if (!res.ok) throw new Error((data && (data.message || data.reason)) || ('HTTP ' + res.status));
    return data;
  }

  // Silent Background Prefetch on App Launch (Notifications + Broadcast + 7-Day KV Usage + Partner Summary)
  const prefetchCache = { notifications: null, broadcast: null, credit7d: null };
  async function runBackgroundPrefetch() {
    try {
      const ctx = await getActiveUserContext();
      const jobs = [
        postApi('getBroadcastBanner', {}).then(r => { prefetchCache.broadcast = r; }).catch(() => {}),
        fetch(getApiBase() + '?action=getnotifications', { method: 'GET' }).then(r => r.json()).then(r => { prefetchCache.notifications = r; }).catch(() => {}),
      ];
      if (ctx.key || ctx.phone10) {
        jobs.push(
          postApi('getCreditUsage7d', { key: ctx.key, phone: ctx.phone10 }).then(r => { prefetchCache.credit7d = r; }).catch(() => {})
        );
        jobs.push(
          postApi('partnerDashboard', { key: ctx.key, phone: ctx.phone10, deviceId: ctx.deviceId })
            .then(r => { if (r && r.status === 'ok') localStorage.setItem('pl_partner_dash_cache_v1', JSON.stringify(r)); })
            .catch(() => {})
        );
      }
      await Promise.allSettled(jobs);
    } catch (_) {}
  }

  g.plHaptic = haptic;
  g.PocketLeadsShared = {
    getApiBase,
    normPhone10,
    formatPhone,
    esc,
    haptic,
    toast,
    setBtnLoading,
    getActiveUserContext,
    getSuperAdminToken,
    postApi,
    prefetchCache,
    runBackgroundPrefetch
  };
})(globalThis);
