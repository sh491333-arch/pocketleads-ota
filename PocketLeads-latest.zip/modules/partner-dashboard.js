(function (g) {
  'use strict';
  // MODULE 3: PARTNER DASHBOARD ENHANCEMENTS (Pull-to-Refresh + Isolated Active User Context)
  function attachPtr(scrollEl, onTrigger) {
    if (!scrollEl || scrollEl.__plPtrBound) return;
    scrollEl.__plPtrBound = true;
    let startY = 0, pulling = false, delta = 0;
    let ind = scrollEl.querySelector('.pl-ptr-indicator');
    if (!ind) {
      ind = document.createElement('div');
      ind.className = 'pl-ptr-indicator';
      ind.innerHTML = '<span>&#8595; Pull down to refresh</span>';
      scrollEl.insertBefore(ind, scrollEl.firstChild);
    }
    scrollEl.addEventListener('touchstart', (e) => {
      if (scrollEl.scrollTop <= 2 && e.touches && e.touches.length === 1) { startY = e.touches[0].clientY; pulling = true; delta = 0; }
    }, { passive: true });
    scrollEl.addEventListener('touchmove', (e) => {
      if (!pulling || !e.touches || !e.touches.length) return;
      delta = e.touches[0].clientY - startY;
      if (delta > 12 && scrollEl.scrollTop <= 2) {
        const c = Math.min(70, Math.round(delta * 0.55));
        ind.style.height = c + 'px';
        ind.style.opacity = String(Math.min(1, c / 46));
        ind.innerHTML = c >= 50 ? '<span style="color:#fb923c;font-weight:800;">&#8635; Release to sync</span>' : '<span>&#8595; Pull down to refresh</span>';
      }
    }, { passive: true });
    scrollEl.addEventListener('touchend', () => {
      if (!pulling) return;
      pulling = false;
      if (delta * 0.55 >= 50 && scrollEl.scrollTop <= 2) {
        if (g.plHaptic) g.plHaptic('tap');
        ind.style.height = '36px'; ind.style.opacity = '1';
        ind.innerHTML = '<span class="pl-btn-spin"></span> <span>Syncing...</span>';
        Promise.resolve(onTrigger()).finally(() => setTimeout(() => { ind.style.height = '0px'; ind.style.opacity = '0'; }, 320));
      } else { ind.style.height = '0px'; ind.style.opacity = '0'; }
    }, { passive: true });
  }

  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
      const pwScroll = document.querySelector('#plPartnerModal .pw-content') || document.querySelector('#plPartnerModal .pw-main');
      if (pwScroll) {
        attachPtr(pwScroll, () => {
          const btn = document.getElementById('plPartnerRefreshBtn');
          if (btn) btn.click();
        });
      }
    }, 500);
  });
})(globalThis);
