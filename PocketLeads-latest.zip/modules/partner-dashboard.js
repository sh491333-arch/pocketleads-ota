(function (g) {
  'use strict';
  // MODULE 3: PARTNER DASHBOARD ENHANCEMENTS (Pull-to-Refresh + Isolated Active User Context)
  function attachPtr(scrollEl, onTrigger) {
    if (!scrollEl || scrollEl.__plPtrBound) return;
    scrollEl.__plPtrBound = true;
    let startY = 0, pulling = false, delta = 0;
    let ind = scrollEl.querySelector('.pl-ptr-indicator');
    if (!ind) {
      ind = document.createElement('div');
      ind.className = 'pl-ptr-indicator';
      ind.innerHTML = '<span>&#8595; Pull down to refresh</span>';
      scrollEl.insertBefore(ind, scrollEl.firstChild);
    }
    scrollEl.addEventListener('touchstart', (e) => {
      if (scrollEl.scrollTop <= 2 && e.touches && e.touches.length === 1) { startY = e.touches[0].clientY; pulling = true; delta = 0; }
    }, { passive: true });
    scrollEl.addEventListener('touchmove', (e) => {
      if (!pulling || !e.touches || !e.touches.length) return;
      delta = e.touches[0].clientY - startY;
      if (delta > 12 && scrollEl.scrollTop <= 2) {
        const c = Math.min(70, Math.round(delta * 0.55));
        ind.style.height = c + 'px';
        ind.style.opacity = String(Math.min(1, c / 46));
        ind.innerHTML = c >= 50 ? '<span style="color:#fb923c;font-weight:800;">&#8635; Release to sync</span>' : '<span>&#8595; Pull down to refresh</span>';
      }
    }, { passive: true });
    scrollEl.addEventListener('touchend', () => {
      if (!pulling) return;
      pulling = false;
      if (delta * 0.55 >= 50 && scrollEl.scrollTop <= 2) {
        if (g.plHaptic) g.plHaptic('tap');
        ind.style.height = '36px'; ind.style.opacity = '1';
        ind.innerHTML = '<span class="pl-btn-spin"></span> <span>Syncing...</span>';
        Promise.resolve(onTrigger()).finally(() => setTimeout(() => { ind.style.height = '0px'; ind.style.opacity = '0'; }, 320));
      } else { ind.style.height = '0px'; ind.style.opacity = '0'; }
    }, { passive: true });
  }

  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
      const pwScroll = document.querySelector('#plPartnerModal .pw-content') || document.querySelector('#plPartnerModal .pw-main');
      if (pwScroll) {
        attachPtr(pwScroll, () => {
          const btn = document.getElementById('plPartnerRefreshBtn');
          if (btn) btn.click();
        });
      }
    }, 500);
  });

  const PITCHES = {
    '1': 'Sir, aapke city ke saare Clinics/Salons/Shops ke verified phone numbers aur WhatsApp data sirf 30 second me Excel me mil jayega — ₹1,804 me poora 1 saal aur 1,00,000 credits!',
    '2': 'Sir, sirf 1 customer close hote hi aapka poora ₹1,804 recover ho jata hai — aur baaki 99,999 leads pure profit hain! Mobile APK + Windows EXE dono milta hai.',
    '3': 'Hello Sir! Aapke PocketLeads PRO plan ka renewal + 1,00,000 fresh credits ready hain — aaj renew karne par instant activation bina kisi rukawat ke!'
  };

  async function renderPartnerPoster(theme) {
    const cv = document.getElementById('pwPosterCanvas');
    if (!cv) return;
    const ctx = cv.getContext('2d');
    const S = g.PocketLeadsShared;
    const uCtx = S ? await S.getActiveUserContext() : { phone10: '', account: {} };
    const pPhone = uCtx.phone10 ? ('+91 ' + uCtx.phone10) : 'Contact Authorized Partner';
    const pName = String((uCtx.account && (uCtx.account.userName || uCtx.account.name)) || 'Authorized PocketLeads Partner');

    const grad = ctx.createLinearGradient(0, 0, 1080, 1080);
    if (theme === 'emerald') { grad.addColorStop(0, '#064e3b'); grad.addColorStop(1, '#090d16'); }
    else if (theme === 'gold') { grad.addColorStop(0, '#78350f'); grad.addColorStop(1, '#090d16'); }
    else { grad.addColorStop(0, '#9a3412'); grad.addColorStop(0.55, '#111827'); grad.addColorStop(1, '#090d16'); }
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 1080, 1080);

    ctx.fillStyle = 'rgba(249,115,22,0.18)';
    ctx.beginPath(); ctx.arc(900, 180, 260, 0, Math.PI * 2); ctx.fill();

    ctx.fillStyle = '#f97316';
    ctx.font = 'bold 46px sans-serif';
    ctx.fillText('POCKETLEADS PRO', 80, 140);
    ctx.fillStyle = '#94a3b8';
    ctx.font = '600 28px sans-serif';
    ctx.fillText("INDIA'S #1 B2B LEAD EXTRACTOR APK & EXE", 80, 190);

    ctx.fillStyle = '#ffffff';
    ctx.font = '900 84px sans-serif';
    const h1 = theme === 'emerald' ? '1,00,000 VERIFIED' : (theme === 'gold' ? 'WHATSAPP & MAPS' : 'GROW YOUR SALES');
    const h2 = theme === 'emerald' ? 'BUSINESS LEADS!' : (theme === 'gold' ? 'LEADS IN 1 CLICK!' : '10X FASTER!');
    ctx.fillText(h1, 80, 360);
    ctx.fillStyle = '#fb923c';
    ctx.fillText(h2, 80, 460);

    ctx.fillStyle = '#e2e8f0';
    ctx.font = '600 36px sans-serif';
    ['✓ Unlimited City & Pincode Search', '✓ Instant Excel / CSV Export', '✓ Built-in WhatsApp Number Verifier', '✓ 1 Year Plan — Only ₹1,804 ($19)'].forEach((line, i) => {
      ctx.fillText(line, 80, 580 + i * 68);
    });

    ctx.fillStyle = '#f97316';
    ctx.fillRect(0, 895, 1080, 185);
    ctx.fillStyle = '#090d16';
    ctx.font = '900 44px sans-serif';
    ctx.fillText('CALL / WHATSAPP: ' + pPhone, 80, 975);
    ctx.font = '700 30px sans-serif';
    ctx.fillText('Authorized Partner: ' + pName, 80, 1030);
  }

  document.addEventListener('click', async (e) => {
    const pitchBtn = e.target && e.target.closest ? e.target.closest('[data-pw-copy-pitch]') : null;
    if (pitchBtn) {
      const txt = PITCHES[pitchBtn.getAttribute('data-pw-copy-pitch')] || '';
      try { await navigator.clipboard.writeText(txt); } catch (_) {}
      if (g.PocketLeadsShared) g.PocketLeadsShared.toast('Sales pitch copied!', 'ok');
      return;
    }
    const posterBtn = e.target && e.target.closest ? e.target.closest('[data-pw-poster]') : null;
    if (posterBtn) { renderPartnerPoster(posterBtn.getAttribute('data-pw-poster')); return; }
    const dlBtn = e.target && e.target.closest ? e.target.closest('#pwDownloadPosterBtn') : null;
    if (dlBtn) {
      const cv = document.getElementById('pwPosterCanvas');
      if (cv) {
        const a = document.createElement('a');
        a.href = cv.toDataURL('image/png');
        a.download = 'PocketLeads_Partner_Poster.png';
        a.click();
        if (g.PocketLeadsShared) g.PocketLeadsShared.toast('HD Poster downloaded!', 'ok');
      }
      return;
    }
    const renewBtn = e.target && e.target.closest ? e.target.closest('[data-pw-renew]') : null;
    if (renewBtn) {
      const cPhone = renewBtn.getAttribute('data-pw-renew');
      if (!cPhone || !g.PocketLeadsShared) return;
      g.PocketLeadsShared.setBtnLoading(renewBtn, true, 'Renewing...');
      try {
        const ctx = await g.PocketLeadsShared.getActiveUserContext();
        const res = await g.PocketLeadsShared.postApi('partnerRenewCustomer', {
          key: ctx.key, phone: ctx.phone10, deviceId: ctx.deviceId, customerPhone: cPhone
        });
        if (res && res.status === 'ok') {
          g.PocketLeadsShared.haptic('success');
          g.PocketLeadsShared.toast(res.message || 'Customer renewed (+1 Year & +1L Credits)!', 'ok');
          if (g.PocketLeadsPartner && g.PocketLeadsPartner.refresh) g.PocketLeadsPartner.refresh('force');
        } else {
          g.PocketLeadsShared.toast((res && res.message) || 'Renewal failed', 'err');
        }
      } catch (err) { g.PocketLeadsShared.toast('Renewal failed: ' + err.message, 'err'); }
      finally { g.PocketLeadsShared.setBtnLoading(renewBtn, false); }
    }
  });
  document.addEventListener('DOMContentLoaded', () => { setTimeout(() => renderPartnerPoster('orange'), 1200); });

})(globalThis);
