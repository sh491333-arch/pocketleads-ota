// Global variable to track active timeouts
// Global variable to track active timeouts
var scrapingTimeouts = [];

// ID for the periodic captcha/no‑results polling interval.  Storing this
// reference allows us to clear the interval when scraping stops or the
// network goes offline.  See the setInterval usage near the bottom of
// this file for details.
var captchaIntervalId = null;

// Counter to limit the number of pages scraped per query.  Each call to
// openEachStore() or openEachStoreFast() increments this counter.  When the
// counter reaches 10, pagination will stop and the scraper will advance to
// the next query.  The counter is reset whenever a new keyword/location
// pair is started.  We deliberately keep this variable outside of any
// closure so that it persists across page navigations within the same tab.
var pageCounter = 0;

// To determine when a new query begins we remember the last processed
// keyword and location in normalised form.  The previous implementation
// compared raw strings and would reset pageCounter whenever whitespace,
// punctuation or casing differed between page loads (e.g. "560 102" vs
// "560102").  Normalising the values eliminates accidental resets and
// allows us to consistently identify the current query across navigations.
var lastNormalizedKeyword = '';
var lastNormalizedLocation = '';

// Coalesce legacy terminal events from page observers. Google Maps can fire
// the same offline/captcha condition repeatedly while the DOM is changing.
var pocketLeadsContentTerminalTimes = Object.create(null);
function sendContentTerminalEventOnce(eventName, data, cooldownMs) {
    const payload = data && typeof data === 'object' ? Object.assign({}, data) : {};
    const message = String(payload.message || '');
    const key = String(eventName || '') + ':' + message.slice(0, 240);
    const now = Date.now();
    const cooldown = Math.max(1000, parseInt(cooldownMs, 10) || 8000);
    if (pocketLeadsContentTerminalTimes[key] && now - pocketLeadsContentTerminalTimes[key] < cooldown) return false;
    pocketLeadsContentTerminalTimes[key] = now;
    payload.eventId = payload.eventId || ('content_' + String(eventName || 'event') + '_' + now.toString(36));
    try {
        $box.send(eventName, payload);
        return true;
    } catch (err) {
        console.warn('Failed to send terminal content event', eventName, err);
        return false;
    }
}

// Install a global unhandledrejection handler to silence promise rejections
// caused by sending runtime messages when no receiver exists.  Without a
// listener, chrome.runtime.sendMessage returns a promise that rejects
// with 'Could not establish connection. Receiving end does not exist'.
// This handler suppresses such errors so they do not clutter the console.
try {
    self.addEventListener('unhandledrejection', function(event) {
        try {
            const reason = event && event.reason ? String(event.reason) : '';
            if (reason.includes('Could not establish connection') || reason.includes('Receiving end does not exist')) {
                event.preventDefault();
                return;
            }
            // For other reasons, log a warning for debugging but do not suppress
            console.warn('Unhandled promise rejection in content script:', reason);
        } catch (err) {
            event.preventDefault();
        }
    });
} catch (err) {
    // In some contexts self may not support addEventListener; ignore
}

/**
 * Clear the periodic captcha/no‑results polling interval.  If the interval
 * is active (captchaIntervalId holds a numeric handle) we clear it and
 * reset the variable to null.  This helper is used when scraping stops or
 * the browser goes offline so that no further polling occurs until
 * scraping is restarted.
 */
function clearCaptchaInterval() {
    try {
        if (captchaIntervalId) {
            clearInterval(captchaIntervalId);
            captchaIntervalId = null;
        }
    } catch (err) {
        // Suppress errors when clearing intervals
    }
}

// Respond to offline and online events.  When the network connection is
// lost, pause scraping, clear any active timeouts and intervals, stop the
// keep‑alive WebRTC connection and notify the dashboard.  When the network
// comes back online we log a message; the user must manually restart
// scraping via the dashboard.
window.addEventListener('offline', function() {
    // If the chrome runtime is unavailable (e.g. extension reloaded), abort.
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) {
        return;
    }
    // Avoid handling the offline event if the extension context has been invalidated.
    try {
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.storage || typeof $box === 'undefined' || !$box.getLocal) {
            console.warn('Offline handler aborted: extension context unavailable');
            return;
        }
    } catch (ctxErr) {
        // If any error occurs while checking the chrome API, abort the handler.
        return;
    }
    console.warn('Network connection lost – pausing scraping.');
    // Clear all scheduled scraping timeouts
    try {
        if (Array.isArray(scrapingTimeouts) && scrapingTimeouts.length) {
            scrapingTimeouts.forEach(function(tid) {
                clearTimeout(tid);
            });
            scrapingTimeouts = [];
        }
    } catch (err) {
        scrapingTimeouts = [];
    }
    // Stop the periodic captcha/no‑results polling interval
    clearCaptchaInterval();
    // Stop the keep‑alive WebRTC connection
    try { stopKeepAliveConnection(); } catch (e) {}
    // Route network pauses through the background controller so it can convert
    // in-flight Place IDs to retry_pending and preserve an exact Resume point.
    try {
        chrome.runtime.sendMessage({ action: 'stop_scraping', reason: 'network_offline' }, function() {
            void chrome.runtime.lastError;
        });
    } catch (err) {
        sendContentTerminalEventOnce('scraping_stopped', {
            message: 'Network connection lost. Scraping paused; reopen the dashboard to Resume.'
        }, 10000);
    }
});

window.addEventListener('online', function() {
    // Abort if the chrome runtime is unavailable.  Attempting to access
    // chrome APIs after the extension context has been invalidated will
    // throw errors.  Simply return in this case.
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) {
        return;
    }
    console.log('Network connection restored.  Scraping remains paused until restarted by the user.');
});

/**
 * Normalise a string used as keyword or location.  This helper trims
 * leading/trailing whitespace, collapses multiple internal spaces to a
 * single space and converts the result to lower case.  For locations
 * specifically we also remove commas and hyphens so that different
 * representations of the same pincode (e.g. "560 102", "560102" or
 * "560-102") are treated identically when determining whether to reset
 * the page counter.  When the input is falsy (null/undefined/empty) an
 * empty string is returned.
 *
 * @param {string} str The string to normalise
 * @param {boolean} isLocation Whether the string represents a location
 * @returns {string} The normalised string
 */
function normalizeValue(str, isLocation) {
    if (!str) return '';
    let out = String(str).trim().toLowerCase();
    // Collapse consecutive whitespace into single spaces
    out = out.replace(/\s+/g, ' ');
    if (isLocation) {
        // Remove commas and hyphens for pincode comparison
        out = out.replace(/[\-,]/g, '');
    }
    return out;
}

/**
 * Return jQuery elements that likely contain the phone number for a
 * business.  Google frequently changes the DOM structure of the
 * details pane, so relying on a single selector can break the
 * scraper when minor UI tweaks occur.  This helper tries multiple
 * selectors and patterns in priority order.  It first looks for the
 * original data‑local attribute used by Google (`d3ph`).  If that
 * fails, it falls back to `tel:` links and then searches for
 * elements labelled "Phone" with a following sibling.  By returning
 * the first set of elements that match, the caller can iterate over
 * potential phone nodes without having to know which selector was
 * successful.
 *
 * @param {HTMLElement|jQuery|string} container The root element or
 * selector to search within.  Accepts a jQuery object, DOM node or
 * selector string.
 * @returns {jQuery} A jQuery collection of elements containing the phone number.
 */
function getPhoneElements(container) {
    try {
        const $root = $(container);
        if (!$root || !$root.length) return $();
        // Primary selector: Google often uses data‑local‑attribute="d3ph".
        let $els = $root.find('[data-local-attribute="d3ph"]');
        if ($els && $els.length) return $els;
        // Fallback 1: look for anchor tags with tel: hrefs.  Many
        // sites expose phone numbers as clickable links beginning with
        // "tel:".  Selecting all anchors whose href starts with tel:
        $els = $root.find('a[href^="tel:"]');
        if ($els && $els.length) return $els;
        // Google Maps profile fallback: phone action/copy controls.
        $els = $root.find('[data-item-id*="phone"], button[aria-label^="Phone:"], button[data-tooltip*="phone"]');
        if ($els && $els.length) return $els;
        // Fallback 2: find elements containing the word "Phone" (case
        // insensitive) and return their next sibling.  We filter
        // through all elements to find those where the text begins
        // with "phone".  We then select the immediate next element
        // which usually holds the phone number.
        const candidates = $root.find('*').filter(function() {
            const txt = $(this).text();
            if (!txt) return false;
            return /^\s*phone\b/i.test(txt);
        });
        if (candidates && candidates.length) {
            let nextSiblings = $();
            candidates.each(function() {
                const nxt = $(this).next();
                if (nxt && nxt.text().trim()) {
                    nextSiblings = nextSiblings.add(nxt);
                }
            });
            if (nextSiblings.length) return nextSiblings;
        }
        // If none of the above selectors return results, return an
        // empty jQuery object.  Callers should treat length===0 as
        // absence of phone nodes.
        return $();
    } catch (err) {
        return $();
    }
}

/**
 * Attempt to extract the business name from the details container using
 * multiple selectors.  Google sometimes changes the markup for the
 * business title, so we fall back to heading elements when the
 * data‑attrid="title" selector fails.  The returned name will be
 * trimmed of whitespace.  If no name is found, an empty string is
 * returned.
 *
 * @param {HTMLElement|jQuery|string} container The container to search within.
 * @returns {string} The company name or "" if not found.
 */
function getCompanyName(container) {
    try {
        const $root = $(container);
        let $nameEl = $root.find('[data-attrid="title"]');
        if (!$nameEl || !$nameEl.length) {
            // Google Maps profile title selectors used in the current panel UI.
            $nameEl = $root.find('.DUwDvf, h1.DUwDvf, [class*="fontHeadlineLarge"]');
        }
        if (!$nameEl || !$nameEl.length) {
            // Fallback: first h1 within the container
            $nameEl = $root.find('h1');
        }
        if (!$nameEl || !$nameEl.length) {
            // Fallback: second heading (h2)
            $nameEl = $root.find('h2');
        }
        if ($nameEl && $nameEl.length) {
            const txt = $nameEl.first().text().trim();
            return txt || '';
        }
        return '';
    } catch (err) {
        return '';
    }
}

/**
 * Extract the website link of the business using flexible selectors.
 * The primary selector searches for an anchor with the text "Website".
 * If not found, we look for anchors whose aria-label contains
 * "Website", which Google sometimes uses for accessibility.  As a
 * last resort we search for an anchor whose href begins with "http"
 * and which appears within a button-like UI element (to avoid picking
 * telephone or direction links).  If multiple candidates exist, the
 * first is returned.
 *
 * @param {HTMLElement|jQuery|string} container The container to search within.
 * @returns {string} The URL string or "" if none found.
 */
function getWebsiteLink(container) {
    try {
        const $root = $(container);
        // Primary: text contains "Website"
        let $link = $root.find('a:contains("Website")');
        if ($link && $link.length) {
            const href = $link.attr('href');
            if (href) return href;
        }
        // Fallback: aria-label includes "Website"
        $link = $root.find('a[aria-label*="Website"]');
        if ($link && $link.length) {
            const href = $link.attr('href');
            if (href) return href;
        }
        // Google Maps profile fallback: official website action button.
        $link = $root.find('a[data-item-id="authority"], a[data-tooltip*="Website"], a[aria-label^="Website:"]');
        if ($link && $link.length) {
            const href = $link.first().attr('href');
            if (href) return href;
        }
        // Fallback: any anchor with http/https that is likely a website link.
        // To reduce false positives (e.g. Directions or Save buttons) we
        // filter by anchor text or aria-label containing typical website
        // keywords such as "Site" or "Official".  If not available, we
        // simply return the first http link that is not pointing to
        // google.com or maps.google.com.
        const links = $root.find('a[href^="http"]');
        for (let i = 0; i < links.length; i++) {
            const $a = $(links[i]);
            const href = $a.attr('href');
            if (!href) continue;
            // Skip Google internal links and telephone or mailto links
            if (/^(https?:\/\/)?(www\.)?google\./i.test(href)) continue;
            if (/\.google\.com\/?/i.test(href)) continue;
            if (/tel:/i.test(href) || /mailto:/i.test(href)) continue;
            // Optionally check for anchor text hints
            const text = $a.text().trim();
            const aria = $a.attr('aria-label') || '';
            const combined = (text + ' ' + aria).toLowerCase();
            if (combined.includes('website') || combined.includes('site') || combined.includes('official')) {
                return href;
            }
        }
        // As a very last resort, return the first external link not pointing
        // back to Google.  This is best-effort and may occasionally pick
        // unrelated URLs, but prevents blank website fields when the page
        // structure changes.
        for (let i = 0; i < links.length; i++) {
            const $a = $(links[i]);
            const href = $a.attr('href');
            if (!href) continue;
            if (/tel:/i.test(href) || /mailto:/i.test(href)) continue;
            if (/google\./i.test(href)) continue;
            return href;
        }
        return '';
    } catch (err) {
        return '';
    }
}

/**
 * Extract the address text for the business.  Google typically stores
 * the address in an element with data‑local‑attribute="d3adr".
 * However, in some layouts the address appears as a label "Address:"
 * followed by a sibling element.  This helper tries the primary
 * selector, then falls back to scanning for the label and returning
 * the next sibling's text.  The returned address will have any
 * leading "Address:" prefix removed and whitespace trimmed.
 *
 * @param {HTMLElement|jQuery|string} container The container to search within.
 * @returns {string} The address string or "" if none found.
 */
function getAddressText(container) {
    try {
        const $root = $(container);
        // Primary: d3adr attribute
        let $addrEl = $root.find('[data-local-attribute="d3adr"]');
        let addrText = '';
        if ($addrEl && $addrEl.length) {
            addrText = $addrEl.first().text().trim();
        }
        if (!addrText) {
            // Google Maps profile fallback: address action button / copy address control.
            const mapsAddr = $root.find('[data-item-id*="address"], button[aria-label^="Address:"], button[data-tooltip*="address"]').first();
            if (mapsAddr && mapsAddr.length) {
                addrText = (mapsAddr.attr('aria-label') || mapsAddr.text() || '').trim();
            }
        }
        if (!addrText) {
            // Fallback: look for an element whose text begins with "Address"
            const label = $root.find('*').filter(function() {
                const txt = $(this).text();
                if (!txt) return false;
                return /^\s*address\b/i.test(txt.trim());
            }).first();
            if (label && label.length) {
                const next = label.next();
                if (next && next.length) {
                    addrText = next.text().trim();
                }
            }
        }
        if (addrText) {
            addrText = addrText.replace(/^\s*Address:?\s*/i, '').trim();
            return addrText;
        }
        return '';
    } catch (err) {
        return '';
    }
}


function normalizeDomTextValue(value) {
    return String(value || '').replace(/[\u200B-\u200D\uFEFF\u00A0]/g, ' ').replace(/\s+/g, ' ').trim();
}

function parseCompactReviewNumber(value) {
    if (value === null || typeof value === 'undefined') return null;
    let text = String(value).replace(/[,\s]+/g, '').trim().toLowerCase();
    if (!text) return null;
    const m = text.match(/^([0-9]*\.?[0-9]+)([kmb])?$/i);
    if (!m) return null;
    let n = parseFloat(m[1]);
    if (!Number.isFinite(n)) return null;
    const suffix = m[2] || '';
    if (suffix === 'k') n *= 1000;
    else if (suffix === 'm') n *= 1000000;
    else if (suffix === 'b') n *= 1000000000;
    return Math.round(n);
}

function extractReviewCountFromText(text, allowBareParentheses) {
    text = normalizeDomTextValue(text);
    if (!text || !/\d/.test(text)) return null;
    const hasReviewWord = /review/i.test(text);
    const hasBareCount = /\(([0-9][0-9,]*(?:\.[0-9]+)?\s*[KMBkmb]?)\)/.test(text);
    if (!hasReviewWord && !(allowBareParentheses && hasBareCount)) return null;
    const patterns = [
        /\(([0-9][0-9,]*(?:\.[0-9]+)?\s*[KMBkmb]?)\)\s*(?:reviews?|Google reviews?)/i,
        /([0-9][0-9,]*(?:\.[0-9]+)?\s*[KMBkmb]?)\s*(?:Google\s+)?reviews?\b/i,
        /(?:reviews?|Google reviews?)\s*\(?([0-9][0-9,]*(?:\.[0-9]+)?\s*[KMBkmb]?)\)?/i,
        /\(([0-9][0-9,]*(?:\.[0-9]+)?\s*[KMBkmb]?)\)/i
    ];
    for (const rx of patterns) {
        const m = text.match(rx);
        if (m && m[1]) {
            const parsed = parseCompactReviewNumber(m[1]);
            if (parsed !== null && parsed >= 0 && parsed < 50000000) return parsed;
        }
    }
    return null;
}

function extractTotalReviews(container) {
    try {
        const $root = $(container);
        if (!$root || !$root.length) return 0;
        const prioritySelectors = [
            '.F7nice',
            '[aria-label*="Google reviews"], [aria-label*="google reviews"]',
            'button[jsaction*="pane.rating"], button[jsaction*="review"]',
            'button[aria-label*="review"], button[aria-label*="Review"]',
            'span[aria-label*="review"], span[aria-label*="Review"]',
            'a[href*="reviews"], button[data-tab-index*="reviews"]'
        ];
        for (const selector of prioritySelectors) {
            const $els = $root.find(selector);
            for (let i = 0; i < Math.min($els.length, 16); i++) {
                const el = $els.eq(i);
                const raw = normalizeDomTextValue([el.attr('aria-label'), el.attr('title'), el.text()].filter(Boolean).join(' '));
                if (!raw || !/review/i.test(raw)) continue;
                const parsed = extractReviewCountFromText(raw, true);
                if (parsed !== null) return parsed;
            }
        }
        // Secondary pass: only inspect small visible nodes that literally contain
        // the review word. Do not parse the full document body, otherwise Maps
        // can leak unrelated numbers from review snippets, addresses, photos etc.
        const scoped = [];
        $root.find('span,button,a,div').each(function() {
            const txt = normalizeDomTextValue($(this).text());
            if (!txt || txt.length > 120 || !/\breviews?\b/i.test(txt) || !/\d/.test(txt)) return;
            const parsed = extractReviewCountFromText(txt, false);
            if (parsed !== null) scoped.push({ count: parsed, len: txt.length });
        });
        if (scoped.length) {
            scoped.sort((a, b) => a.len - b.len || b.count - a.count);
            return scoped[0].count;
        }
        return 0;
    } catch (err) {
        return 0;
    }
}

function extractRatingValue(container) {
    try {
        const $root = $(container);
        const selectors = ['.F7nice', 'g-review-stars>span', 'span[aria-label*="stars"]', 'div[aria-label*="stars"]'];
        for (const selector of selectors) {
            const $els = $root.find(selector);
            for (let i = 0; i < Math.min($els.length, 8); i++) {
                const el = $els.eq(i);
                const raw = normalizeDomTextValue([el.attr('aria-label'), el.attr('title'), el.text()].filter(Boolean).join(' '));
                const m = raw.match(/\b([1-5](?:\.[0-9])?)\b\s*(?:stars?|out of|\()/i) || raw.match(/^\s*([1-5](?:\.[0-9])?)\s*$/);
                if (m && m[1]) return m[1];
            }
        }
    } catch (err) {}
    return '0';
}

function cleanCategoryCandidate(text) {
    text = normalizeDomTextValue(text).replace(/^Category:?\s*/i, '');
    if (!text) return '';
    text = text.replace(/\b(Website|Directions|Save|Share|Call|Phone|Address|Reviews?|Photos|Menu|Order online)\b.*$/i, '').trim();
    text = text.split(/\s+in\s+/i)[0].trim();
    text = text.replace(/\b(Open|Closed|Closes|Opens|Permanently closed|Temporarily closed)\b.*$/i, '').trim();
    text = text.replace(/^[·•\-–—]+|[·•\-–—]+$/g, '').trim();
    if (!text || text.length > 80) return '';
    if (/\d{5,6}|\+?\d[\d\s().-]{7,}|\b(stars?|reviews?|rating|rated)\b/i.test(text)) return '';
    if (/\b(india|directions|website|phone|address|save|share)\b/i.test(text)) return '';
    return text;
}

function getBusinessCategory(container) {
    try {
        const $root = $(container);
        const selectors = [
            'button[jsaction*="pane.rating.category"]',
            'button[jsaction*="category"]',
            'button[aria-label^="Category:"]',
            'button[aria-label*="Category"], button[aria-label*="category"]',
            'button[data-item-id*="category"]',
            '.DkEaL',
            '.YhemCb',
            '.fontBodyMedium .DkEaL'
        ];
        for (const selector of selectors) {
            const $els = $root.find(selector);
            for (let i = 0; i < Math.min($els.length, 8); i++) {
                const el = $els.eq(i);
                const candidate = cleanCategoryCandidate([el.attr('aria-label'), el.attr('title'), el.text()].filter(Boolean).join(' '));
                if (candidate) return candidate;
            }
        }
        const text = normalizeDomTextValue($root.text()).slice(0, 2500);
        const m = text.match(/(?:Category:?\s*)([A-Za-z][A-Za-z &\/.-]{2,60})/i);
        if (m && m[1]) return cleanCategoryCandidate(m[1]);
    } catch (err) {}
    return '';
}

/**
 * Extract email addresses present in the details container.  Google
 * listings rarely expose email addresses directly, but occasionally a
 * "mailto:" link or visible email text may appear.  This helper
 * searches for anchors with mailto: hrefs as well as any text
 * containing an '@' symbol.  Duplicate addresses are removed.  The
 * returned list may contain zero, one or multiple emails.
 *
 * @param {HTMLElement|jQuery|string} container The root element to search.
 * @returns {string[]} An array of unique email addresses.
 */
function getEmailAddresses(container) {
    const emails = [];
    const add = value => {
        const decoded = String(value || '')
            .replace(/^mailto:/i, '').split('?')[0]
            .replace(/&commat;|&#64;|&#x40;/gi, '@')
            .replace(/&period;|&#46;|&#x2e;/gi, '.')
            .replace(/\s*(?:\[|\(|\{)\s*at\s*(?:\]|\)|\})\s*/gi, '@')
            .replace(/\s+at\s+/gi, '@')
            .replace(/\s*(?:\[|\(|\{)\s*dot\s*(?:\]|\)|\})\s*/gi, '.')
            .replace(/\s+dot\s+/gi, '.')
            .trim();
        const re = /[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+/gi;
        let match;
        while ((match = re.exec(decoded)) !== null) {
            const email = match[0].toLowerCase().replace(/[.,;:]+$/, '');
            if (email && email.length <= 254 && !emails.includes(email)) emails.push(email);
        }
    };
    try {
        const $root = $(container);
        if (!$root || !$root.length) return emails;
        $root.find('a[href]').each(function() {
            const href = $(this).attr('href');
            if (href && /^mailto:/i.test(href)) add(href);
        });
        add($root.text());
    } catch (err) {}
    return emails;
}

// -----------------------------------------------------------------------------
// Manifest V3 compatibility fix.
//
// When libs/chromeBox.js is executed in a content script it attempts to
// access chrome.extension.getBackgroundPage() via $box.getBackgroundPage().
// In Manifest V3 there is no persistent background page, so that call
// throws an "Extension context invalidated" error.  To avoid this
// exception in content scripts, we override $box.getBackgroundPage to
// safely return undefined if the original call fails.
try {
    if (typeof $box !== 'undefined' && $box && typeof $box.getBackgroundPage === 'function') {
        const __origGetBg = $box.getBackgroundPage;
        $box.getBackgroundPage = function() {
            try {
                return __origGetBg();
            } catch (err) {
                // In MV3 there is no background page; return undefined
                return undefined;
            }
        };
    }
} catch (err) {
    // Suppress any errors during override
}

// -----------------------------------------------------------------------------
// Background tabs in Chrome are heavily throttled, which can cause our
// timeouts to execute much slower than intended. Users reported that when
// they manually activate the hidden Google Maps tab, scraping speeds up
// dramatically. To mitigate this without requiring user interaction, we play
// a tiny muted audio track in a loop while scraping. Chrome exempts tabs
// actively playing audio from aggressive timer throttling, keeping our
// timeouts responsive even when the tab isn't visible. The audio is muted
// so it doesn't disturb the user and is cleaned up once scraping stops.
// See: https://developer.chrome.com/blog/background-tabs/ for details.

// WebRTC keep‑alive peers to prevent Chrome from aggressively throttling
// background timers. Keeping a DataChannel open qualifies the page as
// "noisy" according to Chrome's timer throttling policy【668346966298831†L193-L223】.
var keepAlivePeer1 = null;
var keepAlivePeer2 = null;

/**
 * Establish a dummy WebRTC connection between two peers in the same page. The
 * presence of an active DataChannel or MediaStreamTrack counts as "noisy"
 * activity and prevents Chrome from applying intensive background timer
 * throttling【668346966298831†L193-L223】. When the connection is already
 * established, this function does nothing.
 */
function startKeepAliveConnection() {
    if (keepAlivePeer1 || keepAlivePeer2) return;
    try {
        // Create two peer connections without any ICE servers. Since both
        // connections exist in the same page, local candidates will be
        // sufficient to complete the connection.
        var pc1 = new RTCPeerConnection();
        var pc2 = new RTCPeerConnection();
        // Create a data channel on one peer. This will cause the other peer
        // to fire an ondatachannel event when negotiation is successful.
        pc1.createDataChannel('keepalive');
        // Exchange ICE candidates between the peers.
        pc1.onicecandidate = function(e) {
            if (e.candidate) {
                pc2.addIceCandidate(e.candidate).catch(function(err) {
                    console.warn('Error adding ICE candidate to pc2', err);
                });
            }
        };
        pc2.onicecandidate = function(e) {
            if (e.candidate) {
                pc1.addIceCandidate(e.candidate).catch(function(err) {
                    console.warn('Error adding ICE candidate to pc1', err);
                });
            }
        };
        // Handle data channel on the second peer.
        pc2.ondatachannel = function(e) {
            var channel = e.channel;
            // Keep the channel alive by sending periodic pings.
            channel.onopen = function() {
                console.log('Keep‑alive DataChannel opened');
                // Send a ping every 30 seconds. Using 30 seconds ensures the
                // channel stays active but avoids unnecessary messages.
                channel.keepAliveInterval = setInterval(function() {
                    if (channel.readyState === 'open') {
                        channel.send('ping');
                    }
                }, 30000);
            };
            channel.onclose = function() {
                if (channel.keepAliveInterval) {
                    clearInterval(channel.keepAliveInterval);
                }
            };
        };
        // Perform the offer/answer exchange to connect the peers.
        pc1.createOffer().then(function(offer) {
            return pc1.setLocalDescription(offer).then(function() {
                return pc2.setRemoteDescription(offer);
            }).then(function() {
                return pc2.createAnswer();
            }).then(function(answer) {
                return pc2.setLocalDescription(answer).then(function() {
                    return pc1.setRemoteDescription(answer);
                });
            });
        }).catch(function(err) {
            console.warn('Keep‑alive WebRTC negotiation failed', err);
        });
        keepAlivePeer1 = pc1;
        keepAlivePeer2 = pc2;
        console.log('Keep‑alive WebRTC connection started');
    } catch (e) {
        console.warn('Unable to start keep‑alive WebRTC connection', e);
    }
}

/**
 * Close the dummy WebRTC connections and clean up resources. Should be called
 * when scraping finishes or is aborted so we don't leave unused connections.
 */
function stopKeepAliveConnection() {
    try {
        if (keepAlivePeer1) {
            keepAlivePeer1.close();
            keepAlivePeer1 = null;
        }
        if (keepAlivePeer2) {
            keepAlivePeer2.close();
            keepAlivePeer2 = null;
        }
        console.log('Keep‑alive WebRTC connection stopped');
    } catch (e) {
        console.warn('Unable to stop keep‑alive WebRTC connection', e);
    }
}

$box.on((event, data) => {
	console.log("Message received : "+event);
	
	if(event=='stop_scraping'){
		console.log("Stop scraping command received");
		// Clear all active timeouts
		scrapingTimeouts.forEach(timeoutId => {
			clearTimeout(timeoutId);
		});
		scrapingTimeouts = [];
		
        // Stop keep‑alive WebRTC connection and update local state
        stopKeepAliveConnection();
        // Also clear the periodic captcha/no‑results polling interval so
        // no further captcha polling occurs until scraping is restarted.
        clearCaptchaInterval();
        // Update local state
		$box.getLocal(local => {
			local.status = false;
			if (!local._taskManager) local._taskManager = {};
			local._taskManager.isWorking = false;
			$box.setLocal(local, {
				onSet: () => {
					console.log("Scraping stopped in content script (silent cleanup)");
					// The background/controller owns the single dashboard event.
					// Re-emitting here previously multiplied stop notifications.
				}
			});
		});
	}
	
});


/*-------------------------- On Load ------------------------*/
$(() => {
    console.log("Content.js loaded");
    $box.getLocal(local => {
        console.log(local);
        // When scraping is active (local.status is true) automatically start
        // processing listings on Google result pages.  Previously this
        // executed on every page load (including WhatsApp and other domains)
        // which caused the scraper to treat unrelated pages as part of
        // the scraping session and trigger premature completion or error
        // events.  Restrict execution to Google domains to prevent
        // interference when the user opens WhatsApp or other sites while
        // scraping is running.  If the current hostname does not
        // contain "google." we skip openEachStore() and let scraping
        // continue in the existing Google search tab.
        if (local.status) {
            // New Apify direct dataset flow: profile pages are opened and scraped by
            // TaskController through explicit POCKETLEADS_SCRAPE_PROFILE messages.
            // Do not auto-run the old Normal/Fast search-result-page scraping here.
            console.log('Apify direct dataset flow active; old search-result auto-scraping is disabled on page load.');
        }
    });
});


/**
 * Collect CIDs from the current Google Maps results page.  Google
 * frequently changes the structure of the search results DOM.  The
 * original implementation relied exclusively on a data‑cid attribute
 * present on each listing.  When this attribute is renamed or
 * removed the scraper would silently fail, producing no leads.  To
 * make CID detection more resilient this function now falls back to
 * parsing common URL patterns used by Google Maps when no data‑cid
 * elements are found.  It also de‑duplicates the results to avoid
 * processing the same business multiple times.
 *
 * @returns {string[]} An array of CID strings
 */
// Replacement collectCid implementation for Google Maps as of 2026.
//
// The new Maps UI no longer exposes a reliable `data-cid` attribute on
// listing rows.  Instead we gather listings from several known
// container selectors (role="listitem", j7fAeb, Nv2PK, DxyBCb, etc.).
// Each listing may expose a unique business identifier either via a
// `data-item-id` attribute (hex pairs like 0x123:0x456) or within
// the `href` of a link (encoded !1s0x…:… or a cid= query param).  We
// extract the CID, gather minimal details (name, website and phone) and
// store them in local.collect.  The function also returns an array of
// collected CIDs so that sequential scraping can continue to click
// through listings when needed.
window.collectCid = function() {
    try {
        // Identify all potential listing elements.  These selectors
        // correspond to card containers in the current Maps UI.  Duplicate
        // selectors are intentionally included to maximise coverage across
        // different layouts and experiments.
        const listings = document.querySelectorAll(
            'div[role="listitem"], div.j7fAeb, div.Nv2PK, div.DxyBCb, div[aria-label*="Results"] > div, div[role="listitem"]'
        );
        let collected = 0;
        const cids = [];
        listings.forEach(el => {
            if (!el) return;
            let cid = null;
            // Attempt 1: data-item-id contains a hex pair separated by a colon
            const idAttr = el.getAttribute('data-item-id');
            if (idAttr) {
                const m = idAttr.match(/0x[a-f0-9]+:[a-f0-9]+/i);
                if (m) cid = m[0];
            }
            // Attempt 2: parse the href of an inner anchor for !1s0x… or cid=
            if (!cid) {
                const link = el.querySelector('a[href*="google.com/maps"], a[href*="maps.google"]');
                if (link) {
                    const href = link.getAttribute('href') || '';
                    // Match encoded segment !1s0x…:… or a cid query param
                    const m = href.match(/!1s0x[a-f0-9]+:[a-f0-9]+/i) || href.match(/cid=([a-f0-9]+)/i);
                    if (m) {
                        // When using cid= the numeric id is captured in group 1.  Otherwise
                        // the full !1s0x… pattern is used.
                        cid = m[1] || m[0];
                    }
                }
            }
            if (!cid) return;
            // Extract business name from various heading selectors
            const nameEl = el.querySelector('h3, .fontHeadlineSmall, [role="heading"], .t3H2x');
            const name = nameEl ? nameEl.innerText.trim() : '';
            // Extract website from the first non-Google external link
            const websiteEl = el.querySelector('a[href^="http"]:not([href*="google"])');
            const website = websiteEl ? websiteEl.href : '';
            // Extract phone number from tel: link
            const phoneEl = el.querySelector('a[href^="tel:"]');
            const phone = phoneEl ? (phoneEl.getAttribute('href') || '').replace('tel:', '') : '';
            if (!name) return;
            // Push to local.collect if not already present
            cids.push(cid);
            $box.getLocal(local => {
                if (!local.collect) local.collect = [];
                // Avoid duplicates
                const exists = local.collect.find(item => item.cid === cid);
                if (!exists) {
                    local.collect.push({
                        cid: cid,
                        company_name: name,
                        website: website,
                        phone: phone,
                        keyword: (local && local.activeKeyword) || '',
                        location: (local && local.activeLocation) || ''
                    });
                    $box.setLocal(local);
                    collected++;
                }
            });
        });
        console.log(`✅ Collected ${collected} new listings this pass`);
        // Deduplicate cids before returning
        return Array.from(new Set(cids));
    } catch (err) {
        console.warn('collectCid: error collecting listings', err);
        return [];
    }
};

// Automatically observe the DOM for new listings and collect them on the fly.
// Only create a single observer per page to avoid multiple observers
// accumulating during navigation.  When the DOM mutates we call
// collectCid() to capture newly loaded listings.
if (false && !window.listingObserver) {
    window.listingObserver = new MutationObserver(() => {
        try {
            window.collectCid();
        } catch (observerErr) {
            console.warn('listingObserver: failed to collect listings', observerErr);
        }
    });
    try {
        // Choose a safe root node for observation.  Some pages may not
        // have a body element yet (e.g. early in the document lifecycle or
        // on certain Google SERP pages).  Fallback to the document element
        // when body is undefined or null.  Always ensure the target is a
        // Node before passing it to observe() to avoid TypeErrors.
        const targetNode = document && (document.body || document.documentElement);
        if (targetNode && typeof targetNode === 'object' && targetNode.nodeType === 1) {
            window.listingObserver.observe(targetNode, { childList: true, subtree: true });
        } else {
            console.warn('listingObserver: no valid target node for observation');
        }
    } catch (observeErr) {
        console.warn('listingObserver: failed to attach observer', observeErr);
    }
}

/**
 * Click a listing row based on its CID.  Historically we located
 * listings by selecting `[data-cid="<cid>"]`.  When Google removed or
 * renamed that attribute the extension could no longer locate the row and
 * silently failed.  This function now attempts multiple strategies to
 * find a clickable element for the given CID.  It first looks for an
 * element with the data‑cid attribute.  If that fails it searches for
 * anchor tags whose href contains either a `cid=` parameter or an
 * encoded `!1s<cid>` segment.  Only when all attempts fail does it
 * report that the selector was not found.
 *
 * @param {string} cid The listing CID to click
 */
function clickStore(cid) {
    try {
        // First attempt to locate the row using the original attributes.
        // Some layouts still include data-cid, while newer layouts may use
        // data-item-id for hex-based CIDs.  We try both before falling
        // back to anchors.
        let el = document.querySelector(`[data-cid="${cid}"]`);
        if (!el) {
            el = document.querySelector(`[data-item-id="${cid}"]`);
        }
        // Fallback 1: anchor containing a cid= query parameter that matches the CID
        if (!el) {
            el = document.querySelector(`a[href*="cid=${cid}"]`);
        }
        // Fallback 2: anchor with encoded !1s<cid> segment (for numeric and hex IDs)
        if (!el) {
            el = document.querySelector(`a[href*="!1s${cid}"]`);
        }
        // Fallback 3: generic substring match on the href (covers hex IDs like 0x…:…)
        if (!el) {
            el = document.querySelector(`a[href*="${cid}"]`);
        }
        if (el) {
            try {
                console.log('clickStore: found element for cid', cid);
                el.click();
            } catch (clickErr) {
                console.warn('clickStore: failed to click element for cid', cid, clickErr);
            }
        } else {
            console.log('clickStore: selector not found for cid', cid);
        }
    } catch (err) {
        console.warn('clickStore: failed to click store for cid ' + cid, err);
    }
}

function openEachStore(){
    // Reset any pending timeouts from previous runs.  Without clearing
    // scrapingTimeouts, residual callbacks from earlier sessions could
    // continue firing even after the user stops scraping.  Clearing
    // existing timeouts here ensures each new start begins with a clean
    // slate.  If scrapingTimeouts is undefined or not an array,
    // gracefully handle the error.
    try {
        if (Array.isArray(scrapingTimeouts) && scrapingTimeouts.length) {
            scrapingTimeouts.forEach((timeoutId) => {
                clearTimeout(timeoutId);
            });
            scrapingTimeouts = [];
        }
    } catch (err) {
        console.warn('Failed to clear existing scraping timeouts', err);
        scrapingTimeouts = [];
    }

    // Collect all listing CIDs from the current search results.  Use the
    // window-scoped collectCid to ensure the correct implementation is
    // invoked.  The function returns an array of CIDs (unique) for
    // sequential scraping.
    let list = window.collectCid();
    $box.getLocal(local => {
        // Mark that scraping has actually begun.  When this callback
        // executes on the first page, set the scrapeStarted flag so
        // that completion events are only dispatched after at least
        // one listing has been processed or an attempt has been made.
        try {
            if (local && local._taskManager && !local._taskManager.scrapeStarted) {
                local._taskManager.scrapeStarted = true;
                $box.setLocal(local);
            }
        } catch (err) {
            console.warn('Failed to mark scrapeStarted in openEachStore', err);
        }
        // Reset the page counter when a new keyword/location is detected.  We
        // compare normalised values to avoid false positives due to
        // whitespace, punctuation or casing differences.  If either the
        // keyword or the location differs from the last known values we
        // consider it a new task and reset the counter.  Store the
        // normalised values for future comparisons.  Wrap in try/catch
        // because local may be undefined or properties missing.
        try {
            if (local) {
                const normKeyword = normalizeValue(local.activeKeyword, false);
                const normLocation = normalizeValue(local.activeLocation, true);
                if (normKeyword !== lastNormalizedKeyword || normLocation !== lastNormalizedLocation) {
                    pageCounter = 0;
                    lastNormalizedKeyword = normKeyword;
                    lastNormalizedLocation = normLocation;
                }
            }
        } catch (err) {
            console.warn('Failed to normalise active keyword/location for page counter reset', err);
        }

        // Increment the page counter only for sequential (non‑fast) mode.  The
        // counter is incremented here rather than at the top of the function
        // so that we know whether the user is in fast mode.  This ensures that
        // the counter is only incremented for pages scraped in sequential
        // mode.  For fast mode the counter is updated inside
        // openEachStoreFast().
        if (!local.fastMode) {
            pageCounter++;
        }
        // Check if scraping should continue
        if (!local.status && !local._taskManager.isWorking) {
            console.log("Scraping was stopped, aborting");
            return;
        }

        // When fastMode is enabled we skip the sequential click‑and‑scrape
        // workflow entirely and instead parse whatever data is available
        // directly in the search results.  In this mode we still call
        // startKeepAliveConnection() to prevent Chrome from throttling
        // background timers.  The fast mode implementation will handle
        // pagination and completion on its own.
        if (local.fastMode) {
            console.log("Fast scrap mode is enabled; scraping page‑wise");
            // Ensure the keep‑alive connection is running to avoid timer
            // throttling in background tabs.
            startKeepAliveConnection();
            openEachStoreFast();
            return;
        }

        // Begin keep‑alive WebRTC connection when scraping starts to prevent
        // Chrome from intensively throttling background timers. This is invoked
        // only once per run.
        startKeepAliveConnection();

        console.log("Opening Each Store (sequential)");

        // Filter out already collected CIDs
        list = list.filter(cid => {
            let index = _.findIndex(local.collect, { cid: cid });
            if (index === -1) {
                return true;
            }
            return false;
        });

        // Skip this page if all from this page is scraped by pushing a dummy ID
        list = list.length ? list : [1234];

        // Define a constant wait time after clicking a store before scraping its data.
        // Reduced further to 1 second to increase scraping throughput while still
        // permitting the business details panel to populate.  Adjust this value
        // cautiously: if set too low the details may not load fully, leading to
        // missing fields.  The small random click delay (see below) simulates
        // natural interaction without accumulating delays.
            // Reduce the wait time between clicking a result and scraping its data.
            // A shorter delay (500 ms) improves throughput without significantly
            // increasing the risk of incomplete data.  If you encounter missing
            // fields, increase this value slightly.
            const WAIT_TIME = 500; // milliseconds

        /**
         * Recursively process each store in the results list.  This
         * sequential approach avoids multiplying the delay by the index,
         * which previously caused later items on the page to wait
         * significantly longer before being processed.  After the last
         * item is processed, we either navigate to the next page or
         * advance to the next query.
         *
         * @param {number} idx - The index of the current store in `list`.
         */
        function processStore(idx) {
            // If we've processed all items on this page, handle pagination or
            // advance to the next query.
            if (idx >= list.length) {
                console.log("Finished processing current page");
                // Determine whether to advance to the next page.  Pagination is
                // permitted only when a Next button exists.  If the active
                // location appears to be a numeric pincode then the number
                // of pages is capped at 10.  For non‑numeric locations (e.g.
                // city or locality names) there is no page limit and the
                // scraper will advance through all available pages.  When the
                // limit is reached the scraper will treat the current page
                // as the final page and move on to the next keyword/location.
                // Normalise the active location by trimming whitespace and
                // removing spaces, commas and hyphens.  After these removals
                // treat the location as a pincode only if it contains digits
                // exclusively.  This makes the numeric check more robust to
                // formats like "110 001" or "560102-" while still rejecting
                // strings with alphabetic characters.
                // Determine if the current location is a numeric pincode by normalising
                // and then testing for digits only.  Normalisation strips
                // whitespace, commas and hyphens so that formats like "560 102"
                // or "560-102" are recognised as pincodes.  We treat the
                // location as a pincode only when it contains solely digits.
                const locNorm = normalizeValue(local.activeLocation, true);
                const isPin = /^[0-9]+$/.test(locNorm);
                if (hasNextPage() && (!isPin || pageCounter < 10)) {
                    console.log("New page found, scheduling navigation to next page");
                    // Introduce a random delay BEFORE clicking the next page.  Waiting before
                    // clicking more closely simulates natural browsing behaviour and helps
                    // prevent CAPTCHAs.  Use $fc.randBetween when available.
                    // Increase the randomised delay before clicking the next page in sequential mode.
                    // A longer pause (2–5 seconds) better imitates human browsing behaviour and helps
                    // reduce CAPTCHA prompts when navigating through multiple pages. Use $fc.randBetween
                    // when available; otherwise compute the range manually.
                    // Compute a random delay before clicking the next page based on the
                    // user‑configurable delayTime.  The base delay is
                    // local.delayTime seconds, and we randomise between
                    // 0.5× and 1.5× of this value (converted to ms).  If
                    // delayTime is undefined the default of 10 seconds is
                    // used.  This replaces the previous hard‑coded 2–5s
                    // range and allows the user to control scraping
                    // pacing via the dashboard slider.
                    const baseDelaySeq = ((local && typeof local.delayTime === 'number') ? local.delayTime : 10) * 1000;
                    let minDelaySeq = Math.floor(baseDelaySeq * 0.5);
                    let maxDelaySeq = Math.floor(baseDelaySeq * 1.5);
                    // Always enforce a minimum pause of 100 ms so that navigation
                    // delays never drop to zero even when delayTime is set to 0.  A shorter
                    // minimum allows near‑instant transitions when users set
                    // delayTime to zero while still avoiding unrealistic zero‑ms clicks.
                    if (minDelaySeq < 100) minDelaySeq = 100;
                    if (maxDelaySeq < minDelaySeq) maxDelaySeq = minDelaySeq;
                    const preDelay = Math.floor(Math.random() * (maxDelaySeq - minDelaySeq + 1)) + minDelaySeq;
                    console.log('Sequential mode: waiting ' + preDelay + ' ms before clicking next page');
                    const preTimeoutId = setTimeout(() => {
                        try {
                            clickNextPage();
                        } catch (clickErr) {
                            console.warn('Sequential mode: failed to click next page', clickErr);
                        }
                        // After clicking the next page, wait again to allow the page to load
                        // before scraping.  This second delay further reduces detection.
                        // Increase the delay after clicking the next page to 2–5 seconds. This gives the
                        // page ample time to load before scraping begins and further reduces the
                        // likelihood of CAPTCHAs.
                        // Compute a random delay after clicking the next page using the
                        // same base delay derived from the user’s delayTime.
                        const baseDelaySeqPost = ((local && typeof local.delayTime === 'number') ? local.delayTime : 10) * 1000;
                        let minDelaySeqPost = Math.floor(baseDelaySeqPost * 0.5);
                        let maxDelaySeqPost = Math.floor(baseDelaySeqPost * 1.5);
                        if (minDelaySeqPost < 100) minDelaySeqPost = 100;
                        if (maxDelaySeqPost < minDelaySeqPost) maxDelaySeqPost = minDelaySeqPost;
                        const postDelay = Math.floor(Math.random() * (maxDelaySeqPost - minDelaySeqPost + 1)) + minDelaySeqPost;
                        console.log('Sequential mode: waiting ' + postDelay + ' ms after page click before scraping');
                        const pageTimeoutId = setTimeout(() => {
                            openEachStore();
                        }, postDelay);
                        scrapingTimeouts.push(pageTimeoutId);
                    }, preDelay);
                    scrapingTimeouts.push(preTimeoutId);
                } else {
                    console.log("No more pages or page limit reached. Opening new search query");
                    // Reset the page counter before starting the next query
                    pageCounter = 0;
                    // Remove the completed task from the list
                    local.taskList.shift();
                    // Persist the updated local state and schedule the next query after a
                    // random delay.  Randomising the delay between queries further
                    // reduces scraping tempo and helps avoid CAPTCHAs.
                    $box.setLocal(local, {
                        onSet: () => {
                            // Before scheduling the next query or signalling completion, check the
                            // most recent local state.  If scraping has been paused (e.g., due
                            // to a captcha), avoid sending a completion message prematurely.
                            $box.getLocal(curr => {
                                try {
                                    if (!curr || !curr.status || !curr._taskManager || !curr._taskManager.isWorking) {
                                        console.log('Sequential mode: scraping paused or stopped, not completing');
                                        return;
                                    }
                                } catch (stateErr) {
                                    console.warn('Sequential mode: error checking current state, assuming paused', stateErr);
                                    return;
                                }
                                console.log("Preparing to send start message for next query");
                                if (Array.isArray(curr.taskList) && curr.taskList.length > 0) {
                                    const baseDelayQuery = ((curr && typeof curr.delayTime === 'number') ? curr.delayTime : 10) * 1000;
                                    let minDelayQuery = Math.floor(baseDelayQuery * 0.5);
                                    let maxDelayQuery = Math.floor(baseDelayQuery * 1.5);
                                    if (minDelayQuery < 100) minDelayQuery = 100;
                                    if (maxDelayQuery < minDelayQuery) maxDelayQuery = minDelayQuery;
                                    const queryDelay = Math.floor(Math.random() * (maxDelayQuery - minDelayQuery + 1)) + minDelayQuery;
                                    console.log('Sequential mode: waiting ' + queryDelay + ' ms before starting next query');
                                    const startTimeoutId = setTimeout(() => {
                                        try {
                                            $box.send('start');
                                        } catch (err) {
                                            console.warn('Sequential mode: failed to send start for next query', err);
                                        }
                                    }, queryDelay);
                                    scrapingTimeouts.push(startTimeoutId);
                                } else {
                                    handleScrapingCompletion("complete");
                                }
                            });
                        }
                    });
                }
                return;
            }

            const cid = list[idx];
            // Small random delay before clicking each store to simulate human
            // interaction. We do not multiply by the index, ensuring
            // consistent processing time across all results.  Narrower range
            // speeds up scraping compared to earlier versions.
            // Increase the click delay range to slow down sequential navigation.  A
            // longer, randomized interval (0.5–1.5 seconds) better mimics human
            // behaviour and reduces the chance of triggering CAPTCHAs.  We use
            // $fc.randBetween if available, otherwise compute the range manually.
            // Compute the delay before clicking each store based on the user’s delayTime.
            // Use a narrower range (0.5× to 1.5× of delayTime) to simulate human
            // hesitations when clicking results.  Ensure a minimum of 250 ms to
            // avoid unrealistic rapid clicking.  If delayTime is undefined,
            // assume the default of 10 seconds.  Note that dividing by 2
            // effectively makes per‑click delays shorter than page navigation delays.
            const baseDelayClick = ((local && typeof local.delayTime === 'number') ? local.delayTime : 10) * 1000;
            const minDelayClick = Math.max(100, Math.floor(baseDelayClick * 0.5));
            const maxDelayClick = Math.floor(baseDelayClick * 1.5);
            const clickDelay = Math.floor(Math.random() * (maxDelayClick - minDelayClick + 1)) + minDelayClick;
            const clickTimeoutId = setTimeout(() => {
                $box.getLocal(currentLocal => {
                    // Abort if scraping was stopped in the meantime
                    if (!currentLocal.status && !currentLocal._taskManager.isWorking) {
                        console.log("Scraping was stopped, aborting operation");
                        return;
                    }

                    console.log("Clicking Store");
                    clickStore(cid);

                    // After clicking, watch for the presence of a phone number using a
                    // MutationObserver.  If a phone number appears quickly, proceed
                    // to scrape.  Otherwise, after a short timeout skip this store.
                    // Increase the timeout to give the details panel more time to load.
                    // A 1.2‑second window reduces the chances of skipping listings
                    // where the phone number appears a bit slowly.
                    
// Increase the timeout before concluding that a phone number
// hasn’t loaded.  Google may load business details lazily, and
// the phone number may only appear after additional content like
// reviews has rendered.  A longer timeout (e.g. 2.5 seconds)
// reduces false negatives when the phone field exists but loads slowly.
const PHONE_CHECK_TIMEOUT = 2500;
      // maximum wait time (ms)
                    
                    // Helper to determine if a phone number is present in the panel.
                    function phoneExists() {
                        try {
                            // Use the multi‑selector helper to find phone elements.  This
                            // function returns a jQuery collection containing one or more
                            // possible phone elements or an empty collection if none are
                            // found.
                            const phoneEls = getPhoneElements($('.immersive-container'));
                            if (!phoneEls || !phoneEls.length) return false;
                            let found = false;
                            phoneEls.each(function() {
                                // Remove "Phone:" prefix if present and trim whitespace.
                                const text = $(this).text().replace(/Phone:?/i, '').trim();
                                // Extract digits from the text.  Some phone links may
                                // include extraneous characters or separators; by
                                // removing non‑digit characters we can detect when a
                                // number exists even if formatting varies.
                                const digits = text.replace(/\D/g, '');
                                if (digits) {
                                    found = true;
                                    return false; // break
                                }
                            });
                            return found;
                        } catch (e) {
                            return false;
                        }
                    }

                    // Define handlers for detection and timeout.
                    function handleDetected() {
                        console.log("Phone detected via observer, scraping now");
                        saveData(updatedLocal => {
                            // Abort if scraping was stopped after saving
                            if (!updatedLocal.status && !updatedLocal._taskManager.isWorking) {
                                console.log("Scraping was stopped, aborting next steps");
                                return;
                            }
                            local = updatedLocal;
                            processStore(idx + 1);
                        });
                    }

                    function handleTimeout() {
                        console.log("No phone detected within timeout, performing final scrape check");
                        // Perform a final scrape attempt after the timeout.  If the phone
                        // number never appears, saveData() will skip the record; otherwise
                        // it will save the entry.  This prevents valid businesses from
                        // being skipped outright when their phone numbers load slowly.
                        saveData(updatedLocal => {
                            // Abort if scraping was stopped after saving
                            if (!updatedLocal.status && !updatedLocal._taskManager.isWorking) {
                                console.log("Scraping was stopped, aborting next steps");
                                return;
                            }
                            local = updatedLocal;
                            processStore(idx + 1);
                        });
                    }

                    // Perform a quick initial check after a short delay to determine
                    // whether a phone field exists and if the number is already
                    // present.  This helps skip entries with no phone field
                    // immediately and proceed faster when the phone number is
                    // available without waiting the full timeout.  Only if a
                    // phone field exists but the number is blank do we set up
                    // a MutationObserver to wait for the number to load.
                    const QUICK_CHECK_DELAY = 300; // ms
                    setTimeout(() => {
                        $box.getLocal(innerLocal => {
                            // Abort if scraping was stopped
                            if (!innerLocal.status && !innerLocal._taskManager.isWorking) {
                                console.log("Scraping was stopped, aborting quick check");
                                return;
                            }
                            const containerEl = document.querySelector('.immersive-container');
                            if (!containerEl) {
                                // If container isn't present yet, fall back to full timeout logic
                                handleTimeout();
                                return;
                            }
                            // Use multi‑selector helper to find potential phone fields.
                            const phoneEls = getPhoneElements(containerEl);
                            // If no phone field at all, skip this store immediately.  This
                            // avoids waiting on a phone number that does not exist.
                            if (!phoneEls || phoneEls.length === 0) {
                                console.log("No phone field detected; skipping store quickly");
                                processStore(idx + 1);
                                return;
                            }
                            // If a phone number is already populated, scrape immediately.
                            let immediatePhone = false;
                            phoneEls.each(function() {
                                const text = $(this).text().replace(/Phone:?/i, '').trim();
                                const digits = text.replace(/\D/g, '');
                                if (digits) {
                                    immediatePhone = true;
                                    return false; // break
                                }
                            });
                            if (immediatePhone) {
                                console.log("Phone number already available; scraping now");
                                saveData(updatedLocal => {
                                    if (!updatedLocal.status && !updatedLocal._taskManager.isWorking) {
                                        console.log("Scraping was stopped, aborting next steps");
                                        return;
                                    }
                                    local = updatedLocal;
                                    processStore(idx + 1);
                                });
                                return;
                            }
                            // Phone field exists but number not yet populated; set up observer with adjusted timeout
                            const remainingTimeout = Math.max(PHONE_CHECK_TIMEOUT - QUICK_CHECK_DELAY, 200);
                            let observer = null;
                            let timeoutId = null;
                            const cleanUp = () => {
                                if (observer) {
                                    observer.disconnect();
                                    observer = null;
                                }
                                if (timeoutId) {
                                    clearTimeout(timeoutId);
                                    timeoutId = null;
                                }
                            };
                            observer = new MutationObserver(() => {
                                if (phoneExists()) {
                                    cleanUp();
                                    handleDetected();
                                }
                            });
                            observer.observe(containerEl, { childList: true, subtree: true });
                            timeoutId = setTimeout(() => {
                                cleanUp();
                                handleTimeout();
                            }, remainingTimeout);
                        });
                    }, QUICK_CHECK_DELAY);
                });
            }, clickDelay);
            scrapingTimeouts.push(clickTimeoutId);
        }

        // Begin processing the first store on the page
        processStore(0);
    });
}

/**
 * Page‑wise scraping handler for Fast Mode.
 *
 * When local.fastMode is enabled, this function processes all results on the
 * current Google Maps search page without opening each individual business
 * detail panel.  It looks for phone numbers directly within the list view
 * elements, extracts basic details (name, rating, review count, status and
 * phone) and saves them to the local.collect array.  After processing
 * the current page it navigates to the next page if available, or
 * progresses to the next keyword/location when done.  This implementation
 * uses regex patterns to find phone numbers and basic metadata within the
 * text of each result row.  It falls back to the standard sequential
 * workflow for entries where no phone number is present.
 */
async function openEachStoreFast() {
    // For fast mode we defer incrementing the page counter until after
    // retrieving the local state.  See below for reset/increment logic.
    // Clear any lingering timeouts from previous runs to avoid stacking calls
    try {
        if (Array.isArray(scrapingTimeouts) && scrapingTimeouts.length) {
            scrapingTimeouts.forEach((timeoutId) => {
                clearTimeout(timeoutId);
            });
            scrapingTimeouts = [];
        }
    } catch (err) {
        console.warn('Failed to clear existing scraping timeouts in fast mode', err);
        scrapingTimeouts = [];
    }

    $box.getLocal(async local => {
        // Mark that scraping has begun for fast mode.  Without this
        // flag completion events could fire before any data is parsed.
        try {
            if (local && local._taskManager && !local._taskManager.scrapeStarted) {
                local._taskManager.scrapeStarted = true;
                $box.setLocal(local);
            }
        } catch (err) {
            console.warn('Failed to mark scrapeStarted in openEachStoreFast', err);
        }
        // Reset and increment the page counter for fast mode.  We normalise
        // the active keyword and location before comparing to avoid
        // differences due to whitespace, punctuation or casing.  When a new
        // combination is detected we reset the counter to zero.  After the
        // optional reset, increment the counter to account for this page.
        try {
            if (local) {
                const normKeyword = normalizeValue(local.activeKeyword, false);
                const normLocation = normalizeValue(local.activeLocation, true);
                if (normKeyword !== lastNormalizedKeyword || normLocation !== lastNormalizedLocation) {
                    pageCounter = 0;
                    lastNormalizedKeyword = normKeyword;
                    lastNormalizedLocation = normLocation;
                }
            }
            // Always increment after potential reset
            pageCounter++;
        } catch (err) {
            console.warn('Failed to reset/increment pageCounter in fast mode', err);
        }

        // Abort if scraping was stopped
        if (!local.status && !local._taskManager.isWorking) {
            console.log('Fast mode: scraping was stopped, aborting');
            return;
        }

        console.log('Fast mode: scraping current page list');

        // In fast mode we sometimes need to open the business details panel
        // in order to extract a phone number when it is not present in the
        // list view.  The following helpers encapsulate the logic for
        // normalising phone numbers and fetching them from the details
        // panel without introducing artificial delays.

        /**
         * Normalise and validate a phone string.  Removes spaces,
         * hyphens and parentheses, trims leading zeros, preserves a
         * leading plus sign when present and ensures the remaining
         * digits are between 8 and 15 characters long.  Returns an
         * empty string when invalid.
         *
         * @param {string} phoneRaw Raw phone string to normalise
         * @returns {string} Cleaned phone number or "" if invalid
         */
        function __normalizePhoneFast(phoneRaw) {
            if (!phoneRaw) return '';
            // Remove spaces, ASCII hyphens, unicode dashes, dots and parentheses
            let phone = String(phoneRaw).replace(/[\s\-\u2013\u2014\.\(\)]/g, '');
            const hasPlus = phone.startsWith('+');
            let digitsOnly = phone.replace(/^\+/, '');
            digitsOnly = digitsOnly.replace(/^0+/, '');
            phone = hasPlus ? ('+' + digitsOnly) : digitsOnly;
            const digitsOnly2 = phone.replace(/^\+/, '');
            if (!/^\d+$/.test(digitsOnly2) || digitsOnly2.length < 8 || digitsOnly2.length > 15) {
                return '';
            }
            return phone;
        }

        /**
         * Quickly open the business details panel for the specified
         * listing and attempt to extract a phone number.  It triggers
         * a click on the row (via clickStore when available), then
         * immediately scans the details pane for phone elements using
         * getPhoneElements().  No artificial delays are introduced.
         *
         * @param {string} cid The listing's CID
         * @param {Element} rowEl The DOM element representing the row
         * @returns {string} The normalised phone number or "" if not found
         */
        /**
         * Attempt to retrieve a phone number from the details panel after
         * clicking a listing.  To reduce false positives (e.g. phone numbers
         * lingering from a previous listing) this helper waits until the
         * business name in the details panel is populated and (optionally)
         * matches the expected name from the list.  It then scans only the
         * immersive container for phone elements.  The function yields
         * control across multiple animation frames without introducing any
         * artificial delay to give the DOM time to update.  If no phone
         * number is found within a handful of frames, it returns an empty
         * string.
         *
         * @param {string} cid The listing's CID
         * @param {Element} rowEl The DOM element representing the row
         * @param {string} [expectedName] Optional expected business name
         * @returns {Promise<string>} The normalised phone number or "" if not found
         */
        async function __getPhoneFromDetailsFast(cid, rowEl, expectedName) {
            try {
                // Click the row to open the details panel.  Use clickStore when
                // available; otherwise fall back to a direct DOM click.  Wrap in
                // try/catch to avoid aborting the scraping loop on errors.
                try {
                    if (typeof clickStore === 'function') {
                        clickStore(cid);
                    } else if (rowEl && typeof rowEl.click === 'function') {
                        rowEl.click();
                    }
                } catch (e) {
                    // ignore click errors
                }
                // Attempt to find a phone number across several animation frames.
                // Each iteration yields control back to the browser without
                // introducing a real delay.  We wait until the details panel
                // reports a business name (via getCompanyName) to reduce
                // the risk of reading stale phone numbers from a previous
                // listing.  If an expectedName is provided, we also require
                // the loaded name to include the expected name (case‑insensitive)
                // before scanning for phone numbers.  Stop looping as soon as
                // a valid phone number is found to minimise overhead.
                let foundPhone = '';
                const maxAttempts = 5;
                for (let attempt = 0; attempt < maxAttempts && !foundPhone; attempt++) {
                    // Yield to allow DOM updates.  Use requestAnimationFrame
                    // when available, otherwise schedule a microtask.
                    await new Promise(resolve => {
                        try {
                            requestAnimationFrame(() => resolve());
                        } catch (err) {
                            Promise.resolve().then(resolve);
                        }
                    });
                    // Ensure the details panel exists
                    const containerEl = document.querySelector('.immersive-container');
                    if (!containerEl) continue;
                    // Verify that the business name has loaded.  If an expectedName
                    // is provided, ensure the loaded name contains it.  Skip
                    // scanning until this condition is satisfied.
                    let loadedName = '';
                    try {
                        loadedName = getCompanyName(containerEl) || '';
                    } catch (err) {
                        loadedName = '';
                    }
                    if (!loadedName) continue;
                    if (expectedName && loadedName && loadedName.length) {
                        try {
                            const loadedLower = loadedName.toLowerCase();
                            const expectedLower = String(expectedName).toLowerCase();
                            if (!loadedLower.includes(expectedLower) && !expectedLower.includes(loadedLower)) {
                                // Name mismatch, try next frame
                                continue;
                            }
                        } catch (err) {
                            // ignore matching errors
                        }
                    }
                    // Search within the immersive container for phone elements.  We
                    // intentionally avoid falling back to document.body to reduce
                    // the chance of picking up unrelated numbers.
                    const phoneEls = getPhoneElements(containerEl);
                    if (!phoneEls || !phoneEls.length) continue;
                    phoneEls.each(function() {
                        if (foundPhone) return;
                        let txt = $(this).text() || '';
                        txt = txt.replace(/Phone:?/i, '').trim();
                        const cleaned = __normalizePhoneFast(txt);
                        if (cleaned) {
                            foundPhone = cleaned;
                        }
                    });
                }
                return foundPhone;
            } catch (err) {
                return '';
            }
        }

        // Collect all result rows.  Prefer elements with a data‑cid attribute, but
        // fall back to anchors with a cid parameter in the href when
        // data‑cid is absent.  Google sometimes removes the data‑cid
        // attribute from list items, so this fallback ensures we can
        // still scrape rows in new layouts.
        let rows = document.querySelectorAll('[data-cid]');
        if (!rows || rows.length === 0) {
            rows = document.querySelectorAll('a[href*="cid="]');
        }
        let newCount = 0;
        // Iterate through each row sequentially.  This loop awaits phone
        // extraction from the details pane when necessary.  Using for..of
        // with await ensures that each row is fully processed before
        // moving to the next, without introducing artificial delays.
        for (const row of rows) {
            try {
                // Determine the listing's CID.  When a data‑cid attribute is
                // available use it; otherwise parse it from the href if
                // present.  Without this fallback the scraper would skip
                // rows that use anchor tags instead of explicit data‑cid
                // attributes.
                let cid = null;
                try {
                    cid = row.getAttribute && row.getAttribute('data-cid');
                } catch (err) {
                    cid = null;
                }
                if (!cid) {
                    try {
                        const href = row.getAttribute && row.getAttribute('href') ? row.getAttribute('href') : (row.href || '');
                        if (href) {
                            let m = href.match(/[?&]cid=(\d+)/i);
                            if (m && m[1]) {
                                cid = m[1];
                            } else {
                                m = href.match(/!1s(\d{10,25})/);
                                if (m && m[1]) cid = m[1];
                            }
                        }
                    } catch (err) {
                        // ignore fallback errors
                    }
                }
                if (!cid) continue;
                // Skip already scraped businesses
                const existingIndex = _.findIndex(local.collect, { cid: cid });
                if (existingIndex !== -1) continue;
                const text = row.innerText || '';
                if (!text) continue;
                // Parse the row text into lines and derive the company name.
                const lines = text.split('\n').map(l => l.trim()).filter(l => l.length);
                let company_name = lines.length ? lines[0] : '';
                // Remove "Sponsored" prefix if present.  Some list rows contain
                // advertisements where the first line reads "Sponsored" followed
                // by the business name.  Strip this prefix so the actual name
                // remains.  If the remaining name is empty we'll skip the row later.
                try {
                    if (/sponsored/i.test(company_name)) {
                        company_name = company_name.replace(/sponsored\s*/i, '').trim();
                    }
                } catch (err) {
                    // ignore name cleaning errors
                }
                // Determine the phone number.  First attempt to find it in the list
                // view using the existing pattern.  If not present, open the
                // business details panel and extract it after yielding one or
                // more animation frames.  Provide the company_name to help
                // identify the correct details panel.
                let phone = '';
                // Match phone numbers that may include spaces, hyphens, dots, unicode dashes and parentheses.
                // Older patterns only matched ASCII hyphens; Google sometimes uses en or em dashes in
                // business listings (– or —).  Expand the character class to include these and dot separators.
                // Attempt to find phone numbers via visible text or tel: link.
                // 1) Look for tel: anchor, which explicitly contains the number
                try {
                    const telAnchor = row.querySelector('a[href^="tel:"]');
                    if (telAnchor) {
                        const telHref = telAnchor.getAttribute('href') || '';
                        const raw = telHref.replace(/^tel:/i, '').trim();
                        phone = __normalizePhoneFast(raw);
                    }
                } catch (err) {
                    // ignore
                }
                // 2) Fallback to pattern matching on row text
                if (!phone) {
                    const phoneMatch = text.match(/(?:\+?\d[\d\s\-\u2013\u2014\.\(\)]{7,20}\d)/);
                    if (phoneMatch) {
                        phone = __normalizePhoneFast(phoneMatch[0]);
                    }
                }
                // 3) Fallback to details panel extraction
                if (!phone) {
                    phone = await __getPhoneFromDetailsFast(cid, row, company_name);
                }
                // Skip rows without a phone number.  Fast mode should only
                // collect businesses that provide a valid phone.  If no
                // phone is found in the list view or details panel,
                // skip this result and move on to the next listing.  This
                // behaviour matches user expectations of excluding listings
                // without a contact number.
                if (!phone) {
                    continue;
                }
                // Extract rating (e.g. 4.7) if present
                let review = '0';
                const ratingMatch = text.match(/([0-9]\.[0-9])/);
                if (ratingMatch) review = ratingMatch[1];
                // Extract total review count from parentheses
                let total_reviews = 0;
                const reviewsMatch = text.match(/\((\d[\d,]*)\)/);
                if (reviewsMatch) {
                    const numStr = reviewsMatch[1].replace(/,/g, '');
                    const parsed = parseInt(numStr, 10);
                    if (!isNaN(parsed)) total_reviews = parsed;
                }
                // Determine open/closed status from the text
                let status = '';
                if (/open/i.test(text)) {
                    status = 'Open';
                } else if (/closed/i.test(text)) {
                    status = 'Closed';
                }
                // Determine address and related fields.  Many list rows
                // include a data-local-attribute="d3adr" span containing the
                // full address.  When present we use its text; otherwise we
                // attempt to find a plausible address line within the row
                // text (e.g. the first non-empty line after the business name).
                let address = '';
                try {
                    const addrEl = row.querySelector('[data-local-attribute="d3adr"]');
                    if (addrEl && (addrEl.innerText || addrEl.textContent)) {
                        address = (addrEl.innerText || addrEl.textContent).trim();
                    }
                } catch (err) {
                    // ignore errors retrieving the element
                }
                if (!address) {
                    // Fallback: select the first line (after the name) that does not
                    // resemble a rating, review count, or open/closed status.  We do
                    // not require the line to contain digits because many addresses
                    // (e.g., "MG Road") lack numbers.  This heuristic captures
                    // addresses present in the list view without opening the
                    // details panel.
                    for (let i = 1; i < lines.length; i++) {
                        const l = lines[i];
                        // Skip lines containing rating patterns (e.g. 4.7),
                        // review counts (e.g. "123 reviews") or status words
                        // "Open"/"Closed".
                        if (/\b[0-9]\.[0-9]\b/.test(l) || /\d+\s*reviews?/i.test(l) || /\b(open|closed)\b/i.test(l)) {
                            continue;
                        }
                        address = l;
                        break;
                    }
                }
                address = address ? address.trim() : '';

                // Build the data object.  In fast mode we store the full
                // address in the address field and intentionally omit
                // city/state/pincode as separate columns.  The map_link
                // parameter is still included to provide a direct link to
                // the business on Google Maps.
                const data = {
                    company_name: company_name,
                    phone: phone,
                    review: review,
                    total_reviews: total_reviews,
                    status: status,
                    cid: cid,
                    keyword: local.activeKeyword,
                    location: local.activeLocation,
                    address: address,
                    // Precompute a maps link using the CID.  If the CID is
                    // missing leave this blank.
                    map_link: (cid && String(cid).trim() !== '') ? `https://maps.google.com/?cid=${cid}` : ''
                };
                // Skip sponsored rows.  Some list entries are ads and the
                // company name appears as "Sponsored"; these should not be
                // stored.  Also ensure the phone number exists before
                // adding to the collection.
                if (data.phone && !/sponsored/i.test(data.company_name)) {
                    local.collect.push(data);
                    newCount++;
                    // Persist the updated data immediately in fast mode to
                    // surface new rows on the dashboard without waiting
                    // until the entire page is processed.  Without this,
                    // users had to wait until all rows were scraped or
                    // manually focus the Maps tab before any data
                    // appeared.  By saving after each addition we ensure
                    // the dashboard’s collect length watcher fires
                    // promptly.  We clone the collect array to trigger
                    // change detection.
                    const tempLocal = { ...local, collect: [...local.collect] };
                    try {
                        $box.setLocal(tempLocal);
                    } catch (saveErr) {
                        console.warn('Fast mode: interim setLocal failed', saveErr);
                    }
                    // Broadcast a message to all extension contexts to update the UI
                    // in real‑time when the Maps tab is not active.  Send via both
                    // $box.sendToAll and chrome.runtime.sendMessage because some
                    // contexts may not have $box defined when running in a
                    // background script or service worker.  Using both methods
                    // improves reliability of fast mode updates.
                    try {
                        if (typeof $box !== 'undefined' && $box && typeof $box.sendToAll === 'function') {
                            try {
                                $box.sendToAll('fast_update', data);
                            } catch (e) {
                                console.warn('Fast mode: $box.sendToAll failed', e);
                            }
                        }
                        if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
                            try {
                                chrome.runtime.sendMessage({ event: 'fast_update', data: data }, function() {
                                    // Access lastError to mark promise handled (MV3)
                                    void chrome.runtime.lastError;
                                });
                            } catch (e) {
                                console.warn('Fast mode: chrome.runtime.sendMessage failed', e);
                            }
                        }
                    } catch (msgErr) {
                        console.warn('Fast mode: failed to broadcast fast_update message', msgErr);
                    }
                }
            } catch (e) {
                console.warn('Fast mode: error processing a row', e);
            }
        }

        if (newCount > 0) {
            // De‑duplicate based on cid to avoid duplicates across pages
            local.collect = _.uniqBy(local.collect, 'cid');
        }

        // Persist local and decide next action
        // Clone the local object before saving.  Writing the same object back into
        // chrome.storage can fail to trigger change listeners when only nested
        // arrays are mutated.  By creating a shallow copy with a fresh
        // collect array, we ensure chrome.storage detects a new value and
        // the dashboard updates its data grid even during fast mode scraping.
        const localCopy = { ...local, collect: [...local.collect] };
        $box.setLocal(localCopy, {
            onSet: () => {
                // If scraping was stopped during setLocal, abort
                if (!local.status && !local._taskManager.isWorking) {
                    console.log('Fast mode: scraping stopped after saving, aborting next steps');
                    return;
                }
                // Determine whether to advance to the next page.  Pagination is
                // permitted only if there is a next page button.  If the active
                // location is a numeric pincode the page limit is 10; otherwise
                // there is no limit and all pages will be scraped.  Once the
                // limit is reached for a pincode the scraper will treat the
                // current page as the final page and move on to the next query.
                // Normalise the active location by trimming whitespace and
                // stripping spaces, commas and hyphens.  After these
                // removals treat the location as numeric only if it consists
                // solely of digits.  This ensures that values like "560 102"
                // or "400005-" are recognised as pincodes, while strings
                // containing letters (e.g. "Delhi 110001") are not.
                // Determine if the current location is a numeric pincode.  We
                // normalise the location by removing whitespace, commas and
                // hyphens, then treat it as a pincode only if it comprises
                // digits exclusively.
                const locNormFast = normalizeValue(local.activeLocation, true);
                const isPinFast = /^[0-9]+$/.test(locNormFast);
                if (hasNextPage() && (!isPinFast || pageCounter < 10)) {
                    console.log('Fast mode: preparing to move to next page');
                    // Introduce a random delay BEFORE clicking the next page to simulate
                    // natural browsing and minimise the chance of triggering a CAPTCHA.
                    // Increase the randomised delay before clicking the next page in fast mode.  A
                    // longer 2–5 second pause reduces the chance of triggering CAPTCHAs during rapid
                    // navigation.  Use $fc.randBetween if available; otherwise compute manually.
                    // Compute the delay before clicking the next page in fast mode
                    // using the user‑defined delayTime.  We randomise between
                    // 0.5× and 1.5× of delayTime (converted to ms).  If
                    // delayTime is undefined the default of 10 seconds is used.
                    const baseDelayFastPre = ((local && typeof local.delayTime === 'number') ? local.delayTime : 10) * 1000;
                    let minDelayFastPre = Math.floor(baseDelayFastPre * 0.5);
                    let maxDelayFastPre = Math.floor(baseDelayFastPre * 1.5);
                    if (minDelayFastPre < 50) minDelayFastPre = 50;
                    if (maxDelayFastPre < minDelayFastPre) maxDelayFastPre = minDelayFastPre;
                    const preDelayFast = Math.floor(Math.random() * (maxDelayFastPre - minDelayFastPre + 1)) + minDelayFastPre;
                    console.log('Fast mode: waiting ' + preDelayFast + ' ms before clicking next page');
                    /*
                     * Use requestAnimationFrame-based delays in fast mode rather than setTimeout.
                     * Chrome intensively throttles timers when a tab is hidden, causing
                     * setTimeout callbacks to fire after several minutes.  requestAnimationFrame
                     * continues to trigger roughly once per second even in background tabs.
                     * We measure elapsed wall-clock time via Date.now() within the
                     * requestAnimationFrame loop.  Once the desired delay has elapsed
                     * we click the next page button and wait again before scraping the
                     * following results.  This ensures pagination proceeds without
                     * requiring the user to activate the Maps tab.
                     */
                    const waitWithRAF = (durationMs, cb) => {
                        const start = Date.now();
                        const step = () => {
                            const elapsed = Date.now() - start;
                            if (elapsed >= durationMs) {
                                try {
                                    cb();
                                } catch (err) {
                                    console.warn('waitWithRAF callback error', err);
                                }
                            } else {
                                try {
                                    requestAnimationFrame(step);
                                } catch (rafErr) {
                                    Promise.resolve().then(step);
                                }
                            }
                        };
                        step();
                    };
                    waitWithRAF(preDelayFast, () => {
                        try {
                            clickNextPage();
                        } catch (clickErr) {
                            console.warn('Fast mode: failed to click next page', clickErr);
                        }
                        // Compute the delay after clicking the next page.  Randomise between 0.5× and 1.5×
                        // of delayTime to simulate human browsing.  When delayTime is undefined
                        // default to 10 seconds.
                        const baseDelayFastPost = ((local && typeof local.delayTime === 'number') ? local.delayTime : 10) * 1000;
                        let minDelayFastPost = Math.floor(baseDelayFastPost * 0.5);
                        let maxDelayFastPost = Math.floor(baseDelayFastPost * 1.5);
                        if (minDelayFastPost < 50) minDelayFastPost = 50;
                        if (maxDelayFastPost < minDelayFastPost) maxDelayFastPost = minDelayFastPost;
                        const postDelayFast = Math.floor(Math.random() * (maxDelayFastPost - minDelayFastPost + 1)) + minDelayFastPost;
                        console.log('Fast mode: waiting ' + postDelayFast + ' ms after page click before scraping');
                        waitWithRAF(postDelayFast, () => {
                            openEachStoreFast();
                        });
                    });
                } else {
                    // Before treating this as the final page or moving on to the next query
                    // verify that we are not on a captcha, human verification or unusual traffic
                    // page.  When such pages appear there will be no 'Next' button and the
                    // scraper previously assumed scraping was complete.  To avoid incorrectly
                    // signalling completion, perform a quick DOM inspection.  If a captcha or
                    // verification page is detected we pause scraping instead of completing.
                    try {
                        const host = (location && location.hostname) ? String(location.hostname).toLowerCase() : '';
                        let captchaOrVerification = false;
                        if (host.includes('google.')) {
                            const hasRobotTitle = $('title:contains("Robot")').length > 0;
                            const hasRecaptcha = document.querySelector('iframe[src*="recaptcha"]') || document.querySelector('.g-recaptcha') || document.querySelector('#recaptcha');
                            // Determine if any listings are present.  In newer versions of Google Maps
                            // the data‑cid attribute may be missing.  Fall back to checking for
                            // common indicators such as an immersive container or an anchor with a cid
                            // parameter in its href.  Without this fallback the scraper could
                            // incorrectly assume a captcha page when listings are present.
                            const hasListings = document.querySelector('[data-cid]') || document.querySelector('.immersive-container') || document.querySelector('a[href*="cid="]');
                            // Unusual traffic phrases
                            const bodyTextLower2 = (document.body && document.body.innerText || '').toLowerCase();
                            const unusualTrafficDetected = bodyTextLower2.includes('our systems have detected unusual traffic') || bodyTextLower2.includes('unusual traffic from your computer network');
                            // Human verification phrases
                            const hvPhrases = [
                                'press & hold',
                                'press and hold',
                                'verify that you are human',
                                'verify you are human',
                                "i'm not a robot",
                                'i am not a robot'
                            ];
                            let hvFound = false;
                            for (const p of hvPhrases) {
                                if (bodyTextLower2.includes(p)) {
                                    hvFound = true;
                                    break;
                                }
                            }
                            const recaptchaAnchorHv = document.querySelector('[aria-label*="not a robot"]') || document.querySelector('[data-sitekey]');
                            if (!hasListings && (hasRobotTitle || hasRecaptcha || unusualTrafficDetected || hvFound || recaptchaAnchorHv)) {
                                captchaOrVerification = true;
                            }
                        }
                        if (captchaOrVerification) {
                            console.log('Fast mode: potential captcha/verification page detected before completion');
                            handleScrapingError();
                            return;
                        }
                    } catch (verifyErr) {
                        console.warn('Fast mode: error checking for captcha before completion', verifyErr);
                    }
                    console.log('Fast mode: no next page or page limit reached, moving to next query');
                    // Reset the page counter before starting the next query
                    pageCounter = 0;
                    // Remove the finished keyword/location from the task list
                    local.taskList.shift();
                    // Create a shallow copy of local with a new taskList array.  Without
                    // cloning, chrome.storage may consider the value unchanged and
                    // suppress the onChanged event.  This ensures the dashboard
                    // updates properly between queries in fast mode.
                    const localAfterShift = { ...local, taskList: [...local.taskList], collect: [...local.collect] };
                    // Save updated local data and schedule the next query after a random
                    // delay.  Introducing variability in the delay between queries
                    // slows down scraping and reduces the likelihood of triggering
                    // CAPTCHAs.  Use $fc.randBetween if available; otherwise
                    // compute the delay manually.  Delays are specified in
                    // milliseconds and range between 1 and 10 seconds.
                    $box.setLocal(localAfterShift, {
                        onSet: () => {
                            /*
                             * Before scheduling the next query or signalling completion, re‑read the
                             * current local state.  handleScrapingError() may have paused or
                             * stopped scraping (setting local.status or local._taskManager.isWorking
                             * to false) after the call to setLocal above.  Without checking the
                             * updated state we risk sending a 'scraping_complete' event even when
                             * a captcha has been detected.  By retrieving the latest values we
                             * ensure that we only continue when scraping is still active.
                             */
                            $box.getLocal(curr => {
                                try {
                                    // Abort if scraping has been paused or stopped (e.g. due to captcha)
                                    if (!curr || !curr.status || !curr._taskManager || !curr._taskManager.isWorking) {
                                        console.log('Fast mode: scraping paused or stopped, not completing');
                                        return;
                                    }
                                } catch (stateErr) {
                                    // If an error occurs while reading the state, assume paused
                                    console.warn('Fast mode: error checking current state, assuming paused', stateErr);
                                    return;
                                }
                                // If tasks remain, schedule the next query after a random delay
                                if (Array.isArray(curr.taskList) && curr.taskList.length > 0) {
                                    const queryDelay = (typeof $fc !== 'undefined' && $fc && typeof $fc.randBetween === 'function')
                                        ? $fc.randBetween(3000, 8000)
                                        : Math.floor(Math.random() * (8000 - 3000 + 1)) + 3000;
                                    console.log('Fast mode: waiting ' + queryDelay + ' ms before starting next query');
                                    const startTimeoutId = setTimeout(() => {
                                        try {
                                            $box.send('start');
                                        } catch (err) {
                                            console.warn('Fast mode: failed to send start for next query', err);
                                        }
                                    }, queryDelay);
                                    scrapingTimeouts.push(startTimeoutId);
                                } else {
                                    // No tasks remain and scraping is still active.  Signal completion.
                                    handleScrapingCompletion('complete');
                                }
                            });
                        }
                    });
                }
            }
        });
    });
}

// Navigate to the next results page in both classic and modern layouts.  The
// earlier implementation only searched within table cells for a span
// containing "Next".  However, Google has updated the local search UI so
// that the pagination controls are no longer wrapped in tables.  The Next
// button may appear as an anchor with id="pnnext", have aria‑labels like
// "Next" or "Next page", or simply be an anchor or span element whose text
// content equals "Next".  To robustly handle these variations, we search
// multiple selector patterns and click whichever is found first.
// Override the fast mode implementation with the legacy logic from the
// uploaded old extension.  This version processes all list rows on the
// current page, extracts data when a phone number is present and then
// navigates through pages using setTimeout‑based delays.  It matches the
// exact flow, selectors and timing of the original extension without any
// requestAnimationFrame loops or mid‑row updates.
function openEachStoreFast() {
    // For fast mode we defer incrementing the page counter until after
    // retrieving the local state.  See below for reset/increment logic.
    // Clear any lingering timeouts from previous runs to avoid stacking calls
    try {
        if (Array.isArray(scrapingTimeouts) && scrapingTimeouts.length) {
            scrapingTimeouts.forEach((timeoutId) => {
                clearTimeout(timeoutId);
            });
            scrapingTimeouts = [];
        }
    } catch (err) {
        console.warn('Failed to clear existing scraping timeouts in fast mode', err);
        scrapingTimeouts = [];
    }

    $box.getLocal(local => {
        // Mark that scraping has begun for fast mode.  Without this
        // flag completion events could fire before any data is parsed.
        try {
            if (local && local._taskManager && !local._taskManager.scrapeStarted) {
                local._taskManager.scrapeStarted = true;
                $box.setLocal(local);
            }
        } catch (err) {
            console.warn('Failed to mark scrapeStarted in openEachStoreFast', err);
        }
        // Reset and increment the page counter for fast mode.  We normalise
        // the active keyword and location before comparing to avoid
        // differences due to whitespace, punctuation or casing.  When a new
        // combination is detected we reset the counter to zero.  After the
        // optional reset, increment the counter to account for this page.
        try {
            if (local) {
                const normKeyword = normalizeValue(local.activeKeyword, false);
                const normLocation = normalizeValue(local.activeLocation, true);
                if (normKeyword !== lastNormalizedKeyword || normLocation !== lastNormalizedLocation) {
                    pageCounter = 0;
                    lastNormalizedKeyword = normKeyword;
                    lastNormalizedLocation = normLocation;
                }
            }
            // Always increment after potential reset
            pageCounter++;
        } catch (err) {
            console.warn('Failed to reset/increment pageCounter in fast mode', err);
        }

        // Abort if scraping was stopped
        if (!local.status && !local._taskManager.isWorking) {
            console.log('Fast mode: scraping was stopped, aborting');
            return;
        }

        console.log('Fast mode: scraping current page list');

        // Collect all result rows.  Google frequently changes the markup
        // used for list items in the Maps results pane.  In modern
        // layouts the traditional [data-cid] attribute may be removed
        // entirely.  To maintain compatibility we first gather any
        // elements with data-cid, then fall back to anchors whose href
        // contains a cid parameter or an encoded !1s<cid> segment.  If
        // no anchors are found we finally attempt to select higher‑level
        // listing containers such as [data-result-index] or the Nv2PK
        // class.  These containers are processed later by extracting
        // their inner anchor to derive the CID.
        let rows = document.querySelectorAll('[data-cid]');
        if (!rows || rows.length === 0) {
            // First fallback: anchors linking to a Maps place with a cid
            // parameter or encoded !1s segment
            rows = document.querySelectorAll('a[href*="cid="], a[href*="!1s"]');
        }
        if (!rows || rows.length === 0) {
            // Second fallback: generic listing containers
            rows = document.querySelectorAll('[data-result-index], .Nv2PK');
        }
        let newCount = 0;
        rows.forEach(row => {
            try {
                // Determine the listing's CID using multiple fallbacks.  When
                // a data‑cid attribute is present use it.  Otherwise parse
                // the cid from the href of the row (if it is an anchor) or
                // from the href of an inner anchor.  If a numeric cid
                // cannot be found, derive a pseudo id from the Maps link.
                let cid = null;
                try {
                    cid = row.getAttribute && row.getAttribute('data-cid');
                } catch (err) {
                    cid = null;
                }
                // b) if no cid and the row itself is an anchor, parse href
                if (!cid && (row.tagName && row.tagName.toLowerCase() === 'a')) {
                    const href = row.getAttribute('href') || '';
                    if (href) {
                        let m = href.match(/[?&]cid=(\d+)/i);
                        if (m && m[1]) {
                            cid = m[1];
                        } else {
                            m = href.match(/!1s(\d{10,25})/);
                            if (m && m[1]) cid = m[1];
                        }
                        if (!cid) {
                            // Use the href without query/hash as pseudo id
                            if (/\/maps\/place\//.test(href)) {
                                const url = href.split('#')[0].split('&authuser=')[0];
                                if (url) {
                                    cid = url;
                                }
                            }
                        }
                    }
                }
                // c) if still no cid and row is a generic container, look for an inner anchor
                if (!cid && !(row.tagName && row.tagName.toLowerCase() === 'a')) {
                    try {
                        const anchor = row.querySelector('a[href]');
                        if (anchor) {
                            const href2 = anchor.getAttribute('href') || '';
                            if (href2) {
                                let m2 = href2.match(/[?&]cid=(\d+)/i);
                                if (m2 && m2[1]) {
                                    cid = m2[1];
                                } else {
                                    m2 = href2.match(/!1s(\d{10,25})/);
                                    if (m2 && m2[1]) cid = m2[1];
                                }
                                if (!cid) {
                                    m2 = href2.match(/[?&](?:lcid|ludocid|dralocid)=(\d+)/i);
                                    if (m2 && m2[1]) {
                                        cid = m2[1];
                                    }
                                }
                                if (!cid) {
                                    // Use trimmed href as pseudo id
                                    if (/\/maps\/place\//.test(href2)) {
                                        const url2 = href2.split('#')[0].split('&authuser=')[0];
                                        if (url2) {
                                            cid = url2;
                                        }
                                    }
                                }
                            }
                        }
                    } catch (err) {
                        // ignore
                    }
                }
                if (!cid) return;
                // Skip already scraped businesses
                const existingIndex = _.findIndex(local.collect, { cid: cid });
                if (existingIndex !== -1) return;
                const text = row.innerText || '';
                if (!text) return;
                // Find the phone number for this row.  Prefer explicit tel:
                // links, then fall back to pattern matching on the row text.
                let phone = '';
                try {
                    const telAnchor = row.querySelector('a[href^="tel:"]');
                    if (telAnchor) {
                        const telHref = telAnchor.getAttribute('href') || '';
                        const rawTel = telHref.replace(/^tel:/i, '').trim();
                        phone = rawTel.replace(/[\s\-\u2013\u2014\.\(\)]/g, '');
                    }
                } catch (err) {
                    // ignore
                }
                if (!phone) {
                    // Pattern captures sequences of digits optionally preceded by
                    // a plus sign and allows spaces, hyphens, dots, unicode dashes and parentheses.
                    const phoneMatch = text.match(/(?:\+?\d[\d\s\-\u2013\u2014\.\(\)]{7,20}\d)/);
                    if (!phoneMatch) return;
                    let phoneRaw = phoneMatch[0];
                    phone = phoneRaw.replace(/[\s\-\u2013\u2014\.\(\)]/g, '');
                }
                // Normalise phone by removing a leading plus and trimming
                // leading zeros from the digits.  Preserve the plus if present.
                const hasPlus = phone.startsWith('+');
                let digitsOnly = phone.replace(/^\+/, '');
                digitsOnly = digitsOnly.replace(/^0+/, '');
                phone = hasPlus ? ('+' + digitsOnly) : digitsOnly;
                // Basic sanity check: ensure phone contains only digits (and
                // optional leading plus) and has a plausible length.  Skip
                // numbers shorter than 8 digits or longer than 15 digits to
                // avoid capturing street numbers or other non‑phone data.
                const digitsOnly2 = phone.replace(/^\+/, '');
                if (!/^\d+$/.test(digitsOnly2) || digitsOnly2.length < 8 || digitsOnly2.length > 15) {
                    return;
                }
                // Extract the first non‑empty line as the company name
                const lines = text.split('\n').map(l => l.trim()).filter(l => l.length);
                let company_name = lines.length ? lines[0] : '';
                // Remove "Sponsored" prefix if present.  Some list rows
                // contain advertisements where the first line reads
                // "Sponsored" followed by the business name.  Strip this
                // prefix so the actual name remains.  If the remaining
                // name is empty we'll skip the row later.
                try {
                    if (/sponsored/i.test(company_name)) {
                        company_name = company_name.replace(/sponsored\s*/i, '').trim();
                    }
                } catch (err) {
                    // ignore name cleaning errors
                }
                // Extract rating (e.g. 4.7) if present
                let review = '0';
                const ratingMatch = text.match(/([0-9]\.[0-9])/);
                if (ratingMatch) review = ratingMatch[1];
                // Extract total review count from parentheses
                let total_reviews = 0;
                const reviewsMatch = text.match(/\((\d[\d,]*)\)/);
                if (reviewsMatch) {
                    const numStr = reviewsMatch[1].replace(/,/g, '');
                    const parsed = parseInt(numStr, 10);
                    if (!isNaN(parsed)) total_reviews = parsed;
                }
                // Determine open/closed status from the text
                let status = '';
                if (/open/i.test(text)) {
                    status = 'Open';
                } else if (/closed/i.test(text)) {
                    status = 'Closed';
                }
                // Determine address and related fields.  Many list rows
                // include a data-local-attribute="d3adr" span containing the
                // full address.  When present we use its text; otherwise we
                // attempt to find a plausible address line within the row
                // text (e.g. the first non-empty line after the business name).
                let address = '';
                try {
                    const addrEl = row.querySelector('[data-local-attribute="d3adr"]');
                    if (addrEl && (addrEl.innerText || addrEl.textContent)) {
                        address = (addrEl.innerText || addrEl.textContent).trim();
                    }
                } catch (err) {
                    // ignore errors retrieving the element
                }
                if (!address) {
                    // Fallback: search through the lines for a segment that does
                    // not resemble a rating, review count or open/closed status.  Many
                    // addresses (e.g. "MG Road") lack digits, so we simply use the
                    // first plausible non‑metadata line.
                    for (let i = 1; i < lines.length; i++) {
                        const l = lines[i];
                        if (/\b[0-9]\.[0-9]\b/.test(l) || /\d+\s*reviews?/i.test(l) || /\b(open|closed)\b/i.test(l) || /reviews?/i.test(l)) {
                            continue;
                        }
                        address = l;
                        break;
                    }
                }
                address = address ? address.trim() : '';

                // Build the data object.  In fast mode we store the full
                // address in the address field and intentionally omit
                // city/state/pincode as separate columns.  The map_link
                // parameter is still included to provide a direct link to
                // the business on Google Maps.
                const data = {
                    company_name: company_name,
                    phone: phone,
                    review: review,
                    total_reviews: total_reviews,
                    status: status,
                    cid: cid,
                    keyword: local.activeKeyword,
                    location: local.activeLocation,
                    address: address,
                    map_link: (cid && String(cid).trim() !== '') ? `https://maps.google.com/?cid=${cid}` : ''
                };
                // Skip sponsored rows.  Some list entries are ads and the
                // company name appears as "Sponsored"; these should not be
                // stored.  Also ensure the phone number exists before
                // adding to the collection.
                if (data.phone && !/sponsored/i.test(data.company_name)) {
                    local.collect.push(data);
                    newCount++;
                }
            } catch (e) {
                console.warn('Fast mode: error processing a row', e);
            }
        });

        if (newCount > 0) {
            // De‑duplicate based on cid to avoid duplicates across pages
            local.collect = _.uniqBy(local.collect, 'cid');
        }

        // Persist local and decide next action
        const localCopy = { ...local, collect: [...local.collect] };
        $box.setLocal(localCopy, {
            onSet: () => {
                if (!local.status && !local._taskManager.isWorking) {
                    console.log('Fast mode: scraping stopped after saving, aborting next steps');
                    return;
                }
                const locNormFast = normalizeValue(local.activeLocation, true);
                const isPinFast = /^[0-9]+$/.test(locNormFast);
                if (hasNextPage() && (!isPinFast || pageCounter < 10)) {
                    console.log('Fast mode: preparing to move to next page');
                    const baseDelayFastPre = ((local && typeof local.delayTime === 'number') ? local.delayTime : 10) * 1000;
                    let minDelayFastPre = Math.floor(baseDelayFastPre * 0.5);
                    let maxDelayFastPre = Math.floor(baseDelayFastPre * 1.5);
                    if (minDelayFastPre < 50) minDelayFastPre = 50;
                    if (maxDelayFastPre < minDelayFastPre) maxDelayFastPre = minDelayFastPre;
                    const preDelayFast = Math.floor(Math.random() * (maxDelayFastPre - minDelayFastPre + 1)) + minDelayFastPre;
                    console.log('Fast mode: waiting ' + preDelayFast + ' ms before clicking next page');
                    const preTimeoutIdFast = setTimeout(() => {
                        try {
                            clickNextPage();
                        } catch (clickErr) {
                            console.warn('Fast mode: failed to click next page', clickErr);
                        }
                        const baseDelayFastPost = ((local && typeof local.delayTime === 'number') ? local.delayTime : 10) * 1000;
                        let minDelayFastPost = Math.floor(baseDelayFastPost * 0.5);
                        let maxDelayFastPost = Math.floor(baseDelayFastPost * 1.5);
                        if (minDelayFastPost < 50) minDelayFastPost = 50;
                        if (maxDelayFastPost < minDelayFastPost) maxDelayFastPost = minDelayFastPost;
                        const postDelayFast = Math.floor(Math.random() * (maxDelayFastPost - minDelayFastPost + 1)) + minDelayFastPost;
                        console.log('Fast mode: waiting ' + postDelayFast + ' ms after page click before scraping');
                        const pageTimeoutIdFast = setTimeout(() => {
                            openEachStoreFast();
                        }, postDelayFast);
                        scrapingTimeouts.push(pageTimeoutIdFast);
                    }, preDelayFast);
                    scrapingTimeouts.push(preTimeoutIdFast);
                } else {
                    console.log('Fast mode: no next page or page limit reached, moving to next query');
                    pageCounter = 0;
                    local.taskList.shift();
                    const localAfterShift = { ...local, taskList: [...local.taskList], collect: [...local.collect] };
                    $box.setLocal(localAfterShift, {
                        onSet: () => {
                            if (local.taskList && local.taskList.length > 0) {
                                const queryDelay = (typeof $fc !== 'undefined' && $fc && typeof $fc.randBetween === 'function')
                                    ? $fc.randBetween(3000, 8000)
                                    : Math.floor(Math.random() * (8000 - 3000 + 1)) + 3000;
                                console.log('Fast mode: waiting ' + queryDelay + ' ms before starting next query');
                                const startTimeoutId = setTimeout(() => {
                                    try {
                                        $box.send('start');
                                    } catch (err) {
                                        console.warn('Fast mode: failed to send start for next query', err);
                                    }
                                }, queryDelay);
                                scrapingTimeouts.push(startTimeoutId);
                            } else {
                                handleScrapingCompletion('complete');
                            }
                        }
                    });
                }
            }
        });
    });
}

function clickNextPage(){
    // Determine the next element using several fallbacks
    let next;
    // 1. Classic search: anchor with id pnnext
    next = $('#pnnext');
    if (next && next.length) {
        next[0].click();
        return true;
    }
    // 2. Anchor with aria‑label "Next" or "Next page"
    next = $('a[aria-label="Next"], a[aria-label="Next page"]');
    if (next && next.length) {
        next[0].click();
        return true;
    }
    // 3. Any anchor whose own text or a child span's text is exactly "Next"
    // (case insensitive).  Iterate through all anchors to find a match.
    const anchors = $('a');
    for (let i = 0; i < anchors.length; i++) {
        const a = anchors[i];
        // jQuery wrapper for convenience when looking for child spans
        const $a = $(a);
        const ownText = $a.text().trim().toLowerCase();
        if (ownText === 'next') {
            a.click();
            return true;
        }
        const span = $a.find('span').first();
        if (span && span.text() && span.text().trim().toLowerCase() === 'next') {
            a.click();
            return true;
        }
    }
    return false;
}

// Determine whether a Next page button exists.  Mirror the logic used in
// clickNextPage() so that we detect pagination controls across Google’s
// various layouts.  Returns true if any selector for the Next button is
// present, false otherwise.
function hasNextPage(){
    // 1. Classic id selector
    if ($('#pnnext').length) {
        return true;
    }
    // 2. Aria labels on anchor
    if ($('a[aria-label="Next"], a[aria-label="Next page"]').length) {
        return true;
    }
    // 3. Anchor or span with text "Next"
    const anchors = $('a');
    for (let i = 0; i < anchors.length; i++) {
        const $a = $(anchors[i]);
        const ownText = $a.text().trim().toLowerCase();
        if (ownText === 'next') {
            return true;
        }
        const span = $a.find('span').first();
        if (span && span.text() && span.text().trim().toLowerCase() === 'next') {
            return true;
        }
    }
    return false;
}

function saveData(callback){
	$box.getLocal(local=>{
		// Check if scraping should continue
		if (!local.status && !local._taskManager.isWorking) {
			console.log("Scraping was stopped, aborting save");
			return;
		}
		
        let data = scrapeData();
        // Skip records marked as "Sponsored".  Some Google listings are
        // advertisements and display "Sponsored" instead of a company name.
        // These are not actual businesses and should not be stored.  If we
        // encounter such a record simply invoke the callback to continue
        // without adding it to the collection.
        if (data.company_name && /sponsored/i.test(data.company_name)) {
            console.log("Skipping sponsored result");
            callback(local);
            return;
        }
        // If the phone number is missing or blank, skip storing this record and
        // immediately invoke the callback to continue to the next store.  By
        // returning early here we avoid pushing incomplete entries into the
        // collection and reduce overall scraping time when phone numbers are
        // absent.  The check trims any whitespace to catch strings that are
        // empty or consist solely of spaces.
        if (!data.phone || (typeof data.phone === 'string' && data.phone.trim() === '')) {
            console.log("Skipping record due to missing phone number");
            callback(local);
            return;
        }
        // Ensure the status field is always set. If scrapeData() did not
        // populate a status (for example, if selectors changed or a status
        // element is missing), default to "Open". This prevents the
        // status column from appearing blank for open businesses.
        if (!data.status || (typeof data.status === "string" && data.status.trim() === "")) {
            data.status = "Open";
        }
        if (data.company_name) {
            // Add data
            data.keyword = local.activeKeyword;
            data.location = local.activeLocation;

            // Insert the new data into the collection and de‑duplicate by CID.
            local.collect.push(data);
            local.collect = _.uniqBy(local.collect, 'cid');

            console.log("Saving Data");
            console.log(local.collect);

            // Persist the updated local state.  Clone the collect array into a
            // new object so that chrome.storage detects the change and
            // notifies listeners, including the dashboard.  Without cloning
            // nested arrays chrome.storage may treat the object as unchanged
            // and the data table would fail to update during sequential mode.
            const localClone = { ...local, collect: [...local.collect] };
            $box.setLocal(localClone, {
                onSet: () => {
                    // Check if scraping should continue
                    if (!local.status && !local._taskManager.isWorking) {
                        console.log("Scraping was stopped, aborting callback");
                        return;
                    }
                    // Always call the callback to continue scraping
                    console.log("Calling callback");
                    callback(local);
                }
            });
        } else {
            console.log("Company Name not found");
            callback(local);
        }
	});
}

function scrapeData(){
	let data = {};
	let parent = $('.immersive-container');
    if (!parent || !parent.length) parent = $('div[role="main"]').first();
    if (!parent || !parent.length) parent = $('body').first();
    // Company name: use multi-selector helper to handle layout changes
    data.company_name = getCompanyName(parent);
    data.company_name = data.company_name ? data.company_name : "";
    // Remove sponsored prefix if present.  Some listings display
    // "Sponsored" before the actual business name; strip this so that
    // sponsored ads do not pollute the company_name field.  If the
    // remaining name is empty after removing "Sponsored" we keep
    // "" so that the saveData logic will skip the record.
    try {
        if (/sponsored/i.test(data.company_name)) {
            data.company_name = data.company_name.replace(/sponsored\s*/i, '').trim();
        }
    } catch (err) {
        // ignore errors during name clean up
    }
	
    // Website: use helper to flexibly identify the website URL
    data.website = getWebsiteLink(parent);
    data.website = data.website ? data.website : "";
	
	// Attempt to extract the listing CID from the details panel.  Older
	// versions of Google Maps exposed the CID on a nested <div>
	// (e.g. div[data-cid]).  When this attribute is absent we fall back to
	// parsing the Maps link for a cid parameter or encoded !1s segment.
	let cidVal = $(parent).find('[data-cid]').attr('data-cid');
	if (!cidVal) {
	    try {
	        const anchor = $(parent).find('a[href*="cid="], a[href*="!1s"]').first();
	        if (anchor && anchor.length) {
	            const href = anchor.attr('href') || '';
	            let match = href.match(/[?&]cid=(\d+)/i);
	            if (match && match[1]) {
	                cidVal = match[1];
	            } else {
	                match = href.match(/!1s(\d{10,25})/);
	                if (match && match[1]) {
	                    cidVal = match[1];
	                }
	            }
	        }
	    } catch (err) {
	        console.warn('scrapeData: failed to parse CID fallback', err);
	    }
	}
	data.cid = cidVal ? cidVal : "";
	
    // Rating and total review count: prefer the Google Maps top summary area and aria labels.
    // This avoids picking unrelated numbers from review text, addresses, pincodes, or hidden page content.
    data.review = extractRatingValue(parent) || "0";
    data.total_reviews = extractTotalReviews(parent);

    // Business category is intentionally extracted from the Maps DOM, not from Places API,
    // so the Places API call can remain IDs-only and avoid paid fields.
    data.category = getBusinessCategory(parent);
    data.categories = data.category;
	
    // Address: use helper to account for alternate layouts
    data.address = getAddressText(parent);
    data.address = data.address ? data.address : "";
	
    // Extract pincode (5 or 6 digit number) from the address, if present.  The
    // previous implementation used an invalid range regex.  Here we look for any
    // standalone 5 or 6 digit sequence.  If multiple codes exist, use the last.
    let pinMatches = data.address.match(/\b\d{5,6}\b/g);
    pinMatches = pinMatches ? pinMatches : [];
    data.pincode = pinMatches.length ? pinMatches.pop() : "";
    // Extract subtitle text from the listing.  The subtitle typically
    // contains a phrase like "Restaurant in City, State".  We start by
    // grabbing the raw text from the .YhemCb element if it exists.
    const subtitleElement = $(parent).find('.YhemCb');
    const subtitleText = subtitleElement.length ? $(subtitleElement).text().trim() : "";

    /*
     * Attempt to extract the city and state from the subtitle.  The
     * structure of the subtitle is usually something like:
     *   "Business type in City, State"
     * We split on the first occurrence of " in " to isolate the
     * location portion, then split on commas to separate city and state.
     */
    let parsedCity = "";
    let parsedState = "";
    if (subtitleText && /\s+in\s+/i.test(subtitleText)) {
        // Extract the substring after the first " in " (case‑insensitive)
        const locPart = subtitleText.split(/\s+in\s+/i)[1] || "";
        // Split on commas and trim whitespace.  Some subtitles include extra
        // locality segments (e.g. "Sector 18, Noida, Uttar Pradesh").  We
        // collect all parts and will later pick the last two as city/state.
        const locParts = locPart.split(',').map(p => p.trim()).filter(p => p);
        if (locParts.length >= 2) {
            // Tentatively assign the last two segments as city and state
            // respectively.  Some subtitles include only one segment (e.g.
            // "Delhi"), which we handle in the else branch below.  When more
            // than two segments are present, assume the last segment is the
            // state and the second‑to‑last is the city.
            parsedState = locParts[locParts.length - 1];
            parsedCity = locParts[locParts.length - 2];
        } else if (locParts.length === 1) {
            // Only one segment present after "in"; assign it to city and leave
            // state blank.  Many union territories or cities like "Chandigarh"
            // fall into this case.
            parsedCity = locParts[0];
        }
        // If the tentative state isn't actually a known state (e.g., the
        // subtitle was "in Sector 10, Chandigarh"), we swap city and state
        // candidates.  We'll reuse the indianStates list defined later in
        // fallback parsing.  To avoid duplication, we compute here only when
        // there are at least two segments.
        if (parsedState) {
            const candidateCity = parsedCity || "";
            const candidateState = parsedState || "";
            const statesList = [
                'Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh',
                'Goa','Gujarat','Haryana','Himachal Pradesh','Jammu and Kashmir',
                'Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra',
                'Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab',
                'Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura',
                'Uttar Pradesh','Uttarakhand','West Bengal','Andaman and Nicobar Islands',
                'Chandigarh','Dadra and Nagar Haveli and Daman and Diu','Delhi',
                'Lakshadweep','Puducherry','Ladakh'
            ].map(s => s.toLowerCase());
            const cCity = candidateCity.toLowerCase();
            const cState = candidateState.toLowerCase();
            // If city candidate matches a known state but state candidate does not,
            // swap them.  This handles cases like "in Chandigarh" or
            // "Sector 10, Chandigarh" where the last two segments might be
            // reversed.
            if (cCity && statesList.includes(cCity) && !statesList.includes(cState)) {
                parsedCity = candidateState;
                parsedState = candidateCity;
            }
        }
    }

    /*
     * If the subtitle did not yield both city and state, fall back to
     * parsing the address.  Addresses are typically comma‑separated:
     *   "Street, Area, City, State PINCODE, Country"
     * We remove trailing segments that contain the postal code or
     * obviously indicate the country (e.g., "India") then assume the
     * last part is the state and the second‑to‑last is the city.
     */
    let fallbackCity = "";
    let fallbackState = "";
    if (!parsedCity || !parsedState) {
        // Split the address into comma‑separated parts and trim whitespace.  We'll
        // also extract the postal code from any part containing a 5‑ or 6‑digit
        // number and remove it from that part.  This ensures segments like
        // "Chandigarh 160017" become just "Chandigarh" and we still capture
        // the pincode for mapping.
        const addressParts = data.address.split(',').map(p => p.trim()).filter(p => p);
        const partsWithoutPin = [];
        for (const part of addressParts) {
            // Detect a 5 or 6 digit sequence within the part; remove it and
            // record the pincode if not already set.
            const pinMatch = part.match(/\b\d{5,6}\b/);
            if (pinMatch) {
                const maybePin = pinMatch[0];
                if (!data.pincode) {
                    data.pincode = maybePin;
                }
            }
            // Remove the digit sequence(s) from the string
            const cleaned = part.replace(/\b\d{5,6}\b/g, '').trim();
            if (cleaned) {
                partsWithoutPin.push(cleaned);
            }
        }
        // Remove trailing elements that are clearly country names or general
        // markers like "India", "United States", etc.
        const countryRegex = /\b(india|united states|usa|canada|australia|uk)\b/i;
        while (partsWithoutPin.length && countryRegex.test(partsWithoutPin[partsWithoutPin.length - 1])) {
            partsWithoutPin.pop();
        }
        // If we have at least two segments, tentatively assign the last as
        // state and second‑last as city.  Otherwise, if there's only one
        // segment, assign it to both city and state (useful for union
        // territories like "Chandigarh").
        if (partsWithoutPin.length >= 2) {
            fallbackState = partsWithoutPin[partsWithoutPin.length - 1];
            fallbackCity = partsWithoutPin[partsWithoutPin.length - 2];
        } else if (partsWithoutPin.length === 1) {
            fallbackCity = partsWithoutPin[0];
            fallbackState = partsWithoutPin[0];
        }

        // Further refine by matching against a list of known states/UTs.  Strip any
        // remaining digits (if any) and compare case‑insensitively.  Swap
        // city/state if necessary.
        const stripDigits = s => (s || '').replace(/\b\d{2,6}\b/g, '').trim();
        let cityCandidate = stripDigits(fallbackCity);
        let stateCandidate = stripDigits(fallbackState);
        const indianStates = [
            'Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh',
            'Goa','Gujarat','Haryana','Himachal Pradesh','Jammu and Kashmir',
            'Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra',
            'Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab',
            'Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura',
            'Uttar Pradesh','Uttarakhand','West Bengal','Andaman and Nicobar Islands',
            'Chandigarh','Dadra and Nagar Haveli and Daman and Diu','Delhi',
            'Lakshadweep','Puducherry','Ladakh'
        ].map(s => s.toLowerCase());
        const mCity = (cityCandidate || '').toLowerCase();
        const mState = (stateCandidate || '').toLowerCase();
        if (mCity && indianStates.includes(mCity) && !indianStates.includes(mState)) {
            // Swap if city candidate is actually a state and state candidate isn't
            const tmp = cityCandidate;
            cityCandidate = stateCandidate;
            stateCandidate = tmp;
        }
        fallbackCity = cityCandidate || fallbackCity;
        fallbackState = stateCandidate || fallbackState;
    }

    // Assign city and state preferring subtitle parse over fallback
    // but ensure that pincode-like numbers are stripped out.  Google
    // sometimes appends postal codes or other digits to locality names,
    // which can end up in the city/state fields.  We remove any 5- or
    // 6-digit numeric tokens and then fall back to whichever candidate
    // remains.  If stripping results in an empty string, revert to
    // whichever alternative (subtitle or fallback) is available.
    let finalCity = parsedCity || fallbackCity || "";
    let finalState = parsedState || fallbackState || "";
    finalCity = finalCity.replace(/\b\d{5,6}\b/g, '').trim();
    finalState = finalState.replace(/\b\d{5,6}\b/g, '').trim();
    if (!finalCity) finalCity = (fallbackCity && fallbackCity.replace(/\b\d{5,6}\b/g, '').trim()) || (parsedCity && parsedCity.replace(/\b\d{5,6}\b/g, '').trim()) || "";
    if (!finalState) finalState = (fallbackState && fallbackState.replace(/\b\d{5,6}\b/g, '').trim()) || (parsedState && parsedState.replace(/\b\d{5,6}\b/g, '').trim()) || "";
    data.city = finalCity || "";
    data.state = finalState || "";

    /*
     * Attempt to extract city and state from a Plus Code if present in the
     * container text.  Plus codes typically appear in the form
     * "9C4M+3J, City" or "X4C9+7R6, Bengaluru, Karnataka".  We use a regex
     * to locate a plus code followed by one or two comma‑separated segments.
     * If found, override the current city and state values with the parsed
     * segments.  This provides another fallback path and improves accuracy
     * when the standard subtitle or address parsing fails.
     */
    try {
        /*
         * Detect plus codes followed by comma‑separated locality and
         * administrative parts.  A typical pattern looks like:
         * "8PQ6+F7, Sector 18, Noida, Uttar Pradesh" or "9C4M+3J, Kolkata".
         * We capture everything after the plus code and split on commas.
         */
        const textContent = $(parent).text();
        const plusMatch = textContent.match(/\b[A-Z0-9]{3,8}\+[A-Z0-9]{2,8}\b([^\n]+)/);
        if (plusMatch && plusMatch[1]) {
            // Split the string after the plus code on commas and trim whitespace.
            const segments = plusMatch[1].split(',').map(s => s.trim()).filter(s => s);
            if (segments.length >= 1) {
                // Remove any segment that is purely numeric (pincodes) or a plus
                // code again.
                const nonNumeric = segments.filter(seg => !/^[0-9]{5,6}$/.test(seg) && !/\+/g.test(seg));
                if (nonNumeric.length === 1) {
                    // Only one segment – could be a city or state.  Assign to both.
                    const val = nonNumeric[0];
                    if (!data.city) data.city = val;
                    if (!data.state) data.state = val;
                } else if (nonNumeric.length >= 2) {
                    // Assume last element is state and second‑last is city.  Use
                    // the same states list to validate and possibly swap.
                    let pcCandidateCity = nonNumeric[nonNumeric.length - 2];
                    let pcCandidateState = nonNumeric[nonNumeric.length - 1];
                    const statesList = [
                        'Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh',
                        'Goa','Gujarat','Haryana','Himachal Pradesh','Jammu and Kashmir',
                        'Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra',
                        'Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab',
                        'Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura',
                        'Uttar Pradesh','Uttarakhand','West Bengal','Andaman and Nicobar Islands',
                        'Chandigarh','Dadra and Nagar Haveli and Daman and Diu','Delhi',
                        'Lakshadweep','Puducherry','Ladakh'
                    ].map(s => s.toLowerCase());
                    const pcCityLower = pcCandidateCity.toLowerCase();
                    const pcStateLower = pcCandidateState.toLowerCase();
                    if (statesList.includes(pcCityLower) && !statesList.includes(pcStateLower)) {
                        // Swap if necessary
                        const tmp = pcCandidateCity;
                        pcCandidateCity = pcCandidateState;
                        pcCandidateState = tmp;
                    }
                    if (pcCandidateCity && !data.city) data.city = pcCandidateCity;
                    if (pcCandidateState && !data.state) data.state = pcCandidateState;
                }
            }
        }
    } catch (e) {
        console.warn('Plus code extraction failed', e);
    }
    
    
	
	
    // Status
    // Determine if the listing is marked as temporarily or permanently closed.
    // We check for both labels within the immersive container. If neither
    // indicates closure, we default the status to "Open". Businesses with
    // "Permanently closed" or "Temporarily closed" labels will show the
    // appropriate status in the exported data and table.
    /*
     * Determine the business status by checking for "temporarily closed" or
     * "permanently closed" text anywhere within the immersive container.
     * We perform a case‑insensitive search on the container's text to
     * accommodate variations in casing and translations. If neither
     * closure status is found, the business is considered open.
     */
    const containerText = $(parent).text().toLowerCase();
    const permanentlyClosed = containerText.includes("permanently closed");
    const temporarilyClosed = containerText.includes("temporarily closed");
    if (permanentlyClosed) {
        data.status = "Permanently closed";
    } else if (temporarilyClosed) {
        data.status = "Temporarily closed";
    } else {
        data.status = "Open";
    }

    // Phone
    // Use the multi‑selector helper to locate potential phone elements.  This
    // approach tries several selectors (d3ph, tel: links, "Phone" labels)
    // and returns a jQuery collection.  We iterate over each unique text
    // value, normalise it and assign the digits to data.phone.
    let tempCollect = [];
    try {
        const phoneEls = getPhoneElements(parent);
        phoneEls.each((key, value) => {
            let phoneText = $(value).text().replace(/Phone:?/i, '').trim();
            if (tempCollect.indexOf(phoneText) === -1) {
                // Normalise phone by removing non‑digit characters and leading zeros.
                let digits = String(phoneText || '').replace(/\D/g, '');
                digits = digits.replace(/^0+/, '');
                if (digits) {
                    data['phone'] = digits;
                }
                tempCollect.push(phoneText);
            }
        });
    } catch (err) {
        // If an error occurs during phone extraction, leave data.phone unset.
    }

    // Email
    // Collect any visible email addresses within the business details panel.  If
    // one or more addresses are found, store them as a comma‑separated string
    // under email_1.  This complements the separate website email scraping
    // function in index.js, allowing direct email extraction from Google
    // listings when available.
    try {
        const emails = getEmailAddresses(parent);
        if (emails && emails.length) {
            data.email_1 = emails.join(', ');
        } else {
            data.email_1 = '';
        }
    } catch (err) {
        data.email_1 = '';
    }

    /*
     * Final cleanup of city and state values.  The earlier parsing steps
     * may still leave the city field set to a state or include stray digits.
     * Here we re-examine the address parts to determine the most likely
     * city and state: the most recent locality in the address that is not
     * a known state is chosen as the city, and the most recent locality
     * that is a known state becomes the state.  If no clear distinction
     * can be made, we fall back to the last two parts of the cleaned
     * address.  This logic reduces the chance of a state name appearing
     * in the city field.
     */
    try {
        const statesListFinal = [
            'Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh',
            'Goa','Gujarat','Haryana','Himachal Pradesh','Jammu and Kashmir',
            'Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra',
            'Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab',
            'Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura',
            'Uttar Pradesh','Uttarakhand','West Bengal','Andaman and Nicobar Islands',
            'Chandigarh','Dadra and Nagar Haveli and Daman and Diu','Delhi',
            'Lakshadweep','Puducherry','Ladakh'
        ].map(s => s.toLowerCase());
        // Split the stored address on commas and remove blank entries
        const addrParts = (data.address || '').split(',').map(p => p.trim()).filter(p => p);
        // Remove any embedded pincodes from each part
        const cleanedParts = [];
        for (const part of addrParts) {
            const cleaned = part.replace(/\b\d{5,6}\b/g, '').trim();
            if (cleaned) cleanedParts.push(cleaned);
        }
        // Remove country identifiers
        const countries = ['india','united states','usa','canada','australia','uk'];
        while (cleanedParts.length && countries.includes(cleanedParts[cleanedParts.length - 1].toLowerCase())) {
            cleanedParts.pop();
        }
        let fallbackCityFinal = '';
        let fallbackStateFinal = '';
        // Iterate from the end to pick the nearest city and state
        for (let i = cleanedParts.length - 1; i >= 0; i--) {
            const part = cleanedParts[i];
            const lower = part.toLowerCase();
            if (!fallbackStateFinal && statesListFinal.includes(lower)) {
                fallbackStateFinal = part;
            } else if (!fallbackCityFinal && !statesListFinal.includes(lower)) {
                fallbackCityFinal = part;
            }
            if (fallbackCityFinal && fallbackStateFinal) break;
        }
        // If state or city still missing, fallback to last parts of the cleaned array
        if (!fallbackStateFinal && cleanedParts.length >= 1) {
            fallbackStateFinal = cleanedParts[cleanedParts.length - 1];
        }
        if (!fallbackCityFinal && cleanedParts.length >= 2) {
            fallbackCityFinal = cleanedParts[cleanedParts.length - 2];
        } else if (!fallbackCityFinal && cleanedParts.length === 1) {
            fallbackCityFinal = cleanedParts[0];
        }
        // Strip digits from the current data.city and data.state and trim
        let cityVal = (data.city || '').replace(/\b\d{5,6}\b/g, '').trim();
        let stateVal = (data.state || '').replace(/\b\d{5,6}\b/g, '').trim();
        // If cityVal is empty or looks like a state, use the fallback city
        if (!cityVal || statesListFinal.includes(cityVal.toLowerCase())) {
            if (fallbackCityFinal && !statesListFinal.includes(fallbackCityFinal.toLowerCase())) {
                cityVal = fallbackCityFinal;
            } else {
                // No suitable city found; avoid using a state name for city
                cityVal = '';
            }
        }
        // If stateVal is not a recognized state, but fallback state is, use fallback
        if (!stateVal || !statesListFinal.includes(stateVal.toLowerCase())) {
            if (fallbackStateFinal && statesListFinal.includes(fallbackStateFinal.toLowerCase())) {
                stateVal = fallbackStateFinal;
            }
        }
        data.city = cityVal;
        data.state = stateVal;

        // If total_reviews is blank or undefined, assign a default of 0.  Some listings
        // may have no reviews; previously this resulted in a blank cell in the CSV
        // and data table.  Setting a numeric zero makes the absence explicit.
        if (data.total_reviews === "" || data.total_reviews === null || typeof data.total_reviews === "undefined") {
            data.total_reviews = 0;
        }
        // Ensure the rating is a string.  If it was blank, we defaulted it to "0" above.
        data.review = (typeof data.review === 'undefined' || data.review === null) ? "0" : String(data.review);
        // Compute a stable Google Maps URL using the CID.  If a CID exists, a map link
        // can be formed via the maps "cid" parameter, which opens the business
        // details directly.  If no CID is available, leave the link blank.
        if (data.cid && String(data.cid).trim() !== "") {
            data.map_link = "https://maps.google.com/?cid=" + data.cid;
        } else {
            data.map_link = "";
        }
    } catch (e) {
        console.warn('Final city/state cleanup failed', e);
    }
	
	console.log("Scraping Data");
	console.log(data);
	return data;
}


// -----------------------------------------------------------------------------
// New profile-page scraper bridge for Apify direct dataset flow.
// The background TaskController opens a direct Google Maps profile URL and sends
// POCKETLEADS_SCRAPE_PROFILE. This keeps only individual business profile
// scraping and avoids the removed search-result-page listing collection flow.
(function installPocketLeadsProfileScraperBridge() {
    if (window.PocketLeadsProfileScraperBridgeInstalled) return;
    window.PocketLeadsProfileScraperBridgeInstalled = true;

    function getPlaceIdFromUrl() {
        try {
            const u = new URL(location.href);
            const q = String(u.searchParams.get('q') || '').trim();
            if (/^place_id:/i.test(q)) return q.slice(q.indexOf(':') + 1).trim();
            return String(u.searchParams.get('query_place_id') || '').trim();
        } catch (e) {
            const direct = String(location.href || '').match(/[?&]q=place_id%3A([^&]+)/i)
                || String(location.href || '').match(/[?&]q=place_id:([^&]+)/i);
            if (direct && direct[1]) { try { return decodeURIComponent(direct[1]).trim(); } catch (_) { return direct[1].trim(); } }
            const m = String(location.href || '').match(/[?&]query_place_id=([^&]+)/);
            try { return m && m[1] ? decodeURIComponent(m[1]).trim() : ''; } catch (_) { return m && m[1] || ''; }
        }
    }

    function normalizePhoneValue(phoneText) {
        if (!phoneText) return '';
        let raw = String(phoneText).replace(/^\s*Phone:?\s*/i, '').replace(/^\s*phone:?\s*/i, '').trim();
        const telMatch = raw.match(/\+?\d[\d\s\-–—().]{7,}\d/);
        if (telMatch) raw = telMatch[0];
        let digits = raw.replace(/[^\d+]/g, '');
        if (digits.indexOf('+') > 0) digits = digits.replace(/\+/g, '');
        return digits;
    }

    function waitForProfilePanel(timeoutMs) {
        const start = Date.now();
        return new Promise((resolve, reject) => {
            function hasProfileSignal() {
                try {
                    // Avoid repeatedly materialising the full Maps page innerText.
                    // On long SPA sessions that creates large temporary strings and
                    // can contribute to renderer memory pressure.
                    const hasTitle = !!($('.DUwDvf, h1.DUwDvf, [class*="fontHeadlineLarge"], [data-attrid="title"]').first().text().trim());
                    const hasBusinessField = $('[data-item-id*="address"], [data-item-id*="phone"], a[data-item-id="authority"], button[aria-label^="Directions"], [aria-label*="reviews"]').length > 0;
                    const hasMainPanel = !!document.querySelector('div[role="main"]');
                    return hasTitle && (hasBusinessField || hasMainPanel);
                } catch (e) {
                    return false;
                }
            }
            function tick() {
                if (hasProfileSignal()) return resolve(true);
                if (Date.now() - start > (timeoutMs || 30000)) return reject(new Error('Google Maps profile failed to load.'));
                setTimeout(tick, 350);
            }
            tick();
        });
    }

    window.PocketLeadsProfileScraper = {
        waitForProfilePanel,
        scrapeProfile: async function(payload) {
            await waitForProfilePanel((payload && payload.timeoutMs) || 30000);
            // Give late address/phone controls a brief settle window without
            // keeping a heavy observer alive.
            await new Promise(resolve => setTimeout(resolve, 350));
            let data = scrapeData();
            const root = $('div[role="main"]').first().length ? $('div[role="main"]').first() : $('body').first();
            const placeId = (payload && payload.placeId) || getPlaceIdFromUrl();
            const profileUrl = (payload && payload.url) || ('https://www.google.com/maps/place/?q=place_id:' + encodeURIComponent(String(placeId || '').trim()));

            if (!data.company_name) {
                data.company_name = $('.DUwDvf, h1.DUwDvf, h1').first().text().trim() || '';
            }
            if (!data.website) {
                const websiteEl = root.find('a[data-item-id="authority"], a[aria-label*="Website"], a[data-tooltip*="Website"]').first();
                data.website = websiteEl && websiteEl.length ? (websiteEl.attr('href') || '') : '';
            }
            if (!data.address) {
                const addrEl = root.find('[data-item-id*="address"], button[aria-label^="Address:"]').first();
                data.address = addrEl && addrEl.length ? ((addrEl.attr('aria-label') || addrEl.text() || '').replace(/^Address:?\s*/i, '').trim()) : '';
            }
            if (!data.phone) {
                const phoneEl = root.find('[data-item-id*="phone"], button[aria-label^="Phone:"], a[href^="tel:"]').first();
                const phoneRaw = phoneEl && phoneEl.length ? (phoneEl.attr('aria-label') || phoneEl.attr('href') || phoneEl.text() || '') : '';
                data.phone = normalizePhoneValue(phoneRaw.replace(/^tel:/i, ''));
            }
            if (!data.review || data.review === '0') {
                const ratingText = root.find('[aria-label*="stars"], [aria-label*="Rated"]').first().attr('aria-label') || '';
                const m = ratingText.match(/([0-9]*\.?[0-9]+)/);
                if (m && m[1]) data.review = m[1];
            }
            if (!data.total_reviews) {
                data.total_reviews = extractTotalReviews(root);
            }
            if (!data.category) {
                data.category = getBusinessCategory(root);
                data.categories = data.category;
            }
            data.place_id = placeId;
            data.cid = data.cid || placeId;
            data.keyword = (payload && payload.keyword) || data.keyword || '';
            data.location = (payload && payload.location) || data.location || '';
            data.map_link = profileUrl;
            data.source = (payload && payload.source) || 'google_maps_place_id_profile';
            if (!data.status) data.status = 'Open';
            if (typeof data.total_reviews === 'undefined' || data.total_reviews === '') data.total_reviews = 0;
            return data;
        }
    };

    try {
        // Only the top Google Maps frame may answer profile scrape requests.
        // Loading/responding in every iframe caused duplicate work and extra RAM usage.
        if (window.top !== window) return;
        chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
            if (!message || message.action !== 'POCKETLEADS_SCRAPE_PROFILE') return;
            window.PocketLeadsProfileScraper.scrapeProfile(message)
                .then(data => sendResponse({ ok: true, data }))
                .catch(err => sendResponse({ ok: false, error: err && err.message ? err.message : String(err) }));
            return true;
        });
    } catch (err) {
        console.warn('PocketLeads profile scraper bridge listener failed to install', err);
    }
})();

// NEW: Function to handle scraping completion
function handleScrapingCompletion(reason) {
    // Guard against premature completion events.  Completion should
    // only fire after at least one listing has been processed (i.e.,
    // scrapeStarted is true).  If this flag is false, ignore the
    // completion call entirely.  This protects against race
    // conditions where the task list has not yet been initialised or
    // the user has not defined any keywords/locations.
    $box.getLocal(local => {
        let started = false;
        try {
            started = !!(local && local._taskManager && local._taskManager.scrapeStarted);
        } catch (err) {
            started = false;
        }
        if (!started) {
            console.warn('handleScrapingCompletion invoked before scraping began; skipping completion');
            return;
        }
        // If scraping has been paused due to a captcha or verification page, do not
        // treat the run as complete.  The captchaPaused flag is set by
        // handleScrapingError() and cleared when the user restarts scraping.
        try {
            if (local && local.captchaPaused) {
                console.log('handleScrapingCompletion aborted: paused due to captcha');
                return;
            }
        } catch (e) {
            // ignore errors while checking captchaPaused
        }
        console.log("Scraping completed: " + reason);

        // Determine if there are still tasks remaining.  In normal
        // operation handleScrapingCompletion should only be invoked
        // when all queued queries have finished.  However, race
        // conditions or interactions with WhatsApp number checks can
        // sometimes trigger a completion early.  If there are
        // remaining tasks (i.e. local.taskList still has entries),
        // abort this completion to avoid prematurely stopping the
        // scraper.  We intentionally do not clear timeouts or modify
        // status flags in this branch.  Instead we simply log and
        // return.  The sequential/fast mode logic will continue
        // processing the remaining queries.  Perform this check
        // before clearing timeouts or stopping the keep‑alive to
        // ensure the ongoing scrape continues unaffected.
        let tasksRemain = false;
        try {
            tasksRemain = Array.isArray(local.taskList) && local.taskList.length > 0;
        } catch (err) {
            tasksRemain = false;
        }
        // Only guard against premature completion when tasks remain.  The
        // original implementation also checked a stillActive flag based on
        // local.status and _taskManager.isWorking.  However, this flag
        // can remain true even after all tasks have finished (e.g. when
        // concurrent WhatsApp checks are running), causing the scraper
        // to hang indefinitely and suppress the completion notification.
        // By ignoring stillActive we allow the completion handler to
        // proceed whenever the task list is empty, ensuring that the
        // scraping process stops and the user receives the final
        // completion message.
        if (tasksRemain) {
            console.warn('handleScrapingCompletion: tasksRemain=' + tasksRemain + ' – ignoring premature completion for reason=' + reason);
            return;
        }

        // Stop the keep‑alive WebRTC connection now that scraping has finished.
        stopKeepAliveConnection();

        // Clear all timeouts
        try {
            scrapingTimeouts.forEach(timeoutId => {
                clearTimeout(timeoutId);
            });
            scrapingTimeouts = [];
        } catch (clearErr) {
            console.warn('Failed to clear scraping timeouts in handleScrapingCompletion', clearErr);
            scrapingTimeouts = [];
        }

        // Mark local status and isWorking false only when no tasks remain.
        try {
            local.status = false;
            if (local._taskManager) {
                local._taskManager.isWorking = false;
            }
            $box.setLocal(local);
        } catch (setErr) {
            console.warn('Failed to reset local state in handleScrapingCompletion', setErr);
        }

        // Completion is a data lifecycle event, not a legacy auth polling gate.
        $box.getLocal(currentLocal => {
            const queue = (currentLocal && currentLocal.apifyQueue) || {};
            const controllerOwnsCompletion = String(queue.provider || '').toLowerCase() === 'googlemaps'
                || !!queue.runEventId || /^google_pipeline/i.test(String(queue.status || ''));
            if (!controllerOwnsCompletion) sendContentTerminalEventOnce('scraping_complete', {message:'Scraping complete.'}, 15000);
        });
    });
}


// NEW: Function to handle scraping errors such as captcha or blocked pages.
// When fast mode is enabled we do not open a new tab.  Instead we pause
// scraping and inform the dashboard via a message.  For non‑fast mode the
// original behaviour (opening a new tab and closing the current one) is
// preserved.  This prevents a flood of new tabs when Google presents a
// captcha while scraping quickly.
function handleScrapingError() {
    console.log("Handling scraping error");
    // Clear the periodic captcha/no‑results polling interval immediately.  If a captcha
    // appears mid‑run, clearing this interval prevents additional polling
    // callbacks from firing while the user resolves the captcha or stops
    // scraping.
    clearCaptchaInterval();
    $box.getLocal(local => {
        // Only proceed if a scraping session is active. Guard against
        // missing _taskManager or isWorking properties which can be
        // undefined on some versions of the local model.
        if (!local || !local.status || !local._taskManager || !local._taskManager.isWorking) {
            return;
        }

        /*
         * Regardless of fast or normal mode, stop any pending timers.
         * During rapid navigation/pagination multiple timeouts may have been
         * scheduled in openEachStore/openEachStoreFast. If we detect a
         * captcha mid‑run these callbacks may still fire and attempt to
         * continue scraping or open new pages. Clearing all timeouts here
         * prevents subsequent invocations from racing ahead after we have
         * paused scraping. The scrapingTimeouts array is defined at the top
         * of this file and tracks all scheduled callbacks.
         */
        try {
            if (Array.isArray(scrapingTimeouts) && scrapingTimeouts.length) {
                scrapingTimeouts.forEach(timeoutId => {
                    clearTimeout(timeoutId);
                });
                scrapingTimeouts = [];
            }
        } catch (err) {
            console.warn('Failed to clear scrapingTimeouts in handleScrapingError', err);
            scrapingTimeouts = [];
        }

        // Pause the current task by clearing the status flags and persist state.
        // Mark that we paused due to a captcha or error so the completion handler
        // does not treat the run as finished.  The captchaPaused flag will be
        // cleared when the user manually restarts scraping.
        local.status = false;
        if (local._taskManager) {
            local._taskManager.isWorking = false;
        }
        // Persist a captcha pause flag on the local model so completion
        // handlers can skip firing while paused.  Without this marker the
        // scraper may prematurely signal completion when a captcha appears.
        try {
            local.captchaPaused = true;
        } catch (e) {
            // ignore assignment errors
        }

        // Notify the dashboard of the error. In all modes we show a
        // persistent popup so the user can manually resolve the captcha.
        // Provide a clear message explaining that scraping has been paused
        // due to a CAPTCHA or verification page and that the user must solve
        // the challenge in the browser before resuming.
        try {
            sendContentTerminalEventOnce('scraping_error', {
                message: 'CAPTCHA detected. Scraping has been paused. Please solve the CAPTCHA in the browser, then click Resume.'
            }, 10000);
        } catch (err) {
            console.warn('Failed to dispatch scraping_error message', err);
        }

        // Persist the updated local state.  We do not trigger continuation
        // automatically; the user must restart manually.  Previously the
        // extension reopened the current search in a new tab when a captcha
        // appeared (non‑fast mode).  This behaviour led to multiple tabs being
        // created before the user could stop scraping.  To avoid this,
        // always stop scraping without spawning new tabs.  Once the state
        // has been saved we also emit a "scraping_stopped" event so the
        // popup UI can update immediately (e.g. stop the spinner and
        // enable the start button).  Without this additional message the
        // popup may continue to display the scraping progress indicator.
        $box.setLocal(local, {
            onSet: () => {
                console.log('Scraping paused due to captcha/error.');
                // Let the background controller create the resumable checkpoint and
                // own the single stop event. Directly emitting scraping_stopped here
                // caused a second popup/notification after scraping_error.
                try {
                    chrome.runtime.sendMessage({ action: 'stop_scraping', reason: 'captcha_detected' }, function () {
                        void chrome.runtime.lastError;
                    });
                } catch (notifyErr) {
                    console.warn('Failed to request controller stop after CAPTCHA', notifyErr);
                }
            }
        });
        // Do not automatically reopen or close tabs on captcha; exit early.
        return;
    });
}

// NEW: Function to handle "no results" pages gracefully.
// When Google returns a page indicating there are no results for the current
// keyword/location combination, we skip the current task instead of
// treating it as a captcha or error.  This helper removes the active
// query from the task list, persists the updated state, and triggers
// TaskManager to move on to the next query.  It ensures the scraping
// session continues uninterrupted and avoids confusing the user with
// captcha notifications when no results are found.
function handleNoResults() {
    console.log('Handling no results: skipping current task');
    // Clear the periodic captcha/no‑results polling interval to avoid
    // repeated detections within the same tab.
    clearCaptchaInterval();
    // Remove all scheduled scraping timeouts for the current page.
    try {
        if (Array.isArray(scrapingTimeouts) && scrapingTimeouts.length) {
            scrapingTimeouts.forEach(timeoutId => {
                clearTimeout(timeoutId);
            });
            scrapingTimeouts = [];
        }
    } catch (err) {
        console.warn('Failed to clear scrapingTimeouts in handleNoResults', err);
        scrapingTimeouts = [];
    }
    $box.getLocal(local => {
        try {
            // If scraping has been stopped or the task manager is idle, do nothing.
            if (!local || !local.status || !local._taskManager || !local._taskManager.isWorking) {
                return;
            }
            // Remove the first task (active query) from the taskList if present.
            if (Array.isArray(local.taskList) && local.taskList.length > 0) {
                local.taskList.shift();
            }
            // Build a shallow clone to ensure storage change events fire.  Clone
            // both taskList and collect arrays to avoid referencing the same
            // objects in memory.
            const updatedLocal = { ...local, taskList: [...local.taskList], collect: [...local.collect] };
            // Persist the updated local state, then advance to the next query.
            $box.setLocal(updatedLocal, {
                onSet: () => {
                    try {
                        // If there are still tasks remaining, schedule the next query.
                        if (updatedLocal.taskList && updatedLocal.taskList.length > 0) {
                            // Immediately trigger the next task via TaskManager rather than
                            // sending a 'start' message.  Using gotoTask ensures the
                            // existing scraping logic is reused.  Pass a copy of updatedLocal
                            // to avoid referencing stale objects.
                            TaskManager.gotoTask(updatedLocal, 'openMap');
                        } else {
                            // No more tasks: complete scraping session
                            handleScrapingCompletion('complete');
                        }
                    } catch (err) {
                        console.warn('Failed to schedule next query after no results', err);
                    }
                }
            });
        } catch (err) {
            console.warn('Error in handleNoResults processing', err);
        }
    });
}

// NEW: Check for captcha or errors periodically
// NEW: Check for captcha, errors, or no-results pages periodically.
//
// The scraping process runs in a Google search page rendered as a
// "Local results" listings page. Occasionally, the search results page may
// display a message like "There are no results here. Try searching in a
// different location." This can occur for remote or invalid locations or
// when Google cannot find matching businesses. In prior versions of the
// extension the content script would detect this state and close the tab
// automatically so the TaskManager could proceed to the next query. When
// the page shows the "no results" message the DOM does not contain any
// listing entries, so the extension would be stuck waiting for result
// selectors that never appear. To restore this behaviour we check for
// these text strings in the DOM every few seconds. If found, we invoke
// handleScrapingError(), which signals the background script to close the
// current tab and open a fresh results tab for the same query. A simple
// state flag prevents repeated invocations within the same tab.
let hasHandledNoResults = false;
// Legacy captcha/error polling now runs every two seconds. Direct v65
// query_place_id profile pages skip this scanner entirely because the managed
// tab worker already handles crashes, timeouts and verification failures. This
// avoids repeatedly reading the full Google Maps page body in hidden tabs.
// Store the interval ID so it can be cleared when scraping stops or the network goes offline.
captchaIntervalId = setInterval(() => {
    // Only perform polling on Google domains.  When the user
    // navigates to non‑Google pages (e.g., whatsapp.com) while
    // scraping remains active, this interval would previously
    // trigger handleScrapingError() erroneously because the page
    // content does not resemble Google results.  Guard against that
    // by skipping the checks when the hostname does not contain
    // "google.".  If not on a Google domain, simply return to allow
    // the interval to continue without taking action.
    try {
        const host = (location && location.hostname) ? String(location.hostname).toLowerCase() : '';
        if (!host.includes('google.')) {
            return;
        }
        // Direct q=place_id pages are controlled by the Ghost profile bridge.
        // Running the old full-body captcha/no-result scanner every 500ms on
        // these heavy Maps pages wastes CPU/memory and can also emit legacy
        // stop/completion events. The background worker already detects crashes,
        // timeouts and discarded tabs for this mode.
        const managedUrl = new URL(location.href);
        const directPlaceQuery = String(managedUrl.searchParams.get('q') || '').trim();
        if (managedUrl.searchParams.has('query_place_id') || /^place_id:/i.test(directPlaceQuery)) return;
    } catch (hostCheckErr) {
        // If any error occurs while determining the hostname, skip checks
        return;
    }
    // Check if we're on a captcha or robot verification page.  Avoid
    // simple substring matches on generic elements like <div> because
    // terms such as "captcha" may appear in unrelated contexts (e.g.,
    // business names).  Instead, look for more specific indicators of
    // a Google CAPTCHA page: the page title containing "Robot" or
    // presence of ReCAPTCHA elements.
    try {
        const hasRobotTitle = $('title:contains("Robot")').length > 0;
        const hasRecaptcha = document.querySelector('iframe[src*="recaptcha"]') || document.querySelector('.g-recaptcha') || document.querySelector('#recaptcha');
        if (hasRobotTitle || hasRecaptcha) {
            console.log("Captcha detected");
            handleScrapingError();
            return;
        }
    } catch (captchaCheckErr) {
        // ignore errors in captcha detection
    }

    
// Detect unusual traffic or bot verification pages.  Google may
// display a message like "Our systems have detected unusual traffic"
// when it suspects automated requests.  However, some normal business
// pages include unrelated words (e.g. reviews or accessibility notes)
// that could match these generic substrings.  To avoid false positives
// we only trigger an error if the page does not appear to contain
// business listings or details (e.g. when no [data-cid] attributes or
// immersive containers are present).  We also look for more complete
// phrases before acting.
try {
    // Check for listings by looking for data‑cid, immersive container or cid
    const hasListings = document.querySelector('[data-cid]') || document.querySelector('.immersive-container') || document.querySelector('a[href*="cid="]');
    const bodyTextLower = (document.body && document.body.innerText || '').toLowerCase();
    const unusualTrafficDetected = bodyTextLower.includes('our systems have detected unusual traffic') ||
                                   bodyTextLower.includes('unusual traffic from your computer network');
    if (!hasListings && unusualTrafficDetected) {
        console.log("Unusual traffic page detected");
        handleScrapingError();
        return;
    }
} catch (err) {
    // ignore errors during unusual traffic detection
}

// Check if we're on a blocked or access denied page.  Similar to the
// unusual traffic check, avoid generic matches on the words "blocked"
// or "denied" which may appear in legitimate business content (e.g.
// "wheelchair access denied" or "blocked alley").  Only act when no
// business content is present and a strong blocking message is found.
try {
    const hasListings = document.querySelector('[data-cid]') || document.querySelector('.immersive-container') || document.querySelector('a[href*="cid="]');
    const bodyTextLower = (document.body && document.body.innerText || '').toLowerCase();
    const blockedPatterns = [
        'access to this page has been blocked',
        'your access has been blocked',
        'access denied',
        'you don’t have permission to access',
        "you don't have permission to access",
        'page blocked due to unusual activity'
    ];
    let blockedDetected = false;
    for (const pattern of blockedPatterns) {
        if (bodyTextLower.includes(pattern)) {
            blockedDetected = true;
            break;
        }
    }
    const urlBlocked = location.href && /blocked|deny/i.test(location.href);
    if (!hasListings && (blockedDetected || urlBlocked)) {
        console.log("Blocked page detected");
        handleScrapingError();
        return;
    }
} catch (err) {
    // ignore errors during blocked page detection
}
        // NEW: Detect human verification or press and hold pages that may not include
        // traditional reCAPTCHA indicators.  When Google requires the user to press
        // and hold or verify they are human, there are typically no business
        // listings on the page.  We scan the page text for characteristic phrases
        // and also look for common reCAPTCHA attributes.  If found and no listings
        // are present, pause scraping.
        try {
            // Consider listings present if we detect a data‑cid attribute, an immersive
            // container or a Maps link containing a cid parameter.  Without this
            // fallback the scraper may falsely identify human verification pages
            // when listings are present but data‑cid is absent.
            const hasListingsHv = document.querySelector('[data-cid]') || document.querySelector('.immersive-container') || document.querySelector('a[href*="cid="]');
            const bodyTextLowerHv = (document.body && document.body.innerText || '').toLowerCase();
            const phrasesHv = [
                'press & hold',
                'press and hold',
                'verify that you are human',
                'verify you are human',
                "i'm not a robot",
                'i am not a robot'
            ];
            let hvDetected = false;
            for (const p of phrasesHv) {
                if (bodyTextLowerHv.includes(p)) {
                    hvDetected = true;
                    break;
                }
            }
            const recaptchaAnchorHv =
                document.querySelector('[aria-label*="not a robot"]') ||
                document.querySelector('[data-sitekey]');
            if (!hasListingsHv && (hvDetected || recaptchaAnchorHv)) {
                console.log('Human verification page detected');
                handleScrapingError();
                return;
            }
        } catch (err) {
            // ignore human verification detection errors
        }
// Check for the "no results" message.  Google uses different
    // elements depending on device and locale; we search the DOM for
    // characteristic phrases rather than specific selectors.  This
    // message usually reads "There are no results here. Try searching in
    // a different location." on English pages.  If found, and we
    // haven't already handled it for the current tab, trigger error
    // handling.
    if (!hasHandledNoResults) {
        // First check the DOM via jQuery selectors for common "no results" messages.
        const noResultsSelectors = [
            'div:contains("There are no results here")',
            'div:contains("There are no results")',
            'div:contains("no results here")',
            'div:contains("Try searching in a different location")',
            'h2:contains("There are no results here")'
        ];
        let foundNoResults = false;
        for (let sel of noResultsSelectors) {
            if ($(sel).length > 0) {
                foundNoResults = true;
                break;
            }
        }
        // If not found by selector, examine the page's text content for the phrase.
        if (!foundNoResults) {
            try {
                const bodyText = document.body && typeof document.body.innerText === 'string' ? document.body.innerText : '';
                const lowerText = bodyText.toLowerCase();
                if (lowerText.includes('there are no results here') || lowerText.includes('no results here') || lowerText.includes('try searching in a different location')) {
                    foundNoResults = true;
                }
            } catch (errCheck) {
                // Ignore errors while reading body text
            }
        }
        if (foundNoResults) {
            console.log("No results message detected");
            hasHandledNoResults = true;
            // Skip the current task gracefully instead of treating it as an error.
            handleNoResults();
            return;
        }
    }
}, 2000);

// NEW: Listen for page navigation events
$(window).on('beforeunload', function() {
    // If we're navigating away from a scraping page, check if we need to handle it
    if (location.href.includes('ref=extension')) {
        console.log("Navigating away from scraping page");
        // This might be due to a captcha redirect or other issue
        setTimeout(() => {
            // Only treat navigation to non‑Google pages as an error when it
            // does not lead to WhatsApp.  Opening WhatsApp for number
            // checks will navigate away from the search page but should
            // not trigger error handling.  Exclude whatsapp domains from
            // the unexpected navigation check.
            const href = location.href || '';
            if (!href.includes('google.com') && !href.includes('ref=extension') && !/whatsapp\.com/.test(href)) {
                console.log("Unexpected navigation detected (" + href + ")");
                handleScrapingError();
            }
        }, 1000);
    }
});

/*-------------------------- On Load ------------------------*/
// Final safety override: old search-result-page collection and Normal/Fast flows
// are intentionally disabled. The only active scrape entry point is
// POCKETLEADS_SCRAPE_PROFILE above, called by the Apify TaskController.
try {
    window.collectCid = function disabledCollectCid() {
        console.log('PocketLeads: old search-result collectCid() is disabled. Use Apify direct dataset flow.');
        return [];
    };
    if (typeof openEachStore === 'function') {
        openEachStore = function disabledOpenEachStore() {
            console.log('PocketLeads: old Normal mode openEachStore() is disabled.');
        };
    }
    if (typeof openEachStoreFast === 'function') {
        openEachStoreFast = function disabledOpenEachStoreFast() {
            console.log('PocketLeads: old Fast mode openEachStoreFast() is disabled.');
        };
    }
} catch (disableOldFlowErr) {
    console.warn('PocketLeads: failed to install old-flow safety override', disableOldFlowErr);
}
