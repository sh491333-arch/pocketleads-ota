if (!(typeof document !== 'undefined' && typeof location !== 'undefined' && /^(chrome|kiwi|edge|brave|opera|moz)-extension:$/i.test(location.protocol) && !window.__plInProcessAndroid)) {
/*
 * PocketLeads Secure Provider Proxy + Durable Pipeline
 * ------------------------------------------------------------
 * Controller flow:
 * query -> provider/API Place IDs or lead rows -> normalize -> persist to
 * IndexedDB -> export through the existing dashboard. Google Place IDs use
 * the Ghost Mode offscreen profile extractor when detail DOM data is needed.
 *
 * No Normal/Fast mode. No visible Google Maps profile tabs in the default path.
 */
(function () {
    const LOG_PREFIX = '[PocketLeads][SmartData]';
    const TERMINAL_STATUSES = ['SUCCEEDED', 'FAILED', 'TIMED-OUT', 'ABORTED'];
    const SERPER_PAGE_SIZE = 20;
    const AUTO_CITY_MAX_PAGES = 50;
    const PINCODE_MAX_PAGES = 3;
    const SERPER_PINCODE_MAX_PAGES = 7;
    const APPS_SCRIPT_URL = PocketLeadsConfig.endpoint;
    const DEFAULT_SETTINGS = {
        provider: 'apify',
        apiToken: '',
        actorId: '',
        sourceId: '',
        secureProxy: true,
        apiKeyRow: 0,
        apifyKeyRow: 0,
        apiUsageLimit: 0,
        apifyUsageLimit: 0,
        autoPageMode: true,
        maxPagesPerSearch: AUTO_CITY_MAX_PAGES,
        maxResultsPerSearch: AUTO_CITY_MAX_PAGES * SERPER_PAGE_SIZE,
        countryFilter: 'India',
        countryCodeFilter: 'IN',
        enforceCountryFilter: true,
        streamResults: true,
        pollIntervalMs: 350,
        streamPollIntervalMs: 350,
        pollTimeoutMs: 15 * 60 * 1000,
        datasetPageSize: 500
    };

    const PLACE_ID_FIELDS = [
        'placeId', 'place_id', 'placeID', 'googlePlaceId', 'googleMapsPlaceId',
        'google_maps_place_id', 'google_place_id', 'inputPlaceId'
    ];

    const FIELD_MAP = {
        company_name: ['company_name', 'companyName', 'name', 'title', 'businessName', 'business_name', 'placeName', 'place_name', 'displayName', 'display_name', 'organizationName', 'organization_name'],
        website: ['website', 'webSite', 'site', 'urlWebsite', 'websiteUrl', 'websiteURL', 'website_link', 'websiteLink', 'webUrl', 'web_url', 'domain', 'displayLink', 'display_link', 'officialWebsite', 'official_website', 'links.website'],
        phone: ['phone', 'phoneNumber', 'phone_number', 'telephone', 'mobile', 'contact', 'phoneNumberUnformatted', 'phoneFormatted', 'phoneUnformatted', 'phone_unformatted', 'internationalPhoneNumber', 'international_phone_number', 'contactPhone', 'contact_number', 'contactNumber', 'businessPhone', 'business_phone', 'primaryPhone', 'primary_phone'],
        address: ['address', 'fullAddress', 'full_address', 'street', 'streetAddress', 'street_address', 'vicinity', 'formattedAddress', 'formatted_address', 'addressLine', 'address_line', 'full_address_line', 'location.address', 'place.address', 'businessAddress', 'business_address'],
        city: ['city', 'municipality', 'locality', 'town', 'district', 'address.city', 'address.locality', 'address.town', 'address.district'],
        state: ['state', 'region', 'province', 'administrativeArea', 'administrative_area', 'address.state', 'address.region', 'address.province', 'address.administrativeArea'],
        pincode: ['pincode', 'pinCode', 'postalCode', 'postal_code', 'postcode', 'postCode', 'zip', 'zipCode', 'address.postalCode', 'address.postcode'],
        total_reviews: ['total_reviews', 'reviewsCount', 'reviews_count', 'reviewCount', 'review_count', 'ratingCount', 'ratingsCount', 'numberOfReviews', 'number_of_reviews', 'user_ratings_total', 'userRatingsTotal', 'reviews'],
        review: ['review', 'rating', 'stars', 'totalScore', 'total_score', 'score', 'ratingValue', 'rating_value', 'averageRating', 'average_rating'],
        cid: ['cid', 'placeId', 'place_id', 'placeID', 'googlePlaceId', 'googleMapsPlaceId'],
        map_link: ['map_link', 'mapLink', 'googleMapsUrl', 'googleMapsURL', 'mapsUrl', 'mapsURL', 'googleMapsLink', 'locationUrl', 'placeUrl', 'directionsUrl', 'url', 'link'],
        status: ['status', 'businessStatus', 'business_status', 'temporarilyClosed', 'permanentlyClosed', 'isClosed'],
        category: ['category', 'categoryName', 'mainCategory', 'main_category', 'type'],
        categories: ['categories', 'additionalCategories'],
        latitude: ['latitude', 'lat'],
        longitude: ['longitude', 'lng', 'lon'],
        plus_code: ['plusCode', 'plus_code'],
        price: ['price', 'priceLevel', 'price_level'],
        opening_hours: ['openingHours', 'opening_hours', 'hours', 'popularTimesLiveText'],
        photo_url: ['photo_url', 'photoUrl', 'thumbnail', 'thumbnailUrl', 'imageUrl', 'image_url', 'photo', 'image', 'mainPhoto', 'featured_image'],
        photo_url_large: ['photo_url_large', 'photoUrlLarge', 'large_photo_url', 'originalPhotoUrl'],
        photo_urls: ['photo_urls', 'photoUrls', 'imageUrls', 'image_urls'],
        email_1: ['email_1', 'email', 'email1', 'emailAddress', 'email_address', 'contactEmail', 'contact_email', 'businessEmail', 'business_email', 'mail', 'mailAddress', 'mail_address']
    };

    const COUNTRY_NAME_TO_CODE = {
        india: 'IN', bharat: 'IN',
        'united states': 'US', 'united states of america': 'US', usa: 'US', us: 'US', america: 'US',
        'united kingdom': 'GB', uk: 'GB', 'great britain': 'GB', england: 'GB',
        bangladesh: 'BD', pakistan: 'PK', nepal: 'NP', 'sri lanka': 'LK', bhutan: 'BT', maldives: 'MV',
        'united arab emirates': 'AE', uae: 'AE', dubai: 'AE',
        canada: 'CA', australia: 'AU', singapore: 'SG', malaysia: 'MY', thailand: 'TH', indonesia: 'ID', philippines: 'PH',
        germany: 'DE', france: 'FR', italy: 'IT', spain: 'ES', netherlands: 'NL', belgium: 'BE', switzerland: 'CH',
        brazil: 'BR', mexico: 'MX', 'south africa': 'ZA', 'saudi arabia': 'SA', qatar: 'QA', oman: 'OM', kuwait: 'KW'
    };

    const INDIA_POSITIVE_SIGNALS = [
        'india', 'bharat', 'west bengal', 'kolkata', 'calcutta', 'delhi', 'new delhi', 'mumbai', 'maharashtra',
        'bengaluru', 'bangalore', 'karnataka', 'chennai', 'tamil nadu', 'hyderabad', 'telangana', 'pune',
        'ahmedabad', 'gujarat', 'jaipur', 'rajasthan', 'lucknow', 'uttar pradesh', 'patna', 'bihar',
        'bhubaneswar', 'odisha', 'assam', 'kerala', 'punjab', 'haryana', 'jharkhand', 'chhattisgarh'
    ];

    const INDIA_NEGATIVE_SIGNALS = [
        'united states', 'usa', 'u.s.a', 'america', 'canada', 'united kingdom', 'uk', 'australia',
        'new york', 'california', 'texas', 'florida', 'london', 'singapore', 'dubai', 'uae'
    ];

    const DEBUG_LOGS = false;
    function log(...args) {
        if (!DEBUG_LOGS) return;
        try { console.debug(LOG_PREFIX, ...args); } catch (e) {}
    }

    function warn(...args) {
        try { console.warn(LOG_PREFIX, ...args); } catch (e) {}
    }

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    const NO_PROVIDER_MESSAGE = 'Service temporarily unavailable. Please try again later.';
    const SUPPORT_EMAIL = PocketLeadsConfig.supportEmail;

    function apiKeyRowOf(settings) {
        return Math.max(0, parseInt(settings && (settings.apiKeyRow || settings.apifyKeyRow), 10) || 0);
    }

    function backendProviderDiagnosticMessage(data) {
        const base = String(data && data.message || NO_PROVIDER_MESSAGE).trim();
        const d = data && data.diagnostics;
        if (!d || typeof d !== 'object') return base;
        const rejected = d.rejected || {};
        const details = [];
        if (rejected.noKey) details.push(`${rejected.noKey} row(s) missing API key`);
        if (rejected.inactive) details.push(`${rejected.inactive} inactive row(s)`);
        if (rejected.limitReached) details.push(`${rejected.limitReached} row(s) at explicit usage limit`);
        if (rejected.sourceMissing) details.push(`${rejected.sourceMissing} Apify row(s) missing Source/Actor ID`);
        if (rejected.unsupportedProvider) details.push(`${rejected.unsupportedProvider} unsupported provider row(s)`);
        if (rejected.providerMismatch) details.push(`${rejected.providerMismatch} other-provider row(s)`);
        const sheet = String(data && data.apiSheetName || '').trim();
        return base + (sheet ? ` Sheet: ${sheet}.` : '') + (details.length ? ` Check: ${details.join(', ')}.` : '');
    }


    function canonicalProviderKey(value) {
        const raw = String(value || '').trim().toLowerCase().replace(/[\s_.-]+/g, '');
        if (!raw) return '';
        if (['scrappa','scrappaco','scrappaapi'].includes(raw)) return 'scrappa';
        if (['serper','serperdev','googleserper'].includes(raw)) return 'serper';
        if (['numberchecker','numbercheckerai','numbercheckerapi','checknumber','checknumberai','nc','ncapi','ncwa','ncwhatsapp','numbercheckerwa','numbercheckerwhatsapp'].includes(raw)) return 'numberchecker';
        if (['apifywpapi','apifywaapi','apifywhatsappapi','apifywhatsapp','whatsappapi','waapi','wpapi'].includes(raw)) return 'apifywpapi';
        if (['apify','apifyactor'].includes(raw)) return 'apify';
        if (['googlemaps','googleplaces','places','googlemap','gmaps','placesapi'].includes(raw)) return 'googlemaps';
        if (/scrappa/.test(raw)) return 'scrappa';
        if (/serper/.test(raw)) return 'serper';
        if (/numberchecker|checknumber/.test(raw)) return 'numberchecker';
        if (/apify.*(?:wp|wa|whatsapp)/.test(raw)) return 'apifywpapi';
        if (/apify/.test(raw)) return 'apify';
        if (/google.*map|placeid|google.*place/.test(raw)) return 'googlemaps';
        return '';
    }

    function providerDisplayName(provider) {
        const key = canonicalProviderKey(provider);
        if (key === 'scrappa') return 'Scrappa';
        if (key === 'serper') return 'Serper';
        if (key === 'numberchecker') return 'NumberChecker.AI';
        if (key === 'apifywpapi') return 'Apify WP API';
        if (key === 'apify') return 'Apify';
        if (key === 'googlemaps') return 'Google Maps';
        return String(provider || '').trim();
    }

    function inferProviderFromSource(value) {
        const text = String(value || '').trim().toLowerCase();
        if (!text) return '';
        if (text.includes('scrappa')) return 'scrappa';
        if (text.includes('serper')) return 'serper';
        if (text.includes('apify')) return 'apify';
        if (text.includes('google_maps') || text.includes('google maps') || text.includes('place_id_profile')) return 'googlemaps';
        return canonicalProviderKey(text);
    }

    function applyProviderProvenance(row, item, meta, settings, detail) {
        if (!row || typeof row !== 'object') return row;
        const provider = canonicalProviderKey(
            (settings && settings.provider) ||
            (meta && meta.provider) ||
            (item && (item._provider || item.provider)) ||
            row._provider ||
            inferProviderFromSource((item && item.source) || row.source || detail)
        );
        const sourceDetail = String(detail || (item && (item._source_detail || item.source)) || row._source_detail || row.source || '').trim();
        if (provider) {
            row._provider = provider;
            row.source = providerDisplayName(provider);
        } else if (row.source) {
            row.source = providerDisplayName(inferProviderFromSource(row.source)) || row.source;
        }
        if (sourceDetail) row._source_detail = sourceDetail;
        return row;
    }

    function errorText(error) {
        if (!error) return '';
        const parts = [];
        if (error.status) parts.push(String(error.status));
        if (error.message) parts.push(String(error.message));
        try {
            if (error.payload) parts.push(JSON.stringify(error.payload));
        } catch (e) {}
        return parts.join(' ').trim();
    }

    function failureKind(error) {
        const code = String(error && (error.code || error.providerReason) || '').toUpperCase();
        const status = Number(error && error.status) || 0;
        if (/LICENSE_|LICENCE_|ALL_CREDITS_EXHAUSTED/.test(code)) return 'customer';
        if (/REQUEST_PENDING|REQUEST_UNCERTAIN|REQUEST_CONFLICT/.test(code)) return 'uncertain';
        if (status === 429) return 'rate';
        if (status === 402 || /PROVIDER_QUOTA/.test(code)) return 'quota';
        if ([401,403].includes(status) || /PROVIDER_AUTH/.test(code)) return 'config';
        if (/PROVIDER_/.test(code) || [404,408,409,422,500,502,503,504].includes(status)) return 'provider';
        return 'other';
    }
    function isApiCreditLimitError(error) { return failureKind(error) === 'quota'; }
    function isApiKeyConfigError(error) { return failureKind(error) === 'config'; }
    function isApiRotationError(error) { return ['rate','quota','config','provider'].includes(failureKind(error)); }
    function isProviderExecutionFailoverError(error) {
        if (['customer','uncertain'].includes(failureKind(error))) return false;
        return isApiRotationError(error) || /actor.*(?:failed|aborted)|run.*(?:failed|aborted)|dataset.*(?:failed|unavailable|not found)|invalid.*response|malformed.*response/i.test(errorText(error));
    }
    function isCommercialStopError(error) { if (/^(RESULT_STORE_UNAVAILABLE|PROVIDER_BUSY|BILLING_CONFIG_ERROR|BACKEND_UNAVAILABLE|BACKEND_UPDATE_REQUIRED|ROUTE_CHANGED)$/.test(String(error && error.code || ''))) return true; return failureKind(error) === 'customer' || failureKind(error) === 'uncertain'; }
    function isLicenceCreditError(error) {
        return /^(LICENSE_CREDIT_EXHAUSTED|ALL_CREDITS_EXHAUSTED|LICENCE_CREDIT_EXHAUSTED)$/.test(String(error && error.code || ''));
    }
    function isProviderAvailabilityStopError(error) {
        return /^(NO_ELIGIBLE_PROVIDER|PROVIDER_FAILOVER_EXHAUSTED)$/.test(String(error && error.code || ''));
    }

    function nowIso() {
        return new Date().toISOString();
    }

        const GOOGLE_API_LIVE_EVENT_ACTION = 'pl_google_api_live_event';
    const GOOGLE_API_LIVE_TOGGLE_ACTION = 'pl_set_google_live_debug';
    let googleApiLiveDebugEnabled = false;

    try {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage && !self.__plGoogleLiveToggleListenerAdded) {
            self.__plGoogleLiveToggleListenerAdded = true;
            chrome.runtime.onMessage.addListener(function(msg) {
                try {
                    if (msg && msg.action === GOOGLE_API_LIVE_TOGGLE_ACTION) {
                        googleApiLiveDebugEnabled = !!msg.enabled;
                    }
                } catch (e) {}
            });
        }
    } catch (e) {}

    function emitGoogleApiLiveEvent(payload) {
        try {
            // Developer debug only.  When the Live API popup is not open, do not
            // spam runtime messages or chrome.storage; this keeps scraping smooth.
            if (!googleApiLiveDebugEnabled) return;
            const event = Object.assign({
                provider: 'googlemaps',
                at: nowIso()
            }, payload || {});
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                try {
                    chrome.runtime.sendMessage({ action: GOOGLE_API_LIVE_EVENT_ACTION, payload: event }, function() {
                        try { void chrome.runtime.lastError; } catch (e) {}
                    });
                } catch (e) {}
            }
        } catch (e) {}
    }

    function elapsedMsFrom(startedAt, finishedAt) {
        const start = Date.parse(startedAt || '');
        const end = Date.parse(finishedAt || '') || Date.now();
        if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) return 0;
        return end - start;
    }

    let _lastKnownRunningState = false;
    let _lastKnownRunningAt = 0;
    function _updateRunningCacheFromLocal(local) {
        try {
            const manager = local && local._taskManager && typeof local._taskManager === 'object' ? local._taskManager : {};
            _lastKnownRunningState = !!(local && local.status === true && manager.isWorking === true);
            _lastKnownRunningAt = Date.now();
        } catch (_) {}
    }

    function getLocalAsync() {
        return new Promise(resolve => {
            try {
                $box.getLocal(local => {
                    const out = local || {};
                    _updateRunningCacheFromLocal(out);
                    resolve(out);
                });
            } catch (err) {
                warn('getLocal failed', err);
                resolve({});
            }
        });
    }

    function setLocalAsync(local) {
        PocketLeadsRunState.apply(local);
        _updateRunningCacheFromLocal(local);
        return new Promise(resolve => {
            try {
                $box.setLocal(local, { onSet: resolve });
            } catch (err) {
                warn('setLocal failed', err);
                resolve();
            }
        });
    }


    function getStoredLicenceAsync() {
        return new Promise(resolve => {
            try {
                if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return resolve(null);
                chrome.storage.local.get('license', res => resolve(res && res.license ? res.license : null));
            } catch (err) {
                warn('Unable to read stored licence', err);
                resolve(null);
            }
        });
    }

    function installationIdFromLicence(licence) {
        const id = String(licence && licence.installationId || '').trim();
        if (!id) {
            const err = new Error('PocketLeads secure device binding requires one-time licence reactivation on this device. Logout/login the licence once, then retry.');
            err.code = 'DEVICE_REACTIVATION_REQUIRED';
            throw err;
        }
        return id;
    }

    function setStoredLicenceAsync(licence) {
        return new Promise(resolve => {
            try {
                chrome.storage.local.set({ license: licence }, () => resolve(!(chrome.runtime && chrome.runtime.lastError)));
            } catch (err) { resolve(false); }
        });
    }

    async function getOrCreateInstallationIdAsync() {
        try {
            if (typeof PocketLeadsDeviceIdentity === 'undefined' || !PocketLeadsDeviceIdentity || typeof PocketLeadsDeviceIdentity.get !== 'function') return '';
            const identity = await PocketLeadsDeviceIdentity.get();
            return String(identity && identity.id || '').trim();
        } catch (err) { return ''; }
    }


    async function fetchLegacyPublicIpSafe() {
        try {
            const resp = await fetch('https://api.ipify.org?format=json', { cache: 'no-store' });
            const data = await resp.json();
            return String(data && data.ip || '').trim();
        } catch (err) { return ''; }
    }

    async function ensureLicenceInstallationAsync(licence) {
        if (!licence || !licence.key) return licence;
        const previousDeviceId = String(licence.installationId || '').trim();
        const installationId = await getOrCreateInstallationIdAsync();
        if (!installationId) throw new Error('Unable to create device identity. Reload the extension and try again.');
        if (previousDeviceId === installationId && Number(licence.identityVersion || 0) >= 2) return licence;
        const ping = await callAppsScript('ping', {}, { attempts: 1, timeoutMs: 8000 });
        if (!ping || ping.status !== 'ok' || ping.physicalDeviceLicensing !== true) {
            const err = new Error('Apps Script backend is outdated. Deploy the included apps_script_code.js v30 before using this build.');
            err.code = 'BACKEND_UPDATE_REQUIRED';
            throw err;
        }
        const legacyIp = (!previousDeviceId || !/^dev[23]-/i.test(previousDeviceId)) ? await fetchLegacyPublicIpSafe() : '';
        const response = await callAppsScript('activate', {
            key: String(licence.key).trim(),
            deviceId: installationId,
            installationId,
            legacyDeviceId: previousDeviceId,
            // Keep ip populated for a graceful old-backend diagnostic path.
            ip: installationId,
            legacyIp
        }, { attempts: 2, timeoutMs: 12000 });
        if (!response || response.status !== 'ok') {
            const reason = String(response && response.reason || 'activation_failed');
            const expired = response && response.status === 'expired';
            const err = new Error(expired
                ? `Your licence expired${response.expiryDate ? ' on ' + response.expiryDate : ''}. Contact ${response.supportEmail || SUPPORT_EMAIL} to renew.`
                : (reason === 'licence_not_found'
                    ? 'Licence key was not found by the deployed Apps Script. Check the licence sheet and deployment URL.'
                    : (/missing_key_or_ip|unknown_action/i.test(reason)
                        ? 'Apps Script backend is outdated. Deploy the included apps_script_code.js v30.'
                        : ('Installation migration failed: ' + reason))));
            err.code = expired ? 'LICENSE_EXPIRED' : 'DEVICE_REACTIVATION_REQUIRED';
            throw err;
        }
        const updated = Object.assign({}, licence, {
            active: true,
            installationId,
            identityVersion: 2,
            devices: response.count != null ? response.count : (licence.devices || 1),
            expiryDate: response.expiryDate || licence.expiryDate || '',
            googleMapsCredit: response.googleMapsCredit != null ? response.googleMapsCredit : licence.googleMapsCredit,
            structuredCredit: response.structuredCredit != null ? response.structuredCredit : licence.structuredCredit,
            supportEmail: response.supportEmail || SUPPORT_EMAIL
        });
        await setStoredLicenceAsync(updated);
        return updated;
    }

    function getBackendCacheStorageArea() {
        try {
            // v87: backend routing cache contains NO provider credentials. Persist
            // the last verified provider/key-row metadata across browser restarts so
            // "Checking licence and selecting data source" can start immediately.
            // Every real providerProxy request still re-validates licence, device,
            // credits and API-row availability server-side before spending credits.
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) return chrome.storage.local;
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.session) return chrome.storage.session;
        } catch (e) {}
        return null;
    }

    function chromeStorageGetAsync(key) {
        return new Promise(resolve => {
            try {
                const area = getBackendCacheStorageArea();
                if (!area) return resolve({});
                area.get(key, result => resolve(result || {}));
            } catch (err) { resolve({}); }
        });
    }

    function chromeStorageSetAsync(value) {
        return new Promise(resolve => {
            try {
                const area = getBackendCacheStorageArea();
                if (!area) return resolve(false);
                area.set(value, () => resolve(!(chrome.runtime && chrome.runtime.lastError)));
            } catch (err) { resolve(false); }
        });
    }

    async function callAppsScript(action, payload, options) {
        const body = Object.assign({ action }, payload || {});
        const isFastRamProxy = !!(body && body.fastRamProxy);
        const maxAttempts = (/^providerproxy$/i.test(action) && !isFastRamProxy)
            ? 2
            : Math.max(2, Math.min(4, parseInt(options && options.attempts, 10) || 3));
        const timeoutMs = Math.max(5000, Math.min(120000, parseInt(options && options.timeoutMs, 10) || 25000));
        const bodyJson = JSON.stringify(body);
        // Attach key/action/deviceId (and _pl_body when compact) to URL query string so if Google Apps Script 302 redirect ever converts POST->GET, parameters are preserved!
        let requestUrl = APPS_SCRIPT_URL;
        try {
            const u = new URL(APPS_SCRIPT_URL);
            if (body.action) u.searchParams.set('action', String(body.action));
            if (body.key) u.searchParams.set('key', String(body.key));
            if (body.deviceId) u.searchParams.set('deviceId', String(body.deviceId));
            if (bodyJson.length <= 1800) {
                u.searchParams.set('_pl_body', bodyJson);
            }
            requestUrl = u.toString();
        } catch (_) {}
        let lastError = null;
        for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
            const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
            const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
            try {
                const response = await fetch(requestUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                    body: bodyJson,
                    cache: 'no-store',
                    signal: controller ? controller.signal : undefined
                });
                let data = null;
                try { data = await response.json(); } catch (e) { data = null; }
                if (!response.ok || !data) {
                    const err = new Error('Backend error while calling ' + action + ' (HTTP ' + response.status + ')');
                    err.status = response.status;
                    throw err;
                }
                // Detect Google 302 redirect POST-body drop (returns missing_licence_key even though body.key was provided)
                if (body.key && data && /^(missing_licence_key|missing_key_or_device|missing_device_id)$/i.test(String(data.reason || ''))) {
                    const redirErr = new Error('Transient redirect dropped POST body (' + data.reason + ')');
                    redirErr.status = 503;
                    throw redirErr;
                }
                await PocketLeadsAccount.observe(data, body.key, body.deviceId);
                return data;
            } catch (err) {
                lastError = err;
                const msg = String(err && err.message || err || '');
                const retryable = /abort|timeout|timed out|network|fetch failed|load failed|temporar|redirect dropped|missing_licence_key|backend error|HTTP 5\d\d/i.test(msg) || [429, 500, 502, 503, 504].includes(parseInt(err && err.status, 10) || 0);
                if (!retryable || attempt >= maxAttempts) break;
                await sleep(Math.min(4000, 600 * Math.pow(2, attempt - 1)) + Math.floor(Math.random() * 250));
            } finally {
                if (timer) clearTimeout(timer);
            }
        }
        throw lastError || new Error('Backend error while calling ' + action);
    }

    const providerRequestLanes = new Map();
    function providerProxyRequest(provider, operation, payload, settings, options) {
        const laneKey = (settings && settings.attemptId) ? (String(provider || '') + ':' + String(settings.attemptId)) : provider;
        const prior = providerRequestLanes.get(laneKey) || Promise.resolve();
        const result = prior.then(() => executeProviderProxyRequest(provider,operation,payload,settings,options));
        providerRequestLanes.set(laneKey, result.catch(() => {}));
        return result;
    }
    async function executeProviderProxyRequest(provider, operation, payload, settings, options) {
        const licence = await ensureLicenceInstallationAsync(await getStoredLicenceAsync());
        const key = licence && licence.key ? String(licence.key).trim() : '';
        if (!key) throw new Error('Please activate your licence first.');
        const deviceId = installationIdFromLicence(licence);
        if (settings && settings.managedRouting && typeof DailyController !== 'undefined' && DailyController && DailyController._activeSettingsKeyRow) {
            settings.apiKeyRow = DailyController._activeSettingsKeyRow;
            settings.apifyKeyRow = DailyController._activeSettingsKeyRow;
        }
        let keyRow = Math.max(0, parseInt(settings && (settings.apiKeyRow || settings.apifyKeyRow), 10) || 0);
        if (!keyRow) throw new Error('Secure provider proxy has no active API row. Refresh provider configuration.');
        const state = await chromeStorageGetAsync('apifyQueue');
        const preCallAvail = Number(state && ((state.pocketleadsAccount && state.pocketleadsAccount.availableCredit) ?? (state.license && state.license.availableCredit)));
        const runId = settings.requestRunId || (state.apifyQueue && state.apifyQueue.runEventId) || 'auxiliary';
        const paid = !/^(getRun|getInputSchema|getKeyValueOutput)$/.test(operation);
        const pendingKey = 'plPendingProviderRequest';
        let legacy = (await chromeStorageGetAsync(pendingKey)).plPendingProviderRequest;
        let request = paid ? await PocketLeadsRequests.prepare({key,runId,provider,keyRow,operation,payload:payload||{},legacy,attemptId:settings.attemptId||''}) : null;
        let requestId = request ? request.requestId : '';
        if(request) { payload = request.payload; keyRow = request.keyRow; }
        if(requestId) await chromeStorageSetAsync({[pendingKey]:{key,requestId,runId,provider,keyRow,operation,payload,jobId:request.jobId,attemptId:settings.attemptId||'',managedRouting:!!settings.managedRouting}});
        let data;
        const initialAttemptId = settings && settings.attemptId || '';
        const triedKeySignatures = new Set();
        let replayedErrorRetried = false;
        const maxKeyFailovers = (settings && settings.managedRouting) ? 5 : 1;
        for (let keyTry = 0; keyTry < maxKeyFailovers; keyTry++) {
            try {
                for (let busyRetry = 0; busyRetry < 4; busyRetry++) {
                    const callStartedAt = Date.now();
                    data = await callAppsScript('providerProxy', {
                        requestId, runId, attemptId: settings.attemptId || '',
                        autoBegin: !!settings.managedRouting,
                        fastRamProxy: !!settings.managedRouting,
                        autoRotateKey: !!settings.managedRouting,
                        key,
                        deviceId,
                        provider: canonicalProviderKey(provider) || String(provider || ''),
                        keyRow,
                        operation: String(operation || ''),
                        payload: payload || {}
                    }, { attempts: Math.max(1, Math.min(3, parseInt(options && options.attempts, 10) || 2)), timeoutMs: Math.max(settings.managedRouting ? 65000 : 8000, Math.min(120000, parseInt(options && options.timeoutMs, 10) || 30000)) });
                    const callElapsed = Math.max(50, Date.now() - callStartedAt);
                    try {
                        if (typeof DailyController !== 'undefined' && DailyController) {
                            DailyController._avgProxyLatencyMs = DailyController._avgProxyLatencyMs
                                ? Math.round(DailyController._avgProxyLatencyMs * 0.7 + callElapsed * 0.3)
                                : callElapsed;
                        }
                    } catch (_) {}
                    const isBusyOrLock = data && (
                        data.status === 'busy' ||
                        data.errorCode === 'PROVIDER_BUSY' ||
                        /^(missing_licence_key|missing_key_or_device|missing_device_id)$/i.test(String(data.reason || '')) ||
                        (data.status === 'configuration_error' && /lock|timeout|waitlock|busy/i.test(String(data.message || '')))
                    );
                    if (isBusyOrLock) {
                        try { if (typeof DailyController !== 'undefined' && DailyController) DailyController._lastProxyBusyAt = Date.now(); } catch (_) {}
                    }
                    if (!isBusyOrLock || busyRetry >= 3) break;
                    await new Promise(r => typeof setTimeout === 'function' ? setTimeout(r, 850 * (busyRetry + 1)) : r());
                }
            } catch (transportError) {
                if (!requestId) throw transportError;
                try { data = await callAppsScript('providerRequestStatus', {key,deviceId,requestId}, {attempts:1,timeoutMs:10000}); }
                catch (_) { data = null; }
                const isLiveManagedRun = !!(settings && settings.managedRouting && typeof DailyController !== 'undefined' && DailyController && DailyController.running);
                if (!data || /^(request_missing|request_pending)$/.test(data.status)) {
                    if (isLiveManagedRun && (!data || data.status === 'request_missing')) {
                        const netErr = new Error('Temporary network/screen-lock interruption during provider request. Retrying automatically.');
                        netErr.code = 'PROVIDER_NETWORK_TIMEOUT';
                        throw netErr;
                    }
                    const err = new Error('Request confirmation is pending. Progress is saved; Resume will check the same request without submitting a duplicate charge.');
                    err.code = 'REQUEST_UNCERTAIN'; throw err;
                }
            }

            if (data && data.replayed && data.status !== 'ok' && !replayedErrorRetried && paid) {
                replayedErrorRetried = true;
                request = await PocketLeadsRequests.prepare({key,runId,provider,keyRow,operation,payload:payload||{},attemptId:settings.attemptId||'',forceNew:true});
                requestId = request ? request.requestId : '';
                if (requestId) {
                    await chromeStorageSetAsync({[pendingKey]:{key,requestId,runId,provider,keyRow,operation,payload,jobId:request.jobId,attemptId:settings.attemptId||'',managedRouting:!!settings.managedRouting}});
                }
                keyTry -= 1;
                continue;
            }
            if (data && !data.reservationPending && !/^(request_pending|request_uncertain|request_conflict)$/.test(data.status) && requestId) {
                await PocketLeadsRequests.settle(request, { failed: data.status !== 'ok' });
                await chromeStorageSetAsync({[pendingKey]:null});
            }
            if (data && data.status === 'ok') {
                const okRow = parseInt(data.keyRow, 10) || keyRow;
                if (okRow && settings && settings.managedRouting) {
                    settings.apiKeyRow = okRow;
                    settings.apifyKeyRow = okRow;
                    try { if (typeof DailyController !== 'undefined' && DailyController) DailyController._activeSettingsKeyRow = okRow; } catch (_) {}
                }
                break;
            }
            // If user has 1-5 keys assigned for this provider and the current key failed (auth/quota/rate_limit/503), rotate to the next assigned key
            const isRotatableKeyFailure = !!(settings && settings.managedRouting && keyTry + 1 < maxKeyFailovers && data && (
                data.status === 'provider_error' ||
                /^(PROVIDER_AUTH|PROVIDER_QUOTA|PROVIDER_RATE_LIMIT|PROVIDER_UNAVAILABLE|PROVIDER_BUDGET|PROVIDER_ERROR|PROVIDER_EXECUTION)$/i.test(String(data.errorCode || ''))
            ));
            if (!isRotatableKeyFailure) break;
            try {
                const failedRow = parseInt(data && data.keyRow, 10) || keyRow;
                const failedApiId = String(data && data.apiId || '').trim();
                triedKeySignatures.add(String(failedRow) + ':' + failedApiId);
                if (failedApiId) triedKeySignatures.add('id:' + failedApiId);
                triedKeySignatures.add('row:' + String(failedRow));
                const seedText = runId + '|krot_' + (keyTry + 1) + '|' + (typeof Date !== 'undefined' ? Date.now() : 0) + '|' + Math.random().toString(36).slice(2, 7) + '|' + JSON.stringify(payload && payload.query || operation || '');
                const seedBytes = new TextEncoder().encode(seedText);
                const nextAttemptId = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', seedBytes)), b => b.toString(16).padStart(2, '0')).join('');
                const nextRoute = await callAppsScript('beginExtraction', {
                    key,
                    deviceId,
                    attemptId: nextAttemptId,
                    resetExhaustedAttempt: true,
                    preferNextKey: true,
                    failedApiId,
                    failedKeyRow: failedRow
                }, { attempts: 2, timeoutMs: 20000 });
                if (!nextRoute || nextRoute.status !== 'ok') {
                    break;
                }
                if (canonicalProviderKey(nextRoute.provider) !== canonicalProviderKey(provider)) {
                    if (data && typeof data === 'object') data.nextRoute = nextRoute;
                    break;
                }
                const nextRow = parseInt(nextRoute.keyRow, 10) || keyRow;
                const nextApiId = String(nextRoute.apiId || '').trim();
                const alreadyTriedSameKey = (nextApiId && triedKeySignatures.has('id:' + nextApiId)) ||
                    triedKeySignatures.has(String(nextRow) + ':' + nextApiId) ||
                    (nextRow === failedRow && (!failedApiId || !nextApiId || nextApiId === failedApiId));
                if (alreadyTriedSameKey && /^(PROVIDER_AUTH|PROVIDER_QUOTA|PROVIDER_RATE_LIMIT)$/i.test(String(data.errorCode || ''))) {
                    break;
                }
                keyRow = nextRow;
                settings.attemptId = nextAttemptId;
                settings.apiKeyRow = keyRow;
                settings.apifyKeyRow = keyRow;
                try {
                    if (typeof DailyController !== 'undefined' && DailyController) {
                        DailyController._activeSettingsKeyRow = keyRow;
                        if (typeof DailyController.emitDiagnosticSpy === 'function') {
                            DailyController.emitDiagnosticSpy('KEY_ROTATE', {
                                level: 'warn',
                                provider: String(provider || ''),
                                errorCode: data.errorCode || 'KEY_SWITCH',
                                message: `API key ${failedApiId || ('Row ' + failedRow)} failed (${data.errorCode || data.status}) -> auto-switched to next assigned key ${nextRoute.apiId || ('Row ' + keyRow)} (key ${keyTry + 2}/5)`
                            });
                        }
                    }
                } catch (_) {}
                request = paid ? await PocketLeadsRequests.prepare({key,runId,provider,keyRow,operation,payload:payload||{},attemptId:nextAttemptId}) : null;
                requestId = request ? request.requestId : '';
                if (requestId) {
                    await chromeStorageSetAsync({[pendingKey]:{key,requestId,runId,provider,keyRow,operation,payload,jobId:request.jobId,attemptId:nextAttemptId,managedRouting:true}});
                }
            } catch (_) {
                break;
            }
        }
        if (!data || data.status !== 'ok') {
            if (initialAttemptId && settings && settings.managedRouting) {
                settings.attemptId = initialAttemptId;
            }
            const baseMsg = (data && (data.message || data.reason)) || 'Secure provider proxy request failed.';
            const diagSuffix = (data && (data.apiId || data.httpStatus || data.keyRow))
                ? ` [API ID: ${data.apiId || '?'}, Row: ${data.keyRow || keyRow || '?'}, HTTP: ${data.httpStatus || '?'}]`
                : '';
            const errCodeUpper = String((data && (data.errorCode || data.reason || data.status)) || 'EXTRACTION_ERROR').toUpperCase();
            const isNormalZeroCredit = /^(CREDITS_EXHAUSTED|LICENSE_CREDIT_EXHAUSTED|LICENCE_CREDIT_EXHAUSTED|ALL_CREDITS_EXHAUSTED|MISSING_LICENCE_KEY|MISSING_KEY_OR_DEVICE|MISSING_DEVICE_ID|ROUTE_CHANGED|REQUEST_PENDING)$/i.test(errCodeUpper);
            if (!isNormalZeroCredit && paid) {
                try {
                    const upRaw = (data && data.data && typeof data.data === 'object') ? data.data : null;
                    const upstreamError = String(
                        (data && data.upstreamError) ||
                        (upRaw && ((upRaw.error && (upRaw.error.message || upRaw.error.description || (typeof upRaw.error === 'string' ? upRaw.error : ''))) || upRaw.message)) ||
                        baseMsg
                    ).trim();
                    const upstreamCode = String(
                        (data && data.upstreamCode) ||
                        (upRaw && (upRaw.code || (upRaw.error && upRaw.error.code))) ||
                        ''
                    ).trim();
                    const queryVal = String(
                        (payload && (payload.query || (payload.body && (payload.body.q || payload.body.textQuery || payload.body.query)))) || ''
                    ).trim();
                    const nowMs = (typeof Date !== 'undefined' && typeof Date.now === 'function') ? Date.now() : 0;
                    const alertPayload = {
                        id: 'ERR-' + String((data && data.apiId) || ('R' + (data && data.keyRow || keyRow || 0))) + '-' + String((data && data.httpStatus) || 'ERR') + '-' + String(nowMs).slice(-5),
                        timestamp: nowMs,
                        timeText: (typeof Date !== 'undefined') ? new Date().toLocaleString() : '',
                        licenceKey: key,
                        apiId: String((data && data.apiId) || ('ROW-' + (data && data.keyRow || keyRow || '?'))),
                        keyRow: parseInt(data && data.keyRow, 10) || keyRow || 0,
                        provider: String(provider || 'scrappa'),
                        httpStatus: parseInt(data && data.httpStatus, 10) || 0,
                        errorCode: String((data && data.errorCode) || (data && data.status) || 'PROVIDER_ERROR'),
                        upstreamCode: upstreamCode,
                        upstreamError: upstreamError,
                        query: queryVal
                    };
                    await chromeStorageSetAsync({ plServerDownAlert: alertPayload });
                    try {
                        if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
                            chrome.runtime.sendMessage({ type: 'pl_server_down_alert', alert: alertPayload }, () => {
                                try { void (chrome.runtime && chrome.runtime.lastError); } catch (_) {}
                            });
                        }
                    } catch (_) {}
                    if (!data.serverLoggedError) {
                        void (async () => {
                            try {
                                const logRes = await callAppsScript('logApiError', Object.assign({ key, deviceId }, alertPayload), { attempts: 1, timeoutMs: 12000 }).catch(() => null);
                                if (!logRes || logRes.reason === 'unknown_action' || logRes.status === 'error') {
                                    const dedupId = 'auto-api-err-' + key + '-' + alertPayload.apiId + '-' + alertPayload.httpStatus;
                                    await callAppsScript('submitTicket', {
                                        key,
                                        deviceId,
                                        subject: `[AUTO API ERROR] ${alertPayload.apiId} (Row ${alertPayload.keyRow}, HTTP ${alertPayload.httpStatus || '?'}) - Licence ${key}`.slice(0, 118),
                                        message: `AUTOMATIC BACKEND API ERROR REPORT
Licence Key: ${key}
API ID: ${alertPayload.apiId} (Row ${alertPayload.keyRow})
Provider: ${alertPayload.provider}
HTTP Status: ${alertPayload.httpStatus || 'N/A'}
Error Code: ${alertPayload.errorCode}${alertPayload.upstreamCode ? ' (' + alertPayload.upstreamCode + ')' : ''}
Query: ${alertPayload.query || 'N/A'}
API Error Message: ${alertPayload.upstreamError || baseMsg}`.slice(0, 1950),
                                        requestId: dedupId
                                    }, { attempts: 1, timeoutMs: 12000 }).catch(() => null);
                                }
                            } catch (_) {}
                        })();
                    }
                } catch (_) {}
            }
            const err = new Error(baseMsg + diagSuffix);
            err.status = parseInt(data && data.httpStatus, 10) || 0;
            err.payload = data && (data.data || data.diagnostics || null);
            err.retryAfter = data && data.retryAfter;
            err.providerStatus = data && data.status;
            err.providerReason = data && data.reason;
            err.keyRow = parseInt(data && data.keyRow, 10) || keyRow;
            err.nextRoute = data && data.nextRoute || null;
            err.code = data && data.errorCode || (data && data.status === 'provider_error' ? 'PROVIDER_EXECUTION' : 'PROVIDER_ERROR');
            if (data && /^(request_pending|request_uncertain|request_conflict)$/.test(data.status)) err.code = data.status.toUpperCase();
            if (data && /^(inactive|invalid|denied)$/.test(data.status)) {
                if (/^(missing_licence_key|missing_key_or_device|missing_device_id)$/i.test(String(data.reason || ''))) {
                    err.code = 'PROVIDER_REDIRECT_RETRY';
                } else {
                    err.code = 'LICENSE_INACTIVE';
                }
            }
            if (data && data.status === 'expired') err.code = 'LICENSE_EXPIRED';
            else if (data && data.status === 'credits_exhausted') err.code = 'LICENSE_CREDIT_EXHAUSTED';
            else if (data && data.status === 'credit_config_error') err.code = 'LICENSE_CREDIT_CONFIG_ERROR';
            throw err;
        }
        // Backend may transparently recover to another healthy row of the same
        // provider. Keep the in-memory settings aligned so later usage/failover
        // bookkeeping refers to the row that actually served the request.
        const servedRow = Math.max(0, parseInt(data && data.keyRow, 10) || 0);
        if (settings && typeof settings === 'object') {
            const postCallAvail = Number(data && data.account && data.account.availableCredit);
            const actualServerDebit = (!data.replayed && Number.isFinite(preCallAvail) && Number.isFinite(postCallAvail) && postCallAvail < preCallAvail)
                ? Math.max(0, preCallAvail - postCallAvail)
                : 0;
            settings._unoffsetServerCredits = (settings._unoffsetServerCredits || 0) + actualServerDebit;
        }
        if (settings.managedRouting) {
            const m = settings.providerMetrics || (settings.providerMetrics = {});
            m.calls = (m.calls || 0) + (data.replayed ? 0 : Number(data.apiCalls || 0));
            m.results = (m.results || 0) + (data.replayed ? 0 : Number(data.rawProviderResultCount || 0));
            m.credits = (m.credits || 0) + (data.replayed ? 0 : Number(data.creditsConsumed || 0));
        }
        if (servedRow && settings && typeof settings === 'object' && !settings.managedRouting) {
            settings.apiKeyRow = servedRow;
            settings.apifyKeyRow = servedRow;
        }
        return data.data;
    }

    function proxyKeyRowFromHeaders(headers) {
        return Math.max(0, parseInt(headers && (headers['X-PocketLeads-Key-Row'] || headers['x-pocketleads-key-row']), 10) || 0);
    }

    const ApiBackendManager = {
        // v91: Start must never perform licence/provider discovery. The latest
        // completed hidden preflight (icon click / licence activation / Clear Data)
        // is the routing source of truth. Real providerProxy calls still revalidate
        // licence, device, credits and the selected API row server-side.
        async getPreparedScrapeConfig(excludeRows) {
            // v92 strict prepared-route contract. Start performs local reads only:
            // no Apps Script config request, no provider probing, no API-key lookup.
            // The route was prepared on icon click / Clear Data / licence activation.
            const stored = await chromeStorageGetAsync(['license', 'pocketleadsAccount', 'pocketleadsPreparedRoute']);
            const licence = stored && stored.license || {};
            const key = licence && licence.key ? String(licence.key).trim() : '';
            if (!key || licence.active === false) {
                const err = new Error('Please activate your licence first.');
                err.code = 'LICENSE_INACTIVE';
                err.preflightOnly = true;
                throw err;
            }
            let prepared=stored.pocketleadsPreparedRoute||{},account=stored.pocketleadsAccount||{};
            let current=account.key===key && account.route;
            if ((!current || current.status !== 'ok') && String(prepared.licenceKey || '').trim() !== key && typeof PocketLeadsAccount !== 'undefined' && PocketLeadsAccount && typeof PocketLeadsAccount.preflight === 'function') {
                try {
                    await PocketLeadsAccount.preflight();
                    const refreshed = await chromeStorageGetAsync(['pocketleadsAccount', 'pocketleadsPreparedRoute']);
                    prepared = (refreshed && refreshed.pocketleadsPreparedRoute) || prepared;
                    account = (refreshed && refreshed.pocketleadsAccount) || account;
                    current = account.key === key && account.route;
                } catch (_) {}
            }
            const useRecovery=prepared.recoveryOnly && prepared.licenceKey===key && (!current || current.status!=='ok');
            const route=useRecovery ? prepared : (current ? {...current,status:current.status==='ok'?'ready':'error',licenceKey:key,apiKeyRow:current.keyRow,apiUsageBefore:current.usageCount,apiUsageLimit:current.usageLimit,error:current.message||current.reason,errorCode:current.status==='credits_exhausted'?'LICENSE_CREDIT_EXHAUSTED':(current.errorCode||'NO_ELIGIBLE_PROVIDER')} : prepared);
            if (String(route.licenceKey || '').trim() !== key) {
                const err = new Error('Network is slow or unstable right now. Please check your internet connection and tap Try Again / Resume.');
                err.code = 'NETWORK_SLOW_RETRY';
                err.preflightOnly = true;
                throw err;
            }
            if (String(route.status || '').toLowerCase() === 'error') {
                const code = String(route.errorCode || '').toUpperCase();
                let message = String(route.error || '').trim();
                if (/LICENSE_CREDIT_EXHAUSTED|ALL_CREDITS_EXHAUSTED|LICENCE_CREDIT_EXHAUSTED/.test(code)) {
                    message = `Your scraping credits are exhausted. Upgrade your plan to continue. Contact ${route.supportEmail || SUPPORT_EMAIL}.`;
                } else if (/LICENSE_EXPIRED|LICENCE_EXPIRED/.test(code)) {
                    message = `Your licence has expired. Contact ${route.supportEmail || SUPPORT_EMAIL} to renew your licence.`;
                } else if (/NO_ELIGIBLE_PROVIDER|PROVIDER_FAILOVER_EXHAUSTED/.test(code)) {
                    message = message || 'No eligible provider. Refresh account and ask the administrator to check provider configuration.';
                }
                const err = new Error(message || 'The prepared data source is unavailable.');
                err.code = code || 'PREFLIGHT_FAILED';
                err.preflightOnly = true;
                throw err;
            }
            if (typeof PocketLeadsConfig !== 'undefined' && PocketLeadsConfig.requireManagedRouting && !route.managedRouting) {const e=new Error('Deploy and configure the included managed backend first.');e.code='BACKEND_UPDATE_REQUIRED';throw e;}
            const provider = canonicalProviderKey(route.provider);
            if (String(route.status || '').toLowerCase() !== 'ready' || !provider) {
                const err = new Error('Network is slow or unstable right now. Please check your internet connection and tap Try Again / Resume.');
                err.code = 'NETWORK_SLOW_RETRY';
                err.preflightOnly = true;
                throw err;
            }
            const excludedRows = new Set((Array.isArray(excludeRows) ? excludeRows : []).map(v => parseInt(v,10)||0).filter(Boolean));
            const keyRow = Math.max(0, parseInt(route.apiKeyRow || route.apifyKeyRow,10)||0);
            if (keyRow && excludedRows.has(keyRow)) {
                const err = new Error('The prepared data source changed. Use Clear Data once to refresh the available source.');
                err.code = 'PREPARED_ROW_EXCLUDED';
                err.preflightOnly = true;
                throw err;
            }
            return {
                provider, managedRouting: !!route.managedRouting, providerPriority: route.providerPriority || [],
                apiToken: '', actorId: '', sourceId: '',
                secureProxy: true, preparedRoute: true, fastStart: true,
                apiKeyRow: keyRow, apifyKeyRow: keyRow,
                apiUsageBefore: parseInt(route.apiUsageBefore || route.apifyUsageBefore,10)||0,
                apifyUsageBefore: parseInt(route.apiUsageBefore || route.apifyUsageBefore,10)||0,
                apiUsageLimit: parseInt(route.apiUsageLimit || route.apifyUsageLimit,10)||DEFAULT_SETTINGS.apiUsageLimit,
                apifyUsageLimit: parseInt(route.apiUsageLimit || route.apifyUsageLimit,10)||DEFAULT_SETTINGS.apifyUsageLimit,
                licenceCreditRemaining: route.licenceCreditRemaining != null ? route.licenceCreditRemaining : null
            };
        },

        async getConfig(preferNext, providerPreference, excludeRows) {
            const licence = await ensureLicenceInstallationAsync(await getStoredLicenceAsync());
            const key = licence && licence.key ? String(licence.key).trim() : '';
            if (!key) throw new Error('Please activate your licence first.');
            const deviceId = installationIdFromLicence(licence);

            let data = null;
            let requestError = null;
            const configPayload = {
                key,
                deviceId,
                preferNext: !!preferNext,
                provider: providerPreference || 'auto',
                excludeRows: Array.isArray(excludeRows) ? excludeRows.join(',') : (excludeRows || '')
            };
            // v89 latency fix: one authoritative auto-source request. Older builds
            // could spend ~30s across nested retries/provider probes. A recent
            // non-secret route cache covers temporary Apps Script cold starts.
            try {
                data = await callAppsScript('getApiConfig', configPayload, { attempts: 1, timeoutMs: 8000 });
                requestError = null;
            } catch (err) {
                requestError = err;
                data = null;
            }

            // A confirmed inactive licence must never use a cache fallback.
            if (data && data.status === 'inactive') {
                const err = new Error(`This licence is inactive. Contact ${data.supportEmail || SUPPORT_EMAIL}.`);
                err.code = 'LICENSE_INACTIVE';
                throw err;
            }
            if (data && data.status === 'expired') {
                const err = new Error(`Your licence expired${data.expiryDate ? ' on ' + data.expiryDate : ''}. Contact ${data.supportEmail || SUPPORT_EMAIL} to renew.`);
                err.code = 'LICENSE_EXPIRED';
                throw err;
            }
            if (data && data.status === 'credits_exhausted') {
                const err = new Error(`Your scraping credits are exhausted. Upgrade your plan to continue. Contact ${data.supportEmail || SUPPORT_EMAIL}.`);
                err.code = 'LICENSE_CREDIT_EXHAUSTED';
                err.payload = data.diagnostics || null;
                throw err;
            }
            if (data && data.status === 'denied' && /device|installation/i.test(String(data.reason || ''))) {
                throw new Error('This device is not authorized for this licence yet. Reactivate the licence once on this device, then retry.');
            }

            if (!data || data.status !== 'ok') {
                if (requestError) throw requestError;
                if (data && data.status === 'no_api_key') {
                    const err = new Error((data && data.message) || NO_PROVIDER_MESSAGE);
                    err.retryAfter = data && data.retryAfter;
                    err.code = 'NO_ELIGIBLE_PROVIDER';
                    err.payload = data.diagnostics || null;
                    err.adminDiagnostic = backendProviderDiagnosticMessage(data);
                    throw err;
                }
                if (data && data.status === 'invalid') {
                    if (!data.backend) {
                        throw new Error('Apps Script old version chal raha hai. ZIP ke apps_script_code.js ko Google Apps Script me paste karke Deploy > Manage deployments > Edit > New version > Deploy karo.');
                    }
                    throw new Error('Licence verification failed. Google Sheet me key/status check karo. Existing verified route cache available nahi tha.');
                }
                throw new Error((data && data.message) || 'Unable to get backend data setup. Apps Script deployment/check API sheet setup.');
            }
            if (data.secureProxy !== true || !['sheet_authoritative_secure_proxy_v3','user_assigned_secure_proxy_v4'].includes(String(data.providerContract || '')) || !/^v\d+_/i.test(String(data.version || ''))) {
                const err = new Error('PocketLeads secure backend v30 required. Deploy the ZIP apps_script_code.js using Manage deployments > Edit > New version.');
                err.code = 'BACKEND_UPDATE_REQUIRED';
                throw err;
            }
            const provider = canonicalProviderKey(data.provider || 'apify') || 'apify';
            const requestedProvider = canonicalProviderKey(providerPreference);
            // The Admin Sheet / Apps Script provider response is authoritative.
            // Never silently reuse or accept a different provider for a provider-specific request.
            if (requestedProvider && requestedProvider !== provider) {
                const mismatch = new Error(`Backend provider mismatch: requested ${requestedProvider}, received ${provider}.`);
                mismatch.code = 'PROVIDER_MISMATCH';
                mismatch.status = 409;
                throw mismatch;
            }
            const config = {
                provider, managedRouting: !!data.managedRouting, providerPriority: data.providerPriority || [],
                // v84 secure proxy: provider credentials never leave Apps Script.
                apiToken: '',
                actorId: '',
                sourceId: '',
                secureProxy: data.secureProxy === true,
                apiKeyRow: parseInt(data.keyRow, 10) || 0,
                apifyKeyRow: parseInt(data.keyRow, 10) || 0,
                apiUsageBefore: parseInt(data.usageCount, 10) || 0,
                apifyUsageBefore: parseInt(data.usageCount, 10) || 0,
                apiUsageLimit: Math.max(0, Number(data.usageLimit) || 0),
                apifyUsageLimit: Math.max(0, Number(data.usageLimit) || 0),
                licenceCreditRemaining: data.licenceCreditRemaining != null ? data.licenceCreditRemaining : null,
                backendCacheUsed: false
            };
            return config;
        },

        async reportUsage(settings, usedCount) {
            // v85/v24 backend accounts returned results atomically inside providerProxy.
            // Keep this method as a compatibility no-op so old queue code does not
            // double-increment API Usage Count or licence credits.
            return null;
        },

        async reportLeadMetrics(settings, uniqueAdded, eventId, extra) {
            const amount = Math.max(0, parseInt(uniqueAdded, 10) || 0);
            const creditToDeduct = (extra && extra.creditToDeduct !== undefined)
                ? Math.max(0, parseInt(extra.creditToDeduct, 10) || 0)
                : amount;
            const row = apiKeyRowOf(settings);
            if (!amount && !creditToDeduct) return null;
            let licence = null;
            try { licence = await ensureLicenceInstallationAsync(await getStoredLicenceAsync()); } catch (e) { return null; }
            const key = licence && licence.key ? String(licence.key).trim() : '';
            if (!key) return null;
            let deviceId = '';
            try { deviceId = installationIdFromLicence(licence); } catch (e) { return null; }
            const deductUniqueCredit = extra && extra.deductUniqueCredit !== undefined ? !!extra.deductUniqueCredit : true;
            const data = await callAppsScript('reportLeadMetrics', {
                key,
                deviceId,
                keyRow: row || 0,
                provider: canonicalProviderKey(settings && settings.provider || (extra && extra.provider) || ''),
                uniqueAdded: deductUniqueCredit ? creditToDeduct : amount,
                rawUniqueAdded: amount,
                creditToDeduct: deductUniqueCredit ? creditToDeduct : 0,
                deductUniqueCredit,
                runId: String(extra && extra.runId || ''),
                eventId: String(eventId || '')
            }, { attempts: 2, timeoutMs: 12000 });
            if (data && data.status === 'ok' && deductUniqueCredit && creditToDeduct > 0 && typeof PocketLeadsAccount !== 'undefined' && typeof PocketLeadsAccount.acknowledgeSync === 'function') {
                await PocketLeadsAccount.acknowledgeSync(creditToDeduct, data, key, deviceId).catch(() => null);
            }
            return data && data.status === 'ok' ? data : null;
        },

        async markLimit(settings, reason) {
            const row = apiKeyRowOf(settings);
            if (!row) return null;
            let licence = null;
            try { licence = await ensureLicenceInstallationAsync(await getStoredLicenceAsync()); } catch (e) { return null; }
            const key = licence && licence.key ? String(licence.key).trim() : '';
            if (!key) return null;
            let deviceId = '';
            try { deviceId = installationIdFromLicence(licence); } catch (e) { return null; }
            try {
                const data = await callAppsScript('markApiLimit', {
                    key,
                    deviceId,
                    keyRow: row,
                    reason: String(reason || 'limit/error').slice(0, 300)
                });
                if (data && data.status === 'ok') return data;
            } catch (err) {
                warn('Backend mark limit failed', err);
            }
            return null;
        },

        async markProblem(settings, rowStatus, reason) {
            const row = apiKeyRowOf(settings);
            if (!row) return null;
            let licence = null;
            try { licence = await ensureLicenceInstallationAsync(await getStoredLicenceAsync()); } catch (e) { return null; }
            const key = licence && licence.key ? String(licence.key).trim() : '';
            if (!key) return null;
            let deviceId = '';
            try { deviceId = installationIdFromLicence(licence); } catch (e) { return null; }
            try {
                const data = await callAppsScript('markApiProblem', {
                    key,
                    deviceId,
                    keyRow: row,
                    rowStatus: rowStatus || 'api_blocked',
                    reason: String(reason || 'api/config error').slice(0, 300)
                });
                if (data && data.status === 'ok') return data;
            } catch (err) {
                warn('Backend mark API problem failed', err);
            }
            return null;
        }
    };



    function safeRuntimeMessage(message) {
        try {
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage(message, function () {
                    if (chrome.runtime.lastError) {
                        warn('runtime message warning', chrome.runtime.lastError.message || chrome.runtime.lastError);
                    }
                });
            }
        } catch (err) {
            warn('runtime message failed', err);
        }
    }

    function makeRunEventId(prefix) {
        return String(prefix || 'run') + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 9);
    }

    // One terminal event must create at most one operating-system notification,
    // even if the MV3 service worker restarts or two error paths converge.
    const terminalNotificationInFlight = new Set();
    function showSingleSystemNotification(id, title, message, eventId) {
        try {
            if (typeof chrome === 'undefined' || !chrome.notifications || typeof chrome.notifications.create !== 'function') return;
            const logicalEventId = String(eventId || (String(title || '') + '|' + String(message || ''))).slice(0, 500);
            const guardKey = 'pocketleads_terminal_notification_' + logicalEventId;
            if (terminalNotificationInFlight.has(guardKey)) return;
            terminalNotificationInFlight.add(guardKey);

            const notificationId = String(id || 'pocketleads_status').replace(/[^a-z0-9_.-]/gi, '_').slice(0, 80);
            const options = {
                type: 'basic',
                iconUrl: chrome.runtime.getURL('assets/icons/icon.png'),
                title: String(title || 'PocketLeads').slice(0, 80),
                message: String(message || '').slice(0, 500)
            };
            const finish = () => {
                // Keep the in-memory marker for this worker lifetime. The session
                // marker below protects against service-worker restarts.
            };
            const create = () => {
                try {
                    chrome.notifications.create(notificationId, options, function () {
                        void chrome.runtime.lastError;
                        finish();
                    });
                } catch (err) {
                    warn('system notification create failed', err);
                }
            };
            const createAndRemember = () => {
                try {
                    if (chrome.storage && chrome.storage.session && typeof chrome.storage.session.set === 'function') {
                        const payload = {};
                        payload[guardKey] = Date.now();
                        chrome.storage.session.set(payload, function () {
                            void chrome.runtime.lastError;
                            create();
                        });
                    } else {
                        create();
                    }
                } catch (err) {
                    create();
                }
            };
            const checkSession = () => {
                try {
                    if (chrome.storage && chrome.storage.session && typeof chrome.storage.session.get === 'function') {
                        chrome.storage.session.get(guardKey, function (stored) {
                            void chrome.runtime.lastError;
                            if (stored && stored[guardKey]) return;
                            createAndRemember();
                        });
                    } else {
                        createAndRemember();
                    }
                } catch (err) {
                    createAndRemember();
                }
            };
            checkSession();
        } catch (err) {
            warn('system notification failed', err);
        }
    }

    function buildEmptyQueue(overrides = {}) {
        return Object.assign({
            status: 'idle',
            statusMessage: '',
            provider: '',
            engine: '',
            executionMode: '',
            startedAt: '',
            finishedAt: '',
            elapsedMs: 0,
            currentQuery: '',
            currentProfileUrl: '',
            totalPlaceIds: 0,
            totalApiResults: 0,
            currentPage: 0,
            totalPages: 0,
            scrapedCount: 0,
            failedCount: 0,
            filteredCount: 0,
            duplicateSkippedCount: 0,
            pendingPlaceIds: [],
            processing: null,
            completed: [],
            failed: [],
            retryCount: {},
            pincodeStatuses: {},
            placeIdQueue: [],
            skipped: [],
            apiTasksTotal: 0,
            apiTasksDone: 0,
            apiTasksFailed: 0,
            apiTasksSettled: 0,
            domTotal: 0,
            domProcessed: 0,
            domPending: 0,
            domRunning: 0,
            domSaved: 0,
            domFailed: 0,
            domSkipped: 0,
            completedWithErrors: false,
            resumeAvailable: false,
            producerDone: false,
            consumerDone: false,
            domConcurrency: 1,
            domSuccessStreak: 0,
            domSuccessRate: 0,
            domTransientErrors: 0,
            lastCheckpointAt: '',
            resultStoreCount: 0,
            runEventId: '',
            jobRunId: '',
            lastTerminalEventId: '',
            lastErrorCode: '',
            lastErrorDetail: '',
            lastErrorAt: '',
            managedTabIds: [],
            apiKeyRow: 0,
            apiUsageBefore: 0,
            apiUsageAfter: 0,
            apiUsageLimit: 0,
            apifyKeyRow: 0,
            apifyUsageBefore: 0,
            apifyUsageAfter: 0,
            apifyUsageLimit: 0,
            lastUpdatedAt: nowIso()
        }, overrides);
    }

    function asString(value) {
        if (value === null || typeof value === 'undefined') return '';
        if (Array.isArray(value)) {
            return value.map(v => asString(v)).filter(Boolean).join(', ');
        }
        if (typeof value === 'object') {
            if ('text' in value) return asString(value.text);
            if ('value' in value) return asString(value.value);
            if ('name' in value) return asString(value.name);
            try { return JSON.stringify(value); } catch (e) { return ''; }
        }
        return String(value).trim();
    }

    function getByPath(obj, path) {
        if (!obj || !path) return undefined;
        if (!path.includes('.')) return obj[path];
        return path.split('.').reduce((acc, part) => acc && typeof acc === 'object' ? acc[part] : undefined, obj);
    }

    function firstValue(obj, keys) {
        for (const key of keys || []) {
            const val = getByPath(obj, key);
            const str = asString(val);
            if (str) return str;
        }
        return '';
    }

    function normalizeEmailText(value) {
        return asString(value)
            .replace(/&commat;|&#64;|&#x40;/gi, '@')
            .replace(/&period;|&#46;|&#x2e;/gi, '.')
            .replace(/\s*(?:\[|\(|\{)\s*at\s*(?:\]|\)|\})\s*/gi, '@')
            .replace(/\s+at\s+/gi, '@')
            .replace(/\s*(?:\[|\(|\{)\s*dot\s*(?:\]|\)|\})\s*/gi, '.')
            .replace(/\s+dot\s+/gi, '.')
            .trim();
    }

    function extractEmailValues(value) {
        const text = normalizeEmailText(value).replace(/^mailto:/i, '');
        const found = [];
        const re = /[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+/gi;
        let match;
        while ((match = re.exec(text)) !== null) {
            const email = match[0].toLowerCase().replace(/[.,;:]+$/, '');
            if (!found.includes(email) && email.length <= 254) found.push(email);
        }
        return found;
    }

    function slugKey(key) {
        return String(key || '')
            .replace(/^[#@]+/, '')
            .replace(/([a-z0-9])([A-Z])/g, '$1_$2')
            .replace(/[^a-zA-Z0-9]+/g, '_')
            .replace(/^_+|_+$/g, '')
            .toLowerCase();
    }

    function hashString(input) {
        const str = String(input || '');
        let hash = 0;
        for (let i = 0; i < str.length; i += 1) {
            hash = ((hash << 5) - hash) + str.charCodeAt(i);
            hash |= 0;
        }
        return Math.abs(hash).toString(36);
    }

    function compactText(value) {
        return String(value || '').toLowerCase().replace(/\s+/g, ' ').trim();
    }

    function makeSkippedRecord(row, meta, reason, status, source) {
        const r = row && typeof row === 'object' ? row : {};
        return {
            source: source || 'Scraping',
            placeId: r.place_id || r.placeId || '',
            cid: r.cid || '',
            query: (meta && (meta.queryForApi || meta.query)) || r.query || '',
            keyword: (meta && meta.keyword) || r.keyword || '',
            location: (meta && meta.location) || r.location || '',
            status: status || 'Skipped',
            reason: reason || 'Skipped before saving',
            skipReason: reason || 'Skipped before saving',
            category: r.category || r.categories || r.company_name || r.name || '',
            companyName: r.company_name || r.name || '',
            address: r.address || '',
            mapsUrl: r.map_link || r.mapsUrl || '',
            lastUpdatedAt: nowIso()
        };
    }

    function mergeSkippedRecords(existing, incoming) {
        const out = [];
        const seen = new Set();
        [...(Array.isArray(existing) ? existing : []), ...(Array.isArray(incoming) ? incoming : [])].forEach(r => {
            if (!r || typeof r !== 'object') return;
            const key = [r.source || '', r.placeId || r.place_id || '', r.cid || '', r.query || '', r.keyword || '', r.location || '', r.status || '', r.reason || r.skipReason || ''].join('|');
            if (seen.has(key)) return;
            seen.add(key);
            out.push(r);
        });
        return out.slice(-2000);
    }

    function escapeRegExp(text) {
        return String(text || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    function normalizePhone(value) {
        return String(value || '').replace(/\D+/g, '');
    }

    const INDIAN_STATE_NAMES = [
        'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana',
        'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur',
        'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Orissa', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
        'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Delhi', 'New Delhi', 'Jammu and Kashmir',
        'Ladakh', 'Puducherry', 'Chandigarh', 'Andaman and Nicobar Islands', 'Dadra and Nagar Haveli', 'Daman and Diu',
        'Lakshadweep'
    ];

    function cleanUrlLike(value) {
        const text = asString(value);
        if (!text) return '';
        if (/google\.[^/]+\/maps|maps\.app\.goo\.gl|goo\.gl\/maps|\/maps\//i.test(text)) return '';
        if (/^https?:\/\//i.test(text) || /^[a-z0-9.-]+\.[a-z]{2,}(\/|$)/i.test(text)) return text;
        return '';
    }

    function titleCaseSmall(text) {
        return String(text || '').trim().replace(/\s+/g, ' ').replace(/\b([a-z])/g, m => m.toUpperCase());
    }

    function normalizeQueryTextForApi(query) {
        // Keep the user's keyword/location exactly as entered. No hidden spelling
        // correction, synonym expansion, or query enhancement.
        return String(query || '').trim().replace(/\s+/g, ' ');
    }

    /**
     * Derive generic business-intent keywords from the user's search query.
     * This is deliberately NOT clinic-only or mobile-only. Users may search
     * any category such as restaurant, school, gym, courier, photo studio,
     * laptop repair, pharmacy, salon, coaching centre, etc.
     *
     * The function removes location/country/noise words, keeps the business
     * part of the query, and adds a small synonym expansion for common words.
     * Unknown categories still work because the original category tokens are
     * retained. Category filtering is soft: if the normalizer is not confident,
     * it will keep rows instead of wrongly skipping genuine results.
     */
    function extractCategoryKeywords(query, meta, settings) {
        let q = String(query || '').toLowerCase();
        if (!q) return [];
        const countryName = String((settings && (settings.countryFilter || settings.country)) || (meta && meta.country) || '').toLowerCase();
        const locationText = String((meta && meta.location) || '').toLowerCase();

        // Prefer only the business part before location prepositions.
        // Examples: "clinic in kolkata" -> "clinic", "mobile shop near me" -> "mobile shop".
        const beforeLocation = q.split(/\b(?:in|near|around|at|from)\b/i)[0].trim();
        if (beforeLocation && beforeLocation.length >= 3) q = beforeLocation;

        const cleaned = q.replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
        if (!cleaned) return [];
        const locationTokens = new Set(String(locationText || '').replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(Boolean));
        const countryTokens = new Set(String(countryName || '').replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(Boolean));
        const stop = new Set([
            'in','near','around','at','from','me','my','best','top','open','now','24','hrs','hour','hours',
            'store','stores','shop','shops','service','services','centre','center','company','companies','business','businesses',
            'india','bharat','state','city','district','area','road','street','market','west','east','north','south',
            'google','maps','map','local','nearby','list','lists','dealer','dealers','supplier','suppliers'
        ]);
        const rawTokens = cleaned.split(' ').filter(Boolean);
        const baseTokens = rawTokens.filter(t => {
            if (!t || t.length < 3) return false;
            if (/^\d+$/.test(t)) return false;
            if (stop.has(t)) return false;
            if (locationTokens.has(t) || countryTokens.has(t)) return false;
            return true;
        });
        if (!baseTokens.length) return [];

        // Generic synonyms for many common categories. This is only an assist;
        // if a user searches a new category not listed here, baseTokens still
        // drive matching, so the system remains category-independent.
        const SYNONYMS = {
            mobile: ['mobile','phone','cell','smartphone','telecom'],
            phone: ['phone','mobile','cell','smartphone','telecom'],
            telecom: ['telecom','mobile','phone','cell'],
            clinic: ['clinic','hospital','medical','health','doctor','diagnostic','diagnostics','pathology','physician','dental','dentist','pharmacy','chemist','nursing'],
            hospital: ['hospital','clinic','medical','health','doctor','nursing'],
            doctor: ['doctor','clinic','hospital','medical','physician','health'],
            diagnostic: ['diagnostic','diagnostics','pathology','clinic','medical','lab','laboratory'],
            pharmacy: ['pharmacy','chemist','medical','medicine','drugstore'],
            chemist: ['chemist','pharmacy','medical','medicine'],
            restaurant: ['restaurant','restuarant','restaurent','resturent','restraunt','restrant','dining','eatery','food','hotel'],
            resturent: ['restaurant','restuarant','restaurent','resturent','restraunt','restrant','dining','eatery','food'],
            restraunt: ['restaurant','restuarant','restaurent','resturent','restraunt','restrant','dining','eatery','food'],
            restrant: ['restaurant','restuarant','restaurent','resturent','restraunt','restrant','dining','eatery','food'],
            cafe: ['cafe','coffee','bakery','food'],
            hotel: ['hotel','restaurant','lodging','guesthouse','resort'],
            grocery: ['grocery','supermarket','mart','kirana','general'],
            supermarket: ['supermarket','grocery','mart','kirana'],
            school: ['school','college','academy','institution','institute'],
            college: ['college','school','academy','institution','institute'],
            coaching: ['coaching','academy','institute','tuition','tutorial'],
            gym: ['gym','fitness','fitness centre','fitness center','workout'],
            salon: ['salon','beauty','parlour','parlor','spa'],
            repair: ['repair','service','technician','workshop','maintenance'],
            laptop: ['laptop','computer','pc','repair','electronics'],
            computer: ['computer','laptop','pc','electronics'],
            electronics: ['electronics','electrical','mobile','computer','appliance'],
            battery: ['battery','inverter','electronics','electrical'],
            courier: ['courier','parcel','logistics','delivery'],
            transport: ['transport','logistics','courier','travel'],
            travel: ['travel','tour','tourism','agency'],
            bank: ['bank','finance','financial','atm'],
            atm: ['atm','bank'],
            insurance: ['insurance','finance','financial'],
            real: ['real','estate','property','broker'],
            estate: ['estate','property','broker','real'],
            photo: ['photo','photography','studio','photographer'],
            studio: ['studio','photo','photography','photographer'],
            hardware: ['hardware','paint','tools','building'],
            paint: ['paint','hardware','building'],
            furniture: ['furniture','interior','wood'],
            cloth: ['cloth','clothing','garment','fashion'],
            clothing: ['clothing','cloth','garment','fashion'],
            garment: ['garment','clothing','cloth','fashion'],
            jewellery: ['jewellery','jewelry','gold','silver'],
            jewelry: ['jewelry','jewellery','gold','silver'],
            bakery: ['bakery','cake','cafe','food'],
            sweet: ['sweet','sweets','mithai','bakery'],
            car: ['car','automobile','auto','vehicle','garage'],
            bike: ['bike','motorcycle','two wheeler','garage'],
            garage: ['garage','car','bike','auto','vehicle','repair']
        };
        const out = new Set(baseTokens);
        baseTokens.forEach(token => {
            const list = SYNONYMS[token];
            if (Array.isArray(list)) list.forEach(v => out.add(v));
        });
        return Array.from(out).slice(0, 24);
    }

    function normalizeSerperLl(value) {
        const text = asString(value).trim();
        if (!text) return '';
        // Accept Serper/Google ll formats like "@22.57,88.36,13z", "22.57,88.36,13z", or plain gps strings.
        const m = text.match(/@?\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)(?:z)?/i);
        if (!m) return '';
        return '@' + m[1] + ',' + m[2] + ',' + m[3] + 'z';
    }

    function buildLlFromPlace(place, fallbackZoom) {
        const lat = asString(place && (place.latitude || place.lat || getByPath(place, 'gps.latitude') || getByPath(place, 'location.lat') || getByPath(place, 'location.latitude')));
        const lon = asString(place && (place.longitude || place.lng || place.lon || getByPath(place, 'gps.longitude') || getByPath(place, 'location.lng') || getByPath(place, 'location.longitude')));
        if (!lat || !lon || !/^-?\d+(?:\.\d+)?$/.test(lat) || !/^-?\d+(?:\.\d+)?$/.test(lon)) return '';
        const zoom = parseInt(fallbackZoom, 10) || 13;
        return '@' + lat + ',' + lon + ',' + zoom + 'z';
    }

    function shouldApplyCategoryFilter(candidateCount, matchedCount, allowedKeywords) {
        // v63: never hard-filter provider results by a local category string.
        // Google/Serper/Apify have already ranked results for the user's full query, while
        // Maps DOM categories are broad, localized and sometimes missing. Hard filtering
        // here caused valid businesses to disappear for harmless spelling variants such
        // as "resturent" -> "Restaurant". Category terms remain a diagnostic signal
        // only; country and duplicate checks are the save-blocking filters.
        return false;
    }

    function normalizeCategoryMatchText(value) {
        let text = String(value || '').toLowerCase();
        try { text = text.normalize('NFKD').replace(/[\u0300-\u036f]/g, ''); } catch (e) {}
        return text.replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim();
    }

    function levenshteinDistanceLimited(a, b, maxDistance) {
        a = normalizeCategoryMatchText(a);
        b = normalizeCategoryMatchText(b);
        const limit = Math.max(0, parseInt(maxDistance, 10) || 0);
        if (a === b) return 0;
        if (!a || !b || Math.abs(a.length - b.length) > limit) return limit + 1;
        let previous = Array.from({ length: b.length + 1 }, (_, i) => i);
        for (let i = 1; i <= a.length; i += 1) {
            const current = [i];
            let rowMin = current[0];
            for (let j = 1; j <= b.length; j += 1) {
                const cost = a[i - 1] === b[j - 1] ? 0 : 1;
                const value = Math.min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost);
                current[j] = value;
                if (value < rowMin) rowMin = value;
            }
            if (rowMin > limit) return limit + 1;
            previous = current;
        }
        return previous[b.length];
    }

    function categoryIntentMatches(row, allowedKeywords) {
        const keywords = Array.isArray(allowedKeywords) ? allowedKeywords : [];
        if (!keywords.length) return true;
        const haystack = normalizeCategoryMatchText([
            row && (row.company_name || row.name || row.title),
            row && row.category,
            row && row.categories
        ].filter(Boolean).join(' '));
        if (!haystack) return true; // Missing DOM category must never remove a valid API result.
        const hayTokens = haystack.split(' ').filter(Boolean);
        return keywords.some(keyword => {
            const clean = normalizeCategoryMatchText(keyword);
            if (!clean) return false;
            if (haystack.includes(clean)) return true;
            const keywordTokens = clean.split(' ').filter(Boolean);
            return keywordTokens.some(token => {
                if (token.length < 4) return hayTokens.includes(token);
                const threshold = token.length >= 8 ? 2 : 1;
                return hayTokens.some(hayToken => hayToken.length >= 4 && levenshteinDistanceLimited(token, hayToken, threshold) <= threshold);
            });
        });
    }

    function queryHasIndiaLocationSignal(meta) {
        const q = compactText([meta && meta.query, meta && meta.queryForApi, meta && meta.location].filter(Boolean).join(' '));
        if (!q) return false;
        if (/\b[1-9][0-9]{5}\b/.test(q)) return true;
        return /\b(kolkata|calcutta|west bengal|bengaluru|bangalore|mumbai|delhi|new delhi|chennai|hyderabad|pune|ahmedabad|jaipur|lucknow|patna|bhubaneswar|odisha|bihar|karnataka|rajasthan|uttar pradesh|himachal|sikkim|india|bharat)\b/.test(q);
    }

    function inferLocationFromQuery(query) {
        const q = String(query || '').trim();
        let m = q.match(/\b(?:in|near|at|around)\s+([a-zA-Z][a-zA-Z\s.-]{2,60})(?:\s+India|\s+Bharat)?\s*$/i);
        if (m && m[1]) return titleCaseSmall(m[1].replace(/\b(west bengal|india|bharat)\b/ig, '').trim());
        m = q.match(/\b(kolkata|calcutta|delhi|new delhi|mumbai|bangalore|bengaluru|chennai|hyderabad|pune|jaipur|patna|bhubaneswar)\b/i);
        return m ? titleCaseSmall(m[1]) : '';
    }

    function inferStateFromCity(cityOrQuery) {
        const t = compactText(cityOrQuery);
        if (/\b(kolkata|calcutta)\b/.test(t)) return 'West Bengal';
        if (/\b(delhi|new delhi)\b/.test(t)) return 'Delhi';
        if (/\b(mumbai|pune)\b/.test(t)) return 'Maharashtra';
        if (/\b(bangalore|bengaluru)\b/.test(t)) return 'Karnataka';
        if (/\b(chennai)\b/.test(t)) return 'Tamil Nadu';
        if (/\b(hyderabad)\b/.test(t)) return 'Telangana';
        if (/\b(jaipur)\b/.test(t)) return 'Rajasthan';
        if (/\b(patna)\b/.test(t)) return 'Bihar';
        if (/\b(bhubaneswar)\b/.test(t)) return 'Odisha';
        return '';
    }

    function isShortAddress(address) {
        const text = asString(address);
        if (!text) return true;
        if (text.length < 32) return true;
        if (!/\b(india|bharat|west bengal|delhi|maharashtra|karnataka|tamil nadu|telangana|rajasthan|bihar|odisha|[1-9][0-9]{5})\b/i.test(text)) return true;
        return false;
    }

    function extractIndianPhoneFromText(text) {
        const raw = String(text || '').replace(/\u00a0/g, ' ');
        if (!raw) return '';
        const candidates = [];
        const regexes = [
            /(?:\+?91[\s.\-()]*)?[6-9][0-9][\s.\-()]*[0-9]{3}[\s.\-()]*[0-9]{5}/g,
            /(?:\+?91[\s.\-()]*)?0?[6-9][0-9]{9}/g,
            /0[1-9][0-9]{1,4}[\s.\-()]*[0-9]{6,8}/g
        ];
        regexes.forEach(rx => {
            let m;
            while ((m = rx.exec(raw)) !== null) candidates.push({ text: m[0], index: m.index });
        });
        for (const c of candidates) {
            const digits = String(c.text).replace(/\D+/g, '');
            if (/^(?:91)?[6-9][0-9]{9}$/.test(digits)) return digits.length === 12 ? '+' + digits : digits;
            if (/^0[1-9][0-9]{8,11}$/.test(digits)) return digits;
        }
        return '';
    }

    function extractIndianPhoneFromContext(text) {
        const raw = String(text || '').replace(/\u00a0/g, ' ');
        if (!raw) return '';
        const telMatch = raw.match(/(?:tel:|href=["']tel:)(\+?91[\s.\-()]*)?0?[6-9][0-9\s.\-()]{8,16}/i);
        if (telMatch) {
            const telPhone = extractIndianPhoneFromText(telMatch[0]);
            if (telPhone) return telPhone;
        }
        const regexes = [
            /(?:\+?91[\s.\-()]*)?[6-9][0-9][\s.\-()]*[0-9]{3}[\s.\-()]*[0-9]{5}/g,
            /(?:\+?91[\s.\-()]*)?0?[6-9][0-9]{9}/g,
            /0[1-9][0-9]{1,4}[\s.\-()]*[0-9]{6,8}/g
        ];
        const positiveRx = /phone|mobile|call|contact|telephone|tel:|aria-label=["'][^"']*(phone|call)|data-item-id=["'][^"']*phone|\bph\b|☎|📞/i;
        const negativeRx = /placeid|place_id|cid|fid|latitude|longitude|rating|review|thumbnail|image|photo|schema|googleusercontent|data-pid|gps|zoom/i;
        for (const rx of regexes) {
            let m;
            while ((m = rx.exec(raw)) !== null) {
                const start = Math.max(0, m.index - 120);
                const end = Math.min(raw.length, m.index + m[0].length + 120);
                const ctx = raw.slice(start, end);
                if (!positiveRx.test(ctx) || negativeRx.test(ctx)) continue;
                const phone = extractIndianPhoneFromText(m[0]);
                if (phone) return phone;
            }
        }
        return '';
    }


    const TASK_COUNTRY_DIAL_CODES = {
        in: '91', india: '91', bharat: '91',
        us: '1', usa: '1', 'united states': '1', 'united states of america': '1', america: '1',
        ca: '1', canada: '1',
        gb: '44', uk: '44', 'united kingdom': '44', 'great britain': '44', england: '44', scotland: '44', wales: '44',
        au: '61', australia: '61',
        ae: '971', uae: '971', 'united arab emirates': '971', dubai: '971',
        bd: '880', bangladesh: '880',
        pk: '92', pakistan: '92',
        np: '977', nepal: '977',
        lk: '94', 'sri lanka': '94',
        bt: '975', bhutan: '975',
        mv: '960', maldives: '960',
        sg: '65', singapore: '65',
        my: '60', malaysia: '60',
        th: '66', thailand: '66',
        id: '62', indonesia: '62',
        ph: '63', philippines: '63',
        de: '49', germany: '49',
        fr: '33', france: '33',
        it: '39', italy: '39',
        es: '34', spain: '34',
        nl: '31', netherlands: '31',
        be: '32', belgium: '32',
        ch: '41', switzerland: '41',
        br: '55', brazil: '55',
        mx: '52', mexico: '52',
        za: '27', 'south africa': '27',
        sa: '966', 'saudi arabia': '966',
        qa: '974', qatar: '974',
        om: '968', oman: '968',
        kw: '965', kuwait: '965',
        bh: '973', bahrain: '973',
        nz: '64', 'new zealand': '64',
        ie: '353', ireland: '353',
        jp: '81', japan: '81',
        kr: '82', 'south korea': '82',
        cn: '86', china: '86',
        hk: '852', 'hong kong': '852',
        tr: '90', turkey: '90', 'türkiye': '90',
        ru: '7', russia: '7',
        eg: '20', egypt: '20',
        ng: '234', nigeria: '234',
        ke: '254', kenya: '254'
    };
    let activeTaskCountryDialPrefix = '91';

    function resolveTaskCountryDialPrefix(countryHint, addressHint) {
        const c = String(countryHint || '').trim().toLowerCase();
        if (c && TASK_COUNTRY_DIAL_CODES[c]) return TASK_COUNTRY_DIAL_CODES[c];
        const addr = String(addressHint || '').trim();
        if (addr) {
            if (/\b[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b/i.test(addr) || /\b(united kingdom|\buk\b|england|scotland|wales|london|manchester|birmingham|glasgow|edinburgh|liverpool|leeds|bristol)\b/i.test(addr)) return '44';
            if (/\b(united arab emirates|\buae\b|dubai|abu dhabi|sharjah)\b/i.test(addr)) return '971';
            if (/\b(united states|\busa\b|new york|california|texas|florida|chicago|los angeles)\b/i.test(addr)) return '1';
            if (/\b(canada|toronto|vancouver|montreal|ontario|calgary)\b/i.test(addr)) return '1';
            if (/\b(australia|sydney|melbourne|brisbane|perth)\b/i.test(addr)) return '61';
            if (/\b[1-9]\d{5}\b/.test(addr) || /\b(india|bharat|kolkata|mumbai|delhi|bengaluru|bangalore|chennai|hyderabad|pune|ahmedabad)\b/i.test(addr)) return '91';
        }
        return activeTaskCountryDialPrefix || '91';
    }

    function normalizeBusinessPhone(value, countryHint, addressHint) {
        const text = asString(value);
        if (!text) return '';
        if (/^https?:\/\//i.test(text) || /^0x[0-9a-f]+/i.test(text) || /^-?\d+\.\d+\s*,\s*-?\d+\.\d+$/.test(text)) return '';
        const cleaned = text.replace(/^\s*(?:phone|mobile|tel|telephone|call|whatsapp|wa)\s*[:：-]\s*/i, '').trim();
        if (!cleaned) return '';
        const prefix = resolveTaskCountryDialPrefix(countryHint, addressHint);
        if (/^\+\s*[1-9][\d\s.\-()]{6,18}$/.test(cleaned)) {
            const intlDigits = cleaned.replace(/\D+/g, '');
            if (intlDigits.length >= 8 && intlDigits.length <= 15) {
                if (prefix !== '91' && /^91\d{10}$/.test(intlDigits)) {
                    return '+' + prefix + intlDigits.slice(2);
                }
                return '+' + intlDigits;
            }
        }
        if (prefix === '91') {
            const indianPhone = extractIndianPhoneFromText(cleaned);
            if (indianPhone) return indianPhone;
        }
        const parts = cleaned.split(/(?:\s*(?:,|;|\||\/|\n|\r)\s*)+/).filter(Boolean);
        for (const part of parts.length ? parts : [cleaned]) {
            const p = String(part || '').trim();
            if (!p || /^\d+\.\d+$/.test(p)) continue;
            const hasPlus = p.startsWith('+');
            const hasDoubleZero = p.startsWith('00');
            const rawDigits = p.replace(/\D+/g, '');
            if (rawDigits.length < 7 || rawDigits.length > 15) continue;
            if (hasPlus && rawDigits.length >= 8) return '+' + rawDigits;
            if (hasDoubleZero && rawDigits.length >= 10) return '+' + rawDigits.slice(2);
            const stripped = rawDigits.replace(/^0+/, '');
            if (!stripped || stripped.length < 7) continue;
            if (prefix && stripped.startsWith(prefix) && stripped.length >= prefix.length + 7) {
                return '+' + stripped;
            }
            if (prefix && stripped.length >= 7 && stripped.length <= 11) {
                return '+' + prefix + stripped;
            }
            if (rawDigits.length >= 8 && rawDigits.length <= 15) {
                return '+' + stripped;
            }
        }
        return extractIndianPhoneFromText(cleaned) || '';
    }

    function extractSerperPhone(place) {
        if (!place || typeof place !== 'object') return '';
        const directKeys = [
            'phoneNumber', 'phone', 'telephone', 'mobile', 'contactPhone',
            'formattedPhone', 'formatted_phone_number', 'internationalPhoneNumber',
            'international_phone_number', 'phoneNumberUnformatted', 'phoneUnformatted',
            'phone_number', 'phone_number_unformatted'
        ];
        for (const key of directKeys) {
            const value = firstValue(place, [key]);
            const phone = normalizeBusinessPhone(value);
            if (phone) return phone;
        }
        const nested = deepFindValue(place, /^(phoneNumber|phone_number|phone|telephone|mobile|contactPhone|formattedPhone|internationalPhoneNumber)$/i, 0);
        return normalizeBusinessPhone(nested) || extractDeepPhone(place);
    }

    function extractSerperAddress(place) {
        if (!place || typeof place !== 'object') return '';
        const direct = firstValue(place, [
            'address', 'fullAddress', 'full_address', 'formattedAddress',
            'formatted_address', 'streetAddress', 'street_address', 'vicinity',
            'location.address', 'gps.address', 'place.address'
        ]);
        if (direct) return direct;
        const nested = deepFindValue(place, /^(address|fullAddress|formattedAddress|streetAddress|vicinity)$/i, 0);
        if (looksLikeAddressText(nested)) return nested;
        return extractDeepAddress(place);
    }

    function extractSerperWebsite(place) {
        if (!place || typeof place !== 'object') return '';
        const direct = firstValue(place, [
            'website', 'websiteUrl', 'websiteURL', 'websiteLink', 'webSite',
            'site', 'urlWebsite', 'domain', 'links.website', 'place.website'
        ]);
        const clean = cleanUrlLike(direct);
        if (clean) return clean;
        const nested = deepFindValue(place, /^(website|websiteUrl|websiteURL|websiteLink|webSite|site|urlWebsite|domain|officialWebsite)$/i, 0);
        return cleanUrlLike(nested);
    }

    function looksLikeAddressText(value) {
        const text = asString(value);
        if (!text) return false;
        if (/\b[1-9][0-9]{5}\b/.test(text)) return true;
        if (/\b(road|rd|street|st|lane|ln|park|para|bazar|market|sector|block|near|opposite|kolkata|calcutta|west bengal|india)\b/i.test(text)) return true;
        if (/^[0-9]{1,5}\s+[a-z]/i.test(text)) return true;
        return false;
    }

    function deepFindValue(obj, keyPattern, depth = 0) {
        if (!obj || depth > 4) return '';
        if (Array.isArray(obj)) {
            for (const item of obj) {
                const val = deepFindValue(item, keyPattern, depth + 1);
                if (val) return val;
            }
            return '';
        }
        if (typeof obj !== 'object') return '';
        for (const key of Object.keys(obj)) {
            const value = obj[key];
            if (keyPattern.test(String(key))) {
                const str = asString(value);
                if (str) return str;
            }
            if (value && typeof value === 'object') {
                const nested = deepFindValue(value, keyPattern, depth + 1);
                if (nested) return nested;
            }
        }
        return '';
    }


    function deepFindAllValues(obj, keyPattern, depth = 0, out = []) {
        if (!obj || depth > 6) return out;
        if (Array.isArray(obj)) {
            obj.forEach(item => deepFindAllValues(item, keyPattern, depth + 1, out));
            return out;
        }
        if (typeof obj !== 'object') return out;
        Object.keys(obj).forEach(key => {
            const value = obj[key];
            if (keyPattern.test(String(key))) {
                const str = asString(value);
                if (str) out.push(str);
            }
            if (value && typeof value === 'object') deepFindAllValues(value, keyPattern, depth + 1, out);
        });
        return out;
    }

    function firstMatchingDeepValue(obj, keyPattern, validator) {
        const values = deepFindAllValues(obj, keyPattern);
        for (const value of values) {
            if (!validator || validator(value)) return value;
        }
        return '';
    }

    function extractDeepPhone(obj) {
        const direct = firstMatchingDeepValue(obj, /^(phone|phoneNumber|phone_number|telephone|mobile|contactPhone|contact_number|businessPhone|primaryPhone|formattedPhone|internationalPhoneNumber|whatsapp)$/i, value => Boolean(normalizeBusinessPhone(value)));
        const phone = normalizeBusinessPhone(direct);
        if (phone) return phone;
        const contact = firstMatchingDeepValue(obj, /contact|contacts|businessContact/i, value => Boolean(extractIndianPhoneFromText(value)));
        return normalizeBusinessPhone(contact);
    }

    function extractDeepAddress(obj) {
        const keys = /^(address|fullAddress|formattedAddress|formatted_address|streetAddress|street_address|vicinity|businessAddress|locationAddress|addressLine|address_line)$/i;
        const direct = firstMatchingDeepValue(obj, keys, looksLikeAddressText);
        if (direct) return direct;
        const loose = firstMatchingDeepValue(obj, /address|street|vicinity|formatted|locality|postal/i, looksLikeAddressText);
        return loose || '';
    }

    function normalizeReviewCount(value) {
        const text = asString(value);
        if (!text) return '';
        const m = text.replace(/,/g, '').match(/\d+/);
        return m ? m[0] : '';
    }

    function normalizeRatingValue(value) {
        const text = asString(value);
        if (!text) return '';
        const m = text.match(/\d+(?:\.\d+)?/);
        if (!m) return '';
        const n = parseFloat(m[0]);
        return Number.isFinite(n) && n >= 0 && n <= 5 ? String(n) : '';
    }

    function enrichRatingAndReview(row, item) {
        row = row || {};
        if (!row.review) {
            const rating = firstValue(item, [
                'rating', 'review', 'stars', 'score', 'totalScore', 'total_score', 'ratingValue',
                'rating_value', 'averageRating', 'average_rating', 'aggregateRating.ratingValue',
                'reviews.rating', 'userRating'
            ]) || firstMatchingDeepValue(item, /^(rating|ratingValue|averageRating|stars|score|totalScore)$/i, normalizeRatingValue);
            const normalized = normalizeRatingValue(rating);
            if (normalized) row.review = normalized;
        }
        if (!row.total_reviews) {
            const count = firstValue(item, [
                'reviewsCount', 'reviews_count', 'reviewCount', 'review_count', 'ratingCount',
                'ratingsCount', 'numberOfReviews', 'number_of_reviews', 'user_ratings_total',
                'userRatingsTotal', 'aggregateRating.reviewCount', 'aggregateRating.ratingCount'
            ]) || firstMatchingDeepValue(item, /^(reviewsCount|reviewCount|ratingCount|ratingsCount|numberOfReviews|userRatingsTotal|user_ratings_total)$/i, normalizeReviewCount);
            const normalized = normalizeReviewCount(count);
            if (normalized) row.total_reviews = normalized;
        }
        return row;
    }

    function enrichLocationParts(row, item, meta, settings) {
        row = row || {};
        if (!row.city) {
            const city = firstValue(item, [
                'city', 'municipality', 'locality', 'town', 'district', 'address.city',
                'address.locality', 'address.town', 'location.city', 'location.locality',
                'place.city', 'place.locality', 'address_components.city'
            ]) || firstMatchingDeepValue(item, /^(city|locality|municipality|town|district)$/i, value => !/\d{5,}/.test(asString(value)));
            if (city) row.city = titleCaseSmall(city);
        }
        if (!row.state) {
            const state = firstValue(item, [
                'state', 'region', 'province', 'administrativeArea', 'administrative_area',
                'address.state', 'address.region', 'address.province', 'location.state',
                'location.region', 'place.state', 'address_components.state'
            ]) || firstMatchingDeepValue(item, /^(state|region|province|administrativeArea|administrative_area)$/i);
            if (state) row.state = titleCaseSmall(state);
        }
        if (!row.pincode) {
            const pin = firstValue(item, [
                'pincode', 'pinCode', 'postalCode', 'postal_code', 'postcode', 'postCode',
                'zip', 'zipCode', 'address.postalCode', 'address.postcode', 'location.postalCode'
            ]) || firstMatchingDeepValue(item, /postal|postcode|pincode|zip/i, value => /\b[1-9][0-9]{5}\b/.test(asString(value)));
            const m = asString(pin).match(/\b[1-9][0-9]{5}\b/);
            if (m) row.pincode = m[0];
        }
        completeAddressFromQuery(row, meta, settings);
        return row;
    }

    function hasLocalBusinessSignal(row) {
        if (!row || typeof row !== 'object') return false;
        return Boolean(
            normalizeBusinessPhone(row.phone || row.phoneNumber || row.telephone || row.mobile) ||
            (row.address && !isShortAddress(row.address)) ||
            row.pincode || row.city || row.state || row.review || row.total_reviews ||
            row.place_id || row.cid || /google\.[^/]+\/maps|maps\.app\.goo\.gl/i.test(asString(row.map_link || row.googleMapsUrl || row.mapsUrl || row.link))
        );
    }

    function completeAddressFromQuery(row, meta, settings) {
        row = row || {};
        const locationText = String((meta && (meta.location || meta.queryForApi || meta.query)) || '').trim();
        const inferredCity = row.city || inferLocationFromQuery(locationText);
        const inferredState = row.state || inferStateFromCity(inferredCity || locationText);
        if (!row.city && inferredCity) row.city = inferredCity;
        if (!row.state && inferredState) row.state = inferredState;
        if (!row.pincode && row.address) {
            const pin = String(row.address).match(/\b[1-9][0-9]{5}\b/);
            if (pin) row.pincode = pin[0];
        }
        if (row.address && isShortAddress(row.address)) {
            const additions = [];
            if (row.city && !new RegExp('\\b' + escapeRegExp(row.city) + '\\b', 'i').test(row.address)) additions.push(row.city);
            if (row.state && !new RegExp('\\b' + escapeRegExp(row.state) + '\\b', 'i').test(row.address)) additions.push(row.state);
            if (!/\bindia\b/i.test(row.address)) additions.push('India');
            if (additions.length) row.address = [row.address, ...additions].filter(Boolean).join(', ');
        }
        return row;
    }

    function enrichRowFromAddress(row, item, meta, settings) {
        row = row || {};
        const addressText = asString(row.address || firstValue(item, [
            'address', 'fullAddress', 'full_address', 'formattedAddress', 'formatted_address',
            'vicinity', 'streetAddress', 'street_address', 'addressLine', 'address_line',
            'location.address', 'location.formattedAddress', 'place.address'
        ]) || deepFindValue(item, /address|street|vicinity|formatted/i));
        if (addressText && !row.address) row.address = addressText;

        if (!row.pincode && addressText) {
            const pin = addressText.match(/\b[1-9][0-9]{5}\b/);
            if (pin) row.pincode = pin[0];
        }

        if (!row.state && addressText) {
            const lower = addressText.toLowerCase();
            const state = INDIAN_STATE_NAMES.find(st => lower.includes(st.toLowerCase()));
            if (state) row.state = state === 'Orissa' ? 'Odisha' : state;
        }

        if (!row.city && addressText) {
            const parts = addressText.split(',').map(x => x.trim()).filter(Boolean);
            let idx = -1;
            if (row.state) idx = parts.findIndex(part => part.toLowerCase().includes(String(row.state).toLowerCase()));
            if (idx > 0) {
                row.city = parts[idx - 1].replace(/\b[1-9][0-9]{5}\b/g, '').trim();
            }
            if (!row.city && row.pincode) {
                const pinIdx = parts.findIndex(part => part.includes(row.pincode));
                if (pinIdx > 0) row.city = parts[pinIdx - 1].replace(/\b[1-9][0-9]{5}\b/g, '').trim();
            }
            if (!row.city && parts.length >= 3) row.city = parts[parts.length - 3].replace(/\b[1-9][0-9]{5}\b/g, '').trim();
            if (row.city) row.city = titleCaseSmall(row.city);
        }

        if (!row.website) {
            const web = cleanUrlLike(firstValue(item, ['website', 'websiteUrl', 'websiteURL', 'websiteLink', 'linkToWebsite', 'url', 'domain', 'officialWebsite', 'merchantWebsite']));
            if (web) row.website = web;
        }

        if (!row.phone) {
            const phoneRaw = firstValue(item, [
                'phoneNumber', 'phone', 'telephone', 'mobile', 'contactPhone', 'internationalPhoneNumber',
                'phoneNumberUnformatted', 'phoneFormatted', 'phoneUnformatted', 'primaryPhone',
                'phones', 'phoneNumbers', 'contact.phone', 'contact.mobile', 'contacts.phone'
            ]) || deepFindValue(item, /phone|telephone|mobile|whatsapp|contact/i);
            const cleanPhone = normalizeBusinessPhone(phoneRaw);
            if (cleanPhone) row.phone = cleanPhone;
            else if (!row.address && looksLikeAddressText(phoneRaw)) row.address = phoneRaw;
        }
        // Do not scan the whole JSON for a phone number. Serper Maps responses contain
        // long IDs/CIDs that can look like Indian mobile numbers and create wrong phones.
        enrichRatingAndReview(row, item || {});
        enrichLocationParts(row, item || {}, meta, settings);
        completeAddressFromQuery(row, meta, settings);
        return row;
    }

    function extractPlaceIdFromUrl(url) {
        const text = String(url || '');
        if (!text) return '';
        try {
            const u = new URL(text);
            const q = String(u.searchParams.get('q') || '').trim();
            if (/^place_id:/i.test(q)) return q.slice(q.indexOf(':') + 1).trim();
            const qp = u.searchParams.get('query_place_id') || u.searchParams.get('place_id') || u.searchParams.get('placeid');
            if (qp) return qp.trim();
            const cid = u.searchParams.get('cid');
            if (cid) return cid.trim();
        } catch (e) {}
        const direct = text.match(/[?&]q=place_id(?::|%3A)([^&]+)/i);
        if (direct) { try { return decodeURIComponent(direct[1]).trim(); } catch (_) { return direct[1].trim(); } }
        const match = text.match(/(?:query_place_id|place_id|placeid|cid)=([^&]+)/i);
        if (!match) return '';
        try { return decodeURIComponent(match[1]).trim(); } catch (_) { return match[1].trim(); }
    }

    function normalizeMapUrl(url) {
        const text = String(url || '').trim();
        if (!text) return '';
        const placeId = extractPlaceIdFromUrl(text);
        if (placeId) return 'place:' + placeId.toLowerCase();
        return text.replace(/^https?:\/\/(www\.)?/i, '').replace(/[?#].*$/, '').replace(/\/$/, '').toLowerCase();
    }

    function rowFingerprint(row) {
        if (!row || typeof row !== 'object') return compactText(row);
        // Stable business identifiers must win over provider/search URLs.
        // Serper/Apify can attach the SAME search-page URL to many different
        // businesses; using that URL first collapsed valid rows (e.g. 60 read
        // but only a handful saved in the dashboard).
        const place = firstValue(row, PLACE_ID_FIELDS);
        if (place) return 'place:' + compactText(place);

        const scrappaBusinessId = asString(row.scrappa_business_id || row.business_id || row.businessId);
        // Scrappa Simple Search exposes business_id as its stable business-level
        // identifier. Prefer it before fallback name/address fingerprints so the
        // same listing repeated on later Scrappa pages is treated as one lead.
        if (scrappaBusinessId) return 'scrappa_business:' + compactText(scrappaBusinessId);

        const cid = asString(row.cid);
        // CID is a business-level identifier in Google/Serper payloads and our
        // normalizer also creates a deterministic CID fallback when needed.
        if (cid && compactText(cid).length >= 6) return 'cid:' + compactText(cid);

        const phone = normalizePhone(row.phone || row.phoneNumber || row.phone_number || '');
        const name = compactText(row.company_name || row.name || row.title || '');
        const address = compactText(row.address || row.fullAddress || row.formattedAddress || '');
        const website = compactText(row.website || row.websiteUrl || '');
        if (phone && name) return 'phone_name:' + phone + '|' + name;
        if (name && address) return 'name_address:' + name + '|' + address;
        if (website && name) return 'site_name:' + website + '|' + name;

        // URL is only a late fallback. This preserves uniqueness when a provider
        // exposes query/searchPageUrl rather than a business-specific Maps URL.
        const urlKey = normalizeMapUrl(row.map_link || row.mapLink || row.googleMapsUrl || row.url || row.link);
        if (urlKey) return 'url:' + urlKey;
        return 'hash:' + hashString(JSON.stringify(row));
    }


    const RESULT_PREVIEW_LIMIT = 250;
    // Route metadata contains no provider secrets; actual providerProxy calls revalidate everything.



    /**
     * IndexedDB-backed canonical result store.
     * chrome.storage.local keeps only a small recent preview so progress writes
     * do not repeatedly serialize the full result set. The dashboard hydrates
     * the complete collection from this store on load.
     */
    const ResultStore = {
        dbName: 'PocketLeadsDB',
        storeName: 'results',
        dbVersion: 4,
        _dbPromise: null,
        _keyCache: null,
        _keyCachePromise: null,
        _metricWebsites: null,
        _metricPhones: null,
        _metricEmails: null,
        _writeChain: Promise.resolve(),

        _indexRowMetrics(row) {
            if (!row || typeof row !== 'object') return;
            if (!(this._metricWebsites instanceof Set)) this._metricWebsites = new Set();
            if (!(this._metricPhones instanceof Set)) this._metricPhones = new Set();
            if (!(this._metricEmails instanceof Set)) this._metricEmails = new Set();
            const getVal = (typeof PocketLeadsResultQuery !== 'undefined' && PocketLeadsResultQuery && typeof PocketLeadsResultQuery.value === 'function')
                ? (r, k) => PocketLeadsResultQuery.value(r, k)
                : (r, k) => r[k] || '';
            const w = String(getVal(row, 'website') || row.website || '').trim().toLowerCase();
            const p = String(getVal(row, 'phone_number') || row.phone_number || row.phone || '').replace(/\D/g, '').replace(/^0+/, '');
            const em = String(getVal(row, 'email_1') || row.email_1 || row.email || '').trim().toLowerCase();
            if (w) this._metricWebsites.add(w);
            if (p.length >= 8) this._metricPhones.add(p);
            if (em && !/^(no email|can't access|blacklisted)/i.test(em) && em.includes('@')) this._metricEmails.add(em);
        },

        open() {
            if (this._dbPromise) return this._dbPromise;
            this._dbPromise = new Promise((resolve, reject) => {
                try {
                    const request = indexedDB.open(this.dbName, this.dbVersion);
                    request.onupgradeneeded = event => {
                        const db = event.target.result;
                        if (!db.objectStoreNames.contains(this.storeName)) {
                            const store = db.createObjectStore(this.storeName, { keyPath: 'key' });
                            store.createIndex('cid', 'cid', { unique: false });
                            store.createIndex('placeId', 'placeId', { unique: false });
                            store.createIndex('updatedAt', 'updatedAt', { unique: false });
                        }
                        if (!db.objectStoreNames.contains('history')) {
                            const history = db.createObjectStore('history', { keyPath: 'id' });
                            history.createIndex('timestamp', 'timestamp', { unique: false });
                        }
                        if (!db.objectStoreNames.contains('jobs')) {
                            const jobs = db.createObjectStore('jobs', { keyPath: 'id' });
                            jobs.createIndex('runId', 'runId', { unique: false });
                            jobs.createIndex('status', 'status', { unique: false });
                            jobs.createIndex('updatedAt', 'updatedAt', { unique: false });
                        }
                        if (!db.objectStoreNames.contains('history_rows')) {
                            db.createObjectStore('history_rows', { keyPath: 'id' });
                        }
                    };
                    request.onsuccess = () => resolve(request.result);
                    request.onerror = () => reject(request.error || new Error('Unable to open IndexedDB result store.'));
                    request.onblocked = () => warn('IndexedDB result store upgrade blocked by another extension page.');
                } catch (err) {
                    reject(err);
                }
            }).catch(err => {
                this._dbPromise = null;
                throw err;
            });
            return this._dbPromise;
        },

        async getAllRecords() {
            const db = await this.open();
            return new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(this.storeName, 'readonly');
                    const req = tx.objectStore(this.storeName).getAll();
                    req.onsuccess = () => resolve(Array.isArray(req.result) ? req.result : []);
                    req.onerror = () => reject(req.error || new Error('Unable to read IndexedDB results.'));
                } catch (err) { reject(err); }
            });
        },

        async compactCanonicalRecords(records) {
            const source = Array.isArray(records) ? records.filter(Boolean) : [];
            if (!source.length) return [];
            const groups = new Map();
            source.forEach(record => {
                const fp = record && record.row ? rowFingerprint(record.row) : String(record && record.key || '');
                if (!fp) return;
                if (!groups.has(fp)) groups.set(fp, []);
                groups.get(fp).push(record);
            });
            let needsCompaction = false;
            groups.forEach((group, fp) => {
                if (group.length > 1 || !group.some(record => String(record.key || '') === fp)) needsCompaction = true;
            });
            if (!needsCompaction) return source;

            const canonical = [];
            groups.forEach((group, fp) => {
                const chosen = group.slice().sort((a, b) => String(b.updatedAt || b.createdAt || '').localeCompare(String(a.updatedAt || a.createdAt || '')))[0];
                canonical.push(Object.assign({}, chosen, { key: fp }));
            });
            const db = await this.open();
            await new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(this.storeName, 'readwrite');
                    const store = tx.objectStore(this.storeName);
                    source.forEach(record => { if (record && record.key) store.delete(record.key); });
                    canonical.forEach(record => store.put(record));
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error || new Error('Unable to compact canonical results.'));
                    tx.onabort = () => reject(tx.error || new Error('Canonical result compaction aborted.'));
                } catch (err) { reject(err); }
            });
            return canonical;
        },

        async getAll() {
            await this.ensureKeyCache();
            const records = await this.getAllRecords();
            return records
                .sort((a, b) => String(a.createdAt || '').localeCompare(String(b.createdAt || '')))
                .map(record => record && record.row)
                .filter(Boolean);
        },

        async query(options) {
            const o=options||{},skip=Math.max(0,Number(o.offset)||0),limit=Math.min(5000,Math.max(1,Number(o.limit)||25));
            const isUnfiltered = !o.facet &&
                !String(o.status || '').trim() &&
                !String(o.query || '').trim() &&
                !Object.values(o.columnQueries || {}).some(v => String(v || '').trim()) &&
                !(Array.isArray(o.valueFilters) && o.valueFilters.length > 0);
            if (isUnfiltered) {
                await this.ensureKeyCache();
                const totalCount = this._keyCache instanceof Set ? this._keyCache.size : 0;
                const cachedMetrics = {
                    website: this._metricWebsites instanceof Set ? this._metricWebsites.size : 0,
                    phone_number: this._metricPhones instanceof Set ? this._metricPhones.size : 0,
                    email_1: this._metricEmails instanceof Set ? this._metricEmails.size : 0
                };
                if (o.metricsOnly) {
                    return { rows: [], count: totalCount, values: [], metrics: cachedMetrics };
                }
                const db = await this.open();
                if (skip >= totalCount) {
                    return { rows: [], count: totalCount, values: [], metrics: cachedMetrics };
                }
                return new Promise((resolve, reject) => {
                    const tx = db.transaction(this.storeName, 'readonly'), request = tx.objectStore(this.storeName).openCursor();
                    const rows = [];
                    let advanced = false, settled = false;
                    request.onsuccess = e => {
                        if (settled) return;
                        const cursor = e.target.result;
                        if (!cursor) {
                            settled = true;
                            return resolve({ rows, count: totalCount, values: [], metrics: cachedMetrics });
                        }
                        if (!advanced && skip > 0) {
                            advanced = true;
                            cursor.advance(skip);
                            return;
                        }
                        advanced = true;
                        if (cursor.value && cursor.value.row) rows.push(cursor.value.row);
                        if (rows.length >= limit) {
                            settled = true;
                            return resolve({ rows, count: totalCount, values: [], metrics: cachedMetrics });
                        }
                        cursor.continue();
                    };
                    request.onerror = () => { if (!settled) { settled = true; reject(request.error); } };
                    tx.onabort = () => { if (!settled) { settled = true; reject(tx.error || Error('Result query interrupted')); } };
                });
            }
            const db=await this.open();
            return new Promise((resolve,reject)=>{
                const tx=db.transaction(this.storeName,'readonly'),request=tx.objectStore(this.storeName).openCursor();
                const rows=[],values=new Set(),websites=new Set(),phones=new Set(),emails=new Set();let count=0;
                request.onsuccess=e=>{const cursor=e.target.result;if(!cursor)return resolve({rows,count,values:[...values].sort(),metrics:{website:websites.size,phone_number:phones.size,email_1:emails.size}});
                    const row=cursor.value.row;
                    if(row && PocketLeadsResultQuery.matches(row,o)){
                        if(o.metrics){const w=String(PocketLeadsResultQuery.value(row,'website')).trim().toLowerCase(),p=String(PocketLeadsResultQuery.value(row,'phone_number')).replace(/\D/g,'').replace(/^0+/,''),em=String(PocketLeadsResultQuery.value(row,'email_1')).trim().toLowerCase();if(w)websites.add(w);if(p.length>=8)phones.add(p);if(em&&!/^(no email|can't access|blacklisted)/i.test(em)&&em.includes('@'))emails.add(em);}
                        if(o.facet)values.add(String(PocketLeadsResultQuery.value(row,o.facet)).trim());
                        if(count>=skip&&rows.length<limit)rows.push(row);count++;
                    }
                    cursor.continue();
                };
                request.onerror=()=>reject(request.error);tx.onabort=()=>reject(tx.error||Error('Result query interrupted'));
            });
        },

        async getPage(offset, limit) {
            await this.ensureKeyCache();
            const start = Math.max(0, parseInt(offset, 10) || 0);
            const size = Math.max(1, Math.min(5000, parseInt(limit, 10) || 1000));
            const db = await this.open();
            return new Promise((resolve, reject) => {
                const rows = [];
                try {
                    const tx = db.transaction(this.storeName, 'readonly');
                    const req = tx.objectStore(this.storeName).openCursor();
                    let advanced = false;
                    req.onsuccess = event => {
                        const cursor = event.target.result;
                        if (!cursor || rows.length >= size) return resolve(rows);
                        if (!advanced && start > 0) {
                            advanced = true;
                            cursor.advance(start);
                            return;
                        }
                        advanced = true;
                        if (cursor.value && cursor.value.row) rows.push(cursor.value.row);
                        cursor.continue();
                    };
                    req.onerror = () => reject(req.error || new Error('Unable to page IndexedDB results.'));
                } catch (err) { reject(err); }
            });
        },

        async ensureKeyCache() {
            if (this._keyCache instanceof Set) return this._keyCache;
            if (this._keyCachePromise) return this._keyCachePromise;
            this._keyCachePromise = this.getAllRecords()
                .then(records => this.compactCanonicalRecords(records))
                .then(records => {
                    this._keyCache = new Set();
                    this._metricWebsites = new Set();
                    this._metricPhones = new Set();
                    this._metricEmails = new Set();
                    records.forEach(record => {
                        const k = String(record && record.key || '');
                        if (k) this._keyCache.add(k);
                        if (record && record.row) this._indexRowMetrics(record.row);
                    });
                    return this._keyCache;
                })
                .finally(() => {
                    this._keyCachePromise = null;
                });
            return this._keyCachePromise;
        },

        async getKeySet() {
            const cache = await this.ensureKeyCache();
            return new Set(cache);
        },

        async count() {
            const cache = await this.ensureKeyCache();
            if (cache instanceof Set) return cache.size;
            const db = await this.open();
            return new Promise((resolve,reject) => {
                const tx = db.transaction(this.storeName,'readonly');
                const request = tx.objectStore(this.storeName).count();
                let count = 0;
                request.onsuccess = () => { count = request.result; };
                tx.oncomplete = () => resolve(count);
                tx.onerror = tx.onabort = () => reject(tx.error || Error('Result count unavailable'));
            });
        },

        async _upsertManyNow(rows) {
            const cleanRows = (Array.isArray(rows) ? rows : []).filter(row => row && typeof row === 'object');
            if (!cleanRows.length) return { added: 0, updated: 0, total: await this.count().catch(() => 0), addedRows: [] };
            const existingKeys = await this.ensureKeyCache();
            const db = await this.open();
            const addedRows = [];
            const newlyAddedKeys = [];
            let added = 0;
            let updated = 0;
            try {
                await new Promise((resolve, reject) => {
                    try {
                        const tx = db.transaction(this.storeName, 'readwrite');
                        const store = tx.objectStore(this.storeName);
                        tx.oncomplete = () => resolve();
                        tx.onerror = () => reject(tx.error || new Error('Unable to write IndexedDB results.'));
                        tx.onabort = () => reject(tx.error || new Error('IndexedDB result write aborted.'));
                        cleanRows.forEach(row => {
                            const key = rowFingerprint(row);
                            if (!key) return;
                            const isNew = !existingKeys.has(key);
                            this._indexRowMetrics(row);
                            if (isNew) {
                                existingKeys.add(key);
                                newlyAddedKeys.push(key);
                                added += 1;
                                addedRows.push(row);
                            } else {
                                updated += 1;
                            }
                            store.put({
                                key,
                                cid: asString(row.cid),
                                placeId: firstValue(row, PLACE_ID_FIELDS) || asString(row.cid),
                                createdAt: row.scraped_at || row.createdAt || nowIso(),
                                updatedAt: nowIso(),
                                row
                            });
                        });
                    } catch (err) { reject(err); }
                });
            } catch (err) {
                newlyAddedKeys.forEach(key => existingKeys.delete(key));
                throw err;
            }
            return { added, updated, total: existingKeys.size, addedRows };
        },

        upsertMany(rows) {
            const run = this._writeChain.then(() => this._upsertManyNow(rows), () => this._upsertManyNow(rows));
            this._writeChain = run.catch(() => null);
            return run;
        },

        replaceAll(rows) {
            const cleanRows = Array.isArray(rows) ? rows : [];
            const run = this._writeChain.then(async () => {
                await this._clearNow();
                return this._upsertManyNow(cleanRows);
            }, async () => {
                await this._clearNow();
                return this._upsertManyNow(cleanRows);
            });
            this._writeChain = run.catch(() => null);
            return run;
        },

        async _clearNow() {
            const db = await this.open();
            await new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(this.storeName, 'readwrite');
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error || new Error('Unable to clear IndexedDB results.'));
                    tx.onabort = () => reject(tx.error || new Error('IndexedDB clear aborted.'));
                    tx.objectStore(this.storeName).clear();
                } catch (err) { reject(err); }
            });
            this._keyCache = new Set();
            this._metricWebsites = new Set();
            this._metricPhones = new Set();
            this._metricEmails = new Set();
            try {
                if (typeof DailyController !== "undefined" && DailyController) {
                    DailyController._authoritativeResultCount = 0;
                    DailyController._latestCollectPreview = [];
                }
            } catch (_) {}
            return true;
        },

        async _deleteRowsNow(rowsOrKeys) {
            const targets = Array.isArray(rowsOrKeys) ? rowsOrKeys : [];
            if (!targets.length) return { deleted: 0, total: await this.count().catch(() => 0) };
            const targetKeys = new Set();
            const targetCids = new Set();
            const targetPlaceIds = new Set();
            targets.forEach(item => {
                if (!item) return;
                if (typeof item === 'string') {
                    targetKeys.add(item.trim());
                    targetCids.add(item.trim());
                    return;
                }
                if (typeof item === 'object') {
                    const fp = rowFingerprint(item);
                    if (fp) targetKeys.add(String(fp));
                    if (item.key) targetKeys.add(String(item.key));
                    if (item.cid) targetCids.add(String(item.cid).trim());
                    const pid = firstValue(item, PLACE_ID_FIELDS);
                    if (pid) {
                        targetPlaceIds.add(String(pid).trim());
                        targetKeys.add('place:' + compactText(pid));
                    }
                    if (item.scrappa_business_id || item.business_id) {
                        targetKeys.add('scrappa_business:' + compactText(item.scrappa_business_id || item.business_id));
                    }
                }
            });
            const records = await this.getAllRecords();
            const toDeleteKeys = [];
            const remainingRows = [];
            records.forEach(rec => {
                if (!rec) return;
                const rKey = String(rec.key || '');
                const rRow = rec.row || {};
                const rFp = rowFingerprint(rRow);
                const rCid = String(rec.cid || rRow.cid || '').trim();
                const rPid = String(rec.placeId || rRow.place_id || rRow.placeId || '').trim();
                if (
                    (rKey && targetKeys.has(rKey)) ||
                    (rFp && targetKeys.has(rFp)) ||
                    (rCid && targetCids.has(rCid)) ||
                    (rPid && targetPlaceIds.has(rPid))
                ) {
                    if (rKey) toDeleteKeys.push(rKey);
                } else if (rec.row) {
                    remainingRows.push(rec.row);
                }
            });
            if (toDeleteKeys.length) {
                const db = await this.open();
                await new Promise((resolve, reject) => {
                    try {
                        const tx = db.transaction(this.storeName, 'readwrite');
                        const store = tx.objectStore(this.storeName);
                        toDeleteKeys.forEach(k => store.delete(k));
                        tx.oncomplete = () => resolve(true);
                        tx.onerror = () => reject(tx.error || new Error('Unable to delete IndexedDB rows.'));
                        tx.onabort = () => reject(tx.error || new Error('IndexedDB delete aborted.'));
                    } catch (err) { reject(err); }
                });
            }
            this._keyCache = new Set();
            this._metricWebsites = new Set();
            this._metricPhones = new Set();
            this._metricEmails = new Set();
            const allRemaining = await this.getAllRecords();
            allRemaining.forEach(rec => {
                if (rec && rec.key) this._keyCache.add(String(rec.key));
                if (rec && rec.row) this._indexRowMetrics(rec.row);
            });
            try {
                if (typeof DailyController !== "undefined" && DailyController) {
                    DailyController._authoritativeResultCount = this._keyCache.size;
                    DailyController._latestCollectPreview = remainingRows.slice(0, 250);
                }
            } catch (_) {}
            return { deleted: toDeleteKeys.length, total: this._keyCache.size };
        },

        deleteRows(rowsOrKeys) {
            const run = this._writeChain.then(() => this._deleteRowsNow(rowsOrKeys), () => this._deleteRowsNow(rowsOrKeys));
            this._writeChain = run.catch(() => null);
            return run;
        },

        clear() {
            const run = this._writeChain.then(() => this._clearNow(), () => this._clearNow());
            this._writeChain = run.catch(() => null);
            return run;
        },

        async purgePendingProfiles() {
            const records = await this.getAllRecords();
            const pending = records.filter(record => {
                const row = record && record.row || {};
                return row._profile_pending === true || /google_maps_place_id_pending/i.test(String(row._source_detail || ''));
            });
            if (!pending.length) return 0;
            const db = await this.open();
            await new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(this.storeName, 'readwrite');
                    const store = tx.objectStore(this.storeName);
                    pending.forEach(record => { if (record && record.key) store.delete(record.key); });
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error || new Error('Unable to remove legacy pending profile rows.'));
                } catch (err) { reject(err); }
            });
            if (this._keyCache instanceof Set) pending.forEach(record => this._keyCache.delete(String(record && record.key || '')));
            return pending.length;
        },

        async migrateFromLocal(rows) {
            const clean = Array.isArray(rows) ? rows.filter(Boolean) : [];
            if (!clean.length) return { added: 0, updated: 0, total: await this.count().catch(() => 0), addedRows: [] };
            return this.upsertMany(clean);
        }
    };

    /**
     * Durable profile-job queue for large Google Maps runs.
     * chrome.storage keeps only a small UI/resume preview; IndexedDB is the
     * authoritative queue so 10k/50k Place ID runs are not truncated.
     */
    const JobStore = {
        storeName: 'jobs',
        makeId(runId, placeId) {
            return String(runId || 'run') + '|' + String(placeId || '').trim().toLowerCase();
        },
        async getRun(runId) {
            if (!runId) return [];
            const db = await ResultStore.open();
            return new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(this.storeName, 'readonly');
                    const index = tx.objectStore(this.storeName).index('runId');
                    const req = index.getAll(String(runId));
                    req.onsuccess = () => resolve((Array.isArray(req.result) ? req.result : []).map(r => r && r.job).filter(Boolean));
                    req.onerror = () => reject(req.error || new Error('Unable to read durable job queue.'));
                } catch (err) { reject(err); }
            });
        },
        async hasPending(runId) {
            if (!runId) return false;
            const db = await ResultStore.open();
            return new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(this.storeName, 'readonly');
                    const index = tx.objectStore(this.storeName).index('runId');
                    const req = index.openCursor(IDBKeyRange.only(String(runId)));
                    let settled = false;
                    req.onsuccess = event => {
                        if (settled) return;
                        const cursor = event.target.result;
                        if (!cursor) { settled = true; return resolve(false); }
                        const status = String(cursor.value && cursor.value.status || '').toLowerCase();
                        if (/^(api_returned|pending|retry_pending|dom_running|dom_failed)$/.test(status)) {
                            settled = true;
                            return resolve(true);
                        }
                        cursor.continue();
                    };
                    req.onerror = () => { if (!settled) { settled = true; reject(req.error || new Error('Unable to inspect durable job queue.')); } };
                } catch (err) { reject(err); }
            });
        },
        async put(runId, job) {
            if (!runId || !job || !job.placeId) return false;
            return this.putMany(runId, [job]);
        },
        async putMany(runId, jobs) {
            const clean = (Array.isArray(jobs) ? jobs : []).filter(j => j && j.placeId);
            if (!runId || !clean.length) return false;
            const db = await ResultStore.open();
            return new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(this.storeName, 'readwrite');
                    const store = tx.objectStore(this.storeName);
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error || new Error('Unable to persist durable job queue.'));
                    tx.onabort = () => reject(tx.error || new Error('Durable job queue write aborted.'));
                    clean.forEach(job => store.put({
                        id: this.makeId(runId, job.placeId),
                        runId: String(runId),
                        status: String(job.status || ''),
                        updatedAt: job.lastUpdatedAt || nowIso(),
                        job: Object.assign({}, job)
                    }));
                } catch (err) { reject(err); }
            });
        },
        async clearRun(runId) {
            if (!runId) return false;
            const db = await ResultStore.open();
            return new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(this.storeName, 'readwrite');
                    const store = tx.objectStore(this.storeName);
                    const index = store.index('runId');
                    const req = index.openKeyCursor(IDBKeyRange.only(String(runId)));
                    req.onsuccess = e => {
                        const cursor = e.target.result;
                        if (!cursor) return;
                        store.delete(cursor.primaryKey);
                        cursor.continue();
                    };
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error || new Error('Unable to clear durable job queue.'));
                    tx.onabort = () => reject(tx.error || new Error('Durable job queue clear aborted.'));
                } catch (err) { reject(err); }
            });
        },
        async clear() {
            const db = await ResultStore.open();
            return new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(this.storeName, 'readwrite');
                    const req = tx.objectStore(this.storeName).clear();
                    req.onsuccess = () => resolve(true);
                    req.onerror = () => reject(req.error || new Error('Unable to clear job queue.'));
                } catch (err) { reject(err); }
            });
        }
    };

    const HistoryStore = {
        storeName: 'history',
        rowsStoreName: 'history_rows',
        stripRows(session) {
            if (!session || typeof session !== 'object') return session;
            const rows = Array.isArray(session.rows) ? session.rows : [];
            const meta = Object.assign({}, session);
            delete meta.rows;
            meta.hasRows = session.hasRows !== false && (rows.length > 0 || !!session.hasRows);
            meta.rowCount = Math.max(0, parseInt(session.rowCount || session.leadCount, 10) || rows.length);
            meta.leadCount = Math.max(0, parseInt(session.leadCount, 10) || meta.rowCount);
            return meta;
        },
        async getAll() {
            const db = await ResultStore.open();
            const sessions = await new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(this.storeName, 'readonly');
                    const req = tx.objectStore(this.storeName).getAll();
                    req.onsuccess = () => resolve(Array.isArray(req.result) ? req.result : []);
                    req.onerror = () => reject(req.error || new Error('Unable to read scraping history.'));
                } catch (err) { reject(err); }
            });
            // Lazy one-time migration from v81 where full rows lived inside the
            // metadata record. This keeps future history-list reads lightweight.
            const legacy = sessions.filter(session => session && Array.isArray(session.rows) && session.rows.length);
            if (legacy.length) {
                for (const session of legacy) await this.put(session).catch(() => false);
            }
            return sessions.map(session => this.stripRows(session)).sort((a, b) => String(b.timestamp || '').localeCompare(String(a.timestamp || '')));
        },
        async get(id) {
            if (!id) return null;
            const db = await ResultStore.open();
            return new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction([this.storeName, this.rowsStoreName], 'readonly');
                    const metaReq = tx.objectStore(this.storeName).get(String(id));
                    const rowsReq = tx.objectStore(this.rowsStoreName).get(String(id));
                    tx.oncomplete = () => {
                        const meta = metaReq.result;
                        if (!meta) return resolve(null);
                        const rowRecord = rowsReq.result;
                        resolve(Object.assign({}, meta, { rows: rowRecord && Array.isArray(rowRecord.rows) ? rowRecord.rows : [] }));
                    };
                    tx.onerror = () => reject(tx.error || new Error('Unable to load scraping history rows.'));
                } catch (err) { reject(err); }
            });
        },
        async put(session) {
            if (!session || !session.id) return false;
            const rows = Array.isArray(session.rows) ? session.rows : [];
            const meta = this.stripRows(session);
            const db = await ResultStore.open();
            return new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction([this.storeName, this.rowsStoreName], 'readwrite');
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error || new Error('Unable to save scraping history.'));
                    tx.onabort = () => reject(tx.error || new Error('Scraping history write aborted.'));
                    tx.objectStore(this.storeName).put(meta);
                    if (rows.length) tx.objectStore(this.rowsStoreName).put({ id: String(session.id), rows });
                } catch (err) { reject(err); }
            });
        },
        async updateMeta(id, patch) {
            if (!id || !patch || typeof patch !== 'object') return false;
            const db = await ResultStore.open();
            return new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(this.storeName, 'readwrite');
                    const store = tx.objectStore(this.storeName);
                    const req = store.get(String(id));
                    req.onsuccess = () => {
                        const session = req.result;
                        if (!session) return;
                        const safePatch = Object.assign({}, patch);
                        delete safePatch.rows;
                        store.put(Object.assign({}, session, safePatch));
                    };
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error || new Error('Unable to update scraping history.'));
                } catch (err) { reject(err); }
            });
        },
        async remove(id) {
            if (!id) return false;
            const db = await ResultStore.open();
            return new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction([this.storeName, this.rowsStoreName], 'readwrite');
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error || new Error('Unable to delete scraping history.'));
                    tx.objectStore(this.storeName).delete(String(id));
                    tx.objectStore(this.rowsStoreName).delete(String(id));
                } catch (err) { reject(err); }
            });
        },
        async clear() {
            const db = await ResultStore.open();
            return new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction([this.storeName, this.rowsStoreName], 'readwrite');
                    tx.objectStore(this.storeName).clear();
                    tx.objectStore(this.rowsStoreName).clear();
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error || new Error('Unable to clear scraping history.'));
                } catch (err) { reject(err); }
            });
        }
    };

    function getCountryCodeByName(country) {
        const clean = String(country || '').trim();
        if (!clean) return '';
        const lower = clean.toLowerCase();
        if (COUNTRY_NAME_TO_CODE[lower]) return COUNTRY_NAME_TO_CODE[lower];
        try {
            if (typeof self !== 'undefined' && self.countryIsoCodes && self.countryIsoCodes[clean]) {
                return String(self.countryIsoCodes[clean] || '').trim().toUpperCase();
            }
        } catch (e) {}
        return '';
    }

    function ensureQueryHasCountry(query, country) {
        const q = String(query || '').trim();
        const c = String(country || '').trim();
        if (!q || !c) return q;
        const qLower = q.toLowerCase();
        const cLower = c.toLowerCase();
        if (qLower.includes(cLower) || (cLower === 'india' && /\b(india|bharat)\b/i.test(q))) return q;
        return (q + ' ' + c).replace(/\s+/g, ' ').trim();
    }

    function buildCountryRestrictedQuery(query, country) {
        // Country is appended before the API call (especially for Serper) so the
        // remote API itself returns fewer wrong-country results. This reduces
        // wasted credits compared with fetching broad global rows and filtering
        // them only after the response arrives.
        return normalizeQueryTextForApi(ensureQueryHasCountry(query, country || DEFAULT_SETTINGS.countryFilter || 'India'));
    }

    function sanitizeApiToken(token, provider) {
        let t = String(token || '')
            .replace(/[\u200B-\u200D\uFEFF\u00A0]/g, '')
            .trim();
        // Fix common copy/paste formats from dashboards, docs, headers, curl commands, and Sheets notes.
        t = t.replace(/^[`'\"<>\[\]{}()]+|[`'\"<>\[\]{}(),;]+$/g, '').trim();
        t = t.replace(/^(?:x-api-key|x_api_key|api-key|apikey|api key|authorization)\s*[:=]\s*/i, '').trim();
        t = t.replace(/^(?:bearer|token)\s+/i, '').trim();
        const apifyMatch = t.match(/apify_[A-Za-z0-9_\-]{20,}/);
        if ((provider || '').toLowerCase() === 'apify' && apifyMatch) t = apifyMatch[0];
        // API keys should never contain whitespace. This also fixes keys copied with line breaks.
        t = t.replace(/\s+/g, '');
        return t;
    }

    function isPincodeSearch(meta) {
        const text = String([
            meta && meta.location,
            meta && meta.queryForApi,
            meta && meta.query
        ].filter(Boolean).join(' '));
        return /\b[1-9][0-9]{5}\b/.test(text);
    }

    function getSelectedPageCount(settings) {
        const raw = parseInt(settings && settings.maxPagesPerSearch, 10);
        if (Number.isFinite(raw) && raw > 0) return Math.max(1, Math.min(AUTO_CITY_MAX_PAGES, raw));
        const legacyMax = parseInt(settings && settings.maxResultsPerSearch, 10);
        if (Number.isFinite(legacyMax) && legacyMax > 0) return Math.max(1, Math.min(AUTO_CITY_MAX_PAGES, Math.ceil(legacyMax / SERPER_PAGE_SIZE)));
        return AUTO_CITY_MAX_PAGES;
    }

    function getEffectivePageCount(meta, settings) {
        const selected = getSelectedPageCount(settings);
        const isPincode = isPincodeSearch(meta);
        const pincodeCap = canonicalProviderKey(settings && settings.provider) === 'serper' ? SERPER_PINCODE_MAX_PAGES : PINCODE_MAX_PAGES;
        const cap = isPincode ? pincodeCap : AUTO_CITY_MAX_PAGES;
        return {
            selected,
            cap,
            effective: Math.max(1, Math.min(selected || cap, cap)),
            isPincode
        };
    }

    const SettingsManager = {
        defaults: DEFAULT_SETTINGS,

        normalize(settings) {
            const merged = Object.assign({}, DEFAULT_SETTINGS, settings || {});
            merged.provider = canonicalProviderKey(merged.provider || 'apify') || 'apify';
            // Credentials intentionally remain blank in v82; server-side proxy owns all provider secrets.
            merged.apiToken = '';
            merged.secureProxy = true;
            merged.actorId = '';
            merged.sourceId = '';
            merged.apiKeyRow = parseInt(merged.apiKeyRow || merged.apifyKeyRow, 10) || 0;
            merged.apifyKeyRow = merged.apiKeyRow;
            merged.apiUsageLimit = Math.max(1, parseInt(merged.apiUsageLimit || merged.apifyUsageLimit, 10) || DEFAULT_SETTINGS.apiUsageLimit);
            merged.apifyUsageLimit = merged.apiUsageLimit;
            const parsedPages = parseInt(merged.maxPagesPerSearch, 10);
            const legacyMax = parseInt(merged.maxResultsPerSearch, 10);
            let pages = Number.isFinite(parsedPages) && parsedPages > 0 ? parsedPages : null;
            if (!pages && Number.isFinite(legacyMax) && legacyMax > 0) pages = Math.ceil(legacyMax / 20);
            if (!pages) pages = DEFAULT_SETTINGS.maxPagesPerSearch || AUTO_CITY_MAX_PAGES;
            merged.autoPageMode = merged.autoPageMode !== false;
            // Auto page mode ignores the old dropdown value and uses the internal safe cap.
            merged.maxPagesPerSearch = merged.autoPageMode ? AUTO_CITY_MAX_PAGES : Math.max(1, Math.min(AUTO_CITY_MAX_PAGES, pages));
            // Keep the old setting as a derived value for Apify actors and older code.
            merged.maxResultsPerSearch = merged.maxPagesPerSearch * SERPER_PAGE_SIZE;
            merged.countryFilter = String(merged.countryFilter || DEFAULT_SETTINGS.countryFilter || '').trim();
            merged.countryCodeFilter = String(merged.countryCodeFilter || getCountryCodeByName(merged.countryFilter) || DEFAULT_SETTINGS.countryCodeFilter || '').trim().toUpperCase();
            merged.enforceCountryFilter = merged.enforceCountryFilter !== false;
            merged.streamResults = merged.streamResults !== false;
            merged.pollIntervalMs = Math.max(250, parseInt(merged.pollIntervalMs, 10) || DEFAULT_SETTINGS.pollIntervalMs);
            merged.streamPollIntervalMs = Math.max(250, parseInt(merged.streamPollIntervalMs, 10) || DEFAULT_SETTINGS.streamPollIntervalMs);
            merged.pollTimeoutMs = Math.max(30000, parseInt(merged.pollTimeoutMs, 10) || DEFAULT_SETTINGS.pollTimeoutMs);
            merged.datasetPageSize = Math.max(100, parseInt(merged.datasetPageSize, 10) || DEFAULT_SETTINGS.datasetPageSize);
            return merged;
        },

        async load() {
            const local = await getLocalAsync();
            const raw = Object.assign({}, (local && local.apifySettings) || {});
            if (local && local.country) raw.countryFilter = local.country;
            if (local && local.countryCode) raw.countryCodeFilter = local.countryCode;
            return this.normalize(raw);
        },

        async save(patch) {
            const local = await getLocalAsync();
            local.apifySettings = this.normalize(Object.assign({}, local.apifySettings || {}, patch || {}));
            await setLocalAsync(local);
            return local.apifySettings;
        },

        validate(settings) {
            const normalized = this.normalize(settings);
            if (!normalized.secureProxy || !normalized.apiKeyRow) {
                throw new Error('Secure provider setup was not returned by backend. Please check admin API sheet setup and deploy Apps Script v23.');
            }
            return normalized;
        }
    };

    const ApifyClient = {
        normalizeActorId(actorId) {
            let id = String(actorId || '').trim();
            if (!id) return '';
            try {
                if (/^https?:\/\//i.test(id)) {
                    const u = new URL(id);
                    if (/api\.apify\.com$/i.test(u.hostname)) {
                        const parts = u.pathname.split('/').filter(Boolean);
                        const idx = parts.indexOf('acts');
                        if (idx >= 0 && parts[idx + 1]) id = decodeURIComponent(parts[idx + 1]);
                    } else if (/apify\.com$/i.test(u.hostname)) {
                        const parts = u.pathname.split('/').filter(Boolean);
                        const start = parts[0] === 'store' ? 1 : 0;
                        if (parts[start] && parts[start + 1]) id = parts[start] + '/' + parts[start + 1];
                    }
                }
            } catch (e) {}
            id = id.replace(/^https?:\/\/api\.apify\.com\/v2\/acts\//i, '').replace(/\/runs.*$/i, '');
            id = id.replace(/^\/+|\/+$/g, '');
            if (id.includes('/') && !id.includes('~')) id = id.split('/').slice(0, 2).join('~');
            return encodeURIComponent(id);
        },

        headers(settings) {
            return {
                'Content-Type': 'application/json',
                'X-PocketLeads-Key-Row': String(apiKeyRowOf(settings))
            };
        },

        buildActorInputs(query, settings) {
            const max = parseInt(settings.maxResultsPerSearch, 10) || 0;
            const countryName = String(settings.countryFilter || '').trim();
            const countryCode = String(settings.countryCodeFilter || getCountryCodeByName(countryName) || '').trim().toLowerCase();
            const withOptions = (obj, limitKeys, includeCountry) => {
                const out = Object.assign({}, obj);
                if (max > 0) {
                    (Array.isArray(limitKeys) ? limitKeys : [limitKeys]).filter(Boolean).forEach(key => { out[key] = max; });
                }
                if (includeCountry && countryName) out.country = countryName;
                if (includeCountry && countryCode) out.countryCode = countryCode;
                return out;
            };
            // Try broad compatible shapes. Some Google Maps actors accept only one
            // schema; if a stricter actor rejects unknown fields, runActor() retries
            // the next simpler shape automatically.
            return [
                withOptions({ searchStringsArray: [query], language: 'en' }, ['maxCrawledPlacesPerSearch', 'maxCrawledPlaces'], true),
                withOptions({ searchStringsArray: [query], language: 'en' }, ['maxCrawledPlacesPerSearch', 'maxCrawledPlaces'], false),
                withOptions({ searchStringsArray: [query], language: 'en' }, 'maxItems', false),
                withOptions({ queries: [query], language: 'en' }, ['maxResults', 'maxItems'], true),
                withOptions({ queries: [query], language: 'en' }, ['maxResults', 'maxItems'], false),
                withOptions({ search: query, language: 'en' }, 'limit', false),
                withOptions({ query, language: 'en' }, 'limit', false),
                withOptions({ searchStringsArray: [query], language: 'en' }, null, false)
            ];
        },

        buildActorInput(query, settings) {
            return this.buildActorInputs(query, settings)[0];
        },

        async requestJson(url, options) {
            const headers = (options && options.headers) || {};
            const settings = options && options.requestSettings || { apiKeyRow: proxyKeyRowFromHeaders(headers), apifyKeyRow: proxyKeyRowFromHeaders(headers) };
            const method = String(options && options.method || 'GET').toUpperCase();
            let body = {};
            try { body = options && options.body ? JSON.parse(options.body) : {}; } catch (e) { body = {}; }
            let operation = '';
            let payload = {};
            const text = String(url || '');
            let match = null;
            if (/\/acts\/[^/]+\/runs/i.test(text) && method === 'POST') {
                operation = 'runActor';
                const u = new URL(text);
                payload = { input: body, maxItems: parseInt(u.searchParams.get('maxItems'), 10) || 0 };
            } else if ((match = text.match(/\/actor-runs\/([^/?]+)\/dataset\/items/i))) {
                const u = new URL(text);
                operation = 'getRunDatasetItems';
                payload = { runId: decodeURIComponent(match[1]), offset: parseInt(u.searchParams.get('offset'), 10) || 0, limit: parseInt(u.searchParams.get('limit'), 10) || 500 };
            } else if ((match = text.match(/\/actor-runs\/([^/?]+)/i))) {
                operation = 'getRun';
                payload = { runId: decodeURIComponent(match[1]) };
            } else if ((match = text.match(/\/datasets\/([^/?]+)\/items/i))) {
                const u = new URL(text);
                operation = 'getDatasetItems';
                payload = { datasetId: decodeURIComponent(match[1]), offset: parseInt(u.searchParams.get('offset'), 10) || 0, limit: parseInt(u.searchParams.get('limit'), 10) || 500 };
            } else {
                throw new Error('Secure Apify proxy blocked unsupported endpoint.');
            }
            return providerProxyRequest('apify', operation, payload, settings, { attempts: 1, timeoutMs: operation === 'runActor' ? 45000 : 20000 });
        },

        async runActor(query, settings) {
            settings = SettingsManager.validate(settings);
            const actorId = 'server-managed-actor';
            const params = new URLSearchParams({ waitForFinish: '0' });
            const paidLimit = parseInt(settings.maxResultsPerSearch, 10) || 0;
            if (paidLimit > 0) params.set('maxItems', String(paidLimit));
            const url = `https://api.apify.com/v2/acts/${actorId}/runs?${params.toString()}`;
            const inputs = this.buildActorInputs(query, settings);
            let lastError = null;
            for (let i = 0; i < inputs.length; i += 1) {
                const body = inputs[i];
                try {
                    log('Starting Apify actor', { actorId: settings.actorId, query, targetResults: settings.maxResultsPerSearch, inputAttempt: i + 1, body });
                    const payload = await this.requestJson(url, {
                        method: 'POST',
                        headers: this.headers(settings),
                requestSettings: settings,
                        body: JSON.stringify(body)
                    });
                    const run = payload && payload.data ? payload.data : payload;
                    if (!run || !run.id) throw new Error('Backend service error: actor run ID was not returned.');
                    return run;
                } catch (err) {
                    lastError = err;
                    const msg = err && err.message ? err.message : String(err);
                    warn('Apify actor start attempt failed', i + 1, msg);
                    if (!/input|schema|additional|required|invalid|property/i.test(msg) || i === inputs.length - 1) {
                        throw err;
                    }
                }
            }
            throw lastError || new Error('Backend service error: actor run could not be started.');
        },

        async getRun(runId, settings) {
            settings = SettingsManager.validate(settings);
            const url = `https://api.apify.com/v2/actor-runs/${encodeURIComponent(runId)}`;
            const payload = await this.requestJson(url, { method: 'GET', headers: this.headers(settings) });
            return payload && payload.data ? payload.data : payload;
        },

        getDatasetId(run) {
            return run && (run.defaultDatasetId || (run.storageIds && run.storageIds.datasets && run.storageIds.datasets.default));
        },

        assertSucceeded(run) {
            const status = String(run && run.status || '').toUpperCase();
            if (TERMINAL_STATUSES.includes(status) && status !== 'SUCCEEDED') {
                throw new Error('Actor run failed: ' + status + (run && run.statusMessage ? ' - ' + run.statusMessage : ''));
            }
        },

        async waitForDatasetId(run, settings) {
            const startedAt = Date.now();
            let currentRun = run;
            let datasetId = this.getDatasetId(currentRun);
            while (!datasetId && Date.now() - startedAt < 30000) {
                await sleep(500);
                currentRun = await this.getRun(run.id, settings);
                this.assertSucceeded(currentRun);
                datasetId = this.getDatasetId(currentRun);
            }
            if (!datasetId) throw new Error('No result dataset found for the data job.');
            return { run: currentRun, datasetId };
        },

        async pollRun(runId, settings, onStatus) {
            settings = SettingsManager.validate(settings);
            const startedAt = Date.now();
            let lastRun = null;
            while (Date.now() - startedAt < settings.pollTimeoutMs) {
                const run = await this.getRun(runId, settings);
                lastRun = run;
                const status = String(run && run.status || '').toUpperCase();
                if (typeof onStatus === 'function') {
                    try { await onStatus(status, run); } catch (e) {}
                }
                log('Apify run status', runId, status);
                if (TERMINAL_STATUSES.includes(status)) {
                    this.assertSucceeded(run);
                    return run;
                }
                await sleep(settings.pollIntervalMs);
            }
            throw new Error('Actor polling timed out' + (lastRun && lastRun.status ? ' at status ' + lastRun.status : ''));
        },

        async getDatasetPage(datasetId, settings, offset, limit) {
            const params = new URLSearchParams({
                format: 'json',
                clean: 'true',
                offset: String(offset),
                limit: String(limit)
            });
            const url = `https://api.apify.com/v2/datasets/${encodeURIComponent(datasetId)}/items?${params.toString()}`;
            const payload = await this.requestJson(url, { method: 'GET', headers: this.headers(settings) });
            if (!Array.isArray(payload)) throw new Error('No dataset found or dataset response was not an array.');
            return payload;
        },

        async getDatasetItems(datasetId, settings, startOffset = 0, maxItems = null) {
            settings = SettingsManager.validate(settings);
            if (!datasetId) throw new Error('No result dataset found for the data job.');
            const target = maxItems === null || typeof maxItems === 'undefined' ? (parseInt(settings.maxResultsPerSearch, 10) || 0) : (parseInt(maxItems, 10) || 0);
            const pageSize = target > 0 ? Math.min(Math.max(1, target), settings.datasetPageSize) : settings.datasetPageSize;
            const all = [];
            let offset = Math.max(0, parseInt(startOffset, 10) || 0);
            for (let guard = 0; guard < 200; guard += 1) {
                const remaining = target > 0 ? target - all.length : pageSize;
                if (target > 0 && remaining <= 0) break;
                const batchLimit = target > 0 ? Math.min(pageSize, remaining) : pageSize;
                const page = await this.getDatasetPage(datasetId, settings, offset, batchLimit);
                if (!page.length) break;
                all.push(...page);
                offset += page.length;
                if (page.length < batchLimit) break;
                if (target <= 0) break; // for streaming, one full page per poll is enough
            }
            return all;
        },

        async getRunDatasetItems(runId, settings, startOffset = 0, maxItems = null) {
            settings = SettingsManager.validate(settings);
            if (!runId) throw new Error('No run ID found for the data job.');
            const target = maxItems === null || typeof maxItems === 'undefined' ? (parseInt(settings.maxResultsPerSearch, 10) || 0) : (parseInt(maxItems, 10) || 0);
            const pageSize = target > 0 ? Math.min(Math.max(1, target), settings.datasetPageSize) : settings.datasetPageSize;
            const params = new URLSearchParams({
                format: 'json',
                clean: 'true',
                offset: String(Math.max(0, parseInt(startOffset, 10) || 0)),
                limit: String(pageSize)
            });
            const url = `https://api.apify.com/v2/actor-runs/${encodeURIComponent(runId)}/dataset/items?${params.toString()}`;
            const payload = await this.requestJson(url, { method: 'GET', headers: this.headers(settings) });
            if (!Array.isArray(payload)) throw new Error('No run dataset found or dataset response was not an array.');
            return payload;
        },

        extractPlaceId(item) {
            return firstValue(item, PLACE_ID_FIELDS);
        }
    };


    const GOOGLE_TEXT_SEARCH_IDS_ONLY_FIELD_MASK = 'places.id,nextPageToken';

    const GoogleMapsPlacesClient = {
        headers(settings) {
            const fieldMask = GOOGLE_TEXT_SEARCH_IDS_ONLY_FIELD_MASK;
            this.assertIdsOnlyFieldMask(fieldMask);
            return {
                'Content-Type': 'application/json',
                'X-PocketLeads-Key-Row': String(apiKeyRowOf(settings)),
                'X-Goog-FieldMask': fieldMask
            };
        },

        assertIdsOnlyFieldMask(fieldMask) {
            const normalized = String(fieldMask || '').replace(/\s+/g, '');
            if (normalized !== GOOGLE_TEXT_SEARCH_IDS_ONLY_FIELD_MASK) {
                throw new Error('Google Maps cost guard blocked request: only places.id,nextPageToken field mask is allowed.');
            }
            if (/displayName|formattedAddress|internationalPhoneNumber|nationalPhoneNumber|websiteUri|rating|userRatingCount|googleMapsUri|googleMapsLinks|addressComponents|businessStatus|types/i.test(normalized)) {
                throw new Error('Google Maps cost guard blocked paid place fields.');
            }
            return true;
        },

        async requestJson(url, options) {
            const headers = (options && options.headers) || {};
            const settings = options && options.requestSettings || { apiKeyRow: proxyKeyRowFromHeaders(headers), apifyKeyRow: proxyKeyRowFromHeaders(headers) };
            let body = {};
            try { body = options && options.body ? JSON.parse(options.body) : {}; } catch (e) { body = {}; }
            return providerProxyRequest('googlemaps', 'textSearch', { body }, settings, { attempts: 1, timeoutMs: 15000 });
        },

        async requestTextSearchPage(query, settings, pageToken) {
            this.assertIdsOnlyFieldMask(GOOGLE_TEXT_SEARCH_IDS_ONLY_FIELD_MASK);
            const body = {
                textQuery: normalizeQueryTextForApi(query),
                pageSize: 20
            };
            if (pageToken) body.pageToken = String(pageToken);
            const endpoint = 'https://places.googleapis.com/v1/places:searchText';
            const payload = await this.requestJson(endpoint, {
                method: 'POST',
                headers: this.headers(settings),
                requestSettings: settings,
                body: JSON.stringify(body)
            });
            const ids = [];
            const items = [];
            const seen = new Set();
            const responseFields = Object.keys(payload || {});
            const places = Array.isArray(payload && payload.places) ? payload.places : [];
            places.forEach((place, index) => {
                const placeFields = Object.keys(place || {});
                const id = asString(place && place.id);
                const key = id.toLowerCase();
                const duplicateInPage = !!(key && seen.has(key));
                if (key && !duplicateInPage) {
                    seen.add(key);
                    ids.push(id);
                }
                items.push({
                    apiIndex: index + 1,
                    placeId: id,
                    fields: placeFields,
                    responseFields,
                    duplicateInPage,
                    skipReason: !id ? 'Skipped: API response me place id missing hai.' : (duplicateInPage ? 'Skipped: duplicate inside same API page.' : ''),
                    mapsUrl: id ? PlaceIdManager.toMapsUrl(id) : ''
                });
            });
            return {
                placeIds: ids,
                items,
                responseFields,
                request: { endpoint, body, fieldMask: GOOGLE_TEXT_SEARCH_IDS_ONLY_FIELD_MASK },
                returnedRawCount: places.length,
                nextPageToken: asString(payload && payload.nextPageToken)
            };
        },

        async searchPlaceIds(query, settings, meta, onPageIds) {
            settings = SettingsManager.validate(settings);
            const cleanQuery = normalizeQueryTextForApi(query);
            const pagePlan = getEffectivePageCount(meta || { queryForApi: cleanQuery, query: cleanQuery }, settings);
            const pagesNeeded = pagePlan.effective;
            const max = pagesNeeded * 20;
            let pageToken = '';
            const allIds = [];
            const seen = new Set();
            emitGoogleApiLiveEvent({
                type: 'session_start',
                stage: 'api',
                query: cleanQuery,
                originalQuery: meta && (meta.query || meta.keyword || ''),
                fieldMask: GOOGLE_TEXT_SEARCH_IDS_ONLY_FIELD_MASK,
                endpoint: 'https://places.googleapis.com/v1/places:searchText',
                selectedPages: pagePlan.selected,
                effectivePages: pagePlan.effective,
                cappedByPincodeRule: !!(pagePlan.isPincode && pagePlan.selected > pagePlan.effective),
                message: 'Google Places API live started. IDs-only FieldMask locked.'
            });
            for (let page = 1; page <= pagesNeeded; page += 1) {
                if(settings.managedRouting && typeof DailyController!=='undefined' && !(await DailyController.isStillRunning()))break;
                emitGoogleApiLiveEvent({
                    type: 'page_request',
                    stage: 'api',
                    query: cleanQuery,
                    page,
                    fieldMask: GOOGLE_TEXT_SEARCH_IDS_ONLY_FIELD_MASK,
                    requestBody: { textQuery: cleanQuery, pageSize: 20, pageToken: pageToken ? '[nextPageToken]' : '' },
                    message: 'Calling Google Places API page ' + page
                });
                const result = await this.requestTextSearchPage(cleanQuery, settings, pageToken);
                const items = Array.isArray(result.items) ? result.items : (result.placeIds || []).map((id, i) => ({ apiIndex: i + 1, placeId: id, fields: ['id'], responseFields: result.responseFields || [] }));
                let acceptedThisPage = 0;
                let skippedThisPage = 0;
                const pageIds = [];
                items.forEach(item => {
                    const placeId = asString(item && item.placeId);
                    const key = placeId.toLowerCase();
                    let status = 'accepted_for_dom';
                    let reason = 'Accepted: API se Place ID mila; ab DOM extraction ke liye queue me jayega.';
                    let duplicate = false;
                    if (!key) {
                        status = 'skipped';
                        reason = item.skipReason || 'Skipped: API response me Place ID missing hai.';
                        skippedThisPage += 1;
                    } else if (seen.has(key)) {
                        duplicate = true;
                        status = 'skipped';
                        reason = 'Skipped: duplicate Place ID from API.';
                        skippedThisPage += 1;
                    } else if (allIds.length < max) {
                        seen.add(key);
                        allIds.push(placeId);
                        pageIds.push(placeId);
                        acceptedThisPage += 1;
                    }
                    emitGoogleApiLiveEvent({
                        type: 'place_id',
                        stage: 'api',
                        query: cleanQuery,
                        page,
                        apiIndex: item.apiIndex,
                        placeId,
                        mapsUrl: item.mapsUrl || (placeId ? PlaceIdManager.toMapsUrl(placeId) : ''),
                        status,
                        reason,
                        duplicate,
                        fieldsReturned: item.fields || [],
                        responseFields: item.responseFields || result.responseFields || [],
                        fieldMask: GOOGLE_TEXT_SEARCH_IDS_ONLY_FIELD_MASK,
                        requestBody: result.request && result.request.body,
                        endpoint: result.request && result.request.endpoint
                    });
                });
                emitGoogleApiLiveEvent({
                    type: 'page_done',
                    stage: 'api',
                    query: cleanQuery,
                    page,
                    returned: result.returnedRawCount || items.length,
                    accepted: acceptedThisPage,
                    skipped: skippedThisPage,
                    uniqueTotal: allIds.length,
                    nextPageToken: !!result.nextPageToken,
                    responseFields: result.responseFields || [],
                    message: 'Page ' + page + ' complete: returned ' + (result.returnedRawCount || items.length) + ', accepted ' + acceptedThisPage + ', skipped ' + skippedThisPage
                });
                const hasMore = Boolean(result.nextPageToken && allIds.length < max && page < pagesNeeded);
                if (typeof onPageIds === 'function' && pageIds.length) {
                    await onPageIds(pageIds.slice(), page, hasMore);
                }
                if (!result.nextPageToken || allIds.length >= max) break;
                pageToken = result.nextPageToken;
                // Keep pagination short. Page 1 streams immediately into Ghost workers; later pages wait briefly.
                await sleep(80);
            }
            emitGoogleApiLiveEvent({
                type: 'session_api_done',
                stage: 'api',
                query: cleanQuery,
                totalIds: allIds.length,
                message: 'Google Places API IDs complete. DOM extraction will start now.'
            });
            return allIds.slice(0, max);
        },

        async previewSearch(query, settings, meta) {
            settings = SettingsManager.validate(settings);
            const cleanQuery = normalizeQueryTextForApi(query);
            const pagePlan = getEffectivePageCount(meta || { queryForApi: cleanQuery, query: cleanQuery }, settings);
            const pagesNeeded = pagePlan.effective;
            let pageToken = '';
            const seen = new Set();
            const pages = [];
            const allIds = [];
            for (let page = 1; page <= pagesNeeded; page += 1) {
                const result = await this.requestTextSearchPage(cleanQuery, settings, pageToken);
                const ids = [];
                (result.placeIds || []).forEach(id => {
                    const key = String(id || '').toLowerCase();
                    if (!key || seen.has(key)) return;
                    seen.add(key);
                    ids.push(id);
                    allIds.push(id);
                });
                pages.push({
                    page,
                    returned: (result.placeIds || []).length,
                    unique: ids.length,
                    ids,
                    nextPageToken: !!result.nextPageToken
                });
                if (!result.nextPageToken) break;
                pageToken = result.nextPageToken;
                await sleep(500);
            }
            return {
                provider: 'googlemaps',
                query: cleanQuery,
                fieldMask: GOOGLE_TEXT_SEARCH_IDS_ONLY_FIELD_MASK,
                selectedPages: pagePlan.selected,
                effectivePages: pagePlan.effective,
                cappedByPincodeRule: !!(pagePlan.isPincode && pagePlan.selected > pagePlan.effective),
                returnedCount: allIds.length,
                pages,
                ids: allIds
            };
        }
    };

    const SerperClient = {
        headers(settings) {
            return {
                'Content-Type': 'application/json',
                'X-PocketLeads-Key-Row': String(apiKeyRowOf(settings))
            };
        },

        async requestJson(url, options) {
            const headers = (options && options.headers) || {};
            const settings = options && options.requestSettings || { apiKeyRow: proxyKeyRowFromHeaders(headers), apifyKeyRow: proxyKeyRowFromHeaders(headers) };
            let body = {};
            try { body = options && options.body ? JSON.parse(options.body) : {}; } catch (e) { body = {}; }
            const match = String(url || '').match(/google\.serper\.dev\/(maps|places|search)/i);
            const operation = match ? String(match[1]).toLowerCase() : '';
            if (!operation) throw new Error('Secure Serper proxy blocked unsupported endpoint.');
            return providerProxyRequest('serper', operation, { body }, settings, { attempts: 1, timeoutMs: 15000 });
        },

        extractPlaces(payload) {
            const out = [];
            const seen = new Set();
            const addOne = item => {
                if (!item || typeof item !== 'object') return;
                const key = [
                    item.placeId || item.place_id || item.cid || item.fid || '',
                    item.title || item.name || '',
                    item.address || item.formattedAddress || ''
                ].join('|');
                const compact = compactText(key) || hashString(asString(item));
                if (seen.has(compact)) return;
                seen.add(compact);
                out.push(item);
            };
            const pushArray = arr => {
                if (Array.isArray(arr)) arr.forEach(addOne);
            };
            const pushSingle = obj => {
                if (obj && typeof obj === 'object' && !Array.isArray(obj)) addOne(obj);
            };
            pushArray(payload && payload.places);
            pushArray(payload && payload.localResults);
            pushArray(payload && payload.local_results);
            pushArray(payload && payload.placesResults);
            pushArray(payload && payload.places_results);
            pushArray(payload && payload.mapsResults);
            pushArray(payload && payload.maps_results);
            pushArray(payload && payload.results);
            // Serper Maps detail calls can return a single object instead of only a list.
            pushSingle(payload && payload.place);
            pushSingle(payload && payload.placeInfo);
            pushSingle(payload && payload.place_info);
            pushSingle(payload && payload.result);
            if (payload && payload.data && typeof payload.data === 'object') {
                pushArray(payload.data.places);
                pushArray(payload.data.localResults);
                pushArray(payload.data.local_results);
                pushArray(payload.data.places_results);
                pushArray(payload.data.mapsResults);
                pushArray(payload.data.maps_results);
                pushArray(payload.data.results);
                pushSingle(payload.data.place);
                pushSingle(payload.data.placeInfo);
                pushSingle(payload.data.place_info);
                pushSingle(payload.data.result);
            }
            return out;
        },

        normalizePlace(place, meta, index) {
            const row = Object.assign({}, place || {});
            if (place && place.title && !row.name) row.name = place.title;
            if (place && place.name && !row.title) row.title = place.name;
            if (place && place.ratingCount && !row.reviewCount) row.reviewCount = place.ratingCount;
            if (place && place.reviewsCount && !row.reviewCount) row.reviewCount = place.reviewsCount;

            // Serper Maps returns the richest phone/address values in normal list rows.
            // Capture only trusted phone fields (never random CID/FID numbers), and do
            // it before the generic normalizer flattens the object for the grid/export.
            const trustedPhone = extractSerperPhone(place);
            if (trustedPhone) {
                row.phone = trustedPhone;
                row.phone_number = trustedPhone;
                row.phoneNumber = trustedPhone;
            }

            const trustedAddress = extractSerperAddress(place);
            if (trustedAddress && (!row.address || isShortAddress(row.address) || trustedAddress.length > String(row.address).length)) {
                row.address = trustedAddress;
            }

            const trustedWebsite = extractSerperWebsite(place);
            if (trustedWebsite && !row.website) row.website = trustedWebsite;

            if (place && place.placeId && !row.place_id) row.place_id = place.placeId;
            if (place && place.place_id && !row.placeId) row.placeId = place.place_id;
            if (place && place.cid && !row.cid) row.cid = place.cid;
            if (place && place.fid && !row.fid) row.fid = place.fid;
            if (place && place.link && !row.googleMapsUrl) row.googleMapsUrl = place.link;
            if (place && place.mapsUrl && !row.googleMapsUrl) row.googleMapsUrl = place.mapsUrl;
            if (place && place.googleMapsUrl && !row.link) row.link = place.googleMapsUrl;
            if (!row.googleMapsUrl && row.place_id) row.googleMapsUrl = PlaceIdManager.toMapsUrl(row.place_id);
            if (!row.googleMapsUrl && row.placeId) row.googleMapsUrl = PlaceIdManager.toMapsUrl(row.placeId);
            if (!row.googleMapsUrl && row.cid) row.googleMapsUrl = PlaceIdManager.toCidMapsUrl(row.cid);
            enrichRowFromAddress(row, place, meta, meta && meta.settings);
            applyProviderProvenance(row, place, Object.assign({}, meta || {}, { provider: 'serper' }), (meta && meta.settings) || { provider: 'serper' }, (meta && meta.serperEndpoint) || 'serper_maps');
            return row;
        },

        async requestMapsPage(query, settings, pageNo, meta) {
            query = normalizeQueryTextForApi(query);
            const page = Math.max(1, parseInt(pageNo, 10) || 1);
            const body = {
                q: buildCountryRestrictedQuery(query, (settings && settings.countryFilter) || (meta && meta.country) || 'India'),
                gl: ((settings && settings.countryCodeFilter) || getCountryCodeByName((settings && settings.countryFilter) || (meta && meta.country)) || 'IN').toLowerCase(),
                hl: 'en',
                page,
                num: 20,
                type: 'maps',
                engine: 'google'
            };
            // Serper Maps requires ll (GPS position + zoom) for page > 1.
            // Page 1 usually returns ll; keep it in meta and reuse it for later pages.
            const ll = normalizeSerperLl(meta && (meta.serperLl || meta.ll || meta.mapsLl));
            if (page > 1 && ll) body.ll = ll;
            // Important: use Serper Maps, not Places. The Serper playground shows
            // phoneNumber/address for many businesses only under Type = Maps.
            // Keep q exact as entered; do not add hidden location/query changes.
            const payload = await this.requestJson('https://google.serper.dev/maps', {
                method: 'POST',
                headers: this.headers(settings),
                requestSettings: settings,
                body: JSON.stringify(body)
            });
            const places = this.extractPlaces(payload);
            let discoveredLl = normalizeSerperLl(
                (payload && payload.ll) ||
                (payload && payload.searchParameters && payload.searchParameters.ll) ||
                (payload && payload.searchParameters && payload.searchParameters.gps) ||
                (payload && payload.parameters && payload.parameters.ll)
            );
            if (!discoveredLl && places.length) discoveredLl = buildLlFromPlace(places[0], 13);
            if (discoveredLl && meta) meta.serperLl = discoveredLl;
            return places.map((place, index) => this.normalizePlace(place, Object.assign({}, meta || {}, { query, pageNo: page, settings, serperEndpoint: 'serper_maps' }), index));
        },

        async requestPlacesPage(query, settings, pageNo, meta) {
            query = normalizeQueryTextForApi(query);
            const body = {
                q: buildCountryRestrictedQuery(query, (settings && settings.countryFilter) || (meta && meta.country) || 'India'),
                gl: ((settings && settings.countryCodeFilter) || getCountryCodeByName((settings && settings.countryFilter) || (meta && meta.country)) || 'IN').toLowerCase(),
                hl: 'en',
                page: Math.max(1, parseInt(pageNo, 10) || 1)
            };
            const payload = await this.requestJson('https://google.serper.dev/places', {
                method: 'POST',
                headers: this.headers(settings),
                requestSettings: settings,
                body: JSON.stringify(body)
            });
            return this.extractPlaces(payload).map((place, index) => this.normalizePlace(place, Object.assign({}, meta || {}, { query, pageNo, settings, serperEndpoint: 'serper_places' }), index));
        },

        buildQueryVariants(query, meta, settings) {
            const normalized = normalizeQueryTextForApi(query);
            return normalized ? [normalized] : [];
        },

        async requestSearchLocalPack(query, settings, meta, pageNo) {
            const body = {
                q: buildCountryRestrictedQuery(query, (settings && settings.countryFilter) || (meta && meta.country) || 'India'),
                gl: ((settings && settings.countryCodeFilter) || getCountryCodeByName((settings && settings.countryFilter) || (meta && meta.country)) || 'IN').toLowerCase(),
                hl: 'en',
                num: 10,
                page: Math.max(1, parseInt(pageNo, 10) || 1)
            };
            const payload = await this.requestJson('https://google.serper.dev/search', {
                method: 'POST',
                headers: this.headers(settings),
                requestSettings: settings,
                body: JSON.stringify(body)
            });
            return this.extractPlaces(payload).map((place, index) => this.normalizePlace(place, Object.assign({}, meta || {}, { query, settings, serperEndpoint: 'serper_search' }), index));
        },

        mergeRows(primaryRows, secondaryRows) {
            const merged = [];
            const indexByKey = new Map();
            const addOrMerge = row => {
                if (!row || typeof row !== 'object') return;
                const keys = [
                    rowFingerprint(row),
                    compactText(row.company_name || row.name || row.title || '') + '|' + compactText(row.address || '')
                ].filter(Boolean);
                let found = null;
                for (const key of keys) {
                    if (indexByKey.has(key)) { found = indexByKey.get(key); break; }
                }
                if (!found) {
                    found = Object.assign({}, row);
                    merged.push(found);
                    keys.forEach(key => indexByKey.set(key, found));
                    return;
                }
                Object.keys(row).forEach(key => {
                    const incoming = row[key];
                    if (incoming === null || typeof incoming === 'undefined' || incoming === '') return;
                    if (!found[key]) {
                        found[key] = incoming;
                        return;
                    }
                    if (key === 'address' && isShortAddress(found.address) && String(incoming).length > String(found.address).length) found.address = incoming;
                    if (key === 'phone' || key === 'phoneNumber') {
                        const phone = normalizeBusinessPhone(incoming);
                        if (phone && !normalizeBusinessPhone(found.phone || found.phoneNumber)) found.phone = phone;
                    }
                });
            };
            (primaryRows || []).forEach(addOrMerge);
            (secondaryRows || []).forEach(addOrMerge);
            return merged;
        },

        hasStrongDetails(row) {
            if (!row || typeof row !== 'object') return false;
            const phone = normalizeBusinessPhone(row.phone || row.phoneNumber || row.telephone || row.mobile);
            const address = asString(row.address || row.fullAddress || row.formattedAddress || row.streetAddress);
            return Boolean(phone && address && !isShortAddress(address));
        },

        needsSerperDetail(row) {
            if (!row || typeof row !== 'object') return false;
            const phone = normalizeBusinessPhone(row.phone || row.phoneNumber || row.telephone || row.mobile);
            const address = asString(row.address || row.fullAddress || row.formattedAddress || row.streetAddress);
            const website = cleanUrlLike(row.website || row.websiteUrl || row.websiteURL || row.domain);
            // Phone and full address are most important. Website is useful but not required.
            return !phone || !address || isShortAddress(address) || !website;
        },

        buildDetailBodies(row, settings, meta) {
            const base = {
                gl: ((settings && settings.countryCodeFilter) || getCountryCodeByName((settings && settings.countryFilter) || (meta && meta.country)) || 'IN').toLowerCase(),
                hl: 'en',
                type: 'maps',
                engine: 'google'
            };
            const bodies = [];
            const placeId = firstValue(row, PLACE_ID_FIELDS) || extractPlaceIdFromUrl(row.map_link || row.googleMapsUrl || row.mapsUrl || row.link || '');
            const cid = row.cid || row.dataCid || row.placeCid || '';
            if (placeId && !/^\d{8,}$/.test(String(placeId))) {
                bodies.push(Object.assign({}, base, { placeId: String(placeId).trim() }));
                bodies.push(Object.assign({}, base, { place_id: String(placeId).trim() }));
            }
            if (cid) {
                bodies.push(Object.assign({}, base, { cid: String(cid).trim() }));
                bodies.push(Object.assign({}, base, { data_cid: String(cid).trim() }));
            }
            // Last fallback: exact business + address query. This matches what the
            // Serper Maps playground does when opening a specific map result.
            const q = [
                row.company_name || row.name || row.title,
                row.address,
                meta && (meta.location || meta.queryForApi || meta.query)
            ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
            if (q) bodies.push(Object.assign({}, base, { q, page: 1, num: 10 }));

            const seen = new Set();
            return bodies.filter(body => {
                const key = JSON.stringify(body);
                if (seen.has(key)) return false;
                seen.add(key);
                return true;
            });
        },

        isSameBusiness(baseRow, detailRow) {
            if (!baseRow || !detailRow) return false;
            const basePlace = firstValue(baseRow, PLACE_ID_FIELDS);
            const detailPlace = firstValue(detailRow, PLACE_ID_FIELDS);
            if (basePlace && detailPlace && String(basePlace).toLowerCase() === String(detailPlace).toLowerCase()) return true;
            const baseCid = asString(baseRow.cid || baseRow.dataCid || baseRow.placeCid);
            const detailCid = asString(detailRow.cid || detailRow.dataCid || detailRow.placeCid);
            if (baseCid && detailCid && baseCid === detailCid) return true;
            const aTitle = compactText(baseRow.company_name || baseRow.name || baseRow.title || '');
            const bTitle = compactText(detailRow.company_name || detailRow.name || detailRow.title || '');
            if (aTitle && bTitle && (aTitle === bTitle || aTitle.includes(bTitle) || bTitle.includes(aTitle))) return true;
            return false;
        },

        mergeDetailIntoRow(row, detail) {
            if (!row || !detail) return row;
            const normalizedDetail = Object.assign({}, detail);
            enrichRowFromAddress(normalizedDetail, detail, {}, {});
            const phone = normalizeBusinessPhone(normalizedDetail.phone || normalizedDetail.phoneNumber || detail.phoneNumber || detail.phone || detail.telephone || detail.mobile || '');
            if (phone && !normalizeBusinessPhone(row.phone || row.phoneNumber)) row.phone = phone;

            const address = asString(normalizedDetail.address || detail.address || detail.fullAddress || detail.formattedAddress || detail.streetAddress);
            if (address && (!row.address || isShortAddress(row.address) || address.length > String(row.address).length)) row.address = address;

            const website = cleanUrlLike(normalizedDetail.website || detail.website || detail.websiteUrl || detail.websiteURL || detail.websiteLink || detail.domain);
            if (website && !row.website) row.website = website;
            const detailEmails = extractEmailValues([
                normalizedDetail.email_1, normalizedDetail.email, normalizedDetail.email1,
                normalizedDetail.emailAddress, normalizedDetail.email_address,
                normalizedDetail.contactEmail, normalizedDetail.contact_email,
                detail.emails, detail.emailAddresses
            ].filter(Boolean).join(', '));
            if (detailEmails.length) {
                const existingEmails = extractEmailValues(row.email_1 || '');
                row.email_1 = existingEmails.concat(detailEmails).filter((value, index, all) => all.indexOf(value) === index).join(', ');
            }

            ['city', 'state', 'pincode', 'latitude', 'longitude', 'review', 'total_reviews', 'category', 'categories', 'opening_hours'].forEach(key => {
                if (!row[key] && normalizedDetail[key]) row[key] = normalizedDetail[key];
            });
            if (!row.place_id) row.place_id = firstValue(normalizedDetail, PLACE_ID_FIELDS) || row.placeId || '';
            if (!row.cid && normalizedDetail.cid) row.cid = normalizedDetail.cid;
            if (!row.map_link && normalizedDetail.googleMapsUrl) row.map_link = normalizedDetail.googleMapsUrl;
            return row;
        },

        async requestMapsDetailsForRow(row, settings, meta) {
            if (settings.managedRouting) return row;
            if (!row || !this.needsSerperDetail(row)) return row;
            const bodies = this.buildDetailBodies(row, settings, meta).slice(0, 4);
            for (const body of bodies) {
                try {
                    const payload = await this.requestJson('https://google.serper.dev/maps', {
                        method: 'POST',
                        headers: this.headers(settings),
                requestSettings: settings,
                        body: JSON.stringify(body)
                    });
                    const places = this.extractPlaces(payload).map((place, index) => this.normalizePlace(place, Object.assign({}, meta || {}, { settings, serperEndpoint: 'serper_maps_detail' }), index));
                    if (!places.length) continue;
                    const preferred = places.find(place => this.isSameBusiness(row, place)) || places[0];
                    this.mergeDetailIntoRow(row, preferred);
                    if (this.hasStrongDetails(row) || normalizeBusinessPhone(row.phone || row.phoneNumber)) return row;
                } catch (err) {
                    if(isCommercialStopError(err) || isApiRotationError(err))throw err;
                    warn('Serper Maps detail failed', err && err.message ? err.message : err);
                }
            }
            return row;
        },

        async enrichRowsWithMapsDetails(rows, settings, meta, options) {
            const list = Array.isArray(rows) ? rows : [];
            const maxDetails = Math.max(0, parseInt(options && options.maxDetails, 10) || 0);
            if (!list.length || !maxDetails) return list;
            const targets = list.filter(row => this.needsSerperDetail(row)).slice(0, maxDetails);
            if (!targets.length) return list;
            const concurrency = Math.max(1, Math.min(8, parseInt(options && options.concurrency, 10) || 6));
            for (let i = 0; i < targets.length; i += concurrency) {
                const chunk = targets.slice(i, i + concurrency);
                for(const row of chunk) await this.requestMapsDetailsForRow(row,settings,meta);
            }
            return list;
        },

        async requestHybridPage(query, settings, pageNo, meta) {
            if (settings.managedRouting) return this.requestMapsPage(query, settings, pageNo, meta);
            const exactQuery = normalizeQueryTextForApi(query);
            // Primary source: Serper Maps. For page > 1, Serper may require GPS `ll`.
            // If Google/Serper does not return ll from page 1, fall back to Places/Search
            // instead of stopping at page 2 so the selected page count is still respected.
            try {
                return await this.requestMapsPage(exactQuery, settings, pageNo, meta);
            } catch (err) {
                const msg = err && err.message ? err.message : String(err);
                const page = Math.max(1, parseInt(pageNo, 10) || 1);
                const llMissing = page > 1 && /Parameter \"ll\"|Parameter "ll"|GPS location|paginated maps|ll.*required/i.test(msg);
                if (!llMissing) throw err;
                warn('Serper Maps page needs ll; falling back to Places/Search for page', page, msg);
                const fallback = [];
                try { fallback.push(...await this.requestPlacesPage(exactQuery, settings, page, meta)); } catch (placesErr) { if (isCommercialStopError(placesErr) || isApiRotationError(placesErr)) throw placesErr; warn('Serper Places fallback failed', placesErr && placesErr.message ? placesErr.message : placesErr); }
                if (fallback.length) return fallback;
                try { return await this.requestSearchLocalPack(exactQuery, settings, meta, page); } catch (searchErr) { if (isCommercialStopError(searchErr) || isApiRotationError(searchErr)) throw searchErr; warn('Serper Search fallback failed', searchErr && searchErr.message ? searchErr.message : searchErr); }
                throw err;
            }
        },

        async searchPlaces(query, settings, meta) {
            settings = SettingsManager.validate(settings);
            const pagePlan = getEffectivePageCount(meta || { queryForApi: query, query }, settings);
            const pageSize = 20;
            const pagesNeeded = pagePlan.effective;
            const max = pagesNeeded * pageSize;
            const firstPage = await this.requestMapsPage(query, settings, 1, meta);
            let rawPlaces = firstPage.slice();
            if (pagesNeeded > 1 && rawPlaces.length < max) {
                const remainingPages = [];
                for (let page = 2; page <= pagesNeeded; page += 1) remainingPages.push(page);
                const settled = await Promise.allSettled(remainingPages.map(page => this.requestMapsPage(query, settings, page, meta)));
                settled.forEach(result => {
                    if (result.status === 'fulfilled' && Array.isArray(result.value)) rawPlaces.push(...result.value);
                    if(result.status==='rejected' && (isCommercialStopError(result.reason)||isApiRotationError(result.reason)))throw result.reason;
                    if (result.status === 'rejected') warn('Serper extra page failed; continuing with available results', result.reason && result.reason.message ? result.reason.message : result.reason);
                });
            }
            const seen = new Set();
            const unique = [];
            rawPlaces.forEach((place, index) => {
                const normalized = this.normalizePlace(place, meta, index);
                const key = rowFingerprint(normalized);
                if (!key || seen.has(key)) return;
                seen.add(key);
                unique.push(normalized);
            });
            return unique.slice(0, max);
        }
    };


    const SCRAPPA_LEAD_FIELDS = 'name,review_count,rating,website,domain,latitude,longitude,business_id,subtypes,district,full_address,type,phone_numbers,place_id,current_status,city,zip_code,state,country_code,opening_hours,price_level,photos_sample';

    function isCorruptedV22PhotoUrl(url) {
        const s = String(url || '').trim();
        if (!s) return false;
        if (/\/(?:gps-cs-s|gps-proxy)\//i.test(s) && /=[ws](?:800|1200|1600)(?:-h(?:800|1200|1600))?/i.test(s)) {
            return true;
        }
        if (/streetviewpixels-pa\.googleapis\.com/i.test(s) && /[?&]w=(?:800|1200|1600)&h=(?:800|1200|1600)/i.test(s)) {
            return true;
        }
        return false;
    }

    function canonicalPhotoIdentity(url) {
        const s = String(url || '').trim();
        if (!/^https?:\/\//i.test(s)) return '';
        return s
            .replace(/=[ws]\d+[^?&]*$/i, '')
            .replace(/([?&])(?:w|h|s)=\d+/gi, '$1')
            .replace(/[?&]+$/, '')
            .toLowerCase();
    }

    function sanitizeGooglePhotoUrl(rawUrl, fallbackSmallUrl) {
        let s = String(rawUrl || '').trim();
        const small = String(fallbackSmallUrl || '').trim();
        if (isCorruptedV22PhotoUrl(s)) {
            s = (!isCorruptedV22PhotoUrl(small) && /^https?:\/\//i.test(small)) ? small : '';
        }
        if (!/^https?:\/\//i.test(s)) return '';
        if (/maps\.gstatic\.com\/.*(?:favicon|tactile| Cleardot|pin_)/i.test(s)) return '';
        if (/googleusercontent\.com\/(?:a|a-)\//i.test(s)) return '';

        // 1. StreetView thumbnail URLs: strip any appended =w... suffix and prefer original signed small URL
        if (/streetviewpixels-pa\.googleapis\.com/i.test(s)) {
            s = s.replace(/=[ws]\d+[^?&]*$/i, '');
            if (/^https?:\/\//i.test(small) && !isCorruptedV22PhotoUrl(small) && /streetviewpixels-pa\.googleapis\.com/i.test(small)) {
                return small.replace(/=[ws]\d+[^?&]*$/i, '');
            }
            return s;
        }

        // 2. googleusercontent / ggpht URLs: strip duplicate =w...=w... suffixes
        if (/googleusercontent\.com|ggpht\.com/i.test(s)) {
            s = s.replace(/(=[ws]\d+[^=]*)(=[ws]\d+[^=]*)$/i, '$1');
            // Signed /gps-cs-s/ or /gps-proxy/ URLs reject modified size suffixes with HTTP 400;
            // always use the exact signed photo_url when available.
            if (/\/(?:gps-cs-s|gps-proxy)\//i.test(s)) {
                if (/^https?:\/\//i.test(small) && !isCorruptedV22PhotoUrl(small)) {
                    return small.replace(/(=[ws]\d+[^=]*)(=[ws]\d+[^=]*)$/i, '$1');
                }
                return s;
            }
            // Standard /p/AF1Qip... URLs: if large URL has extreme dimensions (>1600) that may 400, cap to safe =w1000-h750-k-no
            if (/\/p\//i.test(s)) {
                const dimMatch = s.match(/=w(\d+)-h(\d+)([^=&?]*)$/i);
                if (dimMatch) {
                    const wNum = parseInt(dimMatch[1], 10) || 0;
                    const hNum = parseInt(dimMatch[2], 10) || 0;
                    if (wNum > 1600 || hNum > 1600) {
                        s = s.replace(/=w\d+-h\d+[^=&?]*$/i, '=w1000-h750-k-no');
                    }
                }
            }
        }
        return s;
    }

    function extractPhotosFromItem(item) {
        if (!item || typeof item !== 'object') return { photo_url: '', photo_url_large: '', photo_urls: '', photos_sample: [] };
        const samples = [];
        const allUrls = [];
        const seenIdentities = new Set();

        const addPhotoPair = (rawSmall, rawLarge, photoId) => {
            const cleanSmall = sanitizeGooglePhotoUrl(rawSmall || rawLarge, rawSmall);
            const cleanLarge = sanitizeGooglePhotoUrl(rawLarge || rawSmall, cleanSmall || rawSmall);
            const primaryUrl = cleanSmall || cleanLarge;
            if (!primaryUrl || !/^https?:\/\//i.test(primaryUrl)) return;
            const largeUrl = (/\/(?:gps-cs-s|gps-proxy)\/|streetviewpixels/i.test(primaryUrl))
                ? primaryUrl
                : (cleanLarge || primaryUrl);
            const idKey = canonicalPhotoIdentity(primaryUrl) || primaryUrl;
            if (!seenIdentities.has(idKey)) {
                seenIdentities.add(idKey);
                samples.push({
                    photo_id: String(photoId || ''),
                    photo_url: primaryUrl,
                    photo_url_large: largeUrl
                });
                if (!allUrls.includes(primaryUrl)) {
                    allUrls.push(primaryUrl);
                }
            }
        };

        const rawArrays = [
            item.photos_sample,
            item.photos,
            item.images,
            item.photoUrls,
            item.photo_urls_list,
            item.imageUrls,
            item.image_urls
        ];
        rawArrays.forEach(arr => {
            if (!Array.isArray(arr)) return;
            arr.forEach(p => {
                if (!p) return;
                if (typeof p === 'string') {
                    addPhotoPair(p, p, '');
                    return;
                }
                if (typeof p === 'object') {
                    const rawSmall = String(
                        p.photo_url || p.photoUrl || p.thumbnail || p.thumbnail_url ||
                        p.thumbnailUrl || p.url || p.image || p.image_url || p.src ||
                        p.video_thumbnail_url || ''
                    ).trim();
                    const rawLarge = String(
                        p.photo_url_large || p.photoUrlLarge || p.large_url ||
                        p.large_photo_url || p.original_url || p.originalPhotoUrl || ''
                    ).trim();
                    addPhotoPair(rawSmall, rawLarge, p.photo_id || p.id || '');
                }
            });
        });

        [
            item.photo_url, item.photoUrl, item.thumbnail, item.thumbnailUrl, item.thumbnail_url,
            item.main_photo, item.mainPhoto, item.featured_image, item.featuredImage,
            item.imageUrl, item.image_url, item.photo, item.image, item.street_view,
            item.streetView, item.hero_image, item.photo_url_large, item.photoUrlLarge
        ].forEach(u => {
            if (typeof u === 'string' && u.trim()) {
                addPhotoPair(u.trim(), u.trim(), '');
            } else if (u && typeof u === 'object') {
                addPhotoPair(u.photo_url || u.url || u.thumbnail || '', u.photo_url_large || u.url || '', u.photo_id || '');
            }
        });

        if (typeof item.photo_urls === 'string' && item.photo_urls.trim()) {
            item.photo_urls.split(/\s*,\s*/).forEach(u => addPhotoPair(u, u, ''));
        }

        const firstSmall = (samples[0] && samples[0].photo_url) || allUrls[0] || '';
        const firstLarge = (samples[0] && samples[0].photo_url_large) || firstSmall || '';
        return {
            photo_url: /^https?:\/\//i.test(firstSmall) ? firstSmall : '',
            photo_url_large: /^https?:\/\//i.test(firstLarge) ? firstLarge : (/^https?:\/\//i.test(firstSmall) ? firstSmall : ''),
            photo_urls: allUrls.join(', '),
            photos_sample: samples.slice(0, 30)
        };
    }

    const ScrappaClient = {
        extractItems(payload, dedupeMode) {
            const out = [];
            const rawDuplicates = [];
            const seen = new Set();
            const placeIdOnly = String(dedupeMode || '').toLowerCase() === 'place_id_only';
            const add = item => {
                if (!item || typeof item !== 'object') return;
                if (placeIdOnly) {
                    const placeId = compactText(item.place_id || item.placeId || item.placeID || item.googlePlaceId || item.googleMapsPlaceId || '');
                    if (placeId) {
                        const key = 'place:' + placeId;
                        if (seen.has(key)) {
                            rawDuplicates.push(item);
                            return;
                        }
                        seen.add(key);
                    }
                    out.push(item);
                    return;
                }
                const key = compactText([
                    item.place_id || item.placeId || item.business_id || item.businessId || '',
                    item.name || item.title || '',
                    item.full_address || item.address || ''
                ].join('|')) || hashString(JSON.stringify(item));
                if (seen.has(key)) {
                    rawDuplicates.push(item);
                    return;
                }
                seen.add(key);
                out.push(item);
            };
            const push = arr => { if (Array.isArray(arr)) arr.forEach(add); };
            push(payload && payload.items);
            push(payload && payload.results);
            if (payload && payload.data && typeof payload.data === 'object') {
                push(payload.data.items);
                push(payload.data.results);
            }
            out._rawDuplicates = rawDuplicates;
            return out;
        },

        normalizePlace(place, meta, index) {
            const row = Object.assign({}, place || {});
            const phones = place && (place.phone_numbers || place.phoneNumbers || place.phones);
            const phone = Array.isArray(phones) ? phones.find(Boolean) : (phones || place.phone_number || place.phoneNumber || place.phone || '');
            if (phone) {
                row.phone = phone;
                row.phone_number = phone;
                row.phoneNumber = phone;
            }
            if (place && place.full_address && !row.address) row.address = place.full_address;
            if (place && place.place_id && !row.placeId) row.placeId = place.place_id;
            if (place && place.placeId && !row.place_id) row.place_id = place.placeId;
            if (place && place.review_count != null && row.reviewCount == null) row.reviewCount = place.review_count;
            if (place && place.rating != null && row.review == null) row.review = place.rating;
            if (place && place.zip_code && !row.pincode) row.pincode = place.zip_code;
            if (place && place.current_status && !row.status) row.status = place.current_status;
            if (place && place.type && !row.category) row.category = place.type;
            if (place && Array.isArray(place.subtypes) && !row.categories) row.categories = place.subtypes.join(', ');
            if (place && place.business_id) {
                row.scrappa_business_id = place.business_id;
                row.business_id = place.business_id;
            }
            const photoInfo = extractPhotosFromItem(place);
            if (photoInfo.photo_url) row.photo_url = photoInfo.photo_url;
            if (photoInfo.photo_url_large) row.photo_url_large = photoInfo.photo_url_large;
            if (photoInfo.photo_urls) row.photo_urls = photoInfo.photo_urls;
            if (photoInfo.photos_sample && photoInfo.photos_sample.length) row.photos_sample = photoInfo.photos_sample;
            row._provider = 'scrappa';
            row._source_detail = (meta && meta.scrappaMode === 'advanced') ? 'scrappa_maps_advanced_search' : 'scrappa_maps_simple_search';
            applyProviderProvenance(row, place, Object.assign({}, meta || {}, { provider: 'scrappa' }), (meta && meta.settings) || { provider: 'scrappa' }, row._source_detail);
            return row;
        },

        buildCommonPayload(query, settings, limit, meta, excludeKeys) {
            const cleanQuery = buildCountryRestrictedQuery(
                normalizeQueryTextForApi(query),
                (settings && settings.countryFilter) || (meta && meta.country) || 'India'
            );
            return {
                query: cleanQuery,
                limit: Math.max(1, Math.min(200, parseInt(limit, 10) || 20)),
                hl: 'en',
                gl: ((settings && settings.countryCodeFilter) || getCountryCodeByName((settings && settings.countryFilter) || (meta && meta.country)) || 'IN').toLowerCase(),
                // Pincode runs intentionally dedupe only by Google Place ID. This
                // keeps the complete one-shot Scrappa response while still removing
                // exact listing duplicates. Broad city runs retain the stronger
                // cross-request fingerprint strategy used by the spatial harvester.
                dedupeMode: isPincodeSearch(meta) ? 'place_id_only' : 'stable_fingerprint',
                // Keep enough stable fingerprints to cover a large city run while
                // staying under the secure-proxy payload ceiling.
                excludeKeys: isPincodeSearch(meta) ? [] : (Array.isArray(excludeKeys) ? excludeKeys.slice(-80) : []),
                // Request only fields PocketLeads actually uses. Scrappa supports
                // comma-separated field projection; dropping photos/descriptions/owner
                // payload keeps 200-result pincode responses noticeably lighter.
                // Omit restrictive fields projection so Scrappa returns all native photo & profile fields
            };
        },

        async requestSimpleSearch(query, settings, pageNo, limit, meta, excludeKeys) {
            const payload = Object.assign(this.buildCommonPayload(query, settings, limit, meta, excludeKeys), {
                page: Math.max(0, parseInt(pageNo, 10) || 0)
            });
            // v98: keep the browser->Apps Script transport single-attempt so a late
            // successful response is never duplicated. The backend itself may recover
            // once only after a definitive Scrappa HTTP 503 response. A 65s client
            // window prevents false 'API failed' errors on larger 200-row responses.
            const data = await providerProxyRequest('scrappa', 'simpleSearch', payload, settings, { attempts: 1, timeoutMs: 65000 });
            const extracted = this.extractItems(data, payload.dedupeMode);
            const normMeta = Object.assign({}, meta || {}, { settings, scrappaPage: payload.page, scrappaMode: 'simple' });
            const normalized = extracted.map((place, index) => this.normalizePlace(place, normMeta, index));
            if (Array.isArray(extracted._rawDuplicates) && extracted._rawDuplicates.length) {
                normalized._rawDuplicates = extracted._rawDuplicates.map((place, index) => this.normalizePlace(place, normMeta, index));
            }
            return normalized;
        },

        async requestAdvancedSearch(query, settings, center, zoom, limit, meta, excludeKeys) {
            const payload = Object.assign(this.buildCommonPayload(query, settings, limit, meta, excludeKeys), {
                // Coordinates + gl already provide geo restriction. Appending the
                // whole city/country text can make Google snap every tile back to
                // the same central ranking, defeating spatial harvesting.
                query: normalizeQueryTextForApi(query),
                page: 0,
                zoom: String(Math.max(3, Math.min(21, parseInt(zoom, 10) || 14))),
                lat: String(Number(center && center.lat).toFixed(6)),
                lon: String(Number(center && center.lon).toFixed(6))
            });
            // Same credit rule as Simple Search: one logical tile = one upstream
            // request. Do not spend an invisible retry credit on 503.
            const data = await providerProxyRequest('scrappa', 'advancedSearch', payload, settings, { attempts: 1, timeoutMs: 65000 });
            return this.extractItems(data).map((place, index) => this.normalizePlace(place, Object.assign({}, meta || {}, { settings, scrappaPage: 0, scrappaMode: 'advanced', scrappaCenter: center, scrappaZoom: payload.zoom }), index));
        },

        median(values) {
            const nums = (values || []).map(Number).filter(Number.isFinite).sort((a, b) => a - b);
            if (!nums.length) return null;
            const mid = Math.floor(nums.length / 2);
            return nums.length % 2 ? nums[mid] : (nums[mid - 1] + nums[mid]) / 2;
        },

        percentile(values, p) {
            const nums = (values || []).map(Number).filter(Number.isFinite).sort((a, b) => a - b);
            if (!nums.length) return null;
            const pos = Math.max(0, Math.min(nums.length - 1, (nums.length - 1) * p));
            const lo = Math.floor(pos), hi = Math.ceil(pos);
            if (lo === hi) return nums[lo];
            const t = pos - lo;
            return nums[lo] * (1 - t) + nums[hi] * t;
        },

        deriveSpatialPlan(items, maxTiles) {
            const coords = (items || []).map(row => ({
                lat: Number(row && (row.latitude || row.lat || (row.location && row.location.lat))),
                lon: Number(row && (row.longitude || row.lng || row.lon || (row.location && (row.location.lng || row.location.lon))))
            })).filter(p => Number.isFinite(p.lat) && Number.isFinite(p.lon) && Math.abs(p.lat) <= 90 && Math.abs(p.lon) <= 180);
            if (coords.length < 8) return { center: null, tiles: [], zoom: 14 };
            const lats = coords.map(p => p.lat), lons = coords.map(p => p.lon);
            const center = { lat: this.median(lats), lon: this.median(lons) };
            if (!center || !Number.isFinite(center.lat) || !Number.isFinite(center.lon)) return { center: null, tiles: [], zoom: 14 };

            const latSpan = Math.max(0, (this.percentile(lats, 0.9) || center.lat) - (this.percentile(lats, 0.1) || center.lat));
            const lonSpan = Math.max(0, (this.percentile(lons, 0.9) || center.lon) - (this.percentile(lons, 0.1) || center.lon));
            // 4-8 km spacing is a good compromise for dense metro searches: large
            // enough to change the Google Maps viewport, small enough not to leave
            // holes between adjacent tiles.
            const latStep = Math.max(0.050, Math.min(0.085, latSpan > 0 ? latSpan * 0.50 : 0.060));
            const cosLat = Math.max(0.35, Math.cos(center.lat * Math.PI / 180));
            const lonStepFromSpan = lonSpan > 0 ? lonSpan * 0.50 : (0.060 / cosLat);
            const lonStep = Math.max(0.055, Math.min(0.115, lonStepFromSpan));
            const zoom = Math.max(latSpan > 0.16 || lonSpan > 0.16 ? 13 : 14, 13);

            const offsets = [];
            for (let ring = 1; offsets.length < Math.max(0, maxTiles); ring += 1) {
                for (let x = -ring; x <= ring && offsets.length < maxTiles; x += 1) offsets.push({ x, y: -ring });
                for (let y = -ring + 1; y <= ring && offsets.length < maxTiles; y += 1) offsets.push({ x: ring, y });
                for (let x = ring - 1; x >= -ring && offsets.length < maxTiles; x -= 1) offsets.push({ x, y: ring });
                for (let y = ring - 1; y >= -ring + 1 && offsets.length < maxTiles; y -= 1) offsets.push({ x: -ring, y });
            }
            return {
                center,
                zoom,
                tiles: offsets.slice(0, maxTiles).map((o, i) => ({
                    index: i,
                    ring: Math.max(Math.abs(o.x), Math.abs(o.y)),
                    lat: center.lat + o.y * latStep,
                    lon: center.lon + o.x * lonStep
                }))
            };
        }
    };

    const MapsDetailEnricher = {
        decodeText(text) {
            let out = String(text || '');
            try {
                out = out.replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
                         .replace(/\\x([0-9a-fA-F]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
            } catch (e) {}
            return out.replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/<[^>]+>/g, ' ');
        },

        buildUrl(row, meta) {
            const direct = asString(row.map_link || row.googleMapsUrl || row.mapsUrl || row.link);
            if (direct && /^https?:\/\//i.test(direct) && /google\.[^/]+\/maps|maps\.app\.goo\.gl|goo\.gl\/maps/i.test(direct)) return direct;
            const placeId = firstValue(row, PLACE_ID_FIELDS);
            if (placeId) return PlaceIdManager.toMapsUrl(placeId);
            const q = [row.company_name || row.name || row.title, row.address, meta && (meta.location || meta.queryForApi || meta.query)].filter(Boolean).join(' ');
            return q ? ('https://www.google.com/maps/search/' + encodeURIComponent(q)) : '';
        },

        parseAddress(text, row, meta) {
            const decoded = this.decodeText(text).replace(/\s+/g, ' ');
            const city = row.city || inferLocationFromQuery((meta && (meta.location || meta.queryForApi || meta.query)) || '') || 'Kolkata';
            const cityRx = new RegExp('([^\"<>]{5,220}\\b' + escapeRegExp(city) + '\\b[^\"<>]{0,160})', 'i');
            const pinRx = new RegExp('([^\"<>]{5,220}\\b[1-9][0-9]{5}\\b[^\"<>]{0,80})', 'i');
            const m = decoded.match(pinRx) || decoded.match(cityRx);
            if (!m || !m[1]) return '';
            let addr = m[1].replace(/\n/g, ' ').replace(/\+/g, ' ').replace(/\s+/g, ' ').trim();
            addr = addr.replace(/^(address|directions|website|phone)[:\s-]*/i, '').trim();
            if (addr.length > 220) addr = addr.slice(0, 220).replace(/[,\s]+[^,]*$/, '');
            return addr;
        },

        async fetchDetails(row, meta) {
            const url = this.buildUrl(row, meta);
            if (!url) return {};
            const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
            const timer = controller ? setTimeout(() => { try { controller.abort(); } catch (e) {} }, 4200) : null;
            try {
                const response = await fetch(url, {
                    method: 'GET',
                    credentials: 'include',
                    signal: controller ? controller.signal : undefined,
                    headers: { 'Accept-Language': 'en-IN,en;q=0.9' }
                });
                const html = await response.text();
                const decoded = this.decodeText(html);
                const out = {};
                const phone = extractIndianPhoneFromContext(decoded);
                if (phone) out.phone = phone;
                const address = this.parseAddress(decoded, row, meta);
                if (address) out.address = address;
                const websiteMatch = decoded.match(/https?:\/\/(?![^"\s]*google\.|[^"\s]*gstatic\.|[^"\s]*schema\.org)[^"'\s<>]{5,160}/i);
                if (websiteMatch) out.website = cleanUrlLike(websiteMatch[0]);
                return out;
            } catch (e) {
                return {};
            } finally {
                if (timer) clearTimeout(timer);
            }
        }
    };

    const PlaceIdManager = {
        deduplicate(placeIds) {
            const seen = new Set();
            const out = [];
            (placeIds || []).forEach(id => {
                const clean = String(id || '').trim();
                if (!clean) return;
                const key = clean.toLowerCase();
                if (seen.has(key)) return;
                seen.add(key);
                out.push(clean);
            });
            return out;
        },

        toMapsUrl(placeId, query) {
            const clean = String(placeId || '').trim();
            return clean ? 'https://www.google.com/maps/place/?q=place_id:' + encodeURIComponent(clean) : '';
        },

        toCidMapsUrl(cid) {
            const clean = String(cid || '').trim();
            return clean ? 'https://www.google.com/maps?cid=' + encodeURIComponent(clean) : '';
        },

        isAlreadyScraped(local, rowOrPlaceId) {
            local = local || {};
            const candidate = typeof rowOrPlaceId === 'object' ? rowOrPlaceId : { place_id: rowOrPlaceId, cid: rowOrPlaceId };
            const key = rowFingerprint(candidate);
            if (!key) return false;
            const rawId = String(firstValue(candidate, PLACE_ID_FIELDS) || candidate.cid || '').trim().toLowerCase();
            const queue = local.apifyQueue || {};
            const queued = Array.isArray(queue.placeIdQueue) ? queue.placeIdQueue : [];
            if (rawId && queued.some(item => {
                const itemId = String(item && (item.placeId || item.place_id || item.cid) || '').trim().toLowerCase();
                const terminal = /^(saved|duplicate_before_dom|duplicate_after_dom)$/i.test(String(item && item.status || ''));
                return terminal && itemId === rawId;
            })) return true;
            const rows = Array.isArray(local.collect) ? local.collect : [];
            return rows.some(row => rowFingerprint(row) === key);
        }
    };

    const CountryFilter = {
        getCountry(meta, settings) {
            return String((meta && meta.country) || (settings && settings.countryFilter) || '').trim();
        },

        getCountryCode(country, settings) {
            return String((settings && settings.countryCodeFilter) || getCountryCodeByName(country) || '').trim().toUpperCase();
        },

        getSearchSignals(meta) {
            const q = compactText([meta && meta.query, meta && meta.queryForApi, meta && meta.location].filter(Boolean).join(' '));
            return q.split(/[^a-z0-9]+/).filter(token => token.length >= 4 && !['near', 'best', 'with', 'india'].includes(token));
        },

        isExplicitCountryMatch(text, country, code) {
            const lower = compactText(text);
            if (!lower) return null;
            const c = compactText(country);
            const cc = compactText(code);
            if (c && lower === c) return true;
            if (cc && lower === cc.toLowerCase()) return true;
            if (c && lower.includes(c)) return true;
            if (cc && new RegExp('\\b' + cc.toLowerCase() + '\\b').test(lower)) return true;
            return null;
        },

        isAllowed(row, item, meta, settings) {
            if (!settings || settings.enforceCountryFilter === false) return true;
            const country = this.getCountry(meta, settings);
            if (!country) return true;
            const code = this.getCountryCode(country, settings);
            const text = compactText([
                row && row.address, row && row.city, row && row.state, row && row.pincode, row && row.map_link, row && row.title, row && row.company_name,
                firstValue(item, ['address', 'fullAddress', 'formattedAddress', 'city', 'state', 'postalCode', 'url', 'googleMapsUrl'])
            ].filter(Boolean).join(' '));
            const countryFields = [
                row && row.country, row && row.country_code, row && row.countryCode, row && row.address_country, row && row.addressCountry,
                firstValue(item, ['country', 'countryCode', 'country_code', 'address.country', 'address.countryCode', 'address.country_code', 'location.country', 'location.countryCode'])
            ].filter(Boolean).join(' ');
            const cLower = compactText(country);

            if (cLower === 'india' || code === 'IN') {
                // v57: safe country filter. Do not drop genuine rows just because a
                // countryCode/internal metadata field is blank or misleading. Reject only
                // when we have a clear foreign signal and no Indian address/pincode/query signal.
                const hasPositiveIndia = INDIA_POSITIVE_SIGNALS.some(sig => text.includes(sig)) || /\b[1-9][0-9]{5}\b/.test(text);
                const hasNegativeForeign = INDIA_NEGATIVE_SIGNALS.some(sig => text.includes(sig));
                if (hasPositiveIndia) return true;
                const explicit = this.isExplicitCountryMatch(countryFields, country, code);
                if (explicit === true) return true;
                const searchTokens = this.getSearchSignals(meta);
                if (searchTokens.length && searchTokens.some(token => text.includes(token))) return true;
                const source = compactText((row && row.source) || (item && item.source) || '');
                if ((source.includes('serper') || (meta && meta.queryForApi)) && queryHasIndiaLocationSignal(meta)) return true;
                if (hasNegativeForeign) return false;
                // Only reject explicit country fields when they contain a real foreign country
                // name/code; otherwise keep rows so dashboard does not become empty.
                const foreignCountryText = compactText(countryFields);
                if (foreignCountryText && !/(india|bharat|\bin\b)/i.test(foreignCountryText)) {
                    const knownForeign = Object.keys(COUNTRY_NAME_TO_CODE).some(name => name !== 'india' && name !== 'bharat' && foreignCountryText.includes(name));
                    if (knownForeign) return false;
                }
                return true;
            }

            const explicit = this.isExplicitCountryMatch(countryFields, country, code);
            if (explicit === true) return true;
            if (countryFields && explicit !== true) return false;
            if (cLower && text.includes(cLower)) return true;
            return true;
        }
    };

    const DatasetNormalizer = {
        normalizeItem(item, meta, index, settings) {
            const row = {};
            row.keyword = meta.keyword || meta.query || '';
            row.location = meta.location || '';
            const itemCountryHint = firstValue(item, ['country_code', 'countryCode', 'country', 'address.countryCode', 'address.country']) || (meta && meta.country) || (settings && settings.countryFilter) || '';
            const itemAddressHint = firstValue(item, ['full_address', 'address', 'formattedAddress', 'streetAddress']) || (meta && meta.location) || '';
            activeTaskCountryDialPrefix = resolveTaskCountryDialPrefix(itemCountryHint, itemAddressHint);
            if (item && (item.country_code || item.countryCode)) row.country_code = asString(item.country_code || item.countryCode).toUpperCase();
            if ((meta && meta.country) || (settings && settings.countryFilter)) row.country = asString((meta && meta.country) || (settings && settings.countryFilter));

            Object.keys(FIELD_MAP).forEach(target => {
                const value = firstValue(item, FIELD_MAP[target]);
                if (value) row[target] = value;
            });
            const normalizedEmails = extractEmailValues([
                row.email_1,
                firstValue(item, FIELD_MAP.email_1),
                item && item.emails,
                item && item.emailAddresses
            ].filter(Boolean).join(', '));
            if (normalizedEmails.length) row.email_1 = normalizedEmails.join(', ');
            else delete row.email_1;
            if (!row.phone) {
                const trustedPhone = extractSerperPhone(item);
                if (trustedPhone) row.phone = trustedPhone;
            }
            if (!row.phone && row.phone_number) row.phone = row.phone_number;
            if (!row.phone_number && row.phone) row.phone_number = row.phone;
            if (!row.address || isShortAddress(row.address)) {
                const trustedAddress = extractSerperAddress(item);
                if (trustedAddress && (!row.address || trustedAddress.length > String(row.address).length)) row.address = trustedAddress;
            }
            if (!row.website) {
                const trustedWebsite = extractSerperWebsite(item);
                if (trustedWebsite) row.website = trustedWebsite;
            }
            if (row.phone) {
                const cleanPhone = normalizeBusinessPhone(row.phone);
                if (cleanPhone) { row.phone = cleanPhone; row.phone_number = cleanPhone; }
                else {
                    if (!row.address && looksLikeAddressText(row.phone)) row.address = row.phone;
                    delete row.phone;
                    delete row.phone_number;
                }
            }

            const detectedPlaceId = ApifyClient.extractPlaceId(item) || '';
            const scrappaBusinessId = asString(item && (item.scrappa_business_id || item.business_id || item.businessId));
            if (scrappaBusinessId) {
                row.scrappa_business_id = scrappaBusinessId;
                row.business_id = scrappaBusinessId;
            }
            const detectedCid = row.cid || firstValue(item, ['cid', 'placeCid', 'googleCid', 'dataCid']) || '';
            if (detectedPlaceId) {
                row.place_id = detectedPlaceId;
                row.cid = row.cid || detectedCid || detectedPlaceId;
            } else if (detectedCid) {
                row.cid = detectedCid;
            }

            if (!row.map_link && item && item.url) row.map_link = asString(item.url);
            if (!row.map_link && item && item.googleMapsUrl) row.map_link = asString(item.googleMapsUrl);
            if (!row.map_link && item && item.link) row.map_link = asString(item.link);
            if (!row.place_id && row.map_link) {
                const fromUrl = extractPlaceIdFromUrl(row.map_link);
                if (fromUrl && !/^\d{8,}$/.test(fromUrl)) {
                    row.place_id = fromUrl;
                    row.cid = row.cid || fromUrl;
                } else if (fromUrl && !row.cid) {
                    row.cid = fromUrl;
                }
            }
            enrichRowFromAddress(row, item, meta, settings);
            {
                const validChij = /^ChIJ[A-Za-z0-9_-]{10,}$/.test(String(row.place_id || '').trim()) ? String(row.place_id).trim() : '';
                const numericCid = /^\d{10,22}$/.test(String(detectedCid || row.cid || '').trim()) ? String(detectedCid || row.cid).trim() : '';
                const queryParts = [row.company_name, row.address || row.city || row.location].filter(Boolean).join(', ').trim();
                const existingLink = String(row.map_link || '').trim();
                const isDirectPlacePage = /^https?:\/\/(?:www\.|maps\.)?google\.[^/]+\/maps\/place\/[^?]/i.test(existingLink);
                if (!isDirectPlacePage) {
                    if (queryParts && validChij) {
                        row.map_link = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(queryParts) + '&query_place_id=' + encodeURIComponent(validChij);
                    } else if (numericCid) {
                        row.map_link = PlaceIdManager.toCidMapsUrl(numericCid);
                    } else if (queryParts) {
                        row.map_link = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(queryParts);
                    } else if (row.place_id) {
                        row.map_link = PlaceIdManager.toMapsUrl(row.place_id);
                    }
                }
            }

            if (!row.phone_number && row.phone) row.phone_number = row.phone;
            if (!row.phone && row.phone_number) row.phone = row.phone_number;

            if (!row.cid) row.cid = hashString([row.map_link, row.company_name, row.address, row.phone_number || row.phone, row.website].filter(Boolean).join('|') || ('row_' + index));

            // Convert boolean closed flags into readable status when possible.
            if (String(row.status).toLowerCase() === 'true') row.status = 'Closed';
            if (String(row.status).toLowerCase() === 'false') row.status = '';

            // Do not copy arbitrary actor keys into visible rows. Provider
            // payloads often contain aliases, diagnostics, nested objects and
            // empty keys; exposing them creates duplicate/blank grid headers.
            // The fixed FIELD_MAP above is the only user-facing schema.
            if (!row.latitude || !row.longitude) {
                const location = item && item.location;
                if (location && typeof location === 'object') {
                    if (!row.latitude) row.latitude = firstValue(location, ['lat', 'latitude']);
                    if (!row.longitude) row.longitude = firstValue(location, ['lng', 'lon', 'longitude']);
                }
            }

            // Provider provenance has one canonical user-facing value. The active
            // backend setting wins; raw endpoint detail is kept privately for diagnostics.
            // This prevents Serper rows from being mislabeled as Apify by a generic fallback.
            const itemPhotos = extractPhotosFromItem(item);
            if (itemPhotos.photo_url && !row.photo_url) row.photo_url = itemPhotos.photo_url;
            if (itemPhotos.photo_url_large && !row.photo_url_large) row.photo_url_large = itemPhotos.photo_url_large;
            if (itemPhotos.photo_urls) row.photo_urls = itemPhotos.photo_urls;
            if (itemPhotos.photos_sample && itemPhotos.photos_sample.length) row.photos_sample = itemPhotos.photos_sample;

            const rawSourceDetail = (item && (item._source_detail || item.source)) || (meta && meta.serperEndpoint) || (settings && settings.provider === 'apify' ? 'apify_dataset' : '');
            applyProviderProvenance(row, item, meta, settings, rawSourceDetail);
            row.scraped_at = row.scraped_at || nowIso();
            return row;
        },

        normalizeItems(items, meta, settings) {
            // Collect rows that pass the country check, then optionally filter
            // them by the category keywords derived from the search query. Every
            // raw item removed here is also written to skippedDetails so the
            // Export Skipped button can explain Read > Saved differences.
            let filteredByCountry = 0;
            let filteredByCategory = 0;
            let duplicateInBatch = 0;
            const skippedDetails = [];
            const queryText = meta && (meta.queryForApi || meta.query) || '';
            const allowedKeywords = extractCategoryKeywords(queryText, meta, settings);
            const candidateRows = [];
            (items || []).forEach((item, index) => {
                if (!item || typeof item !== 'object') return;
                const row = this.normalizeItem(item, meta, index, settings);
                if (!CountryFilter.isAllowed(row, item, meta, settings)) {
                    filteredByCountry += 1;
                    skippedDetails.push(makeSkippedRecord(row, meta, 'Filtered outside selected country: ' + ((settings && (settings.countryFilter || settings.country)) || (meta && meta.country) || 'selected country') + '. No matching country/pincode/address signal found or foreign country signal detected.', 'Filtered', 'Normalizer:country'));
                    return;
                }
                candidateRows.push(row);
            });

            let workingRows;
            let categorySkipped = [];
            if (allowedKeywords && allowedKeywords.length > 0) {
                const matches = [];
                candidateRows.forEach(row => {
                    const name = String(row.company_name || row.name || row.title || '').toLowerCase();
                    const categoryText = String(row.category || row.categories || '').toLowerCase();
                    const haystack = (name + ' ' + categoryText).trim();
                    const hasKeyword = allowedKeywords.some(kw => haystack.includes(kw));
                    if (hasKeyword) matches.push(row);
                    else {
                        filteredByCategory += 1;
                        categorySkipped.push(makeSkippedRecord(row, meta, 'Filtered by search category mismatch. User category/search intent: ' + allowedKeywords.slice(0, 8).join(', ') + '. Row category/company: ' + (row.category || row.categories || row.company_name || 'blank'), 'Filtered', 'Normalizer:category'));
                    }
                });
                // Generic soft filter for any searched category. Apply only when
                // enough rows match the inferred business intent. Otherwise keep
                // all rows so unknown categories are not wrongly skipped.
                if (shouldApplyCategoryFilter(candidateRows.length, matches.length, allowedKeywords)) {
                    workingRows = matches;
                    skippedDetails.push(...categorySkipped);
                } else {
                    workingRows = candidateRows;
                    filteredByCategory = 0;
                    categorySkipped = [];
                }
            } else {
                workingRows = candidateRows;
            }

            const seen = new Set();
            const out = [];
            workingRows.forEach(row => {
                const key = rowFingerprint(row);
                if (!key || seen.has(key)) {
                    duplicateInBatch += 1;
                    skippedDetails.push(makeSkippedRecord(row, meta, 'Duplicate result within same API page/batch.', 'Duplicate', 'Normalizer:duplicate'));
                    return;
                }
                seen.add(key);
                out.push(row);
            });
            out.filteredByCountry = filteredByCountry;
            out.filteredByCategory = filteredByCategory;
            out.duplicateInBatch = duplicateInBatch;
            out.skippedDetails = skippedDetails;
            return out;
        }

    };

    const ProfileScraper = {
        tabsBySlot: {},
        slotState: {},
        defaultTimeoutMs: 20000,
        maxProfilesPerTab: 5,
        maxTabAgeMs: 3 * 60 * 1000,

        state(slotId) {
            const key = String(Math.max(0, parseInt(slotId, 10) || 0));
            if (!this.slotState[key]) {
                this.slotState[key] = { busy: false, profiles: 0, createdAt: 0, failures: 0 };
            }
            return this.slotState[key];
        },

        async getTab(tabId) {
            return new Promise(resolve => {
                if (!tabId || typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.get) return resolve(null);
                try {
                    chrome.tabs.get(tabId, tab => {
                        const last = chrome.runtime && chrome.runtime.lastError ? chrome.runtime.lastError : null;
                        if (last || !tab) return resolve(null);
                        resolve(tab);
                    });
                } catch (e) { resolve(null); }
            });
        },

        async ensureTab() {
            throw new Error('Visible Google Maps profile tabs are disabled. Use Ghost Mode offscreen extraction.');
        },

        closeSlot(slotId) {
            const slot = String(Math.max(0, parseInt(slotId, 10) || 0));
            const id = this.tabsBySlot[slot] || 0;
            this.tabsBySlot[slot] = 0;
            const state = this.state(slot);
            state.profiles = 0;
            state.createdAt = 0;
            state.busy = false;
            if (!id || typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.remove) return Promise.resolve();
            return new Promise(resolve => {
                try { chrome.tabs.remove(id, function () { try { void chrome.runtime.lastError; } catch (e) {} resolve(); }); }
                catch (e) { resolve(); }
            });
        },

        async closeLegacyTabsOnly() {
            // Close in-memory tabs created by this scraper instance first.
            const closes = Object.keys(this.tabsBySlot).map(slot => this.closeSlot(slot));
            await Promise.allSettled(closes);

            // Older releases persisted tab IDs in the durable queue. The MV3 service
            // worker can restart and lose tabsBySlot, so read those IDs before the
            // first new run overwrites the checkpoint. Close only inactive recorded
            // tabs whose URL still looks like our old blank/Maps/error profile page.
            const local = await getLocalAsync().catch(() => null);
            const queue = local && local.apifyQueue && typeof local.apifyQueue === 'object' ? local.apifyQueue : null;
            const savedIds = Array.isArray(queue && queue.managedTabIds) ? queue.managedTabIds : [];
            const safeUrl = value => {
                const url = String(value || '');
                if (url === 'about:blank' || /^chrome-error:\/\//i.test(url)) return true;
                try {
                    const u = new URL(url);
                    const googleHost = /^(?:www\.|maps\.)?google\.(?:com|co\.in)$/i.test(u.hostname);
                    const consentHost = /(^|\.)consent\.google\.(?:com|co\.in)$/i.test(u.hostname);
                    return consentHost || (googleHost && (/^\/maps(?:\/|$)/i.test(u.pathname) || /^\/sorry(?:\/|$)/i.test(u.pathname)));
                } catch (_) { return false; }
            };
            const closeSavedTab = async rawId => {
                const id = Number(rawId);
                if (!Number.isInteger(id) || id <= 0) return;
                const tab = await new Promise(resolve => {
                    if (!chrome || !chrome.tabs || typeof chrome.tabs.get !== 'function') return resolve(null);
                    try { chrome.tabs.get(id, result => { const err = chrome.runtime && chrome.runtime.lastError; resolve(err ? null : (result || null)); }); }
                    catch (_) { resolve(null); }
                });
                if (!tab || tab.active || !safeUrl(tab.url || tab.pendingUrl || '')) return;
                await new Promise(resolve => {
                    try { chrome.tabs.remove(id, () => { try { void chrome.runtime.lastError; } catch (_) {} resolve(); }); }
                    catch (_) { resolve(); }
                });
            };
            // Avoid a long serial scan when an older release left dozens of tabs.
            // Work in small bounded groups so Chrome remains responsive.
            for (let i = 0; i < savedIds.length; i += 10) {
                await Promise.all(savedIds.slice(i, i + 10).map(closeSavedTab));
            }
            // Also sweep any unrecorded inactive about:blank, chrome-error://, consent/sorry,
            // or direct place_id Maps profile tabs left behind in the browser.
            const orphanSafeUrl = value => {
                const url = String(value || '');
                if (url === 'about:blank' || /^chrome-error:\/\//i.test(url)) return true;
                try {
                    const u = new URL(url);
                    const googleHost = /^(?:www\.|maps\.)?google\.(?:com|co\.in)$/i.test(u.hostname);
                    const consentHost = /(^|\.)consent\.google\.(?:com|co\.in)$/i.test(u.hostname);
                    const placeProfile = /^\/maps(?:\/|$)/i.test(u.pathname) && /[?&](?:q=place_id(?::|%3A)|query_place_id=|place_id=)/i.test(url);
                    return consentHost || (googleHost && (placeProfile || /^\/sorry(?:\/|$)/i.test(u.pathname)));
                } catch (_) { return false; }
            };
            if (typeof chrome !== 'undefined' && chrome && chrome.tabs && typeof chrome.tabs.query === 'function') {
                const allTabs = await new Promise(resolve => {
                    try { chrome.tabs.query({}, list => { const err = chrome.runtime && chrome.runtime.lastError; resolve(err || !Array.isArray(list) ? [] : list); }); }
                    catch (_) { resolve([]); }
                });
                const orphanIds = allTabs
                    .filter(tab => tab && Number.isInteger(tab.id) && !tab.active && !tab.pinned && !(typeof self !== 'undefined' && self.PocketLeadsGhostMode && typeof self.PocketLeadsGhostMode.isActiveTab === 'function' && self.PocketLeadsGhostMode.isActiveTab(tab.id)) && orphanSafeUrl(tab.url || tab.pendingUrl || ''))
                    .map(tab => tab.id);
                for (let i = 0; i < orphanIds.length; i += 10) {
                    await Promise.all(orphanIds.slice(i, i + 10).map(id => new Promise(resolve => {
                        try { chrome.tabs.remove(id, () => { try { void chrome.runtime.lastError; } catch (_) {} resolve(); }); }
                        catch (_) { resolve(); }
                    })));
                }
            }
            // Relinquish all old IDs after this one safe cleanup pass, including
            // tabs that became active or were navigated by the user.
            if (queue && savedIds.length) {
                // Re-read just before writing so a concurrent progress checkpoint is
                // not overwritten by the stale object inspected above.
                const latest = await getLocalAsync().catch(() => null);
                if (latest && latest.apifyQueue && Array.isArray(latest.apifyQueue.managedTabIds)) {
                    latest.apifyQueue.managedTabIds = [];
                    await setLocalAsync(latest).catch(() => null);
                }
            }
        },

        closeAllTabs() {
            const closes = [this.closeLegacyTabsOnly()];
            // Also release the offscreen document and the single session-recorded
            // legacy fallback tab, if any. No broad tab enumeration.
            try {
                if (typeof self !== 'undefined' && self.PocketLeadsGhostMode && typeof self.PocketLeadsGhostMode.close === 'function') {
                    closes.push(Promise.resolve(self.PocketLeadsGhostMode.close()).catch(() => null));
                }
            } catch (e) {}
            return Promise.allSettled(closes).then(() => undefined);
        },

        // Backward-compatible alias used by older completion/stop handlers.
        closeReusableTab() {
            return this.closeAllTabs();
        },

        getManagedTabIds() {
            return Object.values(this.tabsBySlot).map(x => parseInt(x, 10) || 0).filter(Boolean);
        },

        scrapeUrl() {
            return Promise.reject(new Error('Visible Google Maps profile tabs are disabled. Use Ghost Mode offscreen extraction.'));
        },

        async scrapePlaceId(placeId, meta, settings, slotId) {
            const cleanId = String(placeId || '').trim();
            if (!cleanId) throw new Error('Missing Google Place ID.');
            const url = PlaceIdManager.toMapsUrl(cleanId, meta && (meta.queryForApi || meta.query || [meta.keyword, meta.location].filter(Boolean).join(' ')));
            const slot = Math.max(0, parseInt(slotId, 10) || 0);
            const payload = {
                placeId: cleanId,
                keyword: meta && meta.keyword || '',
                location: meta && meta.location || '',
                query: meta && (meta.queryForApi || meta.query) || '',
                timeoutMs: 8000,
                runEventId: (settings && settings.runEventId) || '',
                url,
                source: 'Google Maps', _provider: 'googlemaps', _source_detail: 'google_maps_place_id_profile_ghost'
            };

            // Ghost Mode uses the hidden offscreen bridge only. Visible profile-tab
            // fallback is disabled; each Place ID has one direct navigation attempt.
            const ghost = typeof self !== 'undefined' && self.PocketLeadsGhostMode;
            if (ghost && typeof ghost.request === 'function') {
                // The bridge owns the bounded retry policy. Do not multiply it
                // with a second controller retry loop.
                const data = await ghost.request(payload);
                if (!data || !String(data.company_name || '').trim()) {
                    throw new Error('Google Maps profile returned no business name. The profile was not saved.');
                }
                // Store the same field names that the dashboard and CSV consume.
                data.place_id = cleanId;
                data.cid = data.cid || cleanId;
                data.phone_number = data.phone_number || data.phone || '';
                data.phone = data.phone || data.phone_number;
                data.map_link = data.map_link || url;
                data.scraped_at = data.scraped_at || nowIso();
                data._dom_worker_slot = slot;
                data._ghost_mode = data._ghost_strategy !== 'background_tab_dom';
                data._dom_elapsed_ms = data._dom_elapsed_ms || 0;
                return data;
            }

            throw new Error('Ghost Mode requires the MV3 offscreen bridge. Reload PocketLeads in Chrome.');
        }
    };

    const DailyController = {
        running: false,
        stopped: false,
        restartRequested: false,
        clearRequested: false,
        _failPromise: null,
        _stopPromise: null,
        _terminalEventSent: '',
        _runEventId: '',

        parseTask(task) {
            const text = String(task || '').trim();
            if (!text) return { keyword: '', location: '', query: '' };
            if (text.includes('~in~')) {
                const parts = text.split('~in~');
                const keyword = (parts[0] || '').trim();
                const location = parts.slice(1).join('~in~').trim();
                return { keyword, location, query: (keyword + ' in ' + location).trim() };
            }
            return { keyword: text, location: '', query: text };
        },

        buildTaskListFromLocal(local) {
            const keywordLines = String(local.keywordTextarea || '').split('\n').map(x => x.trim()).filter(Boolean);
            const locationLines = String(local.locationTextarea || '').split('\n').map(x => x.trim()).filter(Boolean);
            const tasks = [];
            if (keywordLines.length && locationLines.length) {
                keywordLines.forEach(keyword => locationLines.forEach(location => tasks.push(`${keyword}~in~${location}`)));
            } else if (keywordLines.length) {
                keywordLines.forEach(query => tasks.push(query));
            }
            return tasks;
        },

        _queueWriteChain: Promise.resolve(),
        _taskWriteChain: Promise.resolve(),
        _resultWriteChain: Promise.resolve(),

        _liveSpyEvents: [],
        _liveSpySnapshot: null,
        _sessionSkippedRecords: [],

        emitDiagnosticSpy(type, detail = {}) {
            try {
                const now = new Date();
                const timeStr = now.toTimeString().slice(0, 8) + '.' + String(now.getMilliseconds()).padStart(3, '0');
                const entry = {
                    id: now.getTime().toString(36) + '-' + Math.random().toString(36).slice(2, 6),
                    time: timeStr,
                    iso: now.toISOString(),
                    type: String(type || 'INFO').toUpperCase(),
                    level: detail.level || (/ERROR|FAIL/.test(String(type || '')) ? 'error' : (/WARN|SKIP|FILTER|EMPTY|RETRY/.test(String(type || '')) ? 'warn' : 'info')),
                    taskIndex: detail.taskIndex || (this._liveSpySnapshot && this._liveSpySnapshot.taskIndex) || 0,
                    totalTasks: detail.totalTasks || (this._liveSpySnapshot && this._liveSpySnapshot.totalTasks) || 0,
                    query: detail.query || (this._liveSpySnapshot && this._liveSpySnapshot.currentQuery) || '',
                    keyword: detail.keyword || (this._liveSpySnapshot && this._liveSpySnapshot.currentKeyword) || '',
                    location: detail.location || (this._liveSpySnapshot && this._liveSpySnapshot.currentLocation) || '',
                    provider: detail.provider || (this._liveSpySnapshot && this._liveSpySnapshot.provider) || '',
                    rawCount: detail.rawCount != null ? detail.rawCount : null,
                    savedCount: detail.savedCount != null ? detail.savedCount : null,
                    skippedCount: detail.skippedCount != null ? detail.skippedCount : null,
                    duplicateCount: detail.duplicateCount != null ? detail.duplicateCount : null,
                    filteredCount: detail.filteredCount != null ? detail.filteredCount : null,
                    message: String(detail.message || ''),
                    errorCode: String(detail.errorCode || '')
                };
                if (!Array.isArray(this._liveSpyEvents)) this._liveSpyEvents = [];
                this._liveSpyEvents.push(entry);
                if (this._liveSpyEvents.length > 150) this._liveSpyEvents = this._liveSpyEvents.slice(-150);
                this._liveSpySnapshot = Object.assign({}, this._liveSpySnapshot || {}, {
                    updatedAt: entry.iso,
                    updatedTime: timeStr,
                    lastEventType: entry.type,
                    lastMessage: entry.message,
                    taskIndex: entry.taskIndex || (this._liveSpySnapshot && this._liveSpySnapshot.taskIndex) || 0,
                    totalTasks: entry.totalTasks || (this._liveSpySnapshot && this._liveSpySnapshot.totalTasks) || 0,
                    currentQuery: entry.query || (this._liveSpySnapshot && this._liveSpySnapshot.currentQuery) || '',
                    currentKeyword: entry.keyword || (this._liveSpySnapshot && this._liveSpySnapshot.currentKeyword) || '',
                    currentLocation: entry.location || (this._liveSpySnapshot && this._liveSpySnapshot.currentLocation) || '',
                    provider: entry.provider || (this._liveSpySnapshot && this._liveSpySnapshot.provider) || ''
                });
                if (entry.level === 'error' || entry.errorCode) {
                    this._liveSpySnapshot.lastError = entry.message;
                    this._liveSpySnapshot.lastErrorCode = entry.errorCode || entry.type;
                    this._liveSpySnapshot.lastErrorAt = timeStr;
                }
                if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
                    chrome.runtime.sendMessage({
                        action: 'PL_LIVE_SPY_EVENT',
                        event: entry,
                        snapshot: this._liveSpySnapshot
                    }, () => { try { void chrome.runtime.lastError; } catch (_) {} });
                }
            } catch (_) {}
        },

        _sessionSkippedKeys: null,
        recordSessionSkipped(records) {
            if (!Array.isArray(records) || !records.length) return;
            if (!Array.isArray(this._sessionSkippedRecords)) this._sessionSkippedRecords = [];
            if (!(this._sessionSkippedKeys instanceof Set)) {
                this._sessionSkippedKeys = new Set(this._sessionSkippedRecords.map(r => [r.source || '', r.placeId || r.place_id || '', r.cid || '', r.companyName || r.company_name || '', r.query || '', r.location || '', r.status || '', r.reason || ''].join('|')));
            }
            records.forEach(r => {
                if (!r || typeof r !== 'object') return;
                const k = [r.source || '', r.placeId || r.place_id || '', r.cid || '', r.companyName || r.company_name || '', r.query || '', r.location || '', r.status || '', r.reason || ''].join('|');
                if (this._sessionSkippedKeys.has(k)) return;
                this._sessionSkippedKeys.add(k);
                this._sessionSkippedRecords.push(r);
            });
            if (this._sessionSkippedRecords.length > 250) {
                this._sessionSkippedRecords = this._sessionSkippedRecords.slice(-250);
            }
            if (!this._skippedFlushTimer && typeof setTimeout === 'function') {
                this._skippedFlushTimer = setTimeout(() => {
                    this._skippedFlushTimer = null;
                    try {
                        if (typeof chromeStorageSetAsync === 'function') {
                            void chromeStorageSetAsync({ plSessionSkippedRecords: this._sessionSkippedRecords });
                        }
                    } catch (_) {}
                }, 800);
            }
        },

        async flushSessionSkipped() {
            if (this._skippedFlushTimer && typeof clearTimeout === 'function') {
                clearTimeout(this._skippedFlushTimer);
                this._skippedFlushTimer = null;
            }
            try {
                if (typeof chromeStorageSetAsync === 'function' && Array.isArray(this._sessionSkippedRecords)) {
                    await chromeStorageSetAsync({ plSessionSkippedRecords: this._sessionSkippedRecords });
                }
            } catch (_) {}
        },

        _authoritativeResultCount: 0,
        _latestCollectPreview: null,
        _stampAuthoritativeResults(local, queue) {
            if (this.clearRequested || !local) return;
            const floor = Math.max(0, parseInt(this._authoritativeResultCount, 10) || 0);
            if (floor > 0) {
                local.resultStoreCount = Math.max(parseInt(local.resultStoreCount, 10) || 0, floor);
                if (Array.isArray(this._latestCollectPreview) && this._latestCollectPreview.length > (Array.isArray(local.collect) ? local.collect.length : 0)) {
                    local.collect = this._latestCollectPreview.slice(-RESULT_PREVIEW_LIMIT);
                }
                local.collectIsPreview = local.resultStoreCount > (Array.isArray(local.collect) ? local.collect.length : 0);
                if (queue && typeof queue === 'object') {
                    queue.resultStoreCount = local.resultStoreCount;
                    queue.scrapedCount = Math.max(parseInt(queue.scrapedCount, 10) || 0, local.resultStoreCount);
                }
            }
        },

        _nextDispatchSlotAt: 0,
        async acquireStaggeredDispatchSlot(minGapMs = 120) {
            const now = Date.now();
            const scheduled = Math.max(now, (this._nextDispatchSlotAt || 0));
            this._nextDispatchSlotAt = scheduled + minGapMs;
            const waitMs = scheduled - now;
            if (waitMs > 0 && typeof sleep === 'function') {
                await sleep(waitMs);
            }
        },

        async updateQueue(patch) {
            // Serialize read-modify-write cycles. API workers run concurrently and
            // uncoordinated chrome.storage writes can overwrite newer progress.
            const write = async () => {
                const local = await getLocalAsync();
                const existing = Object.assign(buildEmptyQueue(), local.apifyQueue || {});
                if(patch && patch._expectedRunId){
                    if(patch._expectedRunId!==existing.runEventId || this.stopped || this.clearRequested || !local.status)return existing;
                    patch=Object.assign({},patch);delete patch._expectedRunId;
                }
                const queue = Object.assign(buildEmptyQueue(), existing, patch || {}, { lastUpdatedAt: nowIso() });
                if (this.running && Array.isArray(this._activeTaskList)) {
                    local.taskList = this._activeTaskList.slice();
                }
                if (this.running && this._totalTaskCount > 0) {
                    queue.totalTasks = Math.max(queue.totalTasks || 0, this._totalTaskCount);
                    queue.apiTasksTotal = Math.max(queue.apiTasksTotal || 0, this._totalTaskCount);
                }
                if (this.running && this._settledTaskCount != null) {
                    queue.completedTasks = this._settledTaskCount;
                    queue.apiTasksSettled = this._settledTaskCount;
                    queue.currentTaskIndex = Math.min(this._totalTaskCount || queue.totalTasks || 1, this._settledTaskCount + (Array.isArray(this._activeTaskList) && this._activeTaskList.length ? 1 : 0));
                }
                if (typeof this._stampAuthoritativeResults === 'function') this._stampAuthoritativeResults(local, queue);
                if (this._pincodeStatusesMap && Object.keys(this._pincodeStatusesMap).length) {
                    queue.pincodeStatuses = Object.assign({}, existing.pincodeStatuses || {}, this._pincodeStatusesMap);
                }
                // Never lose accumulated skipped records or monotonic counters during intermediate status updates
                if (Array.isArray(this._sessionSkippedRecords) && this._sessionSkippedRecords.length) {
                    queue.skipped = this._sessionSkippedRecords.slice(-300);
                } else if (Array.isArray(existing.skipped) && existing.skipped.length && (!patch || !Array.isArray(patch.skipped))) {
                    queue.skipped = existing.skipped.slice(-300);
                }
                if (this._liveSpySnapshot) queue.liveSpySnapshot = this._liveSpySnapshot;
                if (Array.isArray(this._liveSpyEvents) && this._liveSpyEvents.length) {
                    queue.liveSpyEvents = this._liveSpyEvents.slice(-80);
                }
                if (!queue.startedAt && local.scrapeStartedAt) queue.startedAt = local.scrapeStartedAt;
                if (queue.startedAt && !queue.finishedAt) queue.elapsedMs = elapsedMsFrom(queue.startedAt);
                local.apifyQueue = queue;
                if (queue.startedAt) local.scrapeStartedAt = queue.startedAt;
                if (queue.finishedAt) local.scrapeFinishedAt = queue.finishedAt;
                local.scrapeElapsedMs = queue.elapsedMs || local.scrapeElapsedMs || 0;
                if (patch && patch.currentQuery) {
                    local.activeQuery = patch.currentQuery;
                    local.activeKeyword = patch.currentKeyword || patch.currentQuery;
                    local.activeLocation = patch.currentLocation != null ? patch.currentLocation : (local.activeLocation || '');
                }
                await setLocalAsync(local);
                if (typeof self !== 'undefined' && self.PocketLeadsGhostMode && patch && (
                    Object.prototype.hasOwnProperty.call(patch, 'domProcessed') ||
                    Object.prototype.hasOwnProperty.call(patch, 'domSaved') ||
                    Object.prototype.hasOwnProperty.call(patch, 'domFailed') ||
                    Object.prototype.hasOwnProperty.call(patch, 'apiTasksSettled')
                )) {
                    try {
                        const total = Math.max(0, parseInt(queue.domTotal, 10) || parseInt(queue.totalPlaceIds, 10) || parseInt(queue.totalTasks, 10) || 0);
                        const current = Math.max(0, Math.min(total || Number.MAX_SAFE_INTEGER, parseInt(queue.domProcessed, 10) || parseInt(queue.apiTasksSettled, 10) || 0));
                        chrome.runtime.sendMessage({
                            type: 'PROGRESS',
                            current,
                            total,
                            percent: total ? Math.round((current / total) * 100) : 0,
                            stage: 'google_maps_profile_ghost',
                            ghostMode: true
                        }, () => { try { void chrome.runtime.lastError; } catch (e) {} });
                    } catch (e) {}
                }
                return queue;
            };
            const run = this._queueWriteChain.then(write, write);
            this._queueWriteChain = run.catch(() => null);
            return run;
        },

        _pendingQueuePatch: null,
        _lastQueueWriteAt: 0,

        async updateQueueThrottled(patch, minIntervalMs = 700, force = false) {
            this._pendingQueuePatch = Object.assign({}, this._pendingQueuePatch || {}, patch || {});
            const now = Date.now();
            if (!force && now - (this._lastQueueWriteAt || 0) < minIntervalMs) {
                return Object.assign(buildEmptyQueue(), this._pendingQueuePatch || {});
            }
            const toWrite = this._pendingQueuePatch || {};
            this._pendingQueuePatch = null;
            this._lastQueueWriteAt = now;
            return this.updateQueue(toWrite);
        },

        async flushQueueUpdates() {
            if (this._pendingQueuePatch) {
                const patch = this._pendingQueuePatch;
                this._pendingQueuePatch = null;
                this._lastQueueWriteAt = Date.now();
                return this.updateQueue(patch);
            }
            if (this._queueWriteChain) {
                try { await this._queueWriteChain; } catch (_) {}
            }
            return null;
        },

        queryStatusKey(meta) {
            const combined = meta && meta.keyword && meta.location ? `${meta.keyword} in ${meta.location}` : '';
            return compactText((meta && (combined || meta.query || meta.location || meta.queryForApi || meta.keyword)) || 'query') || String(Date.now());
        },

        _pincodeStatusesMap: null,
        async updatePincodeStatus(meta, patch, force = false) {
            if (!this._pincodeStatusesMap || typeof this._pincodeStatusesMap !== 'object') {
                this._pincodeStatusesMap = {};
            }
            const key = this.queryStatusKey(meta);
            const existing = this._pincodeStatusesMap[key] || {
                key,
                keyword: meta && meta.keyword || '',
                location: meta && meta.location || '',
                query: meta && (meta.queryForApi || meta.query) || '',
                status: 'pending',
                apiIds: 0,
                domTotal: 0,
                domProcessed: 0,
                saved: 0,
                failed: 0,
                skipped: 0,
                filtered: 0
            };
            this._pincodeStatusesMap[key] = Object.assign({}, existing, patch || {}, { lastUpdatedAt: nowIso() });
            if (force) await this.updateQueue({ pincodeStatuses: Object.assign({}, this._pincodeStatusesMap) });
            else await this.updateQueueThrottled({ pincodeStatuses: Object.assign({}, this._pincodeStatusesMap) }, 900, false);
            return this._pincodeStatusesMap[key];
        },

        async updatePlaceIdStatus(placeId, patch, force = false) {
            const clean = String(placeId || '').trim();
            if (!clean) return null;
            const local = await getLocalAsync();
            const q = Object.assign(buildEmptyQueue(), local.apifyQueue || {});
            const list = Array.isArray(q.placeIdQueue) ? q.placeIdQueue : [];
            const idx = list.findIndex(x => String(x && x.placeId || '').toLowerCase() === clean.toLowerCase());
            const base = idx >= 0 ? list[idx] : { placeId: clean, status: 'api_returned', createdAt: nowIso() };
            const updated = Object.assign({}, base, patch || {}, { placeId: clean, lastUpdatedAt: nowIso() });
            if (idx >= 0) list[idx] = updated;
            else list.push(updated);
            while (list.length > 5000) list.shift();
            q.placeIdQueue = list;
            local.apifyQueue = q;
            if (force) await setLocalAsync(local);
            else await this.updateQueueThrottled({ placeIdQueue: list }, 1200, false);
            return updated;
        },

        async failHard(errorOrMessage) {
            if (this._failPromise) return this._failPromise;
            const rawMessage = String(errorOrMessage && errorOrMessage.message ? errorOrMessage.message : (errorOrMessage || 'Unexpected scraping error'));
            const incomingCode = String(errorOrMessage && (errorOrMessage.code || errorOrMessage.providerReason) || '').toUpperCase();
            let publicMessage = /cannot read properties of undefined.*meta/i.test(rawMessage)
                ? 'A temporary search-queue synchronization issue was detected.'
                : rawMessage;
            let publicCode = incomingCode || (/cannot read properties of undefined.*meta/i.test(rawMessage) ? 'API_QUEUE_CLAIM_RACE' : 'UNEXPECTED_CONTROLLER_ERROR');
            let upgradeRequired = false;
            if (/LICENSE_EXPIRED|LICENCE_EXPIRED/.test(publicCode) || /licen[cs]e.*expired/i.test(rawMessage)) {
                publicCode = 'LICENSE_EXPIRED';
                publicMessage = `Your licence has expired. Scraping is paused. Contact ${SUPPORT_EMAIL} to renew your licence.`;
                upgradeRequired = true;
            } else if (/LICENSE_CREDIT_EXHAUSTED|ALL_CREDITS_EXHAUSTED|LICENCE_CREDIT_EXHAUSTED/.test(publicCode)) {
                publicCode = 'LICENSE_CREDIT_EXHAUSTED';
                publicMessage = `Your scraping credits are exhausted. Upgrade your plan to continue. Contact ${SUPPORT_EMAIL}.`;
                upgradeRequired = true;
            } else if (
                /NETWORK_SLOW|PROVIDER_NETWORK_TIMEOUT|REQUEST_UNCERTAIN|REQUEST_PENDING|PREFLIGHT_NOT_READY|ACCOUNT_PREFLIGHT|BACKEND_UNAVAILABLE|GHOST_EXTRACTION_FAILED/i.test(publicCode) ||
                /network|timeout|timed out|slow|abort|fetch failed|failed to fetch|offline|internet|connection|preparing in the background|did not finish loading|redirect dropped|temporarily unreachable|ghost tab/i.test(rawMessage)
            ) {
                publicCode = 'NETWORK_SLOW_RETRY';
                publicMessage = 'Network is slow or unstable right now. Your extracted leads and progress are safe — please check your internet connection and tap Try Again / Resume.';
            } else if (/NO_ELIGIBLE_PROVIDER|PROVIDER_FAILOVER_EXHAUSTED/.test(publicCode)) {
                if (/timeout|timed out|network|slow|abort|fetch|did not finish loading|ghost/i.test(rawMessage)) {
                    publicCode = 'NETWORK_SLOW_RETRY';
                    publicMessage = 'Network is slow or unstable right now. Your extracted leads and progress are safe — please check your internet connection and tap Try Again / Resume.';
                } else {
                    publicCode = 'SERVICE_TEMPORARILY_UNAVAILABLE';
                    publicMessage = rawMessage || 'No eligible provider. Ask the administrator to check provider configuration.';
                }
            }
            const runFailure = async () => {
                warn(rawMessage);
                const local = await getLocalAsync();
                local.status = false;
                if (!local._taskManager) local._taskManager = {};
                local._taskManager.isWorking = false;
                const failedAt = nowIso();
                const queueBefore = Object.assign(buildEmptyQueue(), local.apifyQueue || {});
                const pendingJobs = Array.isArray(queueBefore.placeIdQueue)
                    ? queueBefore.placeIdQueue.filter(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || ''))).length
                    : Math.max(0, parseInt(queueBefore.domPending, 10) || 0) + Math.max(0, parseInt(queueBefore.domRunning, 10) || 0);
                const tasksRemain = Array.isArray(local.taskList) && local.taskList.length > 0;
                const apiIncomplete = (parseInt(queueBefore.apiTasksSettled, 10) || 0) < (parseInt(queueBefore.apiTasksTotal, 10) || parseInt(queueBefore.totalTasks, 10) || 0);
                const preflightOnly = !!(errorOrMessage && errorOrMessage.preflightOnly);
                // Credit/expiry/preflight denials are not resumable scrape failures.
                // This prevents a zero-credit licence from producing Resume state,
                // keyword progress or fake per-task api_failed rows.
                const canResume = !preflightOnly && (pendingJobs > 0 || tasksRemain || apiIncomplete);
                const noRunProgress = (parseInt(queueBefore.totalApiResults, 10) || 0) === 0
                    && (parseInt(queueBefore.apiTasksDone, 10) || 0) === 0
                    && (parseInt(queueBefore.domProcessed, 10) || 0) === 0;
                if ((upgradeRequired || preflightOnly) && noRunProgress) {
                    queueBefore.pincodeStatuses = {};
                    queueBefore.apiTasksDone = 0;
                    queueBefore.apiTasksFailed = 0;
                    queueBefore.apiTasksSettled = 0;
                    queueBefore.completedTasks = 0;
                    queueBefore.failedCount = 0;
                    queueBefore.currentQuery = '';
                }
                local._taskManager.activeTask = canResume ? 'openMap' : null;
                if (Array.isArray(queueBefore.placeIdQueue)) {
                    queueBefore.placeIdQueue = queueBefore.placeIdQueue.map(item => {
                        if (String(item && item.status || '').toLowerCase() !== 'dom_running') return item;
                        return Object.assign({}, item, { status: 'retry_pending', reason: 'Worker interrupted; resumable checkpoint.', lastUpdatedAt: failedAt });
                    });
                }
                const statusMessage = canResume
                    ? (/progress saved/i.test(publicMessage) ? publicMessage : publicMessage + ' Progress saved. Click Resume to continue.')
                    : publicMessage;
                const eventId = (this._runEventId || queueBefore.runEventId || makeRunEventId('run')) + ':error';
                const failedQueue = Object.assign(buildEmptyQueue(), queueBefore, {
                    status: canResume ? 'paused_recoverable' : 'failed',
                    statusMessage,
                    resumeAvailable: canResume,
                    domRunning: 0,
                    domPending: pendingJobs,
                    currentProfileUrl: '',
                    processing: null,
                    finishedAt: failedAt,
                    lastUpdatedAt: failedAt,
                    runEventId: this._runEventId || queueBefore.runEventId || '',
                    lastErrorCode: publicCode,
                    lastErrorDetail: rawMessage.slice(0, 1000),
                    lastErrorAt: failedAt,
                    lastTerminalEventId: eventId
                });
                failedQueue.elapsedMs = elapsedMsFrom(failedQueue.startedAt || local.scrapeStartedAt, failedAt);
                local.scrapeFinishedAt = failedAt;
                local.scrapeElapsedMs = failedQueue.elapsedMs;
                local.apifyQueue = failedQueue;
                try { await ProfileScraper.closeAllTabs(); } catch (e) {}
                await setLocalAsync(local);
                if (this._terminalEventSent !== eventId) {
                    this._terminalEventSent = eventId;
                    showSingleSystemNotification('pocketleads_scrape_status', upgradeRequired ? 'Upgrade Required' : 'Scraping Paused', statusMessage, eventId);
                    try { $box.send('scraping_error', { message: statusMessage, resumable: canResume, eventId, errorCode: failedQueue.lastErrorCode, upgradeRequired, supportEmail: SUPPORT_EMAIL }); } catch (e) {}
                    if (!/^(LICENSE_CREDIT_EXHAUSTED|ALL_CREDITS_EXHAUSTED|LICENCE_CREDIT_EXHAUSTED)$/i.test(publicCode)) {
                        try {
                            const snap = typeof chromeStorageGetAsync === 'function' ? await chromeStorageGetAsync(['license', 'pocketleadsAccount', 'plServerDownAlert']) : {};
                            const licObj = (snap && snap.license) || (snap && snap.pocketleadsAccount) || {};
                            const licKey = String(licObj.key || licObj.licenceKey || local.licenseKey || '').trim();
                            const existingAlert = snap && snap.plServerDownAlert;
                            const nowMs = Date.now();
                            const isRecentSameAlert = existingAlert && existingAlert.timestamp && (nowMs - Number(existingAlert.timestamp) < 15000);
                            if (!isRecentSameAlert) {
                                const failAlert = {
                                    id: 'ERR-RUN-' + String(publicCode || 'ISSUE').slice(0, 18) + '-' + String(nowMs).slice(-5),
                                    timestamp: nowMs,
                                    timeText: new Date().toLocaleString(),
                                    licenceKey: licKey || 'UNACTIVATED',
                                    apiId: String(failedQueue.apiId || (failedQueue.apifyKeyRow ? ('ROW-' + failedQueue.apifyKeyRow) : 'EXTRACTION')),
                                    keyRow: parseInt(failedQueue.apifyKeyRow || failedQueue.apiKeyRow, 10) || 0,
                                    provider: String(failedQueue.provider || 'auto'),
                                    httpStatus: parseInt(errorOrMessage && errorOrMessage.status, 10) || 0,
                                    errorCode: String(publicCode || 'EXTRACTION_ERROR'),
                                    upstreamCode: String(incomingCode || ''),
                                    upstreamError: String(rawMessage || statusMessage || 'Extraction error').slice(0, 500),
                                    query: String(failedQueue.currentQuery || local.activeQuery || (Array.isArray(local.taskList) && local.taskList[0]) || 'Extraction Task').slice(0, 200)
                                };
                                await chromeStorageSetAsync({ plServerDownAlert: failAlert });
                                try {
                                    if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
                                        chrome.runtime.sendMessage({ type: 'pl_server_down_alert', alert: failAlert }, () => {
                                            try { void (chrome.runtime && chrome.runtime.lastError); } catch (_) {}
                                        });
                                    }
                                } catch (_) {}
                                if (licKey) {
                                    void (async () => {
                                        try {
                                            const devId = await getInstallationDeviceId().catch(() => '');
                                            const logRes = await callAppsScript('logApiError', Object.assign({ key: licKey, deviceId: devId }, failAlert), { attempts: 1, timeoutMs: 12000 }).catch(() => null);
                                            if (!logRes || logRes.reason === 'unknown_action' || logRes.status === 'error') {
                                                const dedupId = 'auto-ext-err-' + licKey + '-' + failAlert.errorCode + '-' + String(nowMs).slice(0, -4);
                                                await callAppsScript('submitTicket', {
                                                    key: licKey,
                                                    deviceId: devId,
                                                    subject: `[AUTO EXTRACTION ERROR] ${failAlert.errorCode} (${failAlert.provider}) - Licence ${licKey}`.slice(0, 118),
                                                    message: `AUTOMATIC EXTRACTION ISSUE REPORT\nLicence Key: ${licKey}\nSource/API ID: ${failAlert.apiId} (Row ${failAlert.keyRow || '?'})\nProvider: ${failAlert.provider}\nError Code: ${failAlert.errorCode}\nQuery: ${failAlert.query}\nDetails: ${failAlert.upstreamError}`.slice(0, 1950),
                                                    requestId: dedupId
                                                }, { attempts: 1, timeoutMs: 12000 }).catch(() => null);
                                            }
                                        } catch (_) {}
                                    })();
                                }
                            }
                        } catch (_) {}
                    }
                }
                return false;
            };
            this._failPromise = runFailure();
            return this._failPromise;
        },

        // v86: Runtime liveness guard restored after the v85 commercial refactor.
        // Keep this method on DailyController because every producer/consumer loop
        // uses it as the single source of truth for Stop/Resume state.
        async isStillRunning() {
            if (this.stopped || this.clearRequested) return false;
            const now = Date.now();
            if (_lastKnownRunningAt > 0 && (now - _lastKnownRunningAt) < 400) {
                return _lastKnownRunningState && !this.stopped && !this.clearRequested;
            }
            const local = await getLocalAsync();
            const manager = local && local._taskManager && typeof local._taskManager === 'object'
                ? local._taskManager
                : {};
            return !!(
                local &&
                local.status === true &&
                manager.isWorking === true &&
                !this.stopped &&
                !this.clearRequested
            );
        },

        async start() {
            if (this.running) {
                if (this.stopped && !this.clearRequested) {
                    this.restartRequested = true;
                    log('Resume requested while previous worker is shutting down; queued automatic restart.');
                } else {
                    log('Controller already running; ignoring duplicate start');
                }
                return;
            }
            this.running = true;
            this.stopped = false;
            this.cancelProgressiveFeed();
            this.clearRequested = false;
            this.restartRequested = false;
            this._failPromise = null;
            this._stopPromise = null;
            this._terminalEventSent = '';
            this._runEventId = makeRunEventId('scrape');
            if (this._swKeepAliveTimer && typeof clearInterval === 'function') {
                clearInterval(this._swKeepAliveTimer);
                this._swKeepAliveTimer = null;
            }
            if (typeof setInterval === 'function') {
                this._swKeepAliveTimer = setInterval(() => {
                    try {
                        if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getPlatformInfo === 'function') {
                            chrome.runtime.getPlatformInfo(() => { try { void chrome.runtime.lastError; } catch (_) {} });
                        }
                    } catch (_) {}
                }, 15000);
            }
            // Publish a local-only start pulse immediately. This is deliberately
            // fire-and-forget so UI progress does not wait for licence/provider HTTP.
            try {
                const pulseAt = nowIso();
                void getLocalAsync().then(pulse => {
                    pulse = pulse || {};
                    pulse.status = true;
                    pulse._taskManager = Object.assign({}, pulse._taskManager || {}, { isWorking: true, activeTask: 'openMap', scrapeStarted: true });
                    pulse.apifyQueue = Object.assign(buildEmptyQueue(), pulse.apifyQueue || {}, {
                        status: 'starting', statusMessage: 'Starting PocketLeads and preparing the assigned provider…',
                        runEventId: this._runEventId, startedAt: pulse.apifyQueue?.startedAt || pulseAt,
                        finishedAt: '', lastUpdatedAt: pulseAt
                    });
                    return setLocalAsync(pulse);
                }).catch(err => warn('Immediate start progress update failed', err));
            } catch (pulseError) { warn('Immediate start progress update failed', pulseError); }
            try {
                // Clean up any legacy/orphan tabs in parallel with loading settings and storage
                // so Start immediately enters provider execution without serial startup lag.
                void Promise.allSettled([
                    Promise.resolve().then(() => self.PocketLeadsGhostMode?.cleanupTabs?.()),
                    ProfileScraper.closeLegacyTabsOnly()
                ]);
                let [settings, local] = await Promise.all([SettingsManager.load(), getLocalAsync()]);
                const freshTasks = this.buildTaskListFromLocal(local);
                const freshSignature = freshTasks.join('\n');
                const existingTasks = Array.isArray(local.taskList) ? local.taskList.map(x => String(x || '').trim()).filter(Boolean) : [];
                const existingQueue = Object.assign(buildEmptyQueue(), local.apifyQueue || {});
                const previousSignature = String(local.apifyTaskSignature || '').trim();
                const resumableStatus = /^(stopped|failed|partial_results|paused_recoverable|memory_recovery|google_pipeline_running|google_pipeline_draining|dataset_saved|streaming_results|serper_streaming|scrappa_streaming|switching_key|api_switching|resuming|no_results|no_results_after_filter)$/i.test(String(existingQueue.status || ''));
                const durableResumeJobs = existingQueue.jobRunId
                    ? await JobStore.getRun(existingQueue.jobRunId).catch(() => [])
                    : [];
                const hasPendingPlaceJobs = (Array.isArray(existingQueue.placeIdQueue) && existingQueue.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || ''))))
                    || durableResumeJobs.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
                const hasSavedProgress = (existingQueue.scrapedCount || 0) > 0 || (existingQueue.completedTasks || 0) > 0 || hasPendingPlaceJobs || (Array.isArray(local.collect) && local.collect.length > 0);
                const sameTaskSet = freshSignature && previousSignature && freshSignature === previousSignature;
                const settledBeforeResume = Math.max(0, parseInt(existingQueue.apiTasksSettled || existingQueue.completedTasks, 10) || 0);
                const totalBeforeResume = Math.max(freshTasks.length, parseInt(existingQueue.totalTasks || local.apifyTaskTotal, 10) || 0);
                const hasUnfinishedTasksByCount = totalBeforeResume > 0 && settledBeforeResume < totalBeforeResume && freshTasks.length > 0;
                const canResume = (existingTasks.length > 0 || hasPendingPlaceJobs || hasUnfinishedTasksByCount || !!existingQueue.resumeAvailable) && (sameTaskSet || !freshSignature || !!existingQueue.resumeAvailable) && (resumableStatus || hasSavedProgress || !!existingQueue.resumeAvailable);

                if (canResume && existingQueue.runEventId) this._runEventId = existingQueue.runEventId;
                if (canResume) {
                    if (existingTasks.length > 0) {
                        local.taskList = existingTasks;
                    } else if (freshTasks.length > 0) {
                        const resumeIdx = Math.min(settledBeforeResume, Math.max(0, freshTasks.length - 1));
                        local.taskList = freshTasks.slice(resumeIdx);
                    } else {
                        local.taskList = [];
                    }
                } else {
                    if (freshTasks.length) local.taskList = freshTasks;
                    local.apifyTaskSignature = freshSignature;
                    local.apifyTaskTotal = Array.isArray(local.taskList) ? local.taskList.length : 0;
                }
                if ((!Array.isArray(local.taskList) || !local.taskList.length) && !hasPendingPlaceJobs) {
                    throw new Error('No tasks or pending profiles to scrape. Please add a search query first.');
                }

                // v91 fast-start contract: route/licence/source discovery already ran
                // invisibly on icon click, licence activation or Clear Data. Start
                // consumes that prepared non-secret route only; it does not call
                // getApiConfig or wait for provider probing.
                this._activeSettingsKeyRow = 0;
                let backendConfig;
                try {
                    // Always clear any interrupted in-flight provider request marker on Start/Resume
                    // so Resume never gets blocked by a pre-close REQUEST_UNCERTAIN / attempt conflict.
                    try { await chromeStorageSetAsync({ plPendingProviderRequest: null }); } catch (_) {}
                    try {
                        if (typeof PocketLeadsAccount !== 'undefined' && PocketLeadsAccount && typeof PocketLeadsAccount.refresh === 'function') {
                            await Promise.race([
                                PocketLeadsAccount.refresh({ force: true }),
                                new Promise(r => typeof setTimeout === 'function' ? setTimeout(r, 4500) : r())
                            ]).catch(() => null);
                        }
                    } catch (_) {}
                    backendConfig = await ApiBackendManager.getPreparedScrapeConfig();
                } catch (preparedErr) {
                    if (preparedErr && typeof preparedErr === 'object') preparedErr.preflightOnly = true;
                    throw preparedErr;
                }
                settings = SettingsManager.validate(Object.assign({}, settings, backendConfig));
                settings.requestRunId = this._runEventId;

                if (!local._taskManager) local._taskManager = {};
                local.status = true;
                local._taskManager.isWorking = true;
                local.apifyQueue = Object.assign(buildEmptyQueue(), local.apifyQueue || {}, {
                    runEventId: this._runEventId,
                    lastTerminalEventId: '',
                    lastErrorCode: '',
                    lastErrorDetail: '',
                    lastErrorAt: ''
                });
                local._taskManager.activeTask = 'openMap';
                local._taskManager.scrapeStarted = true;
                local.fastMode = false;
                const sessionTotalTasks = canResume
                    ? (parseInt(existingQueue.totalTasks || local.apifyTaskTotal, 10) || Math.max(existingTasks.length, freshTasks.length, local.taskList.length))
                    : local.taskList.length;
                let runStartedAt = canResume ? (existingQueue.startedAt || local.scrapeStartedAt || nowIso()) : '';
                local.scrapeStartedAt = runStartedAt;
                local.scrapeFinishedAt = '';
                local.scrapeElapsedMs = canResume ? elapsedMsFrom(runStartedAt) : 0;
                local.apifyTaskTotal = sessionTotalTasks;
                local.apifyTaskSignature = freshSignature || previousSignature || local.taskList.join('\n');
                const completedTasksAtStart = canResume
                    ? Math.max(0, parseInt(existingQueue.apiTasksSettled || existingQueue.completedTasks, 10) || Math.max(0, sessionTotalTasks - (Array.isArray(local.taskList) ? local.taskList.length : 0)))
                    : 0;
                local.apifyQueue = buildEmptyQueue(Object.assign({}, canResume ? existingQueue : {}, {
                    status: canResume ? 'resuming' : 'preparing',
                    // Stable durable-queue identity survives Stop/Resume even though
                    // runEventId changes for terminal notification de-duplication.
                    jobRunId: canResume ? (existingQueue.jobRunId || existingQueue.runEventId || makeRunEventId('jobs')) : makeRunEventId('jobs'),
                    startedAt: runStartedAt,
                    finishedAt: '',
                    elapsedMs: elapsedMsFrom(runStartedAt),
                    statusMessage: canResume ? 'Resuming from last pending keyword/location...' : 'Data source prepared. Starting extraction...',
                    currentQuery: local.taskList[0] ? this.parseTask(local.taskList[0]).query : '',
                    totalTasks: sessionTotalTasks,
                    completedTasks: completedTasksAtStart,
                    totalPlaceIds: canResume ? (existingQueue.totalPlaceIds || 0) : 0,
                    totalApiResults: canResume ? (existingQueue.totalApiResults || 0) : 0,
                    scrapedCount: canResume ? (existingQueue.scrapedCount || (Array.isArray(local.collect) ? local.collect.length : 0) || 0) : 0,
                    failedCount: canResume ? (existingQueue.failedCount || 0) : 0,
                    filteredCount: canResume ? (existingQueue.filteredCount || 0) : 0,
                    duplicateSkippedCount: canResume ? (existingQueue.duplicateSkippedCount || 0) : 0,
                    pincodeStatuses: canResume ? (existingQueue.pincodeStatuses || {}) : {},
                    placeIdQueue: canResume ? (existingQueue.placeIdQueue || []) : [],
                    apiTasksTotal: sessionTotalTasks,
                    apiTasksDone: canResume ? (existingQueue.apiTasksDone || completedTasksAtStart || 0) : 0,
                    apiTasksFailed: canResume ? (existingQueue.apiTasksFailed || 0) : 0,
                    apiTasksSettled: canResume ? (existingQueue.apiTasksSettled || existingQueue.apiTasksDone || completedTasksAtStart || 0) : 0,
                    domTotal: canResume ? (existingQueue.domTotal || 0) : 0,
                    domProcessed: canResume ? (existingQueue.domProcessed || 0) : 0,
                    domPending: canResume ? (existingQueue.domPending || 0) : 0,
                    domRunning: 0,
                    domSaved: canResume ? (existingQueue.domSaved || 0) : 0,
                    domFailed: canResume ? (existingQueue.domFailed || 0) : 0,
                    domSkipped: canResume ? (existingQueue.domSkipped || 0) : 0,
                    completedWithErrors: canResume ? !!existingQueue.completedWithErrors : false,
                    resumeAvailable: false,
                    producerDone: canResume ? !!existingQueue.producerDone : false,
                    consumerDone: false,
                    domConcurrency: settings.provider === 'googlemaps' ? 2 : 1,
                    runEventId: this._runEventId,
                    managedRequestRunId: canResume ? (existingQueue.managedRequestRunId || existingQueue.runEventId || this._runEventId) : this._runEventId,
                    lastTerminalEventId: '',
                    lastErrorCode: '',
                    lastErrorDetail: '',
                    lastErrorAt: ''
                }));
                // Initialize session skipped records & live spy telemetry
                this._activeTaskList = Array.isArray(local.taskList) ? local.taskList.slice() : [];
                this._totalTaskCount = sessionTotalTasks;
                this._settledTaskCount = completedTasksAtStart;
                this._authoritativeResultCount = Math.max(
                    0,
                    parseInt(local.resultStoreCount, 10) || 0,
                    canResume ? (parseInt(existingQueue.scrapedCount, 10) || 0) : 0,
                    Array.isArray(local.collect) ? local.collect.length : 0
                );
                this._latestCollectPreview = Array.isArray(local.collect) ? local.collect.slice(-RESULT_PREVIEW_LIMIT) : [];
                this._pincodeStatusesMap = canResume ? Object.assign({}, existingQueue.pincodeStatuses || {}) : {};
                if (!canResume) {
                    this._sessionSkippedRecords = [];
                    this._sessionSkippedKeys = new Set();
                    this._liveSpyEvents = [];
                    this._liveSpySnapshot = {
                        taskIndex: 0,
                        totalTasks: sessionTotalTasks,
                        currentQuery: '',
                        currentKeyword: '',
                        currentLocation: '',
                        provider: settings.provider || '',
                        rawReturned: 0,
                        uniqueSaved: 0,
                        duplicateSkipped: 0,
                        filteredSkipped: 0,
                        failedTasks: 0,
                        lastError: '',
                        lastErrorCode: '',
                        lastErrorAt: ''
                    };
                    try { void chromeStorageSetAsync({ plSessionSkippedRecords: [] }); } catch (_) {}
                } else {
                    this._sessionSkippedRecords = Array.isArray(existingQueue.skipped) ? existingQueue.skipped.slice() : (this._sessionSkippedRecords || []);
                    this._sessionSkippedKeys = new Set(this._sessionSkippedRecords.map(r => [r.source || '', r.placeId || r.place_id || '', r.cid || '', r.companyName || r.company_name || '', r.query || '', r.location || '', r.status || '', r.reason || ''].join('|')));
                    this._liveSpyEvents = Array.isArray(existingQueue.liveSpyEvents) ? existingQueue.liveSpyEvents.slice() : (this._liveSpyEvents || []);
                }
                const resumeGen = canResume ? (Math.max(0, parseInt(existingQueue.resumeGeneration, 10) || 0) + 1) : 0;
                local.apifyQueue.resumeGeneration = resumeGen;
                this._resumeGeneration = resumeGen;

                // Pre-start beginExtraction for the first task in parallel with local storage writes
                // so the Apps Script routing round-trip overlaps with startup.
                this._prefetchedBeginRoute = null;
                this._prefetchedBeginRoutes = new Map();
                this._fastFinishAttempt = true;
                const prefetchRunId = local.apifyQueue.managedRequestRunId || local.apifyQueue.runEventId || this._runEventId;
                const prefetchTaskRoute = (rawTask) => {
                    // With inline autoBegin inside providerProxy, separate beginExtraction HTTP calls are no longer needed when primary provider & keyRow are known and server supports autoBegin
                    if (this._fastAutoBeginExplicitlySupported && !this._fastAutoBeginUnsupported && settings && settings.provider && (settings.apiKeyRow || settings.apifyKeyRow)) return null;
                    if (!settings || !settings.managedRouting || !rawTask || !prefetchRunId || typeof crypto === 'undefined' || !crypto.subtle) return null;
                    const qText = String(this.parseTask(rawTask).query || '').trim();
                    if (!qText) return null;
                    const p = (async () => {
                        const seed = resumeGen > 0 ? (prefetchRunId + '|r' + resumeGen + '|' + qText) : (prefetchRunId + '|' + qText);
                        const input = new TextEncoder().encode(seed);
                        const attemptId = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', input)), b => b.toString(16).padStart(2, '0')).join('');
                        if (this._prefetchedBeginRoutes && this._prefetchedBeginRoutes.has(attemptId)) {
                            return this._prefetchedBeginRoutes.get(attemptId);
                        }
                        const route = await this.managedControl('beginExtraction', { attemptId, resetExhaustedAttempt: resumeGen > 0 });
                        return { attemptId, route };
                    })();
                    p.catch(() => null);
                    p.then(res => {
                        if (res && res.attemptId && this._prefetchedBeginRoutes) {
                            this._prefetchedBeginRoutes.set(res.attemptId, Promise.resolve(res));
                        }
                    }).catch(() => null);
                    return p;
                };
                if (settings && settings.managedRouting && Array.isArray(local.taskList) && local.taskList[0]) {
                    this._prefetchedBeginRoute = prefetchTaskRoute(local.taskList[0]);
                }
                await setLocalAsync(local);

                // Prepared route was selected before the run entered Running state.
                // Do not repeat licence/source selection here.
                local = await getLocalAsync();
                if (!canResume) {
                    runStartedAt = nowIso();
                    local.scrapeStartedAt = runStartedAt;
                    local.scrapeElapsedMs = 0;
                }
                if (!settings.countryFilter && local.country) settings.countryFilter = local.country;
                if (!settings.countryCodeFilter && String(settings.countryFilter || '').toLowerCase() === 'india') settings.countryCodeFilter = 'IN';
                local.status = true;
                local._taskManager = Object.assign({}, local._taskManager || {}, { isWorking: true, activeTask: 'openMap', scrapeStarted: true });
                local.fastMode = false;
                const qBeforeBackendReady = Object.assign(buildEmptyQueue(), local.apifyQueue || {});
                const selectedEngine = settings.provider === 'googlemaps' ? 'engine2_place_id_url_fallback' : 'engine1_structured_provider';
                local.apifyQueue = buildEmptyQueue(Object.assign({}, qBeforeBackendReady, {
                    status: 'running',
                    statusMessage: canResume ? 'Data source ready. Resuming saved progress...' : 'Data source ready. Starting search...',
                    provider: settings.provider || '',
                    engine: selectedEngine,
                    startedAt: runStartedAt,
                    finishedAt: '',
                    elapsedMs: elapsedMsFrom(runStartedAt),
                    totalTasks: sessionTotalTasks,
                    completedTasks: Math.max(0, sessionTotalTasks - (Array.isArray(local.taskList) ? local.taskList.length : 0)),
                    currentTaskIndex: Math.min(sessionTotalTasks, Math.max(1, sessionTotalTasks - (Array.isArray(local.taskList) ? local.taskList.length : 0) + 1)),
                    resumeGeneration: resumeGen,
                    totalPlaceIds: qBeforeBackendReady.totalPlaceIds || 0,
                    totalApiResults: qBeforeBackendReady.totalApiResults || 0,
                    scrapedCount: qBeforeBackendReady.scrapedCount || 0,
                    failedCount: qBeforeBackendReady.failedCount || 0,
                    filteredCount: qBeforeBackendReady.filteredCount || 0,
                    duplicateSkippedCount: qBeforeBackendReady.duplicateSkippedCount || 0,
                    apiKeyRow: settings.apiKeyRow || settings.apifyKeyRow || 0,
                    apiUsageBefore: settings.apiUsageBefore || settings.apifyUsageBefore || 0,
                    apiUsageAfter: settings.apiUsageBefore || settings.apifyUsageBefore || 0,
                    apiUsageLimit: settings.apiUsageLimit || settings.apifyUsageLimit || DEFAULT_SETTINGS.apiUsageLimit,
                    apifyKeyRow: settings.apiKeyRow || settings.apifyKeyRow || 0,
                    apifyUsageBefore: settings.apiUsageBefore || settings.apifyUsageBefore || 0,
                    apifyUsageAfter: settings.apiUsageBefore || settings.apifyUsageBefore || 0,
                    apifyUsageLimit: settings.apiUsageLimit || settings.apifyUsageLimit || DEFAULT_SETTINGS.apiUsageLimit,
                    domConcurrency: settings.provider === 'googlemaps' ? 2 : (qBeforeBackendReady.domConcurrency || 1)
                }));
                await setLocalAsync(local);

                const originalTaskCount = sessionTotalTasks;
                this.emitDiagnosticSpy('RUN_START', {
                    taskIndex: local.apifyQueue.currentTaskIndex || 1,
                    totalTasks: originalTaskCount,
                    provider: settings.provider || 'auto',
                    message: `${canResume ? 'Resumed' : 'Started'} extraction for ${originalTaskCount} location/keyword task(s) via ${settings.provider || 'auto'}.`
                });
                if (!settings.managedRouting && settings.provider === 'googlemaps') return await this.runGooglePipeline(settings, originalTaskCount);
                // Smart Staggered Rolling Pool:
                // - For multi-location structured runs (e.g., 20-67+ pincodes on Scrappa/Serper),
                //   runs up to 3 concurrent rolling workers staggered by 650ms so Apps Script ScriptLock
                //   and Scrappa rate limits are never burst-jammed.
                // - Each completed pincode settles IMMEDIATELY one-by-one (1/67 -> 2/67 -> 3/67 ... 67/67)
                //   so progress and active query update smoothly in real time without waiting for a wave.
                const isMultiStructured = (settings.provider === 'scrappa' || settings.provider === 'serper') && Array.isArray(local.taskList) && local.taskList.length > 1;
                if (!isMultiStructured) {
                    while (await this.isStillRunning()) {
                        local = await getLocalAsync();
                        if (!Array.isArray(local.taskList) || !local.taskList.length) break;
                        const task = local.taskList[0];
                        const meta = this.parseTask(task);
                        const completedBeforeTask = Math.max(0, originalTaskCount - local.taskList.length);
                        const currentTaskNumber = Math.min(originalTaskCount, completedBeforeTask + 1);
                        meta.taskIndex = currentTaskNumber;
                        meta.totalTasks = originalTaskCount;
                        if (settings.managedRouting && local.taskList[1]) {
                            prefetchTaskRoute(local.taskList[1]);
                        }
                        await this.updateQueue({
                            currentQuery: meta.query,
                            currentKeyword: meta.keyword || meta.query,
                            currentLocation: meta.location || '',
                            currentTaskIndex: currentTaskNumber,
                            totalTasks: originalTaskCount,
                            completedTasks: completedBeforeTask,
                            statusMessage: `Searching (${currentTaskNumber}/${originalTaskCount}): ${meta.query}`
                        });
                        if (!meta.query) {
                            local.taskList.shift();
                            await setLocalAsync(local);
                            continue;
                        }
                        this.emitDiagnosticSpy('TASK_START', {
                            taskIndex: currentTaskNumber,
                            totalTasks: originalTaskCount,
                            query: meta.query,
                            keyword: meta.keyword || '',
                            location: meta.location || '',
                            provider: settings.provider || '',
                            message: `[${currentTaskNumber}/${originalTaskCount}] Searching "${meta.query}"`
                        });
                        await this.updatePincodeStatus(meta, {
                            status: 'searching',
                            keyword: meta.keyword || '',
                            location: meta.location || meta.query || '',
                            query: meta.query || ''
                        }, false);
                        try {
                            let lastSingleErr = null;
                            for (let singleTry = 0; singleTry < 3; singleTry++) {
                                if (!(await this.isStillRunning())) break;
                                try {
                                    const healthySettings = await this.processQuery(meta, settings);
                                    if (healthySettings) settings = healthySettings;
                                    lastSingleErr = null;
                                    break;
                                } catch (sErr) {
                                    lastSingleErr = sErr;
                                    const sCode = String(sErr && (sErr.code || sErr.providerReason) || '').toUpperCase();
                                    const sMsg = String(sErr && sErr.message || sErr || '');
                                    const isFatal = /^(LICENSE_CREDIT_EXHAUSTED|ALL_CREDITS_EXHAUSTED|LICENCE_CREDIT_EXHAUSTED|LICENSE_EXPIRED|LICENCE_EXPIRED|RESULT_STORE_UNAVAILABLE|BILLING_CONFIG_ERROR|BACKEND_UPDATE_REQUIRED)$/.test(sCode) ||
                                        (sCode === 'LICENSE_INACTIVE' && !/missing_licence_key|missing_key|missing_device/i.test(sMsg));
                                    if (isFatal || singleTry >= 2) break;
                                    await sleep(1000 * (singleTry + 1));
                                    try {
                                        if (typeof PocketLeadsAccount !== 'undefined' && PocketLeadsAccount && typeof PocketLeadsAccount.refresh === 'function') {
                                            await PocketLeadsAccount.refresh({ force: true }).catch(() => null);
                                        }
                                        const freshCfg = await ApiBackendManager.getPreparedScrapeConfig().catch(() => null);
                                        if (freshCfg && freshCfg.provider) {
                                            settings = SettingsManager.validate(Object.assign({}, settings, freshCfg));
                                        }
                                    } catch (_) {}
                                }
                            }
                            if (lastSingleErr) throw lastSingleErr;
                            if (!settings.managedRouting && settings.provider === 'googlemaps') return await this.runGooglePipeline(settings, originalTaskCount);
                        } catch (taskErr) {
                            const errCode = String(taskErr && (taskErr.code || taskErr.providerReason) || '').toUpperCase();
                            const hasOtherTasksOrProgress = originalTaskCount > 1 || completedBeforeTask > 0 || (local.resultStoreCount || 0) > 0;
                            if (isCommercialStopError(taskErr) || (errCode === 'NO_ELIGIBLE_PROVIDER' && !hasOtherTasksOrProgress) || (errCode === 'PROVIDER_FAILOVER_EXHAUSTED' && !hasOtherTasksOrProgress)) {
                                this.emitDiagnosticSpy('FATAL_ERROR', {
                                    level: 'error',
                                    taskIndex: currentTaskNumber,
                                    totalTasks: originalTaskCount,
                                    query: meta.query,
                                    location: meta.location || '',
                                    provider: settings.provider || '',
                                    errorCode: errCode || 'STOP_ERROR',
                                    message: `[${currentTaskNumber}/${originalTaskCount}] Stopped: ${taskErr && taskErr.message ? taskErr.message : String(taskErr)}`
                                });
                                throw taskErr;
                            }
                            const msg = taskErr && taskErr.message ? taskErr.message : String(taskErr);
                            warn('Task failed or returned no usable results; continuing next location', meta.query, msg);
                            const skipRecord = makeSkippedRecord(
                                { company_name: meta.location || meta.query, address: meta.location || '' },
                                meta,
                                `Location/Query skipped (${errCode || 'PROVIDER_ISSUE'}): ${msg}`,
                                'Failed',
                                `Task:${settings.provider || 'provider'}`
                            );
                            this.recordSessionSkipped([skipRecord]);
                            this.emitDiagnosticSpy('TASK_SKIP_CONTINUE', {
                                level: 'warn',
                                taskIndex: currentTaskNumber,
                                totalTasks: originalTaskCount,
                                query: meta.query,
                                location: meta.location || '',
                                provider: settings.provider || '',
                                errorCode: errCode || 'TASK_SKIPPED',
                                message: `[${currentTaskNumber}/${originalTaskCount}] "${meta.query}" skipped (${msg}) — continuing to next location.`
                            });
                            await this.updatePincodeStatus(meta, {
                                status: 'api_failed',
                                error: msg,
                                failed: 1,
                                skipped: 1,
                                completedWithErrors: true
                            }, true);
                            const localOnError = await getLocalAsync();
                            const qOnError = Object.assign(buildEmptyQueue(), localOnError.apifyQueue || {});
                            qOnError.failedCount = (qOnError.failedCount || 0) + 1;
                            qOnError.apiTasksFailed = (qOnError.apiTasksFailed || 0) + 1;
                            qOnError.completedWithErrors = true;
                            qOnError.skipped = (this._sessionSkippedRecords || [skipRecord]).slice(-300);
                            qOnError.status = 'task_failed_continue';
                            qOnError.statusMessage = `Skipped (${currentTaskNumber}/${originalTaskCount}): ${meta.query} — continuing next location...`;
                            qOnError.lastErrorCode = errCode || 'TASK_FAILED_CONTINUE';
                            qOnError.lastErrorDetail = `[${currentTaskNumber}/${originalTaskCount}] ${meta.query}: ${msg}`;
                            qOnError.lastErrorAt = nowIso();
                            qOnError.lastUpdatedAt = nowIso();
                            localOnError.apifyQueue = qOnError;
                            await setLocalAsync(localOnError);
                        }
                        await this.flushQueueUpdates();
                        if (!(await this.settleCurrentTask(originalTaskCount))) break;
                    }
                } else {
                    const pendingPoolTasks = local.taskList.slice();
                    const initialDone = Math.max(0, originalTaskCount - pendingPoolTasks.length);
                    let claimCursor = 0;
                    let settledCount = initialDone;
                    let fatalPoolError = null;
                    const activeByLane = new Map();
                    const poolConcurrency = Math.min(3, pendingPoolTasks.length);
                    // Prefetch first 3 routes right away
                    if (settings.managedRouting) {
                        for (let i = 0; i < Math.min(3, pendingPoolTasks.length); i++) {
                            prefetchTaskRoute(pendingPoolTasks[i]);
                        }
                    }
                    const formatActiveBanner = () => {
                        const activeList = Array.from(activeByLane.values()).filter(Boolean);
                        if (!activeList.length) return '';
                        const primary = activeList[0];
                        return activeList.length > 1
                            ? `${primary.query} (+${activeList.length - 1} parallel)`
                            : primary.query;
                    };
                    const settleSingleTaskAtomic = (rawTask, failedInfo = null) => {
                        const op = async () => {
                            const curLocal = await getLocalAsync();
                            if (this.clearRequested) return false;
                            if (Array.isArray(this._activeTaskList)) {
                                const mIdx = this._activeTaskList.indexOf(rawTask);
                                if (mIdx >= 0) this._activeTaskList.splice(mIdx, 1);
                                curLocal.taskList = this._activeTaskList.slice();
                            } else if (Array.isArray(curLocal.taskList)) {
                                const idx = curLocal.taskList.indexOf(rawTask);
                                if (idx >= 0) curLocal.taskList.splice(idx, 1);
                            }
                            const left = Array.isArray(curLocal.taskList) ? curLocal.taskList.length : 0;
                            settledCount = Math.max(settledCount + 1, originalTaskCount - left);
                            settledCount = Math.min(originalTaskCount, settledCount);
                            this._settledTaskCount = settledCount;
                            const q = Object.assign(buildEmptyQueue(), curLocal.apifyQueue || {});
                            const activeList = Array.from(activeByLane.values()).filter(Boolean);
                            const nextActive = activeList[0] || (left > 0 ? this.parseTask(curLocal.taskList[0]) : null);
                            if (failedInfo) {
                                q.failedCount = (q.failedCount || 0) + 1;
                                q.apiTasksFailed = (q.apiTasksFailed || 0) + 1;
                                q.completedWithErrors = true;
                                q.lastErrorCode = failedInfo.errCode || 'TASK_FAILED_CONTINUE';
                                q.lastErrorDetail = failedInfo.detail || '';
                                q.lastErrorAt = nowIso();
                            }
                            if (Array.isArray(this._sessionSkippedRecords) && this._sessionSkippedRecords.length) {
                                q.skipped = this._sessionSkippedRecords.slice(-300);
                            }
                            const domStillActive = (q.domPending > 0 || q.domRunning > 0);
                            curLocal.apifyQueue = Object.assign(q, {
                                totalTasks: originalTaskCount,
                                completedTasks: settledCount,
                                currentTaskIndex: left > 0 ? Math.min(originalTaskCount, settledCount + 1) : originalTaskCount,
                                currentQuery: formatActiveBanner() || (nextActive ? nextActive.query : q.currentQuery),
                                currentKeyword: nextActive ? (nextActive.keyword || nextActive.query) : (q.currentKeyword || ''),
                                currentLocation: nextActive ? (nextActive.location || '') : (q.currentLocation || ''),
                                apiTasksDone: Math.max(0, settledCount - (q.apiTasksFailed || 0)),
                                apiTasksSettled: settledCount,
                                producerDone: left === 0,
                                consumerDone: left === 0 && !domStillActive,
                                resumeAvailable: false,
                                lastUpdatedAt: nowIso()
                            });
                            if (typeof this._stampAuthoritativeResults === 'function') this._stampAuthoritativeResults(curLocal, curLocal.apifyQueue);
                            if (curLocal.apifyQueue.currentQuery) {
                                curLocal.activeQuery = curLocal.apifyQueue.currentQuery;
                            }
                            await setLocalAsync(curLocal);
                            return true;
                        };
                        const run = this._taskWriteChain.then(op, op);
                        this._taskWriteChain = run.catch(() => null);
                        return run;
                    };

                    const runPoolLane = async (laneId) => {
                        // Safe-Fast 3-Lane Launch: 380ms spacing prevents Scrappa Cloudflare WAF from rejecting burst calls with HTTP 403 PROVIDER_AUTH
                        if (laneId > 0) await sleep(laneId * 380);
                        while (!fatalPoolError && (await this.isStillRunning())) {
                            if (claimCursor >= pendingPoolTasks.length) break;
                            const myIndex = claimCursor++;
                            const rawTask = pendingPoolTasks[myIndex];
                            const taskNumber = initialDone + myIndex + 1;
                            const meta = this.parseTask(rawTask);
                            meta.taskIndex = taskNumber;
                            meta.totalTasks = originalTaskCount;
                            if (!meta.query) {
                                await settleSingleTaskAtomic(rawTask);
                                continue;
                            }
                            // Prefetch next unclaimed task route
                            if (settings.managedRouting && pendingPoolTasks[claimCursor]) {
                                prefetchTaskRoute(pendingPoolTasks[claimCursor]);
                            }
                            activeByLane.set(laneId, meta);
                            // Fire-and-forget pre-query status updates so worker HTTP requests never wait on chrome.storage writes
                            void this.updateQueueThrottled({
                                currentQuery: formatActiveBanner() || meta.query,
                                currentKeyword: meta.keyword || meta.query,
                                currentLocation: meta.location || '',
                                currentTaskIndex: Math.min(originalTaskCount, settledCount + 1),
                                totalTasks: originalTaskCount,
                                completedTasks: settledCount,
                                statusMessage: `Searching (${ Math.min(originalTaskCount, settledCount + 1) }/${originalTaskCount}): ${formatActiveBanner() || meta.query}`
                            }, 250, myIndex === 0);
                            this.emitDiagnosticSpy('TASK_START', {
                                taskIndex: taskNumber,
                                totalTasks: originalTaskCount,
                                query: meta.query,
                                keyword: meta.keyword || '',
                                location: meta.location || '',
                                provider: settings.provider || '',
                                message: `[${taskNumber}/${originalTaskCount}] (Worker ${laneId + 1}) Searching "${meta.query}"`
                            });
                            void this.updatePincodeStatus(meta, {
                                status: 'searching',
                                keyword: meta.keyword || '',
                                location: meta.location || meta.query || '',
                                query: meta.query || ''
                            }, false);
                            // Safe 350ms dispatch stagger so all 3 workers run continuously without triggering Scrappa HTTP 403 burst blocks
                            if (myIndex > 0) {
                                await this.acquireStaggeredDispatchSlot(350);
                            }
                            if (fatalPoolError || !(await this.isStillRunning())) {
                                activeByLane.delete(laneId);
                                break;
                            }
                            if (typeof this._liveRunCreditRemaining === "number" && Number.isFinite(this._liveRunCreditRemaining) && this._liveRunCreditRemaining <= 0) {
                                const credErr = new Error("Your scraping credits are exhausted. Buy credits to continue.");
                                credErr.code = "LICENSE_CREDIT_EXHAUSTED";
                                fatalPoolError = credErr;
                                activeByLane.delete(laneId);
                                break;
                            }
                            let failedInfo = null;
                            let lastTaskErr = null;
                            for (let taskTry = 0; taskTry < 3; taskTry++) {
                                if (fatalPoolError || !(await this.isStillRunning())) break;
                                try {
                                    const laneSettings = Object.assign({}, settings, { providerMetrics: {} });
                                    const healthySettings = await this.processQuery(meta, laneSettings);
                                    if (healthySettings) settings = healthySettings;
                                    lastTaskErr = null;
                                    break;
                                } catch (attemptErr) {
                                    lastTaskErr = attemptErr;
                                    const attemptCode = String(attemptErr && (attemptErr.code || attemptErr.providerReason) || '').toUpperCase();
                                    const attemptMsg = String(attemptErr && attemptErr.message || attemptErr || '');
                                    const isTrueFatal = /^(LICENSE_CREDIT_EXHAUSTED|ALL_CREDITS_EXHAUSTED|LICENCE_CREDIT_EXHAUSTED|LICENSE_EXPIRED|LICENCE_EXPIRED|RESULT_STORE_UNAVAILABLE|BILLING_CONFIG_ERROR|BACKEND_UPDATE_REQUIRED)$/.test(attemptCode) ||
                                        (attemptCode === 'LICENSE_INACTIVE' && !/missing_licence_key|missing_key|missing_device/i.test(attemptMsg));
                                    if (isTrueFatal || taskTry >= 2) break;
                                    this.emitDiagnosticSpy('TASK_RETRY', {
                                        level: 'warn',
                                        taskIndex: taskNumber,
                                        totalTasks: originalTaskCount,
                                        query: meta.query,
                                        location: meta.location || '',
                                        provider: settings.provider || '',
                                        errorCode: attemptCode || 'RETRY',
                                        message: `[${taskNumber}/${originalTaskCount}] Auto-retrying "${meta.query}" (attempt ${taskTry + 2}/3) after temporary interruption: ${attemptMsg}`
                                    });
                                    await sleep(1200 * (taskTry + 1));
                                }
                            }
                            if (lastTaskErr) {
                                const taskErr = lastTaskErr;
                                const errCode = String(taskErr && (taskErr.code || taskErr.providerReason) || '').toUpperCase();
                                const rawErrMsg = String(taskErr && taskErr.message || taskErr || '');
                                const isTrueFatalStop = /^(LICENSE_CREDIT_EXHAUSTED|ALL_CREDITS_EXHAUSTED|LICENCE_CREDIT_EXHAUSTED|LICENSE_EXPIRED|LICENCE_EXPIRED|RESULT_STORE_UNAVAILABLE|BILLING_CONFIG_ERROR|BACKEND_UPDATE_REQUIRED)$/.test(errCode) ||
                                    (errCode === 'LICENSE_INACTIVE' && !/missing_licence_key|missing_key|missing_device/i.test(rawErrMsg));
                                if (isTrueFatalStop) {
                                    fatalPoolError = taskErr;
                                    activeByLane.delete(laneId);
                                    this.emitDiagnosticSpy('FATAL_ERROR', {
                                        level: 'error',
                                        taskIndex: taskNumber,
                                        totalTasks: originalTaskCount,
                                        query: meta.query,
                                        location: meta.location || '',
                                        provider: settings.provider || '',
                                        errorCode: errCode || 'STOP_ERROR',
                                        message: `[${taskNumber}/${originalTaskCount}] Stopped: ${rawErrMsg}`
                                    });
                                    break;
                                }
                                const msg = taskErr && taskErr.message ? taskErr.message : String(taskErr);
                                warn('Task failed in rolling pool; continuing remaining locations', meta.query, msg);
                                void (async () => {
                                    try {
                                        const licSnap = typeof chromeStorageGetAsync === 'function' ? await chromeStorageGetAsync(['license', 'pocketleadsAccount']) : {};
                                        const licObj = (licSnap && licSnap.license) || (licSnap && licSnap.pocketleadsAccount) || {};
                                        const licKey = String(licObj.key || licObj.licenceKey || settings.licenseKey || '').trim();
                                        if (!licKey) return;
                                        const devId = await getInstallationDeviceId().catch(() => '');
                                        const taskAlert = {
                                            licenceKey: licKey,
                                            apiId: String(settings.apiId || (settings.apiKeyRow ? ('ROW-' + settings.apiKeyRow) : 'TASK_POOL')),
                                            keyRow: parseInt(settings.apiKeyRow || settings.apifyKeyRow, 10) || 0,
                                            provider: String(settings.provider || 'scrappa'),
                                            httpStatus: parseInt(taskErr && taskErr.status, 10) || 0,
                                            errorCode: String(errCode || 'TASK_SKIPPED_ERROR'),
                                            upstreamCode: 'TASK_SKIP',
                                            upstreamError: String(msg || 'Task failed').slice(0, 500),
                                            query: String(meta.query || '').slice(0, 200)
                                        };
                                        await callAppsScript('logApiError', Object.assign({ key: licKey, deviceId: devId }, taskAlert), { attempts: 1, timeoutMs: 10000 }).catch(() => null);
                                    } catch (_) {}
                                })();
                                const skipRecord = makeSkippedRecord(
                                    { company_name: meta.location || meta.query, address: meta.location || '' },
                                    meta,
                                    `Location/Query skipped (${errCode || 'PROVIDER_ISSUE'}): ${msg}`,
                                    'Failed',
                                    `Task:${settings.provider || 'provider'}`
                                );
                                this.recordSessionSkipped([skipRecord]);
                                this.emitDiagnosticSpy('TASK_SKIP_CONTINUE', {
                                    level: 'warn',
                                    taskIndex: taskNumber,
                                    totalTasks: originalTaskCount,
                                    query: meta.query,
                                    location: meta.location || '',
                                    provider: settings.provider || '',
                                    errorCode: errCode || 'TASK_SKIPPED',
                                    message: `[${taskNumber}/${originalTaskCount}] "${meta.query}" skipped (${msg}) — continuing remaining locations.`
                                });
                                await this.updatePincodeStatus(meta, {
                                    status: 'api_failed',
                                    error: msg,
                                    failed: 1,
                                    skipped: 1,
                                    completedWithErrors: true
                                }, false);
                                failedInfo = {
                                    errCode: errCode || 'TASK_FAILED_CONTINUE',
                                    detail: `[${taskNumber}/${originalTaskCount}] ${meta.query}: ${msg}`
                                };
                            }
                            activeByLane.delete(laneId);
                            if (fatalPoolError || !(await this.isStillRunning())) break;
                            await settleSingleTaskAtomic(rawTask, failedInfo);
                        }
                    };

                    await Promise.all(Array.from({ length: poolConcurrency }, (_, idx) => runPoolLane(idx)));
                    await this.flushQueueUpdates();
                    if (fatalPoolError) throw fatalPoolError;
                }

                await this.flushLeadMetricsSync();
                if (await this.isStillRunning()) await this.complete();
            } catch (err) {
                await this.failHard(err);
            } finally {
                if (this._swKeepAliveTimer && typeof clearInterval === 'function') {
                    clearInterval(this._swKeepAliveTimer);
                    this._swKeepAliveTimer = null;
                }
                const shouldRestart = !!(this.restartRequested && !this.clearRequested);
                this.running = false;
                this.restartRequested = false;
                if (shouldRestart) {
                    setTimeout(() => {
                        this.start().catch(err => warn('Queued Resume failed', err));
                    }, 150);
                }
            }
        },

        async settleCurrentTask(originalTaskCount) {
            if (!(await this.isStillRunning())) return false;
            const local = await getLocalAsync();
            // Stop can arrive while the storage read is in flight.
            if (!(await this.isStillRunning()) || this.clearRequested) return false;
            if (!Array.isArray(local.taskList) || !local.taskList.length) return true;
            local.taskList.shift();
            if (Array.isArray(this._activeTaskList)) this._activeTaskList = local.taskList.slice();
            const left = local.taskList.length;
            const queue = Object.assign(buildEmptyQueue(), local.apifyQueue || {});
            const settled = Math.max(0, originalTaskCount - left);
            this._settledTaskCount = settled;
            const nextTaskMeta = left > 0 ? this.parseTask(local.taskList[0]) : null;
            const domStillActive = (queue.domPending > 0 || queue.domRunning > 0);
            if (Array.isArray(this._sessionSkippedRecords) && this._sessionSkippedRecords.length) {
                queue.skipped = mergeSkippedRecords(queue.skipped || [], this._sessionSkippedRecords);
            }
            local.apifyQueue = Object.assign(queue, {
                totalTasks: originalTaskCount,
                completedTasks: settled,
                currentTaskIndex: left > 0 ? Math.min(originalTaskCount, settled + 1) : originalTaskCount,
                currentQuery: nextTaskMeta ? nextTaskMeta.query : queue.currentQuery,
                currentKeyword: nextTaskMeta ? (nextTaskMeta.keyword || nextTaskMeta.query) : (queue.currentKeyword || ''),
                currentLocation: nextTaskMeta ? (nextTaskMeta.location || '') : (queue.currentLocation || ''),
                apiTasksDone: Math.max(0, settled - (queue.apiTasksFailed || 0)),
                apiTasksSettled: settled,
                producerDone: left === 0,
                consumerDone: left === 0 && !domStillActive,
                placeIdQueue: (left === 0 && !domStillActive) ? [] : (queue.placeIdQueue || []),
                pendingPlaceIds: (left === 0 && !domStillActive) ? [] : (queue.pendingPlaceIds || []),
                resumeAvailable: false,
                lastUpdatedAt: nowIso()
            });
            if (typeof this._stampAuthoritativeResults === 'function') this._stampAuthoritativeResults(local, local.apifyQueue);
            await setLocalAsync(local);
            return true;
        },

        async settleCompletedWaveTasks(completedSet, originalTaskCount) {
            if (!(await this.isStillRunning()) && !completedSet.size) return false;
            const local = await getLocalAsync();
            if (this.clearRequested) return false;
            if (!Array.isArray(local.taskList) || !local.taskList.length) return true;
            local.taskList = local.taskList.filter(t => !completedSet.has(t));
            const left = local.taskList.length;
            const queue = Object.assign(buildEmptyQueue(), local.apifyQueue || {});
            const settled = Math.max(0, originalTaskCount - left);
            const domStillActive = (queue.domPending > 0 || queue.domRunning > 0);
            local.apifyQueue = Object.assign(queue, {
                totalTasks: originalTaskCount, completedTasks: settled,
                apiTasksDone: Math.max(0, settled - (queue.apiTasksFailed || 0)),
                apiTasksSettled: settled,
                producerDone: left === 0,
                consumerDone: left === 0 && !domStillActive,
                placeIdQueue: (left === 0 && !domStillActive) ? [] : (queue.placeIdQueue || []),
                pendingPlaceIds: (left === 0 && !domStillActive) ? [] : (queue.pendingPlaceIds || []),
                resumeAvailable: false,
                lastUpdatedAt: nowIso()
            });
            await setLocalAsync(local);
            return true;
        },

        // v91: Google Place-ID placeholders are intentionally not published to the customer table.

        async runGooglePipeline(settings, originalTaskCount) {
            let local = await getLocalAsync();
                    // v90: warm the hidden Maps renderer in parallel with the first
                    // Places API request. This removes offscreen/content-script cold
                    // start from the first profile whenever possible.
                    try {
                        if (typeof self !== 'undefined' && self.PocketLeadsGhostMode && typeof self.PocketLeadsGhostMode.prewarm === 'function') {
                            void self.PocketLeadsGhostMode.prewarm('google_run_start');
                        }
                    } catch (e) {}
                    const googleTasks = Array.isArray(local.taskList) ? local.taskList.slice() : [];
                    const outcome = await this.processGoogleMapsBatch(googleTasks, settings, originalTaskCount);
                    if (outcome && outcome.cleared) return;
                    local = await getLocalAsync();
                    if (outcome && outcome.fullyComplete) {
                        local.taskList = [];
                        local.apifyQueue = Object.assign(buildEmptyQueue(), local.apifyQueue || {}, {
                            totalTasks: originalTaskCount,
                            completedTasks: originalTaskCount,
                            apiTasksDone: Math.max(originalTaskCount, (local.apifyQueue && local.apifyQueue.apiTasksDone) || 0),
                            apiTasksSettled: Math.max(originalTaskCount, (local.apifyQueue && local.apifyQueue.apiTasksSettled) || 0),
                            resumeAvailable: false,
                            producerDone: true,
                            consumerDone: true,
                            lastUpdatedAt: nowIso()
                        });
                        await setLocalAsync(local);
                        if (await this.isStillRunning()) await this.complete();
                    } else {
                        const q = Object.assign(buildEmptyQueue(), local.apifyQueue || {});
                        q.resumeAvailable = true;
                        q.status = q.status === 'stopped' ? 'stopped' : 'paused_recoverable';
                        q.statusMessage = q.statusMessage || 'Run paused before all profiles completed. Click Resume to continue.';
                        q.lastUpdatedAt = nowIso();
                        local.apifyQueue = q;
                        local.status = false;
                        if (!local._taskManager) local._taskManager = {};
                        local._taskManager.isWorking = false;
                        local._taskManager.activeTask = 'openMap';
                        await setLocalAsync(local);
                    }
                    return;
        },

        async processGoogleMapsBatch(taskList, settings, originalTaskCount) {
            settings = SettingsManager.validate(settings || {});
            const country = String((settings && settings.countryFilter) || 'India').trim() || 'India';
            const localAtStart = await getLocalAsync();
            const queueAtStart = Object.assign(buildEmptyQueue(), localAtStart.apifyQueue || {});
            const rawTasks = (Array.isArray(taskList) ? taskList : []).map(x => String(x || '').trim()).filter(Boolean);
            const sessionTotalTasks = Math.max(
                parseInt(originalTaskCount, 10) || 0,
                parseInt(queueAtStart.apiTasksTotal, 10) || 0,
                rawTasks.length
            );

            if (!localAtStart.resultStoreMigrated && Array.isArray(localAtStart.collect) && localAtStart.collect.length) {
                try {
                    await ResultStore.migrateFromLocal(localAtStart.collect);
                    localAtStart.resultStoreMigrated = true;
                    localAtStart.resultStoreCount = await ResultStore.count();
                    await setLocalAsync(localAtStart);
                } catch (migrationErr) {
                    warn('Result-store migration failed at pipeline start', migrationErr);
                }
            }

            const savedKeys = await ResultStore.getKeySet().catch(() => new Set((localAtStart.collect || []).map(row => rowFingerprint(row))));
            const isTerminalJob = status => /^(saved|duplicate_before_dom|duplicate_after_dom|filtered_country|filtered_category|failed_final|cancelled)$/i.test(String(status || ''));
            const isPendingJob = status => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(status || ''));
            const queryKeyForMeta = meta => this.queryStatusKey(meta);
            const jobs = [];
            const jobMap = new Map();
            const jobRunId = String(queueAtStart.jobRunId || queueAtStart.runEventId || queueAtStart.startedAt || makeRunEventId('jobs'));
            const durableJobs = await JobStore.getRun(jobRunId).catch(err => {
                warn('Durable job queue restore failed; falling back to lightweight local preview.', err);
                return [];
            });
            const existingPlaceQueue = durableJobs.length
                ? durableJobs
                : (Array.isArray(queueAtStart.placeIdQueue) ? queueAtStart.placeIdQueue : []);
            existingPlaceQueue.forEach(item => {
                const placeId = String(item && item.placeId || '').trim();
                if (!placeId) return;
                const key = placeId.toLowerCase();
                if (jobMap.has(key)) return;
                const restored = Object.assign({}, item, {
                    placeId,
                    query: item.query || '',
                    queryForApi: item.queryForApi || item.query || '',
                    keyword: item.keyword || '',
                    location: item.location || '',
                    attempts: Math.max(0, parseInt(item.attempts, 10) || 0),
                    status: isTerminalJob(item.status) ? item.status : (isPendingJob(item.status) ? 'retry_pending' : 'pending'),
                    lastUpdatedAt: nowIso()
                });
                jobs.push(restored);
                jobMap.set(key, restored);
            });

            const state = {
                apiTotal: sessionTotalTasks,
                apiDone: Math.max(0, parseInt(queueAtStart.apiTasksDone, 10) || 0),
                apiFailed: Math.max(0, parseInt(queueAtStart.apiTasksFailed, 10) || 0),
                apiSettled: Math.max(0, sessionTotalTasks-rawTasks.length, parseInt(queueAtStart.apiTasksSettled, 10) || 0),
                producerDone: false,
                // v91 performance: start with two profile workers for faster real
                // first-lead delivery; transient tab/memory failures automatically
                // reduce this back to one.
                desiredConcurrency: 2,
                successStreak: Math.max(0, parseInt(queueAtStart.domSuccessStreak, 10) || 0),
                recentOutcomes: [],
                successRate: Math.max(0, Math.min(1, parseFloat(queueAtStart.domSuccessRate) || 0)),
                transientErrors: Math.max(0, parseInt(queueAtStart.domTransientErrors, 10) || 0),
                lastTransientAt: 0,
                newIdsCount: 0,
                pincodeStatuses: Object.assign({}, queueAtStart.pincodeStatuses || {}),
                lastCheckpointAt: 0
            };

            const taskEntries = rawTasks.map((raw, index) => {
                const meta = Object.assign({ keyword: '', location: '', query: '' }, this.parseTask(raw));
                meta.country = country;
                meta.queryForApi = normalizeQueryTextForApi(ensureQueryHasCountry(meta.query, country));
                return { raw, index, meta, key: queryKeyForMeta(meta) };
            });

            // Older v64 sessions may retain tasks even though their Place IDs were
            // already checkpointed. Skip those API calls and consume the saved queue.
            const tasksForApi = [];
            taskEntries.forEach(entry => {
                const pin = state.pincodeStatuses[entry.key] || {};
                const entryMeta = entry && entry.meta && typeof entry.meta === 'object' ? entry.meta : {};
                const hasQueuedIds = jobs.some(job => String(job.queryForApi || job.query || '').toLowerCase() === String(entryMeta.queryForApi || '').toLowerCase());
                const alreadySettled = hasQueuedIds && /^(api_done_dom_pending|dom_running|completed|completed_with_errors)$/i.test(String(pin.status || ''));
                if (!alreadySettled) tasksForApi.push(entry);
            });

            const removeTaskFromPersistentList = async rawTask => {
                const write = async () => {
                    const local = await getLocalAsync();
                    if (!Array.isArray(local.taskList)) local.taskList = [];
                    const idx = local.taskList.findIndex(item => String(item || '').trim() === String(rawTask || '').trim());
                    if (idx >= 0) local.taskList.splice(idx, 1);
                    await setLocalAsync(local);
                };
                const run = this._taskWriteChain.then(write, write);
                this._taskWriteChain = run.catch(() => null);
                return run;
            };

            // Remove already-settled legacy tasks from the resume list.
            for (const entry of taskEntries) {
                if (!tasksForApi.includes(entry)) await removeTaskFromPersistentList(entry.raw);
            }

            const recalc = () => {
                const pending = jobs.filter(job => /^(api_returned|pending|retry_pending)$/i.test(String(job.status || ''))).length;
                const running = jobs.filter(job => String(job.status || '').toLowerCase() === 'dom_running').length;
                const processed = jobs.filter(job => isTerminalJob(job.status)).length;
                const saved = jobs.filter(job => String(job.status || '').toLowerCase() === 'saved').length;
                const failed = jobs.filter(job => String(job.status || '').toLowerCase() === 'failed_final').length;
                const skipped = jobs.filter(job => /^(duplicate_before_dom|duplicate_after_dom|filtered_country|filtered_category|cancelled)$/i.test(String(job.status || ''))).length;
                return { pending, running, processed, saved, failed, skipped };
            };

            const checkpoint = async (force, status, message) => {
                const counts = recalc();
                if (this.clearRequested) return counts;
                const now = Date.now();
                if (!force && now - state.lastCheckpointAt < 450) return counts;
                state.lastCheckpointAt = now;
                const active = await this.isStillRunning();
                const effectiveStatus = active ? (status || 'google_pipeline_running') : 'stopped';
                const effectiveMessage = active ? message : (message ? ('Stopped safely. ' + message) : 'Stopped safely. Resume is available.');
                await this.updateQueue({
                    status: effectiveStatus,
                    statusMessage: effectiveMessage || `Live pipeline: API ${state.apiSettled}/${state.apiTotal}, profiles ${counts.processed}/${jobs.length}, pending ${counts.pending}, saved ${counts.saved}, failed ${counts.failed}.`,
                    provider: 'googlemaps',
                    apiTasksTotal: state.apiTotal,
                    apiTasksDone: state.apiDone,
                    apiTasksFailed: state.apiFailed,
                    apiTasksSettled: state.apiSettled,
                    totalTasks: state.apiTotal,
                    completedTasks: Math.min(state.apiTotal, state.apiSettled),
                    totalPlaceIds: jobs.length,
                    totalApiResults: jobs.length,
                    domTotal: jobs.length,
                    domProcessed: counts.processed,
                    domPending: counts.pending,
                    domRunning: counts.running,
                    domSaved: counts.saved,
                    domFailed: counts.failed,
                    domSkipped: counts.skipped,
                    producerDone: state.producerDone,
                    consumerDone: state.producerDone && counts.pending === 0 && counts.running === 0,
                    domConcurrency: state.desiredConcurrency,
                    domSuccessStreak: state.successStreak,
                    domSuccessRate: state.successRate,
                    domTransientErrors: state.transientErrors,
                    resumeAvailable: !active && (counts.pending > 0 || counts.running > 0 || state.apiSettled < state.apiTotal),
                    pendingPlaceIds: jobs.filter(job => /^(api_returned|pending|retry_pending)$/i.test(String(job.status || ''))).slice(0, 300).map(job => job.placeId),
                    // Keep only a small resume/UI preview in chrome.storage. The
                    // authoritative full queue is persisted in IndexedDB JobStore.
                    placeIdQueue: (() => {
                        const activeJobs = jobs.filter(job => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(job.status || ''))).slice(0, 300);
                        return activeJobs.length ? activeJobs : jobs.slice(-100);
                    })(),
                    jobRunId,
                    pincodeStatuses: state.pincodeStatuses,
                    managedTabIds: ProfileScraper.getManagedTabIds(),
                    lastCheckpointAt: nowIso()
                });
                return counts;
            };

            const enqueueIds = async (ids, meta) => {
                let added = 0;
                const newJobs = [];
                PlaceIdManager.deduplicate(ids || []).forEach((placeId, index) => {
                    const key = String(placeId || '').toLowerCase();
                    if (!key || jobMap.has(key)) return;
                    const fp = rowFingerprint({ place_id: placeId, cid: placeId });
                    const alreadySaved = savedKeys.has(fp);
                    const job = {
                        placeId,
                        query: meta.queryForApi || meta.query || '',
                        queryForApi: meta.queryForApi || meta.query || '',
                        keyword: meta.keyword || '',
                        location: meta.location || '',
                        country: meta.country || country,
                        apiIndex: index + 1,
                        status: alreadySaved ? 'duplicate_before_dom' : 'pending',
                        reason: alreadySaved ? 'Already exists in IndexedDB result store.' : 'Produced by Google Places API; waiting for DOM worker.',
                        attempts: 0,
                        createdAt: nowIso(),
                        lastUpdatedAt: nowIso()
                    };
                    jobs.push(job);
                    newJobs.push(job);
                    jobMap.set(key, job);
                    added += 1;
                });
                if (newJobs.length) {
                    await JobStore.putMany(jobRunId, newJobs).catch(err => warn('Durable job enqueue failed', err));
                    // v91: keep raw Place IDs internal. The customer table receives
                    // only real extracted business rows after profile enrichment.
                }
                state.newIdsCount += added;
                return added;
            };

            await checkpoint(true, 'google_pipeline_starting', `Producer-consumer pipeline starting. ${tasksForApi.length} API task(s), ${recalc().pending} pending profile(s), up to 2 hidden workers; no visible Maps tabs.`);

            let apiCursor = 0;
            const claimApiEntry = () => {
                if (apiCursor >= tasksForApi.length) return null;
                const index = apiCursor;
                apiCursor += 1;
                return tasksForApi[index] || null;
            };
            const apiConcurrency = 1; // One paid producer; DOM consumers remain parallel. Protect the pending receipt.
            const apiWorker = async () => {
                while (await this.isStillRunning()) {
                    const entry = claimApiEntry();
                    if (!entry) return;
                    const meta = entry.meta && typeof entry.meta === 'object'
                        ? entry.meta
                        : Object.assign({ keyword: '', location: '', query: '' }, this.parseTask(entry.raw || ''));
                    if (!meta.queryForApi) meta.queryForApi = normalizeQueryTextForApi(ensureQueryHasCountry(meta.query || meta.keyword || '', country));
                    if (!meta.queryForApi) {
                        state.apiFailed += 1;
                        state.apiSettled += 1;
                        state.pincodeStatuses[entry.key || this.queryStatusKey(meta)] = {
                            key: entry.key || this.queryStatusKey(meta),
                            keyword: meta.keyword || '',
                            location: meta.location || '',
                            query: '',
                            status: 'api_failed',
                            error: 'Malformed or blank queued search task.',
                            failed: 1,
                            lastUpdatedAt: nowIso()
                        };
                        await removeTaskFromPersistentList(entry.raw || '');
                        await checkpoint(true, 'google_pipeline_running', `Skipped one malformed search task. API ${state.apiSettled}/${state.apiTotal}.`);
                        continue;
                    }
                    state.pincodeStatuses[entry.key] = Object.assign({}, state.pincodeStatuses[entry.key] || {}, {
                        key: entry.key,
                        keyword: meta.keyword || '',
                        location: meta.location || '',
                        query: meta.queryForApi,
                        status: 'api_running',
                        startedAt: nowIso(),
                        lastUpdatedAt: nowIso()
                    });
                    await checkpoint(false, 'google_pipeline_running', `Searching API ${state.apiSettled + 1}/${state.apiTotal}: ${meta.queryForApi}`);
                    try {
                        let streamedAdded = 0;
                        const ids = await this.searchGoogleWithFailover(meta.queryForApi, settings, meta, async pageIds => {
                            if (this.clearRequested || !(await this.isStillRunning()) || this.stopped) return;
                            streamedAdded += await enqueueIds(pageIds, meta);
                            await checkpoint(false, 'google_pipeline_running', `Streaming Place IDs for ${meta.queryForApi}: ${jobs.length} queued, profiles extracting in parallel.`);
                        });
                        if (this.clearRequested) return;
                        if (!(await this.isStillRunning()) || this.stopped) {
                            state.pincodeStatuses[entry.key] = Object.assign({}, state.pincodeStatuses[entry.key] || {}, {
                                status: 'api_paused',
                                error: '',
                                failed: 0,
                                lastUpdatedAt: nowIso()
                            });
                            await checkpoint(true, 'stopped', `API search paused safely: ${meta.queryForApi}. It remains queued for Resume.`);
                            return;
                        }
                        const added = streamedAdded + (await enqueueIds(ids, meta));
                        state.apiDone += 1;
                        state.apiSettled += 1;
                        state.pincodeStatuses[entry.key] = Object.assign({}, state.pincodeStatuses[entry.key] || {}, {
                            status: ids.length ? 'api_done_dom_pending' : 'api_no_result',
                            apiIds: ids.length,
                            domTotal: ids.length,
                            addedUniqueIds: added,
                            lastUpdatedAt: nowIso()
                        });
                    } catch (err) {
                        if (this.clearRequested) return;
                        // Commercial/service-stop errors apply to the entire run.
                        // Do not convert them into per-pincode api_failed rows or
                        // advance keyword progress. Bubble immediately to failHard().
                        if (isCommercialStopError(err) || isProviderAvailabilityStopError(err)) throw err;
                        const stillRunning = await this.isStillRunning();
                        if (!stillRunning || this.stopped) {
                            // Manual Stop must not convert the in-flight API task into
                            // a permanent failure. Keep it in local.taskList so Resume
                            // starts from this exact keyword/location.
                            state.pincodeStatuses[entry.key] = Object.assign({}, state.pincodeStatuses[entry.key] || {}, {
                                status: 'api_paused',
                                error: '',
                                failed: 0,
                                lastUpdatedAt: nowIso()
                            });
                            await checkpoint(true, 'stopped', `API search paused safely: ${meta.queryForApi}. It remains queued for Resume.`);
                            return;
                        }
                        const msg = String(err && err.message || err || 'API search failed');
                        state.apiFailed += 1;
                        state.apiSettled += 1;
                        state.pincodeStatuses[entry.key] = Object.assign({}, state.pincodeStatuses[entry.key] || {}, {
                            status: 'api_failed',
                            error: msg,
                            failed: 1,
                            lastUpdatedAt: nowIso()
                        });
                        const q = Object.assign(buildEmptyQueue(), (await getLocalAsync()).apifyQueue || {});
                        await this.updateQueue({ failedCount: (q.failedCount || 0) + 1, completedWithErrors: true });
                    }
                    await removeTaskFromPersistentList(entry.raw);
                    await checkpoint(false, 'google_pipeline_running', `API ${state.apiSettled}/${state.apiTotal}. Profiles are processing at the same time; pending ${recalc().pending}.`);
                }
            };

            const claimJob = () => {
                const job = jobs.find(item => /^(api_returned|pending|retry_pending)$/i.test(String(item.status || '')));
                if (!job) return null;
                job.status = 'dom_running';
                job.startedAt = nowIso();
                job.lastUpdatedAt = nowIso();
                return job;
            };

            const isTransientDomError = err => /back\/forward cache|message channel is closed|port is moved|receiving end|could not establish|context invalidated|timed out|out of memory|memory pressure|aw, snap|crash|discarded|tab disappeared|tab was closed|profile failed to load/i.test(String(err && err.message || err || ''));

            const processJob = async (job, slotId) => {
                const meta = {
                    keyword: job.keyword || '',
                    location: job.location || '',
                    query: job.query || job.queryForApi || '',
                    queryForApi: job.queryForApi || job.query || '',
                    country: job.country || country
                };
                const profileUrl = PlaceIdManager.toMapsUrl(job.placeId);
                job.mapsUrl = profileUrl;
                job.workerSlot = slotId;
                await JobStore.put(jobRunId, job).catch(err => warn('Durable job claim persist failed', err));
                await checkpoint(false, 'google_profile_scraping', `Profile worker ${slotId + 1}: ${job.placeId}`);
                try {
                    const row = await ProfileScraper.scrapePlaceId(job.placeId, meta, settings, slotId);
                    if (this.clearRequested) return;
                    if (!(await this.isStillRunning()) || this.stopped) {
                        // A Stop may arrive while the page is finishing. Do not save or
                        // mark the profile failed after the user paused the run.
                        job.status = 'retry_pending';
                        job.reason = 'Paused after profile load; queued for Resume before saving.';
                        job.lastUpdatedAt = nowIso();
                        await JobStore.put(jobRunId, job).catch(err => warn('Durable paused job persist failed', err));
                        await checkpoint(true, 'stopped', `Paused safely before saving ${job.placeId}. Resume will retry this profile.`);
                        return;
                    }
                    row.place_id = row.place_id || job.placeId;
                    row.cid = row.cid || job.placeId;
                    row.map_link = row.map_link || profileUrl;
                    row.keyword = row.keyword || meta.keyword || meta.query || '';
                    row.location = row.location || meta.location || '';
                    row._provider = 'googlemaps'; row._source_detail = 'google_maps_place_id_profile'; row.source = 'Google Maps';
                    row.scraped_at = row.scraped_at || nowIso();
                    completeAddressFromQuery(row, meta, settings);

                    if (!CountryFilter.isAllowed(row, row, meta, settings)) {
                        job.status = 'filtered_country';
                        job.reason = 'Country filter failed after DOM extraction.';
                    } else {
                        const saveCall = () => this.saveDatasetRows([row], meta, 1, { rawBatchCount: 1, duplicateInBatch: 0, streaming: true, enrichmentUpdate: true });
                        const saveRun = this._resultWriteChain.then(saveCall, saveCall);
                        this._resultWriteChain = saveRun.catch(() => null);
                        const saved = await saveRun;
                        if (saved && (saved.savedNow > 0 || saved.updatedNow > 0)) {
                            job.status = 'saved';
                            job.reason = 'Saved to IndexedDB result store.';
                            savedKeys.add(rowFingerprint(row));
                        } else {
                            job.status = 'duplicate_after_dom';
                            job.reason = 'Duplicate in IndexedDB result store.';
                        }
                        job.companyName = row.company_name || row.name || '';
                        job.category = row.category || row.categories || '';
                        job.address = row.address || '';
                    }
                    job.completedAt = nowIso();
                    job.lastUpdatedAt = nowIso();
                    state.successStreak += 1;
                    state.recentOutcomes.push(1);
                    if (state.recentOutcomes.length > 10) state.recentOutcomes.shift();
                    state.successRate = state.recentOutcomes.length ? (state.recentOutcomes.reduce((sum, value) => sum + value, 0) / state.recentOutcomes.length) : 0;
                    const backlog = recalc().pending;
                    const stableFor = state.lastTransientAt ? (Date.now() - state.lastTransientAt) : Number.MAX_SAFE_INTEGER;
                    if (state.recentOutcomes.length >= 6 && state.successRate >= 0.85 && backlog >= 4 && stableFor > 30000) {
                        state.desiredConcurrency = 2;
                    } else if (state.recentOutcomes.length >= 6 && state.successRate < 0.70) {
                        state.desiredConcurrency = 1;
                    }
                } catch (err) {
                    if (this.clearRequested) return;
                    const stillRunning = await this.isStillRunning();
                    if (!stillRunning || this.stopped) {
                        // Closing a managed tab during manual Stop produces the same
                        // Chrome errors as a crash. Treat it as a checkpoint, not a
                        // failed lead, otherwise Resume would skip the last profile.
                        job.status = 'retry_pending';
                        job.reason = 'Paused during profile extraction; queued for Resume.';
                        job.lastUpdatedAt = nowIso();
                        await ProfileScraper.closeSlot(slotId);
                        await JobStore.put(jobRunId, job).catch(err => warn('Durable paused job persist failed', err));
                        await checkpoint(true, 'stopped', `Paused safely at ${job.placeId}. Resume will continue from this profile.`);
                        return;
                    }
                    // Strictly 1 attempt per Place ID (https://www.google.com/maps/place/?q=place_id:...).
                    // Never retry 3 times or throttle worker concurrency down to 1.
                    job.attempts = 1;
                    const transient = isTransientDomError(err);
                    state.successStreak = 0;
                    state.recentOutcomes.push(0);
                    if (state.recentOutcomes.length > 10) state.recentOutcomes.shift();
                    state.successRate = state.recentOutcomes.length ? (state.recentOutcomes.reduce((sum, value) => sum + value, 0) / state.recentOutcomes.length) : 0;
                    if (transient) {
                        state.transientErrors += 1;
                        state.lastTransientAt = Date.now();
                        await ProfileScraper.closeSlot(slotId);
                    }
                    job.status = 'failed_final';
                    job.reason = String(err && err.message || err || 'DOM extraction failed');
                    job.failedAt = nowIso();
                    job.lastUpdatedAt = nowIso();
                    const q = Object.assign(buildEmptyQueue(), (await getLocalAsync()).apifyQueue || {});
                    await this.updateQueue({ failedCount: (q.failedCount || 0) + 1, completedWithErrors: true });
                }
                await JobStore.put(jobRunId, job).catch(err => warn('Durable job completion persist failed', err));
                await checkpoint(false, 'google_pipeline_running', `Live pipeline: API ${state.apiSettled}/${state.apiTotal}; profiles ${recalc().processed}/${jobs.length}; tabs ${state.desiredConcurrency}; success ${Math.round(state.successRate * 100)}%; pending ${recalc().pending}.`);
            };

            const domWorker = async slotId => {
                while (true) {
                    const active = await this.isStillRunning();
                    if (!active) return;
                    if (slotId > 0 && state.desiredConcurrency < 2) {
                        if (state.producerDone && recalc().pending === 0) return;
                        await sleep(100);
                        continue;
                    }
                    const job = claimJob();
                    if (!job) {
                        if (state.producerDone) return;
                        await sleep(60);
                        continue;
                    }
                    await processJob(job, slotId);
                }
            };

            const producerPromise = Promise.all(Array.from({ length: apiConcurrency }, () => apiWorker())).then(async () => {
                state.producerDone = state.apiSettled >= state.apiTotal;
                const remainingApi = Math.max(0, state.apiTotal - state.apiSettled);
                await checkpoint(true, state.producerDone ? 'google_pipeline_draining' : 'stopped', state.producerDone
                    ? `All API searches settled. Finishing ${recalc().pending} pending profile(s).`
                    : `API producer paused with ${remainingApi} search(es) remaining and ${recalc().pending} profile(s) pending.`);
            });
            const consumerPromises = [domWorker(0), domWorker(1)];
            await Promise.all([producerPromise, ...consumerPromises]);
            await this.flushQueueUpdates();
            await ProfileScraper.closeAllTabs();

            if (this.clearRequested) {
                return { fullyComplete: false, stopped: true, cleared: true, apiSettled: state.apiSettled, apiTotal: state.apiTotal, pending: 0, running: 0, saved: 0, failed: 0, skipped: 0 };
            }
            const counts = recalc();
            const activeAtEnd = await this.isStillRunning();
            const fullyComplete = !!(activeAtEnd && state.producerDone && state.apiSettled >= state.apiTotal && counts.pending === 0 && counts.running === 0);
            if (state.newIdsCount > 0) {
                await ApiBackendManager.reportUsage(settings, state.newIdsCount).catch(err => warn('Google usage report failed', err));
            }
            if (fullyComplete) {
                await checkpoint(true, counts.failed || counts.skipped ? 'pipeline_ready_with_errors' : 'pipeline_ready_complete', `Pipeline drained. Saved ${counts.saved}, failed ${counts.failed}, skipped ${counts.skipped}.`);
                // Successful runs no longer need resumable job payloads; release
                // durable queue space after the terminal checkpoint is written.
                await JobStore.clearRun(jobRunId).catch(err => warn('Durable completed job cleanup failed', err));
            } else {
                await checkpoint(true, activeAtEnd ? 'paused_recoverable' : 'stopped', `Run paused safely. Resume available: API remaining ${Math.max(0, state.apiTotal - state.apiSettled)}, profile pending ${counts.pending}.`);
            }
            return {
                fullyComplete,
                stopped: !activeAtEnd,
                apiSettled: state.apiSettled,
                apiTotal: state.apiTotal,
                pending: counts.pending,
                running: counts.running,
                saved: counts.saved,
                failed: counts.failed,
                skipped: counts.skipped
            };
        },

        async processScrappaQuery(meta, settings) {
            const pagePlan = getEffectivePageCount(meta, settings);
            const isPincode = !!pagePlan.isPincode;
            // Every Scrappa query is one page-0 call, maximum 200 results.
            // City/text and pincode deliberately ignore multi-page UI targets.
            const targetResults = 200;
            const requestSize = 200;
            const apiQuery = meta.queryForApi;
            const variantMeta = Object.assign({}, meta, {
                queryForApi: apiQuery,
                provider: 'scrappa',
                settings,
                scrappaPincodeSingleCall: isPincode,
                scrappaDedupeMode: isPincode ? 'place_id_only' : 'stable_fingerprint'
            });
            const seenApi = new Set();
            let totalProviderUnique = 0;
            let savedAny = false;
            let logicalRequests = 0;
            let stopReason = '';
            const scrappaStreamToken = Date.now().toString(36) + Math.random().toString(36).slice(2);

            // One logical request for every query; never tile or paginate Scrappa.
            const maxLogicalRequests = 1;

            const buildSkip = typeof makeSkippedRecord === 'function'
                ? makeSkippedRecord
                : ((row, m, reason, status, source) => ({
                    source: source || 'Scrappa',
                    placeId: (row && (row.place_id || row.placeId)) || '',
                    cid: (row && row.cid) || '',
                    query: (m && (m.queryForApi || m.query)) || '',
                    keyword: (m && m.keyword) || '',
                    location: (m && m.location) || '',
                    status: status || 'Skipped',
                    reason: reason || 'Skipped',
                    skipReason: reason || 'Skipped',
                    category: (row && (row.category || row.categories || row.company_name || row.name)) || '',
                    companyName: (row && (row.company_name || row.name)) || '',
                    address: (row && (row.address || row.full_address)) || '',
                    mapsUrl: (row && (row.map_link || row.mapsUrl)) || ''
                }));

            const processBatch = async (items, batchLabel) => {
                const uniqueItems = [];
                const preSkippedDetails = [];
                let preDuplicateCount = 0;
                if (items && Array.isArray(items._rawDuplicates)) {
                    items._rawDuplicates.forEach(dupItem => {
                        preDuplicateCount += 1;
                        preSkippedDetails.push(buildSkip(dupItem, variantMeta, 'Duplicate row inside raw Scrappa API response.', 'Duplicate', 'Scrappa:raw_api_duplicate'));
                    });
                }
                (Array.isArray(items) ? items : []).forEach(item => {
                    if (isPincode) {
                        const placeId = firstValue(item, PLACE_ID_FIELDS);
                        if (placeId) {
                            const key = 'place:' + compactText(placeId);
                            if (seenApi.has(key)) {
                                preDuplicateCount += 1;
                                preSkippedDetails.push(buildSkip(item, variantMeta, 'Duplicate Place ID within Scrappa pincode search.', 'Duplicate', 'Scrappa:pincode_duplicate'));
                                return;
                            }
                            seenApi.add(key);
                        }
                        uniqueItems.push(item);
                        return;
                    }
                    const key = rowFingerprint(item);
                    if (!key) {
                        preSkippedDetails.push(buildSkip(item, variantMeta, 'Missing identifiable business key (name/address/place_id) in Scrappa response.', 'Skipped', 'Scrappa:missing_identity'));
                        return;
                    }
                    if (seenApi.has(key)) {
                        preDuplicateCount += 1;
                        preSkippedDetails.push(buildSkip(item, variantMeta, 'Duplicate business fingerprint within Scrappa search.', 'Duplicate', 'Scrappa:query_duplicate'));
                        return;
                    }
                    seenApi.add(key);
                    uniqueItems.push(item);
                });
                if (!uniqueItems.length) {
                    if (preSkippedDetails.length && typeof this.recordSessionSkipped === 'function') {
                        this.recordSessionSkipped(preSkippedDetails);
                    }
                    return { newProviderRows: 0, savedNow: 0, rows: [], skippedCount: preSkippedDetails.length };
                }

                const capRemaining = Math.max(0, targetResults - totalProviderUnique);
                const limited = uniqueItems.slice(0, capRemaining);
                if (uniqueItems.length > limited.length) {
                    uniqueItems.slice(capRemaining).forEach(overItem => {
                        preSkippedDetails.push(buildSkip(overItem, variantMeta, 'Skipped beyond 200 per-location result limit.', 'Skipped', 'Scrappa:cap_limit'));
                    });
                }
                totalProviderUnique += limited.length;
                let rows = DatasetNormalizer.normalizeItems(limited, variantMeta, settings);
                const firstPassSkipped = (rows && Array.isArray(rows.skippedDetails)) ? rows.skippedDetails.slice() : [];
                const firstPassCountryFiltered = (rows && rows.filteredByCountry) || 0;
                const firstPassCategoryFiltered = (rows && rows.filteredByCategory) || 0;
                if ((!rows || !rows.length) && limited.length) {
                    const safeSettings = Object.assign({}, settings || {}, { enforceCountryFilter: false });
                    rows = DatasetNormalizer.normalizeItems(limited, variantMeta, safeSettings);
                    rows._safeModeRecovered = true;
                }
                const combinedSkippedDetails = [
                    ...preSkippedDetails,
                    ...((rows && Array.isArray(rows.skippedDetails) && rows.skippedDetails.length) ? rows.skippedDetails : firstPassSkipped)
                ];
                if (combinedSkippedDetails.length && typeof this.recordSessionSkipped === 'function') {
                    this.recordSessionSkipped(combinedSkippedDetails);
                }
                let savedNow = 0;
                let totalDupesInSave = preDuplicateCount + ((rows && rows.duplicateInBatch) || 0);
                let saveResult = { savedNow: 0, duplicateCount: 0 };
                const streamRows = Array.isArray(rows) ? rows.slice() : [];
                const isFirstTaskInRun = !meta || !meta.taskIndex || meta.taskIndex <= 1;
                const chunkSize = isFirstTaskInRun ? 20 : Math.max(200, streamRows.length);
                if (!streamRows.length && combinedSkippedDetails.length) {
                    saveResult = await this.saveDatasetRows([], variantMeta, totalProviderUnique, {
                        rawBatchCount: limited.length,
                        filteredByCountry: firstPassCountryFiltered,
                        filteredByCategory: firstPassCategoryFiltered,
                        duplicateInBatch: preDuplicateCount,
                        skippedDetails: combinedSkippedDetails,
                        streaming: false,
                        safeModeRecovered: !!(rows && rows._safeModeRecovered)
                    });
                }
                for (let cursor = 0; cursor < streamRows.length;) {
                    if (!(await this.isStillRunning())) return { newProviderRows: limited.length, savedNow, rows };
                    const stepSize = cursor === 0 ? chunkSize : Math.max(chunkSize, streamRows.length - cursor);
                    const chunk = streamRows.slice(cursor, cursor + stepSize);
                    cursor += stepSize;
                    const isLastChunk = cursor >= streamRows.length;
                    saveResult = await this.saveDatasetRows(chunk, variantMeta, totalProviderUnique, {
                        rawBatchCount: chunk.length,
                        filteredByCountry: isLastChunk ? ((rows && rows.filteredByCountry) || 0) : 0,
                        filteredByCategory: isLastChunk ? ((rows && rows.filteredByCategory) || 0) : 0,
                        duplicateInBatch: isLastChunk ? (preDuplicateCount + ((rows && rows.duplicateInBatch) || 0)) : 0,
                        skippedDetails: isLastChunk ? combinedSkippedDetails : [],
                        streaming: true,
                        deferStorageFlush: !isLastChunk,
                        safeModeRecovered: !!(rows && rows._safeModeRecovered)
                    });
                    savedNow += Math.max(0, parseInt(saveResult && saveResult.savedNow, 10) || 0);
                    totalDupesInSave += Math.max(0, parseInt(saveResult && saveResult.duplicateCount, 10) || 0);
                }
                savedAny = savedAny || savedNow > 0 || rows.length > 0;
                const totalFilteredNow = ((rows && rows.filteredByCountry) || 0) + ((rows && rows.filteredByCategory) || 0);
                const totalSkippedNow = totalDupesInSave + totalFilteredNow;
                if (typeof this.updatePincodeStatus === 'function') {
                    await this.updatePincodeStatus(variantMeta, {
                        status: savedNow > 0 ? 'completed' : (limited.length > 0 ? 'all_skipped' : 'no_results'),
                        apiIds: Array.isArray(items) ? items.length : limited.length,
                        domTotal: limited.length,
                        domProcessed: limited.length,
                        saved: savedNow,
                        failed: 0,
                        skipped: totalSkippedNow,
                        filtered: totalFilteredNow
                    }, false);
                }
                if (typeof this.emitDiagnosticSpy === 'function') {
                    this.emitDiagnosticSpy(totalSkippedNow > 0 ? 'FILTER_SKIP' : 'TASK_DONE', {
                        taskIndex: meta && meta.taskIndex,
                        totalTasks: meta && meta.totalTasks,
                        query: apiQuery,
                        keyword: meta && meta.keyword || '',
                        location: meta && meta.location || '',
                        provider: 'scrappa',
                        rawCount: Array.isArray(items) ? items.length : limited.length,
                        savedCount: savedNow,
                        skippedCount: totalSkippedNow,
                        duplicateCount: totalDupesInSave,
                        filteredCount: totalFilteredNow,
                        message: `${apiQuery}: Scrappa returned ${Array.isArray(items) ? items.length : limited.length} raw -> ${savedNow} unique saved, ${totalDupesInSave} duplicate skipped, ${totalFilteredNow} filtered.`
                    });
                }
                if (!this._fastFinishAttempt || (meta && meta.totalTasks <= 1)) {
                    const q = Object.assign(buildEmptyQueue(), (await getLocalAsync()).apifyQueue || {});
                    await this.updateQueue({
                        status: 'scrappa_streaming',
                        statusMessage: `${batchLabel} — ${limited.length} provider row(s), ${savedNow} new lead(s), ${totalSkippedNow} skipped/filtered. Total saved: ${q.scrapedCount || 0}.`,
                        currentQuery: apiQuery,
                        currentPage: logicalRequests,
                        totalPages: maxLogicalRequests,
                        totalApiResults: Math.max(q.totalApiResults || 0, totalProviderUnique),
                        totalPlaceIds: Math.max(q.totalPlaceIds || 0, totalProviderUnique)
                    });
                }
                return { newProviderRows: limited.length, savedNow, rows };
            };

            const requestSimple = async pageNo => {
                if (!(await this.isStillRunning())) return null;
                logicalRequests += 1;
                const statusUpdatePromise = (this._fastFinishAttempt && meta && meta.totalTasks > 1)
                    ? this.updateQueueThrottled({
                        status: 'scrappa_searching',
                        currentQuery: apiQuery,
                        currentPage: logicalRequests,
                        totalPages: maxLogicalRequests
                    }, 600, false)
                    : this.updateQueue({
                        status: 'scrappa_searching',
                        statusMessage: isPincode
                            ? `Scrappa pincode request ${logicalRequests}/${maxLogicalRequests}: one-shot page 0, limit ${requestSize}.`
                            : `Scrappa request ${logicalRequests}/${maxLogicalRequests}: broad search page ${pageNo}, limit ${requestSize}.`,
                        currentQuery: apiQuery,
                        currentPage: logicalRequests,
                        totalPages: maxLogicalRequests,
                        totalApiResults: totalProviderUnique,
                        totalPlaceIds: totalProviderUnique
                    });
                const [, rows] = await Promise.all([
                    statusUpdatePromise,
                    ScrappaClient.requestSimpleSearch(apiQuery, settings, pageNo, requestSize, variantMeta, Array.from(seenApi))
                ]);
                return rows;
            };

            // First request: broad city/pincode discovery.
            let firstItems = [];
            try {
                firstItems = await requestSimple(0) || [];
                this._managedProviderHttpOk = true;
                this._managedRawReturned = Array.isArray(firstItems) ? firstItems.length : 0;
                if (settings && settings.attemptId && this._managedUsableByAttempt && this._managedRawReturned > 0) {
                    this._managedUsableByAttempt.set(settings.attemptId, Math.max(this._managedUsableByAttempt.get(settings.attemptId) || 0, this._managedRawReturned));
                }
            } catch (err) {
                if (typeof this.emitDiagnosticSpy === 'function') {
                    this.emitDiagnosticSpy('API_ERROR', {
                        level: 'error',
                        taskIndex: meta && meta.taskIndex,
                        totalTasks: meta && meta.totalTasks,
                        query: apiQuery,
                        location: meta && meta.location || '',
                        provider: 'scrappa',
                        errorCode: err && err.code || 'SCRAPPA_ERROR',
                        message: `Scrappa API error for "${apiQuery}": ${err && err.message ? err.message : String(err)}`
                    });
                }
                if (isCommercialStopError(err) || isApiRotationError(err) || isProviderExecutionFailoverError(err)) throw err;
                throw err;
            }
            await processBatch(firstItems, 'Scrappa broad search');
            if (!firstItems.length) {
                stopReason = 'initial search returned no rows';
                if (typeof this.recordSessionSkipped === 'function') {
                    this.recordSessionSkipped([buildSkip({ company_name: meta && meta.location || apiQuery }, variantMeta, 'Scrappa returned 0 results for this query/location.', 'No Results', 'Scrappa:empty_response')]);
                }
                if (typeof this.updatePincodeStatus === 'function') {
                    await this.updatePincodeStatus(variantMeta, { status: 'no_results', apiIds: 0, saved: 0, skipped: 1 }, false);
                }
                if (typeof this.emitDiagnosticSpy === 'function') {
                    this.emitDiagnosticSpy('TASK_EMPTY', {
                        level: 'warn',
                        taskIndex: meta && meta.taskIndex,
                        totalTasks: meta && meta.totalTasks,
                        query: apiQuery,
                        location: meta && meta.location || '',
                        provider: 'scrappa',
                        rawCount: 0,
                        savedCount: 0,
                        skippedCount: 1,
                        message: `Scrappa returned 0 rows for "${apiQuery}".`
                    });
                }
            }

            if (!(await this.isStillRunning())) return;
            if (!stopReason) stopReason = 'single page-0 request complete (maximum 200 results)';

            if (!totalProviderUnique) {
                await this.updateQueue({
                    status: 'no_results',
                    statusMessage: 'No results found for: ' + meta.queryForApi,
                    currentQuery: meta.queryForApi,
                    currentPage: logicalRequests,
                    totalPages: maxLogicalRequests,
                    totalApiResults: 0,
                    totalPlaceIds: 0
                });
            } else {
                const targetNote = totalProviderUnique >= targetResults
                    ? `target ${targetResults} reached`
                    : (stopReason || `stopped after ${logicalRequests} cost-aware request(s)`);
                await this.updateQueue({
                    status: 'scrappa_done',
                    statusMessage: `Scrappa search complete — ${totalProviderUnique} provider-unique row(s) from ${logicalRequests} logical request(s); ${targetNote}.`,
                    currentQuery: meta.queryForApi,
                    currentPage: logicalRequests,
                    totalPages: maxLogicalRequests,
                    totalApiResults: totalProviderUnique,
                    totalPlaceIds: totalProviderUnique,
                    scrappaLogicalRequests: logicalRequests,
                    scrappaStopReason: stopReason
                });
            }
        },

        async processSerperQuery(meta, settings) {
            const pagePlan = getEffectivePageCount(meta, Object.assign({}, settings, { provider: 'serper' }));
            const maxPages = pagePlan.effective;
            const selectedPages = pagePlan.selected;
            const estimatedPageSize = SERPER_PAGE_SIZE;
            const max = maxPages * estimatedPageSize;
            let totalRaw = 0;
            let savedAny = false;
            const seenApi = new Set();
            const queryVariants = SerperClient.buildQueryVariants(meta.queryForApi, meta, settings);

            for (let variantIndex = 0; variantIndex < queryVariants.length && totalRaw < max; variantIndex += 1) {
                const apiQuery = queryVariants[variantIndex];
                const variantMeta = Object.assign({}, meta, { queryForApi: apiQuery, provider: 'serper' });
                for (let page = 1; page <= maxPages && totalRaw < max; page += 1) {
                    if (!(await this.isStillRunning())) return;
                    const capNote = pagePlan.isPincode ? ' (pincode: up to 7 pages)' : ' (auto: continues until empty/duplicate pages)';
                    const serperQueueUpdate = this.updateQueue({
                        status: 'serper_searching',
                        statusMessage: `Searching: ${apiQuery} — page ${page}/${maxPages}${capNote}`,
                        currentQuery: apiQuery,
                        currentPage: page,
                        totalPages: maxPages,
                        totalApiResults: totalRaw,
                        totalPlaceIds: totalRaw
                    });

                    let pageItems = [];
                    try {
                        const [, fetchedItems] = await Promise.all([
                            serperQueueUpdate,
                            SerperClient.requestHybridPage(apiQuery, settings, page, variantMeta)
                        ]);
                        pageItems = fetchedItems;
                    } catch (err) {
                        const msg = err && err.message ? err.message : String(err);
                        if (isCommercialStopError(err) || isApiRotationError(err) || isProviderExecutionFailoverError(err)) {
                            // Do not show a popup here. The main controller will rotate to the
                            // next active backend API row and retry the same keyword/page.
                            throw err;
                        }
                        const llMissing = /Parameter \"ll\"|GPS location|paginated maps/i.test(msg);
                        await this.updateQueue({
                            status: savedAny ? (llMissing ? 'serper_done' : 'partial_results') : 'failed',
                            statusMessage: savedAny
                                ? (llMissing ? `Saved available results for ${apiQuery}. More pages need GPS ll, but Serper did not return it.` : `Saved available results for ${apiQuery}. Extra page stopped: ${msg}`)
                                : msg,
                            currentQuery: apiQuery,
                            currentPage: Math.max(1, page - 1),
                            totalPages: maxPages,
                            totalApiResults: totalRaw,
                            totalPlaceIds: totalRaw
                        });
                        if (!savedAny) throw err;
                        break;
                    }

                    if (!Array.isArray(pageItems) || !pageItems.length) {
                        await this.updateQueue({
                            status: savedAny ? 'serper_done' : 'no_results',
                            statusMessage: savedAny ? `No more results for ${apiQuery}.` : `No results found for: ${apiQuery}`,
                            currentQuery: apiQuery,
                            currentPage: page,
                            totalPages: maxPages,
                            totalApiResults: totalRaw,
                            totalPlaceIds: totalRaw
                        });
                        break;
                    }

                    // Save Serper Maps rows immediately. Phone/address are already extracted
                    // from the Maps response, so no blocking detail search is done here.

                    const uniqueItems = [];
                    pageItems.forEach(item => {
                        const key = rowFingerprint(item);
                        if (!key || seenApi.has(key)) return;
                        seenApi.add(key);
                        uniqueItems.push(item);
                    });
                    if (!uniqueItems.length) {
                        await this.updateQueue({
                            status: savedAny ? 'serper_done' : 'no_results',
                            statusMessage: savedAny ? `Stopped at page ${page}: Serper repeated old results for ${apiQuery}.` : `No unique results found for: ${apiQuery}`,
                            currentQuery: apiQuery,
                            currentPage: page,
                            totalPages: maxPages,
                            totalApiResults: totalRaw,
                            totalPlaceIds: totalRaw
                        });
                        break;
                    }
                    const limited = uniqueItems.slice(0, Math.max(0, max - totalRaw));
                    totalRaw += limited.length;
                    let rows = DatasetNormalizer.normalizeItems(limited, variantMeta, settings);
                    // v57 result-guard: if API returned rows but filters/normalizer produced zero,
                    // retry once with country/category filters disabled so the dashboard still shows
                    // the data instead of a false "no result" experience.
                    if ((!rows || !rows.length) && limited.length) {
                        const safeSettings = Object.assign({}, settings || {}, { enforceCountryFilter: false });
                        rows = DatasetNormalizer.normalizeItems(limited, variantMeta, safeSettings);
                        rows._safeModeRecovered = true;
                    }
                    await this.saveDatasetRows(rows, variantMeta, totalRaw, {
                        rawBatchCount: limited.length,
                        filteredByCountry: rows.filteredByCountry || 0,
                        filteredByCategory: rows.filteredByCategory || 0,
                        duplicateInBatch: rows.duplicateInBatch || 0,
                        skippedDetails: rows.skippedDetails || [],
                        streaming: true,
                        safeModeRecovered: !!rows._safeModeRecovered
                    });
                    savedAny = savedAny || rows.length > 0;
                    // No background detail calls by default: Serper Maps already returns the available phone/address in one response.
                    // This keeps first result fast and prevents duplicate API searches.

                    const q = Object.assign(buildEmptyQueue(), (await getLocalAsync()).apifyQueue || {});
                    await this.updateQueue({
                        status: 'serper_streaming',
                        statusMessage: `Page ${page}/${maxPages} done — Saved ${q.scrapedCount || 0}, Read ${totalRaw}. Auto mode stops when no more or repeated results are returned.`,
                        currentQuery: apiQuery,
                        currentPage: page,
                        totalPages: maxPages,
                        totalApiResults: totalRaw,
                        totalPlaceIds: totalRaw
                    });

                    // Do not stop only because a page returned fewer than the estimated 20 rows.
                    // Some Maps APIs return 6-18 rows on middle pages but still have later pages.
                    // Continue until the selected page count is reached or a truly empty page arrives.
                }
            }

            // No extra Search/Places enrichment after Maps results. It saves credits and
            // avoids adding short/blank rows when Maps already returned complete data.

            const usageReport = await ApiBackendManager.reportUsage(settings, totalRaw);
            if (usageReport && usageReport.status === 'ok') {
                await this.updateQueue({
                    apiKeyRow: settings.apiKeyRow || settings.apifyKeyRow || 0,
                    apiUsageBefore: usageReport.before,
                    apiUsageAfter: usageReport.after,
                    apiUsageLimit: usageReport.usageLimit || settings.apiUsageLimit || settings.apifyUsageLimit || DEFAULT_SETTINGS.apiUsageLimit,
                    apifyKeyRow: settings.apiKeyRow || settings.apifyKeyRow || 0,
                    apifyUsageBefore: usageReport.before,
                    apifyUsageAfter: usageReport.after,
                    apifyUsageLimit: usageReport.usageLimit || settings.apiUsageLimit || settings.apifyUsageLimit || DEFAULT_SETTINGS.apiUsageLimit
                });
            }

            if (!totalRaw) {
                await this.updateQueue({
                    status: 'no_results',
                    statusMessage: 'No results found for: ' + meta.queryForApi,
                    currentQuery: meta.queryForApi,
                    currentPage: 0,
                    totalPages: maxPages,
                    totalApiResults: 0,
                    totalPlaceIds: 0
                });
            }
        },

        async enrichSavedRowsBestEffort(rows, meta, settings) {
            const maxEnrich = 25;
            const targets = (rows || []).filter(row => row && (!row.phone || !row.address || isShortAddress(row.address) || !row.city || !row.state || !row.pincode)).slice(0, maxEnrich);
            if (!targets.length) return;
            const queueBefore = Object.assign(buildEmptyQueue(), (await getLocalAsync()).apifyQueue || {});
            await this.updateQueue({
                status: 'enriching_details',
                statusMessage: `Enhancing phone/address for ${targets.length} result(s)...`,
                currentQuery: meta.queryForApi || meta.query,
                scrapedCount: queueBefore.scrapedCount || 0
            });
            let changed = 0;
            const concurrency = 8;
            for (let i = 0; i < targets.length; i += concurrency) {
                const chunk = targets.slice(i, i + concurrency);
                const enriched = await Promise.all(chunk.map(async row => {
                    const before = Object.assign({}, row);
                    if ((settings && settings.provider) === 'serper') await SerperClient.requestMapsDetailsForRow(row, settings, meta).catch(err => { if(isCommercialStopError(err))throw err; warn('Serper detail enrichment failed', err && err.message ? err.message : err); });
                    let details = {};
                    if (!normalizeBusinessPhone(row.phone || row.phoneNumber) || !row.address || isShortAddress(row.address) || !row.website) {
                        details = await MapsDetailEnricher.fetchDetails(row, meta);
                    }
                    if (row.phone && !before.phone) details.phone = row.phone;
                    if (row.address && (!before.address || isShortAddress(before.address))) details.address = row.address;
                    if (row.website && !before.website) details.website = row.website;
                    return { row, details };
                }));
                const local = await getLocalAsync();
                if (!Array.isArray(local.collect)) local.collect = [];
                enriched.forEach(({ row, details }) => {
                    if (!details || (!details.phone && !details.address && !details.website)) return;
                    const key = rowFingerprint(row);
                    const found = local.collect.find(item => rowFingerprint(item) === key);
                    if (!found) return;
                    if (!found.phone && details.phone) { found.phone = details.phone; changed += 1; }
                    if ((!found.address || isShortAddress(found.address)) && details.address) { found.address = details.address; changed += 1; }
                    if (!found.website && details.website) { found.website = details.website; changed += 1; }
                    completeAddressFromQuery(found, meta, settings);
                });
                await setLocalAsync(local);
            }
            if (await this.isStillRunning()) {
                const q = Object.assign(buildEmptyQueue(), (await getLocalAsync()).apifyQueue || {});
                await this.updateQueue({
                    status: 'serper_streaming',
                    statusMessage: changed ? `Enhanced ${changed} field(s). Continuing...` : 'Continuing search. Some businesses do not publish phone/address online.',
                    currentQuery: meta.queryForApi || meta.query,
                    scrapedCount: q.scrapedCount || 0
                });
            }
        },
        async rotateApiSettings(settings, err, triedRows) {
            const msg = err && err.message ? err.message : String(err || 'API error');
            const currentRow = apiKeyRowOf(settings);
            if (isCommercialStopError(err)) throw err;
            const licenceCreditIssue = false;
            const providerQuotaIssue = !licenceCreditIssue && isApiCreditLimitError(err);
            const configIssue = isApiKeyConfigError(err) && !providerQuotaIssue;
            if (currentRow) triedRows.add(currentRow);

            // Provider health is written by the backend response handler.
            const quotaIssue = providerQuotaIssue || licenceCreditIssue;
            const executionIssue = !configIssue && !quotaIssue;
            await this.updateQueue({
                status: 'switching_key',
                statusMessage: configIssue
                    ? 'API key/config restriction detected. Trying the next healthy provider row...'
                    : (licenceCreditIssue
                        ? 'Plan credit for this engine is exhausted. Trying another available engine...'
                        : (providerQuotaIssue
                            ? 'API credit/limit reached. Trying the next healthy provider row...'
                            : 'Provider execution failed. Failing over to the next healthy provider/engine...')),
                apiSwitchCount: triedRows.size,
                apiKeyRow: currentRow,
                apifyKeyRow: currentRow
            });
            try {
                const excluded = new Set(triedRows);
                const nextConfig = await ApiBackendManager.getConfig(false, settings.provider === 'googlemaps' ? 'googlemaps' : 'auto', Array.from(excluded));
                if (excluded.has(apiKeyRowOf(nextConfig))) { const e = new Error('No untried provider row is available. Retry after cooldown.'); e.code='PROVIDER_FAILOVER_EXHAUSTED'; throw e; }
                const nextSettings = SettingsManager.validate(Object.assign({}, settings, nextConfig));
                await this.updateQueue({
                    status: 'api_switched',
                    statusMessage: `Switched to next active ${nextSettings.provider || 'API'} row. Continuing without resetting progress...`,
                    provider: nextSettings.provider || '',
                    engine: nextSettings.provider === 'googlemaps' ? 'engine2_place_id_url_fallback' : 'engine1_structured_provider',
                    apiKeyRow: apiKeyRowOf(nextSettings),
                    apiUsageBefore: nextSettings.apiUsageBefore || nextSettings.apifyUsageBefore || 0,
                    apiUsageAfter: nextSettings.apiUsageBefore || nextSettings.apifyUsageBefore || 0,
                    apiUsageLimit: nextSettings.apiUsageLimit || nextSettings.apifyUsageLimit || DEFAULT_SETTINGS.apiUsageLimit,
                    apifyKeyRow: apiKeyRowOf(nextSettings),
                    apifyUsageBefore: nextSettings.apiUsageBefore || nextSettings.apifyUsageBefore || 0,
                    apifyUsageAfter: nextSettings.apiUsageBefore || nextSettings.apifyUsageBefore || 0,
                    apifyUsageLimit: nextSettings.apiUsageLimit || nextSettings.apifyUsageLimit || DEFAULT_SETTINGS.apiUsageLimit
                });
                return nextSettings;
            } catch (nextErr) {
                warn('No more backend API rows available after rotation', nextErr && nextErr.message ? nextErr.message : nextErr);
                const err = nextErr instanceof Error ? nextErr : new Error(String(nextErr || NO_PROVIDER_MESSAGE));
                if (!err.code) err.code = 'PROVIDER_FAILOVER_EXHAUSTED';
                throw err;
            }
        },

        async managedControl(action, payload) {
            const licence = await ensureLicenceInstallationAsync(await getStoredLicenceAsync());
            let result;
            try {
                for (let retry = 0; retry < 3; retry++) {
                    result = await callAppsScript(action, Object.assign({key: licence.key, deviceId: installationIdFromLicence(licence)}, payload), {attempts: 2, timeoutMs: 25000});
                    const isLockBusy = result && (result.status === 'busy' || result.errorCode === 'PROVIDER_BUSY' || (result.status === 'configuration_error' && /lock|timeout|waitlock|busy/i.test(String(result.message || ''))));
                    if (!isLockBusy || retry >= 2) break;
                    await new Promise(r => typeof setTimeout === 'function' ? setTimeout(r, 800 * (retry + 1)) : r());
                }
            }
            catch(e) {e.code='BACKEND_UNAVAILABLE';throw e;}
            if (!result || !['ok','attempt_complete'].includes(result.status)) {
                const e = new Error(result && (result.message || result.reason) || 'Routing request failed. Resume to retry.');
                e.code = result && result.errorCode || 'ROUTE_CHANGED'; throw e;
            }
            return result;
        },

        async processManagedQuery(meta, settings) {
            const queue = (await getLocalAsync()).apifyQueue || {};
            const runId = queue.managedRequestRunId || queue.runEventId || this._runEventId;
            const rGen = Math.max(0, parseInt(this._resumeGeneration || queue.resumeGeneration, 10) || 0);
            const seedStr = rGen > 0 ? (runId + '|r' + rGen + '|' + String(meta.query || '')) : (runId + '|' + String(meta.query || ''));
            const input = new TextEncoder().encode(seedStr);
            let attemptId = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', input)), b => b.toString(16).padStart(2,'0')).join('');
            const prefetchedMap = this._prefetchedBeginRoutes;
            const prefetched = this._prefetchedBeginRoute;
            this._prefetchedBeginRoute = null;
            const canUseOptimisticAutoBegin = !!(this._fastAutoBeginExplicitlySupported && !this._fastAutoBeginUnsupported && settings && settings.provider && (settings.apiKeyRow || settings.apifyKeyRow));
            const nowTs = () => (typeof Date !== 'undefined' && typeof Date.now === 'function') ? Date.now() : 0;
            const beginWithRecovery = async (idToUse) => {
                try {
                    return await this.managedControl('beginExtraction', { attemptId: idToUse, resetExhaustedAttempt: true });
                } catch (beginErr) {
                    if (beginErr && (beginErr.code === 'ROUTE_CHANGED' || beginErr.code === 'PROVIDER_FAILOVER_EXHAUSTED')) {
                        const freshSeed = new TextEncoder().encode(runId + '|fresh|' + nowTs() + '|' + String(meta.query || ''));
                        attemptId = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', freshSeed)), b => b.toString(16).padStart(2,'0')).join('');
                        return await this.managedControl('beginExtraction', { attemptId, resetExhaustedAttempt: true });
                    }
                    throw beginErr;
                }
            };
            const beginRoutePromise = (async () => {
                if (canUseOptimisticAutoBegin) {
                    return {
                        status: 'ok',
                        provider: (typeof canonicalProviderKey === 'function' ? canonicalProviderKey(settings.provider) : settings.provider) || settings.provider,
                        keyRow: settings.apiKeyRow || settings.apifyKeyRow,
                        attemptId,
                        _optimistic: true
                    };
                }
                if (prefetchedMap && prefetchedMap.has(attemptId)) {
                    const p = prefetchedMap.get(attemptId);
                    prefetchedMap.delete(attemptId);
                    const ready = await p.catch(() => null);
                    if (ready && ready.route) return ready.route;
                }
                if (prefetched) {
                    const ready = await prefetched.catch(() => null);
                    if (ready && ready.attemptId === attemptId && ready.route) return ready.route;
                }
                return beginWithRecovery(attemptId);
            })();
            const prepStatusPromise = (this._fastFinishAttempt && meta && meta.totalTasks > 1)
                ? Promise.resolve()
                : this.updateQueue({status:'provider_preparing',statusMessage:'Preparing the assigned provider request. First results will appear as soon as the provider responds.'});
            const [, initialRoute] = await Promise.all([
                prepStatusPromise,
                beginRoutePromise
            ]);
            let route = initialRoute;
            if (route && route.status === 'attempt_complete') {
                if (rGen > 0) {
                    const freshSeed = new TextEncoder().encode(runId + '|resume_fresh|' + nowTs() + '|' + String(meta.query || ''));
                    attemptId = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', freshSeed)), b => b.toString(16).padStart(2,'0')).join('');
                    route = await beginWithRecovery(attemptId);
                } else {
                    return settings;
                }
            }
            if (route && route.status === 'attempt_complete') return settings;
            const tried = new Set();
            while (await this.isStillRunning()) {
                if (tried.has(route.provider) || tried.size >= 3) { const e = new Error('Provider fallback exhausted.'); e.code='PROVIDER_FAILOVER_EXHAUSTED'; throw e; }
                tried.add(route.provider);
                const active = SettingsManager.validate(Object.assign({}, settings, {provider: route.provider, managedRouting:true, attemptId, requestRunId:runId,
                    apiKeyRow:route.keyRow, apifyKeyRow:route.keyRow, providerMetrics:{},runEventId:this._runEventId}));
                if (!this._managedUsableByAttempt) this._managedUsableByAttempt = new Map();
                this._managedUsableByAttempt.set(attemptId, 0);
                this._managedUsable = 0;
            this._liveRunCreditRemaining = null;
                this._managedProviderHttpOk = false;
                this._managedRawReturned = 0;
                let failure = null;
                if (!this._fastFinishAttempt || !meta || meta.totalTasks <= 1) {
                    await this.updateQueue({provider:active.provider,status:'running',statusMessage:'Searching with '+active.provider+' ('+tried.size+'/3 providers).'});
                }
                try {
                    if (active.provider === 'googlemaps') await this.processManagedGoogleQuery(meta,active);
                    else await this.processQueryWithSettings(Object.assign({},meta),active);
                } catch(e) {
                    if (active && active.attemptId && active.attemptId !== attemptId) attemptId = active.attemptId;
                    if (isCommercialStopError(e)) throw e;
                    failure=e;
                }
                if (active && active.attemptId && active.attemptId !== attemptId) attemptId = active.attemptId;
                if (!(await this.isStillRunning())) return active;
                if (route._optimistic && failure) {
                    if (failure.code === 'ROUTE_CHANGED' && /Begin this extraction/i.test(String(failure.message || ''))) {
                        this._fastAutoBeginUnsupported = true;
                    }
                    tried.delete(route.provider);
                    if (failure.nextRoute && failure.nextRoute.status) {
                        route = failure.nextRoute;
                    } else {
                        try {
                            route = await beginWithRecovery(attemptId);
                        } catch (recErr) {
                            throw failure.code === 'PROVIDER_FAILOVER_EXHAUSTED' ? failure : recErr;
                        }
                    }
                    if (route.status === 'attempt_complete') return active;
                    if (route.status !== 'ok') {
                        const err = new Error(route.message || failure.message || 'All assigned providers failed or returned no usable results.');
                        err.code = route.errorCode || failure.code || 'PROVIDER_FAILOVER_EXHAUSTED';
                        throw err;
                    }
                    if (route.keyRow && settings) {
                        settings.apiKeyRow = route.keyRow;
                        settings.apifyKeyRow = route.keyRow;
                    }
                    continue;
                }
                const usable = Math.max(
                    this._managedUsable || 0,
                    (this._managedUsableByAttempt && this._managedUsableByAttempt.get(attemptId)) || 0,
                    (!failure && this._managedProviderHttpOk && (this._managedRawReturned || 0) > 0) ? this._managedRawReturned : 0
                );
                if (this._managedUsableByAttempt) this._managedUsableByAttempt.delete(attemptId);
                if (usable > 0 && !failure && this._fastFinishAttempt) {
                    route = { status: 'attempt_complete', usableResults: usable };
                } else if (failure && failure.nextRoute && failure.nextRoute.status === 'ok' && failure.nextRoute.provider && failure.nextRoute.provider !== active.provider) {
                    route = failure.nextRoute;
                    try { await this.managedControl('finishProviderAttempt', {attemptId,provider:active.provider,usableResults:0}); } catch (_) {}
                } else {
                    try { route = await this.managedControl('finishProviderAttempt', {attemptId,provider:active.provider,usableResults:usable}); }
                    catch(error){
                        if ((usable > 0 || (!failure && this._managedProviderHttpOk)) && !isCommercialStopError(error) && error.code !== 'ROUTE_CHANGED') {
                            route = { status: 'attempt_complete', usableResults: usable };
                        } else {
                            if(error.code==='PROVIDER_FAILOVER_EXHAUSTED' && failure)error.message += ' Last '+active.provider+' error: '+failure.message;
                            throw error;
                        }
                    }
                }
                if (route.status === 'attempt_complete') {
                    if (failure) await this.updateQueue({status:'partial_results',statusMessage:'Saved usable '+active.provider+' results; extra pages stopped: '+failure.message});
                    return active;
                }
                if (route.keyRow && settings) {
                    settings.provider = route.provider;
                    settings.apiKeyRow = route.keyRow;
                    settings.apifyKeyRow = route.keyRow;
                }
                await this.updateQueue({status:'switching_key',statusMessage:(failure?failure.message:'No usable results')+'. Trying '+route.provider+'.'});
            }
            return settings;
        },

        async processManagedGoogleQuery(meta, settings) {
            meta = Object.assign({},meta,{settings,provider:'googlemaps'});
            meta.country = settings.countryFilter || 'India';
            meta.queryForApi = normalizeQueryTextForApi(ensureQueryHasCountry(meta.query,meta.country));
            try { if (typeof self !== 'undefined' && self.PocketLeadsGhostMode && typeof self.PocketLeadsGhostMode.prewarm === 'function') void self.PocketLeadsGhostMode.prewarm(); } catch (_) {}
            const jobRun = 'gjobs:' + String(meta.queryForApi || meta.query || '').toLowerCase().trim();
            const checkpoint=async operation=>{try{return await operation();}catch(cause){const e=new Error('Ghost queue could not be saved/read. Resume after storage recovers. '+String(cause.message||cause));e.code='RESULT_STORE_UNAVAILABLE';throw e;}};
            let [jobs, savedKeys, localSnap] = await Promise.all([
                checkpoint(()=>JobStore.getRun(jobRun)),
                ResultStore.getKeySet(),
                getLocalAsync()
            ]);
            const byId = new Map(jobs.map(j=>[j.placeId,j]));
            const snapQueue = (localSnap && localSnap.apifyQueue && Array.isArray(localSnap.apifyQueue.placeIdQueue)) ? localSnap.apifyQueue.placeIdQueue : [];
            for (const qItem of snapQueue) {
                const pid = String(qItem && (qItem.placeId || qItem.place_id) || '').trim();
                if (!pid || byId.has(pid)) continue;
                const restoredJob = { placeId: pid, status: 'pending', query: meta.query, attempts: 0 };
                byId.set(pid, restoredJob);
                jobs.push(restoredJob);
            }
            const isResumingRun = Math.max(0, parseInt(this._resumeGeneration, 10) || 0) > 0;
            let processed=0,saved=0,failed=0,lastError='',blockedError=null,fatalWorkerError=null,apiFeeding=true;
            const pending=[];
            for(const job of jobs){
                if(savedKeys.has(rowFingerprint({place_id:job.placeId}))){
                    this._managedUsable=(this._managedUsable||0)+1;processed++;saved++;continue;
                }
                if (job.status === 'dom_running' || (isResumingRun && job.status === 'failed_final' && !/GOOGLE_ACCESS_BLOCKED/.test(job.error || ''))) {
                    job.status = 'pending';
                }
                if(job.status==='failed_final' && (job.profileEngineVersion==='10.16.3' || job.profileEngineVersion==='10.16.4' || /GOOGLE_ACCESS_BLOCKED/.test(job.error||''))){
                    processed++;failed++;lastError=job.error||lastError;continue;
                }
                if(job.status==='filtered_country'){processed++;continue;}
                pending.push(job);
            }

            let cursor=0;
            const workerPromises=[];
            const worker=async lane=>{
                while(await this.isStillRunning()){
                    if(blockedError||fatalWorkerError)return;
                    const job=pending[cursor];
                    if(!job){
                        if(!apiFeeding)return;
                        await new Promise(r=>setTimeout(r,25));
                        continue;
                    }
                    cursor++;
                    await this.updateQueue({
                        status:'google_profile_scraping',currentQuery:meta.queryForApi,
                        domTotal:jobs.length,domProcessed:processed,domSaved:saved,domFailed:failed,
                        domPending:Math.max(0,jobs.length-processed),domRunning:Math.min(2,pending.length-cursor+1),
                        domConcurrency:Math.min(2,pending.length),
                        statusMessage:`Ghost Mode: opening profile ${processed+1}/${jobs.length} (worker ${lane+1}).`
                    });
                    job.status='dom_running';job.profileEngineVersion='10.16.4';job.lastUpdatedAt=nowIso();
                    await checkpoint(()=>JobStore.put(jobRun,job));
                    try{
                        const row=await ProfileScraper.scrapePlaceId(job.placeId,meta,settings,lane);
                        if(!(await this.isStillRunning())){job.status='pending';job.reason='Paused while the single profile attempt was in flight.';await checkpoint(()=>JobStore.put(jobRun,job));return;}
                        row.place_id=job.placeId;row.cid=row.cid||job.placeId;row.map_link=row.map_link||PlaceIdManager.toMapsUrl(job.placeId);
                        row.phone_number=row.phone_number||row.phone||'';row.phone=row.phone||row.phone_number||'';
                        row.keyword=row.keyword||meta.keyword||meta.query||'';row.location=row.location||meta.location||'';
                        row._provider='googlemaps';row.source='Google Maps';
                        completeAddressFromQuery(row,meta,settings);
                        if(CountryFilter.isAllowed(row,row,meta,settings)){
                            const saveCall=()=>this.saveDatasetRows([row],meta,1,{enrichmentUpdate:true});
                            const writeChain=this._resultWriteChain||Promise.resolve();const saveRun=writeChain.then(saveCall,saveCall);this._resultWriteChain=saveRun.catch(()=>null);
                            const result=await saveRun;
                            if(!result||!(result.savedNow>0||result.updatedNow>0)){
                                const committedKeys=await ResultStore.getKeySet();
                                if(!committedKeys.has(rowFingerprint(row))){const error=new Error('Google profile was extracted but could not be persisted to the dashboard.');error.code='RESULT_STORE_UNAVAILABLE';throw error;}
                            }
                            job.status='saved';job.reason='Saved to IndexedDB result store.';saved++;this._managedUsable=(this._managedUsable||0)+1;
                            savedKeys.add(rowFingerprint(row));
                        }else{job.status='filtered_country';job.reason='Country filter failed after profile extraction.';}
                    }catch(e){
                        if(isCommercialStopError(e)){fatalWorkerError=e;throw e;}
                        if(!(await this.isStillRunning())){job.status='pending';job.reason='Paused during profile extraction; queued for Resume.';await checkpoint(()=>JobStore.put(jobRun,job));return;}
                        job.status='failed_final';job.error=String(e.message||e);job.reason=job.error;job.attempts=1;job.failedAt=nowIso();lastError=job.error;failed++;
                        if(/GOOGLE_ACCESS_BLOCKED/.test(job.error))blockedError=e;
                    }
                    processed++;job.completedAt=nowIso();job.lastUpdatedAt=nowIso();
                    await checkpoint(()=>JobStore.put(jobRun,job));
                    await this.updateQueue({
                        jobRunId:jobRun,
                        placeIdQueue:pending.slice(cursor, cursor + 200).map(j => ({ placeId: j.placeId, status: 'pending' })),
                        domTotal:jobs.length,domProcessed:processed,domSaved:saved,domFailed:failed,
                        domPending:Math.max(0,jobs.length-processed),domRunning:Math.max(0,Math.min(2,pending.length-cursor)),
                        domConcurrency:Math.min(2,pending.length),lastProfileError:lastError,
                        statusMessage:`Ghost Mode: ${processed}/${jobs.length} profiles processed, ${saved} saved, ${failed} failed.`
                    });
                }
            };
            const ensureWorkers=()=>{
                const target=Math.min(2,pending.length);
                while(workerPromises.length<target){
                    const lane=workerPromises.length;
                    workerPromises.push(worker(lane));
                }
            };
            const enqueueBatch=async batchIds=>{
                if(!(await this.isStillRunning()))return;
                let addedAny=false;
                for(const placeId of (batchIds||[])){
                    if(byId.has(placeId))continue;
                    const job={placeId,status:'pending',query:meta.query,attempts:0};
                    await checkpoint(()=>JobStore.put(jobRun,job));
                    byId.set(placeId,job);
                    jobs.push(job);
                    if(savedKeys.has(rowFingerprint({place_id:job.placeId}))){
                        this._managedUsable=(this._managedUsable||0)+1;processed++;saved++;
                    }else{
                        pending.push(job);
                    }
                    addedAny=true;
                }
                if(addedAny){
                    await this.updateQueue({
                        jobRunId:jobRun,
                        placeIdQueue:pending.slice(cursor, cursor + 200).map(j => ({ placeId: j.placeId, status: 'pending' })),
                        status:'google_profile_scraping',totalPlaceIds:jobs.length,domTotal:jobs.length,
                        domProcessed:processed,domSaved:saved,domFailed:failed,domPending:Math.max(0,pending.length-cursor),domRunning:workerPromises.length,
                        domConcurrency:Math.min(2,pending.length),
                        statusMessage:`Ghost Mode is ready: processing ${pending.length} profile(s) using up to 2 hidden workers.`
                    });
                    ensureWorkers();
                }
            };
            if(pending.length){
                await this.updateQueue({
                    status:'google_profile_scraping',totalPlaceIds:jobs.length,domTotal:jobs.length,
                    domProcessed:processed,domSaved:saved,domFailed:failed,domPending:pending.length,domRunning:0,
                    domConcurrency:Math.min(2,pending.length),
                    statusMessage:`Ghost Mode is ready: processing ${pending.length} profile(s) using up to 2 hidden workers.`
                });
            }
            // Stream Page 1 Place IDs immediately into Ghost Mode workers while remaining pages fetch in parallel.
            let ids=[];
            try{
                ids=await GoogleMapsPlacesClient.searchPlaceIds(meta.queryForApi,settings,meta,async pageIds=>{
                    await enqueueBatch(pageIds);
                });
            }finally{
                apiFeeding=false;
            }
            if (!(await this.isStillRunning())) { await Promise.allSettled(workerPromises); return; }
            await enqueueBatch(ids);
            ensureWorkers();
            await Promise.all(workerPromises);
            try { if (typeof self !== 'undefined' && self.PocketLeadsGhostMode && typeof self.PocketLeadsGhostMode.close === 'function') await self.PocketLeadsGhostMode.close(); } catch (_) {}
            if(fatalWorkerError)throw fatalWorkerError;
            if(blockedError){
                await this.updateQueue({domTotal:jobs.length,domProcessed:processed,domSaved:saved,domFailed:failed,
                    domPending:Math.max(0,jobs.length-processed),domRunning:0,lastProfileError:lastError,
                    status:'google_access_blocked',statusMessage:lastError||'Google requires consent or verification.'});
                throw blockedError;
            }
            await this.updateQueue({totalPlaceIds:jobs.length,domTotal:jobs.length,domProcessed:processed,domSaved:saved,domFailed:failed,domPending:0,domRunning:0,
                placeIdQueue:[],pendingPlaceIds:[],producerDone:true,consumerDone:true,resumeAvailable:false,
                status:saved?'dataset_saved':'no_results',lastProfileError:lastError,
                statusMessage:'Google: '+jobs.length+' Place IDs, '+saved+' usable profiles, '+failed+' failed profiles.'+(lastError?' Last error: '+lastError:'')});
            if(!saved && failed){const e=new Error('No Google profiles extracted. '+lastError);e.code='GHOST_EXTRACTION_FAILED';throw e;}

        },

        async processQuery(meta, settings) {
            if (settings && settings.managedRouting) return this.processManagedQuery(meta, settings);
            meta = Object.assign({ keyword: '', location: '', query: '' }, meta || {});
            if (!meta.query && meta.keyword) meta.query = meta.keyword;
            if (!meta.query) throw new Error('Blank/invalid task skipped: query missing.');
            let activeSettings = SettingsManager.validate(settings || {});
            const triedRows = new Set();
            if (triedRows.has(apiKeyRowOf(activeSettings))) activeSettings = SettingsManager.validate(Object.assign({},activeSettings,await ApiBackendManager.getConfig(false,'auto',Array.from(triedRows))));
            while (await this.isStillRunning()) {
                if (!(await this.isStillRunning())) return;
                const row = apiKeyRowOf(activeSettings);
                if (row) triedRows.add(row);
                try {
                    if (activeSettings.provider === 'googlemaps') return activeSettings;
                    await this.processQueryWithSettings(Object.assign({}, meta), activeSettings);
                    return activeSettings;
                } catch (err) {
                    if (isCommercialStopError(err) || (!isApiRotationError(err) && !isProviderExecutionFailoverError(err))) throw err;
                    warn('API row failed; rotating', row, err && err.message ? err.message : err);
                    activeSettings = await this.rotateApiSettings(activeSettings, err, triedRows);
                }
            }
            return activeSettings;
        },

        async searchGoogleWithFailover(query, settings, meta, onPageIds) {
            const tried = new Set();
            if (tried.has(apiKeyRowOf(settings))) Object.assign(settings, await ApiBackendManager.getConfig(false,'googlemaps',Array.from(tried)));
            while (await this.isStillRunning()) {
                try { return await GoogleMapsPlacesClient.searchPlaceIds(query, settings, meta, onPageIds); }
                catch (err) {
                    if (isCommercialStopError(err) || (!isApiRotationError(err) && !isProviderExecutionFailoverError(err))) throw err;
                    Object.assign(settings, await this.rotateApiSettings(settings,err,tried));
                }
            }
            return [];
        },

        async processQueryWithSettings(meta, settings) {
            meta = Object.assign({ keyword: '', location: '', query: '' }, meta || {});
            settings = SettingsManager.validate(settings || {});
            // Keep current non-secret routing metadata with each batch so exact
            // dashboard unique-lead metrics are reported to the API row that
            // actually served the request (including same-provider row recovery).
            meta.settings = settings;
            if (!meta.query && meta.keyword) meta.query = meta.keyword;
            if (!meta.query && meta.queryForApi) meta.query = meta.queryForApi;
            if (!meta.query) throw new Error('Blank/invalid task skipped: query missing.');
            const country = String((meta && meta.country) || (settings && settings.countryFilter) || 'India').trim() || 'India';
            meta.country = country;
            const rawApiQuery = buildCountryRestrictedQuery(meta.query, country);
            meta.queryForApi = normalizeQueryTextForApi(rawApiQuery);
            log('Processing query', { originalQuery: meta.query, apiQuery: meta.queryForApi, country, provider: settings.provider });
            const providerStatus = settings.provider === 'scrappa' ? 'scrappa_starting' : (settings.provider === 'serper' ? 'serper_starting' : (settings.provider === 'googlemaps' ? 'google_ids_starting' : 'apify_starting'));
            const engineMessage = settings.provider === 'googlemaps' ? 'Engine 2 (Place IDs + URL fallback): ' : 'Engine 1 (structured provider): ';
            const providerMessage = settings.provider === 'scrappa'
                ? engineMessage + 'Searching Scrappa Maps with country restriction: '
                : (settings.provider === 'serper'
                    ? engineMessage + 'Searching Serper Maps with country restriction: '
                    : (settings.provider === 'googlemaps' ? engineMessage + 'Google Maps IDs-only search: ' : engineMessage + 'Starting search for: '));
            await this.updateQueue({
                status: providerStatus,
                statusMessage: providerMessage + meta.queryForApi,
                provider: settings.provider || '',
                engine: settings.provider === 'googlemaps' ? 'engine2_place_id_url_fallback' : 'engine1_structured_provider',
                currentQuery: meta.queryForApi,
                currentProfileUrl: '',
                pendingPlaceIds: [],
                processing: null
            });

            if (settings.provider === 'scrappa') {
                await this.processScrappaQuery(meta, settings);
                return;
            }
            if (settings.provider === 'serper') {
                await this.processSerperQuery(meta, settings);
                return;
            }
            if (settings.provider === 'googlemaps') {
                throw new Error('Google work must enter runGooglePipeline.');
                return;
            }

            let run = await ApifyClient.runActor(meta.queryForApi, settings);
            let datasetId = ApifyClient.getDatasetId(run) || '';

            let fetchedOffset = 0;
            let sawAnyItems = false;
            let runStatus = String(run && run.status || '').toUpperCase();
            const target = parseInt(settings.maxResultsPerSearch, 10) || 0;
            const apifyPagePlan = getEffectivePageCount(meta, settings);
            const maxPages = apifyPagePlan.effective;
            const startedAt = Date.now();

            while (await this.isStillRunning()) {
                const remaining = target > 0 ? Math.max(0, target - fetchedOffset) : settings.datasetPageSize;
                if (target <= 0 || remaining > 0) {
                    let items = [];
                    try {
                        items = datasetId
                            ? await ApifyClient.getDatasetItems(datasetId, settings, fetchedOffset, remaining || settings.datasetPageSize)
                            : await ApifyClient.getRunDatasetItems(run.id, settings, fetchedOffset, remaining || settings.datasetPageSize);
                    } catch (fetchErr) {
                        const msg = fetchErr && fetchErr.message ? fetchErr.message : String(fetchErr);
                        if (!datasetId && /404|dataset|not found|not.*array/i.test(msg)) items = [];
                        else throw fetchErr;
                    }
                    if (items.length) {
                        sawAnyItems = true;
                        fetchedOffset += items.length;
                        let rows = DatasetNormalizer.normalizeItems(items, meta, settings);
                        // v57 result-guard for Apify datasets too: avoid empty dashboard when
                        // the actor returned data but local filters were too strict.
                        if ((!rows || !rows.length) && items.length) {
                            const safeSettings = Object.assign({}, settings || {}, { enforceCountryFilter: false });
                            rows = DatasetNormalizer.normalizeItems(items, meta, safeSettings);
                            rows._safeModeRecovered = true;
                        }
                        await this.saveDatasetRows(rows, meta, fetchedOffset, {
                            rawBatchCount: items.length,
                            filteredByCountry: rows.filteredByCountry || 0,
                            filteredByCategory: rows.filteredByCategory || 0,
                            duplicateInBatch: rows.duplicateInBatch || 0,
                            skippedDetails: rows.skippedDetails || [],
                            streaming: true,
                            safeModeRecovered: !!rows._safeModeRecovered
                        });
                    }
                }

                run = await ApifyClient.getRun(run.id, settings);
                datasetId = datasetId || ApifyClient.getDatasetId(run) || '';
                runStatus = String(run && run.status || '').toUpperCase();
                ApifyClient.assertSucceeded(run);
                const q = Object.assign(buildEmptyQueue(), (await getLocalAsync()).apifyQueue || {});
                await this.updateQueue({
                    status: TERMINAL_STATUSES.includes(runStatus) ? 'fetching_dataset' : 'streaming_results',
                    statusMessage: `Loading results for ${meta.queryForApi} — read ${fetchedOffset}, saved ${q.scrapedCount || 0}`,
                    currentQuery: meta.queryForApi,
                    totalApiResults: fetchedOffset,
                    totalPlaceIds: fetchedOffset
                });

                if (TERMINAL_STATUSES.includes(runStatus)) break;
                if (target > 0 && fetchedOffset >= target) break;
                if (Date.now() - startedAt > settings.pollTimeoutMs) throw new Error('Actor polling timed out at status ' + (runStatus || 'RUNNING'));
                await sleep(settings.streamPollIntervalMs || settings.pollIntervalMs || 1200);
            }

            if (!(await this.isStillRunning())) return;

            // Final quick fetch catches any last rows written just before the actor finished.
            const finalRemaining = target > 0 ? Math.max(0, target - fetchedOffset) : settings.datasetPageSize;
            if (finalRemaining > 0) {
                let finalItems = [];
                try {
                    finalItems = datasetId
                        ? await ApifyClient.getDatasetItems(datasetId, settings, fetchedOffset, finalRemaining)
                        : await ApifyClient.getRunDatasetItems(run.id, settings, fetchedOffset, finalRemaining);
                } catch (finalFetchErr) {
                    const msg = finalFetchErr && finalFetchErr.message ? finalFetchErr.message : String(finalFetchErr);
                    if (!/404|dataset|not found|not.*array/i.test(msg)) throw finalFetchErr;
                }
                if (finalItems.length) {
                    sawAnyItems = true;
                    fetchedOffset += finalItems.length;
                    const finalRows = DatasetNormalizer.normalizeItems(finalItems, meta, settings);
                    await this.saveDatasetRows(finalRows, meta, fetchedOffset, {
                        rawBatchCount: finalItems.length,
                        filteredByCountry: finalRows.filteredByCountry || 0,
                        filteredByCategory: finalRows.filteredByCategory || 0,
                        duplicateInBatch: finalRows.duplicateInBatch || 0,
                        skippedDetails: finalRows.skippedDetails || [],
                        streaming: false
                    });
                }
            }

            const usageReport = await ApiBackendManager.reportUsage(settings, fetchedOffset);
            if (usageReport && usageReport.status === 'ok') {
                await this.updateQueue({
                    apiKeyRow: settings.apiKeyRow || settings.apifyKeyRow || 0,
                    apiUsageBefore: usageReport.before,
                    apiUsageAfter: usageReport.after,
                    apiUsageLimit: usageReport.usageLimit || settings.apiUsageLimit || settings.apifyUsageLimit || DEFAULT_SETTINGS.apiUsageLimit,
                    apifyKeyRow: settings.apiKeyRow || settings.apifyKeyRow || 0,
                    apifyUsageBefore: usageReport.before,
                    apifyUsageAfter: usageReport.after,
                    apifyUsageLimit: usageReport.usageLimit || settings.apiUsageLimit || settings.apifyUsageLimit || DEFAULT_SETTINGS.apiUsageLimit,
                    statusMessage: `Backend usage updated.`
                });
            }

            if (!sawAnyItems) {
                await this.updateQueue({
                    status: 'no_results',
                    statusMessage: 'No results found for: ' + meta.queryForApi,
                    currentQuery: meta.queryForApi,
                    currentPage: 0,
                    totalPages: maxPages,
                    totalApiResults: 0,
                    totalPlaceIds: 0
                });
                return;
            }

            const local = await getLocalAsync();
            const queue = Object.assign(buildEmptyQueue(), local.apifyQueue || {});
            if (!(queue.scrapedCount || 0)) {
                await this.updateQueue({
                    status: 'no_results_after_filter',
                    statusMessage: `Found ${fetchedOffset} row(s), but all were duplicate or outside ${country || 'selected country'} filter.`,
                    currentQuery: meta.queryForApi,
                    totalApiResults: fetchedOffset,
                    totalPlaceIds: fetchedOffset
                });
            }
        },


        // v98.1 progressive dashboard feed manager.
        // Keeps API/storage writes independent from UI animation. Every new run
        // invalidates old timers so stale results can never appear.
        _progressiveFeedState: { token: 0, timers: [] },

        cancelProgressiveFeed() {
            try {
                const state = this._progressiveFeedState;
                (state.timers || []).forEach(id => clearTimeout(id));
                state.timers = [];
                state.pending = [];
                state.draining = false;
                state.token++;
            } catch (e) {}
        },

        scheduleProgressiveDashboardFeed(rows, meta, queue) {
            const state = this._progressiveFeedState;
            if (!state.pending) state.pending = [];
            const list = Array.isArray(rows) ? rows : [];
            for (let i = 0; i < list.length; i += 50) {
                state.pending.push({ rows: list.slice(i, i + 50), total: queue && queue.resultStoreCount,
                    runId: queue && queue.runEventId, provider: queue && queue.provider || '' });
            }
            if (state.draining || !state.pending.length) return;
            state.draining = true;
            const token = state.token;
            const drain = () => {
                state.timers = [];
                if (state.token !== token) return;
                const batch = state.pending.shift();
                if (batch) {
                    try { chrome.runtime.sendMessage(Object.assign({action: 'PL_RESULT_STORE_DELTA', progressive: true, at: nowIso()}, batch),
                        () => { void chrome.runtime.lastError; }); } catch (_) {}
                }
                if (state.pending.length) state.timers.push(setTimeout(drain, 10));
                else state.draining = false;
            };
            state.timers.push(setTimeout(drain, 0));
        },

        queueLeadMetricsSync(metricSettings, uniqueAddedNow, creditToDeduct, metricEventId, runMetricId) {
            const added = Math.max(0, parseInt(uniqueAddedNow, 10) || 0);
            const debit = Math.max(0, parseInt(creditToDeduct, 10) || 0);
            if (!added && !debit) return;
            if (!this._pendingLeadMetrics) this._pendingLeadMetrics = new Map();
            const provider = canonicalProviderKey(metricSettings && metricSettings.provider || '');
            const keyRow = apiKeyRowOf(metricSettings);
            const bucketKey = `${provider}:${keyRow}:${runMetricId}`;
            const existing = this._pendingLeadMetrics.get(bucketKey) || {
                settings: metricSettings,
                provider,
                runId: runMetricId,
                uniqueAdded: 0,
                creditToDeduct: 0,
                events: []
            };
            existing.settings = metricSettings;
            existing.uniqueAdded += added;
            existing.creditToDeduct += debit;
            if (metricEventId) existing.events.push(metricEventId);
            this._pendingLeadMetrics.set(bucketKey, existing);
            const fastFlushDelay = (typeof this._liveRunCreditRemaining === "number" && Number.isFinite(this._liveRunCreditRemaining) && this._liveRunCreditRemaining <= 250) ? 400 : 4000;
            if (!this._leadMetricsFlushTimer && typeof setTimeout === 'function') {
                this._leadMetricsFlushTimer = setTimeout(() => {
                    this._leadMetricsFlushTimer = null;
                    void this.flushLeadMetricsSync();
                }, fastFlushDelay);
            }
        },

        async flushLeadMetricsSync() {
            if (this._leadMetricsFlushTimer && typeof clearTimeout === 'function') {
                clearTimeout(this._leadMetricsFlushTimer);
                this._leadMetricsFlushTimer = null;
            }
            if (!this._pendingLeadMetrics || !this._pendingLeadMetrics.size) return;
            const entries = Array.from(this._pendingLeadMetrics.entries());
            this._pendingLeadMetrics.clear();
            const runFlush = async () => {
                for (const [, batch] of entries) {
                    if (!batch.uniqueAdded && !batch.creditToDeduct) continue;
                    const combinedEventId = `v96|${batch.runId}|${batch.provider}|${hashString(batch.events.join('|'))}|${batch.uniqueAdded}|${batch.creditToDeduct}`;
                    await ApiBackendManager.reportLeadMetrics(
                        batch.settings,
                        batch.uniqueAdded,
                        combinedEventId,
                        {
                            deductUniqueCredit: batch.creditToDeduct > 0,
                            creditToDeduct: batch.creditToDeduct,
                            provider: batch.provider,
                            runId: batch.runId
                        }
                    ).catch(metricErr => warn('Coalesced unique lead metric report failed', metricErr));
                }
            };
            const chain = (this._leadMetricsFlushChain || Promise.resolve()).then(runFlush, runFlush);
            this._leadMetricsFlushChain = chain.catch(() => null);
            return chain;
        },

        async saveDatasetRows(rows, meta, rawCount, stats = {}) {
            const executeSave = async () => {
                const deferFlush = !!(stats && stats.deferStorageFlush) && !this.stopped && !this.clearRequested;
                const local = this._streamCachedLocal ? this._streamCachedLocal : await getLocalAsync();
                if (!Array.isArray(local.collect)) local.collect = [];
                const skippedRecords = Array.isArray(stats.skippedDetails) ? stats.skippedDetails.slice() : [];
                if (Array.isArray(rows) && Array.isArray(rows.skippedDetails)) skippedRecords.push(...rows.skippedDetails);

                // One-time migration of older chrome.storage.local results.
                if (!local.resultStoreMigrated) {
                    try {
                        await ResultStore.migrateFromLocal(local.collect);
                        local.resultStoreMigrated = true;
                    } catch (migrationErr) {
                        warn('IndexedDB migration failed; keeping local preview fallback', migrationErr);
                    }
                }

                // v98.1 strict country enforcement. API calls stay single-pass, but
                // returned rows are guarded before storage to prevent cross-country leaks.
                let strictCountryDropped = 0;
                const strictCountry = String(meta && (meta.country || (meta.settings && meta.settings.country)) || '').trim().toLowerCase();
                if (strictCountry && Array.isArray(rows)) {
                    rows = rows.filter(row => {
                        const value = String(
                            row.country || row.country_name || row.countryCode ||
                            row.address_country || ''
                        ).trim().toLowerCase();
                        const keep = !value || value === strictCountry ||
                            value.includes(strictCountry) || strictCountry.includes(value);
                        if (!keep) {
                            strictCountryDropped += 1;
                            skippedRecords.push(makeSkippedRecord(row, meta, 'Filtered by strict country guard (' + strictCountry + '). Row country: ' + value, 'Filtered', 'Save:strict_country'));
                        }
                        return keep;
                    });
                }

                // Master Credit Gate: check remaining user credits before committing new leads
                const enrichmentUpdate = !!stats.enrichmentUpdate;
                let creditCappedStop = false;
                if (!enrichmentUpdate && Array.isArray(rows) && rows.length > 0 && typeof chromeStorageGetAsync === 'function') {
                    try {
                        const creditSnap = await chromeStorageGetAsync(['license', 'pocketleadsAccount']);
                        const accObj = (creditSnap && creditSnap.pocketleadsAccount) || (creditSnap && creditSnap.license) || null;
                        const availRaw = accObj ? accObj.availableCredit : null;
                        if (availRaw !== null && availRaw !== undefined && availRaw !== '' && String(availRaw).toLowerCase() !== 'unlimited') {
                            const availNum = Number(availRaw);
                            if (Number.isFinite(availNum)) {
                                const alreadyOffset = Math.max(0, parseInt(meta && meta.settings && meta.settings._unoffsetServerCredits, 10) || 0);
                                const storageRemaining = Math.max(0, availNum + alreadyOffset);
                                const effectiveRemaining = (typeof this._liveRunCreditRemaining === "number" && Number.isFinite(this._liveRunCreditRemaining))
                                    ? Math.min(storageRemaining, Math.max(0, this._liveRunCreditRemaining))
                                    : storageRemaining;
                                this._liveRunCreditRemaining = effectiveRemaining;
                                if (effectiveRemaining <= 0) {
                                    const exhaustedErr = new Error('Your scraping credits are exhausted. Buy credits to continue.');
                                    exhaustedErr.code = 'LICENSE_CREDIT_EXHAUSTED';
                                    throw exhaustedErr;
                                }
                                if (rows.length > effectiveRemaining) {
                                    rows = rows.slice(0, effectiveRemaining);
                                    creditCappedStop = true;
                                }
                            }
                        } else if (String(availRaw || "").toLowerCase() === "unlimited") {
                            this._liveRunCreditRemaining = null;
                        }
                    } catch (gateErr) {
                        if (gateErr && gateErr.code === 'LICENSE_CREDIT_EXHAUSTED') throw gateErr;
                    }
                }

                let storeResult = null;
                for (let attempt = 0; attempt < 3; attempt++) {
                    if (this.clearRequested || this.stopped) { const e = new Error('Result save paused. Resume to recover the request.'); e.code = 'RESULT_STORE_UNAVAILABLE'; throw e; }
                    try { storeResult = await ResultStore.upsertMany(rows || []); break; }
                    catch (storeErr) {
                        if (attempt === 2) {
                            const error = new Error('Results could not be saved to IndexedDB. Progress is paused; Resume will recover the existing request. ' + storeErr.message);
                            error.code = 'RESULT_STORE_UNAVAILABLE'; throw error;
                        }
                        await sleep(150 * (attempt + 1));
                    }
                }
                if (meta && meta.settings && meta.settings.managedRouting) {
                    const usableCount = (rows || []).filter(r => r && (r.company_name || r.name || r.title)).length;
                    this._managedUsable = (this._managedUsable || 0) + usableCount;
                    const attId = meta.settings.attemptId;
                    if (attId && this._managedUsableByAttempt) {
                        this._managedUsableByAttempt.set(attId, (this._managedUsableByAttempt.get(attId) || 0) + usableCount);
                    }
                }

                const added = Array.isArray(storeResult.addedRows) ? storeResult.addedRows : [];
                const addedKeys = new Set(added.map(row => rowFingerprint(row)));
                const updatedNow = Math.max(0, parseInt(storeResult.updated, 10) || 0);
                const duplicateRows = enrichmentUpdate ? [] : (rows || []).filter(row => !addedKeys.has(rowFingerprint(row)));
                duplicateRows.forEach(row => {
                    skippedRecords.push(makeSkippedRecord(row, meta, 'Duplicate already saved in IndexedDB result store.', 'Duplicate', 'Save:indexeddb_duplicate'));
                });

                if (this.clearRequested || this.stopped) { const e = new Error('Saved batch paused; canonical rows will hydrate on Resume.'); e.code = 'RESULT_STORE_UNAVAILABLE'; throw e; }

                if (enrichmentUpdate) {
                    const replacementKeys = new Set((rows || []).map(row => rowFingerprint(row)).filter(Boolean));
                    local.collect = this.dedupeCollect([
                        ...(local.collect || []).filter(row => !replacementKeys.has(rowFingerprint(row))),
                        ...(rows || [])
                    ]).slice(-RESULT_PREVIEW_LIMIT);
                } else {
                    local.collect = this.dedupeCollect([...(local.collect || []), ...added]).slice(-RESULT_PREVIEW_LIMIT);
                }
                this._authoritativeResultCount = Math.max(this._authoritativeResultCount || 0, parseInt(storeResult.total, 10) || 0);
                this._latestCollectPreview = local.collect.slice(-RESULT_PREVIEW_LIMIT);
                local.resultStoreCount = this._authoritativeResultCount;
                local.collectIsPreview = local.resultStoreCount > local.collect.length;
                const uniqueAddedNow = Math.max(0, parseInt(storeResult.added, 10) || 0);
                const savedNow = enrichmentUpdate
                    ? Math.max(0, uniqueAddedNow + updatedNow)
                    : uniqueAddedNow;
                if (skippedRecords.length && typeof this.recordSessionSkipped === 'function') {
                    this.recordSessionSkipped(skippedRecords);
                }
                const cachedQueue = local.apifyQueue || {};
                const latestLocal = deferFlush ? null : await getLocalAsync().catch(() => null);
                const latestQueue = (latestLocal && latestLocal.apifyQueue) || {};
                const queue = Object.assign(buildEmptyQueue(), latestQueue, cachedQueue);
                // Preserve live task progress counters and authoritative taskList across concurrent workers
                if (this.running && Array.isArray(this._activeTaskList)) {
                    local.taskList = this._activeTaskList.slice();
                } else if (latestLocal && Array.isArray(latestLocal.taskList)) {
                    local.taskList = latestLocal.taskList.slice();
                }
                if (latestQueue.currentTaskIndex) queue.currentTaskIndex = latestQueue.currentTaskIndex;
                if (latestQueue.totalTasks) queue.totalTasks = latestQueue.totalTasks;
                if (this._totalTaskCount > 0) queue.totalTasks = Math.max(queue.totalTasks || 0, this._totalTaskCount);
                if (latestQueue.completedTasks != null) queue.completedTasks = Math.max(cachedQueue.completedTasks || 0, latestQueue.completedTasks || 0);
                if (this._settledTaskCount != null) {
                    queue.completedTasks = Math.max(queue.completedTasks || 0, this._settledTaskCount);
                    queue.apiTasksSettled = Math.max(queue.apiTasksSettled || 0, this._settledTaskCount);
                }
                if (this._pincodeStatusesMap && Object.keys(this._pincodeStatusesMap).length) {
                    queue.pincodeStatuses = Object.assign({}, latestQueue.pincodeStatuses || {}, cachedQueue.pincodeStatuses || {}, this._pincodeStatusesMap);
                } else if (latestQueue.pincodeStatuses && cachedQueue.pincodeStatuses) {
                    queue.pincodeStatuses = Object.assign({}, latestQueue.pincodeStatuses, cachedQueue.pincodeStatuses);
                }
                queue.status = savedNow ? 'dataset_saved' : 'streaming_results';
                const filtered = (stats.filteredByCountry || 0) + strictCountryDropped;
                const filteredCat = stats.filteredByCategory || 0;
                const batchDupes = (stats.duplicateInBatch || 0) + duplicateRows.length;
                queue.statusMessage = `Saved ${savedNow} new row(s) for ${meta.queryForApi || meta.query}. Read ${rawCount} row(s)` +
                    (filtered ? `, filtered ${filtered} outside country` : '') +
                    (filteredCat ? `, category warning ${filteredCat}` : '') +
                    (batchDupes ? `, skipped ${batchDupes} duplicate` : '') +
                    (stats.safeModeRecovered ? ', safe mode recovered API rows' : '') + '.';
                queue.currentQuery = meta.queryForApi || meta.query;
                if (meta && meta.keyword) queue.currentKeyword = meta.keyword;
                if (meta && meta.location) queue.currentLocation = meta.location;
                if (meta && meta.totalTasks) queue.totalTasks = Math.max(queue.totalTasks || 0, meta.totalTasks);
                if (this._settledTaskCount != null) {
                    queue.completedTasks = this._settledTaskCount;
                    queue.apiTasksSettled = this._settledTaskCount;
                    queue.currentTaskIndex = Math.min(queue.totalTasks || this._totalTaskCount || 1, this._settledTaskCount + 1);
                } else if (meta && meta.taskIndex) {
                    queue.currentTaskIndex = Math.max(1, (queue.completedTasks || 0) + 1);
                }
                queue.totalApiResults = Math.max(queue.totalApiResults || 0, (cachedQueue.totalApiResults || 0) + (stats.rawBatchCount || 0), rawCount);
                queue.totalPlaceIds = Math.max(queue.totalPlaceIds || 0, queue.totalApiResults || 0);
                queue.scrapedCount = local.resultStoreCount;
                queue.failedCount = Math.max(cachedQueue.failedCount || 0, latestQueue.failedCount || 0);
                queue.filteredCount = Math.max(cachedQueue.filteredCount || 0, latestQueue.filteredCount || 0) + filtered + filteredCat;
                queue.duplicateSkippedCount = Math.max(cachedQueue.duplicateSkippedCount || 0, latestQueue.duplicateSkippedCount || 0) + duplicateRows.length;
                const allSessionSkipped = (Array.isArray(this._sessionSkippedRecords) && this._sessionSkippedRecords.length)
                    ? this._sessionSkippedRecords
                    : skippedRecords;
                if (allSessionSkipped.length || skippedRecords.length) {
                    queue.skipped = allSessionSkipped.slice(-300);
                }
                if (this._liveSpySnapshot) {
                    this._liveSpySnapshot.uniqueSaved = storeResult.total;
                    this._liveSpySnapshot.duplicateSkipped = queue.duplicateSkippedCount;
                    this._liveSpySnapshot.filteredSkipped = queue.filteredCount;
                    queue.liveSpySnapshot = this._liveSpySnapshot;
                }
                if (Array.isArray(this._liveSpyEvents) && this._liveSpyEvents.length) {
                    queue.liveSpyEvents = this._liveSpyEvents.slice(-80);
                }
                queue.apifyKeyRow = queue.apifyKeyRow || (meta && meta.apifyKeyRow) || 0;
                queue.processing = null;
                queue.currentProfileUrl = '';
                queue.completed = PlaceIdManager.deduplicate([...(queue.completed || []), ...(enrichmentUpdate ? (rows || []) : added).map(r => r.cid || r.place_id)]).slice(-500);
                queue.resultStoreCount = local.resultStoreCount;
                queue.lastUpdatedAt = nowIso();
                local.apifyQueue = queue;

                try {
                    const deltaRows = enrichmentUpdate
                        ? (Array.isArray(rows) ? rows : [])
                        : (storeResult.total > RESULT_PREVIEW_LIMIT ? added.slice(-25) : added);
                    if (deltaRows.length > 0 || storeResult.total <= RESULT_PREVIEW_LIMIT) {
                        this.scheduleProgressiveDashboardFeed(deltaRows, meta, queue);
                    }
                } catch (deltaErr) {}

                if (deferFlush && !creditCappedStop) {
                    this._streamCachedLocal = local;
                } else {
                    this._streamCachedLocal = null;
                    await setLocalAsync(local);
                }

                // Master Unique-Lead Credit & Metric Accounting across ALL providers
                let exhaustedAfterConsume = creditCappedStop;
                try {
                    const metricProvider = canonicalProviderKey(queue.provider || (meta && meta.provider) || (meta && meta.settings && meta.settings.provider) || '');
                    if (uniqueAddedNow > 0 && ['googlemaps', 'scrappa', 'serper', 'apify'].includes(metricProvider)) {
                        const alreadyDebitedByProxy = Math.min(uniqueAddedNow, Math.max(0, parseInt(meta && meta.settings && meta.settings._unoffsetServerCredits, 10) || 0));
                        if (meta && meta.settings && alreadyDebitedByProxy > 0) {
                            meta.settings._unoffsetServerCredits = Math.max(0, (meta.settings._unoffsetServerCredits || 0) - alreadyDebitedByProxy);
                        }
                        const netCreditToDeduct = Math.max(0, uniqueAddedNow - alreadyDebitedByProxy);
                        if (typeof this._liveRunCreditRemaining === "number" && Number.isFinite(this._liveRunCreditRemaining)) {
                            this._liveRunCreditRemaining = Math.max(0, this._liveRunCreditRemaining - netCreditToDeduct);
                            if (this._liveRunCreditRemaining <= 0) exhaustedAfterConsume = true;
                        }
                        const runMetricId = queue.jobRunId || queue.runEventId || queue.startedAt || 'run';
                        const addedSignature = (added || []).map(row => rowFingerprint(row)).filter(Boolean).sort().join('|');
                        const metricEventId = `v96|${runMetricId}|${metricProvider}|${hashString(addedSignature)}|${uniqueAddedNow}`;
                        if (netCreditToDeduct > 0) {
                            if (typeof PocketLeadsAccount !== 'undefined' && typeof PocketLeadsAccount.consume === 'function') {
                                const consumeRes = await PocketLeadsAccount.consume(netCreditToDeduct, {
                                    provider: metricProvider,
                                    runId: runMetricId,
                                    eventId: metricEventId
                                });
                                if (consumeRes && consumeRes.exhausted) exhaustedAfterConsume = true;
                            } else if (typeof chromeStorageGetAsync === 'function' && typeof chromeStorageSetAsync === 'function') {
                                const stored = await chromeStorageGetAsync(['license', 'pocketleadsAccount']);
                                const lic = stored && stored.license;
                                const acc = stored && stored.pocketleadsAccount;
                                const updates = {};
                                if (lic && typeof lic === 'object') {
                                    const nextLic = Object.assign({}, lic);
                                    if (Number.isFinite(Number(nextLic.availableCredit))) nextLic.availableCredit = Math.max(0, Number(nextLic.availableCredit) - netCreditToDeduct);
                                    if (Number.isFinite(Number(nextLic.googleMapsCredit)) && metricProvider === 'googlemaps') nextLic.googleMapsCredit = Math.max(0, Number(nextLic.googleMapsCredit) - netCreditToDeduct);
                                    if (Number.isFinite(Number(nextLic.structuredCredit)) && metricProvider !== 'googlemaps') nextLic.structuredCredit = Math.max(0, Number(nextLic.structuredCredit) - netCreditToDeduct);
                                    updates.license = nextLic;
                                }
                                if (acc && typeof acc === 'object') {
                                    const nextAcc = Object.assign({}, acc);
                                    if (Number.isFinite(Number(nextAcc.availableCredit))) nextAcc.availableCredit = Math.max(0, Number(nextAcc.availableCredit) - netCreditToDeduct);
                                    if (Number.isFinite(Number(nextAcc.googleMapsCredit)) && metricProvider === 'googlemaps') nextAcc.googleMapsCredit = Math.max(0, Number(nextAcc.googleMapsCredit) - netCreditToDeduct);
                                    if (Number.isFinite(Number(nextAcc.structuredCredit)) && metricProvider !== 'googlemaps') nextAcc.structuredCredit = Math.max(0, Number(nextAcc.structuredCredit) - netCreditToDeduct);
                                    updates.pocketleadsAccount = nextAcc;
                                }
                                if (Object.keys(updates).length) await chromeStorageSetAsync(updates);
                            }
                        }
                        const metricSettings = Object.assign({}, meta && meta.settings || {}, {
                            provider: metricProvider,
                            apiKeyRow: (meta && meta.settings && (meta.settings.apiKeyRow || meta.settings.apifyKeyRow)) || queue.apiKeyRow || queue.apifyKeyRow || (meta && meta.apifyKeyRow) || 0,
                            apifyKeyRow: (meta && meta.settings && (meta.settings.apifyKeyRow || meta.settings.apiKeyRow)) || queue.apifyKeyRow || queue.apiKeyRow || (meta && meta.apifyKeyRow) || 0
                        });
                        if (typeof this.queueLeadMetricsSync === 'function') {
                            this.queueLeadMetricsSync(metricSettings, uniqueAddedNow, netCreditToDeduct, metricEventId, runMetricId);
                        } else {
                            void ApiBackendManager.reportLeadMetrics(
                                metricSettings,
                                uniqueAddedNow,
                                metricEventId,
                                { deductUniqueCredit: netCreditToDeduct > 0, creditToDeduct: netCreditToDeduct, provider: metricProvider, runId: runMetricId }
                            ).catch(metricErr => warn('Unique lead metric report failed', metricErr));
                        }
                    }
                } catch (metricErr) { warn('Unique lead metric accounting skipped', metricErr); }

                if (exhaustedAfterConsume) {
                    if (this._streamCachedLocal) {
                        const pendingLocal = this._streamCachedLocal;
                        this._streamCachedLocal = null;
                        await setLocalAsync(pendingLocal);
                    }
                    if (typeof this.flushLeadMetricsSync === 'function') {
                        await this.flushLeadMetricsSync();
                    }
                    const exhaustedErr = new Error('Your scraping credits are exhausted. Buy credits to continue.');
                    exhaustedErr.code = 'LICENSE_CREDIT_EXHAUSTED';
                    throw exhaustedErr;
                }

                log('Saved dataset rows', { query: meta.queryForApi || meta.query, rawCount, added: savedNow, uniqueAddedNow, duplicates: duplicateRows.length, indexedDbTotal: local.resultStoreCount });
                return { savedNow, uniqueAddedNow, updatedNow, duplicateCount: duplicateRows.length, addedRows: added, total: local.resultStoreCount };
            };
            const priorSave = this._datasetSaveMutex || Promise.resolve();
            const currentSave = priorSave.then(executeSave, executeSave);
            this._datasetSaveMutex = currentSave.catch(() => null);
            return currentSave;
        },

        dedupeCollect(rows) {
            const seen = new Set();
            const out = [];
            (rows || []).forEach(row => {
                if (!row) return;
                const key = rowFingerprint(row);
                if (seen.has(key)) return;
                seen.add(key);
                out.push(row);
            });
            return out;
        },

        async complete() {
            // Drain pending queue/result writes and persisted tab IDs before terminal check.
            try { if (this._datasetSaveMutex) await this._datasetSaveMutex.catch(() => null); } catch (_) {}
            try { if (this._resultWriteChain) await this._resultWriteChain.catch(() => null); } catch (_) {}
            try { if (typeof this.flushLeadMetricsSync === 'function') await this.flushLeadMetricsSync(); } catch (_) {}
            try { if (typeof this.flushSessionSkipped === 'function') await this.flushSessionSkipped(); } catch (_) {}
            try { if (typeof this.flushQueueUpdates === 'function') await this.flushQueueUpdates(); } catch (_) {}
            try { await ProfileScraper.closeLegacyTabsOnly(); } catch (cleanupError) { warn('Legacy tab cleanup before completion failed', cleanupError); }
            const local = await getLocalAsync();
            const queue = Object.assign(buildEmptyQueue(), local.apifyQueue || {});
            const tasksRemain = Array.isArray(local.taskList) && local.taskList.length > 0;
            const domTotalCount = Math.max(0, parseInt(queue.domTotal, 10) || 0);
            const domProcessedCount = Math.max(0, parseInt(queue.domProcessed, 10) || 0);
            if (!tasksRemain && domTotalCount > 0 && domProcessedCount >= domTotalCount) {
                queue.placeIdQueue = [];
                queue.pendingPlaceIds = [];
                queue.domPending = 0;
                queue.domRunning = 0;
                queue.producerDone = true;
                queue.consumerDone = true;
                queue.apiTasksSettled = Math.max(parseInt(queue.apiTasksSettled, 10) || 0, parseInt(queue.apiTasksTotal || queue.totalTasks, 10) || 1);
                queue.completedTasks = Math.max(parseInt(queue.completedTasks, 10) || 0, parseInt(queue.totalTasks, 10) || 1);
            }
            const pendingJobs = Array.isArray(queue.placeIdQueue) && queue.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
            const apiIncomplete = (queue.apiTasksTotal || queue.totalTasks || 0) > (queue.apiTasksSettled || 0);
            const countersIncomplete = Math.max(0, parseInt(queue.domPending, 10) || 0) > 0 || Math.max(0, parseInt(queue.domRunning, 10) || 0) > 0;
            const googlePipeline = String(queue.provider || '').toLowerCase() === 'googlemaps' || (Array.isArray(queue.placeIdQueue) && queue.placeIdQueue.length > 0) || /^google_pipeline/i.test(String(queue.status || ''));
            const producerIncomplete = googlePipeline && !queue.producerDone;

            if (pendingJobs || tasksRemain || apiIncomplete || countersIncomplete || producerIncomplete) {
                local.status = false;
                if (!local._taskManager) local._taskManager = {};
                local._taskManager.isWorking = false;
                local._taskManager.activeTask = 'openMap';
                queue.status = 'paused_recoverable';
                queue.statusMessage = `Not marked complete: API remaining ${Math.max(0, (queue.apiTasksTotal || queue.totalTasks || 0) - (queue.apiTasksSettled || 0))}, profile pending ${Math.max(queue.domPending || 0, pendingJobs ? 1 : 0)}. Click Resume.`;
                queue.resumeAvailable = true;
                queue.finishedAt = nowIso();
                queue.lastUpdatedAt = nowIso();
                local.apifyQueue = queue;
                await setLocalAsync(local);
                await ProfileScraper.closeAllTabs();
                return false;
            }

            local.status = false;
            if (!local._taskManager) local._taskManager = {};
            local._taskManager.isWorking = false;
            local._taskManager.activeTask = null;
            local.activeQuery = '';
            const completedAt = nowIso();
            const hasErrors = !!(queue.completedWithErrors || (queue.failedCount || 0) || (queue.domFailed || 0));
            const hasSkipped = !!((queue.filteredCount || 0) || (queue.duplicateSkippedCount || 0) || (queue.domSkipped || 0));
            queue.status = (hasErrors || hasSkipped) ? 'completed_with_errors' : 'completed';
            queue.statusMessage = (queue.status === 'completed_with_errors')
                ? `Completed with errors/skips. Saved ${queue.scrapedCount || queue.resultStoreCount || 0}, failed ${queue.failedCount || queue.domFailed || 0}, skipped ${queue.domSkipped || queue.filteredCount || queue.duplicateSkippedCount || 0}.`
                : `Completed. Saved ${queue.scrapedCount || queue.resultStoreCount || 0} result row(s).`;
            queue.totalTasks = Math.max(0, parseInt(queue.totalTasks || local.apifyTaskTotal || 0, 10) || 0);
            queue.completedTasks = queue.totalTasks;
            queue.apiTasksDone = Math.max(queue.apiTasksDone || 0, Math.max(0, (queue.totalTasks || 0) - (queue.apiTasksFailed || 0)));
            queue.apiTasksSettled = Math.max(queue.apiTasksSettled || 0, queue.totalTasks || 0);
            queue.domRunning = 0;
            queue.domPending = 0;
            queue.completedWithErrors = queue.status === 'completed_with_errors';
            queue.resumeAvailable = false;
            queue.producerDone = true;
            queue.consumerDone = true;
            local.taskList = [];
            queue.processing = null;
            queue.currentProfileUrl = '';
            queue.pendingPlaceIds = [];
            queue.managedTabIds = [];
            queue.finishedAt = completedAt;
            queue.elapsedMs = elapsedMsFrom(queue.startedAt || local.scrapeStartedAt, completedAt);
            queue.lastUpdatedAt = completedAt;
            local.scrapeFinishedAt = completedAt;
            local.scrapeElapsedMs = queue.elapsedMs;
            const eventId = (this._runEventId || queue.runEventId || makeRunEventId('scrape')) + ':complete';
            queue.runEventId = this._runEventId || queue.runEventId || '';
            queue.lastTerminalEventId = eventId;
            local.apifyQueue = queue;
            await setLocalAsync(local);
            await ProfileScraper.closeAllTabs();
            if (this._terminalEventSent !== eventId) {
                this._terminalEventSent = eventId;
                showSingleSystemNotification('pocketleads_scrape_status', 'Scraping Complete', queue.statusMessage, eventId);
                try { $box.send('scraping_complete', { eventId, message: queue.statusMessage, completedWithErrors: queue.completedWithErrors }); } catch (e) {}
                try { if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') chrome.runtime.sendMessage({ action: 'PL_SCRAPING_COMPLETE', event: 'scraping_complete', data: { eventId, message: queue.statusMessage, completedWithErrors: queue.completedWithErrors } }, () => { try { void chrome.runtime.lastError; } catch (_) {} }); } catch (e) {}
            }
            return true;
        },

        async stop() {
            if (this._stopPromise) return this._stopPromise;
            const performStop = async () => {
                this.stopped = true;
                this.cancelProgressiveFeed();
                this.clearRequested = false;
                try { if (typeof this.flushLeadMetricsSync === 'function') await this.flushLeadMetricsSync(); } catch (_) {}
            try { if (typeof this.flushSessionSkipped === 'function') await this.flushSessionSkipped(); } catch (_) {}
                // Clean old-release tabs before stop clears managedTabIds.
                try { await ProfileScraper.closeLegacyTabsOnly(); } catch (cleanupError) { warn('Legacy tab cleanup before stop failed', cleanupError); }
                const local = await getLocalAsync();
                local.status = false;
                if (!local._taskManager) local._taskManager = {};
                local._taskManager.isWorking = false;
                local._taskManager.activeTask = 'openMap';
                const queue = Object.assign(buildEmptyQueue(), local.apifyQueue || {});
                const stoppedAt = nowIso();
                // Convert in-flight jobs to retryable checkpoints so Resume starts
                // from the last unfinished Place ID instead of restarting the query.
                if (Array.isArray(queue.placeIdQueue)) {
                    queue.placeIdQueue = queue.placeIdQueue.map(item => {
                        if (String(item && item.status || '').toLowerCase() !== 'dom_running') return item;
                        return Object.assign({}, item, {
                            status: 'retry_pending',
                            reason: 'Stopped during DOM extraction; queued for Resume.',
                            lastUpdatedAt: stoppedAt
                        });
                    });
                }
                const pending = Array.isArray(queue.placeIdQueue)
                    ? queue.placeIdQueue.filter(item => /^(api_returned|pending|retry_pending|dom_failed)$/i.test(String(item && item.status || ''))).length
                    : Math.max(0, parseInt(queue.domPending, 10) || 0);
                queue.status = 'stopped';
                queue.statusMessage = `Scraping stopped safely. Resume available from ${pending} pending profile(s) and ${Array.isArray(local.taskList) ? local.taskList.length : 0} pending search(es).`;
                queue.resumeAvailable = pending > 0 || (Array.isArray(local.taskList) && local.taskList.length > 0);
                queue.processing = null;
                queue.currentProfileUrl = '';
                queue.domRunning = 0;
                queue.domPending = pending;
                queue.managedTabIds = [];
                queue.finishedAt = stoppedAt;
                queue.elapsedMs = elapsedMsFrom(queue.startedAt || local.scrapeStartedAt, stoppedAt);
                queue.lastUpdatedAt = stoppedAt;
                local.scrapeFinishedAt = stoppedAt;
                local.scrapeElapsedMs = queue.elapsedMs;
                local.apifyQueue = queue;
                await setLocalAsync(local);
                await ProfileScraper.closeAllTabs();
                try { TaskManager.randInterval.stop(); } catch (e) {}
                const stopEventId = (this._runEventId || queue.runEventId || makeRunEventId('scrape')) + ':stopped:' + stoppedAt;
                try { $box.send('scraping_stopped', { eventId: stopEventId, message: queue.statusMessage, resumable: queue.resumeAvailable }); } catch (e) {}
                return true;
            };
            this._stopPromise = performStop();
            return this._stopPromise;
        }
    };

    async function purgeLegacyProviderSecretsOnce() {
        try {
            const local = await getLocalAsync();
            if (local && local.secureProxyStorageMigratedV82) return;
            if (local && local.apifySettings && typeof local.apifySettings === 'object') {
                local.apifySettings.apiToken = '';
                local.apifySettings.actorId = '';
                local.apifySettings.sourceId = '';
                local.apifySettings.secureProxy = true;
            }
            if (local) {
                local.secureProxyStorageMigratedV82 = true;
                await setLocalAsync(local);
            }
            const area = getBackendCacheStorageArea();
            if (area && typeof area.remove === 'function') {
                await new Promise(resolve => area.remove('pocketleadsBackendCache', () => resolve(true)));
            }
        } catch (err) {
            warn('Legacy provider-secret cleanup failed', err);
        }
    }
    purgeLegacyProviderSecretsOnce();

    // One-time cleanup of v90 customer-visible Place-ID placeholders.
    (async function purgeV90PendingRows(){
        try {
            const removed = await ResultStore.purgePendingProfiles();
            if (removed) {
                const local = await getLocalAsync();
                if (Array.isArray(local.collect)) {
                    local.collect = local.collect.filter(row => !(row && (row._profile_pending === true || /google_maps_place_id_pending/i.test(String(row._source_detail || '')))));
                }
                local.resultStoreCount = await ResultStore.count();
                await setLocalAsync(local);
            }
        } catch (err) { warn('v90 pending-row cleanup failed', err); }
    })();

    try {
        self.PocketLeadsApifyFlow = { version: '10.11.98', SettingsManager, ApiBackendManager, ApifyClient, ScrappaClient, SerperClient, GoogleMapsPlacesClient, PlaceIdManager, DatasetNormalizer, ResultStore, JobStore, HistoryStore, TaskController: DailyController, DailyController, ProfileScraper, ensureQueryHasCountry, normalizeQueryTextForApi };
    } catch (e) {}

    TaskManager.container.start = () => DailyController.start();
    TaskManager.container.openMap = () => DailyController.start();
    TaskManager.container.completed = () => DailyController.complete();
    TaskManager.container.stop = () => DailyController.stop();
})();

}
