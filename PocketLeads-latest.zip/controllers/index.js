
// v31 Security Guard: Block DevTools / View-Source shortcuts & sanitize untrusted scraped strings
(function installPocketLeadsSecurityGuard() {
    try {
        if (typeof window !== 'undefined' && !window.__plSecurityShortcutsBound) {
            window.__plSecurityShortcutsBound = true;
            window.addEventListener('keydown', function(e) {
                const key = String(e.key || '').toUpperCase();
                if (e.keyCode === 123 || key === 'F12' ||
                    ((e.ctrlKey || e.metaKey) && e.shiftKey && (key === 'I' || key === 'J' || key === 'C')) ||
                    ((e.ctrlKey || e.metaKey) && key === 'U')) {
                    e.preventDefault();
                    e.stopPropagation();
                    return false;
                }
            }, true);
        }
    } catch (_) {}
})();

function sanitizeScrapedFieldText(val) {
    if (val == null || typeof val !== 'string') return val;
    if (!/[<>]|javascript:|data:text\/html|on(?:error|load|click|mouseover)=/i.test(val)) return val;
    return val
        .replace(/<\s*\/?\s*(?:script|iframe|object|embed|svg|math|style|link|meta|base|form)[^>]*>/gi, '')
        .replace(/\bon[a-z]{2,20}\s*=\s*["'][^"']*["']/gi, '')
        .replace(/\b(?:javascript|vbscript|data:text\/html)\s*:/gi, '');
}

var ngApp = angular.module("popupApp",[]).config(function($sceProvider) {
    $sceProvider.enabled(false);
});

['ngTouchstart', 'ngTouchmove', 'ngTouchend', 'ngTouchcancel', 'ngContextmenu'].forEach(function(dirName) {
    var evtName = dirName.slice(2).toLowerCase();
    ngApp.directive(dirName, ['$parse', function($parse) {
        return {
            restrict: 'A',
            compile: function($element, attr) {
                var fn = $parse(attr[dirName]);
                return function(scope, element) {
                    element[0].addEventListener(evtName, function(event) {
                        scope.$evalAsync(function() {
                            fn(scope, { $event: event });
                        });
                    }, { passive: false });
                };
            }
        };
    }]);
});

/*
 * Some third‑party libraries (or legacy parts of this codebase) invoke
 * chrome.runtime.sendMessage without a callback.  In Chrome Manifest V3
 * this causes sendMessage to return a Promise which will reject with
 * "Could not establish connection. Receiving end does not exist." when
 * there is no listener.  To prevent unhandled promise rejections from
 * surfacing in the console, we override sendMessage to always use a
 * dummy callback when none is provided.  This wrapper forwards the
 * original arguments and suppresses the returned promise when no
 * callback is supplied.
 */
try {
    if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
        const _origSendMessage = chrome.runtime.sendMessage.bind(chrome.runtime);
        chrome.runtime.sendMessage = function(message, arg2, arg3) {
            // Detect invocation patterns:
            //   sendMessage(message)
            //   sendMessage(message, options)
            //   sendMessage(message, callback)
            //   sendMessage(message, options, callback)
            // Chrome docs: the second parameter is optional options or callback.
            // The third parameter is callback if second is options.
            let callback;
            if (typeof arg2 === 'function') {
                callback = arg2;
            } else if (typeof arg3 === 'function') {
                callback = arg3;
            }
            // Provide a wrapper callback that always reads chrome.runtime.lastError
            // so that runtime errors are marked as handled.  Without reading
            // lastError, Chrome will log "Unchecked runtime.lastError" when
            // there is no receiving end.  If the caller did not provide
            // a callback, we insert a dummy callback that reads lastError.
            const wrappedCallback = function(...cbArgs) {
                try {
                    // Access lastError to mark it as handled
                    void chrome.runtime.lastError;
                } catch (e) {
                    // ignore
                }
                if (typeof callback === 'function') {
                    try {
                        callback.apply(this, cbArgs);
                    } catch (cbErr) {
                        // Avoid letting callback errors propagate
                        console.warn('Error in runtime.sendMessage callback', cbErr);
                    }
                }
            };
            // If no callback provided, pass our dummy wrapper as the second arg
            if (!callback) {
                return _origSendMessage(message, wrappedCallback);
            }
            // Determine whether arg2 is options or callback and invoke accordingly
            if (typeof arg2 === 'function') {
                // Only message and callback provided
                return _origSendMessage(message, wrappedCallback);
            }
            // message, options and callback provided
            return _origSendMessage(message, arg2, wrappedCallback);
        };
    }
} catch (sendWrapErr) {
    console.warn('Failed to wrap chrome.runtime.sendMessage', sendWrapErr);
}

/*
 * Globally suppress unhandled promise rejections originating from Chrome
 * messaging when there is no receiving end.  Without a listener,
 * chrome.runtime.sendMessage() returns a promise that rejects with
 * "Could not establish connection. Receiving end does not exist.".
 * This handler prevents those rejections from surfacing as uncaught
 * errors in the console.  Other unhandled rejection reasons are
 * untouched so legitimate errors still appear.
 */
window.addEventListener('unhandledrejection', event => {
    try {
        const reason = event && event.reason;
        const msg = reason && (reason.message || reason.toString());
        if (msg && msg.includes('Could not establish connection')) {
            // Prevent default logging of this rejection
            // We intentionally do not emit our own warning here to avoid cluttering
            // the console with benign messaging errors.  Prior versions of this
            // extension logged a suppressed warning, but that still annoyed
            // users.  Simply prevent the default unhandled rejection and
            // silently ignore the message.
            event.preventDefault();
            return;
        }
    } catch (err) {
        // Silently ignore any issues in the rejection handler itself
    }
});

// v89: if the dashboard was opened directly (bookmark/reload rather than the
// toolbar icon), still warm licence/provider routing in the background.
try {
    const warmDashboardBackend = function(reason) {
        try { chrome.runtime.sendMessage({ action: 'pocketleads_warm_backend', reason: reason || 'dashboard_load', force: false }, function(){ void chrome.runtime.lastError; }); } catch (e) {}
    };
    setTimeout(function(){ warmDashboardBackend('dashboard_load'); }, 0);
    // Keep routeVerifiedAt fresh (<30s) while dashboard is open so clicking Start
    // never blocks on a synchronous preflight round-trip to Apps Script.
    setInterval(function(){
        try { if (typeof document === 'undefined' || !document.hidden) warmDashboardBackend('dashboard_keepwarm'); } catch (e) {}
    }, 120000);
} catch (e) {}

window.addEventListener('error', event => {
    try {
        const msg = event && event.message ? String(event.message) : '';
        const file = event && event.filename ? String(event.filename) : '';
        if (/Cannot read properties of null \(reading ['\"]data['\"]\)/i.test(msg) && /dx\.all\.js/i.test(file)) {
            event.preventDefault();
        }
    } catch (err) {}
});


// Include a new 'status' column to indicate whether a business is temporarily closed.
// Include WhatsApp status column to show availability of WhatsApp for each phone number.
var baseColumnList = [
    "keyword",
    "location",
    "company_name",
    "photo_url",
    "photo_url_large",
    "photo_urls",
    "website",
    "phone_number",
    // New column to display whether the scraped phone is available on WhatsApp.  Values will be
    // populated via the WhatsApp number check feature.  See $scope.whatsappCheck for logic.
    "whatsapp_status",
    // Only a single email column is needed.  Additional emails will be
    // concatenated and stored in email_1, separated by commas.
    "email_1",
    "facebook",
    "instagram",
    "linkedin",
    "twitter",
    "youtube",
    "address",
    "city",
    "state",
    "pincode",
    // Rename rating_count to total_reviews for clarity
    "total_reviews",
    "review",
    "category",
    "categories",
    "latitude",
    "longitude",
    "place_id",
    "cid",
    // Insert a new column for the map link.  This column will hold a Google
    // Maps URL constructed from the listing's CID.  The order here dictates
    // where the column appears in the data grid and the exported CSV.
    "map_link",
    "status", // New column for the business status (e.g., temporarily closed)
    "source",
    "scraped_at"
];

var columnList = baseColumnList.slice();

const DASHBOARD_COUNTRY_DIAL_CODES = {
    'afghanistan': '93', 'albania': '355', 'algeria': '213', 'american samoa': '1', 'andorra': '376',
    'angola': '244', 'anguilla': '1', 'antigua and barbuda': '1', 'argentina': '54', 'armenia': '374',
    'aruba': '297', 'australia': '61', 'au': '61', 'austria': '43', 'azerbaijan': '994', 'bahamas': '1',
    'bahrain': '973', 'bh': '973', 'bangladesh': '880', 'bd': '880', 'barbados': '1', 'belarus': '375', 'belgium': '32', 'be': '32',
    'belize': '501', 'benin': '229', 'bermuda': '1', 'bhutan': '975', 'bt': '975', 'bolivia': '591',
    'bosnia and herzegovina': '387', 'botswana': '267', 'brazil': '55', 'br': '55', 'brunei darussalam': '673',
    'bulgaria': '359', 'burkina faso': '226', 'burundi': '257', 'cabo verde': '238', 'cambodia': '855',
    'cameroon': '237', 'canada': '1', 'ca': '1', 'cayman islands': '1', 'central african republic': '236',
    'chad': '235', 'chile': '56', 'china': '86', 'cn': '86', 'colombia': '57', 'comoros': '269', 'congo': '242',
    'costa rica': '506', 'croatia': '385', 'cuba': '53', 'cyprus': '357', 'czechia': '420',
    'denmark': '45', 'djibouti': '253', 'dominica': '1', 'dominican republic': '1', 'ecuador': '593',
    'egypt': '20', 'eg': '20', 'el salvador': '503', 'equatorial guinea': '240', 'eritrea': '291', 'estonia': '372',
    'eswatini': '268', 'ethiopia': '251', 'fiji': '679', 'finland': '358', 'france': '33', 'fr': '33',
    'gabon': '241', 'gambia': '220', 'georgia': '995', 'germany': '49', 'de': '49', 'ghana': '233',
    'gibraltar': '350', 'greece': '30', 'greenland': '299', 'grenada': '1', 'guam': '1',
    'guatemala': '502', 'guinea': '224', 'guyana': '592', 'haiti': '509', 'honduras': '504',
    'hong kong': '852', 'hk': '852', 'hungary': '36', 'iceland': '354', 'india': '91', 'in': '91', 'bharat': '91',
    'indonesia': '62', 'id': '62', 'iran, islamic republic of': '98', 'iraq': '964', 'ireland': '353', 'ie': '353',
    'israel': '972', 'italy': '39', 'it': '39', 'jamaica': '1', 'japan': '81', 'jp': '81', 'jordan': '962',
    'kazakhstan': '7', 'kenya': '254', 'ke': '254', 'korea, republic of': '82', 'south korea': '82', 'kr': '82',
    'kuwait': '965', 'kw': '965', 'kyrgyzstan': '996', 'latvia': '371', 'lebanon': '961', 'lesotho': '266',
    'liberia': '231', 'libya': '218', 'liechtenstein': '423', 'lithuania': '370', 'luxembourg': '352',
    'macao': '853', 'madagascar': '261', 'malawi': '265', 'malaysia': '60', 'my': '60', 'maldives': '960', 'mv': '960',
    'mali': '223', 'malta': '356', 'mauritius': '230', 'mexico': '52', 'mx': '52', 'monaco': '377',
    'mongolia': '976', 'montenegro': '382', 'morocco': '212', 'mozambique': '258', 'myanmar': '95',
    'namibia': '264', 'nepal': '977', 'np': '977', 'netherlands': '31', 'nl': '31', 'new zealand': '64', 'nz': '64',
    'nicaragua': '505', 'niger': '227', 'nigeria': '234', 'ng': '234', 'north macedonia': '389', 'norway': '47',
    'oman': '968', 'om': '968', 'pakistan': '92', 'pk': '92', 'panama': '507', 'papua new guinea': '675',
    'paraguay': '595', 'peru': '51', 'philippines': '63', 'ph': '63', 'poland': '48', 'portugal': '351',
    'puerto rico': '1', 'qatar': '974', 'qa': '974', 'romania': '40', 'russian federation': '7', 'russia': '7', 'ru': '7',
    'rwanda': '250', 'saudi arabia': '966', 'sa': '966', 'senegal': '221', 'serbia': '381', 'seychelles': '248',
    'sierra leone': '232', 'singapore': '65', 'sg': '65', 'slovakia': '421', 'slovenia': '386',
    'south africa': '27', 'za': '27', 'spain': '34', 'es': '34', 'sri lanka': '94', 'lk': '94', 'sudan': '249',
    'sweden': '46', 'switzerland': '41', 'ch': '41', 'taiwan, province of china': '886', 'tajikistan': '992',
    'thailand': '66', 'th': '66', 'togo': '228', 'trinidad and tobago': '1', 'tunisia': '216',
    'turkmenistan': '993', 'türkiye': '90', 'turkey': '90', 'tr': '90', 'uganda': '256', 'ukraine': '380',
    'united arab emirates': '971', 'uae': '971', 'ae': '971', 'dubai': '971',
    'united kingdom': '44', 'uk': '44', 'gb': '44', 'great britain': '44', 'england': '44', 'scotland': '44', 'wales': '44',
    'united states': '1', 'usa': '1', 'us': '1', 'united states of america': '1', 'america': '1',
    'uruguay': '598', 'uzbekistan': '998', 'viet nam': '84', 'vietnam': '84', 'yemen': '967', 'zambia': '260', 'zimbabwe': '263'
};

function detectRowAddressCountryPrefix(row) {
    if (!row || typeof row !== 'object') return '';
    const explicit = [row.country_code, row.countryCode, row.country, row.address_country, row.addressCountry]
        .map(v => String(v || '').trim().toLowerCase())
        .find(v => v && DASHBOARD_COUNTRY_DIAL_CODES[v]);
    if (explicit) return DASHBOARD_COUNTRY_DIAL_CODES[explicit];
    const addr = [row.address, row.full_address, row.formattedAddress, row.location, row.city, row.state, row.pincode]
        .filter(Boolean).join(' ');
    if (!addr) return '';
    if (/\b[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b/i.test(addr) || /\b(united kingdom|\buk\b|england|scotland|wales|london|manchester|birmingham|glasgow|edinburgh|liverpool|leeds|bristol)\b/i.test(addr)) return '44';
    if (/\b(united arab emirates|\buae\b|dubai|abu dhabi|sharjah)\b/i.test(addr)) return '971';
    if (/\b(united states|\busa\b|new york|california|texas|florida|chicago|los angeles)\b/i.test(addr)) return '1';
    if (/\b(canada|toronto|vancouver|montreal|ontario|calgary)\b/i.test(addr)) return '1';
    if (/\b(australia|sydney|melbourne|brisbane|perth)\b/i.test(addr)) return '61';
    if (/\b[1-9]\d{5}\b/.test(addr) || /\b(india|bharat|kolkata|mumbai|delhi|bengaluru|bangalore|chennai|hyderabad|pune|ahmedabad)\b/i.test(addr)) return '91';
    return '';
}

function dashboardCountryDialPrefix(row) {
    const fromRow = detectRowAddressCountryPrefix(row);
    if (fromRow) return fromRow;
    try {
        const activeCountry = String((typeof window !== 'undefined' && window.localCountry) || '').trim().toLowerCase();
        if (activeCountry && DASHBOARD_COUNTRY_DIAL_CODES[activeCountry]) {
            return DASHBOARD_COUNTRY_DIAL_CODES[activeCountry];
        }
    } catch (e) {}
    return '91';
}

function normalizeDashboardPhone(value, row) {
    const text = String(value == null ? '' : value).trim();
    if (!text) return '';
    const cleaned = text.replace(/^\s*(?:phone|mobile|tel|telephone)\s*[:：-]\s*/i, '').trim();
    const parts = cleaned.split(/(?:\s*(?:,|;|\||\/|\n|\r)\s*)+/).filter(Boolean);
    const prefix = dashboardCountryDialPrefix(row);
    let best = '';
    for (const part of parts.length ? parts : [cleaned]) {
        let digits = String(part || '').replace(/\D/g, '').replace(/^0+/, '');
        if (!digits) continue;
        if (digits.length >= 7 && digits.length <= 15) { best = digits; break; }
    }
    if (!best) best = cleaned.replace(/\s+/g, ' ').trim();
    if (/^\+/.test(cleaned) && /^\d{8,15}$/.test(best)) {
        // Repair rows where +91 was previously prepended to a non-Indian 10-digit local number (e.g. UK 07301531111 -> +917301531111)
        if (prefix !== '91' && /^91\d{9,10}$/.test(best)) {
            return '+' + prefix + best.slice(2);
        }
        return '+' + best;
    }
    if (prefix === '91') {
        if (/^91\d{10}$/.test(best)) return '+' + best;
        if (/^\d{10}$/.test(best)) return '+91' + best;
    } else if (prefix) {
        if (best.startsWith(prefix) && best.length >= prefix.length + 7 && best.length <= 15) return '+' + best;
        if (/^91\d{9,10}$/.test(best)) return '+' + prefix + best.slice(2);
        if (/^\d{7,11}$/.test(best)) return '+' + prefix + best;
    }
    if (/^\d{8,15}$/.test(best)) return '+' + best;
    return best;
}

function rowPhoneValue(row) {
    if (!row || typeof row !== 'object') return '';
    const candidates = [
        row.phone_number, row.phoneNumber, row.phone, row.telephone, row.mobile,
        row.contactPhone, row.contact_number, row.businessPhone, row.primaryPhone,
        row.formattedPhone, row.formatted_phone_number, row.internationalPhoneNumber,
        row.international_phone_number, row.phoneNumberUnformatted, row.phoneUnformatted,
        row.phone_number_unformatted
    ];
    for (const value of candidates) {
        const formatted = normalizeDashboardPhone(value, row);
        if (formatted) return formatted;
    }
    return '';
}

function dashboardFirstValue(row, keys) {
    for (const key of keys || []) {
        const value = row && row[key];
        if (value !== null && typeof value !== 'undefined' && String(value).trim()) return String(value).trim();
    }
    return '';
}

function resolveLeadProfileMapsUrl(row) {
    if (!row || typeof row !== 'object') return '';
    let rawLink = dashboardFirstValue(row, ['map_link', 'googleMapsUrl', 'googleMapsURL', 'mapsUrl', 'mapsURL', 'googleMapsLink', 'link', 'url']);
    const hyperMatch = rawLink.match(/^=HYPERLINK\(\s*"([^"]+)"/i);
    if (hyperMatch && hyperMatch[1]) rawLink = hyperMatch[1].trim();

    let placeId = dashboardFirstValue(row, ['place_id', 'placeId', 'placeID', 'googlePlaceId', 'googleMapsPlaceId', 'google_maps_place_id']);
    if (!placeId && rawLink) {
        const m = rawLink.match(/(?:q=place_id(?::|%3A)|query_place_id=|place_id=)([^&#"'\s]+)/i);
        if (m && m[1]) {
            try { placeId = decodeURIComponent(m[1]).trim(); } catch (e) { placeId = m[1].trim(); }
        }
    }
    const validChij = /^ChIJ[A-Za-z0-9_-]{10,}$/.test(placeId) ? placeId : '';
    const cidRaw = String(row.cid || '').trim();
    const numericCid = /^\d{10,22}$/.test(cidRaw) ? cidRaw : '';
    const name = dashboardFirstValue(row, ['company_name', 'name', 'title', 'businessName', 'business_name', 'placeName', 'displayName']);
    const address = dashboardFirstValue(row, ['address', 'formattedAddress', 'formatted_address', 'fullAddress', 'full_address', 'streetAddress', 'vicinity', 'location', 'city']);
    const queryParts = [name, address].filter(Boolean).join(', ').trim();

    if (rawLink && /^https?:\/\/(?:www\.|maps\.)?google\.[^/]+\/maps\/place\/[^?]/i.test(rawLink)) {
        return rawLink;
    }
    if (queryParts && validChij) {
        return 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(queryParts) + '&query_place_id=' + encodeURIComponent(validChij);
    }
    if (numericCid) {
        return 'https://www.google.com/maps?cid=' + encodeURIComponent(numericCid);
    }
    if (queryParts) {
        return 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(queryParts);
    }
    if (validChij) {
        return 'https://www.google.com/maps/place/?q=place_id:' + encodeURIComponent(validChij);
    }
    return rawLink;
}

function normalizeDashboardEmails(value) {
    const text = String(value == null ? '' : value)
        .replace(/&commat;|&#64;|&#0*64;|&#x0*40;/gi, '@')
        .replace(/&period;|&#46;|&#0*46;|&#x0*2e;/gi, '.')
        .replace(/\s*(?:\[|\(|\{)\s*at\s*(?:\]|\)|\})\s*/gi, '@')
        .replace(/\s+at\s+/gi, '@')
        .replace(/\s*(?:\[|\(|\{)\s*dot\s*(?:\]|\)|\})\s*/gi, '.')
        .replace(/\s+dot\s+/gi, '.');
    const emails = [];
    const re = /[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+/gi;
    let match;
    while ((match = re.exec(text)) !== null) {
        const email = match[0].toLowerCase().replace(/[.,;:]+$/, '');
        if (email && !emails.includes(email) && email.length <= 254) emails.push(email);
    }
    return emails.join(', ');
}

function canonicalDashboardSource(value) {
    const text = String(value || '').trim();
    const lower = text.toLowerCase().replace(/[\s_-]+/g, '');
    if (!lower) return '';
    if (lower.includes('scrappa')) return 'Scrappa';
    if (lower.includes('serper')) return 'Serper';
    if (lower.includes('apify')) return 'Apify';
    if (lower.includes('googlemaps') || lower.includes('googleplace') || lower.includes('placeidprofile')) return 'Google Maps';
    return text;
}

function repairLegacyProviderSources(rows, local) {
    const list = Array.isArray(rows) ? rows : [];
    const queue = local && local.apifyQueue ? local.apifyQueue : {};
    const provider = String(queue.provider || '').trim().toLowerCase();
    const startedMs = Date.parse(queue.startedAt || (local && local.scrapeStartedAt) || '');
    const changed = [];
    list.forEach(row => {
        if (!row || typeof row !== 'object') return;
        const before = String(row.source || '');
        const canonical = canonicalDashboardSource(before);
        if (canonical && canonical !== before && canonical !== 'apify_dataset') row.source = canonical;
        const scrapedMs = Date.parse(row.scraped_at || row.createdAt || '');
        const isCurrentRun = Number.isFinite(startedMs) && Number.isFinite(scrapedMs) && scrapedMs >= (startedMs - 60000);
        if (provider === 'serper' && /^(apify|apify_dataset)$/i.test(before) && isCurrentRun) {
            row.source = 'Serper';
            row._provider = 'serper';
            row._source_detail = row._source_detail || 'legacy_v80_source_repair';
        }
        if (row.source !== before) changed.push(row);
    });
    return changed;
}

function isCorruptedDashboardPhotoUrl(url) {
    const s = String(url || '').trim();
    if (!s) return false;
    if (/\/(?:gps-cs-s|gps-proxy)\//i.test(s) && /=[ws](?:800|1200|1600)(?:-h(?:800|1200|1600))?/i.test(s)) return true;
    if (/streetviewpixels-pa\.googleapis\.com/i.test(s) && /[?&]w=(?:800|1200|1600)&h=(?:800|1200|1600)/i.test(s)) return true;
    return false;
}

function canonicalDashboardPhotoKey(url) {
    const s = String(url || '').trim();
    if (!/^https?:\/\//i.test(s)) return '';
    return s
        .replace(/=[ws]\d+[^?&]*$/i, '')
        .replace(/([?&])(?:w|h|s)=\d+/gi, '$1')
        .replace(/[?&]+$/, '')
        .toLowerCase();
}

function upgradeDashboardPhotoUrl(rawUrl, fallbackSmallUrl) {
    let s = String(rawUrl || '').trim();
    const small = (typeof fallbackSmallUrl === 'string') ? fallbackSmallUrl.trim() : '';
    if (isCorruptedDashboardPhotoUrl(s)) {
        s = (!isCorruptedDashboardPhotoUrl(small) && /^https?:\/\//i.test(small)) ? small : '';
    }
    if (!/^https?:\/\//i.test(s)) return '';
    if (/maps\.gstatic\.com\/.*(?:favicon|tactile|cleardot|pin_)/i.test(s)) return '';
    if (/googleusercontent\.com\/(?:a|a-)\//i.test(s)) return '';
    try {
        if (/streetviewpixels-pa\.googleapis\.com/i.test(s)) {
            s = s.replace(/=[ws]\d+[^?&]*$/i, '');
            if (/^https?:\/\//i.test(small) && !isCorruptedDashboardPhotoUrl(small) && /streetviewpixels-pa\.googleapis\.com/i.test(small)) {
                return small.replace(/=[ws]\d+[^?&]*$/i, '');
            }
            return s;
        }
        if (/googleusercontent\.com|ggpht\.com/i.test(s)) {
            s = s.replace(/(=[ws]\d+[^=]*)(=[ws]\d+[^=]*)$/i, '$1');
            if (/\/(?:gps-cs-s|gps-proxy)\//i.test(s)) {
                if (/^https?:\/\//i.test(small) && !isCorruptedDashboardPhotoUrl(small)) {
                    return small.replace(/(=[ws]\d+[^=]*)(=[ws]\d+[^=]*)$/i, '$1');
                }
                return s;
            }
            if (/\/p\//i.test(s)) {
                const dimMatch = s.match(/=w(\d+)-h(\d+)([^=&?]*)$/i);
                if (dimMatch) {
                    const wNum = parseInt(dimMatch[1], 10) || 0;
                    const hNum = parseInt(dimMatch[2], 10) || 0;
                    if (wNum > 1600 || hNum > 1600) {
                        s = s.replace(/=w\d+-h\d+[^=&?]*$/i, '=w1000-h750-k-no');
                    }
                }
            }
        }
    } catch (_) {}
    return s;
}

function normalizeDashboardRow(row) {
    if (!row || typeof row !== 'object') return row;
    if (row._plNormV46 === 1 && row.company_name && (row.phone_number !== undefined)) return row;
    row.company_name = row.company_name || dashboardFirstValue(row, ['name', 'title', 'businessName', 'business_name', 'placeName', 'displayName']);
    row.website = row.website || dashboardFirstValue(row, ['websiteUrl', 'websiteURL', 'urlWebsite', 'officialWebsite', 'official_website', 'site']);
    row.address = row.address || dashboardFirstValue(row, ['formattedAddress', 'formatted_address', 'fullAddress', 'full_address', 'streetAddress', 'vicinity']);
    row.city = row.city || dashboardFirstValue(row, ['municipality', 'locality', 'town', 'district']);
    row.state = row.state || dashboardFirstValue(row, ['region', 'province', 'administrativeArea']);
    row.pincode = row.pincode || dashboardFirstValue(row, ['pinCode', 'postalCode', 'postal_code', 'postcode', 'zip', 'zipCode']);
    const phone = rowPhoneValue(row);
    if (phone) row.phone_number = phone;
    const email = normalizeDashboardEmails([
        row.email_1, row.email, row.email1, row.emailAddress, row.email_address,
        row.contactEmail, row.contact_email, row.businessEmail, row.business_email,
        row.mail, row.mailAddress, row.mail_address
    ].filter(Boolean).join(', '));
    if (email) row.email_1 = email;
    else if (row.email_1 && /^(no email found|can't access website|blacklisted email)$/i.test(String(row.email_1).trim())) row.email_1 = String(row.email_1).trim();
    else row.email_1 = '';
    row.total_reviews = row.total_reviews || dashboardFirstValue(row, ['reviewCount', 'reviewsCount', 'reviews_count', 'ratingCount', 'ratingsCount', 'userRatingsTotal', 'user_ratings_total']);
    row.review = row.review || dashboardFirstValue(row, ['rating', 'stars', 'score', 'ratingValue', 'averageRating', 'average_rating']);
    row.place_id = row.place_id || dashboardFirstValue(row, ['placeId', 'placeID', 'googlePlaceId', 'googleMapsPlaceId', 'google_maps_place_id']);
    row.map_link = resolveLeadProfileMapsUrl(row) || row.map_link || '';
    row.facebook = row.facebook || dashboardFirstValue(row, ['facebookUrl', 'facebook_url', 'fb']);
    row.instagram = row.instagram || dashboardFirstValue(row, ['instagramUrl', 'instagram_url', 'ig']);
    row.linkedin = row.linkedin || dashboardFirstValue(row, ['linkedinUrl', 'linkedin_url']);
    row.twitter = row.twitter || dashboardFirstValue(row, ['twitterUrl', 'twitter_url', 'x_url']);
    row.youtube = row.youtube || dashboardFirstValue(row, ['youtubeUrl', 'youtube_url']);
    if (!row.keyword && row.query) {
        const qStr = String(row.query || '').trim();
        if (qStr.includes('~in~')) {
            const parts = qStr.split('~in~');
            row.keyword = String(parts[0] || '').trim();
            if (!row.location && parts[1]) row.location = String(parts[1] || '').trim();
        } else {
            row.keyword = qStr;
        }
    } else if (row.keyword && String(row.keyword).includes('~in~')) {
        const parts = String(row.keyword).split('~in~');
        row.keyword = String(parts[0] || '').trim();
        if (!row.location && parts[1]) row.location = String(parts[1] || '').trim();
    }
    if (!row.location) {
        row.location = dashboardFirstValue(row, ['searchLocation', 'city', 'district', 'pincode']);
    }

    const dedupedSamples = [];
    const dedupedUrls = [];
    const seenPhotoKeys = new Set();
    const registerPhotoPair = (rawSmall, rawLarge, photoId) => {
        const pid = String(photoId || '').trim();
        if (/^AF1Qip[A-Za-z0-9_\-]{10,}$/.test(pid)) {
            rawSmall = 'https://lh3.googleusercontent.com/p/' + pid + '=w600-h450-k-no';
            rawLarge = 'https://lh3.googleusercontent.com/p/' + pid + '=w1200-h900-k-no';
        }
        const cSmall = upgradeDashboardPhotoUrl(rawSmall || rawLarge || '', rawSmall);
        const cLarge = upgradeDashboardPhotoUrl(rawLarge || rawSmall || '', cSmall || rawSmall);
        const primary = cSmall || cLarge;
        if (!primary || !/^https?:\/\//i.test(primary)) return;
        const large = (/\/(?:gps-cs-s|gps-proxy)\/|streetviewpixels/i.test(primary)) ? primary : (cLarge || primary);
        const k = canonicalDashboardPhotoKey(primary) || primary;
        if (seenPhotoKeys.has(k)) return;
        seenPhotoKeys.add(k);
        dedupedSamples.push({ photo_id: String(photoId || ''), photo_url: primary, photo_url_large: large });
        if (!dedupedUrls.includes(primary)) dedupedUrls.push(primary);
    };

    if (Array.isArray(row.photos_sample)) {
        row.photos_sample.forEach(p => {
            if (!p) return;
            if (typeof p === 'string') registerPhotoPair(p, p, '');
            else if (typeof p === 'object') {
                registerPhotoPair(
                    p.photo_url || p.photoUrl || p.thumbnail || p.url || p.image || '',
                    p.photo_url_large || p.photoUrlLarge || p.photo_url || p.url || '',
                    p.photo_id || p.id || ''
                );
            }
        });
    }
    const directSmall = row.photo_url || dashboardFirstValue(row, ['photoUrl', 'thumbnail', 'thumbnailUrl', 'imageUrl', 'image_url', 'photo', 'image', 'mainPhoto', 'featured_image', 'street_view']);
    const directLarge = row.photo_url_large || dashboardFirstValue(row, ['photoUrlLarge', 'large_photo_url', 'originalPhotoUrl']);
    if (directSmall || directLarge) {
        registerPhotoPair(directSmall, directLarge, '');
    }
    if (typeof row.photo_urls === 'string' && row.photo_urls.trim()) {
        row.photo_urls.split(/\s*,\s*/).forEach(u => registerPhotoPair(u, u, ''));
    }

    if (dedupedSamples.length) {
        row.photos_sample = dedupedSamples;
        row.photo_url = dedupedSamples[0].photo_url;
        row.photo_url_large = dedupedSamples[0].photo_url;
        row.photo_urls = dedupedUrls.join(', ');
    } else {
        row.photo_url = '';
        row.photo_url_large = '';
        row.photo_urls = '';
    }
    if (row.source) row.source = canonicalDashboardSource(row.source);
    try {
        ['phoneNumber','telephone','tel','mobile','formattedPhone','formatted_phone_number','internationalPhoneNumber','international_phone_number','phoneNumberUnformatted','phoneUnformatted','phone_number_unformatted','contactPhone','contact_number','businessPhone','primaryPhone','email','email1','emailAddress','email_address','contactEmail','contact_email','businessEmail','business_email','mail','mailAddress','mail_address','serper_raw_json','serper_endpoint'].forEach(k => { if (k in row) delete row[k]; });
    } catch (e) {}
    return row;
}

function isHiddenPhoneAliasColumn(key) {
    const normalized = String(key || '')
        .replace(/([a-z0-9])([A-Z])/g, '$1_$2')
        .replace(/[^a-zA-Z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '')
        .toLowerCase();
    if (!normalized) return false;
    // Keep only the canonical snake_case field. Hide camelCase/header variants
    // such as phoneNumber / Phone Number because the canonical column already
    // renders their value through rowPhoneValue().
    if (normalized === 'phone_number') return String(key || '') !== 'phone_number';
    return [
        'phone', 'phone_number_raw', 'phone_number_display', 'phone_number_formatted',
        'phone_number_unformatted', 'phone_number_unformatted_raw', 'phone_unformatted',
        'phone_formatted', 'formatted_phone', 'formatted_phone_number',
        'international_phone_number', 'telephone', 'tel', 'mobile', 'contact_phone',
        'contact_number', 'business_phone', 'primary_phone', 'whatsapp_number',
        'wa_number'
    ].includes(normalized);
}

function buildColumnListFromRows(rows) {
    // Deliberately fixed for both Engine 1 and Engine 2. Raw provider keys,
    // debug payloads and aliases must never become user-facing headers.
    (rows || []).forEach(row => { if (row && typeof row === 'object') normalizeDashboardRow(row); });
    return baseColumnList.slice();
}

function refreshColumnList(rows) {
    columnList = buildColumnListFromRows(rows || []);
    return columnList;
}

ngApp.controller("indexController", function($scope, $http,$sce) {
    
    $scope.developer = DEVELOPER_INFO;
    $scope.manifest = chrome.runtime.getManifest();
    $scope.welcome = WelcomeController.model;
    $scope.Tabs = Tabs;
    $scope.$fc = FoxCommon;
    $scope.$auth = Auth;
    $scope.$config = Config;

    // -----------------------------------------------------------------------
    // Page limit dropdown controls
    //
    // We implement a custom dropdown for selecting the maximum number of pages
    // to scrape per pincode search.  Unlike a native <select>, this
    // dropdown uses a button and menu to allow for full styling in the
    // dark dashboard.  The dropdown is toggled via
    // togglePageLimitDropdown(), and selecting an option calls
    // setPageLimit(value) which stores the choice and hides the menu.
    $scope.pageLimitDropdownVisible = false;
    $scope.togglePageLimitDropdown = () => {
        $scope.pageLimitDropdownVisible = !$scope.pageLimitDropdownVisible;
    };
    $scope.setPageLimit = (value) => {
        $scope.local.pageLimit = value;
        $scope.saveLocal();
        $scope.pageLimitDropdownVisible = false;
    };

    // -----------------------------------------------------------------------
    // WA number check progress tracking
    //
    // These properties track the progress of the local‑only WA number
    // check feature.  waTotal is the number of phone numbers to process,
    // waFinished counts how many have completed, and waChecking is true
    // while the check is running.  waCompletedRows is a map of row
    // indices that have already been counted so we do not double‑count
    // retries or duplicate updates.
    $scope.waTotal = 0;
    $scope.waFinished = 0;
    $scope.waChecking = false;
    $scope.waCompletedRows = {};
    /*
     * Maintain sets of completed and enqueued rows keyed by a stable
     * identifier (cid) rather than the row index.  Using the row index
     * alone can lead to incorrect progress tracking when new results
     * are inserted into local.collect, shifting indices and causing
     * previously processed rows to be considered pending again.  The
     * cid property is unique per record and does not change when
     * records are reordered or new results are inserted.  We use
     * waCompletedIds and waEnqueuedIds alongside the legacy
     * waCompletedRows/waEnqueuedRows to ensure that progress is
     * session‑scoped and cumulative.
     */
    $scope.waCompletedIds = {};
    $scope.waEnqueuedIds = {};
    // Track all phone numbers discovered during the current scraping session.
    // Keys are stable cids.  This allows the total (waTotal) to represent
    // the number of unique phone numbers encountered so far, regardless of
    // whether they have been processed or enqueued.  Do not clear this
    // object when stopping a WA run; clear it only when starting a new
    // scraping session.
    $scope.waDiscoveredIds = {};
    // Capture the initial total number of phone numbers at the moment a
    // WhatsApp number check begins.  This value is used for the
    // progress bar denominator so that the total count displayed to
    // the user remains constant even when new numbers are added
    // during scraping.  We update waInitialTotal at the start of
    // each WA check and keep it unchanged during subsequent runs until
    // the next WA check begins.  Resets to zero when the user
    // manually stops the check.
    $scope.waInitialTotal = 0;
    // Track rows that have been enqueued for the current WhatsApp check.  When
    // scraping is running concurrently with a WA check we may discover new
    // phone numbers.  To avoid sending duplicates to the background
    // service worker we record each rowId as soon as it is queued.  Only
    // rows not present in this object will be added when new data arrives.
    $scope.waEnqueuedRows = {};

    // When a WA run finishes while scraping is still active we defer showing
    // the completion popup until scraping has truly ended.  This flag is
    // true when a WA run has completed but more numbers may still arrive.
    $scope.waPendingComplete = false;
        // Record the timestamp when a WA check starts.  This is used to
        // suppress an immediate scraping completion popup if the
        // completion event arrives within a few seconds of starting a
        // WA check.  Without this, a race condition in fast mode may
        // cause the scraping completion popup to appear right after
        // initiating the WA check.
        $scope.waStartTimestamp = 0;
    // Track whether scraping is currently active.  This is updated when
    // scraping starts and stops so that WA checking logic can decide
    // whether to wait for new numbers or show a completion notification.
    $scope.scrapingActive = false;

        // When true we suppress the "Scraping completed" UI and desktop
        // notification because a WhatsApp number check is currently
        // running or has completed and is waiting for late numbers.
        // Scraping may finish while WA is still active; in that case we
        // defer the completion popup until WA finishes.  The flag is
        // reset when the WA run ends and the deferred popup is shown.
        $scope.suppressScrapingComplete = false;
        // Internal flag set when a scraping_complete event occurs while
        // suppressScrapingComplete is true.  It indicates that the
        // scraping completion logic should run after WA finishes.
        $scope.scrapingCompletePending = false;

    // Flag to indicate that a manual stop is in progress.  When true, any
    // subsequent scraping_stopped events will not trigger notifications or
    // duplicate "Scraping stopped" alerts.  This flag is set by
    // manualStopScraping and cleared after the stop has been fully handled.
    $scope.manualStopInProgress = false;

    // When true, the UI is waiting for the user to log in to
    // WhatsApp Web.  During this period waChecking is true but no
    // numbers are processed.  The user should switch to the
    // WhatsApp tab and scan the QR code.  Once login is detected
    // processing will begin automatically.
    $scope.waLoginWaiting = false;

    /**
     * Safely execute a function within Angular's digest cycle.  When called
     * during an existing $apply/$digest this helper will execute the
     * callback immediately without triggering a new digest.  Otherwise it
     * delegates to $apply so that changes are picked up.  Use this
     * function instead of $scope.$apply() in asynchronous callbacks to
     * avoid `$rootScope:inprog` errors.
     *
     * @param {Function} fn The function to execute
     */
    $scope.safeApply = function(fn) {
        try {
            const phase = $scope.$root && $scope.$root.$$phase;
            if (phase === '$apply' || phase === '$digest') {
                if (typeof fn === 'function') {
                    fn();
                }
            } else {
                $scope.$apply(fn);
            }
        } catch (err) {
            // Log and suppress errors; never throw from safeApply
            console.warn('safeApply: error executing callback', err);
            try {
                if (typeof fn === 'function') {
                    fn();
                }
            } catch (innerErr) {
                /* ignore */
            }
        }
    };

    // Country selector used by Serper/Google/Apify query restriction. Keep this
    // inside the dashboard model so the selected country is saved and used by
    // the API before credits are spent.
    const DASHBOARD_COUNTRY_CODES = {
        'India': 'IN', 'Bangladesh': 'BD', 'Pakistan': 'PK', 'Nepal': 'NP', 'Sri Lanka': 'LK', 'Bhutan': 'BT',
        'United States': 'US', 'United Kingdom': 'GB', 'United Arab Emirates': 'AE', 'Canada': 'CA', 'Australia': 'AU',
        'Singapore': 'SG', 'Malaysia': 'MY', 'Thailand': 'TH', 'Indonesia': 'ID', 'Philippines': 'PH',
        'Germany': 'DE', 'France': 'FR', 'Italy': 'IT', 'Spain': 'ES', 'Netherlands': 'NL', 'Brazil': 'BR', 'Mexico': 'MX',
        'South Africa': 'ZA', 'Saudi Arabia': 'SA', 'Qatar': 'QA', 'Oman': 'OM', 'Kuwait': 'KW'
    };
    $scope.countries = Object.keys(DASHBOARD_COUNTRY_CODES);
    if (typeof window !== 'undefined') {
        window.countryList = $scope.countries;
        window.countryIsoCodes = Object.assign({}, window.countryIsoCodes || {}, DASHBOARD_COUNTRY_CODES);
    }
    function dashboardCountryCode(country) {
        const c = String(country || '').trim();
        if (!c) return 'IN';
        return DASHBOARD_COUNTRY_CODES[c] || (typeof window !== 'undefined' && window.countryIsoCodes && window.countryIsoCodes[c]) || 'IN';
    }
    function getPermanentUserSelectedCountry() {
        try {
            if (typeof localStorage !== 'undefined') {
                const saved = String(localStorage.getItem('pl_user_selected_country_v1') || '').trim();
                if (saved) return saved;
            }
        } catch (_) {}
        return '';
    }

    function savePermanentUserSelectedCountry(countryName) {
        const clean = String(countryName || '').trim();
        if (!clean) return;
        try {
            if (typeof localStorage !== 'undefined') {
                localStorage.setItem('pl_user_selected_country_v1', clean);
            }
        } catch (_) {}
        try {
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                chrome.storage.local.set({ pl_user_selected_country_v1: clean });
            }
        } catch (_) {}
    }

    $scope.setCountry = function(country) {
        if (!$scope.local) $scope.local = {};
        const selected = String(country !== undefined ? country : ($scope.local.country || '')).trim();
        if (selected) {
            savePermanentUserSelectedCountry(selected);
        }
        $scope.local.country = selected;
        $scope.local.countryCode = selected ? dashboardCountryCode(selected) : '';
        $scope.local.apifySettings = Object.assign({}, $scope.local.apifySettings || {}, {
            countryFilter: selected,
            countryCodeFilter: $scope.local.countryCode,
            enforceCountryFilter: !!selected
        });
        if (typeof window !== 'undefined') window.localCountry = selected;
        try { $scope.saveLocal(); } catch (e) {}
    };

    $scope.exportModal = {
        show: false,
        fields: [],
        selected: {},
        format: 'csv'
    };

    // Track whether a valid licence has been activated.  This flag
    // defaults to false until storage is queried.  When true, the
    // dashboard's start button is enabled and export functionality
    // operates normally.  When false, attempts to start scraping or
    // export will display a prompt asking the user to activate their
    // licence first.
    $scope.licenseActive = false;
    // Store the number of active devices returned by the backend.  This
    // value is displayed in the navbar and defaults to zero until the
    // licence state is read from storage.
    $scope.licenseDevices = 0;

    // Initialize licenceActive based on stored licence information.  If
    // storage access fails we leave licenceActive false to ensure the
    // user is prompted for activation.  This check runs only once
    // during controller initialization.
    try {
        chrome.storage.local.get('license', function(res) {
            const lic = res && res.license;
            $scope.$apply(() => {
                $scope.licenseActive = !!(lic && lic.active);
                // After retrieving licence state, update the UI to
                // reflect start button availability.
                if (typeof $scope.updateUIState === 'function') {
                    $scope.updateUIState();
                }
            });
        });
    } catch (err) {
        console.error('Failed to read licence from storage', err);
    }

    // Listen for licence changes in storage so the UI responds when a
    // licence is activated or released while the popup is open.  This
    // ensures the start button updates without requiring a refresh.
    try {
        chrome.storage.onChanged.addListener(function(changes, areaName) {
            if(areaName==='local' && changes.pocketleadsPreflightState?.newValue?.errorCode==='ACCOUNT_PREFLIGHT'){
                const message=changes.pocketleadsPreflightState.newValue.message;
                $scope.$evalAsync(()=>{ $scope.startLaunchPending=false; if($scope.showCaptchaPopup)$scope.showCaptchaPopup(message); });
            }
            if (areaName === 'local' && changes.license) {
                const newLic = changes.license.newValue;
                $scope.$apply(() => {
                    $scope.licenseActive = !!(newLic && newLic.active);
                    if (typeof $scope.updateUIState === 'function') {
                        $scope.updateUIState();
                    }
                });
            }
            if (areaName === 'local' && (changes.pocketleadsAccount || changes.license || changes.pocketleadsPreparedRoute)) {
                if (typeof $scope.checkExpiringLicencePopup === 'function') {
                    $scope.checkExpiringLicencePopup(false);
                }
            }
            if (areaName === 'local' && changes.pocketleadsPreflightState) {
                const state = changes.pocketleadsPreflightState.newValue || {};
                const code = String(state.errorCode || '').toUpperCase();
                const upgrade = !!state.upgradeRequired || /LICENSE_(?:EXPIRED|CREDIT_EXHAUSTED)|LICENCE_(?:EXPIRED|CREDIT_EXHAUSTED)|ALL_CREDITS_EXHAUSTED/.test(code);
                if (upgrade && String(state.status || '') === 'error') {
                    const show = function(){
                        if (typeof $scope.showCaptchaPopup === 'function') {
                            const msg = /CREDIT/.test(code)
                                ? 'Your scraping credits are exhausted. Upgrade your plan to continue. Contact ' + (state.supportEmail || PocketLeadsConfig.supportEmail) + '.'
                                : 'Your licence has expired. Contact ' + (state.supportEmail || PocketLeadsConfig.supportEmail) + ' to renew your licence.';
                            $scope.showCaptchaPopup(msg, { title:'Upgrade Required', upgrade:true, supportEmail:state.supportEmail || PocketLeadsConfig.supportEmail });
                        } else {
                            $scope.pendingPreflightCommercialState = state;
                        }
                    };
                    try { $scope.safeApply ? $scope.safeApply(show) : $scope.$evalAsync(show); } catch (e) { $scope.pendingPreflightCommercialState = state; }
                }
            }
        });
    } catch (err) {
        console.error('Failed to register licence change listener', err);
    }
    
    $scope.isCheckingLicense = false;
    // v91: short UI-only launch guard. Running/timer state is owned by the
    // background controller after a prepared data source has been accepted.
    $scope.startLaunchPending = false;
    
    /* ------------------------------- Login Page ------------------------------- */
    $scope.loginPage = {
        email : "",
        password : "",
        isLoading : false,
    };
    
    /* ---------------------------------- Local --------------------------------- */
    $scope.local = $box.getDefaultLocalModel();
    // Track whether a WhatsApp check has been paused.  When true the
    // resume button is shown and subsequent calls to whatsappCheck
    // will continue processing cancelled rows rather than starting
    // from scratch.  This flag is reset automatically when a new
    // WhatsApp check begins or after resuming.
    $scope.local.pausedWhatsapp = false;

    // Flag to suppress the next stop notification after a captcha
    // pause.  When scraping_error is received we set this to true.
    // The next scraping_stopped event resets it to false and
    // prevents additional notifications from showing.
    $scope.ignoreNextStopNotification = false;

    // Flag to indicate whether a scraping completion notification has
    // already been displayed during the current run.  This prevents
    // duplicate "Scraping Complete" notifications from showing if
    // multiple scraping_complete events are fired.  It is reset to
    // false whenever scraping starts again.
    $scope.scrapingCompleteShown = false;

    // Initialize settings panel visibility flag.  When false, the panel is
    // hidden; toggled to true by clicking the Settings button in the
    // dashboard header.  We store this on the local object so that
    // changes propagate through Angular's binding system.  See
    // views/index.html for the corresponding ng-show directive.
    $scope.local.showSettings = false;

    // ------------------------------------------------------------------------
    // Progress bar management (initial definitions)
    // ------------------------------------------------------------------------
    // Define the progressData object up front so it is available when
    // updateUIState first runs.  Without this early definition,
    // updateUIState may attempt to call updateProgress before the latter
    // has been assigned.
    $scope.progressData = { completed: 0, total: 0, percent: 0 };

    // Separate progress tracker for WhatsApp number checking.  This
    // object will be updated during the WhatsApp check to reflect
    // how many numbers have been processed out of the total.  When
    // total is zero the progress bar is hidden in the UI (via
    // ng-if).  Define it here so it exists before any checks run.
    $scope.whatsappProgress = { completed: 0, total: 0, percent: 0 };

    // Scraping timer for the dashboard stat card. It updates every second only
    // while scraping is active and also keeps the final completed/stopped time.
    $scope.scrapeTimerTick = Date.now();
    $scope.totalScrapingTimeText = '00:00';
    $scope.formatDurationMs = function(ms) {
        ms = Math.max(0, parseInt(ms, 10) || 0);
        const totalSeconds = Math.floor(ms / 1000);
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
        const pad = n => String(n).padStart(2, '0');
        return hours > 0 ? (hours + ':' + pad(minutes) + ':' + pad(seconds)) : (pad(minutes) + ':' + pad(seconds));
    };
    let _activeScreenWakeLock = null;
    async function syncScreenWakeLock(shouldHold) {
        try {
            if (typeof navigator === 'undefined' || !navigator.wakeLock || typeof navigator.wakeLock.request !== 'function') return;
            if (shouldHold && !document.hidden) {
                if (!_activeScreenWakeLock) {
                    _activeScreenWakeLock = await navigator.wakeLock.request('screen').catch(() => null);
                    if (_activeScreenWakeLock && typeof _activeScreenWakeLock.addEventListener === 'function') {
                        _activeScreenWakeLock.addEventListener('release', () => { _activeScreenWakeLock = null; });
                    }
                }
            } else if (!shouldHold && _activeScreenWakeLock) {
                try { await _activeScreenWakeLock.release(); } catch (_) {}
                _activeScreenWakeLock = null;
            }
        } catch (_) {}
    }

    if (typeof document !== 'undefined' && !document.documentElement.dataset.plWakeRecoveryBound) {
        document.documentElement.dataset.plWakeRecoveryBound = '1';
        const onWakeOrFocus = () => {
            try {
                const local = $scope.local || {};
                if (PocketLeadsRunState.isRunning(local)) {
                    void syncScreenWakeLock(true);
                    if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
                        chrome.runtime.sendMessage({ action: 'ensure_engine_alive' }, () => { try { void chrome.runtime.lastError; } catch (_) {} });
                    }
                }
            } catch (_) {}
        };
        document.addEventListener('visibilitychange', () => {
            $scope._lastStopTimerTickMs = 0;
            if (!document.hidden) onWakeOrFocus();
        });
        if (typeof window !== 'undefined') {
            window.addEventListener('focus', onWakeOrFocus);
            window.addEventListener('online', onWakeOrFocus);
        }
    }

    $scope._stopTimerElapsedMs = (function() {
        try { return Math.max(0, parseInt(localStorage.getItem('pl_stop_active_elapsed_ms'), 10) || 0); } catch (_) { return 0; }
    })();
    $scope._lastStopTimerTickMs = 0;

    function isStopButtonStateActive() {
        const local = $scope.local || {};
        const q = local.apifyQueue || {};
        const qStatus = String(q.status || '').toLowerCase();
        if (qStatus === 'stopped' || qStatus === 'idle' || qStatus === 'completed' || qStatus === 'completed_with_errors' || qStatus === 'failed') {
            return false;
        }
        return !!(
            (local.status === true) ||
            (local._taskManager && local._taskManager.isWorking === true) ||
            PocketLeadsRunState.isRunning(local)
        );
    }

    // Silent WebAudio keep-alive prevents Android WebView / Chrome from throttling
    // background fetch() & Promise timers when the APK is minimized or the screen is off
    let _bgAudioCtx = null;
    let _bgAudioOsc = null;
    function syncBackgroundAudioKeepAlive(active) {
        try {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (!AudioCtx) return;
            if (active) {
                if (!_bgAudioCtx) {
                    _bgAudioCtx = new AudioCtx();
                }
                if (_bgAudioCtx.state === 'suspended') {
                    _bgAudioCtx.resume().catch(() => {});
                }
                if (!_bgAudioOsc) {
                    const osc = _bgAudioCtx.createOscillator();
                    const gain = _bgAudioCtx.createGain();
                    gain.gain.value = 0.00001; // Completely inaudible
                    osc.frequency.value = 1;
                    osc.connect(gain);
                    gain.connect(_bgAudioCtx.destination);
                    osc.start();
                    _bgAudioOsc = osc;
                }
            } else {
                if (_bgAudioOsc) {
                    try { _bgAudioOsc.stop(); _bgAudioOsc.disconnect(); } catch (_) {}
                    _bgAudioOsc = null;
                }
                if (_bgAudioCtx && _bgAudioCtx.state === 'running') {
                    try { _bgAudioCtx.suspend().catch(() => {}); } catch (_) {}
                }
            }
        } catch (_) {}
    }
    window.__plBackgroundHeartbeatTick = function() {
        try {
            if (isStopButtonStateActive() && typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
                chrome.runtime.sendMessage({ action: 'ensure_engine_alive' }, () => { try { void chrome.runtime.lastError; } catch (_) {} });
            }
        } catch (_) {}
    };

    $scope.recalculateScrapingTimeText = function() {
        const local = $scope.local || {};
        const q = local.apifyQueue || {};
        const qStatus = String(q.status || '').toLowerCase();
        const activeNow = isStopButtonStateActive();
        if ($scope._isClearedSession && !activeNow) {
            $scope._stopTimerElapsedMs = 0;
            $scope.totalScrapingTimeText = '00:00';
            return '00:00';
        }
        let lsMs = 0;
        try { lsMs = Math.max(0, parseInt(localStorage.getItem('pl_stop_active_elapsed_ms'), 10) || 0); } catch (_) {}
        const currentMemMs = Math.max(0, Number($scope._stopTimerElapsedMs) || 0, lsMs);
        const queueActiveMs = Math.max(0, parseInt(q._activeElapsedMs, 10) || 0);
        // Prevent any sudden upward jump during active scraping: while active, the 1-second interval owns smooth +1s ticking
        let bestMs = currentMemMs;
        if (!activeNow) {
            bestMs = Math.max(currentMemMs, queueActiveMs);
        } else if (currentMemMs === 0 && queueActiveMs > 0 && queueActiveMs < 15000) {
            bestMs = queueActiveMs;
        }
        if (bestMs === 0 && !activeNow && (qStatus === 'idle' || !qStatus) && (Number(local.resultStoreCount) || 0) === 0) {
            $scope._stopTimerElapsedMs = 0;
            $scope.totalScrapingTimeText = '00:00';
            return '00:00';
        }
        $scope._stopTimerElapsedMs = bestMs;
        try {
            if (bestMs > lsMs) localStorage.setItem('pl_stop_active_elapsed_ms', String(bestMs));
        } catch (_) {}
        const value = $scope.formatDurationMs(bestMs);
        $scope.totalScrapingTimeText = value;
        return value;
    };
    $scope.getTotalScrapingTime = function() {
        return $scope.totalScrapingTimeText || $scope.recalculateScrapingTimeText();
    };
    try {
        setInterval(function() {
            // Immediate stop if internet is turned off / Flight Mode while running
            if (typeof navigator !== 'undefined' && navigator.onLine === false) {
                if (isStopButtonStateActive() || $scope.startLaunchPending || ($scope.local && $scope.local.isScrapingEmail)) {
                    $scope._lastStopTimerTickMs = 0;
                    $scope.manualStopScraping('offline');
                    return;
                }
            }
            const stopActive = isStopButtonStateActive();
            void syncScreenWakeLock(stopActive);
            syncBackgroundAudioKeepAlive(stopActive);
            if (stopActive) {
                const nowMs = Date.now();
                // Strict 1-second monotonic increment (never jumps even if a digest was delayed)
                if ($scope._lastStopTimerTickMs > 0 && (nowMs - $scope._lastStopTimerTickMs) < 750) {
                    return;
                }
                const deltaMs = ($scope._lastStopTimerTickMs > 0 && (nowMs - $scope._lastStopTimerTickMs) <= 1600)
                    ? (nowMs - $scope._lastStopTimerTickMs)
                    : 1000;
                $scope._lastStopTimerTickMs = nowMs;
                $scope._stopTimerElapsedMs = Math.max(0, (Number($scope._stopTimerElapsedMs) || 0) + deltaMs);
                try { localStorage.setItem('pl_stop_active_elapsed_ms', String($scope._stopTimerElapsedMs)); } catch (_) {}
                try {
                    if (!$scope._nativeKeepAliveActive && window.AndroidChromeBridge && typeof window.AndroidChromeBridge.setExtractionActive === 'function') {
                        $scope._nativeKeepAliveActive = true;
                        window.AndroidChromeBridge.setExtractionActive(true, 'Extracting leads in background...');
                    }
                } catch (_) {}
                if ($scope.local) {
                    $scope.local.scrapeElapsedMs = $scope._stopTimerElapsedMs;
                    if ($scope.local.apifyQueue) {
                        $scope.local.apifyQueue.elapsedMs = $scope._stopTimerElapsedMs;
                        $scope.local.apifyQueue._activeElapsedMs = $scope._stopTimerElapsedMs;
                    }
                }
                $scope.$applyAsync(function() {
                    $scope.scrapeTimerTick = nowMs;
                    $scope.totalScrapingTimeText = $scope.formatDurationMs($scope._stopTimerElapsedMs);
                });
            } else {
                // Immediately freeze timer & clear any ongoing Android notification as soon as "Stop" state becomes inactive
                $scope._lastStopTimerTickMs = 0;
                if ($scope._nativeKeepAliveActive && !($scope.local && $scope.local.isScrapingEmail)) {
                    $scope._nativeKeepAliveActive = false;
                    try {
                        if (window.AndroidChromeBridge) {
                            if (typeof window.AndroidChromeBridge.setExtractionActive === 'function') {
                                window.AndroidChromeBridge.setExtractionActive(false, '');
                            }
                            if (typeof window.AndroidChromeBridge.cancelAllNotifications === 'function') {
                                window.AndroidChromeBridge.cancelAllNotifications();
                            }
                        }
                    } catch (_) {}
                }
            }
        }, 1000);
    } catch (timerErr) {
        console.warn('Scraping timer init failed', timerErr);
    }

    // Storage-change events can occasionally be missed while the extension page
    // is being reopened. Poll only during an active run as a low-cost watchdog.
    try {
        setInterval(function() {
            const current = $scope.local || {};
            const isActive = PocketLeadsRunState.isRunning(current);
            if (!isActive) return;
            const lastAt = Date.parse((current.apifyQueue && current.apifyQueue.lastUpdatedAt) || '');
            if (Number.isFinite(lastAt) && Date.now() - lastAt > 9000) {
                try {
                    if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
                        chrome.runtime.sendMessage({ action: 'ensure_engine_alive' }, () => { try { void chrome.runtime.lastError; } catch (_) {} });
                    }
                } catch (_) {}
            }
            $box.getLocal(function(fresh) {
                if (!fresh) return;
                const oldStamp = String(current.apifyQueue && current.apifyQueue.lastUpdatedAt || '');
                const newStamp = String(fresh.apifyQueue && fresh.apifyQueue.lastUpdatedAt || '');
                if (!newStamp || newStamp === oldStamp) return;
                fresh.collect = dedupeDashboardRows(fresh.collect || []);
                $scope.$applyAsync(function() {
                    const sameRun = (fresh.apifyQueue || {}).runEventId === (($scope.local || {}).apifyQueue || {}).runEventId;
                    if (sameRun && $scope.local && Array.isArray($scope.local.collect) && $scope.local.collect.length > 0) {
                        const fullRows = $scope.local.collect.slice();
                        const rowKey = row => String((row && (row.place_id || row.cid || row.map_link || row.phone || row.company_name || ((row.company_name || row.name || '') + '|' + (row.address || '')))) || '');
                        const indexByKey = new Map();
                        fullRows.forEach((row, idx) => indexByKey.set(rowKey(row), idx));
                        (fresh.collect || []).forEach(row => {
                            const key = rowKey(row);
                            if (key && indexByKey.has(key)) fullRows[indexByKey.get(key)] = Object.assign({}, fullRows[indexByKey.get(key)], row);
                            else { indexByKey.set(key, fullRows.length); fullRows.push(row); }
                        });
                        fresh.collect = dedupeDashboardRows(fullRows).slice(-5000);
                    }
                    const bestCount = Math.max(
                        sameRun ? (parseInt($scope._monotonicResultCount, 10) || 0) : 0,
                        sameRun ? (parseInt($scope.local && $scope.local.resultStoreCount, 10) || 0) : 0,
                        parseInt(fresh.resultStoreCount, 10) || 0,
                        Array.isArray(fresh.collect) ? fresh.collect.length : 0
                    );
                    fresh.resultStoreCount = bestCount;
                    fresh.collectIsPreview = bestCount > (Array.isArray(fresh.collect) ? fresh.collect.length : 0);
                    $scope._monotonicResultCount = bestCount;
                    $scope.local = fresh;
                    refreshDashboardMetricCounts(fresh.collect || []);
                    if (typeof $scope.recalculateScrapingTimeText === 'function') $scope.recalculateScrapingTimeText();
                    $scope.updateUIState();
                });
            });
        }, 1500);
    } catch (watchdogErr) {
        console.warn('Progress watchdog init failed', watchdogErr);
    }

    /**
     * Compute and update the scraping progress.  See the detailed
     * documentation later in this file for the full description.  This
     * duplicate definition ensures that updateProgress exists before it is
     * invoked inside updateUIState.  The later definition will simply
     * overwrite this one with identical logic.
     */
    $scope.updateProgress = function() {
        const local = $scope.local || {};
        const q = local.apifyQueue || {};
        const status = String(q.status || '').toLowerCase();
        const active = !!(PocketLeadsRunState.isRunning(local) || local.status || (local._taskManager && local._taskManager.isWorking));
        const terminal = /^(completed|completed_with_errors|dataset_saved|dataset_saved_with_errors)$/.test(status);
        const stopped = status === 'stopped' || status === 'paused_recoverable' || status === 'failed';

        const kwArr = Array.isArray(local.keywordList) ? local.keywordList : [];
        const locArr = Array.isArray(local.locationList) ? local.locationList : [];
        const listTotalKeywords = kwArr.length || $scope.getKeywordLineCount();
        const listTotalLocations = locArr.length || $scope.getLocationLineCount();
        const listTotal = (listTotalKeywords && listTotalLocations) ? (listTotalKeywords * listTotalLocations) : 0;

        const currentSig = (kwArr.length && locArr.length) ? computeFastTaskSignature(kwArr, locArr) : '';
        const savedSig = String(local.apifyTaskSignature || '').trim();
        const inputsModified = Boolean(!active && !$scope.startLaunchPending && currentSig && savedSig && currentSig !== savedSig);

        if ((status === 'idle' || $scope._isClearedSession) && !active && !$scope.startLaunchPending && (parseInt(q.scrapedCount, 10) || 0) === 0 && (parseInt(local.resultStoreCount, 10) || 0) === 0) {
            $scope._monotonicTaskCompleted = 0;
            $scope.progressData = {
                completed: 0,
                completedSettled: 0,
                taskCompleted: 0,
                taskTotal: listTotal,
                currentTaskIndex: 0,
                total: listTotal,
                percent: 0,
                percentExact: 0,
                phase: 'Ready',
                detail: listTotal ? ('0/' + listTotal + ' searches') : ''
            };
            return;
        }

        // If user edited Keywords/Locations while idle/stopped/completed, reflect the new target task total (e.g. 71)
        const queueTotal = parseInt(q.totalTasks, 10) || 0;
        const apifyTotal = parseInt(local.apifyTaskTotal, 10) || 0;
        const taskTotal = inputsModified
            ? listTotal
            : Math.max(0, (active || $scope.startLaunchPending) ? Math.max(queueTotal, apifyTotal, listTotal) : (queueTotal || apifyTotal || listTotal));

        const rawCompleted = inputsModified
            ? 0
            : Math.max(0, Math.min(taskTotal || Number.MAX_SAFE_INTEGER, Math.max(parseInt(q.completedTasks, 10) || 0, parseInt(q.apiTasksSettled, 10) || 0)));

        const runId = String(q.runEventId || '');
        if (inputsModified || $scope._isClearedSession) {
            $scope._monotonicTaskCompleted = 0;
        } else if (runId && $scope._monotonicProgressRunId !== runId) {
            $scope._monotonicProgressRunId = runId;
            $scope._monotonicTaskCompleted = rawCompleted;
        } else if (active || (rawCompleted > 0 && status !== 'idle' && status !== 'cleared')) {
            $scope._monotonicTaskCompleted = Math.max($scope._monotonicTaskCompleted || 0, rawCompleted);
        } else if (!active && rawCompleted === 0 && (status === 'idle' || status === 'cleared' || status === 'preparing' || status === 'starting')) {
            $scope._monotonicTaskCompleted = 0;
        }

        const taskCompleted = inputsModified
            ? 0
            : Math.min(taskTotal || Number.MAX_SAFE_INTEGER, Math.max(rawCompleted, $scope._monotonicTaskCompleted || 0));

        const apiTotal = Math.max(0, inputsModified ? taskTotal : (parseInt(q.apiTasksTotal, 10) || taskTotal));
        const apiDone = inputsModified ? 0 : Math.max(0, parseInt(q.apiTasksDone, 10) || 0);
        const apiFailed = inputsModified ? 0 : Math.max(0, parseInt(q.apiTasksFailed, 10) || 0);
        const apiSettled = inputsModified
            ? 0
            : Math.max(taskCompleted, Math.min(apiTotal || Number.MAX_SAFE_INTEGER, parseInt(q.apiTasksSettled, 10) || (apiDone + apiFailed)));
        const domTotal = inputsModified ? 0 : Math.max(0, parseInt(q.domTotal, 10) || 0);
        const domProcessed = inputsModified ? 0 : Math.max(0, Math.min(domTotal || Number.MAX_SAFE_INTEGER, parseInt(q.domProcessed, 10) || 0));
        const provider = String(q.provider || '').toLowerCase();
        const googleFlow = !inputsModified && (provider === 'googlemaps' || /google_/.test(status) || domTotal > 0);
        const hasSessionProgress = taskTotal > 0 || apiTotal > 0 || domTotal > 0 || (q.scrapedCount || 0) > 0 || active || $scope.startLaunchPending;

        if (!hasSessionProgress) {
            $scope.progressData = {
                completed: 0,
                completedSettled: 0,
                taskCompleted: 0,
                taskTotal: 0,
                currentTaskIndex: 0,
                total: 0,
                percent: 0,
                percentExact: 0,
                phase: 'Ready',
                detail: ''
            };
            return;
        }

        const currentTaskIdx = Math.max(
            0,
            Math.min(
                taskTotal || Number.MAX_SAFE_INTEGER,
                (active || $scope.startLaunchPending) && taskTotal > 0
                    ? Math.max(1, Math.min(taskTotal, (parseInt(q.currentTaskIndex, 10) || (taskCompleted + 1))))
                    : taskCompleted
            )
        );
        let completed = (terminal && !inputsModified) ? taskTotal : taskCompleted;
        let total = taskTotal;
        let phase = 'Searches';
        let detail = taskTotal ? (completed + '/' + taskTotal + ' searches') : '';
        let percentExact = (terminal && !inputsModified) ? 100 : (taskTotal > 0 ? (completed / taskTotal) * 100 : 0);

        if (googleFlow) {
            const effectiveApiDone = domTotal > 0 ? Math.max(apiSettled, taskCompleted + (domProcessed > 0 || q.producerDone ? 1 : 0)) : apiSettled;
            const apiRatio = apiTotal ? Math.min(1, effectiveApiDone / apiTotal) : (domTotal > 0 ? 1 : 0);
            const domRatio = domTotal ? Math.min(1, domProcessed / domTotal) : 0;
            const domStarted = domTotal > 0 || /google_dom|google_profile|dataset_saved/.test(status);
            // If multi-location search (apiTotal > 1), weight task completion heavily so 1/71 never jumps to 85% on the first location
            if (apiTotal > 1) {
                const currentTaskDomBonus = (domStarted && effectiveApiDone <= apiTotal) ? (domRatio / apiTotal) : 0;
                const overallTaskRatio = Math.min(1, (taskCompleted / apiTotal) + currentTaskDomBonus);
                percentExact = overallTaskRatio * 100;
            } else {
                percentExact = domStarted ? (15 * apiRatio + 85 * domRatio) : (15 * apiRatio);
            }
            if (domTotal > 0 && domProcessed >= domTotal && (parseInt(q.domPending, 10) || 0) === 0 && (parseInt(q.domRunning, 10) || 0) === 0 && (q.producerDone || effectiveApiDone >= apiTotal) && taskCompleted >= taskTotal) {
                percentExact = 100;
            }
            phase = domStarted ? 'Profiles' : 'API searches';
            detail = taskTotal ? (taskCompleted + '/' + taskTotal + ' tasks · ' + domProcessed + '/' + domTotal + ' profiles') : (domProcessed + '/' + domTotal + ' profiles');
        }

        if (terminal && !inputsModified && !active && !$scope.startLaunchPending) percentExact = 100;
        if (stopped || active || $scope.startLaunchPending) percentExact = Math.min(99.4, percentExact);
        if (inputsModified) percentExact = 0;
        percentExact = Math.max(0, Math.min(100, percentExact));

        $scope.progressData = {
            completed: taskCompleted,
            completedSettled: taskCompleted,
            taskCompleted: taskCompleted,
            taskTotal: taskTotal,
            currentTaskIndex: currentTaskIdx,
            total: taskTotal,
            percent: Math.round(percentExact),
            percentExact: percentExact,
            phase: phase,
            detail: detail,
            apiCompleted: (active || $scope.startLaunchPending) && apiTotal > 0 ? currentTaskIdx : apiSettled,
            apiTotal: apiTotal,
            domCompleted: domProcessed,
            domTotal: domTotal,
            inputsModified: inputsModified
        };
    };


    // Provide a stub for percentComplete to avoid undefined errors prior to
    // the later compatibility definition.
    $scope.percentComplete = () => {
        return $scope.progressData;
    };
    
    /* ----------------------------- On Local Change ---------------------------- */
    // The service worker can persist several result batches within a few
    // milliseconds. Reading/applying every notification separately makes
    // Angular evaluate local.collect.length repeatedly in one digest and can
    // trigger [$rootScope:infdig]. Coalesce to the latest storage snapshot.
    let localChangeTimer = null;
    let localChangeSerial = 0;
    let localReadSerial = 0;
    let localAppliedSerial = 0;
    $box.onLocalChange(() => {
        // v87 leading throttle instead of trailing debounce. Rapid background
        // writes used to keep clearing the timer forever, starving the live table
        // while KPI cards continued to move. One snapshot is now applied at least
        // every ~55ms during a busy stream.
        localChangeSerial += 1;
        if (localChangeTimer) return;
        localChangeTimer = setTimeout(() => {
            localChangeTimer = null;
            const readSerial = ++localReadSerial;
            const generation = $scope._canonicalGeneration;
            $box.getLocal(local => {
                if (readSerial < localAppliedSerial || generation !== $scope._canonicalGeneration) return;
                // v83 migration guard: storage can contain a model written by an
                // older extension build without nested runtime objects.  Always
                // merge defaults before Angular consumes it so bindings such as
                // local._taskManager.isWorking can never dereference undefined.
                const defaultLocal = $box.getDefaultLocalModel ? $box.getDefaultLocalModel() : {};
                local = Object.assign({}, defaultLocal || {}, local || {});
                local._taskManager = Object.assign({ isWorking: false, activeTask: null, searchTabId: null }, (defaultLocal && defaultLocal._taskManager) || {}, local._taskManager || {});
                local._notifications = Object.assign({ last_show_notification_hash: '', list: [] }, (defaultLocal && defaultLocal._notifications) || {}, local._notifications || {});
                if (!Array.isArray(local._notifications.list)) local._notifications.list = [];
                local.apifyQueue = Object.assign({}, (defaultLocal && defaultLocal.apifyQueue) || {}, local.apifyQueue || {});
                local.apifySettings = Object.assign({}, (defaultLocal && defaultLocal.apifySettings) || {}, local.apifySettings || {});
                if (!Array.isArray(local.collect)) local.collect = [];
                if (!Array.isArray(local.taskList)) local.taskList = [];
            /*
             * Always remove duplicate entries based on the unique cid field
             * before assigning the collection to the view model.  This keeps
             * the displayed record count consistent with the data grid,
             * avoiding discrepancies where the dashboard count lags behind
             * the true number of unique items.  Without deduplication here
             * stale or duplicate entries could persist in local.collect even
             * though the data grid (which is keyed by cid) only tracks
             * unique rows.
             */
            local.collect = dedupeDashboardRows(local.collect || []);
            const advertisedStoreCount = Math.max(0, parseInt(local.resultStoreCount, 10) || 0, parseInt((local.apifyQueue || {}).scrapedCount, 10) || 0);
            const qStatus = String((local.apifyQueue || {}).status || '').toLowerCase();
            const isClearedState = qStatus === 'idle' && advertisedStoreCount === 0 && (!local.collect || local.collect.length === 0) && !PocketLeadsRunState.isRunning(local);
            const sameRun = !isClearedState && ((local.apifyQueue || {}).runEventId === (($scope.local || {}).apifyQueue || {}).runEventId);
            if (isClearedState) {
                $scope._monotonicResultCount = 0;
                $scope._monotonicTaskCompleted = 0;
            }
            // Preserve live in-memory rows & email/social enrichments during the same session
            if ((sameRun || $scope.local && $scope.local.isScrapingEmail) && $scope.local && Array.isArray($scope.local.collect) && $scope.local.collect.length > 0 && !isClearedState) {
                const fullRows = $scope.local.collect.slice();
                const rowKey = row => String((row && (row.place_id || row.cid || row.map_link || row.phone || row.company_name || ((row.company_name || row.name || '') + '|' + (row.address || '')))) || '');
                const indexByKey = new Map();
                fullRows.forEach((row, idx) => indexByKey.set(rowKey(row), idx));
                (local.collect || []).forEach(row => {
                    const key = rowKey(row);
                    if (key && indexByKey.has(key)) fullRows[indexByKey.get(key)] = Object.assign({}, row, fullRows[indexByKey.get(key)]);
                    else { indexByKey.set(key, fullRows.length); fullRows.push(row); }
                });
                const maxKeep = ($scope.local && $scope.local.isScrapingEmail) ? Math.max(5000, fullRows.length) : 5000;
                local.collect = dedupeDashboardRows(fullRows).slice(-maxKeep);
                if ($scope.local && $scope.local.isScrapingEmail) local.isScrapingEmail = true;
            }
            const monotonicFloor = (sameRun && !isClearedState)
                ? Math.max(0, parseInt($scope._monotonicResultCount, 10) || 0, parseInt($scope.local && $scope.local.resultStoreCount, 10) || 0)
                : 0;
            const effectiveStoreCount = isClearedState
                ? 0
                : Math.max(advertisedStoreCount, monotonicFloor, Array.isArray(local.collect) ? local.collect.length : 0);
            local.resultStoreCount = effectiveStoreCount;
            local.collectIsPreview = effectiveStoreCount > (Array.isArray(local.collect) ? local.collect.length : 0);
            $scope._monotonicResultCount = effectiveStoreCount;
            if (effectiveStoreCount === 0 && !local.collectIsPreview) {
                local.collect = [];
                $scope.resultStoreHydrated = false;
            }
            $scope.$applyAsync(() => {
                if (readSerial < localAppliedSerial || generation !== $scope._canonicalGeneration) return;
                localAppliedSerial = readSerial;
                if (!sameRun) {
                    $scope._canonicalGeneration++;
                    $scope._pendingResultEdits.clear();
                    if ($scope._resultStoreSyncTimer) clearTimeout($scope._resultStoreSyncTimer);
                    $scope._resultStoreSyncTimer = null;
                    $scope.resultStoreHydrated = false;
                }
                // Do not log every storage event.  DevTools retains console
                // arguments, which can materially increase memory during long runs.
                $scope.local = local;
                if (typeof window !== 'undefined' && local && local.country) window.localCountry = local.country;
                // v92 completion watchdog: chrome.runtime terminal messages can be
                // dropped if the dashboard/service worker wakes at an awkward moment.
                // Persisted queue state is authoritative, so a completed transition
                // must still surface the dashboard Download + Close modal exactly once.
                try {
                    const isActivelyRunningNow = !!(local && (local.status || (local._taskManager && local._taskManager.isWorking))) || PocketLeadsRunState.isRunning(local);
                    if (isActivelyRunningNow) {
                        $scope._wasRunningInThisSession = true;
                    }
                    const terminalStatus = String(local && local.apifyQueue && local.apifyQueue.status || '').toLowerCase();
                    const terminalReady = /^(completed|completed_with_errors)$/.test(terminalStatus)
                        && !isActivelyRunningNow
                        && !(local && local.apifyQueue && local.apifyQueue.resumeAvailable);
                    const runCompletionSig = String(
                        (local && local.apifyQueue && (local.apifyQueue.runEventId || local.apifyQueue.finishedAt || local.apifyQueue.startedAt)) ||
                        (local && local.resultStoreCount) ||
                        'done'
                    );
                    if (!$scope._initialBootStorageChecked) {
                        $scope._initialBootStorageChecked = true;
                        if (terminalReady) {
                            // Already completed before APK/dashboard was opened — just show status, NEVER show popup or notification on app open!
                            $scope.scrapingCompleteShown = true;
                            try { localStorage.setItem('pl_ack_completed_run_sig_v1', runCompletionSig); } catch (_) {}
                        }
                    } else if (terminalReady && !$scope.scrapingCompleteShown && !$scope.waChecking && !$scope.suppressScrapingComplete) {
                        let lastAckSig = '';
                        try { lastAckSig = localStorage.getItem('pl_ack_completed_run_sig_v1') || ''; } catch (_) {}
                        if (lastAckSig && lastAckSig === runCompletionSig && !$scope._wasRunningInThisSession) {
                            $scope.scrapingCompleteShown = true;
                        } else if ($scope._wasRunningInThisSession || (lastAckSig !== runCompletionSig && (parseInt(local.resultStoreCount, 10) > 0 || (Array.isArray(local.collect) && local.collect.length > 0)))) {
                            try { localStorage.setItem('pl_ack_completed_run_sig_v1', runCompletionSig); } catch (_) {}
                            setTimeout(function(){
                                try {
                                    if (!$scope.scrapingCompleteShown && typeof $scope.handleScrapingComplete === 'function') {
                                        $scope.handleScrapingComplete();
                                    }
                                } catch (e) { console.warn('Completion watchdog failed', e); }
                            }, 0);
                        }
                    }
                } catch (e) {}
                refreshDashboardMetricCounts(local.collect || []);
                try {
                    const targetStoreCount = Math.max(0, parseInt(local.resultStoreCount, 10) || 0);
                    const expectedPreviewCount = Math.min(5000, targetStoreCount);
                    if (expectedPreviewCount > (Array.isArray(local.collect) ? local.collect.length : 0) && typeof $scope.syncLiveCanonicalTable === 'function') {
                        $scope.syncLiveCanonicalTable(targetStoreCount);
                    }
                } catch (e) {}
                /*
                 * If the grid has not yet been created, build it once to
                 * initialise the data source.  Otherwise, avoid
                 * reinitialising the grid on every change to prevent the
                 * pager from resetting or the scroll position jumping.  When
                 * the grid already exists we push new items into the
                 * productsStore and update existing rows.  This keeps
                 * scrolling stable while scraping results are inserted.
                 */
                const nextCollectSignature = computeCollectUiSignature(local.collect || []);
                const collectChanged = nextCollectSignature !== lastCollectUiSignature;
                const deferHiddenMobileGrid = ($scope.viewMode === 'mobile' && !$scope.mobileDataDrawerOpen && PocketLeadsRunState.isRunning(local));
                if (!dataGrid && !deferHiddenMobileGrid) {
                    // Build from THIS already-merged snapshot. Re-reading storage here
                    // can race the live IndexedDB delta and create an empty/stale grid.
                    lastCollectDataCount = 0;
                    buildDataTable(local);
                    lastCollectUiSignature = nextCollectSignature;
                } else if (collectChanged && !deferHiddenMobileGrid) {
                    // Only touch the heavy DevExtreme grid when result rows actually changed.
                    // Progress updates now stay lightweight and render immediately.
                    let scrollTop = 0;
                    try {
                        const scrollable = dataGrid.getScrollable && dataGrid.getScrollable();
                        if (scrollable && typeof scrollable.scrollTop === 'function') scrollTop = scrollable.scrollTop();
                    } catch (err) {
                        console.warn('Unable to capture scroll position', err);
                    }
                    insertIntoDataTable(local);
                    updateDataTable(local);
                    try {
                        const scrollable2 = dataGrid.getScrollable && dataGrid.getScrollable();
                        if (scrollable2 && typeof scrollable2.scrollTo === 'function') scrollable2.scrollTo({ top: scrollTop });
                    } catch (err) {
                        console.warn('Unable to restore scroll position', err);
                    }
                    lastCollectDataCount = local.collect.length;
                    lastCollectUiSignature = nextCollectSignature;
                }

                // Always update the set of discovered phone numbers to ensure that
                // waTotal reflects the total number of unique phone numbers seen
                // during the current scraping session.  This update occurs
                // regardless of whether a WA run is active or pending.  When WA
                // progress is visible (either because waFinished > 0 or a run
                // has been started), the denominator will update in real time.
                try {
                    const rows = Array.isArray(local.collect) ? local.collect : [];
                    let newlyDiscovered = 0;
                    rows.forEach(row => {
                        const raw = row && row.phone ? String(row.phone).trim() : '';
                        if (!raw) return;
                        let digits = raw.replace(/\D/g, '');
                        digits = digits.replace(/^0+/, '');
                        if (!digits) return;
                        const cid = row.cid;
                        if (cid && !$scope.waDiscoveredIds[cid]) {
                            $scope.waDiscoveredIds[cid] = true;
                            newlyDiscovered++;
                        }
                    });
                    // Increment the total count by the number of newly discovered numbers.
                    // This count grows monotonically and will never decrease.  Even
                    // when WA is not active, we keep track of new numbers so that a
                    // subsequent run can resume from the correct denominator.
                    if (newlyDiscovered > 0) {
                        $scope.waTotal += newlyDiscovered;
                    }
                } catch (discErr) {
                    console.warn('onLocalChange: error updating discovered phone numbers', discErr);
                }

                // When a WhatsApp number check is active or pending completion,
                // identify newly discovered phone numbers that still need to be
                // processed in the current run.  New numbers will be either
                // appended to the existing WA queue or will trigger a new run
                // if the previous run has finished.  Note that we no longer
                // update waDiscoveredIds or waTotal inside this block; those
                // updates are performed above to ensure consistent totals even
                // when WA is not running.
                if (($scope.waChecking || $scope.waPendingComplete) && !$scope.waApiMode) {
                    try {
                        const rows = Array.isArray(local.collect) ? local.collect : [];
                        const newItems = [];
                        rows.forEach((row, idx) => {
                            const raw = row && row.phone ? String(row.phone).trim() : '';
                            if (!raw) return;
                            let digits = raw.replace(/\D/g, '');
                            digits = digits.replace(/^0+/, '');
                            if (!digits) return;
                            const cid = row.cid;
                            // Skip numbers already processed or currently enqueued
                            if ($scope.waCompletedIds[cid] || $scope.waEnqueuedIds[cid]) {
                                return;
                            }
                            newItems.push({ number: digits, rowId: idx });
                            // Mark the cid and row index as enqueued
                            if (cid) {
                                $scope.waEnqueuedIds[cid] = true;
                            }
                            $scope.waEnqueuedRows[idx] = true;
                        });
                        if (newItems.length > 0) {
                            if ($scope.waChecking) {
                                // A run is in progress; append the new numbers.
                                try {
                                    chrome.runtime.sendMessage({ action: 'append_wa_check', items: newItems }, function() {});
                                } catch (err) {
                                    console.warn('Failed to append WA numbers', err);
                                }
                            } else {
                                // A run completed earlier and we were waiting for new numbers.
                                // Start a new WA run now.  Preserve finished count, reset the
                                // pending flag and mark the new run as active.
                                $scope.waChecking = true;
                                $scope.waPendingComplete = false;
                                // Reset enqueued rows and repopulate them based on newItems.
                                $scope.waEnqueuedRows = {};

    // -----------------------------------------------------------------------
    // Country list for the dashboard selector
    //
    // Provide a comprehensive list of countries and territories that users can
    // select from when specifying the country for their Google Maps
    // queries.  The array below is derived from the ISO 3166 standard via
    // the pycountry library.  Each country name appears exactly as
    // recognised by international standards.  If additional entities are
    // required, they can be appended to this array.
    $scope.countries = [
        "Aruba", "Afghanistan", "Angola", "Anguilla", "Åland Islands", "Albania", "Andorra", "United Arab Emirates", "Argentina",
        "Armenia", "American Samoa", "Antarctica", "French Southern Territories", "Antigua and Barbuda", "Australia", "Austria",
        "Azerbaijan", "Burundi", "Belgium", "Benin", "Bonaire, Sint Eustatius and Saba", "Burkina Faso", "Bangladesh", "Bulgaria",
        "Bahrain", "Bahamas", "Bosnia and Herzegovina", "Saint Barthélemy", "Belarus", "Belize", "Bermuda",
        "Bolivia, Plurinational State of", "Brazil", "Barbados", "Brunei Darussalam", "Bhutan", "Bouvet Island", "Botswana",
        "Central African Republic", "Canada", "Cocos (Keeling) Islands", "Switzerland", "Chile", "China", "Côte d'Ivoire",
        "Cameroon", "Congo, The Democratic Republic of the", "Congo", "Cook Islands", "Colombia", "Comoros", "Cabo Verde",
        "Costa Rica", "Cuba", "Curaçao", "Christmas Island", "Cayman Islands", "Cyprus", "Czechia", "Germany", "Djibouti",
        "Dominica", "Denmark", "Dominican Republic", "Algeria", "Ecuador", "Egypt", "Eritrea", "Western Sahara", "Spain",
        "Estonia", "Ethiopia", "Finland", "Fiji", "Falkland Islands (Malvinas)", "France", "Faroe Islands",
        "Micronesia, Federated States of", "Gabon", "United Kingdom", "Georgia", "Guernsey", "Ghana", "Gibraltar", "Guinea",
        "Guadeloupe", "Gambia", "Guinea-Bissau", "Equatorial Guinea", "Greece", "Grenada", "Greenland", "Guatemala",
        "French Guiana", "Guam", "Guyana", "Hong Kong", "Heard Island and McDonald Islands", "Honduras", "Croatia", "Haiti",
        "Hungary", "Indonesia", "Isle of Man", "India", "British Indian Ocean Territory", "Ireland", "Iran, Islamic Republic of",
        "Iraq", "Iceland", "Israel", "Italy", "Jamaica", "Jersey", "Jordan", "Japan", "Kazakhstan", "Kenya", "Kyrgyzstan",
        "Cambodia", "Kiribati", "Saint Kitts and Nevis", "Korea, Republic of", "Kuwait", "Lao People's Democratic Republic",
        "Lebanon", "Liberia", "Libya", "Saint Lucia", "Liechtenstein", "Sri Lanka", "Lesotho", "Lithuania", "Luxembourg",
        "Latvia", "Macao", "Saint Martin (French part)", "Morocco", "Monaco", "Moldova, Republic of", "Madagascar", "Maldives",
        "Mexico", "Marshall Islands", "North Macedonia", "Mali", "Malta", "Myanmar", "Montenegro", "Mongolia",
        "Northern Mariana Islands", "Mozambique", "Mauritania", "Montserrat", "Martinique", "Mauritius", "Malawi", "Malaysia",
        "Mayotte", "Namibia", "New Caledonia", "Niger", "Norfolk Island", "Nigeria", "Nicaragua", "Niue", "Netherlands",
        "Norway", "Nepal", "Nauru", "New Zealand", "Oman", "Pakistan", "Panama", "Pitcairn", "Peru", "Philippines", "Palau",
        "Papua New Guinea", "Poland", "Puerto Rico", "Korea, Democratic People's Republic of", "Portugal", "Paraguay",
        "Palestine, State of", "French Polynesia", "Qatar", "Réunion", "Romania", "Russian Federation", "Rwanda", "Saudi Arabia",
        "Sudan", "Senegal", "Singapore", "South Georgia and the South Sandwich Islands", "Saint Helena, Ascension and Tristan da Cunha",
        "Svalbard and Jan Mayen", "Solomon Islands", "Sierra Leone", "El Salvador", "San Marino", "Somalia",
        "Saint Pierre and Miquelon", "Serbia", "South Sudan", "Sao Tome and Principe", "Suriname", "Slovakia", "Slovenia",
        "Sweden", "Eswatini", "Sint Maarten (Dutch part)", "Seychelles", "Syrian Arab Republic", "Turks and Caicos Islands", "Chad",
        "Togo", "Thailand", "Tajikistan", "Tokelau", "Turkmenistan", "Timor-Leste", "Tonga", "Trinidad and Tobago", "Tunisia",
        "Türkiye", "Tuvalu", "Taiwan, Province of China", "Tanzania, United Republic of", "Uganda", "Ukraine",
        "United States Minor Outlying Islands", "Uruguay", "United States", "Uzbekistan", "Holy See (Vatican City State)",
        "Saint Vincent and the Grenadines", "Venezuela, Bolivarian Republic of", "Virgin Islands, British", "Virgin Islands, U.S.",
        "Viet Nam", "Vanuatu", "Wallis and Futuna", "Samoa", "Yemen", "South Africa", "Zambia", "Zimbabwe"
    ];

    // Expose the full countries list on the global window so that non‑Angular
    // scripts (e.g. DevExtreme SelectBox initialiser) can access it without
    // relying on scope traversal.  Without this assignment, the country
    // dropdown may appear empty because jQuery code cannot retrieve the
    // Angular scope before it initialises.
    if (typeof window !== 'undefined') {
        window.countryList = $scope.countries;
    }
                                $scope.waEnqueuedIds = {};
                                newItems.forEach(item => {
                                    const rowIdx = item.rowId;
                                    const row = rows[rowIdx];
                                    if (row && row.cid) {
                                        $scope.waEnqueuedIds[row.cid] = true;
                                    }
                                    $scope.waEnqueuedRows[rowIdx] = true;
                                });
                                try {
                                    chrome.runtime.sendMessage({ action: 'start_wa_check', items: newItems }, function() {});
                                } catch (startErr) {
                                    console.warn('Failed to start WA check for new items', startErr);
                                }
                            }
                        } else {
                            // No new items found.  If a WA run had finished and we were
                            // waiting for new numbers, and scraping has also finished,
                            // finalise the WA check now.  Without this, the WA
                            // completion popup may never appear when scraping ends
                            // without producing additional numbers.
                            if (!$scope.waChecking && $scope.waPendingComplete && !$scope.scrapingActive) {
                                $scope.waPendingComplete = false;
                                // Ensure finished count reflects the number of completed IDs.
                                $scope.waFinished = Object.keys($scope.waCompletedIds).length;
                                try {
                                    $scope.handleWaCheckComplete($scope.waFinished, $scope.waTotal);
                                } catch (completeErr) {
                                    console.warn('Error finalising WA check on local change', completeErr);
                                }
                            }
                        }
                    } catch (appendErr) {
                        console.warn('Error while processing WA numbers on local change', appendErr);
                    }
                }
                // Update scrapingActive based on the current status.  This
                // ensures WA logic accurately knows whether scraping is
                // ongoing or has finished after each local change.  Use
                // isScrapingActive() helper to compute the state.
                try {
                    if (typeof $scope.isScrapingActive === 'function') {
                        $scope.scrapingActive = !!$scope.isScrapingActive();
                    }
                } catch (stateErr) {
                    // ignore errors computing scraping state
                }
                // Update UI state based on current status
                if (typeof $scope.recalculateScrapingTimeText === 'function') $scope.recalculateScrapingTimeText();
                $scope.updateUIState();
            });
            });
        }, ($scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking))) ? 380 : 80);
    });
    /* ----------------------------- On Local Change ---------------------------- */
    
    /* ------------------------------- Init Local ------------------------------- */
    $box.getLocal(local => {
        $scope.$apply(() => {
            // Ensure proper initialization with safe defaults.  Retrieve
            // the default model from $box (typically an empty object)
            // and merge it with any persisted values.  Provide an empty
            // object when local is undefined to avoid TypeErrors on
            // spreading undefined.
            const defaultLocal = $box.getDefaultLocalModel();
            const persisted = local || {};
            $scope.local = { ...defaultLocal, ...persisted };
            refreshDashboardMetricCounts($scope.local.collect || []);

            // Expose the currently selected country to the global window.  This allows
            // non‑Angular scripts (e.g. DevExtreme SelectBox initialiser) to
            // populate the SelectBox with the correct initial value when the
            // dashboard loads.  If undefined, default to an empty string.
            if (typeof window !== 'undefined') {
                window.localCountry = $scope.local && $scope.local.country ? $scope.local.country : '';
            }
            // Ensure notifications structure exists with a list array
            if (!$scope.local._notifications || !$scope.local._notifications.list) {
                $scope.local._notifications = { list: [] };
            }
            // Ensure the task manager object exists with sensible defaults
            if (!$scope.local._taskManager) {
                $scope.local._taskManager = { isWorking: false, activeTask: null, searchTabId: null };
            } else {
                if (typeof $scope.local._taskManager.isWorking !== 'boolean') {
                    $scope.local._taskManager.isWorking = false;
                }
                if (!('activeTask' in $scope.local._taskManager)) {
                    $scope.local._taskManager.activeTask = null;
                }
                if (!('searchTabId' in $scope.local._taskManager)) {
                    $scope.local._taskManager.searchTabId = null;
                }
            }

            // Apify direct dataset flow defaults. Persisted users may not have these
            // keys yet, so initialise them without disturbing existing values.
            $scope.local.fastMode = false;
            $scope.local.apifySettings = Object.assign({
                provider: 'sheet-managed',
                apiKeyRow: 0,
                apiUsageLimit: 0,
                autoPageMode: true,
                maxPagesPerSearch: 50,
                maxResultsPerSearch: 1000,
                countryFilter: 'India',
                countryCodeFilter: 'IN',
                enforceCountryFilter: true,
                streamResults: true
            }, $scope.local.apifySettings || {});
            const _permSavedCountry = getPermanentUserSelectedCountry();
            $scope.local.country = _permSavedCountry;
            $scope.local.countryCode = _permSavedCountry ? dashboardCountryCode(_permSavedCountry) : '';
            $scope.local.apifySettings.countryFilter = $scope.local.country;
            $scope.local.apifySettings.countryCodeFilter = $scope.local.countryCode;
            $scope.local.apifySettings.enforceCountryFilter = !!$scope.local.country;
            if (!_permSavedCountry && typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                chrome.storage.local.get(['pl_user_selected_country_v1'], function(res) {
                    const fromChrome = res && res.pl_user_selected_country_v1 ? String(res.pl_user_selected_country_v1).trim() : '';
                    if (fromChrome) {
                        $scope.safeApply(function() {
                            $scope.setCountry(fromChrome);
                        });
                    }
                });
            }
            // Manual page selector removed: city/location searches run in auto-page mode
            // up to the safe internal cap, while pincode searches are capped to 3 pages.
            $scope.local.apifySettings.autoPageMode = true;
            $scope.local.apifySettings.maxPagesPerSearch = 50;
            $scope.local.apifySettings.maxResultsPerSearch = 1000;
            // Clean old locally-stored API credentials from previous builds.
            $scope.local.apifySettings.provider = 'sheet-managed';
            $scope.local.apifySettings.apiKeyRow = 0;
            $scope.local.apifySettings.apiUsageLimit = $scope.local.apifySettings.apiUsageLimit ?? 0;
            $scope.local.apifySettings.apiToken = '';
            $scope.local.apifySettings.actorId = '';
            $scope.local.apifyQueue = Object.assign({
                status: 'idle',
                statusMessage: '',
                provider: '',
                currentQuery: '',
                currentProfileUrl: '',
                totalPlaceIds: 0,
                totalApiResults: 0,
                totalTasks: 0,
                completedTasks: 0,
                apiTasksTotal: 0,
                apiTasksDone: 0,
                apiTasksFailed: 0,
                apiTasksSettled: 0,
                domTotal: 0,
                domProcessed: 0,
                domPending: 0,
                domRunning: 0,
                domSaved: 0,
                domFailed: 0,
                domSkipped: 0,
                apiSwitchCount: 0,
                scrapedCount: 0,
                failedCount: 0,
                filteredCount: 0,
                duplicateSkippedCount: 0,
                apiKeyRow: 0,
                apiUsageBefore: 0,
                apiUsageAfter: 0,
                apiUsageLimit: 0,
                pendingPlaceIds: [],
                skipped: [],
                processing: null,
                completed: [],
                failed: [],
                retryCount: {},
                placeIdQueue: [],
                resumeAvailable: false,
                producerDone: false,
                consumerDone: false,
                domConcurrency: 1,
                domSuccessStreak: 0,
                domSuccessRate: 0,
                domTransientErrors: 0,
                lastCheckpointAt: '',
                resultStoreCount: 0,
                managedTabIds: []
            }, $scope.local.apifyQueue || {});
            if (typeof $scope.local.showApifySettings === 'undefined') {
                $scope.local.showApifySettings = false;
            }
            $scope.local.showLimitModal = false;

            // Remove any duplicate rows from the collect array on load.  If
            // previous sessions stored duplicate entries, this ensures the
            // dashboard's result count reflects only unique records.
            $scope.local.collect = dedupeDashboardRows($scope.local.collect || []);
            $scope.local.collectIsPreview = !!$scope.local.collectIsPreview;
            // A full hydrated collection is authoritative. Never retain a
            // stale preview/queue count (for example 921) when the actual
            // unique rows available to the grid are 650.
            $scope.local.resultStoreCount = $scope.local.collectIsPreview
                ? Math.max(parseInt($scope.local.resultStoreCount, 10) || 0, $scope.local.collect.length)
                : $scope.local.collect.length;
            $scope.local.resultStoreMigrated = !!$scope.local.resultStoreMigrated;

            // Rebuild the data table on first load to ensure the grid row
            // count matches the deduplicated collection.  Without resetting
            // the last count here the previous session's duplicate rows may
            // linger in the grid, leading to inconsistent counts between
            // "RESULTS FOUND" and the grid's pager.
            lastCollectDataCount = 0;
            buildDataTable();

            // Preserve persisted background state when the dashboard is reopened.
            // Resetting status here made an active run appear idle and stopped live
            // progress until another storage event happened.
            if (!$scope.local._taskManager) {
                $scope.local._taskManager = { isWorking: false, activeTask: null, searchTabId: null };
            }
            // APK Close & Reopen Normalization:
            // When APK is closed completely and reopened, any previously active extraction must be stopped,
            // and if unfinished progress exists, 'Resume' must be shown while preserving all existing data.
            try {
                const qBoot = $scope.local.apifyQueue || {};
                const wasRunningOnBoot = !!($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking) ||
                    /starting|preparing|resuming|searching|streaming|running|draining|switching|switched|backend_ready|scraping|processing|api_ready|enriching/i.test(String(qBoot.status || '')));
                const isApkOrInProcess = !!(typeof window !== 'undefined' && (window.__plInProcessAndroid || window.AndroidChromeBridge));
                const lastUpdMs = Date.parse(qBoot.lastUpdatedAt || '');
                const isStaleRun = wasRunningOnBoot && (isApkOrInProcess || !Number.isFinite(lastUpdMs) || (Date.now() - lastUpdMs > 12000));
                if (isStaleRun && !window.__plBootNormalizedOnce) {
                    window.__plBootNormalizedOnce = true;
                    $scope.local.status = false;
                    $scope.local._taskManager.isWorking = false;
                    const rawSigBoot = String($scope.local.apifyTaskSignature || '');
                    const sigList = /^v38sig:/i.test(rawSigBoot) ? [] : rawSigBoot.split('\n').map(s => s.trim()).filter(Boolean);
                    const doneCnt = Math.max(0, parseInt(qBoot.completedTasks || qBoot.apiTasksSettled, 10) || 0);
                    const totCnt = Math.max(sigList.length, parseInt(qBoot.totalTasks || $scope.local.apifyTaskTotal, 10) || 0);
                    const hasPendProf = (Array.isArray(qBoot.placeIdQueue) && qBoot.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')))) || (Math.max(0, parseInt(qBoot.domPending, 10) || 0) > 0);
                    if ((!Array.isArray($scope.local.taskList) || $scope.local.taskList.length === 0) && sigList.length > 0 && doneCnt < sigList.length) {
                        $scope.local.taskList = sigList.slice(doneCnt);
                    }
                    const hasPendTasks = Array.isArray($scope.local.taskList) && $scope.local.taskList.length > 0;
                    const savedCnt = Math.max(parseInt($scope.local.resultStoreCount, 10) || 0, Array.isArray($scope.local.collect) ? $scope.local.collect.length : 0);
                    const isUnfinished = hasPendTasks || hasPendProf || (totCnt > 0 && doneCnt < totCnt) || (wasRunningOnBoot && String(qBoot.status || '').toLowerCase() !== 'completed');
                    if (isUnfinished) {
                        if ((!Array.isArray($scope.local.taskList) || $scope.local.taskList.length === 0) && sigList.length > 0) {
                            $scope.local.taskList = sigList.slice(Math.min(doneCnt, sigList.length - 1));
                        }
                        qBoot.status = 'stopped';
                        qBoot.resumeAvailable = true;
                        qBoot.statusMessage = 'Extraction paused · Tap Resume to continue';
                        $scope.local._taskManager.activeTask = 'openMap';
                    } else {
                        qBoot.status = savedCnt > 0 ? 'completed' : 'idle';
                        qBoot.resumeAvailable = false;
                        $scope.local._taskManager.activeTask = null;
                    }
                    $scope.local.apifyQueue = qBoot;
                    $box.setLocal($scope.local);
                } else {
                    window.__plBootNormalizedOnce = true;
                }
            } catch (_) {}
            // Never replay completion popup or notification on fresh APK/dashboard open!
            if (!$scope.isScrapingActive()) {
                $scope.scrapingCompleteShown = true;
                $scope._wasRunningInThisSession = false;
            }
            $scope.recalculateScrapingTimeText();
            $scope.updateUIState();
            setTimeout(() => {
                try { if (typeof $scope.hydrateResultsFromIndexedDB === 'function') $scope.hydrateResultsFromIndexedDB(0); } catch (e) {}
            }, 100);
        });
        
        /* Get the active tab URL*/
        // When retrieving the active tab, guard against undefined results.
        // On some mobile browsers (e.g. Kiwi on Android) the callback may
        // receive an empty array or an undefined tab.  Accessing tab.url
        // directly would throw a TypeError.  Instead, check for the
        // existence of the tab and url property and fall back to an
        // empty string when either is missing.
        $box.activeTab(tab => {
            $scope.$apply(() => {
                let url = '';
                try {
                    if (tab && typeof tab.url === 'string') {
                        url = tab.url;
                    }
                } catch (e) {
                    console.warn('Error reading active tab url', e);
                }
                $scope.local.activeTabUrl = url;
            });
        });
    });
    /* ------------------------------- Init Local ------------------------------- */
    
    // NEW: Function to update UI state based on scraping status
    $scope.updateUIState = () => {
        // Always recalculate progress metrics when updating UI state.  This
        // ensures the progress bar reflects the current number of tasks
        // completed and prevents stale progress values from persisting.
        $scope.updateProgress();

        const active = !!(PocketLeadsRunState.isRunning($scope.local) || $scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking));
        const queue = $scope.local.apifyQueue || {};
        if (active || /^(stopped|completed|completed_with_errors|failed)$/i.test(String(queue.status || ''))) {
            if (active) $scope.startLaunchPending = false;
        }
        const domAllProcessed = (parseInt(queue.domTotal, 10) || 0) > 0 && (parseInt(queue.domProcessed, 10) || 0) >= (parseInt(queue.domTotal, 10) || 0) && (parseInt(queue.domPending, 10) || 0) === 0 && (parseInt(queue.domRunning, 10) || 0) === 0;
        const hasPendingSearches = Array.isArray($scope.local.taskList) && $scope.local.taskList.length > 0;
        const hasPendingProfiles = !domAllProcessed && Array.isArray(queue.placeIdQueue) && queue.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
        const terminalStatus = /^(completed|completed_with_errors|dataset_saved|dataset_saved_with_errors|no_results|no_results_after_filter)$/i.test(String(queue.status || ''));
        const progressFinished = Number($scope.progressData && $scope.progressData.percent || 0) >= 100 || (domAllProcessed && !hasPendingSearches);
        const hasFinishedCleanly = !active && (terminalStatus || progressFinished) && !hasPendingProfiles && !hasPendingSearches;
        const queueErrorCode = String(queue.lastErrorCode || '').toUpperCase();
        const nonResumableCommercialStop = /LICENSE_(?:EXPIRED|CREDIT_EXHAUSTED|INACTIVE)|LICENCE_(?:EXPIRED|CREDIT_EXHAUSTED)|ALL_CREDITS_EXHAUSTED|PREFLIGHT_/i.test(queueErrorCode);
        const _curKwArr = Array.isArray($scope.local.keywordList) ? $scope.local.keywordList : [];
        const _curLocArr = Array.isArray($scope.local.locationList) ? $scope.local.locationList : [];
        const _curSigNow = (_curKwArr.length && _curLocArr.length) ? computeFastTaskSignature(_curKwArr, _curLocArr) : '';
        const _savedSigNow = String($scope.local.apifyTaskSignature || '').trim();
        const _sameSigNow = !_savedSigNow || !_curSigNow || _curSigNow === _savedSigNow;
        const resumable = _sameSigNow && !nonResumableCommercialStop && !hasFinishedCleanly && !active && (!!queue.resumeAvailable || hasPendingProfiles || (hasPendingSearches && /^(stopped|failed|paused_recoverable|partial_results|memory_recovery)$/i.test(String(queue.status || ''))));
        const hasFreshKw = (Array.isArray($scope.local.keywordList) && $scope.local.keywordList.length > 0) || String(($scope.local && $scope.local.keywordTextarea) || '').trim().length > 0;
        const hasFreshLoc = (Array.isArray($scope.local.locationList) && $scope.local.locationList.length > 0) || String(($scope.local && $scope.local.locationTextarea) || '').trim().length > 0;
        const hasFreshInput = hasFreshKw && hasFreshLoc;

        const launchPending = !!$scope.startLaunchPending;
        $scope.isStopEnabled = active;
        $scope.isStartEnabled = !active && !launchPending && (hasFreshInput || resumable) && $scope.licenseActive;
        $scope.startButtonText = launchPending ? "Starting…" : (active ? "Stop" : (resumable ? "Resume" : "Start"));
        $scope.resumeAvailable = resumable;
        if (hasFinishedCleanly && !launchPending) {
            queue.resumeAvailable = false;
            if (!terminalStatus && progressFinished) queue.status = 'completed';
            queue.statusMessage = queue.status === 'completed_with_errors' ? 'Scraping completed with some skipped or failed records.' : 'Scraping completed successfully.';
            const isExplicitlyLoggedOut = (typeof localStorage !== 'undefined' && localStorage.getItem('pl_explicit_logout_v1') === '1');
            if (isExplicitlyLoggedOut) {
                $scope.scrapingCompleteShown = true;
            } else if ($scope._wasRunningInThisSession && !$scope.scrapingCompleteShown && !$scope.waChecking && !$scope.suppressScrapingComplete && ((parseInt(queue.scrapedCount, 10) || 0) > 0 || (parseInt(queue.domProcessed, 10) || 0) > 0 || (parseInt($scope.local.resultStoreCount, 10) || 0) > 0 || /^completed/i.test(String(queue.status || '')))) {
                setTimeout(() => {
                    try {
                        if (!$scope.scrapingCompleteShown && typeof $scope.handleScrapingComplete === 'function') {
                            $scope.handleScrapingComplete();
                        }
                    } catch (_) {}
                }, 0);
            }
        }
        
        // Show/hide spinner only when there's a valid query and work
        // in progress.  This logic remains unchanged.
        $scope.showSpinner = !!($scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking)) &&
                            $scope.local.activeQuery && $scope.local.activeQuery !== " in ");
    };

    // ------------------------------------------------------------------------
    // Progress bar management
    // ------------------------------------------------------------------------
    /**
     * Holds the current progress metrics for the scrape.  The view binds to
     * this object rather than repeatedly invoking percentComplete() directly
     * from the template.  Updating a single object avoids unnecessary
     * recalculations during Angular's digest and ensures that the progress
     * bar always animates smoothly from 0% on the left to 100% on the right.
     * @type {{completed:number,total:number,percent:number}}
     */
    $scope.progressData = { completed: 0, total: 0, percent: 0 };

    /**
     * Recalculate the scraping progress based on the current keywords,
     * locations and remaining task list.  This function should be invoked
     * whenever the number of keywords or locations changes, or when tasks
     * are consumed by the scraper.  It updates `$scope.progressData` with
     * the completed count, total count and percent complete (rounded to an
     * integer).  When there are no tasks defined, all values are reset to
     * zero to avoid NaN widths in the progress bar.
     */
    $scope.updateProgress = function() {
        const local = $scope.local || {};
        const q = local.apifyQueue || {};
        const status = String(q.status || '').toLowerCase();
        const active = !!(PocketLeadsRunState.isRunning(local) || local.status || (local._taskManager && local._taskManager.isWorking));
        const terminal = /^(completed|completed_with_errors|dataset_saved|dataset_saved_with_errors)$/.test(status);
        const stopped = status === 'stopped' || status === 'paused_recoverable' || status === 'failed';

        const kwArr = Array.isArray(local.keywordList) ? local.keywordList : [];
        const locArr = Array.isArray(local.locationList) ? local.locationList : [];
        const listTotalKeywords = kwArr.length || $scope.getKeywordLineCount();
        const listTotalLocations = locArr.length || $scope.getLocationLineCount();
        const listTotal = (listTotalKeywords && listTotalLocations) ? (listTotalKeywords * listTotalLocations) : 0;

        const currentSig = (kwArr.length && locArr.length) ? computeFastTaskSignature(kwArr, locArr) : '';
        const savedSig = String(local.apifyTaskSignature || '').trim();
        const inputsModified = Boolean(!active && !$scope.startLaunchPending && currentSig && savedSig && currentSig !== savedSig);

        if ((status === 'idle' || $scope._isClearedSession) && !active && !$scope.startLaunchPending && (parseInt(q.scrapedCount, 10) || 0) === 0 && (parseInt(local.resultStoreCount, 10) || 0) === 0) {
            $scope._monotonicTaskCompleted = 0;
            $scope.progressData = {
                completed: 0,
                completedSettled: 0,
                taskCompleted: 0,
                taskTotal: listTotal,
                currentTaskIndex: 0,
                total: listTotal,
                percent: 0,
                percentExact: 0,
                phase: 'Ready',
                detail: listTotal ? ('0/' + listTotal + ' searches') : ''
            };
            return;
        }

        // If user edited Keywords/Locations while idle/stopped/completed, reflect the new target task total (e.g. 71)
        const queueTotal = parseInt(q.totalTasks, 10) || 0;
        const apifyTotal = parseInt(local.apifyTaskTotal, 10) || 0;
        const taskTotal = inputsModified
            ? listTotal
            : Math.max(0, (active || $scope.startLaunchPending) ? Math.max(queueTotal, apifyTotal, listTotal) : (queueTotal || apifyTotal || listTotal));

        const rawCompleted = inputsModified
            ? 0
            : Math.max(0, Math.min(taskTotal || Number.MAX_SAFE_INTEGER, Math.max(parseInt(q.completedTasks, 10) || 0, parseInt(q.apiTasksSettled, 10) || 0)));

        const runId = String(q.runEventId || '');
        if (inputsModified || $scope._isClearedSession) {
            $scope._monotonicTaskCompleted = 0;
        } else if (runId && $scope._monotonicProgressRunId !== runId) {
            $scope._monotonicProgressRunId = runId;
            $scope._monotonicTaskCompleted = rawCompleted;
        } else if (active || (rawCompleted > 0 && status !== 'idle' && status !== 'cleared')) {
            $scope._monotonicTaskCompleted = Math.max($scope._monotonicTaskCompleted || 0, rawCompleted);
        } else if (!active && rawCompleted === 0 && (status === 'idle' || status === 'cleared' || status === 'preparing' || status === 'starting')) {
            $scope._monotonicTaskCompleted = 0;
        }

        const taskCompleted = inputsModified
            ? 0
            : Math.min(taskTotal || Number.MAX_SAFE_INTEGER, Math.max(rawCompleted, $scope._monotonicTaskCompleted || 0));

        const apiTotal = Math.max(0, inputsModified ? taskTotal : (parseInt(q.apiTasksTotal, 10) || taskTotal));
        const apiDone = inputsModified ? 0 : Math.max(0, parseInt(q.apiTasksDone, 10) || 0);
        const apiFailed = inputsModified ? 0 : Math.max(0, parseInt(q.apiTasksFailed, 10) || 0);
        const apiSettled = inputsModified
            ? 0
            : Math.max(taskCompleted, Math.min(apiTotal || Number.MAX_SAFE_INTEGER, parseInt(q.apiTasksSettled, 10) || (apiDone + apiFailed)));
        const domTotal = inputsModified ? 0 : Math.max(0, parseInt(q.domTotal, 10) || 0);
        const domProcessed = inputsModified ? 0 : Math.max(0, Math.min(domTotal || Number.MAX_SAFE_INTEGER, parseInt(q.domProcessed, 10) || 0));
        const provider = String(q.provider || '').toLowerCase();
        const googleFlow = !inputsModified && (provider === 'googlemaps' || /google_/.test(status) || domTotal > 0);
        const hasSessionProgress = taskTotal > 0 || apiTotal > 0 || domTotal > 0 || (q.scrapedCount || 0) > 0 || active || $scope.startLaunchPending;

        if (!hasSessionProgress) {
            $scope.progressData = {
                completed: 0,
                completedSettled: 0,
                taskCompleted: 0,
                taskTotal: 0,
                currentTaskIndex: 0,
                total: 0,
                percent: 0,
                percentExact: 0,
                phase: 'Ready',
                detail: ''
            };
            return;
        }

        const currentTaskIdx = Math.max(
            0,
            Math.min(
                taskTotal || Number.MAX_SAFE_INTEGER,
                (active || $scope.startLaunchPending) && taskTotal > 0
                    ? Math.max(1, Math.min(taskTotal, (parseInt(q.currentTaskIndex, 10) || (taskCompleted + 1))))
                    : taskCompleted
            )
        );
        let completed = (terminal && !inputsModified) ? taskTotal : taskCompleted;
        let total = taskTotal;
        let phase = 'Searches';
        let detail = taskTotal ? (completed + '/' + taskTotal + ' searches') : '';
        let percentExact = (terminal && !inputsModified) ? 100 : (taskTotal > 0 ? (completed / taskTotal) * 100 : 0);

        if (googleFlow) {
            const effectiveApiDone = domTotal > 0 ? Math.max(apiSettled, taskCompleted + (domProcessed > 0 || q.producerDone ? 1 : 0)) : apiSettled;
            const apiRatio = apiTotal ? Math.min(1, effectiveApiDone / apiTotal) : (domTotal > 0 ? 1 : 0);
            const domRatio = domTotal ? Math.min(1, domProcessed / domTotal) : 0;
            const domStarted = domTotal > 0 || /google_dom|google_profile|dataset_saved/.test(status);
            // If multi-location search (apiTotal > 1), weight task completion heavily so 1/71 never jumps to 85% on the first location
            if (apiTotal > 1) {
                const currentTaskDomBonus = (domStarted && effectiveApiDone <= apiTotal) ? (domRatio / apiTotal) : 0;
                const overallTaskRatio = Math.min(1, (taskCompleted / apiTotal) + currentTaskDomBonus);
                percentExact = overallTaskRatio * 100;
            } else {
                percentExact = domStarted ? (15 * apiRatio + 85 * domRatio) : (15 * apiRatio);
            }
            if (domTotal > 0 && domProcessed >= domTotal && (parseInt(q.domPending, 10) || 0) === 0 && (parseInt(q.domRunning, 10) || 0) === 0 && (q.producerDone || effectiveApiDone >= apiTotal) && taskCompleted >= taskTotal) {
                percentExact = 100;
            }
            phase = domStarted ? 'Profiles' : 'API searches';
            detail = taskTotal ? (taskCompleted + '/' + taskTotal + ' tasks · ' + domProcessed + '/' + domTotal + ' profiles') : (domProcessed + '/' + domTotal + ' profiles');
        }

        if (terminal && !inputsModified && !active && !$scope.startLaunchPending) percentExact = 100;
        if (stopped || active || $scope.startLaunchPending) percentExact = Math.min(99.4, percentExact);
        if (inputsModified) percentExact = 0;
        percentExact = Math.max(0, Math.min(100, percentExact));

        $scope.progressData = {
            completed: taskCompleted,
            completedSettled: taskCompleted,
            taskCompleted: taskCompleted,
            taskTotal: taskTotal,
            currentTaskIndex: currentTaskIdx,
            total: taskTotal,
            percent: Math.round(percentExact),
            percentExact: percentExact,
            phase: phase,
            detail: detail,
            apiCompleted: (active || $scope.startLaunchPending) && apiTotal > 0 ? currentTaskIdx : apiSettled,
            apiTotal: apiTotal,
            domCompleted: domProcessed,
            domTotal: domTotal,
            inputsModified: inputsModified
        };
    };


    /**
     * Provide backward compatibility for templates that still reference
     * percentComplete().  Instead of recalculating progress on every call,
     * simply return the already computed progressData.  This function may be
     * removed in a future version when templates are fully updated to use
     * progressData instead.
     */
    $scope.percentComplete = () => {
        return $scope.progressData;
    };

    $scope.getKeywordsProgressText = function() {
        const p = $scope.progressData || { completed: 0, total: 0 };
        return (p.completed || 0) + '/' + (p.total || 0);
    };

    $scope.getScrapingProgressText = function() {
        const p = $scope.progressData || { percentExact: 0 };
        const value = Number.isFinite(p.percentExact) ? p.percentExact : (parseFloat(p.percent) || 0);
        return value.toFixed(1) + '%';
    };


    const API_LIVE_APPS_SCRIPT_URL = PocketLeadsConfig.endpoint;
    const API_LIVE_FIELD_MASK = 'places.id,nextPageToken';

    function createEmptyApiLiveResult() {
        return {
            provider: 'googlemaps',
            query: '',
            fieldMask: API_LIVE_FIELD_MASK,
            selectedPages: 0,
            effectivePages: 0,
            pagesDone: 0,
            uniqueCount: 0,
            duplicateCount: 0,
            returnedCount: 0,
            rawCount: 0,
            rows: [],
            pages: [],
            filterNotes: [],
            allPlaceIdsText: '',
            acceptedIdsText: '',
            mapsLinksText: '',
            pageBreakdownText: ''
        };
    }

    $scope.apiLive = {
        loading: false,
        visible: false,
        error: '',
        statusText: 'Ready',
        progress: 0,
        currentQuery: '',
        steps: [],
        result: createEmptyApiLiveResult()
    };

    function apiLiveTime() {
        try {
            const d = new Date();
            return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + ':' + String(d.getSeconds()).padStart(2, '0');
        } catch (err) { return ''; }
    }

    function apiLiveApply() {
        try { $scope.$applyAsync(); } catch (err) {}
    }

    function apiLiveStep(text) {
        $scope.apiLive.steps = Array.isArray($scope.apiLive.steps) ? $scope.apiLive.steps : [];
        $scope.apiLive.steps.push({ time: apiLiveTime(), text: String(text || '') });
        if ($scope.apiLive.steps.length > 120) $scope.apiLive.steps = $scope.apiLive.steps.slice(-120);
        apiLiveApply();
    }

    function apiLiveSetProgress(value, statusText) {
        const v = Math.max(0, Math.min(100, parseInt(value, 10) || 0));
        $scope.apiLive.progress = v;
        if (statusText) $scope.apiLive.statusText = statusText;
        apiLiveApply();
    }

    function apiLiveRefreshIdTexts(result) {
        try {
            const rows = Array.isArray(result && result.rows) ? result.rows : [];
            const pages = Array.isArray(result && result.pages) ? result.pages : [];
            result.allPlaceIdsText = rows.map((row, idx) => {
                return (idx + 1) + '. Page ' + row.page + ' | ' + row.status + ' | ' + row.placeId + '\n' + (row.mapsUrl || '') + (row.reason ? '\nFilter: ' + row.reason : '');
            }).join('\n\n');
            const accepted = rows.filter(row => row.status === 'Accepted');
            result.acceptedIdsText = accepted.map(row => row.placeId).join('\n');
            result.mapsLinksText = accepted.map(row => row.mapsUrl).filter(Boolean).join('\n');
            result.pageBreakdownText = pages.map(page => {
                return 'Page ' + page.page + ': API returned ' + page.returned + ', accepted ' + page.accepted + ', duplicate ' + page.duplicate + ', nextPageToken=' + (page.nextPageToken ? 'yes' : 'no');
            }).join('\n');
        } catch (err) {}
    }

    $scope.copyApiLiveText = async function(kind) {
        try {
            const result = ($scope.apiLive && $scope.apiLive.result) || {};
            const text = kind === 'links' ? (result.mapsLinksText || '') : kind === 'accepted' ? (result.acceptedIdsText || '') : (result.allPlaceIdsText || '');
            if (!text) {
                apiLiveStep('Nothing to copy yet. Run API Live Result first.');
                return;
            }
            if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText(text);
            } else {
                const ta = document.createElement('textarea');
                ta.value = text;
                ta.style.position = 'fixed';
                ta.style.left = '-9999px';
                document.body.appendChild(ta);
                ta.focus();
                ta.select();
                document.execCommand('copy');
                document.body.removeChild(ta);
            }
            apiLiveStep((kind === 'links' ? 'Maps profile links' : kind === 'accepted' ? 'Accepted Place IDs' : 'All Place ID rows') + ' copied.');
        } catch (err) {
            apiLiveStep('Copy failed: ' + (err && err.message ? err.message : err));
        }
    };

    function buildPreviewTaskFromInputs() {
        try {
            const keywordLines = String(($scope.local && $scope.local.keywordTextarea) || '').split('\n').map(x => x.trim()).filter(Boolean);
            const locationLines = String(($scope.local && $scope.local.locationTextarea) || '').split('\n').map(x => x.trim()).filter(Boolean);
            if (keywordLines.length && locationLines.length) {
                return { keyword: keywordLines[0], location: locationLines[0], query: (keywordLines[0] + ' in ' + locationLines[0]).replace(/\s+/g, ' ').trim() };
            }
            if (keywordLines.length) return { keyword: keywordLines[0], location: '', query: keywordLines[0] };
            const q = ($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.currentQuery) || '';
            return { keyword: q, location: '', query: q };
        } catch (err) {
            return { keyword: '', location: '', query: '' };
        }
    }

    function apiLiveNormalizeQuery(value) {
        return String(value || '').replace(/\s+/g, ' ').trim();
    }

    function apiLiveEnsureCountry(query, country) {
        const q = apiLiveNormalizeQuery(query);
        const c = apiLiveNormalizeQuery(country || 'India');
        if (!q || !c) return q;
        if (new RegExp('\\b' + c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i').test(q)) return q;
        return (q + ' in ' + c).replace(/\s+/g, ' ').trim();
    }

    function apiLiveIsPincode(text) {
        return /(^|\D)[1-9][0-9]{5}(\D|$)/.test(String(text || ''));
    }

    function apiLiveEffectivePages(meta, settings) {
        const selected = Math.max(1, Math.min(50, parseInt(($scope.local && ($scope.local.maxPagesPerSearch || $scope.local.pageLimit)) || (settings && settings.maxPagesPerSearch) || 50, 10) || 50));
        const isPincode = apiLiveIsPincode((meta && (meta.location || meta.query || meta.queryForApi)) || '');
        const effective = isPincode ? Math.min(selected, 3) : selected;
        return { selected, effective, isPincode };
    }

    function apiLiveMapsUrl(placeId) {
        const id = String(placeId || '').trim();
        return id ? ('https://www.google.com/maps/place/?q=place_id:' + encodeURIComponent(id)) : '';
    }

    function apiLiveGetStoredLicence() {
        return new Promise(resolve => {
            try {
                if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return resolve(null);
                chrome.storage.local.get('license', res => resolve(res && res.license ? res.license : null));
            } catch (err) { resolve(null); }
        });
    }

    async function apiLiveCallAppsScript(action, payload) {
        const body = Object.assign({ action }, payload || {});
        if (body.key && !body.deviceId && !/^(activate|release|ping|status)$/i.test(String(action || ''))) {
            const licence = await apiLiveGetStoredLicence();
            const installationId = String(licence && licence.installationId || '').trim();
            if (!installationId) throw new Error('PocketLeads secure device binding requires one-time licence reactivation on this device.');
            body.deviceId = installationId;
        }
        const bodyJson = JSON.stringify(body);
        let baseUrl = API_LIVE_APPS_SCRIPT_URL;
        try {
            const cfgEdge = (typeof PocketLeadsConfig !== 'undefined' && PocketLeadsConfig && PocketLeadsConfig.edgeProxyUrl) ? String(PocketLeadsConfig.edgeProxyUrl).trim() : '';
            const learnedEdge = (typeof localStorage !== 'undefined' && localStorage.getItem('pl_edge_proxy_url_v42')) ? String(localStorage.getItem('pl_edge_proxy_url_v42')).trim() : '';
            const edgeCandidate = cfgEdge || learnedEdge;
            if (edgeCandidate && /^https:\/\//i.test(edgeCandidate) && /^(providerproxy|getapiconfig|reportapiusage|reportleadmetrics|getnotifications)$/i.test(String(action || ''))) {
                baseUrl = edgeCandidate;
            }
        } catch (_) {}
        let reqUrl = baseUrl;
        try {
            const u = new URL(baseUrl);
            if (body.action) u.searchParams.set('action', String(body.action));
            if (body.key) u.searchParams.set('key', String(body.key));
            if (body.deviceId) u.searchParams.set('deviceId', String(body.deviceId));
            if (bodyJson.length <= 1800) u.searchParams.set('_pl_body', bodyJson);
            reqUrl = u.toString();
        } catch (_) {}
        const timeoutMs = 55000;
        const startedAt = Date.now();
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        try {
            const response = await fetch(reqUrl, {
                signal: controller.signal,
                method: 'POST',
                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                body: bodyJson
            });
            clearTimeout(timer);
            const elapsedMs = Date.now() - startedAt;
            const rawText = await response.text();
            let data = null;
            try { data = JSON.parse(rawText); } catch (err) { data = null; }
            if (!response.ok || !data) {
                const httpErr = new Error(`[HTTP ${response.status}] Backend call "${action}" to ${baseUrl} failed after ${elapsedMs}ms: ${String(rawText || 'empty response').slice(0, 260)}`);
                httpErr.status = response.status;
                httpErr.targetUrl = baseUrl;
                httpErr.elapsedMs = elapsedMs;
                httpErr.rawPreview = String(rawText || '').slice(0, 260);
                throw httpErr;
            }
            data._clientElapsedMs = elapsedMs;
            data._targetUrl = baseUrl;
            await PocketLeadsAccount.observe(data, body.key, body.deviceId);
            return data;
        } catch (err) {
            clearTimeout(timer);
            const elapsedMs = Date.now() - startedAt;
            const rawErrMsg = String((err && err.message) || err || '');
            if (/signal is aborted|aborted without reason|The user aborted/i.test(rawErrMsg)) {
                const tErr = new Error(`[CLIENT TIMEOUT ABORT] "${action}${body.operation ? ' (' + body.operation + ')' : ''}" to ${baseUrl} timed out after ${elapsedMs}ms (limit: ${timeoutMs}ms).`);
                tErr.code = 'CLIENT_FETCH_TIMEOUT';
                tErr.targetUrl = baseUrl;
                tErr.elapsedMs = elapsedMs;
                throw tErr;
            }
            if (err && typeof err === 'object') {
                if (!err.targetUrl) err.targetUrl = baseUrl;
                if (!err.elapsedMs) err.elapsedMs = elapsedMs;
            }
            throw err;
        }
    }

    async function apiLiveGetGoogleSettings() {
        const licence = await apiLiveGetStoredLicence();
        const key = licence && licence.key ? String(licence.key).trim() : '';
        if (!key) throw new Error('Please activate your licence first.');
        const data = await apiLiveCallAppsScript('getApiConfig', { key, provider: 'googlemaps', preferNext: false });
        if (!data || data.status !== 'ok') {
            if (data && data.status === 'credits_exhausted') throw new Error('Google Maps plan credit is exhausted. Upgrade your plan or contact samimn7890@gmail.com.');
            if (data && data.status === 'expired') throw new Error(`Licence expired${data.expiryDate ? ' on ' + data.expiryDate : ''}. Contact ${data.supportEmail || PocketLeadsConfig.supportEmail} to renew.`);
            if (data && data.status === 'no_api_key') throw new Error('Google Maps service is temporarily unavailable. Please try again later.');
            if (data && data.status === 'invalid' && !data.backend) throw new Error('Apps Script old version hai. ZIP ke apps_script_code.js ko paste karke new deployment karo.');
            throw new Error((data && data.message) || 'Google Maps API config nahi mila.');
        }
        if (data.secureProxy !== true || String(data.providerContract || '') !== 'sheet_authoritative_secure_proxy_v3') throw new Error('Secure backend v30 required. Deploy ZIP apps_script_code.js first.');
        if (String(data.provider || '').toLowerCase() !== 'googlemaps') throw new Error('Google Maps row active nahi hai. API Live Result only googlemaps provider ko test karta hai.');
        return {
            provider: 'googlemaps',
            apiToken: '',
            secureProxy: data.secureProxy === true,
            apiKeyRow: parseInt(data.keyRow, 10) || 0,
            usageCount: parseInt(data.usageCount, 10) || 0,
            usageLimit: Math.max(0, Number(data.usageLimit) || 0),
            maxPagesPerSearch: Math.max(1, Math.min(50, parseInt(($scope.local && ($scope.local.maxPagesPerSearch || $scope.local.pageLimit)) || 50, 10) || 50)),
            countryFilter: ($scope.local && $scope.local.country) || 'India'
        };
    }

    function apiLiveAssertIdsOnly() {
        const normalized = API_LIVE_FIELD_MASK.replace(/\s+/g, '');
        if (normalized !== 'places.id,nextPageToken') throw new Error('Cost guard blocked: only places.id,nextPageToken is allowed.');
        if (/displayName|formattedAddress|internationalPhoneNumber|nationalPhoneNumber|websiteUri|rating|userRatingCount|reviews|types|primaryType/i.test(normalized)) {
            throw new Error('Cost guard blocked paid Google Places fields.');
        }
    }

    async function apiLiveRequestPage(query, settings, pageToken) {
        apiLiveAssertIdsOnly();
        const body = { textQuery: apiLiveNormalizeQuery(query), pageSize: 20 };
        if (pageToken) body.pageToken = String(pageToken);
        const licence = await apiLiveGetStoredLicence();
        const key = licence && licence.key ? String(licence.key).trim() : '';
        if (!key) throw new Error('Please activate your licence first.');
        const proxied = await apiLiveCallAppsScript('providerProxy', {
            key, provider: 'googlemaps', keyRow: settings.apiKeyRow || 0, operation: 'textSearch', payload: { body }
        });
        if (!proxied || proxied.status !== 'ok') {
            const detail = proxied && (proxied.message || proxied.reason) || 'Secure Google Places proxy failed.';
            const err = new Error(proxied && proxied.status === 'credits_exhausted'
                ? 'Google Maps plan credit is exhausted. Upgrade your plan or contact samimn7890@gmail.com.'
                : (proxied && proxied.status === 'expired'
                    ? `Licence expired${proxied.expiryDate ? ' on ' + proxied.expiryDate : ''}. Contact ${proxied.supportEmail || PocketLeadsConfig.supportEmail} to renew.`
                    : ('Google Places API error: ' + detail)));
            err.status = parseInt(proxied && proxied.httpStatus, 10) || 0;
            throw err;
        }
        const payload = proxied.data || {};
        const places = Array.isArray(payload && payload.places) ? payload.places : [];
        const responseFields = Object.keys(payload || {});
        const items = places.map(function(place, index) {
            const fields = Object.keys(place || {});
            const id = place && place.id ? String(place.id).trim() : '';
            return {
                apiIndex: index + 1,
                placeId: id,
                fields,
                responseFields,
                raw: place
            };
        });
        return { payload, places, items, nextPageToken: String(payload && payload.nextPageToken || '') };
    }

    $scope.hideApiLiveResult = function() {
        setGoogleApiLiveDebug(false);
        $scope.apiLive.visible = false;
        $scope.apiLive.loading = false;
    };

    let apiLiveMonitorOverlay = null;
    let apiLiveMonitorState = null;
    function setGoogleApiLiveDebug(enabled) {
        try {
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage({ action: 'pl_set_google_live_debug', enabled: !!enabled }, function() {
                    try { void chrome.runtime.lastError; } catch (e) {}
                });
            }
        } catch (e) {}
    }


    function createApiIdMonitorModal(queryText) {
        try { document.getElementById('plApiIdMonitorOverlay')?.remove(); } catch (e) {}
        const overlay = document.createElement('div');
        apiLiveMonitorOverlay = overlay;
        overlay.id = 'plApiIdMonitorOverlay';
        overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(2,6,23,.78);display:flex;align-items:center;justify-content:center;padding:18px;font-family:Arial,Helvetica,sans-serif;';
        overlay.innerHTML = `
            <div style="width:min(1280px,98vw);max-height:94vh;background:#ffffff;border-radius:16px;box-shadow:0 24px 80px rgba(0,0,0,.45);display:flex;flex-direction:column;overflow:hidden;color:#0f172a;">
                <div style="padding:14px 16px;background:#0f172a;color:#fff;display:flex;align-items:center;justify-content:space-between;gap:12px;">
                    <div>
                        <div style="font-size:18px;font-weight:900;">Live API Place ID Result</div>
                        <div id="plApiIdMonitorQuery" style="font-size:12px;color:#cbd5e1;margin-top:3px;word-break:break-word;">${apiLiveEscapeHtml(queryText || '-')}</div>
                    </div>
                    <button id="plApiIdMonitorClose" type="button" style="border:none;background:#334155;color:#fff;border-radius:10px;width:36px;height:36px;font-size:24px;line-height:1;cursor:pointer;">×</button>
                </div>
                <div style="padding:12px 16px;border-bottom:1px solid #e2e8f0;display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;background:#f8fafc;">
                    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:9px;"><div style="font-size:10px;color:#64748b;text-transform:uppercase;font-weight:800;">Status</div><div id="plApiIdMonitorStatus" style="font-size:13px;font-weight:900;color:#0f172a;margin-top:3px;">Waiting live...</div></div>
                    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:9px;"><div style="font-size:10px;color:#64748b;text-transform:uppercase;font-weight:800;">API Rows</div><div id="plApiIdMonitorReturned" style="font-size:18px;font-weight:900;color:#0f172a;margin-top:3px;">0</div></div>
                    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:9px;"><div style="font-size:10px;color:#64748b;text-transform:uppercase;font-weight:800;">Unique IDs</div><div id="plApiIdMonitorUnique" style="font-size:18px;font-weight:900;color:#0f172a;margin-top:3px;">0</div></div>
                    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:9px;"><div style="font-size:10px;color:#64748b;text-transform:uppercase;font-weight:800;">Skipped</div><div id="plApiIdMonitorSkipped" style="font-size:18px;font-weight:900;color:#b45309;margin-top:3px;">0</div></div>
                    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:9px;"><div style="font-size:10px;color:#64748b;text-transform:uppercase;font-weight:800;">Saved</div><div id="plApiIdMonitorSaved" style="font-size:18px;font-weight:900;color:#15803d;margin-top:3px;">0</div></div>
                    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:9px;"><div style="font-size:10px;color:#64748b;text-transform:uppercase;font-weight:800;">Pages</div><div id="plApiIdMonitorPages" style="font-size:18px;font-weight:900;color:#0f172a;margin-top:3px;">0</div></div>
                </div>
                <div style="padding:10px 16px;display:flex;gap:8px;align-items:center;justify-content:space-between;border-bottom:1px solid #e2e8f0;background:#fff;">
                    <div style="font-size:12px;color:#475569;line-height:1.35;">
                        Endpoint: <b>places:searchText</b> &nbsp;|&nbsp; FieldMask locked: <b>places.id,nextPageToken</b><br>
                        <span id="plApiIdMonitorRequest" style="font-family:monospace;color:#334155;">Waiting for request...</span>
                    </div>
                    <div style="display:flex;gap:8px;">
                        <button id="plApiIdCopyIds" type="button" style="border:none;background:#2563eb;color:#fff;border-radius:9px;padding:8px 10px;font-size:12px;font-weight:800;cursor:pointer;">Copy IDs</button>
                        <button id="plApiIdCopyAll" type="button" style="border:none;background:#0f172a;color:#fff;border-radius:9px;padding:8px 10px;font-size:12px;font-weight:800;cursor:pointer;">Copy All</button>
                        <button id="plApiIdClear" type="button" style="border:none;background:#64748b;color:#fff;border-radius:9px;padding:8px 10px;font-size:12px;font-weight:800;cursor:pointer;">Clear</button>
                    </div>
                </div>
                <div id="plApiIdMonitorError" style="display:none;margin:10px 16px 0;padding:10px;border-radius:10px;background:#fee2e2;color:#991b1b;border:1px solid #fecaca;font-size:13px;white-space:pre-wrap;"></div>
                <div style="padding:0 16px 16px;overflow:auto;">
                    <table style="width:100%;border-collapse:collapse;font-size:12px;margin-top:12px;">
                        <thead style="position:sticky;top:0;background:#e2e8f0;z-index:1;">
                            <tr>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;width:48px;">#</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;width:66px;">Page</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;width:86px;">Stage</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;">Place ID returned by API</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;width:140px;">Status</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;">Reason / Skip reason</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;width:120px;">API fields</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;">Maps Link</th>
                            </tr>
                        </thead>
                        <tbody id="plApiIdMonitorRows">
                            <tr id="plApiIdEmptyRow"><td colspan="8" style="padding:18px;text-align:center;color:#64748b;border:1px solid #cbd5e1;">Popup open hai. API call hota hi Place IDs yahan live append honge...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>`;
        document.body.appendChild(overlay);
        setGoogleApiLiveDebug(true);
        const close = overlay.querySelector('#plApiIdMonitorClose');
        if (close) close.onclick = () => { setGoogleApiLiveDebug(false); overlay.remove(); if (apiLiveMonitorOverlay === overlay) apiLiveMonitorOverlay = null; };
        const clear = overlay.querySelector('#plApiIdClear');
        if (clear) clear.onclick = () => {
            if (apiLiveMonitorState) {
                apiLiveMonitorState.rows = [];
                apiLiveMonitorState.rowByPlace = {};
                apiLiveMonitorState.uniqueSet = new Set();
                apiLiveMonitorState.skipped = 0;
                apiLiveMonitorState.saved = 0;
                apiLiveMonitorState.pagesDone = 0;
                rebuildApiIdMonitorRows(overlay, apiLiveMonitorState);
                updateApiIdMonitorSummary(overlay, apiLiveMonitorState);
            }
        };
        return overlay;
    }

    function apiLiveEscapeHtml(value) {
        return String(value == null ? '' : value).replace(/[&<>'"]/g, function(ch) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[ch] || ch;
        });
    }

    function initApiLiveState(query) {
        apiLiveMonitorState = {
            query: query || '',
            status: 'Watching live API events...',
            rows: [],
            rowByPlace: {},
            uniqueSet: new Set(),
            pagesDone: 0,
            skipped: 0,
            saved: 0,
            error: '',
            lastRequest: ''
        };
        return apiLiveMonitorState;
    }

    function updateApiIdMonitorSummary(overlay, state) {
        if (!overlay || !state) return;
        const setText = (id, value) => { const el = overlay.querySelector('#' + id); if (el) el.textContent = String(value == null ? '' : value); };
        setText('plApiIdMonitorStatus', state.status || 'Running...');
        setText('plApiIdMonitorReturned', state.rows.filter(r => r.stage === 'API').length || 0);
        setText('plApiIdMonitorUnique', state.uniqueSet.size || 0);
        setText('plApiIdMonitorSkipped', state.skipped || 0);
        setText('plApiIdMonitorSaved', state.saved || 0);
        setText('plApiIdMonitorPages', state.pagesDone || 0);
        const q = overlay.querySelector('#plApiIdMonitorQuery');
        if (q && state.query) q.textContent = state.query;
        const req = overlay.querySelector('#plApiIdMonitorRequest');
        if (req && state.lastRequest) req.textContent = state.lastRequest;
        const err = overlay.querySelector('#plApiIdMonitorError');
        if (err) {
            if (state.error) { err.style.display = 'block'; err.textContent = state.error; }
            else { err.style.display = 'none'; err.textContent = ''; }
        }
        const copyIds = overlay.querySelector('#plApiIdCopyIds');
        const copyAll = overlay.querySelector('#plApiIdCopyAll');
        const idsText = Array.from(state.uniqueSet).join('\n');
        const allText = state.rows.map((r, i) => (i + 1) + '. Page ' + (r.page || '-') + ' | ' + (r.stage || '-') + ' | ' + (r.placeId || '-') + ' | ' + (r.status || '-') + ' | ' + (r.reason || '-') + ' | fields=' + (r.fields || '-') + ' | ' + (r.mapsUrl || '')).join('\n');
        if (copyIds) copyIds.onclick = () => apiLiveCopyPlainText(idsText);
        if (copyAll) copyAll.onclick = () => apiLiveCopyPlainText(allText);
    }

    function appendApiIdMonitorRow(overlay, row, state) {
        if (!overlay || !row) return;
        const tbody = overlay.querySelector('#plApiIdMonitorRows');
        if (!tbody) return;
        const empty = overlay.querySelector('#plApiIdEmptyRow');
        if (empty) empty.remove();
        const idx = state.rows.length;
        const bg = /skip|duplicate|filter|failed/i.test(row.status || row.reason || '') ? '#fff7ed' : (/saved/i.test(row.status || '') ? '#f0fdf4' : '#ffffff');
        const tr = document.createElement('tr');
        tr.setAttribute('data-place-id', row.placeId || '');
        tr.style.background = bg;
        tr.innerHTML =
            '<td style="padding:7px;border:1px solid #e2e8f0;font-weight:800;">' + idx + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;">' + apiLiveEscapeHtml(row.page || '-') + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;font-weight:800;">' + apiLiveEscapeHtml(row.stage || '-') + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;font-family:monospace;font-size:12px;word-break:break-all;">' + apiLiveEscapeHtml(row.placeId || '-') + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;">' + apiLiveEscapeHtml(row.status || '-') + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;min-width:220px;">' + apiLiveEscapeHtml(row.reason || '-') + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;font-family:monospace;">' + apiLiveEscapeHtml(row.fields || '-') + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;word-break:break-all;">' + (row.mapsUrl ? '<a href="' + apiLiveEscapeHtml(row.mapsUrl) + '" target="_blank">Open</a>' : '-') + '</td>';
        tbody.appendChild(tr);
        try { tbody.parentElement.parentElement.scrollTop = tbody.parentElement.parentElement.scrollHeight; } catch (e) {}
    }

    function rebuildApiIdMonitorRows(overlay, state) {
        const tbody = overlay && overlay.querySelector('#plApiIdMonitorRows');
        if (!tbody) return;
        tbody.innerHTML = '<tr id="plApiIdEmptyRow"><td colspan="8" style="padding:18px;text-align:center;color:#64748b;border:1px solid #cbd5e1;">Popup open hai. API call hota hi Place IDs yahan live append honge...</td></tr>';
        (state.rows || []).forEach(row => appendApiIdMonitorRow(overlay, row, state));
    }

    function apiLiveHandleEvent(event) {
        if (!event || !apiLiveMonitorOverlay) return;
        const state = apiLiveMonitorState || initApiLiveState(event.query || '');
        if (event.query) state.query = event.query;
        if (event.type === 'session_start') {
            state.status = 'API started';
            state.lastRequest = 'POST places:searchText | textQuery=' + (event.query || '-') + ' | fieldMask=' + (event.fieldMask || API_LIVE_FIELD_MASK);
        } else if (event.type === 'page_request') {
            state.status = 'Calling page ' + (event.page || '-');
            state.lastRequest = 'POST places:searchText | body=' + JSON.stringify(event.requestBody || {});
        } else if (event.type === 'place_id') {
            const placeId = event.placeId || '';
            const status = event.status === 'accepted_for_dom' ? 'Accepted' : 'Skipped';
            const reason = event.reason || (event.duplicate ? 'Duplicate Place ID' : '-');
            if (placeId && !event.duplicate && event.status !== 'skipped') state.uniqueSet.add(placeId);
            if (event.status === 'skipped' || event.duplicate) state.skipped += 1;
            const row = {
                page: event.page || '-',
                stage: 'API',
                placeId,
                status,
                reason,
                fields: (event.fieldsReturned || event.responseFields || []).join(', ') || 'id',
                mapsUrl: event.mapsUrl || (placeId ? apiLiveMapsUrl(placeId) : '')
            };
            state.rows.push(row);
            if (placeId) state.rowByPlace[placeId] = row;
            appendApiIdMonitorRow(apiLiveMonitorOverlay, row, state);
        } else if (event.type === 'page_done') {
            state.pagesDone = Math.max(state.pagesDone || 0, event.page || 0);
            state.status = event.message || ('Page ' + event.page + ' done');
        } else if (event.type === 'place_status') {
            const placeId = event.placeId || '';
            if (/skip|filter|failed/i.test(event.status || event.reason || '')) state.skipped += 1;
            if (/saved/i.test(event.status || '')) state.saved += 1;
            const row = {
                page: event.processed || '-',
                stage: String(event.stage || 'DOM').toUpperCase(),
                placeId,
                status: event.status || '-',
                reason: event.reason || '-',
                fields: 'DOM',
                mapsUrl: event.mapsUrl || (placeId ? apiLiveMapsUrl(placeId) : '')
            };
            state.rows.push(row);
            appendApiIdMonitorRow(apiLiveMonitorOverlay, row, state);
            state.status = event.reason || event.status || state.status;
        } else if (event.type === 'session_api_done') {
            state.status = event.message || 'API IDs complete';
        }
        updateApiIdMonitorSummary(apiLiveMonitorOverlay, state);
    }

    try {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage && !window.__plGoogleApiLiveListenerAdded) {
            window.__plGoogleApiLiveListenerAdded = true;
            chrome.runtime.onMessage.addListener(function(msg) {
                try {
                    if (msg && msg.action === 'pl_google_api_live_event') apiLiveHandleEvent(msg.payload || {});
                } catch (e) {}
            });
        }
    } catch (e) {}

    async function apiLiveCopyPlainText(text) {
        try {
            text = String(text || '');
            if (!text) return;
            if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(text);
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.left = '-9999px';
            document.body.appendChild(ta);
            ta.focus();
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
        } catch (err) {}
    }

    $scope.showApiLiveResult = async function() {
        const task = buildPreviewTaskFromInputs();
        const overlay = createApiIdMonitorModal(task.query || ($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.currentQuery) || '');
        const liveState = initApiLiveState(task.query || '');
        updateApiIdMonitorSummary(overlay, liveState);

        $scope.apiLive.loading = true;
        $scope.apiLive.visible = false; // simple DOM popup only
        apiLiveApply();

        const queue = ($scope.local && $scope.local.apifyQueue) || {};
        const isMainScrapingRunning = !!($scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking) || /starting|searching|streaming|scraping|google_|apify|serper|scrappa/i.test(String(queue.status || ''))));

        if (isMainScrapingRunning) {
            liveState.status = 'Watching current extraction live...';
            liveState.query = queue.currentQuery || task.query || liveState.query;
            liveState.lastRequest = 'Normal Start Extracting flow chal raha hai. API events yahan live append honge.';
            updateApiIdMonitorSummary(overlay, liveState);
            $scope.apiLive.loading = false;
            apiLiveApply();
            return;
        }

        if (!task.query) {
            liveState.status = 'Input needed';
            liveState.error = 'Keyword/query blank hai. Example: clinic in kolkata';
            updateApiIdMonitorSummary(overlay, liveState);
            $scope.apiLive.loading = false;
            apiLiveApply();
            return;
        }

        try {
            liveState.status = 'Reading API key...';
            updateApiIdMonitorSummary(overlay, liveState);
            const settings = await apiLiveGetGoogleSettings();
            const country = settings.countryFilter || 'India';
            const queryForApi = apiLiveEnsureCountry(task.query, country);
            const meta = { keyword: task.keyword, location: task.location, query: task.query, queryForApi, country };
            const pagePlan = apiLiveEffectivePages(meta, settings);
            liveState.query = queryForApi;
            liveState.status = 'Calling Places API...';
            liveState.lastRequest = 'POST places:searchText | textQuery=' + queryForApi + ' | fieldMask=' + API_LIVE_FIELD_MASK;
            updateApiIdMonitorSummary(overlay, liveState);

            let nextPageToken = '';
            for (let page = 1; page <= pagePlan.effective; page += 1) {
                liveState.status = 'Calling page ' + page + '/' + pagePlan.effective + '...';
                liveState.lastRequest = 'POST places:searchText | body=' + JSON.stringify({ textQuery: queryForApi, pageSize: 20, pageToken: nextPageToken ? '[nextPageToken]' : '' });
                updateApiIdMonitorSummary(overlay, liveState);

                const pageResult = await apiLiveRequestPage(queryForApi, settings, nextPageToken);
                liveState.pagesDone = page;
                const items = pageResult.items || [];
                for (let i = 0; i < items.length; i += 1) {
                    const item = items[i];
                    const placeId = item.placeId || '';
                    const key = placeId.toLowerCase();
                    let status = 'Accepted';
                    let reason = 'Accepted: API se Place ID return hua.';
                    let duplicate = false;
                    if (!key) {
                        status = 'Skipped';
                        reason = 'Skipped: API response me Place ID missing hai.';
                        liveState.skipped += 1;
                    } else if (liveState.uniqueSet.has(placeId)) {
                        status = 'Skipped';
                        reason = 'Skipped: duplicate Place ID from API.';
                        liveState.skipped += 1;
                        duplicate = true;
                    } else {
                        liveState.uniqueSet.add(placeId);
                    }
                    const row = {
                        page,
                        stage: 'API',
                        placeId,
                        status,
                        reason,
                        fields: (item.fields || item.responseFields || []).join(', ') || 'id',
                        mapsUrl: item.mapsUrl || (placeId ? apiLiveMapsUrl(placeId) : '')
                    };
                    liveState.rows.push(row);
                    if (placeId) liveState.rowByPlace[placeId] = row;
                    appendApiIdMonitorRow(overlay, row, liveState);
                    liveState.status = 'Live: page ' + page + ' row ' + (i + 1) + '/' + items.length;
                    updateApiIdMonitorSummary(overlay, liveState);
                    await new Promise(resolve => setTimeout(resolve, 0));
                }

                liveState.status = 'Page ' + page + ' returned ' + items.length + ' row(s)';
                updateApiIdMonitorSummary(overlay, liveState);
                if (!pageResult.nextPageToken) break;
                nextPageToken = pageResult.nextPageToken;
                if (page < pagePlan.effective) await new Promise(resolve => setTimeout(resolve, 250));
            }
            liveState.status = 'Completed: API returned ' + liveState.rows.filter(r => r.stage === 'API').length + ' row(s), unique ' + liveState.uniqueSet.size;
            updateApiIdMonitorSummary(overlay, liveState);
        } catch (err) {
            liveState.status = 'Error';
            liveState.error = err && err.message ? err.message : String(err || 'API Live Result failed');
            updateApiIdMonitorSummary(overlay, liveState);
        }

        $scope.apiLive.loading = false;
        apiLiveApply();
    };
    
    // Zero-overhead Live Spy & Diagnostic Telemetry state
    $scope.liveSpy = {
        open: true,
        filter: 'all',
        events: [],
        snapshot: {}
    };
    let liveSpyFlushTimer = null;
    const pendingSpyEvents = [];

    function scheduleLiveSpyUiFlush() {
        if (liveSpyFlushTimer) return;
        liveSpyFlushTimer = setTimeout(() => {
            liveSpyFlushTimer = null;
            if (!pendingSpyEvents.length) return;
            const batch = pendingSpyEvents.splice(0, pendingSpyEvents.length);
            const merged = [...($scope.liveSpy.events || []), ...batch].slice(-120);
            $scope.liveSpy.events = merged;
            if ($scope.showDiagnostics) {
                try { $scope.$applyAsync(); } catch (_) {}
            }
        }, 220);
    }

    try {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage && !window.__plLiveSpyListenerAdded) {
            window.__plLiveSpyListenerAdded = true;
            chrome.runtime.onMessage.addListener(function(msg) {
                try {
                    if (msg && msg.action === 'PL_LIVE_SPY_EVENT') {
                        if (msg.snapshot) $scope.liveSpy.snapshot = msg.snapshot;
                        if (msg.event) {
                            pendingSpyEvents.push(msg.event);
                            scheduleLiveSpyUiFlush();
                        }
                    }
                } catch (_) {}
            });
        }
    } catch (_) {}

    let _liveSpyMemoSig = '';
    let _liveSpyMemoArr = [];
    $scope.getLiveSpyEvents = function() {
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const fromQueue = Array.isArray(q.liveSpyEvents) ? q.liveSpyEvents : [];
        const fromLive = Array.isArray($scope.liveSpy && $scope.liveSpy.events) ? $scope.liveSpy.events : [];
        const mode = String($scope.liveSpy && $scope.liveSpy.filter || 'all');
        const qLastId = fromQueue.length ? (fromQueue[fromQueue.length - 1].id || '') : '';
        const lLastId = fromLive.length ? (fromLive[fromLive.length - 1].id || '') : '';
        const sig = fromQueue.length + ':' + qLastId + '|' + fromLive.length + ':' + lLastId + '|' + mode;
        if (sig === _liveSpyMemoSig) return _liveSpyMemoArr;
        _liveSpyMemoSig = sig;
        const byId = new Map();
        for (let i = 0; i < fromQueue.length; i++) {
            const ev = fromQueue[i];
            if (ev && ev.id) byId.set(ev.id, ev);
        }
        for (let i = 0; i < fromLive.length; i++) {
            const ev = fromLive[i];
            if (ev && ev.id) byId.set(ev.id, ev);
        }
        const all = Array.from(byId.values()).slice(-80).reverse();
        if (mode === 'errors') {
            _liveSpyMemoArr = all.filter(ev => ev.level === 'error' || ev.level === 'warn' || /ERROR|FAIL|SKIP|EMPTY/i.test(ev.type || ''));
        } else if (mode === 'skips') {
            _liveSpyMemoArr = all.filter(ev => (ev.skippedCount || 0) > 0 || /SKIP|FILTER|EMPTY/i.test(ev.type || ''));
        } else {
            _liveSpyMemoArr = all;
        }
        return _liveSpyMemoArr;
    };

    let _pinStatusMemoSig = '';
    let _pinStatusMemoArr = [];
    $scope.getVisiblePincodeStatuses = function() {
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const map = q.pincodeStatuses;
        if (!map || typeof map !== 'object') return [];
        const keys = Object.keys(map);
        if (!keys.length) return [];
        const lastKey = keys[keys.length - 1];
        const lastRow = map[lastKey] || {};
        const sig = keys.length + ':' + lastKey + ':' + (lastRow.status || '') + ':' + (lastRow.lastUpdatedAt || '') + ':' + (q.lastUpdatedAt || '');
        if (sig === _pinStatusMemoSig) return _pinStatusMemoArr;
        _pinStatusMemoSig = sig;
        const sliceKeys = keys.slice(-80).reverse();
        const out = [];
        for (let i = 0; i < sliceKeys.length; i++) {
            const k = sliceKeys[i];
            const r = map[k];
            if (r && typeof r === 'object') {
                out.push(r.key ? r : Object.assign({ key: k }, r));
            }
        }
        _pinStatusMemoArr = out;
        return _pinStatusMemoArr;
    };

    $scope.clearLiveSpyEvents = function() {
        $scope.liveSpy.events = [];
        if ($scope.local && $scope.local.apifyQueue) {
            $scope.local.apifyQueue.liveSpyEvents = [];
        }
    };

    $scope.copyLiveSpyLog = function() {
        const events = $scope.getLiveSpyEvents().slice().reverse();
        const lines = events.map(ev => `[${ev.time || ev.iso || ''}] [${ev.type || 'INFO'}] ${ev.taskIndex ? '(' + ev.taskIndex + '/' + (ev.totalTasks || '?') + ') ' : ''}${ev.message || ''}`);
        apiLiveCopyPlainText(lines.join('\n') || 'No live spy events recorded yet.');
        try { $scope.snackbar && $scope.snackbar.show && $scope.snackbar.show('Copied ' + lines.length + ' Live Spy event(s).'); } catch (_) {}
    };

    $scope.exportSkippedReport = async function() {
        try {
            const collected = [];
            const seen = new Set();
            function addRow(r, source) {
                if (!r || typeof r !== 'object') return;
                const status = String(r.status || r.stageStatus || r.resultStatus || '').trim();
                const reason = String(r.reason || r.skipReason || r.error || r.message || r.filterReason || '').trim();
                const placeId = r.placeId || r.place_id || r.id || '';
                const cid = r.cid || '';
                const company = r.companyName || r.company_name || r.name || r.category || '';
                const addr = r.address || r.full_address || '';
                const key = [source || r.source || '', placeId, cid, company, addr, r.query || '', r.keyword || '', r.location || '', status, reason].join('|');
                if (seen.has(key)) return;
                const text = (status + ' ' + reason).toLowerCase();
                const isSkipped = /skip|fail|filter|duplicate|timeout|missing|blocked|error|invalid|no result|not found|all_skipped|no_results/.test(text);
                if (!isSkipped) return;
                seen.add(key);
                collected.push({
                    source: r.source || source || '',
                    placeId,
                    query: r.query || r.textQuery || '',
                    keyword: r.keyword || '',
                    location: r.location || '',
                    status: status || 'Skipped',
                    skipReason: reason || (status ? 'Skipped by status: ' + status : 'No detailed reason saved'),
                    category: company || r.category || '',
                    address: addr,
                    mapsUrl: r.mapsUrl || r.map_link || (placeId ? apiLiveMapsUrl(placeId) : ''),
                    updatedAt: r.lastUpdatedAt || r.createdAt || r.updatedAt || r.time || r.iso || ''
                });
            }
            const storedExtra = await new Promise(resolve => {
                try {
                    chrome.storage.local.get(['plSessionSkippedRecords', 'apifyQueue'], res => resolve(res || {}));
                } catch (_) { resolve({}); }
            });
            const q = Object.assign({}, ($scope.local && $scope.local.apifyQueue) || {}, (storedExtra && storedExtra.apifyQueue) || {});
            if (Array.isArray(storedExtra.plSessionSkippedRecords)) {
                storedExtra.plSessionSkippedRecords.forEach(r => addRow(r, r && r.source ? r.source : 'SessionSkipped'));
            }
            ['placeIdQueue','skipped','failed','filtered','items','logs','events'].forEach(name => {
                const arr = Array.isArray(q[name]) ? q[name] : [];
                arr.forEach(r => addRow(r, (r && r.source) || ('Queue:' + name)));
            });
            if (q.pincodeStatuses && typeof q.pincodeStatuses === 'object') {
                Object.values(q.pincodeStatuses).forEach(st => {
                    if (st && (/fail|no_results|all_skipped/i.test(st.status || '') || (st.failed || 0) > 0 || (st.error))) {
                        addRow({
                            source: 'LocationStatus',
                            query: st.query || '',
                            keyword: st.keyword || '',
                            location: st.location || st.key || '',
                            status: st.status || 'Skipped',
                            reason: st.error || `Location status: ${st.status} (API rows: ${st.apiIds || 0}, Saved: ${st.saved || 0}, Skipped: ${st.skipped || 0})`,
                            companyName: st.location || st.query || '',
                            lastUpdatedAt: st.lastUpdatedAt || ''
                        }, 'LocationStatus');
                    }
                });
            }
            const spyEvents = $scope.getLiveSpyEvents ? $scope.getLiveSpyEvents() : [];
            spyEvents.forEach(ev => {
                if (ev && (ev.level === 'error' || ev.level === 'warn')) {
                    addRow({
                        source: 'LiveSpy:' + (ev.type || 'EVENT'),
                        query: ev.query || '',
                        keyword: ev.keyword || '',
                        location: ev.location || '',
                        status: ev.type || 'Diagnostic',
                        reason: ev.message || '',
                        companyName: ev.provider || '',
                        lastUpdatedAt: ev.iso || ev.time || ''
                    }, 'LiveSpy');
                }
            });
            if (apiLiveMonitorState && Array.isArray(apiLiveMonitorState.rows)) apiLiveMonitorState.rows.forEach(r => addRow(r, 'API Live Monitor'));
            if ($scope.apiLive && $scope.apiLive.result && Array.isArray($scope.apiLive.result.rows)) $scope.apiLive.result.rows.forEach(r => addRow(r, 'API ID Live'));
            const headers = ['Source','Place ID','Query','Keyword','Location','Status','Skip Reason','Category/Company','Address','Maps URL','Updated At'];
            function csv(v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; }
            const csvRows = [headers.map(csv).join(',')];
            collected.forEach(r => {
                csvRows.push([
                    r.source, r.placeId, r.query, r.keyword, r.location, r.status, r.skipReason,
                    r.category, r.address, r.mapsUrl, r.updatedAt
                ].map(csv).join(','));
            });
            if (!collected.length) {
                csvRows.push(['No skipped/failed records found','','','','','','Current session did not save any skip reason records.','','','',''].map(csv).join(','));
            }
            const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'PocketLeads_Skipped_With_Reasons_' + new Date().toISOString().slice(0,19).replace(/[:T]/g,'-') + '.csv';
            document.body.appendChild(a);
            a.click();
            setTimeout(() => { try { URL.revokeObjectURL(url); a.remove(); } catch (e) {} }, 1000);
            try { $scope.snackbar.show('Skipped report exported: ' + collected.length + ' row(s).'); } catch (e) {}
        } catch (err) {
            try { $scope.snackbar && $scope.snackbar.show && $scope.snackbar.show('Export failed: ' + (err && err.message ? err.message : err)); } catch (e) {}
        }
    };

    /*	Toggle Tab*/
    $scope.toggleTab = tab => {
        $scope.local.activeTab = tab;
        $scope.saveLocal();
        $scope.initiMaterialDesignComponents();
    };
    
    $scope.resultStoreHydrated = false;
    $scope._canonicalGeneration = 0;
    $scope._pendingResultEdits = new Map();
    $scope._resultStoreSyncTimer = null;
    $scope._liveCanonicalSyncTimer = null;
    $scope._liveCanonicalSyncInFlight = false;
    $scope._liveCanonicalSyncTarget = 0;
    $scope._canonicalWatchdogBusy = false;

    // Reconcile the visible dashboard with IndexedDB, including idle/reopened
    // dashboards whose last runtime delta or storage notification was missed.
    $scope._canonicalWatchdogTimer = setInterval(async () => {
        try {
            const local = $scope.local || {};
            const queue = local.apifyQueue || {};
            const status = String(queue.status || '').toLowerCase();
            const active = PocketLeadsRunState.isRunning(local)
                || /starting|searching|streaming|google_pipeline|dataset_saved|switching_key|resuming/.test(status);
            if (document.hidden || $scope._canonicalWatchdogBusy) return;
            $scope._canonicalWatchdogBusy = true;
            const isIdleCleared = !!($scope._isClearedSession || (status === 'idle' && !active && (parseInt(queue.scrapedCount, 10) || 0) === 0 && (!local.collect || local.collect.length === 0)));
            if (isIdleCleared) {
                if (Number(local.resultStoreCount) !== 0 || Number($scope._monotonicResultCount) !== 0) {
                    $scope.$evalAsync(() => {
                        if (!$scope.local) return;
                        $scope._monotonicResultCount = 0;
                        $scope._monotonicTaskCompleted = 0;
                        $scope.local.resultStoreCount = 0;
                        $scope.local.collect = [];
                        $scope.local.collectIsPreview = false;
                    });
                }
                return;
            }
            const count = await getCanonicalStoreCount();
            const visible = Array.isArray(local.collect) ? local.collect.length : 0;
            const needHydrate = !$scope.resultStoreHydrated || (count > 0 && visible < Math.min(5000, count) && !active) || !!$scope.resultStoreError;
            if (count !== Number(local.resultStoreCount) || needHydrate) {
                $scope.$evalAsync(() => {
                    if (!$scope.local || $scope._isClearedSession) return;
                    const bestCount = active
                        ? Math.max(parseInt($scope._monotonicResultCount, 10) || 0, parseInt($scope.local.resultStoreCount, 10) || 0, count)
                        : (count > 0 ? Math.max(parseInt($scope._monotonicResultCount, 10) || 0, count) : 0);
                    $scope._monotonicResultCount = bestCount;
                    $scope.local.resultStoreCount = bestCount;
                    $scope.local.collectIsPreview = bestCount > visible;
                    if (needHydrate && typeof $scope.syncLiveCanonicalTable === 'function') {
                        $scope.syncLiveCanonicalTable(bestCount);
                    }
                });
            }
        } catch (e) {
            // The next interval is enough; never interrupt scraping for a UI check.
        } finally {
            $scope._canonicalWatchdogBusy = false;
        }
    }, 1500);
    $scope.$on('$destroy', function(){
        try { if ($scope._canonicalWatchdogTimer) clearInterval($scope._canonicalWatchdogTimer); } catch (e) {}
        try { if ($scope._liveCanonicalSyncTimer) clearTimeout($scope._liveCanonicalSyncTimer); } catch (e) {}
    });

    // v87 safety net for any missed realtime delta. This only hydrates when the
    // server/queue says IndexedDB contains MORE rows than the table currently has,
    // so it does not repeatedly reload a healthy live grid.
    $scope.syncLiveCanonicalTable = function() {
        if ($scope._liveCanonicalSyncInFlight) { $scope._canonicalReloadPending = true; return; }
        if ($scope._liveCanonicalSyncTimer) return;
        $scope._liveCanonicalSyncTimer = setTimeout(() => {
            $scope._liveCanonicalSyncTimer = null;
            $scope.hydrateResultsFromIndexedDB();
        }, 30);
    };
    $scope.hydrateResultsFromIndexedDB = async function() {
        if ($scope._liveCanonicalSyncInFlight) { $scope._canonicalReloadPending = true; return; }
        $scope._liveCanonicalSyncInFlight = true;
        const runId = $scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.runEventId;
        const generation = $scope._canonicalGeneration;
        try {
            const result = await runtimeMessageAsync({action:'result_store_query',query:{offset:0,limit:5000}});
            if (!result || result.ok === false || !Array.isArray(result.rows) || !Number.isFinite(result.count)) throw Error('Canonical results unavailable');
            $scope.$evalAsync(() => {
                const latestRunId = $scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.runEventId;
                const latestStatus = String(($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.status) || '').toLowerCase();
                if (!$scope.local || $scope._isClearedSession || (latestStatus === 'idle' && !PocketLeadsRunState.isRunning($scope.local) && !($scope.local.apifyQueue && $scope.local.apifyQueue.scrapedCount))) return;
                if (runId && latestRunId && runId !== latestRunId) return;
                if (generation !== $scope._canonicalGeneration) return;
                const isRunningNow = PocketLeadsRunState.isRunning($scope.local);
                const bestTotal = isRunningNow
                    ? Math.max(parseInt($scope._monotonicResultCount, 10) || 0, parseInt($scope.local.resultStoreCount, 10) || 0, result.count, result.rows.length)
                    : Math.max(result.count, result.rows.length);
                $scope._monotonicResultCount = bestTotal;
                $scope.local.collect = result.rows;
                $scope.local.collectIsPreview = bestTotal > result.rows.length;
                $scope.local.resultStoreCount = bestTotal;
                $scope.resultStoreHydrated = true;
                $scope.resultStoreError = '';
                buildDataTable($scope.local);
            });
        } catch (e) { $scope.$evalAsync(() => { $scope.resultStoreError = 'Saved results unavailable. Retrying…'; }); }
        finally {
            $scope._liveCanonicalSyncInFlight = false;
            if ($scope._canonicalReloadPending) { $scope._canonicalReloadPending = false; $scope.syncLiveCanonicalTable(); }
        }
    };

    $scope.saveLocal = function(onSaved) {
        const rows = Array.isArray($scope.local && $scope.local.collect) ? $scope.local.collect : [];
        const currentSignature = computeCollectUiSignature(rows);
        // Results are canonical in IndexedDB. Only send rows whose content
        // actually changed; progress/settings saves must never re-send the full
        // hydrated dataset.
        if (currentSignature !== $scope._lastResultStoreSyncSignature) {
            try {
                if (!($scope._resultStoreRowHashes instanceof Map)) $scope._resultStoreRowHashes = new Map();
                const changedRows = [];
                rows.forEach((row, idx) => {
                    const key = String((row && (row.place_id || row.cid || row.map_link || row.phone || row.company_name)) || ('row_' + idx));
                    let hash = '';
                    try { hash = JSON.stringify(row || {}); } catch (e) { hash = String(row); }
                    if ($scope._resultStoreRowHashes.get(key) !== hash) {
                        $scope._resultStoreRowHashes.set(key, hash);
                        changedRows.push(row);
                    }
                });
                changedRows.forEach(row => $scope._pendingResultEdits.set(String(row.place_id || row.cid || row.map_link || row.phone || row.company_name), row));
                if (!$scope._resultStoreSyncTimer && $scope._pendingResultEdits.size) {
                    const generation = $scope._canonicalGeneration;
                    const runId = $scope.local.apifyQueue && $scope.local.apifyQueue.runEventId;
                    $scope._resultStoreSyncTimer = setTimeout(async () => {
                        $scope._resultStoreSyncTimer = null;
                        const edits = [...$scope._pendingResultEdits.values()];
                        $scope._pendingResultEdits.clear();
                        for (let attempt = 0; attempt < 3; attempt++) {
                            if (generation !== $scope._canonicalGeneration) return;
                            try {
                                const response = await runtimeMessageAsync({action:'result_store_upsert',rows:edits,runId});
                                if (!response || !response.ok || !response.result) throw Error('Result update not saved');
                                $scope.$evalAsync(() => {if(generation===$scope._canonicalGeneration)$scope.local.resultStoreCount=response.result.total;});
                                return;
                            } catch(e) {
                                if(attempt===2){$scope._lastResultStoreSyncSignature='';$scope._resultStoreRowHashes.clear();$scope.$evalAsync(()=>{$scope.resultStoreError='Result edits could not be saved. Retry after reopening the dashboard.';});}
                                else await new Promise(resolve=>setTimeout(resolve,200*(attempt+1)));
                            }
                        }
                    }, 250);
                }
                $scope._lastResultStoreSyncSignature = currentSignature;
            } catch (e) {
                console.warn('Result-store incremental sync failed', e);
            }
        }
        const previewLimit = 5000;
        const cappedTasks = Array.isArray($scope.local && $scope.local.taskList)
            ? $scope.local.taskList.slice(0, 400)
            : [];
        const cappedLocations = Array.isArray($scope.local && $scope.local.locationList)
            ? $scope.local.locationList.slice(0, 500)
            : [];
        const storageLocal = Object.assign({}, $scope.local, {
            taskList: cappedTasks,
            locationList: cappedLocations,
            collect: rows.slice(-previewLimit),
            collectIsPreview: Number($scope.local.resultStoreCount) > Math.min(rows.length, previewLimit),
            resultStoreCount: Math.max(0, Number($scope.local.resultStoreCount) || 0),
            resultStoreMigrated: true
        });
        $box.setLocal(storageLocal, {
            onSet: function() {
                if (typeof onSaved === 'function') {
                    try { onSaved(); } catch (e) { console.warn('saveLocal callback failed', e); }
                }
            }
        });
    };

    $scope.sendMessage = function(action, data = {}) {
        console.log("Message sent: " + action);
        $box.send(action, data);
    };
    
    /* URL List — Ultra-Fast Memoized & Windowed Task Builder (v10.19.38) */
    const MAX_UI_TASK_PREVIEW = 400;
    function computeFastTaskSignature(kwList, locList) {
        const kws = Array.isArray(kwList) ? kwList : [];
        const locs = Array.isArray(locList) ? locList : [];
        const total = kws.length * locs.length;
        if (total === 0) return '';
        if (total <= 120) {
            const out = [];
            for (let i = 0; i < kws.length; i++) {
                for (let j = 0; j < locs.length; j++) {
                    out.push(kws[i] + '~in~' + locs[j]);
                }
            }
            return out.join('\n');
        }
        let h1 = 2166136261 >>> 0;
        let h2 = 16777619 >>> 0;
        for (let i = 0; i < kws.length; i++) {
            const s = kws[i];
            for (let c = 0; c < s.length; c++) {
                h1 ^= s.charCodeAt(c);
                h1 = Math.imul(h1, 16777619) >>> 0;
            }
            h1 ^= 126;
        }
        for (let j = 0; j < locs.length; j++) {
            const s = locs[j];
            for (let c = 0; c < s.length; c++) {
                h2 ^= s.charCodeAt(c);
                h2 = Math.imul(h2, 16777619) >>> 0;
            }
            h2 ^= 10;
        }
        return 'v38sig:' + kws.length + 'x' + locs.length + ':' + total + ':' + h1.toString(36) + '_' + h2.toString(36);
    }

    let _memoKwRaw = null, _memoKwArr = [];
    let _memoLocRaw = null, _memoLocArr = [];
    let _memoBlRaw = null, _memoBlArr = [];
    let _saveAsListPersistTimer = null;

    function dedupeCleanLinesFast(rawText) {
        const str = String(rawText || '');
        if (!str) return [];
        const seen = new Set();
        const out = [];
        const lines = str.split(/\r?\n/);
        for (let i = 0; i < lines.length; i++) {
            const clean = lines[i].replace(/\s+/g, ' ').trim();
            if (!clean) continue;
            const key = clean.toLowerCase();
            if (!seen.has(key)) {
                seen.add(key);
                out.push(clean);
            }
        }
        return out;
    }

        $scope.kwInputFocused = false;
    $scope.locInputFocused = false;
    $scope.clearKeywordInputCard = function($event) {
        if ($event) {
            try { $event.preventDefault(); $event.stopPropagation(); } catch (_) {}
        }
        if (!$scope.local) $scope.local = {};
        $scope.local.keywordTextarea = '';
        $scope.local.keywordList = [];
        _memoKwRaw = '';
        _memoKwArr = [];
        $scope.saveAsList();
        setTimeout(function() {
            try {
                const el = document.getElementById($scope.viewMode === 'mobile' ? 'mobileKeywordTextarea' : 'keywordTextarea');
                if (el) { el.value = ''; el.focus(); }
            } catch (_) {}
        }, 10);
    };
    $scope.clearLocationInputCard = function($event) {
        if ($event) {
            try { $event.preventDefault(); $event.stopPropagation(); } catch (_) {}
        }
        if (!$scope.local) $scope.local = {};
        $scope.local.locationTextarea = '';
        $scope.local.locationList = [];
        _memoLocRaw = '';
        _memoLocArr = [];
        $scope.saveAsList();
        setTimeout(function() {
            try {
                const el = document.getElementById($scope.viewMode === 'mobile' ? 'mobileLocationTextarea' : 'locationTextarea');
                if (el) { el.value = ''; el.focus(); }
            } catch (_) {}
        }, 10);
    };

    $scope.saveAsList = (skipPersist)=>{
        const keywordText = String(($scope.local && $scope.local.keywordTextarea) || '');
        const locationText = String(($scope.local && $scope.local.locationTextarea) || '');
        const blackListText = String(($scope.local && $scope.local.blackListTextarea) || '');

        if (keywordText !== _memoKwRaw) {
            _memoKwRaw = keywordText;
            _memoKwArr = dedupeCleanLinesFast(keywordText);
        }
        if (locationText !== _memoLocRaw) {
            _memoLocRaw = locationText;
            _memoLocArr = dedupeCleanLinesFast(locationText);
        }
        if (blackListText !== _memoBlRaw) {
            _memoBlRaw = blackListText;
            _memoBlArr = dedupeCleanLinesFast(blackListText);
        }

        $scope.local.keywordList = _memoKwArr;
        $scope.local.locationList = _memoLocArr;
        $scope.local.blackList = _memoBlArr;
        $scope._kwCountCacheRaw = keywordText;
        $scope._kwCountCacheVal = _memoKwArr.length;
        $scope._locCountCacheRaw = locationText;
        $scope._locCountCacheVal = _memoLocArr.length;
        $scope.local.fastMode = false;

        const kwLen = _memoKwArr.length;
        const locLen = _memoLocArr.length;
        const totalTasks = kwLen * locLen;
        const previewCollect = [];
        if (kwLen && locLen) {
            outerLoop:
            for (let i = 0; i < kwLen; i++) {
                const kw = _memoKwArr[i];
                for (let j = 0; j < locLen; j++) {
                    previewCollect.push(kw + '~in~' + _memoLocArr[j]);
                    if (previewCollect.length >= MAX_UI_TASK_PREVIEW) break outerLoop;
                }
            }
        }
        $scope.local.taskList = previewCollect;
        if (!$scope.isScrapingActive()) {
            $scope.local.apifyTaskTotal = totalTasks;
        }
        if (!skipPersist) {
            $scope.updateUIState();
            if (_saveAsListPersistTimer) clearTimeout(_saveAsListPersistTimer);
            _saveAsListPersistTimer = setTimeout(() => {
                _saveAsListPersistTimer = null;
                $scope.saveLocal();
            }, 120);
        }
    };

    // --------------------------------------------------------------------
    // Enforce fast mode limits on keyword and location textareas in real time.
    //
    // When the user types or pastes more than 20 lines into either textarea
    // while fast mode is enabled, immediately truncate the extra lines and
    // surface a snackbar message.  This watcher runs within Angular's digest
    // cycle, so updating the model will propagate to the view automatically.
    $scope.$watch('local.locationTextarea', function(newVal, oldVal) {
        if ($scope.local.fastMode && newVal !== oldVal) {
            const lines = newVal ? newVal.split('\n') : [];
            const limit = 20;
            if (lines.length > limit) {
                // Truncate to the first 20 lines and update both the textarea and list.
                $scope.local.locationTextarea = lines.slice(0, limit).join('\n');
                $scope.local.locationList = $scope.local.locationTextarea.split('\n').filter(x => x.length);
                // Show the limit modal instead of a snackbar.  Persist the flag so
                // the modal remains visible until dismissed.
                $scope.local.showLimitModal = true;
                $scope.saveLocal();
            }
        }
    });
    $scope.$watch('local.keywordTextarea', function(newVal, oldVal) {
        if ($scope.local.fastMode && newVal !== oldVal) {
            const lines = newVal ? newVal.split('\n') : [];
            const limit = 20;
            if (lines.length > limit) {
                $scope.local.keywordTextarea = lines.slice(0, limit).join('\n');
                $scope.local.keywordList = $scope.local.keywordTextarea.split('\n').filter(x => x.length);
                // Show the limit modal instead of a snackbar.  Persist the flag
                // so that the modal remains visible until dismissed.
                $scope.local.showLimitModal = true;
                $scope.saveLocal();
            }
        }
    });

    /* ------------------------------------------------------------------------
     * Watch for changes to the collected results.
     *
     * In fast scrape mode the background service worker updates the
     * local.collect array directly via chrome.storage without always
     * triggering the $box.onLocalChange callback in the popup.  As a
     * consequence the data grid can fail to update when new results are
     * inserted while scraping at high speed.  To ensure the dashboard
     * reflects newly added businesses regardless of how the array is
     * mutated, watch the length of local.collect.  Whenever the count
     * increases or decreases we refresh the data grid and update the UI
     * state.  Using $scope.$evalAsync defers execution until after
     * Angular’s current digest cycle completes, preventing infinite
     * digest errors.  The scroll position is preserved so that the
     * viewport does not jump when new rows are appended.
     */
    // Result batches are already handled by $box.onLocalChange above and the
    // IndexedDB hydration path. Do not watch local.collect.length here: rapid
    // storage batches can change it repeatedly inside the same Angular digest,
    // causing [$rootScope:infdig] while the table is being refreshed.
    // Direct feature flows (such as Email Scraping) update the grid explicitly.

    
    /* Fast email extraction: Maps profile emails first, then a bounded website
       worker pool. A page is fetched once; only same-origin contact/about
       links are visited when the homepage contains no address. */
    const EMAIL_WORKERS = 12;
    const EMAIL_TIMEOUT_MS = 3800;
    const EMAIL_FOLLOWUP_TIMEOUT_MS = 2400;
    const EMAIL_MAX_HTML_CHARS = 160000;
    const EMAIL_CACHE_MAX_ENTRIES = 600;
    let emailRunToken = 0;
    const emailControllers = new Set();
    const websiteScrapeCache = new Map();
    $scope.emailScrapeDone = 0;
    $scope.emailScrapeTotal = 0;

    function canonicalWebsiteUrl(value) {
        let raw = String(value || '').trim();
        if (!raw) return '';
        if (/^(?:https?:\/\/(?:www\.)?google\.[^/]+)?\/url\?/i.test(raw)) {
            try {
                const u = new URL(raw.startsWith('/') ? ('https://www.google.com' + raw) : raw);
                const target = u.searchParams.get('q') || u.searchParams.get('url') || '';
                if (target) raw = target.trim();
            } catch (e) {}
        }
        if (!/^https?:\/\//i.test(raw)) raw = 'https://' + raw.replace(/^\/+/, '');
        try {
            const url = new URL(raw);
            if (!/^https?:$/i.test(url.protocol) || /(^|\.)google\./i.test(url.hostname) || /gstatic\./i.test(url.hostname)) return '';
            url.hash = '';
            return url.href;
        } catch (e) { return ''; }
    }

    function decodeCfEmails(html) {
        const decoded = [];
        const text = String(html || '');
        if (!text.includes('cfemail') && !text.includes('email-protection')) return '';
        const rx = /(?:data-cfemail=["']|email-protection#)([0-9a-fA-F]{10,160})/gi;
        let m;
        while ((m = rx.exec(text)) !== null) {
            try {
                const hex = m[1];
                const r = parseInt(hex.substr(0, 2), 16);
                let email = '';
                for (let n = 2; n < hex.length; n += 2) {
                    email += String.fromCharCode(parseInt(hex.substr(n, 2), 16) ^ r);
                }
                if (email.includes('@')) decoded.push(email);
            } catch (e) {}
        }
        return decoded.join(' ');
    }

    // Part 2 #2: Smart Junk Email Filter + Business Relevance Scorer
    const JUNK_EMAIL_DOMAIN_RX = /(?:sentry|wixpress|wix\.com|example|domain|yoursite|yourdomain|email\.com|test\.com|localhost|schema\.org|w3\.org|cloudflare|wordpress|getbootstrap|googleapis|googleusercontent|gravatar|godaddy|squarespace|shopify|fontawesome|jsdelivr|unpkg|cdnjs|gstatic|facebook\.com|instagram\.com|twitter\.com|linkedin\.com|tiktok\.com|youtube\.com|google\.com|apple\.com|microsoft\.com|amazonaws\.com|heroku|vercel|netlify| LatLng|brochure|template|placeholder|mywebsite|company\.com|business\.com|abc\.com|xyz\.com)/i;
    const JUNK_EMAIL_LOCAL_RX = /^(?:noreply|no-reply|donotreply|do-not-reply|mailer-daemon|postmaster|hostmaster|abuse|privacy|legal|dmca|gdpr|security|bugbounty|webmaster@wix|user|username|name|firstname|lastname|yourname|youremail|email|test|testing|sample|demo|placeholder|null|undefined|admin@wordpress|[0-9a-f]{24,}|\d+x\d+)$/i;

    function scoreEmailCandidate(email, siteHostname) {
        const parts = String(email || '').toLowerCase().split('@');
        if (parts.length !== 2) return -999;
        const [local, domain] = parts;
        let score = 10;
        const cleanHost = String(siteHostname || '').toLowerCase().replace(/^www\./, '');
        if (cleanHost && (domain === cleanHost || cleanHost.endsWith('.' + domain) || domain.endsWith('.' + cleanHost))) {
            score += 55;
        }
        if (/^(?:info|contact|contactus|sales|enquir|inquir|office|hello|support|care|booking|appointments?|desk|reception|clinic|hospital|store|shop|orders?|owner|founder|director|ceo|md|partner|hr|admin|billing|accounts?|help|mail|connect|reach|team|business)/i.test(local)) {
            score += 35;
        }
        if (/^(?:gmail\.com|yahoo\.(?:com|co\.in|in)|outlook\.com|hotmail\.com|rediffmail\.com|icloud\.com|zoho(?:mail)?\.(?:com|in)|protonmail\.com|live\.com)$/i.test(domain)) {
            score += 22;
        }
        if (local.length <= 2 || /\d{6,}/.test(local)) score -= 12;
        return score;
    }

    function extractEmailCandidates(value, siteUrl) {
        const rawHtml = String(value == null ? '' : value).slice(0, EMAIL_MAX_HTML_CHARS);
        const cfDecoded = decodeCfEmails(rawHtml);
        let decodedMailtos = '';
        if (rawHtml.includes('mailto:')) {
            try {
                const mailtoRx = /mailto:\s*([^"'\s?>#<]+)/gi;
                let mm;
                while ((mm = mailtoRx.exec(rawHtml)) !== null) {
                    try { decodedMailtos += ' ' + decodeURIComponent(mm[1]); } catch (e) { decodedMailtos += ' ' + mm[1]; }
                }
            } catch (e) {}
        }
        let siteHost = '';
        try { if (siteUrl) siteHost = new URL(siteUrl).hostname; } catch (_) {}
        const text = (rawHtml + ' ' + cfDecoded + ' ' + decodedMailtos)
            .replace(/\\\//g, '/')
            .replace(/\\u002f/gi, '/')
            .replace(/\\u0040|&commat;|&#0*64;|&#x0*40;|%40|\u0040/gi, '@')
            .replace(/\\u002e|&period;|&#0*46;|&#x0*2e;/gi, '.')
            .replace(/&#(\d{2,3});/g, (_, code) => {
                const n = parseInt(code, 10);
                return (n >= 32 && n <= 126) ? String.fromCharCode(n) : ' ';
            })
            .replace(/&#x([0-9a-f]{2});/gi, (_, hex) => {
                const n = parseInt(hex, 16);
                return (n >= 32 && n <= 126) ? String.fromCharCode(n) : ' ';
            })
            .replace(/\s*(?:\[|\(|\{)\s*at\s*(?:\]|\)|\})\s*/gi, '@')
            .replace(/\s*(?:\[|\(|\{)\s*dot\s*(?:\]|\)|\})\s*/gi, '.');
        const found = [];
        const re = /[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+/gi;
        let match;
        while ((match = re.exec(text)) !== null) {
            const email = match[0].toLowerCase().replace(/[.,;:]+$/, '').replace(/^(?:u003e|u003c|u0022|u0027|20|3a)+/i, '');
            if (!email || email.length < 5 || email.length > 120) continue;
            if (/\.(?:png|jpg|jpeg|gif|svg|webp|ico|css|js|woff|woff2|ttf|eot|mp4|mp3|pdf|zip|json|xml|map|tsx|jsx|ts|php|asp|aspx|html|htm)$/i.test(email)) continue;
            const [localPart, domainPart] = email.split('@');
            if (!localPart || !domainPart || !domainPart.includes('.')) continue;
            const tld = domainPart.split('.').pop() || '';
            if (tld.length < 2 || tld.length > 12 || /^\d+$/.test(tld)) continue;
            if (JUNK_EMAIL_DOMAIN_RX.test(domainPart) || JUNK_EMAIL_LOCAL_RX.test(localPart)) continue;
            if (!found.includes(email)) found.push(email);
            if (found.length >= 12) break;
        }
        found.sort((a, b) => scoreEmailCandidate(b, siteHost) - scoreEmailCandidate(a, siteHost));
        return found.slice(0, 5);
    }

    // Fast zero-DOMParser regex link extractor so 4,000-5,000 websites never allocate DOM trees on the UI thread
    function emailLinksFromHtml(html, baseUrl) {
        const scored = [];
        const seen = new Set();
        const stripWww = h => String(h || '').toLowerCase().replace(/^www\./, '');
        try {
            const base = new URL(baseUrl);
            const baseRoot = stripWww(base.hostname);
            const boundedHtml = String(html || '').slice(0, EMAIL_MAX_HTML_CHARS);
            const anchorRx = /<a\b[^>]*?\bhref\s*=\s*(?:["']([^"']{1,320})["']|([^\s>"']{1,320}))[^>]*>([\s\S]{0,240}?)<\/a>/gi;
            let m;
            let count = 0;
            while ((m = anchorRx.exec(boundedHtml)) !== null && count < 250) {
                count++;
                const href = String(m[1] || m[2] || '').trim().replace(/&amp;/gi, '&');
                if (!href || /^(?:mailto:|tel:|javascript:|#|data:)/i.test(href)) continue;
                const innerText = String(m[3] || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
                const label = (innerText + ' ' + href).toLowerCase();
                const isContact = /(contact|get-in-touch|touch|enquir|reach|connect|write-to-us)/i.test(label);
                const isAbout = /(about|impressum|support|help|team|office|clinic|location|info)/i.test(label);
                if (!isContact && !isAbout) continue;
                try {
                    const url = new URL(href, baseUrl);
                    if (!/^https?:$/i.test(url.protocol)) continue;
                    if (stripWww(url.hostname) !== baseRoot) continue;
                    if (/\.(?:pdf|jpg|jpeg|png|gif|svg|webp|zip|mp4|mp3|css|js|xml|json)$/i.test(url.pathname)) continue;
                    url.hash = '';
                    const clean = url.href;
                    if (clean !== base.href && !seen.has(clean)) {
                        seen.add(clean);
                        scored.push({ url: clean, score: isContact ? 100 : 50 });
                    }
                } catch (e) {}
            }
            scored.sort((a, b) => b.score - a.score);
            const hasExplicitContact = scored.some(item => item.score >= 100);
            if (!hasExplicitContact) {
                ['/contact', '/contact-us'].forEach(path => {
                    try {
                        const fallbackUrl = new URL(path, base.origin).href;
                        if (fallbackUrl !== base.href && !seen.has(fallbackUrl)) {
                            seen.add(fallbackUrl);
                            scored.push({ url: fallbackUrl, score: 85 });
                        }
                    } catch (e) {}
                });
                scored.sort((a, b) => b.score - a.score);
            }
        } catch (e) {}
        return scored.slice(0, 2).map(item => item.url);
    }

    async function fetchEmailPage(url, customTimeoutMs) {
        const timeoutMs = Math.max(2000, Number(customTimeoutMs) || EMAIL_TIMEOUT_MS);
        try {
            if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
                const bgRes = await new Promise(resolve => {
                    let done = false;
                    const t = setTimeout(() => { if (!done) { done = true; resolve({ ok: false, timedOut: true }); } }, timeoutMs + 1500);
                    try {
                        chrome.runtime.sendMessage({ action: 'pocketleads_fetch_website', url, timeoutMs }, resp => {
                            clearTimeout(t);
                            if (done) return;
                            done = true;
                            if (chrome.runtime && chrome.runtime.lastError) return resolve(null);
                            resolve(resp || { ok: false });
                        });
                    } catch (e) { clearTimeout(t); if (!done) { done = true; resolve(null); } }
                });
                if (bgRes && bgRes.ok && bgRes.html) {
                    const clipped = bgRes.html.length > EMAIL_MAX_HTML_CHARS ? bgRes.html.slice(0, EMAIL_MAX_HTML_CHARS) : bgRes.html;
                    return { ok: true, html: clipped, url: bgRes.url || url };
                }
            }
        } catch (bgErr) {}

        throw new Error('Website request failed');
    }

    function ensureWebsiteEmailHostPermission() {
        return Promise.resolve(true);
    }

    function extractSocialLinksFromHtml(html, sourceUrl) {
        const text = (String(html || '').slice(0, EMAIL_MAX_HTML_CHARS) + ' ' + String(sourceUrl || ''))
            .replace(/\\\//g, '/')
            .replace(/\\u002f/gi, '/')
            .replace(/&amp;/gi, '&');
        const socials = { facebook: '', instagram: '', linkedin: '', twitter: '', youtube: '' };
        const patterns = [
            ['facebook', /https?:\/\/(?:www\.|m\.|web\.)?(?:facebook|fb)\.com\/(?!sharer|plugins|tr\?|dialog|events|groups|watch|pages\/category|share\.php|login|help|policies)(?:profile\.php\?id=\d+|pages\/[a-zA-Z0-9._\-%]+\/?\d*|people\/[a-zA-Z0-9._\-%]+\/?\d*|[a-zA-Z0-9._\-]{2,80})\/?/i],
            ['instagram', /https?:\/\/(?:www\.)?(?:instagram\.com|instagr\.am)\/(?!p\/|reel\/|reels\/|explore\/|accounts\/|stories\/|tv\/|about\/|developer\/)[a-zA-Z0-9._]{2,60}\/?/i],
            ['linkedin', /https?:\/\/(?:[a-z]{2,3}\.)?linkedin\.com\/(?:company|in|school)\/[a-zA-Z0-9._\-%]{2,100}\/?/i],
            ['twitter', /https?:\/\/(?:www\.)?(?:twitter|x)\.com\/(?!intent|share|home|search|hashtag|i\/|privacy|tos|explore|login)[a-zA-Z0-9_]{2,50}\/?/i],
            ['youtube', /https?:\/\/(?:www\.)?youtube\.com\/(?:@[a-zA-Z0-9._\-]+|channel\/[a-zA-Z0-9_\-]+|c\/[a-zA-Z0-9_\-]+|user\/[a-zA-Z0-9_\-]+)\/?/i]
        ];
        for (const [key, regex] of patterns) {
            const m = text.match(regex);
            if (m && m[0]) socials[key] = m[0].replace(/["'<>\\),;\s]+$/, '');
        }
        return socials;
    }

    // Part 1 #8: Battery-Saver Eco Mode Monitor
    const plBatteryState = { level: 1, charging: true, isEco: false };
    try {
        if (typeof navigator !== 'undefined' && typeof navigator.getBattery === 'function') {
            navigator.getBattery().then(batt => {
                if (!batt) return;
                const syncBatt = () => {
                    plBatteryState.level = typeof batt.level === 'number' ? batt.level : 1;
                    plBatteryState.charging = !!batt.charging;
                    plBatteryState.isEco = (!plBatteryState.charging && plBatteryState.level <= 0.22);
                };
                syncBatt();
                batt.addEventListener('levelchange', syncBatt);
                batt.addEventListener('chargingchange', syncBatt);
            }).catch(() => {});
        }
    } catch (_) {}

    function isEcoModeActive() {
        return !!(plBatteryState.isEco || (typeof document !== 'undefined' && document.hidden));
    }

    // Part 1 #7: 2G / Slow Network Adaptive Timeout Calculator
    function getAdaptiveEmailTimeoutMs(isFollowup, isRetryPass) {
        if (isRetryPass) return isFollowup ? 11000 : 18500;
        let slowNet = false;
        try {
            const conn = navigator && (navigator.connection || navigator.mozConnection || navigator.webkitConnection);
            if (conn) {
                const eff = String(conn.effectiveType || '').toLowerCase();
                if (eff === 'slow-2g' || eff === '2g' || eff === '3g' || Number(conn.rtt) > 550 || conn.saveData) {
                    slowNet = true;
                }
            }
        } catch (_) {}
        if (slowNet) return isFollowup ? 9500 : 15500;
        return isFollowup ? EMAIL_FOLLOWUP_TIMEOUT_MS : EMAIL_TIMEOUT_MS;
    }

    // Part 3 #5: Auto-Pause & Auto-Resume on Network Drop
    let networkDropToastShown = false;
    async function waitForInternetConnection(maxWaitMs = 90000) {
        try {
            if (typeof navigator === 'undefined' || navigator.onLine !== false) return true;
            if (!networkDropToastShown) {
                networkDropToastShown = true;
                try { showTopStatusToast('⏸️ Internet disconnected — Paused, waiting to auto-resume...', 'warn'); } catch (_) {}
            }
            const started = Date.now();
            while (navigator.onLine === false && (Date.now() - started) < maxWaitMs) {
                await new Promise(r => setTimeout(r, 900));
            }
            if (navigator.onLine !== false && networkDropToastShown) {
                networkDropToastShown = false;
                try { showTopStatusToast('▶️ Internet connected — Auto-resuming extraction!', 'success'); } catch (_) {}
            }
            return navigator.onLine !== false;
        } catch (_) {
            return true;
        }
    }

    try {
        if (typeof window !== 'undefined' && !window.__plOnlineListenersBound) {
            window.__plOnlineListenersBound = true;
            window.addEventListener('offline', () => {
                if (PocketLeadsRunState.isRunning($scope.local) || $scope.isScrapingActive() || $scope.startLaunchPending || ($scope.local && $scope.local.isScrapingEmail)) {
                    $scope._lastStopTimerTickMs = 0;
                    if ($scope.local && $scope.local.isScrapingEmail) {
                        try { $scope.stopEmailScraping(); } catch (_) {}
                    }
                    $scope.manualStopScraping('offline');
                }
            });
            window.addEventListener('online', () => {
                if (PocketLeadsRunState.isRunning($scope.local) || ($scope.local && $scope.local.isScrapingEmail)) {
                    showTopStatusToast('▶️ Internet restored — Auto-resuming extraction!', 'success');
                }
            });
        }
    } catch (_) {}

    // Part 2 #3: Franchise / Same-Domain Root Normalizer
    const SHARED_DIRECTORY_DOMAINS_RX = /^(?:facebook\.com|fb\.com|instagram\.com|instagr\.am|linkedin\.com|twitter\.com|x\.com|youtube\.com|youtu\.be|wa\.me|api\.whatsapp\.com|google\.com|goo\.gl|maps\.app\.goo\.gl|justdial\.com|indiamart\.com|sulekha\.com|practo\.com|zomato\.com|swiggy\.com|magicpin\.in|urbanpro\.com|lybrate\.com|linktr\.ee|bit\.ly|tinyurl\.com|sites\.google\.com|business\.site)$/i;
    const franchiseDomainCache = new Map();

    function getNormalizedFranchiseDomain(urlStr) {
        try {
            const u = new URL(urlStr);
            const host = String(u.hostname || '').toLowerCase().replace(/^www\./, '');
            if (!host || SHARED_DIRECTORY_DOMAINS_RX.test(host)) return '';
            return host;
        } catch (_) {
            return '';
        }
    }

    // Part 3 #10: Pre-filter valid scrapable business websites
    function isScrapableBusinessWebsite(rawUrl) {
        const s = String(rawUrl || '').trim();
        if (!s || s === '—' || /^(?:no website|n\/a|none|null|undefined)$/i.test(s)) return false;
        const clean = canonicalWebsiteUrl(s);
        if (!clean) return false;
        if (/google\.com\/(?:maps|search)|maps\.app\.goo\.gl|wa\.me\/|api\.whatsapp\.com/i.test(clean)) return false;
        return true;
    }

    // Part 1 #3: Hybrid Ghost WebView DOM Fallback for SPA / React / Cloudflare Sites
    let activeGhostRenders = 0;
    async function fetchRenderedDomFallback(url) {
        if (activeGhostRenders >= 2) return null;
        activeGhostRenders++;
        try {
            if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.fetchRenderedWebsiteDomAsync === 'function' && window.__plNativeCallbacks) {
                return await new Promise(resolve => {
                    const cbId = 'dom_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
                    const timer = setTimeout(() => {
                        window.__plNativeCallbacks.delete(cbId);
                        resolve(null);
                    }, 6200);
                    window.__plNativeCallbacks.set(cbId, (resJson) => {
                        clearTimeout(timer);
                        window.__plNativeCallbacks.delete(cbId);
                        try {
                            const parsed = JSON.parse(resJson);
                            resolve(parsed && parsed.ok && parsed.body ? parsed.body : null);
                        } catch (_) {
                            resolve(null);
                        }
                    });
                    window.AndroidChromeBridge.fetchRenderedWebsiteDomAsync(url, 2100, cbId);
                });
            }
        } catch (_) {
        } finally {
            activeGhostRenders = Math.max(0, activeGhostRenders - 1);
        }
        return null;
    }

    function looksLikeDynamicSpaOrCloudflare(html) {
        const s = String(html || '');
        if (!s) return false;
        if (/cf-browser-verification|Just a moment\.\.\.|__NEXT_DATA__|__NUXT__|ng-version=|data-reactroot|<div\s+id=["'](?:root|app|__next)["']\s*><\/div>/i.test(s)) {
            return true;
        }
        const stripped = s.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
        return stripped.length < 320;
    }

    async function scrapeWebsiteEmails(website, token, isRetryPass) {
        await waitForInternetConnection(90000);
        const home = canonicalWebsiteUrl(website);
        if (!home) return { value: "Can't Access Website", inaccessible: true, socials: {} };
        const initialSocials = extractSocialLinksFromHtml('', home);
        if (/^(?:https?:\/\/)?(?:www\.|m\.)?(?:facebook\.com|fb\.com|instagram\.com|instagr\.am|linkedin\.com|twitter\.com|x\.com|youtube\.com)\//i.test(home)) {
            return { value: 'No Email found', inaccessible: false, socials: initialSocials };
        }
        const domainKey = getNormalizedFranchiseDomain(home);
        if (!isRetryPass && websiteScrapeCache.has(home)) {
            const cached = await websiteScrapeCache.get(home);
            if (token !== emailRunToken) return { cancelled: true };
            return Object.assign({}, cached, { fromCache: true });
        }
        if (!isRetryPass && domainKey && franchiseDomainCache.has(domainKey)) {
            const domainCached = await franchiseDomainCache.get(domainKey);
            if (token !== emailRunToken) return { cancelled: true };
            if (domainCached && !domainCached.inaccessible) {
                return Object.assign({}, domainCached, { fromCache: true });
            }
        }
        const taskPromise = (async () => {
            try {
                const primaryTimeout = getAdaptiveEmailTimeoutMs(false, isRetryPass);
                const followupTimeout = getAdaptiveEmailTimeoutMs(true, isRetryPass);
                const first = await fetchEmailPage(home, primaryTimeout);
                if (token !== emailRunToken) return { cancelled: true };
                let emails = extractEmailCandidates(first.html, first.url || home);
                let socials = Object.assign({}, initialSocials, extractSocialLinksFromHtml(first.html, first.url || home));
                const hasAnySocial = Object.values(socials).some(Boolean);
                if (!emails.length || !hasAnySocial) {
                    const followups = emailLinksFromHtml(first.html, first.url || home);
                    if (followups.length && token === emailRunToken) {
                        const settled = await Promise.allSettled(
                            followups.map(link => fetchEmailPage(link, followupTimeout))
                        );
                        for (const item of settled) {
                            if (item.status === 'fulfilled' && item.value && item.value.html) {
                                emails = emails.concat(extractEmailCandidates(item.value.html, item.value.url || home));
                                const moreSocials = extractSocialLinksFromHtml(item.value.html, item.value.url || home);
                                Object.keys(socials).forEach(k => { if (!socials[k] && moreSocials[k]) socials[k] = moreSocials[k]; });
                            }
                        }
                    }
                }
                // Part 1 #3: If HTTP fetch found 0 emails and page looks like a JS SPA or Cloudflare shell, run Ghost WebView DOM fallback
                if (!emails.length && token === emailRunToken && looksLikeDynamicSpaOrCloudflare(first.html)) {
                    const renderedHtml = await fetchRenderedDomFallback(first.url || home);
                    if (renderedHtml && token === emailRunToken) {
                        emails = emails.concat(extractEmailCandidates(renderedHtml, first.url || home));
                        const domSocials = extractSocialLinksFromHtml(renderedHtml, first.url || home);
                        Object.keys(socials).forEach(k => { if (!socials[k] && domSocials[k]) socials[k] = domSocials[k]; });
                    }
                }
                let hostForSort = '';
                try { hostForSort = new URL(first.url || home).hostname; } catch (_) {}
                emails = emails.filter((email, index, all) => all.indexOf(email) === index);
                emails.sort((a, b) => scoreEmailCandidate(b, hostForSort) - scoreEmailCandidate(a, hostForSort));
                emails = emails.slice(0, 5);
                return { value: emails.length ? emails.join(', ') : 'No Email found', inaccessible: false, socials };
            } catch (e) {
                if (token !== emailRunToken) return { cancelled: true };
                // Part 1 #3: Also try Ghost WebView fallback on retry pass if direct HTTP fetch was blocked by Cloudflare 403/503
                if (isRetryPass) {
                    const renderedHtml = await fetchRenderedDomFallback(home);
                    if (renderedHtml && token === emailRunToken) {
                        const emails = extractEmailCandidates(renderedHtml, home).slice(0, 5);
                        const socials = Object.assign({}, initialSocials, extractSocialLinksFromHtml(renderedHtml, home));
                        if (emails.length || Object.values(socials).some(Boolean)) {
                            return { value: emails.length ? emails.join(', ') : 'No Email found', inaccessible: false, socials };
                        }
                    }
                }
                return { value: "Can't Access Website", inaccessible: true, socials: initialSocials };
            }
        })();
        if (websiteScrapeCache.size >= EMAIL_CACHE_MAX_ENTRIES) {
            const firstKey = websiteScrapeCache.keys().next().value;
            if (firstKey) websiteScrapeCache.delete(firstKey);
        }
        websiteScrapeCache.set(home, taskPromise);
        if (domainKey && !franchiseDomainCache.has(domainKey)) {
            if (franchiseDomainCache.size >= EMAIL_CACHE_MAX_ENTRIES) {
                const fk = franchiseDomainCache.keys().next().value;
                if (fk) franchiseDomainCache.delete(fk);
            }
            franchiseDomainCache.set(domainKey, taskPromise);
        }
        const finalRes = await taskPromise;
        if (websiteScrapeCache.has(home)) {
            websiteScrapeCache.set(home, Promise.resolve(finalRes));
        }
        if (domainKey && franchiseDomainCache.has(domainKey)) {
            if (finalRes && !finalRes.inaccessible) {
                franchiseDomainCache.set(domainKey, Promise.resolve(finalRes));
            } else {
                franchiseDomainCache.delete(domainKey);
            }
        }
        return finalRes;
    }

    function isPendingEmailScrapeValue(val) {
        const s = String(val || '').trim();
        return !s || /^(no email found|can't access website)$/i.test(s);
    }

    function rowMatchKeysForEnrichment(r) {
        if (!r || typeof r !== 'object') return [];
        const keys = [];
        const add = k => { const s = String(k || '').trim().toLowerCase(); if (s && !keys.includes(s)) keys.push(s); };
        if (r.place_id || r.placeId) add('pid:' + (r.place_id || r.placeId));
        if (r.scrappa_business_id || r.business_id) add('bid:' + (r.scrappa_business_id || r.business_id));
        if (r.cid) add('cid:' + r.cid);
        const rawWeb = String(r.website || r.websiteUrl || '').trim().toLowerCase().replace(/^https?:\/\/(www\.)?/, '').replace(/\/+$/, '');
        if (rawWeb) add('web:' + rawWeb);
        const name = String(r.company_name || r.name || r.title || '').trim();
        const addr = String(r.address || r.location || r.city || '').trim();
        if (name) add('na:' + name + '|' + addr);
        return keys;
    }

    function buildFastEnrichmentIndex(collections) {
        const index = new Map();
        const addRow = r => {
            if (!r || typeof r !== 'object') return;
            const keys = rowMatchKeysForEnrichment(r);
            for (let i = 0; i < keys.length; i++) {
                const k = keys[i];
                let bucket = index.get(k);
                if (!bucket) {
                    bucket = new Set();
                    index.set(k, bucket);
                }
                bucket.add(r);
            }
        };
        collections.forEach(arr => {
            if (Array.isArray(arr)) {
                for (let i = 0; i < arr.length; i++) addRow(arr[i]);
            }
        });
        return index;
    }

    function syncEnrichedRowToLiveCollections(sourceRow, allRows, fastIndex) {
        if (!sourceRow || typeof sourceRow !== 'object') return;
        const keys = rowMatchKeysForEnrichment(sourceRow);
        if (!keys.length) return;
        const applyToTarget = target => {
            if (!target || target === sourceRow) return;
            target.email_1 = sourceRow.email_1;
            ['facebook', 'instagram', 'linkedin', 'twitter', 'youtube'].forEach(sk => {
                if (sourceRow[sk]) target[sk] = sourceRow[sk];
            });
        };
        if (fastIndex instanceof Map) {
            const visited = new Set();
            for (let i = 0; i < keys.length; i++) {
                const bucket = fastIndex.get(keys[i]);
                if (!bucket) continue;
                bucket.forEach(target => {
                    if (!visited.has(target)) {
                        visited.add(target);
                        applyToTarget(target);
                    }
                });
            }
        } else {
            const matchSet = new Set(keys);
            const fallbackCopy = target => {
                if (!target || target === sourceRow) return;
                if (rowMatchKeysForEnrichment(target).some(k => matchSet.has(k))) applyToTarget(target);
            };
            if (Array.isArray(allRows)) allRows.forEach(fallbackCopy);
            if ($scope.local && Array.isArray($scope.local.collect)) $scope.local.collect.forEach(fallbackCopy);
            if (Array.isArray($scope.mobileVisibleLeads)) $scope.mobileVisibleLeads.forEach(fallbackCopy);
        }
        if ($scope.activeLeadDetail) {
            const detailKeys = rowMatchKeysForEnrichment($scope.activeLeadDetail);
            if (detailKeys.some(k => keys.includes(k))) {
                applyToTarget($scope.activeLeadDetail);
                if (typeof buildMobileLeadDetailVm === 'function') {
                    $scope.activeLeadDetailVm = buildMobileLeadDetailVm($scope.activeLeadDetail);
                }
            }
        }
    }

    let lastEmailScrapeStartClickAt = 0;
    $scope.scrapeEmails = async () => {
        const nowClick = Date.now();
        if ($scope.local.isScrapingEmail) {
            // Prevent accidental double-click within 900ms of starting from immediately cancelling the run!
            if (nowClick - lastEmailScrapeStartClickAt < 900) {
                return;
            }
            emailRunToken += 1;
            emailControllers.forEach(controller => { try { controller.abort(); } catch (e) {} });
            emailControllers.clear();
            $scope.local.isScrapingEmail = false;
            $scope.saveLocal();
            showTopStatusToast('⏹ Email & Social extraction stopped', 'warn');
            return;
        }
        if (!$scope.licenseActive || ($scope.license && ($scope.license.status === "inactive" || $scope.license.status === "expired" || $scope.license.status === "blocked"))) {
            showTopStatusToast('⚠ Active licence required for Email & Social extraction', 'warn');
            if (typeof window.showLicenseModal === 'function') window.showLicenseModal();
            return;
        }
        // Instant 0ms visual feedback on first click so the button updates immediately!
        lastEmailScrapeStartClickAt = nowClick;
        const token = ++emailRunToken;
        const initialEstimate = ($scope.emailFiltered && $scope.emailFiltered()) || ($scope.local && ($scope.local.resultStoreCount || ($scope.local.collect && $scope.local.collect.length))) || 0;
        $scope.local.isScrapingEmail = true;
        $scope.emailScrapeDone = 0;
        $scope.emailScrapeTotal = initialEstimate;
        showTopStatusToast('▶ Extracting Emails & Social links...', 'success');

        // Verify licence in background without blocking the button UI response
        if (window.PocketLeadsAccount && typeof window.PocketLeadsAccount.refresh === 'function') {
            window.PocketLeadsAccount.refresh({ force: true, maxAgeMs: 0 }).then(async liveAcc => {
                const latestLic = (await window.PocketLeadsAccount.read()).license;
                if (!latestLic || !latestLic.active || latestLic.requiresActivation || (liveAcc && ['inactive', 'expired'].includes(liveAcc.status))) {
                    emailRunToken += 1;
                    emailControllers.forEach(c => { try { c.abort(); } catch (_) {} });
                    emailControllers.clear();
                    $scope.$evalAsync(() => { $scope.local.isScrapingEmail = false; });
                    showTopStatusToast('⚠ This licence is inactive. Please contact admin.', 'warn');
                    if (typeof window.showLicenseModal === 'function') window.showLicenseModal();
                }
            }).catch(() => {});
        }

        await ensureWebsiteEmailHostPermission();
        if (token !== emailRunToken) return;
        websiteScrapeCache.clear();
        let canonicalRows = null;
        try {
            const allCanonical = await runtimeMessageAsync({ action: 'result_store_get_all' });
            if (allCanonical && Array.isArray(allCanonical.rows) && allCanonical.rows.length > 0) {
                canonicalRows = allCanonical.rows;
            }
        } catch (e) {}
        if (token !== emailRunToken) return;

        const rows = canonicalRows && canonicalRows.length >= (($scope.local.collect || []).length)
            ? canonicalRows
            : (Array.isArray($scope.local.collect) ? $scope.local.collect : []);

        // Normalize in yielded chunks if dataset is huge (e.g. 4,000-5,000 rows) so start click never blocks UI
        for (let i = 0; i < rows.length; i++) {
            const row = rows[i];
            if (row && typeof row === 'object') {
                ensureDashboardRowKey(row, i);
                if (!row.company_name || !row.website) normalizeDashboardRow(row);
            }
            if (i > 0 && i % 800 === 0) {
                await new Promise(r => setTimeout(r, 0));
                if (token !== emailRunToken) return;
            }
        }

        franchiseDomainCache.clear();
        let targets = rows.filter(row => row && isScrapableBusinessWebsite(row.website) && !String(row.email_1 || '').trim());
        if (!targets.length) {
            targets = rows.filter(row => row && isScrapableBusinessWebsite(row.website) && (isPendingEmailScrapeValue(row.email_1) || !(row.facebook || row.instagram || row.linkedin || row.twitter || row.youtube)));
        }
        if (!targets.length) {
            $scope.$evalAsync(() => {
                $scope.local.isScrapingEmail = false;
                $scope.emailScrapeDone = 0;
                $scope.emailScrapeTotal = 0;
            });
            showTopStatusToast('⚠ No leads with websites found to extract', 'warn');
            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                $scope.snackbar.show('No leads with websites found to extract.');
            }
            return;
        }

        // Build O(1) enrichment lookup index once across all collections (eliminates O(N^2) lag on 4000-5000 leads)
        const fastEnrichmentIndex = buildFastEnrichmentIndex([
            rows,
            $scope.local && $scope.local.collect,
            $scope.mobileVisibleLeads
        ]);

        $scope.$evalAsync(() => {
            $scope.local.isScrapingEmail = true;
            $scope.emailScrapeDone = 0;
            $scope.emailScrapeTotal = targets.length;
        });
        let cursor = 0;
        let completed = 0;
        const dirtyRowsForIdb = new Map();
        let isFlushingIdb = false;
        let uiRefreshTimer = null;

        const scheduleEmailUiRefresh = () => {
            if (uiRefreshTimer) return;
            uiRefreshTimer = setTimeout(() => {
                uiRefreshTimer = null;
                $scope.$evalAsync(() => {
                    try {
                        if (dataGrid && typeof dataGrid.repaint === 'function') {
                            dataGrid.repaint();
                        }
                    } catch (e) {}
                });
            }, 650);
        };

        const flushDirtyRowsToIdb = async (forceAll) => {
            if (isFlushingIdb || !dirtyRowsForIdb.size) return;
            isFlushingIdb = true;
            try {
                while (dirtyRowsForIdb.size > 0 && (forceAll || dirtyRowsForIdb.size >= 40)) {
                    const entries = Array.from(dirtyRowsForIdb.entries()).slice(0, 120);
                    entries.forEach(([k]) => dirtyRowsForIdb.delete(k));
                    const batch = entries.map(([, v]) => v);
                    await runtimeMessageAsync({ action: 'result_store_upsert', rows: batch });
                    if (!forceAll) break;
                }
            } catch (e) {
            } finally {
                isFlushingIdb = false;
            }
        };

        const blacklist = Array.isArray($scope.local.blackList) ? $scope.local.blackList.map(x => String(x).trim().toLowerCase()) : [];

        const applyResult = (row, result) => {
            if (token !== emailRunToken || !result || result.cancelled || !row) return;
            const values = String(result.value || '').split(/[,;\n]+/).map(x => x.trim()).filter(Boolean);
            const processed = values.map(value => blacklist.includes(value.toLowerCase()) ? 'Blacklisted Email' : value);
            const existingValid = !isPendingEmailScrapeValue(row.email_1) ? row.email_1 : '';
            const nextEmail = processed.join(', ') || 'No Email found';
            const finalEmail = (existingValid && isPendingEmailScrapeValue(nextEmail)) ? existingValid : nextEmail;
            const hadEmailBefore = !isPendingEmailScrapeValue(row.email_1) && String(row.email_1 || '').includes('@');
            row.email_1 = finalEmail;
            const hasEmailAfter = !isPendingEmailScrapeValue(row.email_1) && String(row.email_1 || '').includes('@');
            if (!hadEmailBefore && hasEmailAfter && $scope.metricCounts) {
                $scope.metricCounts.email_1 = ($scope.metricCounts.email_1 || 0) + 1;
            }
            if (result.socials && typeof result.socials === 'object') {
                ['facebook', 'instagram', 'linkedin', 'twitter', 'youtube'].forEach(k => {
                    if (result.socials[k]) row[k] = result.socials[k];
                });
            }
            syncEnrichedRowToLiveCollections(row, rows, fastEnrichmentIndex);
            const rowKeyStr = String(ensureDashboardRowKey(row, 0) || row.place_id || row.cid || row.company_name);
            dirtyRowsForIdb.set(rowKeyStr, row);
            scheduleEmailUiRefresh();
        };

        try {
            if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.setExtractionActive === 'function') {
                window.AndroidChromeBridge.setExtractionActive(true, 'Scanning ' + targets.length + ' websites for Emails & Socials...');
            }
        } catch (_) {}
        const retryTargets = [];
        const worker = async (workerIdx) => {
            while (token === emailRunToken) {
                // Part 1 #8: Battery-Saver Eco Mode throttles extra workers when battery < 20% or screen is off
                if (workerIdx >= 3 && isEcoModeActive()) {
                    await new Promise(r => setTimeout(r, 450));
                }
                const index = cursor++;
                if (index >= targets.length) return;
                const targetRow = targets[index];
                try {
                    const result = await scrapeWebsiteEmails(targetRow.website, token, false);
                    if (token !== emailRunToken) return;
                    if (result && result.inaccessible) {
                        retryTargets.push(targetRow);
                    }
                    applyResult(targetRow, result);
                } catch (e) {
                    if (token !== emailRunToken) return;
                    retryTargets.push(targetRow);
                    applyResult(targetRow, { value: "Can't Access Website", socials: {} });
                }
                completed += 1;
                $scope.emailScrapeDone = completed;
                // Do not re-post notification every 25 websites so user can dismiss notification freely on Samsung/Android
                if (dirtyRowsForIdb.size >= 50 && !isFlushingIdb) {
                    void flushDirtyRowsToIdb(false);
                }
                // Yield to main event loop (longer breather in Eco Mode to prevent battery/heat buildup)
                const breatherMs = isEcoModeActive() ? 95 : 15;
                await new Promise(r => setTimeout(r, breatherMs));
            }
        };
        try {
            const initialWorkers = Math.min(EMAIL_WORKERS, targets.length);
            await Promise.all(Array.from({ length: initialWorkers }, (_, i) => worker(i)));
            // Part 1 #7: Pass 2 Smart Auto-Retry Queue for slow/2G websites that timed out in Pass 1
            if (token === emailRunToken && retryTargets.length > 0 && retryTargets.length <= 2500) {
                let retryCursor = 0;
                const retryWorker = async () => {
                    while (token === emailRunToken) {
                        const rIdx = retryCursor++;
                        if (rIdx >= retryTargets.length) return;
                        const rRow = retryTargets[rIdx];
                        try {
                            const retryRes = await scrapeWebsiteEmails(rRow.website, token, true);
                            if (token !== emailRunToken) return;
                            if (retryRes && !retryRes.inaccessible) {
                                applyResult(rRow, retryRes);
                            }
                        } catch (_) {}
                        await new Promise(r => setTimeout(r, 30));
                    }
                };
                await Promise.all(Array.from({ length: Math.min(3, retryTargets.length) }, retryWorker));
            }
        } catch (error) {
            try { console.warn('Email scraping workers stopped safely', error && error.message ? error.message : error); } catch (e) {}
        } finally {
            try {
                if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.setExtractionActive === 'function' && !PocketLeadsRunState.isRunning($scope.local)) {
                    window.AndroidChromeBridge.setExtractionActive(false, '');
                }
            } catch (_) {}
            if (uiRefreshTimer) { clearTimeout(uiRefreshTimer); uiRefreshTimer = null; }
            await flushDirtyRowsToIdb(true);
            websiteScrapeCache.clear();
            franchiseDomainCache.clear();
            emailControllers.clear();
            if (token === emailRunToken) {
                $scope.$evalAsync(() => {
                    $scope.local.isScrapingEmail = false;
                    $scope.emailScrapeDone = 0;
                    $scope.emailScrapeTotal = 0;
                    $scope.local.collect = rows.slice(0, 5000);
                    $scope.local.collectIsPreview = rows.length > $scope.local.collect.length;
                    $scope.local.resultStoreCount = Math.max($scope.local.resultStoreCount || 0, rows.length);
                    refreshDashboardMetricCounts(rows);
                    refreshMobileLeadsView($scope.local.collect);
                    try { $scope.recordScrapingHistory('email_enriched', false); } catch (_) {}
                    triggerCompletionSoundVibrateAndNotification('Email & Social Scrape Done');
                    $scope.saveLocal();
                    try {
                        updateDataTable($scope.local);
                        if (dataGrid && typeof dataGrid.refresh === 'function') dataGrid.refresh();
                    } catch (e) {}
                });
            }
        }
    };

    $scope.emailFiltered = () => {
        const rows = Array.isArray($scope.local && $scope.local.collect) ? $scope.local.collect : [];
        const fresh = rows.filter(x => x && x.website && !String(x.email_1 || '').trim()).length;
        if (fresh > 0) return Math.max(fresh, Number($scope.metricCounts && $scope.metricCounts.website) || fresh);
        const retryable = rows.filter(x => x && x.website && isPendingEmailScrapeValue(x.email_1)).length;
        return retryable || Number($scope.metricCounts && $scope.metricCounts.website) || 0;
    };

    function exportHeaderFor(label) {
        let header;
        try { header = (typeof FoxCommon !== 'undefined' && FoxCommon.getKeyFromMap) ? FoxCommon.getKeyFromMap(label) : undefined; } catch (e) { header = undefined; }
        if (!header || header === label) header = FoxCommon.downloadAs.keyToColumnHeader(label);
        return header;
    }

    function selectedExportLabels() {
        const modal = $scope.exportModal || {};
        const raw = (modal.fields || []).filter(field => modal.selected && modal.selected[field]);
        const head = [];
        if (raw.includes('keyword')) head.push('keyword');
        if (raw.includes('location')) head.push('location');
        const rest = raw.filter(f => f !== 'keyword' && f !== 'location');
        return [...head, ...rest];
    }

    function exportValueFor(row, label) {
        if (!row || typeof row !== 'object') return '';
        if (label === 'lead_quality_score') {
            return $scope.getLeadQualityInfo(row).exportText;
        }
        if (label === 'keyword') {
            let kw = String(row.keyword || row.searchKeyword || row.query || '').trim();
            if (kw.includes('~in~')) kw = kw.split('~in~')[0].trim();
            return kw;
        }
        if (label === 'location') {
            let loc = String(row.location || row.searchLocation || '').trim();
            if (!loc && row.keyword && String(row.keyword).includes('~in~')) {
                loc = String(row.keyword).split('~in~')[1].trim();
            }
            if (!loc) loc = String(row.city || row.district || row.pincode || '').trim();
            return loc;
        }
        if (label === 'phone_number') return rowPhoneValue(row);
        if (label === 'map_link') return resolveLeadProfileMapsUrl(row) || PocketLeadsExport.value(row[label]);
        if (label === 'photo_url') {
            const samples = $scope.getLeadPhotosSample(row);
            const perm = samples.find(s => s && /\/p\/AF1Qip/i.test(String(s.photo_url || '')));
            if (perm && perm.photo_url) return perm.photo_url;
            if (samples.length && samples[0].photo_url) return samples[0].photo_url;
            return upgradeDashboardPhotoUrl(row.photo_url || row.photo_url_large || '');
        }
        if (label === 'photo_url_large') {
            const samples = $scope.getLeadPhotosSample(row);
            const perm = samples.find(s => s && /\/p\/AF1Qip/i.test(String(s.photo_url_large || s.photo_url || '')));
            if (perm && (perm.photo_url_large || perm.photo_url)) return perm.photo_url_large || perm.photo_url;
            if (samples.length && samples[0].photo_url_large) return samples[0].photo_url_large;
            return upgradeDashboardPhotoUrl(row.photo_url_large || row.photo_url || '');
        }
        if (label === 'photo_urls') {
            const all = $scope.getLeadAllPhotoUrls(row);
            if (all.length) return all.join(', ');
            const fallbackSingle = upgradeDashboardPhotoUrl(row.photo_url || row.photo_url_large || '', row.photo_url || '');
            return fallbackSingle || '';
        }
        const value = sanitizeScrapedFieldText(row[label]);
        const strOut = String(PocketLeadsExport.value(value) ?? '');
        // v31 Security: Prevent CSV/Excel Formula Injection (=CMD, @SUM, +cmd, -cmd)
        if (/^[=\+@\-]/.test(strOut) && !/^\+?\d[\d\s\-().]{5,}$/.test(strOut) && !/^[\-+]?\d+(\.\d+)?%?$/.test(strOut)) {
            return "'" + strOut;
        }
        return strOut;
    }


    function dedupeCanonicalRows(rows) {
        const input = Array.isArray(rows) ? rows : [];
        const seen = new Set();
        const out = [];
        input.forEach((row, index) => {
            if (!row || typeof row !== 'object') return;
            const key = String((row.place_id || row.placeId || row.cid || row.map_link || row.phone || row.company_name || ('row_' + index)));
            if (seen.has(key)) return;
            seen.add(key);
            out.push(row);
        });
        return out;
    }

    function runtimeMessageAsync(message) {
        return new Promise(resolve => {
            try {
                chrome.runtime.sendMessage(message, response => {
                    const last = chrome.runtime && chrome.runtime.lastError ? chrome.runtime.lastError : null;
                    if (last || !response || !response.ok) return resolve(null);
                    resolve(response);
                });
            } catch (e) { resolve(null); }
        });
    }

    const exportService=PocketLeadsExport.create(runtimeMessageAsync);
    async function requestCanonicalRowsForExport(){return exportService.rows();}
    async function getCanonicalStoreCount(){return exportService.count();}
    async function getCanonicalStorePage(offset,limit){return exportService.page(offset,limit);}

    async function buildLargeExportBlob(mode, labels) {
        const total = await getCanonicalStoreCount();
        if(total!==$scope.exportModal.rowCount)throw new Error('Results changed. Reopen Download to refresh the export.');
        if (!total) throw new Error('No data available for export.');
        const pageSize = total > 30000 ? 750 : 1500;
        const parts = [];
        const escHtml = value => String(value === null || typeof value === 'undefined' ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        if (mode === 'excel') {
            parts.push('<html><head><meta charset="utf-8"></head><body><table border="1"><thead><tr>');
            labels.forEach(label => {
                let header;
                try { header = (typeof FoxCommon !== 'undefined' && FoxCommon.getKeyFromMap) ? FoxCommon.getKeyFromMap(label) : undefined; } catch (e) { header = undefined; }
                if (!header || header === label) header = FoxCommon.downloadAs.keyToColumnHeader(label);
                parts.push('<th>' + escHtml(header) + '</th>');
            });
            parts.push('</tr></thead><tbody>');
        } else {
            parts.push('\uFEFF' + labels.map(label => {
                let header;
                try { header = (typeof FoxCommon !== 'undefined' && FoxCommon.getKeyFromMap) ? FoxCommon.getKeyFromMap(label) : undefined; } catch (e) { header = undefined; }
                if (!header || header === label) header = FoxCommon.downloadAs.keyToColumnHeader(label);
                return '"' + String(header).replace(/"/g, '""') + '"';
            }).join(',') + '\r\n');
        }
        const uniqueKey = $scope.exportModal && $scope.exportModal.uniqueBy ? String($scope.exportModal.uniqueBy).trim() : '';
        const seenUnique = new Set();
        const filterPageRow = row => {
            if (!uniqueKey) return true;
            const rawVal = String(exportValueFor(row, uniqueKey) || '').trim().toLowerCase();
            if (!rawVal || rawVal === '—' || rawVal === 'no email found' || rawVal === "can't access website") return false;
            const normVal = uniqueKey === 'phone_number' ? rawVal.replace(/\D/g, '').replace(/^0+/, '') : rawVal;
            if (!normVal || seenUnique.has(normVal)) return false;
            seenUnique.add(normVal);
            return true;
        };
        for (let offset = 0; offset < total; offset += pageSize) {
            const page = await getCanonicalStorePage(offset, pageSize);
            if(page.length!==Math.min(pageSize,total-offset))throw new Error('Results changed during export. Retry after scraping stops.');
            const filteredPage = uniqueKey ? page.filter(filterPageRow) : page;
            if (mode === 'excel') {
                let chunk = '';
                filteredPage.forEach(row => {
                    chunk += '<tr>';
                    labels.forEach(label => {
                        const value = exportValueFor(row, label);
                        chunk += label === 'map_link' && value
                            ? '<td><a href="' + escHtml(value) + '">' + escHtml(value) + '</a></td>'
                            : '<td>' + escHtml(value) + '</td>';
                    });
                    chunk += '</tr>';
                });
                parts.push(chunk);
            } else {
                let chunk = '';
                filteredPage.forEach(row => {
                    chunk += labels.map(label => {
                        let value = exportValueFor(row, label);
                        if (label === 'map_link' && value) value = resolveLeadProfileMapsUrl(row) || value;
                        return '"' + String(value).replace(/"/g, '""') + '"';
                    }).join(',') + '\r\n';
                });
                parts.push(chunk);
            }
            if (page.length < pageSize) break;
            await new Promise(resolve => setTimeout(resolve, 0));
        }
        if(await getCanonicalStoreCount()!==total)throw new Error('Results changed during export. Retry after scraping stops.');
        if (mode === 'excel') {
            parts.push('</tbody></table></body></html>');
            return new Blob(parts, { type: 'application/vnd.ms-excel;charset=utf-8' });
        }
        return new Blob(parts, { type: 'text/csv;charset=utf-8' });
    }

    const WA_VERIFIED_STORAGE_KEY = 'pl_wa_verified_cache_v1';
    let waVerifiedPhoneMemoryMap = null;

    function loadWaVerifiedPhoneMap() {
        if (waVerifiedPhoneMemoryMap) return waVerifiedPhoneMemoryMap;
        waVerifiedPhoneMemoryMap = new Map();
        try {
            const raw = localStorage.getItem(WA_VERIFIED_STORAGE_KEY);
            if (raw) {
                const obj = JSON.parse(raw);
                if (obj && typeof obj === 'object') {
                    Object.keys(obj).forEach(k => {
                        if (obj[k]) waVerifiedPhoneMemoryMap.set(k, obj[k]);
                    });
                }
            }
        } catch (_) {}
        return waVerifiedPhoneMemoryMap;
    }

    function saveWaVerifiedPhoneMap() {
        try {
            const map = loadWaVerifiedPhoneMap();
            if (map.size > 60000) {
                const keys = Array.from(map.keys());
                for (let i = 0; i < keys.length - 50000; i++) map.delete(keys[i]);
            }
            const out = {};
            map.forEach((v, k) => { out[k] = v; });
            localStorage.setItem(WA_VERIFIED_STORAGE_KEY, JSON.stringify(out));
        } catch (_) {}
    }

    function normalizeCanonicalWaStatusLabel(st) {
        const s = String(st || '').trim().toLowerCase();
        if (/^(valid|available|yes|true|verified|active|registered)$/.test(s)) return 'Valid';
        if (/^(invalid|not available|not_available|no|false|unregistered|not found|not_found)$/.test(s)) return 'Invalid';
        if (/^(unknown|no result|failed|pending \/ timeout)$/.test(s)) return 'Unknown';
        return String(st || '').trim();
    }

    function recordPhoneInWaVerifiedCache(rawPhone, statusLabel) {
        const cleanSt = normalizeCanonicalWaStatusLabel(statusLabel);
        if (!cleanSt || !/^(Valid|Invalid|Unknown)$/.test(cleanSt)) return;
        const digits = String(rawPhone || '').replace(/\D+/g, '').replace(/^0+/, '');
        if (digits.length < 7) return;
        const map = loadWaVerifiedPhoneMap();
        map.set(digits, cleanSt);
        if (digits.length > 10) map.set(digits.slice(-10), cleanSt);
    }

    function applyWaVerifiedCacheToRows(rows) {
        if (!Array.isArray(rows) || !rows.length) return rows;
        const map = loadWaVerifiedPhoneMap();
        for (let i = 0; i < rows.length; i++) {
            const r = rows[i];
            if (!r || typeof r !== 'object') continue;
            if (r.whatsapp_status) {
                const normExisting = normalizeCanonicalWaStatusLabel(r.whatsapp_status);
                if (/^(Valid|Invalid|Unknown)$/.test(normExisting)) {
                    r.whatsapp_status = normExisting;
                    recordPhoneInWaVerifiedCache(rowPhoneValue(r), normExisting);
                    continue;
                }
            }
            if (map.size > 0) {
                const digits = String(rowPhoneValue(r) || '').replace(/\D+/g, '').replace(/^0+/, '');
                if (digits.length >= 7) {
                    const hit = map.get(digits) || (digits.length > 10 ? map.get(digits.slice(-10)) : '');
                    if (hit) {
                        r.whatsapp_status = hit;
                    }
                }
            }
        }
        return rows;
    }

    async function getCompleteRowsForExport() {
        const storeRows = await exportService.rows().catch(() => []);
        const localRows = Array.isArray($scope.local && $scope.local.collect) ? $scope.local.collect : [];
        // Merge in-memory whatsapp_status / email_1 enrichments into storeRows so exports NEVER lose verified statuses
        const baseRows = (Array.isArray(storeRows) && storeRows.length >= localRows.length) ? storeRows : localRows;
        if (localRows.length > 0 && baseRows !== localRows) {
            const localByPhone = new Map();
            localRows.forEach(lr => {
                if (!lr) return;
                const p = String(rowPhoneValue(lr) || '').replace(/\D+/g, '').replace(/^0+/, '');
                if (p && lr.whatsapp_status) localByPhone.set(p, normalizeCanonicalWaStatusLabel(lr.whatsapp_status));
            });
            baseRows.forEach(br => {
                if (!br) return;
                const p = String(rowPhoneValue(br) || '').replace(/\D+/g, '').replace(/^0+/, '');
                if (p && localByPhone.has(p) && (!br.whatsapp_status || /checking|pending|queued/i.test(String(br.whatsapp_status)))) {
                    br.whatsapp_status = localByPhone.get(p);
                }
            });
        }
        return applyWaVerifiedCacheToRows(baseRows);
    }

    let rememberedExportFields = {};
    chrome.storage.local.get('pocketleadsExportFields',v=>{rememberedExportFields=v.pocketleadsExportFields||{};});
    const EXPORT_FIELD_LABELS = {
        keyword: 'Search Keyword',
        location: 'Search Location',
        company_name: 'Business Name',
        website: 'Website URL',
        phone_number: 'Phone Number',
        whatsapp_status: 'WhatsApp Status',
        email_1: 'Email Address',
        facebook: 'Facebook',
        instagram: 'Instagram',
        linkedin: 'LinkedIn',
        twitter: 'Twitter / X',
        youtube: 'YouTube',
        address: 'Full Address',
        city: 'City',
        state: 'State',
        pincode: 'Pincode / ZIP',
        total_reviews: 'Total Reviews',
        review: 'Star Rating',
        category: 'Category',
        categories: 'All Categories',
        latitude: 'Latitude',
        longitude: 'Longitude',
        place_id: 'Place ID',
        cid: 'Google CID',
        map_link: 'Google Maps Link',
        status: 'Business Status',
        source: 'Data Source',
        lead_quality_score: 'Lead Quality Score',
        opening_hours: 'Opening Hours',
        photo_url: 'Photo URL',
        photo_url_large: 'Photo URL (Large)',
        photo_urls: 'All Photo URLs',
        scraped_at: 'Scraped Time'
    };

    $scope.getExportFieldLabel = function(field) {
        const key = String(field || '').trim();
        if (EXPORT_FIELD_LABELS[key]) return EXPORT_FIELD_LABELS[key];
        return key.replace(/_/g, ' ').replace(/\b\w/g, m => m.toUpperCase());
    };

    $scope.download = () => {
        if (!$scope.licenseActive) {
            try { showTopStatusToast('⚠ Please activate your licence first', 'warn'); } catch (_) {}
            $scope.snackbar.show("Please activate your licence first");
            return;
        }
        const localRows = dedupeCanonicalRows($scope.local && $scope.local.collect);
        const sortExportColumnsPriority = (cols) => {
            const priority = ['keyword', 'location', 'company_name', 'phone_number', 'whatsapp_status', 'review', 'total_reviews', 'category', 'address', 'city', 'state', 'pincode', 'website', 'email_1', 'map_link', 'photo_url', 'photo_url_large', 'photo_urls', 'status', 'facebook', 'instagram', 'linkedin', 'twitter', 'youtube', 'place_id', 'cid', 'latitude', 'longitude', 'source', 'scraped_at'];
            const rank = k => { const idx = priority.indexOf(k); return idx >= 0 ? idx : 999; };
            return [...cols].sort((a, b) => rank(a) - rank(b));
        };
        const ensureMandatoryCols = cols => {
            const set = new Set(['keyword', 'location', ...cols, 'photo_url', 'photo_url_large', 'photo_urls']);
            return sortExportColumnsPriority(Array.from(set));
        };
        const initialLabels = ensureMandatoryCols(PocketLeadsExport.fields(localRows, baseColumnList));
        const initialSelected = {};
        initialLabels.forEach(label => {
            if (label === 'keyword' || label === 'location' || label === 'photo_url' || label === 'photo_url_large' || label === 'photo_urls') {
                initialSelected[label] = true;
            } else {
                initialSelected[label] = rememberedExportFields[label] !== false;
            }
        });
        $scope.exportModal = { show: true, step:'fields', activePreset: 'all', uniqueBy: '', loading: !localRows.length, error: false, fields: initialLabels, selected: initialSelected, format: 'excel', rows: localRows, largeMode: false, rowCount: localRows.length };

        getCanonicalStoreCount().then(async total => {
            if (total > 10000) {
                const union=new Set(PocketLeadsExport.fields(localRows,baseColumnList));
                for(let offset=0;offset<total;offset+=2000){
                    const page=await getCanonicalStorePage(offset,2000);
                    PocketLeadsExport.fields(page,baseColumnList).forEach(label=>union.add(label));
                }
                const labels = ensureMandatoryCols(Array.from(union));
                const selected = {};
                labels.forEach(label => {
                    if (label === 'keyword' || label === 'location' || label === 'photo_url' || label === 'photo_url_large' || label === 'photo_urls') selected[label] = true;
                    else selected[label] = rememberedExportFields[label] !== false;
                });
                $scope.safeApply(() => {
                    $scope.exportModal.fields = labels;
                    $scope.exportModal.selected = selected;
                    $scope.exportModal.rows = [];
                    $scope.exportModal.rowCount = total;
                    $scope.exportModal.largeMode = true;
                    $scope.exportModal.loading = false;
                });
                return;
            }
            let storeRows = [];
            try { storeRows = await getCompleteRowsForExport(); } catch (_) {}
            const arrData = (Array.isArray(storeRows) && storeRows.length >= localRows.length) ? dedupeCanonicalRows(storeRows) : localRows;
            if (!arrData.length) {
                $scope.safeApply(() => {
                    $scope.exportModal.loading = false;
                    $scope.closeExportModal();
                    try { showTopStatusToast('⚠ No leads available to export yet', 'warn'); } catch (_) {}
                    $scope.snackbar.show('No data available for export.');
                });
                return;
            }
            const labels = ensureMandatoryCols(PocketLeadsExport.fields(arrData, baseColumnList));
            const selected = {};
            labels.forEach(label => {
                if (label === 'keyword' || label === 'location' || label === 'photo_url' || label === 'photo_url_large' || label === 'photo_urls') selected[label] = true;
                else selected[label] = rememberedExportFields[label] !== false;
            });
            $scope.safeApply(() => { $scope.exportModal.fields = labels; $scope.exportModal.selected = selected; $scope.exportModal.rows = arrData; $scope.exportModal.rowCount = arrData.length; $scope.exportModal.loading = false; $scope.exportModal.error = false; });
        }).catch(error => {
            $scope.safeApply(() => {
                if (localRows.length > 0) {
                    $scope.exportModal.rows = localRows;
                    $scope.exportModal.rowCount = localRows.length;
                    $scope.exportModal.loading = false;
                    $scope.exportModal.error = false;
                } else {
                    $scope.exportModal.loading = false;
                    $scope.exportModal.error = true;
                    try { showTopStatusToast('⚠ ' + (error && error.message ? error.message : 'Unable to prepare export.'), 'warn'); } catch (_) {}
                }
            });
        });
    };

    function compactMobileCrmRow(row, index) {
        row = row && typeof row === 'object' ? row : {};
        const pick = (keys, fallback) => {
            for (let i = 0; i < keys.length; i++) {
                const value = row[keys[i]];
                if (value !== null && typeof value !== 'undefined' && String(value).trim() !== '') return value;
            }
            return typeof fallback === 'undefined' ? '' : fallback;
        };
        const resolvedThumb = (typeof $scope.getMobileLeadImage === 'function' && $scope.getMobileLeadImage(row)) || pick(['photo_url', 'photo_url_large', 'image', 'thumbnail']);
        const resolvedLarge = (typeof $scope.getMobileLeadFallbackImage === 'function' && $scope.getMobileLeadFallbackImage(row)) || pick(['photo_url_large', 'photo_url']) || resolvedThumb;
        const resolvedAllPhotos = (typeof $scope.getLeadAllPhotoUrls === 'function' && ($scope.getLeadAllPhotoUrls(row) || []).join(', ')) || pick(['photo_urls']);
        return {
            id: pick(['id', 'place_id', 'cid'], 'lead_' + (index + 1)),
            company_name: pick(['company_name', 'title', 'name', 'business_name']),
            photo_url: resolvedThumb,
            photo_url_large: resolvedLarge,
            photo_urls: resolvedAllPhotos,
            email_1: pick(['email_1', 'email']),
            facebook: pick(['facebook']),
            instagram: pick(['instagram']),
            linkedin: pick(['linkedin']),
            twitter: pick(['twitter']),
            youtube: pick(['youtube']),
            opening_hours: pick(['opening_hours']),
            phone_number: rowPhoneValue(row),
            whatsapp_status: pick(['whatsapp_status', 'wa_status']),
            review: pick(['review', 'rating', 'stars'], 0),
            total_reviews: pick(['total_reviews', 'reviews', 'review_count', 'reviewCount'], 0),
            category: pick(['category', 'type', 'main_category']),
            address: pick(['address', 'full_address', 'complete_address']),
            city: pick(['city']),
            state: pick(['state']),
            pincode: pick(['pincode', 'postal_code', 'zip']),
            website: pick(['website', 'url']),
            map_link: pick(['map_link', 'google_maps_url', 'maps_url', 'googleMapsUrl']),
            place_id: pick(['place_id', 'placeId']),
            status: pick(['status', 'crm_status'], 'new'),
            starred: Boolean(row.starred),
            remark: pick(['remark', 'remarks', 'note', 'notes']),
            dirty: Boolean(row.dirty),
            changed_fields: Array.isArray(row.changed_fields) ? row.changed_fields : [],
            source: pick(['source']),
            scraped_at: pick(['scraped_at', 'created_at']),
            updated_at: pick(['updated_at'])
        };
    }

    function safeMobileCrmJson(payload) {
        return JSON.stringify(payload)
            .replace(/</g, '\\u003c')
            .replace(/>/g, '\\u003e')
            .replace(/&/g, '\\u0026')
            .replace(/\u2028/g, '\\u2028')
            .replace(/\u2029/g, '\\u2029');
    }

    async function allowExportRows(count) {
        try {
            const state = await PocketLeadsAccount.read();
            const a = state && state.pocketleadsAccount;
            const licActive = !!($scope.licenseActive || (state && state.license && state.license.active));
            if (!licActive) {
                showTopStatusToast('Please activate your licence first', 'warn');
                return false;
            }
            if (a && a.entitlements && a.entitlements.export === false) {
                showTopStatusToast('Export is disabled for this licence plan', 'warn');
                return false;
            }
            const limit = a && a.limits && a.limits.exportLimit;
            if (limit && limit !== 'unlimited' && Number.isFinite(limit) && count > limit) {
                showTopStatusToast('Export exceeds plan limit (' + limit + ' rows)', 'warn');
                return false;
            }
            return true;
        } catch (_) {
            return !!$scope.licenseActive;
        }
    }
    $scope.mobileCrmExporting = false;
    $scope.openInAppCrmView = () => { $scope._openCrmInAppMode = true; $scope.exportMobileCrmHtml(); };
    $scope.exportMobileCrmHtml = () => {
        if (!$scope.licenseActive) {
            $scope.snackbar.show('Please activate your licence first');
            return;
        }
        if ($scope.mobileCrmExporting) return;
        $scope.mobileCrmExporting = true;
        const templateUrl = chrome.runtime.getURL('templates/PocketLeads_Mobile_CRM.html');
        getCompleteRowsForExport().then(async sourceRows => {
            if(!await allowExportRows(sourceRows.length))throw new Error("Export unavailable for this account or row count.");
            if (!sourceRows.length) throw new Error('No data available for Mobile CRM export.');
            return fetch(templateUrl, { cache: 'no-store' })
                .then(response => {
                    if (!response.ok) throw new Error('CRM template could not be loaded.');
                    return response.text();
                })
                .then(template => ({ template, sourceRows }));
        })
            .then(({ template, sourceRows }) => {
                const payload = {
                    workspaceId: 'pocketleads_' + Date.now().toString(36),
                    generatedAt: new Date().toISOString(),
                    source: 'PocketLeads extension export',
                    rows: sourceRows.map(compactMobileCrmRow)
                };
                const dataPattern = /(<script id="pocketleads-embedded-data" type="application\/json">)[\s\S]*?(<\/script>)/;
                if (!dataPattern.test(template)) throw new Error('CRM template data marker is missing.');
                const safePayload = safeMobileCrmJson(payload);
                const output = template.replace(dataPattern, (match, openTag, closeTag) => openTag + '\n' + safePayload + '\n  ' + closeTag);
                const stamp = ($scope.exportModal && $scope.exportModal.customStamp) ? $scope.exportModal.customStamp : new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
                const crmFilename = 'PocketLeads_Mobile_CRM_' + stamp + '.html';
                if ($scope._openCrmInAppMode && typeof window !== 'undefined' && typeof window.__openMobileCrmInApp === 'function') {
                    $scope._openCrmInAppMode = false;
                    window.__openMobileCrmInApp(output, crmFilename);
                    $scope.snackbar.show('Mobile CRM view opened.');
                } else {
                    $scope._openCrmInAppMode = false;
                    saveBlobDownload(new Blob([output], { type: 'text/html;charset=utf-8' }), crmFilename);
                    $scope.snackbar.show('Mobile CRM HTML downloaded.');
                }
            })
            .catch(error => {
                console.error('Mobile CRM export failed:', error);
                $scope.snackbar.show(error && error.message ? error.message : 'Mobile CRM export failed.');
            })
            .finally(() => {
                $scope.safeApply(() => { $scope.mobileCrmExporting = false; });
            });
    };


    // =========================================================================
    // Offline India Pincode & Area Selector ("+ Select areas" -> "Select locations")
    // =========================================================================
    let cachedPincodeDataset = null;
    let pincodeDatasetPromise = null;

    $scope.pincodeModal = {
        show: false,
        loading: false,
        totalCsvRows: 165627,
        totalUniquePincodes: 19586,
        states: [],
        districts: [],
        divisions: [],
        selectedState: 'WEST BENGAL',
        selectedDistrict: '',
        selectedDivision: '',
        searchQuery: '',
        filteredItems: [],
        pageItems: [],
        page: 1,
        pageSize: 100,
        totalPages: 1,
        pageStart: 0,
        pageEnd: 0,
        selectedMap: {},
        selectedCount: 0
    };

    function loadOfflinePincodeDataset() {
        if (cachedPincodeDataset) return Promise.resolve(cachedPincodeDataset);
        if (pincodeDatasetPromise) return pincodeDatasetPromise;
        const url = (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getURL === 'function')
            ? chrome.runtime.getURL('assets/data/india-pincodes.json')
            : '/assets/data/india-pincodes.json';
        pincodeDatasetPromise = fetch(url, { cache: 'force-cache' })
            .then(r => {
                if (!r.ok) throw new Error('Failed to load pincode dataset');
                return r.json();
            })
            .then(data => {
                cachedPincodeDataset = data;
                return data;
            })
            .catch(err => {
                pincodeDatasetPromise = null;
                console.warn('[PocketLeads] Pincode dataset load error:', err);
                return null;
            });
        return pincodeDatasetPromise;
    }

    function updateSelectedPincodeCount() {
        const map = $scope.pincodeModal.selectedMap || {};
        let c = 0;
        for (const k in map) {
            if (Object.prototype.hasOwnProperty.call(map, k) && map[k]) c++;
        }
        $scope.pincodeModal.selectedCount = c;
    }

    function rebuildPincodeDropdownOptions() {
        if (!cachedPincodeDataset) return;
        const states = cachedPincodeDataset.states || [];
        const districts = cachedPincodeDataset.districts || [];
        const divisions = cachedPincodeDataset.divisions || [];
        const items = cachedPincodeDataset.items || [];

        $scope.pincodeModal.states = states;
        const stIdx = $scope.pincodeModal.selectedState ? states.indexOf($scope.pincodeModal.selectedState) : -1;

        const distSet = new Set();
        for (let i = 0; i < items.length; i++) {
            const row = items[i];
            if (stIdx >= 0 && row[1] !== stIdx) continue;
            const dName = districts[row[2]];
            if (dName) distSet.add(dName);
        }
        $scope.pincodeModal.districts = Array.from(distSet).sort();
        if ($scope.pincodeModal.selectedDistrict && !distSet.has($scope.pincodeModal.selectedDistrict)) {
            $scope.pincodeModal.selectedDistrict = '';
        }

        const dtIdx = $scope.pincodeModal.selectedDistrict ? districts.indexOf($scope.pincodeModal.selectedDistrict) : -1;
        const divSet = new Set();
        for (let i = 0; i < items.length; i++) {
            const row = items[i];
            if (stIdx >= 0 && row[1] !== stIdx) continue;
            if (dtIdx >= 0 && row[2] !== dtIdx) continue;
            const vName = divisions[row[3]];
            if (vName) divSet.add(vName);
        }
        $scope.pincodeModal.divisions = Array.from(divSet).sort();
        if ($scope.pincodeModal.selectedDivision && !divSet.has($scope.pincodeModal.selectedDivision)) {
            $scope.pincodeModal.selectedDivision = '';
        }
    }

    function updatePincodeModalPageSlice() {
        const m = $scope.pincodeModal;
        const total = m.filteredItems.length;
        const pageSize = m.pageSize || 100;
        m.totalPages = Math.max(1, Math.ceil(total / pageSize));
        if (m.page > m.totalPages) m.page = m.totalPages;
        if (m.page < 1) m.page = 1;
        const start = (m.page - 1) * pageSize;
        const end = Math.min(total, start + pageSize);
        m.pageStart = start;
        m.pageEnd = end;
        m.pageItems = m.filteredItems.slice(start, end);
        try {
            const sc = document.getElementById('plPinListScrollBody');
            if (sc) sc.scrollTop = 0;
        } catch (_) {}
    }

    function recomputeFilteredPincodes() {
        if (!cachedPincodeDataset) return;
        const m = $scope.pincodeModal;
        const states = cachedPincodeDataset.states || [];
        const districts = cachedPincodeDataset.districts || [];
        const divisions = cachedPincodeDataset.divisions || [];
        const items = cachedPincodeDataset.items || [];

        const stIdx = m.selectedState ? states.indexOf(m.selectedState) : -1;
        const dtIdx = m.selectedDistrict ? districts.indexOf(m.selectedDistrict) : -1;
        const dvIdx = m.selectedDivision ? divisions.indexOf(m.selectedDivision) : -1;
        const q = String(m.searchQuery || '').trim().toLowerCase();

        const byPin = new Map();
        for (let i = 0; i < items.length; i++) {
            const row = items[i];
            if (stIdx >= 0 && row[1] !== stIdx) continue;
            if (dtIdx >= 0 && row[2] !== dtIdx) continue;
            if (dvIdx >= 0 && row[3] !== dvIdx) continue;
            const pin = String(row[0]);
            const areasStr = String(row[4] || '');
            if (q && pin.toLowerCase().indexOf(q) === -1 && areasStr.toLowerCase().indexOf(q) === -1) {
                continue;
            }
            const existing = byPin.get(pin);
            if (!existing) {
                byPin.set(pin, areasStr);
            } else if (areasStr && existing.indexOf(areasStr) === -1) {
                const combined = new Set(existing.split(' · ').concat(areasStr.split(' · ')).filter(Boolean));
                byPin.set(pin, Array.from(combined).sort().join(' · '));
            }
        }

        const out = [];
        byPin.forEach((areas, pin) => {
            out.push({ pin, areas });
        });
        m.filteredItems = out;
        m.page = 1;
        updatePincodeModalPageSlice();
    }

    $scope.openPincodeSelectorModal = function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        const m = $scope.pincodeModal;
        m.show = true;
        // Pre-populate selectedMap from any 6-digit pincodes already inside local.locationTextarea
        const existingLines = String(($scope.local && $scope.local.locationTextarea) || '')
            .split(/\r?\n/)
            .map(s => s.trim())
            .filter(Boolean);
        const selMap = Object.assign({}, m.selectedMap || {});
        existingLines.forEach(line => {
            if (/^[1-9][0-9]{5}$/.test(line)) {
                selMap[line] = true;
            }
        });
        m.selectedMap = selMap;
        updateSelectedPincodeCount();

        try {
            const savedSt = localStorage.getItem('pl_last_pincode_state_v1');
            if (savedSt !== null) m.selectedState = savedSt;
            const savedDt = localStorage.getItem('pl_last_pincode_district_v1');
            if (savedDt !== null) m.selectedDistrict = savedDt;
        } catch (_) {}

        if (cachedPincodeDataset) {
            m.loading = false;
            rebuildPincodeDropdownOptions();
            recomputeFilteredPincodes();
            return;
        }
        m.loading = true;
        loadOfflinePincodeDataset().then(data => {
            $scope.safeApply(() => {
                m.loading = false;
                if (data) {
                    m.totalCsvRows = data.csvRows || 165627;
                    m.totalUniquePincodes = data.uniquePincodes || 19586;
                    rebuildPincodeDropdownOptions();
                    recomputeFilteredPincodes();
                }
            });
        });
    };

    $scope.closePincodeSelectorModal = function() {
        $scope.pincodeModal.show = false;
    };

    $scope.onPincodeStateChange = function() {
        $scope.pincodeModal.selectedDistrict = '';
        $scope.pincodeModal.selectedDivision = '';
        try {
            localStorage.setItem('pl_last_pincode_state_v1', $scope.pincodeModal.selectedState || '');
            localStorage.setItem('pl_last_pincode_district_v1', '');
        } catch (_) {}
        rebuildPincodeDropdownOptions();
        recomputeFilteredPincodes();
    };

    $scope.onPincodeDistrictChange = function() {
        $scope.pincodeModal.selectedDivision = '';
        try {
            localStorage.setItem('pl_last_pincode_district_v1', $scope.pincodeModal.selectedDistrict || '');
        } catch (_) {}
        rebuildPincodeDropdownOptions();
        recomputeFilteredPincodes();
    };

    $scope.onPincodeFilterChange = function() {
        recomputeFilteredPincodes();
    };

    $scope.changePincodeModalPage = function(delta) {
        const m = $scope.pincodeModal;
        const next = (m.page || 1) + delta;
        if (next < 1 || next > m.totalPages) return;
        m.page = next;
        updatePincodeModalPageSlice();
    };

    $scope.togglePincodeItem = function(pin, $event) {
        if ($event) {
            $event.stopPropagation();
        }
        const m = $scope.pincodeModal;
        if (m.selectedMap[pin]) {
            delete m.selectedMap[pin];
        } else {
            m.selectedMap[pin] = true;
        }
        updateSelectedPincodeCount();
    };

    $scope.isAllFilteredPincodesSelected = function() {
        const list = $scope.pincodeModal.filteredItems || [];
        if (!list.length) return false;
        const map = $scope.pincodeModal.selectedMap || {};
        for (let i = 0; i < list.length; i++) {
            if (!map[list[i].pin]) return false;
        }
        return true;
    };

    $scope.toggleSelectAllFilteredPincodes = function($event) {
        if ($event) $event.stopPropagation();
        const list = $scope.pincodeModal.filteredItems || [];
        if (!list.length) return;
        const map = $scope.pincodeModal.selectedMap || {};
        const allSelected = $scope.isAllFilteredPincodesSelected();
        if (allSelected) {
            for (let i = 0; i < list.length; i++) {
                delete map[list[i].pin];
            }
        } else {
            for (let i = 0; i < list.length; i++) {
                map[list[i].pin] = true;
            }
        }
        updateSelectedPincodeCount();
    };

    $scope.clearSelectedPincodes = function() {
        $scope.pincodeModal.selectedMap = {};
        updateSelectedPincodeCount();
    };

    $scope.applySelectedPincodes = function() {
        const map = $scope.pincodeModal.selectedMap || {};
        const selectedPins = Object.keys(map).filter(k => map[k]).sort();
        const existingNonPinLines = String(($scope.local && $scope.local.locationTextarea) || '')
            .split(/\r?\n/)
            .map(s => s.trim())
            .filter(line => line && !/^[1-9][0-9]{5}$/.test(line));
        const finalLines = existingNonPinLines.concat(selectedPins);
        const joinedLocs = finalLines.join('\n');
        if ($scope.local) {
            $scope.local.locationTextarea = joinedLocs;
            $scope.local.locationList = finalLines;
            _memoLocRaw = joinedLocs;
            _memoLocArr = finalLines;
            $scope._locCountCacheRaw = joinedLocs;
            $scope._locCountCacheVal = finalLines.length;
        }
        $scope.pincodeModal.show = false;
        try {
            if (typeof showTopStatusToast === 'function') {
                showTopStatusToast('✓ Applied ' + selectedPins.length + ' pincode(s) to Locations', 'success');
            }
        } catch (_) {}
        setTimeout(() => {
            try {
                if (typeof $scope.saveAsList === 'function') {
                    $scope.saveAsList();
                }
            } catch (_) {}
        }, 15);
    };


    // Smooth Touch & Mouse Drag-to-Resize for Keywords & Locations Cards (Mobile & Desktop)
    (function initCardDragResizers() {
        if (typeof document === 'undefined' || window.__plCardDragResizerBoundV42) return;
        window.__plCardDragResizerBound = true;
        window.__plCardDragResizerBoundV42 = true;
        let activeGroup = null;
        let activeHandles = [];
        let isMobileGroup = false;
        let startY = 0;
        let startHeight = 0;

        function getSyncedGroup(targetId) {
            if (targetId === 'mobileKeywordTextarea' || targetId === 'mobileLocationTextarea') {
                isMobileGroup = true;
                return [
                    document.getElementById('mobileKeywordTextarea'),
                    document.getElementById('mobileLocationTextarea')
                ].filter(Boolean);
            }
            isMobileGroup = false;
            return [
                document.getElementById('keywordTextarea'),
                document.getElementById('locationTextarea')
            ].filter(Boolean);
        }

        function getSyncedHandles(mobile) {
            const ids = mobile
                ? ['mobileKeywordTextarea', 'mobileLocationTextarea']
                : ['keywordTextarea', 'locationTextarea'];
            return ids
                .map(id => document.querySelector('[data-resize-textarea="' + id + '"]'))
                .filter(Boolean);
        }

        function applyGroupHeight(elements, nextH, maxH) {
            for (let i = 0; i < elements.length; i++) {
                const el = elements[i];
                if (!el) continue;
                el.style.setProperty('height', nextH + 'px', 'important');
                el.style.setProperty('max-height', maxH + 'px', 'important');
                el.style.setProperty('resize', 'none', 'important');
                const parentCard = el.closest && el.closest('.pl-m-card, .pl-input-panel');
                if (parentCard) {
                    parentCard.style.setProperty('height', 'auto', 'important');
                    parentCard.style.setProperty('overflow', 'hidden', 'important');
                }
            }
        }

        function restoreSavedHeights() {
            try {
                const deskH = parseInt(localStorage.getItem('pl_synced_desktop_ta_h'), 10);
                if (deskH >= 96 && deskH <= 360) {
                    applyGroupHeight(getSyncedGroup('keywordTextarea'), deskH, 360);
                }
                const mobH = parseInt(localStorage.getItem('pl_synced_mobile_ta_h'), 10);
                if (mobH >= 76 && mobH <= 220) {
                    applyGroupHeight(getSyncedGroup('mobileKeywordTextarea'), mobH, 220);
                }
            } catch (_) {}
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => setTimeout(restoreSavedHeights, 60));
        } else {
            setTimeout(restoreSavedHeights, 60);
        }

        function onStart(e) {
            const handle = e.target && e.target.closest ? e.target.closest('[data-resize-textarea]') : null;
            if (!handle) return;
            const targetId = handle.getAttribute('data-resize-textarea');
            const group = getSyncedGroup(targetId);
            if (!group.length) return;
            activeGroup = group;
            activeHandles = getSyncedHandles(isMobileGroup);
            activeHandles.forEach(h => h.classList.add('is-dragging-synced'));
            const clientY = (e.touches && e.touches[0]) ? e.touches[0].clientY : e.clientY;
            startY = clientY;
            startHeight = group[0].getBoundingClientRect().height || (isMobileGroup ? 88 : 120);
            if (e.cancelable) e.preventDefault();
            e.stopPropagation();
        }

        function onMove(e) {
            if (!activeGroup || !activeGroup.length) return;
            const clientY = (e.touches && e.touches[0]) ? e.touches[0].clientY : e.clientY;
            const deltaY = clientY - startY;
            const minH = isMobileGroup ? 76 : 96;
            const maxH = isMobileGroup ? 220 : 360;
            const nextH = Math.max(minH, Math.min(maxH, Math.round(startHeight + deltaY)));
            applyGroupHeight(activeGroup, nextH, maxH);
            try {
                localStorage.setItem(isMobileGroup ? 'pl_synced_mobile_ta_h' : 'pl_synced_desktop_ta_h', String(nextH));
            } catch (_) {}
            if (e.cancelable) e.preventDefault();
        }

        function onEnd() {
            if (activeHandles && activeHandles.length) {
                activeHandles.forEach(h => h.classList.remove('is-dragging-synced'));
            }
            activeGroup = null;
            activeHandles = [];
        }

        document.addEventListener('touchstart', onStart, { passive: false });
        document.addEventListener('touchmove', onMove, { passive: false });
        document.addEventListener('touchend', onEnd, { passive: true });
        document.addEventListener('touchcancel', onEnd, { passive: true });
        document.addEventListener('mousedown', onStart, false);
        document.addEventListener('mousemove', onMove, false);
        document.addEventListener('mouseup', onEnd, false);
    })();

    // Quietly warm up pincode dataset in idle time after boot so modal opens in 0ms
    setTimeout(() => { try { loadOfflinePincodeDataset(); } catch (_) {} }, 2800);

    $scope.closeExportModal = () => {
        $scope.exportModal.show = false;
    };

    $scope.selectAllExportFields = () => {
        if ($scope.exportModal) $scope.exportModal.activePreset = 'all';
        ($scope.exportModal.fields || []).forEach(field => { $scope.exportModal.selected[field] = true; });
    };

    $scope.deselectAllExportFields = () => {
        if ($scope.exportModal) $scope.exportModal.activePreset = 'none';
        ($scope.exportModal.fields || []).forEach(field => { $scope.exportModal.selected[field] = false; });
    };

    $scope.selectExportPreset = preset => {
        const fields = $scope.exportModal && Array.isArray($scope.exportModal.fields) ? $scope.exportModal.fields : [];
        $scope.deselectAllExportFields();
        if ($scope.exportModal) $scope.exportModal.activePreset = preset;
        if (preset === 'phone') {
            fields.forEach(f => { if (/^(keyword|location|company_name|phone_number|whatsapp_status|photo_url)$/i.test(f)) $scope.exportModal.selected[f] = true; });
        } else if (preset === 'email') {
            fields.forEach(f => { if (/^(keyword|location|company_name|email_1|website|facebook|instagram|linkedin|twitter|youtube|photo_url)$/i.test(f)) $scope.exportModal.selected[f] = true; });
        } else if (preset === 'telecalling') {
            fields.forEach(f => { if (/^(keyword|location|company_name|phone_number|whatsapp_status|city|category|address|map_link|photo_url)$/i.test(f)) $scope.exportModal.selected[f] = true; });
        } else if (preset === 'single_phone') {
            fields.forEach(f => { if (f === 'phone_number') $scope.exportModal.selected[f] = true; });
        } else if (preset === 'single_email') {
            fields.forEach(f => { if (f === 'email_1') $scope.exportModal.selected[f] = true; });
        } else if (preset === 'custom') {
            let savedCustom = [];
            try {
                const raw = localStorage.getItem('pl_custom_export_preset_v1');
                if (raw) savedCustom = JSON.parse(raw);
            } catch (_) {}
            if (!Array.isArray(savedCustom) || !savedCustom.length) {
                fields.forEach(f => { if (/^(keyword|location|company_name|phone_number|whatsapp_status|email_1|website|address|city|photo_url)$/i.test(f)) $scope.exportModal.selected[f] = true; });
                try { showTopStatusToast('ℹ Select your preferred columns and tap 💾 Save Preset to customize!', 'info'); } catch (_) {}
            } else {
                const customSet = new Set(savedCustom);
                fields.forEach(f => { if (customSet.has(f)) $scope.exportModal.selected[f] = true; });
                try { showTopStatusToast('⭐ Loaded your custom preset (' + savedCustom.length + ' columns)', 'success'); } catch (_) {}
            }
        }
    };

    $scope.saveCustomExportPreset = function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        const chosen = selectedExportLabels();
        if (!chosen.length) {
            try { showTopStatusToast('⚠ Please select at least 1 column to save as your preset', 'warn'); } catch (_) {}
            return;
        }
        try {
            localStorage.setItem('pl_custom_export_preset_v1', JSON.stringify(chosen));
            if (chrome && chrome.storage && chrome.storage.local) {
                chrome.storage.local.set({ pocketleadsCustomExportPreset: chosen });
            }
        } catch (_) {}
        if ($scope.exportModal) $scope.exportModal.activePreset = 'custom';
        try { showTopStatusToast('✓ Saved ' + chosen.length + ' columns to ⭐ My Preset!', 'success'); } catch (_) {}
    };

    $scope.shareExportedLeads = async function(format, $event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        if (typeof window !== 'undefined') {
            window.__plShareNextDownload = true;
        }
        await $scope.runSelectedExport(format || 'excel');
    };

    $scope.saveAsExportedLeads = async function(format, $event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        if (typeof window !== 'undefined') {
            window.__plChooseFolderNextDownload = true;
        }
        await $scope.runSelectedExport(format || 'excel');
    };

    $scope.selectedExportCount = () => selectedExportLabels().length;
    $scope.downloadFullData = () => { $scope.selectAllExportFields(); return $scope.runSelectedExport($scope.exportModal.format, true); };
    $scope.runSelectedExport = async (format, full=false) => {
        if($scope.exportModal.loading || $scope.exportModal.error)return;
        if (!(await allowExportRows($scope.exportModal.rowCount || 0))) return;
        if(!full){rememberedExportFields={...$scope.exportModal.selected};chrome.storage.local.set({pocketleadsExportFields:rememberedExportFields});}
        const modalRows = $scope.exportModal && Array.isArray($scope.exportModal.rows) ? $scope.exportModal.rows : [];
        const labels = selectedExportLabels();
        if (!labels.length) {
            $scope.snackbar.show('Please select at least one field.');
            return;
        }
        const mode = String(format || $scope.exportModal.format || 'csv').toLowerCase();
        const stamp = new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
        if ($scope.exportModal && $scope.exportModal.largeMode) {
            if (mode === 'copy') {
                $scope.snackbar.show('Large datasets are exported in chunks. Use CSV or Excel instead of Copy.');
                return;
            }
            $scope.exportModal.loading = true;
            try {
                const blob = await buildLargeExportBlob(mode === 'excel' ? 'excel' : 'csv', labels);
                saveBlobDownload(blob, 'PocketLeads_Leads_' + stamp + (mode === 'excel' ? '.xlsx' : '.csv'));
                $scope.closeExportModal();
            } catch (error) {
                $scope.snackbar.show(error && error.message ? error.message : 'Large export failed.');
            } finally {
                $scope.exportModal.loading = false;
            }
            return;
        }
        let rows = ($scope.exportModal && Array.isArray(modalRows) && modalRows.length) ? modalRows : await getCompleteRowsForExport();
        const uniqueKey = $scope.exportModal && $scope.exportModal.uniqueBy ? String($scope.exportModal.uniqueBy).trim() : '';
        if (uniqueKey && Array.isArray(rows)) {
            const seenUnique = new Set();
            rows = rows.filter(r => {
                const rawVal = String(exportValueFor(r, uniqueKey) || '').trim().toLowerCase();
                if (!rawVal || rawVal === '—' || rawVal === 'no email found' || rawVal === "can't access website") return false;
                const normVal = uniqueKey === 'phone_number' ? rawVal.replace(/\D/g, '').replace(/^0+/, '') : rawVal;
                if (!normVal || seenUnique.has(normVal)) return false;
                seenUnique.add(normVal);
                return true;
            });
        }
        if (mode === 'json') {
            const jsonRows = rows.map(row => {
                const obj = {};
                labels.forEach(label => { obj[label] = exportValueFor(row, label); });
                return obj;
            });
            saveBlobDownload(new Blob([JSON.stringify(jsonRows, null, 2)], { type: 'application/json;charset=utf-8' }), 'PocketLeads_Custom_Export_' + stamp + '.json');
            $scope.closeExportModal();
            return;
        }
        try {
            window.__plLastExportedSheet = {
                filename: 'PocketLeads_Leads_' + stamp + (mode === 'excel' ? '.xlsx' : (mode === 'json' ? '.json' : '.csv')),
                format: mode,
                headers: labels.map(l => $scope.getExportFieldLabel(l)),
                rows: rows.slice(0, 300).map(r => labels.map(l => exportValueFor(r, l))),
                totalCount: rows.length
            };
        } catch (_) {}
        if (mode === 'excel') {
            saveBlobDownload(buildTrueXlsxBlob(rows, labels), 'PocketLeads_Leads_' + stamp + '.xlsx');
            $scope.closeExportModal();
            return;
        }
        if (mode === 'copy') {
            const text = labels.map(exportHeaderFor).join('\t') + '\n' + rows.map(row => labels.map(label => {
                const value = exportValueFor(row, label);
                return String(value).replace(/[\t\r\n]+/g, ' ');
            }).join('\t')).join('\n');
            const done = () => { $scope.safeApply(() => { $scope.snackbar.show('Selected fields copied.'); showTopStatusToast('✓ Selected leads copied to clipboard', 'success'); $scope.closeExportModal(); }); };
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(done).catch(() => {
                    const ta = document.createElement('textarea');
                    ta.value = text;
                    document.body.appendChild(ta);
                    ta.select();
                    document.execCommand('copy');
                    ta.remove();
                    done();
                });
            } else {
                const ta = document.createElement('textarea');
                ta.value = text;
                document.body.appendChild(ta);
                ta.select();
                document.execCommand('copy');
                ta.remove();
                done();
            }
            return;
        }
        saveBlobDownload(new Blob([buildCsvFromRows(rows, labels)], { type: 'text/csv;charset=utf-8' }), 'PocketLeads_Custom_Export_' + stamp + '.csv');
        $scope.closeExportModal();
    };
    
    $scope.metricCounts = { website: 0, phone_number: 0, email_1: 0 };
    let metricsTimer=null;
    function refreshDashboardMetricCounts(rows) {
        try { refreshMobileLeadsView(rows); } catch (e) {}
        const isActiveRun = !!(($scope.local && PocketLeadsRunState.isRunning($scope.local)) || ($scope.local && $scope.local.isScrapingEmail));
        if($scope.local?.collectIsPreview){
            if(metricsTimer)return;
            metricsTimer=setTimeout(async()=>{
                try{
                    const r=await runtimeMessageAsync({action:'result_store_query',query:{metrics:true,metricsOnly:true,limit:1}});
                    if(r?.metrics){
                        $scope.$evalAsync(()=>{
                            if (isActiveRun && $scope.metricCounts) {
                                $scope.metricCounts = {
                                    website: Math.max($scope.metricCounts.website || 0, r.metrics.website || 0),
                                    phone_number: Math.max($scope.metricCounts.phone_number || 0, r.metrics.phone_number || 0),
                                    email_1: Math.max($scope.metricCounts.email_1 || 0, r.metrics.email_1 || 0)
                                };
                            } else {
                                $scope.metricCounts = r.metrics;
                            }
                        });
                    }
                }
                finally{metricsTimer=null;}
            },350);
            return;
        }
        const websites = new Set();
        const phones = new Set();
        const emails = new Set();
        (Array.isArray(rows) ? rows : []).forEach(row => {
            const website = String(row && row.website || '').trim().toLowerCase();
            if (website) websites.add(website);
            const digits = String(rowPhoneValue(row) || '').replace(/\D/g, '').replace(/^0+/, '');
            if (digits.length >= 8) phones.add(digits);
            const em = String(row && row.email_1 || '').trim().toLowerCase();
            if (em && !/^(no email|can't access|blacklisted)/i.test(em) && em.includes('@')) emails.add(em);
        });
        if (!Array.isArray(rows) || rows.length === 0) {
            if (!isActiveRun) {
                $scope.metricCounts.website = 0;
                $scope.metricCounts.phone_number = 0;
                $scope.metricCounts.email_1 = 0;
            }
            return;
        }
        $scope.metricCounts.website = isActiveRun ? Math.max($scope.metricCounts.website || 0, websites.size) : websites.size;
        $scope.metricCounts.phone_number = isActiveRun ? Math.max($scope.metricCounts.phone_number || 0, phones.size) : phones.size;
        $scope.metricCounts.email_1 = isActiveRun ? Math.max($scope.metricCounts.email_1 || 0, emails.size) : emails.size;
    }
    $scope.countOf = targetKey => Number($scope.metricCounts && $scope.metricCounts[targetKey]) || 0;
    $scope.countPhones = () => Number($scope.metricCounts && $scope.metricCounts.phone_number) || 0;

    /* --------------------------------------------------------------------
     * Mobile View State, Navigation, Progress & Lead Card Helpers
     * Provides a clean, responsive 3-tab mobile view (Home/Setup, Progress,
     * Leads) that shares 100% of triggers, models, and live extraction state
     * with Desktop View so switching views at any time is instant and smooth.
     */
    $scope.viewMode = (typeof window !== 'undefined' && window.pocketleadsViewMode && typeof window.pocketleadsViewMode.get === 'function')
        ? window.pocketleadsViewMode.get()
        : 'desktop';
    $scope.themeMode = (typeof window !== 'undefined' && window.pocketleadsTheme && typeof window.pocketleadsTheme.get === 'function')
        ? window.pocketleadsTheme.get()
        : 'dark';
    $scope.mobileTab = (function() {
        try {
            const saved = sessionStorage.getItem('pl_mobile_tab');
            return (saved === 'home' || saved === 'progress' || saved === 'leads') ? saved : 'home';
        } catch (_) {
            return 'home';
        }
    })();
    $scope.mobileDataDrawerOpen = false;
    $scope.mobileLeadSearch = '';
    $scope.mobileLeadFilter = 'all';
    $scope.mobileLeadLimit = 40;
    $scope.getLeadQualityInfo = function(row) {
        if (!row || typeof row !== 'object') {
            return { score: 0, tier: 'cold', badge: '❄️ Cold 0%', exportText: '0% (Cold)' };
        }
        let score = 0;
        const phone = String(rowPhoneValue(row) || '').trim();
        if (phone) score += 25;
        if (/^(valid|available|yes|true|verified|active)$/i.test(String(row.whatsapp_status || '').trim())) score += 5;
        const email = String(row.email_1 || row.email || '').trim();
        if (email && email.includes('@') && !/^(no email found|can't access website|blacklisted email)$/i.test(email)) {
            score += 25;
        }
        const web = String(row.website || row.websiteUrl || '').trim();
        if (web && !/google\.com\/maps/i.test(web)) score += 15;
        if (row.facebook || row.instagram || row.linkedin || row.twitter || row.youtube) score += 10;
        const ratingNum = parseFloat(String(row.review || row.rating || '').replace(/[^0-9.]/g, ''));
        if (Number.isFinite(ratingNum)) {
            if (ratingNum >= 4.0) score += 10;
            else if (ratingNum >= 3.0) score += 5;
        }
        const revCnt = parseInt(String(row.review_count || row.reviews || row.total_reviews || '').replace(/[^0-9]/g, ''), 10);
        if (Number.isFinite(revCnt)) {
            if (revCnt >= 10) score += 10;
            else if (revCnt >= 3) score += 5;
        }
        if ((row.photos_sample && row.photos_sample.length) || row.photo_url || row.opening_hours) score += 5;
        if (score > 100) score = 100;
        const tier = score >= 70 ? 'hot' : (score >= 45 ? 'warm' : 'cold');
        const icon = tier === 'hot' ? '🔥 Hot ' : (tier === 'warm' ? '⚡ Warm ' : '❄️ Cold ');
        const tierLabel = tier === 'hot' ? 'Hot' : (tier === 'warm' ? 'Warm' : 'Cold');
        row.lead_quality_score = score + '% (' + tierLabel + ')';
        return {
            score: score,
            tier: tier,
            badge: icon + score + '%',
            exportText: score + '% (' + tierLabel + ')'
        };
    };

    $scope.setMobileLeadFilter = function(filterKey) {
        const next = String(filterKey || 'all').toLowerCase();
        $scope.mobileLeadFilter = ($scope.mobileLeadFilter === next && next !== 'all') ? 'all' : next;
        $scope.mobileLeadLimit = 40;
        refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
    };
    $scope.mobileSelectedMap = {};
    $scope.mobileVisibleLeads = [];
    $scope.mobileTotalFilteredCount = 0;
    let mobileSearchTimer = null;

    function syncGridLayoutSoon() {
        setTimeout(function() {
            try {
                if (dataGrid && typeof dataGrid.refresh === 'function') dataGrid.refresh();
                if (typeof window !== 'undefined') window.dispatchEvent(new Event('resize'));
            } catch (_) {}
        }, 40);
    }

    $scope.setViewMode = function(mode) {
        const next = (String(mode || '').toLowerCase() === 'mobile') ? 'mobile' : 'desktop';
        if (typeof window !== 'undefined' && window.pocketleadsViewMode && typeof window.pocketleadsViewMode.set === 'function') {
            $scope.viewMode = window.pocketleadsViewMode.set(next);
        } else {
            $scope.viewMode = next;
            try {
                document.documentElement.setAttribute('data-view-mode', next);
                if (document.body) document.body.setAttribute('data-view-mode', next);
            } catch (_) {}
        }
        if ($scope.viewMode === 'desktop') {
            $scope.mobileDataDrawerOpen = false;
            syncGridLayoutSoon();
        } else {
            refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
        }
    };

    $scope.setThemeMode = function(theme) {
        const next = (String(theme || '').toLowerCase() === 'light') ? 'light' : 'dark';
        if (typeof window !== 'undefined' && window.pocketleadsTheme && typeof window.pocketleadsTheme.set === 'function') {
            $scope.themeMode = window.pocketleadsTheme.set(next);
        } else {
            $scope.themeMode = next;
        }
    };

    $scope.mobileTableZoom = 85;
    $scope.zoomMobileTable = function(delta) {
        const cur = Number($scope.mobileTableZoom) || 85;
        $scope.mobileTableZoom = Math.max(50, Math.min(140, cur + (Number(delta) || 0)));
    };
    $scope.resetMobileTableZoom = function() {
        $scope.mobileTableZoom = 85;
    };

    const mobileTabStack = ['home'];
    function armMobileBackGuardIfNeeded() {
        try {
            if (typeof window === 'undefined' || !window.history || typeof window.history.pushState !== 'function') return;
            const pDoc = document.getElementById('pl-inapp-doc-overlay');
            const pDet = document.getElementById('plTicketDetailModal');
            const pSup = document.getElementById('plSupportModal');
            const pProf = document.getElementById('plProfilePanel');
            const pNotif = document.getElementById('plNotificationsPanel');
            const hasOpenLayer = !!(
                pDoc ||
                (pDet && !pDet.hidden) ||
                (pSup && !pSup.hidden) ||
                (pProf && !pProf.hidden) ||
                (pNotif && !pNotif.hidden) ||
                document.getElementById('pl-inapp-crm-overlay') ||
                document.getElementById('pl-inapp-excel-viewer') ||
                $scope.activeLeadDetail ||
                ($scope.exportModal && $scope.exportModal.show) ||
                ($scope.historyModal && $scope.historyModal.show) ||
                $scope.mobileDataDrawerOpen ||
                ($scope.completePopup && $scope.completePopup.show) ||
                $scope.showClearDataModal ||
                $scope.showDiagnostics ||
                ($scope.mobileTab && $scope.mobileTab !== 'home')
            );
            if (hasOpenLayer && (!window.history.state || !window.history.state.plBackGuard)) {
                window.history.pushState({ plBackGuard: true }, '', window.location.href);
            }
        } catch (_) {}
    }

    const MOBILE_TABS_ORDER = ['home', 'progress', 'leads'];
    function triggerMobileTabSlideAnimation(prevTab, nextTab, explicitDir) {
        try {
            const shell = document.querySelector('.pl-mobile-shell');
            if (!shell) return;
            const prevIdx = MOBILE_TABS_ORDER.indexOf(prevTab || 'home');
            const nextIdx = MOBILE_TABS_ORDER.indexOf(nextTab || 'home');
            const dir = explicitDir || (nextIdx >= prevIdx ? 'right' : 'left');
            const cls = dir === 'left' ? 'pl-slide-from-left' : 'pl-slide-from-right';
            setTimeout(function() {
                const panes = shell.querySelectorAll('.pl-m-tab-pane');
                panes.forEach(function(p) {
                    p.classList.remove('pl-slide-from-right', 'pl-slide-from-left');
                    if (!p.classList.contains('ng-hide')) {
                        void p.offsetWidth;
                        p.classList.add(cls);
                    }
                });
            }, 10);
        } catch (_) {}
    }

    $scope.setMobileTab = function(tab, fromBack, slideDir) {
        const next = (tab === 'progress' || tab === 'leads') ? tab : 'home';
        const prev = $scope.mobileTab || 'home';
        if (!fromBack && prev && prev !== next) {
            if (mobileTabStack[mobileTabStack.length - 1] !== prev) {
                mobileTabStack.push(prev);
                if (mobileTabStack.length > 8) mobileTabStack.shift();
            }
        }
        $scope.mobileTab = next;
        $scope.mobileDataDrawerOpen = false;
        try { sessionStorage.setItem('pl_mobile_tab', next); } catch (_) {}
        if (next === 'leads') {
            refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
        }
        if (prev !== next) {
            triggerMobileTabSlideAnimation(prev, next, slideDir);
        }
        setTimeout(armMobileBackGuardIfNeeded, 20);
    };

    // 3-Tab Horizontal Touch Swipe Navigation (Home <-> Progress <-> Leads)
    if (typeof document !== 'undefined' && !window.__plMobileTabSwipeBound) {
        window.__plMobileTabSwipeBound = true;
        let swipeStartX = 0;
        let swipeStartY = 0;
        let swipeStartTime = 0;
        let swipeValid = false;

        function canStartTabSwipe(target) {
            if ($scope.viewMode !== 'mobile') return false;
            if ($scope.mobileDataDrawerOpen || $scope.activeLeadDetail) return false;
            if ($scope.photoLightbox && $scope.photoLightbox.open) return false;
            if ($scope.exportModal && $scope.exportModal.show) return false;
            if ($scope.historyModal && $scope.historyModal.show) return false;
            if ($scope.pincodeModal && $scope.pincodeModal.show) return false;
            if ($scope.startConfirmModal && $scope.startConfirmModal.open) return false;
            if ($scope.showClearDataModal) return false;
            if (document.getElementById('pl-inapp-doc-overlay') || document.getElementById('pl-inapp-crm-overlay') || document.getElementById('pl-inapp-excel-viewer')) return false;
            const prof = document.getElementById('plProfilePanel');
            if (prof && !prof.hidden) return false;
            const notif = document.getElementById('plNotificationsPanel');
            if (notif && !notif.hidden) return false;
            const sup = document.getElementById('plSupportModal');
            if (sup && !sup.hidden) return false;
            if (!target || typeof target.closest !== 'function') return false;
            if (!target.closest('.pl-mobile-shell')) return false;
            if (target.closest('.pl-card-resize-handle, .pl-m-spreadsheet-wrap, .pl-m-bottom-nav, .pl-m-card-dropdown, input[type="range"]')) return false;
            return true;
        }

        document.addEventListener('touchstart', function(ev) {
            if (!ev.touches || ev.touches.length !== 1) {
                swipeValid = false;
                return;
            }
            if (!canStartTabSwipe(ev.target)) {
                swipeValid = false;
                return;
            }
            swipeStartX = ev.touches[0].clientX;
            swipeStartY = ev.touches[0].clientY;
            swipeStartTime = Date.now();
            swipeValid = true;
        }, { passive: true });

        document.addEventListener('touchmove', function(ev) {
            if (!swipeValid || !ev.touches || ev.touches.length !== 1) {
                swipeValid = false;
                return;
            }
            const dy = Math.abs(ev.touches[0].clientY - swipeStartY);
            const dx = Math.abs(ev.touches[0].clientX - swipeStartX);
            // If user is predominantly scrolling vertically, cancel horizontal tab swipe
            if (dy > 28 && dy > dx * 0.95) {
                swipeValid = false;
            }
        }, { passive: true });

        document.addEventListener('touchend', function(ev) {
            if (!swipeValid || !ev.changedTouches || ev.changedTouches.length !== 1) return;
            swipeValid = false;
            const dt = Date.now() - swipeStartTime;
            if (dt > 750) return;
            const dx = ev.changedTouches[0].clientX - swipeStartX;
            const dy = ev.changedTouches[0].clientY - swipeStartY;
            if (Math.abs(dx) < 54 || Math.abs(dx) < Math.abs(dy) * 1.35) return;

            const curIdx = MOBILE_TABS_ORDER.indexOf($scope.mobileTab || 'home');
            if (dx < 0 && curIdx < MOBILE_TABS_ORDER.length - 1) {
                // Swipe Left -> Next Page (Home -> Progress -> Leads)
                const nextTab = MOBILE_TABS_ORDER[curIdx + 1];
                $scope.safeApply(function() {
                    $scope.setMobileTab(nextTab, false, 'right');
                });
            } else if (dx > 0 && curIdx > 0) {
                // Swipe Right -> Previous Page (Leads -> Progress -> Home)
                const prevTab = MOBILE_TABS_ORDER[curIdx - 1];
                $scope.safeApply(function() {
                    $scope.setMobileTab(prevTab, false, 'left');
                });
            }
        }, { passive: true });
    }

    if (typeof window !== 'undefined') {
        window.__handleAndroidBackButton = function() {
            try {
                if ($scope.photoLightbox && $scope.photoLightbox.open) {
                    $scope.safeApply(function() { $scope.photoLightbox.open = false; });
                    setTimeout(armMobileBackGuardIfNeeded, 20);
                    return 'handled';
                }
                const docOverlay = document.getElementById('pl-inapp-doc-overlay');
                if (docOverlay) {
                    docOverlay.remove();
                    setTimeout(armMobileBackGuardIfNeeded, 20);
                    return 'handled';
                }
                const ticketDetail = document.getElementById('plTicketDetailModal');
                if (ticketDetail && !ticketDetail.hidden) {
                    const closeBtn = document.getElementById('plTicketDetailClose');
                    if (closeBtn) closeBtn.click();
                    else { ticketDetail.hidden = true; ticketDetail.style.display = 'none'; }
                    setTimeout(armMobileBackGuardIfNeeded, 20);
                    return 'handled';
                }
                const supportModal = document.getElementById('plSupportModal');
                if (supportModal && !supportModal.hidden) {
                    const closeBtn = document.getElementById('plSupportCloseBtn');
                    if (closeBtn) closeBtn.click();
                    else { supportModal.hidden = true; supportModal.style.display = 'none'; document.body.classList.remove('pl-modal-open'); }
                    setTimeout(armMobileBackGuardIfNeeded, 20);
                    return 'handled';
                }
                const profilePanel = document.getElementById('plProfilePanel');
                if (profilePanel && !profilePanel.hidden) {
                    const closeBtn = profilePanel.querySelector('[data-profile-action="close"]');
                    if (closeBtn) closeBtn.click();
                    else { profilePanel.hidden = true; profilePanel.classList.remove('is-open'); profilePanel.style.display = 'none'; }
                    setTimeout(armMobileBackGuardIfNeeded, 20);
                    return 'handled';
                }
                const notifPanel = document.getElementById('plNotificationsPanel');
                if (notifPanel && !notifPanel.hidden) {
                    const closeBtn = document.getElementById('plNotifCloseBtn');
                    if (closeBtn) closeBtn.click();
                    else { notifPanel.hidden = true; notifPanel.classList.remove('is-open'); notifPanel.style.display = 'none'; }
                    setTimeout(armMobileBackGuardIfNeeded, 20);
                    return 'handled';
                }
                const crmOverlay = document.getElementById('pl-inapp-crm-overlay');
                if (crmOverlay) {
                    crmOverlay.remove();
                    setTimeout(armMobileBackGuardIfNeeded, 20);
                    return 'handled';
                }
                const xlOverlay = document.getElementById('pl-inapp-excel-viewer');
                if (xlOverlay) {
                    xlOverlay.remove();
                    setTimeout(armMobileBackGuardIfNeeded, 20);
                    return 'handled';
                }
                const privFull = document.getElementById('privacyFullModal');
                if (privFull && privFull.style.display === 'flex') {
                    privFull.style.display = 'none';
                    const privSum = document.getElementById('privacyModal');
                    if (privSum) privSum.style.display = 'flex';
                    setTimeout(armMobileBackGuardIfNeeded, 20);
                    return 'handled';
                }
                let handledInScope = false;
                $scope.safeApply(function() {
                    if ($scope.confirmDeleteHistoryModal && $scope.confirmDeleteHistoryModal.show) {
                        $scope.confirmDeleteHistoryModal.show = false;
                        handledInScope = true;
                        return;
                    }
                    if ($scope.activeCardMenuKey) {
                        $scope.activeCardMenuKey = '';
                        handledInScope = true;
                        return;
                    }
                    if ($scope.activeLeadDetail) {
                        $scope.closeMobileLeadDetail();
                        handledInScope = true;
                        return;
                    }
                    if ($scope.exportModal && $scope.exportModal.show) {
                        $scope.closeExportModal();
                        handledInScope = true;
                        return;
                    }
                    if ($scope.historyModal && $scope.historyModal.show) {
                        if ($scope.historyModal.viewSession) {
                            $scope.backToHistoryList();
                        } else {
                            $scope.closeScrapingHistory();
                        }
                        handledInScope = true;
                        return;
                    }
                    if ($scope.mobileDataDrawerOpen) {
                        $scope.closeMobileDataGrid();
                        handledInScope = true;
                        return;
                    }
                    if ($scope.completePopup && $scope.completePopup.show) {
                        $scope.closeCompletePopup();
                        handledInScope = true;
                        return;
                    }
                    if ($scope.showClearDataModal) {
                        $scope.showClearDataModal = false;
                        handledInScope = true;
                        return;
                    }
                    if ($scope.showDiagnostics) {
                        $scope.showDiagnostics = false;
                        handledInScope = true;
                        return;
                    }
                    if ($scope.viewMode === 'mobile' && $scope.mobileTab && $scope.mobileTab !== 'home') {
                        let prevTab = mobileTabStack.pop();
                        if (!prevTab || prevTab === $scope.mobileTab) {
                            prevTab = ($scope.mobileTab === 'leads') ? 'progress' : 'home';
                        }
                        $scope.setMobileTab(prevTab, true);
                        handledInScope = true;
                        return;
                    }
                });
                if (handledInScope) {
                    setTimeout(armMobileBackGuardIfNeeded, 20);
                    return 'handled';
                }
            } catch (_) {}
            return 'exit';
        };

        if (!window.__plBackPopstateBound) {
            window.__plBackPopstateBound = true;
            window.addEventListener('popstate', function() {
                if (typeof window.__handleAndroidBackButton === 'function') {
                    window.__handleAndroidBackButton();
                }
            });
            document.addEventListener('click', function() {
                setTimeout(armMobileBackGuardIfNeeded, 60);
            }, true);
            document.addEventListener('focusin', function(ev) {
                const t = ev && ev.target;
                if (t && (t.tagName === 'TEXTAREA' || (t.tagName === 'INPUT' && t.type !== 'checkbox' && t.type !== 'radio')) && t.closest && t.closest('.pl-mobile-shell')) {
                    document.documentElement.classList.add('pl-kb-open');
                    setTimeout(function() {
                        try { t.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (_) {}
                    }, 180);
                }
            }, true);
            document.addEventListener('focusout', function() {
                setTimeout(function() {
                    const a = document.activeElement;
                    if (!a || !(a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && a.type !== 'checkbox' && a.type !== 'radio'))) {
                        document.documentElement.classList.remove('pl-kb-open');
                    }
                }, 120);
            }, true);
        }
    }

    $scope.openMobileDataGrid = function() {
        $scope.mobileDataDrawerOpen = true;
        refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
        try {
            const targetCount = Math.max(0, parseInt($scope.local && $scope.local.resultStoreCount, 10) || 0);
            const curLen = Array.isArray($scope.local && $scope.local.collect) ? $scope.local.collect.length : 0;
            if (targetCount > curLen && typeof $scope.syncLiveCanonicalTable === 'function') {
                $scope.syncLiveCanonicalTable(targetCount);
            }
        } catch (_) {}
        if (!dataGrid || !productsStore) {
            buildDataTable($scope.local || {});
        } else if (productsStore && typeof productsStore.setRows === 'function') {
            productsStore.setRows(safeCollectRows($scope.local || {}));
        }
        syncGridLayoutSoon();
        setTimeout(function() {
            armMobileBackGuardIfNeeded();
            const wrap = document.getElementById('plMobileSpreadsheetWrap');
            if (wrap && !wrap.__plPinchBound) {
                wrap.__plPinchBound = true;
                let startDist = 0;
                let startZoom = 85;
                wrap.addEventListener('touchstart', function(e) {
                    if (e.touches && e.touches.length === 2) {
                        const dx = e.touches[0].clientX - e.touches[1].clientX;
                        const dy = e.touches[0].clientY - e.touches[1].clientY;
                        startDist = Math.hypot(dx, dy);
                        startZoom = Number($scope.mobileTableZoom) || 85;
                    }
                }, { passive: true });
                wrap.addEventListener('touchmove', function(e) {
                    if (e.touches && e.touches.length === 2 && startDist > 20) {
                        const dx = e.touches[0].clientX - e.touches[1].clientX;
                        const dy = e.touches[0].clientY - e.touches[1].clientY;
                        const curDist = Math.hypot(dx, dy);
                        const ratio = curDist / startDist;
                        const nextZoom = Math.max(50, Math.min(140, Math.round((startZoom * ratio) / 5) * 5));
                        if (nextZoom !== $scope.mobileTableZoom) {
                            $scope.$evalAsync(function() {
                                $scope.mobileTableZoom = nextZoom;
                            });
                        }
                    }
                }, { passive: true });
            }
        }, 60);
    };

    $scope.closeMobileDataGrid = function() {
        $scope.mobileDataDrawerOpen = false;
    };

    $scope.onMobileMainAction = function() {
        if ($scope.isStopEnabled || $scope.isScrapingActive()) {
            $scope.manualStopScraping();
            return;
        }
        $scope.saveAsList(true);
        const hasKw = (Array.isArray($scope.local && $scope.local.keywordList) && $scope.local.keywordList.length > 0) ||
                      String(($scope.local && $scope.local.keywordTextarea) || '').trim().length > 0;
        const hasLoc = (Array.isArray($scope.local && $scope.local.locationList) && $scope.local.locationList.length > 0) ||
                       String(($scope.local && $scope.local.locationTextarea) || '').trim().length > 0;
        if ((!hasKw || !hasLoc) && !$scope.resumeAvailable) {
            const missingMsg = (!hasKw && !hasLoc)
                ? 'Please input Keywords and Location first'
                : (!hasKw ? 'Please input Keywords first' : 'Please input Location first');
            showTopStatusToast('⚠ ' + missingMsg, 'warn');
            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                $scope.snackbar.show(missingMsg);
            }
            $scope.setMobileTab('home');
            setTimeout(() => {
                try {
                    const targetId = !hasKw ? 'mobileKeywordTextarea' : 'mobileLocationTextarea';
                    const el = document.getElementById(targetId);
                    if (el) el.focus();
                } catch (_) {}
            }, 80);
            return;
        }
        const wasResume = !!$scope.resumeAvailable;
        $scope.manualStartScraping();
        if ($scope.startLaunchPending || $scope.isScrapingActive()) {
            showTopStatusToast(wasResume ? '▶ Resuming lead extraction...' : '▶ Extraction started...', 'success');
            $scope.setMobileTab('progress');
        }
    };

    if (typeof document !== 'undefined' && !document.documentElement.dataset.plViewControllerBound) {
        document.documentElement.dataset.plViewControllerBound = '1';
        document.addEventListener('pocketleads-view-mode-change', function(ev) {
            const next = (ev && ev.detail && ev.detail.viewMode) || 'desktop';
            $scope.$evalAsync(function() {
                $scope.viewMode = next;
                if (next === 'desktop') {
                    $scope.mobileDataDrawerOpen = false;
                    syncGridLayoutSoon();
                } else {
                    refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
                }
            });
        });
        document.addEventListener('pocketleads-theme-change', function(ev) {
            const next = (ev && ev.detail && ev.detail.theme) || 'dark';
            $scope.$evalAsync(function() {
                $scope.themeMode = next;
            });
        });
    }

    $scope.getCountryIsoCode = function(country) {
        const name = String(country || ($scope.local && $scope.local.country) || 'India').trim();
        const code = DASHBOARD_COUNTRY_CODES[name] || (typeof window !== 'undefined' && window.countryIsoCodes && window.countryIsoCodes[name]) || 'IN';
        return String(code || 'IN').toLowerCase();
    };

    $scope.getMobileStatusText = function() {
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const active = $scope.isScrapingActive() || !!$scope.startLaunchPending;
        if (active) {
            const pTotal = Math.max(0, parseInt(($scope.progressData && $scope.progressData.taskTotal) || q.totalTasks, 10) || ($scope.getKeywordLineCount() * $scope.getLocationLineCount()) || 0);
            const pIdx = Math.max(1, Math.min(pTotal || 1, parseInt(q.currentTaskIndex || ($scope.progressData && $scope.progressData.currentTaskIndex) || ((parseInt(q.completedTasks, 10) || 0) + 1), 10) || 1));
            return pTotal > 0 ? ('Extracting leads (' + pIdx + '/' + pTotal + ')...') : 'Extracting business leads...';
        }
        if ($scope.progressData && $scope.progressData.inputsModified) {
            const newTotal = $scope.getKeywordLineCount() * $scope.getLocationLineCount();
            return 'Ready to extract (' + newTotal + (newTotal === 1 ? ' task)' : ' tasks)');
        }
        const totalSaved = Number($scope.local && ($scope.local.resultStoreCount || ($scope.local.collect && $scope.local.collect.length))) || 0;
        const status = String(q.status || '').toLowerCase();
        if (status === 'stopped' || $scope.resumeAvailable) {
            return 'Extraction paused · Ready to resume';
        }
        if (/^(completed|completed_with_errors|dataset_saved)$/.test(status) && totalSaved > 0) {
            return 'All business leads extracted';
        }
        return 'Ready to extract business leads';
    };

    $scope.getMobileProgressPercent = function() {
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const status = String(q.status || '').toLowerCase();
        const active = $scope.isScrapingActive() || !!$scope.startLaunchPending;
        if ($scope.progressData && $scope.progressData.inputsModified && !active) {
            return 0;
        }
        const p = Number($scope.progressData && $scope.progressData.percent);
        if (active) {
            return Number.isFinite(p) ? Math.max(0, Math.min(99, Math.round(p))) : 0;
        }
        if (/^(completed|completed_with_errors|dataset_saved)$/.test(status)) {
            return 100;
        }
        if (Number.isFinite(p) && p >= 0) {
            return Math.max(0, Math.min(100, Math.round(p)));
        }
        return 0;
    };

    $scope.getDesktopRingDashoffset = function() {
        const circumference = 477.5;
        const pct = $scope.getMobileProgressPercent();
        return circumference - (circumference * (pct / 100));
    };

    $scope.getMobileRingDashoffset = function() {
        const circumference = 527.79; // 2 * Math.PI * 84
        const pct = $scope.getMobileProgressPercent();
        return circumference - (circumference * (pct / 100));
    };

    $scope.getLiveActiveQueryBanner = function() {
        const local = $scope.local || {};
        const q = local.apifyQueue || {};
        const active = $scope.isScrapingActive() || !!$scope.startLaunchPending;
        const inputsModified = !!($scope.progressData && $scope.progressData.inputsModified && !active);
        const listTotal = $scope.getKeywordLineCount() * $scope.getLocationLineCount();
        const total = inputsModified
            ? listTotal
            : Math.max(0, parseInt(($scope.progressData && $scope.progressData.taskTotal) || q.totalTasks || local.apifyTaskTotal || listTotal, 10) || 0);
        if (inputsModified) {
            return 'Ready to extract ' + total + (total === 1 ? ' target search' : ' target searches');
        }
        const done = Math.max(0, parseInt(($scope.progressData && $scope.progressData.taskCompleted) ?? q.completedTasks, 10) || 0);
        const currentIdx = active
            ? Math.max(1, Math.min(total || 1, parseInt(q.currentTaskIndex || ($scope.progressData && $scope.progressData.currentTaskIndex) || (done + 1), 10) || 1))
            : Math.min(total, Math.max(done, parseInt(q.currentTaskIndex, 10) || 0));
        let query = String(q.currentQuery || local.activeQuery || '').trim();
        if (!query && Array.isArray(local.taskList) && local.taskList[0]) {
            query = String(local.taskList[0]).replace(/~in~/g, ' in ') + (local.country ? (' ' + local.country) : '');
        }
        const stepPrefix = total > 0 && currentIdx > 0 ? `[${Math.min(total, currentIdx)}/${total}] ` : '';
        if (active && query) {
            return `Scraping ${stepPrefix}${query}`;
        }
        if (query && !/^(completed|completed_with_errors|idle)$/i.test(String(q.status || ''))) {
            return `${stepPrefix}${query}`;
        }
        return q.statusMessage || ((local.resultStoreCount || (local.collect && local.collect.length)) ? 'All leads captured successfully' : 'Waiting for start');
    };

    $scope.getMobileProfilesProcessedText = function() {
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const saved = Number($scope.local && ($scope.local.resultStoreCount || ($scope.local.collect && $scope.local.collect.length))) || 0;
        const active = $scope.isScrapingActive() || !!$scope.startLaunchPending;
        const inputsModified = !!($scope.progressData && $scope.progressData.inputsModified && !active);
        const listTotal = $scope.getKeywordLineCount() * $scope.getLocationLineCount();
        const totalTasks = inputsModified
            ? listTotal
            : Math.max(0, parseInt(($scope.progressData && $scope.progressData.taskTotal) || q.totalTasks || ($scope.local && $scope.local.apifyTaskTotal) || listTotal, 10) || 0);
        const doneTasks = inputsModified
            ? 0
            : Math.max(0, parseInt(($scope.progressData && $scope.progressData.taskCompleted) ?? q.completedTasks, 10) || 0);
        if (totalTasks > 0) {
            return `${saved} saved (${Math.min(totalTasks, doneTasks)}/${totalTasks} tasks)`;
        }
        return saved + ' saved';
    };

    $scope._kwCountCacheRaw = null;
    $scope._kwCountCacheVal = 0;
    $scope.getKeywordLineCount = function() {
        const kwText = String(($scope.local && $scope.local.keywordTextarea) || '');
        if (!kwText) return 0;
        if (kwText === $scope._kwCountCacheRaw) return $scope._kwCountCacheVal;
        $scope._kwCountCacheRaw = kwText;
        let count = 0;
        const lines = kwText.split(/\r?\n/);
        for (let i = 0; i < lines.length; i++) {
            if (lines[i].trim()) count++;
        }
        $scope._kwCountCacheVal = count;
        return count;
    };

    $scope._locCountCacheRaw = null;
    $scope._locCountCacheVal = 0;
    $scope.getLocationLineCount = function() {
        const locText = String(($scope.local && $scope.local.locationTextarea) || '');
        if (!locText) return 0;
        if (locText === $scope._locCountCacheRaw) return $scope._locCountCacheVal;
        $scope._locCountCacheRaw = locText;
        let count = 0;
        const lines = locText.split(/\r?\n/);
        for (let i = 0; i < lines.length; i++) {
            if (lines[i].trim()) count++;
        }
        $scope._locCountCacheVal = count;
        return count;
    };

    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
        chrome.runtime.onMessage.addListener(function(msg) {
            if (msg && msg.type === 'pl_notification_clicked') {
                $scope.$evalAsync(function() {
                    const count = Number(($scope.local && ($scope.local.resultStoreCount || ($scope.local.collect && $scope.local.collect.length))) || 0);
                    const targetTab = count > 0 ? 'leads' : 'progress';
                    if (typeof $scope.setMobileTab === 'function') {
                        $scope.setMobileTab(targetTab);
                    } else {
                        $scope.mobileTab = targetTab;
                    }
                });
            }
        });
    }

    $scope.getMobileKeywordsStatText = function() {
        const kwTotal = $scope.getKeywordLineCount();
        if (!kwTotal) return '0 / 0';
        const locTotal = Math.max(1, $scope.getLocationLineCount());
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const active = $scope.isScrapingActive() || !!$scope.startLaunchPending;
        if ($scope.progressData && $scope.progressData.inputsModified && !active) {
            return '0 / ' + kwTotal;
        }
        const completedTasks = Math.max(0, parseInt(($scope.progressData && $scope.progressData.taskCompleted) ?? q.completedTasks, 10) || 0);
        if (!active && /^(completed|completed_with_errors|dataset_saved)$/i.test(String(q.status || '')) && completedTasks > 0) {
            return kwTotal + ' / ' + kwTotal;
        }
        if (completedTasks >= kwTotal * locTotal && (kwTotal * locTotal) > 0) {
            return kwTotal + ' / ' + kwTotal;
        }
        const kwDone = Math.floor(completedTasks / locTotal) + (active ? 1 : 0);
        return Math.min(kwTotal, Math.max(0, (active || completedTasks > 0) ? kwDone : 0)) + ' / ' + kwTotal;
    };

    $scope.getMobileLocationsStatText = function() {
        const locCount = $scope.getLocationLineCount();
        const kwCount = Math.max(1, $scope.getKeywordLineCount());
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const active = $scope.isScrapingActive() || !!$scope.startLaunchPending;
        const inputsModified = !!($scope.progressData && $scope.progressData.inputsModified && !active);
        const totalTasks = inputsModified
            ? (kwCount * locCount)
            : Math.max(0, parseInt(($scope.progressData && $scope.progressData.taskTotal) || q.totalTasks || (kwCount * locCount), 10) || 0);
        const locTotal = locCount || totalTasks;
        if (!locTotal) return '0 / 0';
        if (inputsModified) {
            return '0 / ' + locTotal;
        }
        const completedTasks = Math.max(0, parseInt(($scope.progressData && $scope.progressData.taskCompleted) ?? q.completedTasks, 10) || 0);
        if (!active && /^(completed|completed_with_errors|dataset_saved)$/i.test(String(q.status || '')) && totalTasks > 0 && completedTasks >= totalTasks) {
            return locTotal + ' / ' + locTotal;
        }
        // When running 1 keyword across N locations, completedTasks maps 1:1 with completed locations
        const locDone = kwCount <= 1 ? completedTasks : (completedTasks >= totalTasks ? locTotal : (completedTasks % locTotal));
        return Math.min(locTotal, locDone) + ' / ' + locTotal;
    };

    $scope.getMobileRemainingText = function() {
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const active = $scope.isScrapingActive() || !!$scope.startLaunchPending;
        const inputsModified = !!($scope.progressData && $scope.progressData.inputsModified && !active);
        const listTotal = $scope.getKeywordLineCount() * $scope.getLocationLineCount();
        if (inputsModified) {
            return listTotal + (listTotal === 1 ? ' task remaining' : ' tasks remaining');
        }
        const pDone = Math.max(0, parseInt(($scope.progressData && $scope.progressData.taskCompleted) ?? q.completedTasks, 10) || 0);
        const pTotal = Math.max(0, parseInt(($scope.progressData && $scope.progressData.taskTotal) || q.totalTasks || listTotal, 10) || 0);
        if (pTotal > pDone) {
            const rem = Math.max(0, pTotal - pDone);
            return rem + (rem === 1 ? ' task remaining' : ' tasks remaining');
        }
        const domDone = Math.max(0, parseInt(q.domProcessed || ($scope.progressData && $scope.progressData.domCompleted), 10) || 0);
        const domTotal = Math.max(0, parseInt(q.domTotal || ($scope.progressData && $scope.progressData.domTotal), 10) || 0);
        if (domTotal > domDone && String(q.provider || '').toLowerCase() === 'googlemaps') {
            const rem = Math.max(0, domTotal - domDone);
            return rem + (rem === 1 ? ' profile remaining' : ' profiles remaining');
        }
        return '0 tasks remaining';
    };

    function matchesMobileLeadQuery(row, qLower) {
        if (!qLower) return true;
        if (!row || typeof row !== 'object') return false;
        const hay = [
            row.company_name, row.name, row.title,
            rowPhoneValue(row),
            row.website, row.websiteUrl, row.url,
            row.address, row.city, row.location, row.pincode,
            row.email_1, row.email, row.category
        ].filter(Boolean).join(' ').toLowerCase();
        return hay.includes(qLower);
    }

    function refreshMobileLeadsView(sourceRows) {
        const rows = Array.isArray(sourceRows)
            ? sourceRows
            : (Array.isArray($scope.local && $scope.local.collect) ? $scope.local.collect : []);
        const storeCount = Number($scope.local && $scope.local.resultStoreCount) || 0;
        if ($scope.viewMode === 'mobile' && $scope.mobileTab !== 'leads' && PocketLeadsRunState.isRunning($scope.local)) {
            $scope.mobileTotalFilteredCount = Math.max(rows.length, storeCount);
            return;
        }
        const qLower = String($scope.mobileLeadSearch || '').trim().toLowerCase();
        const fMode = String($scope.mobileLeadFilter || 'all').toLowerCase();
        const limit = Math.max(20, parseInt($scope.mobileLeadLimit, 10) || 40);
        const matchesFilterChip = (r) => {
            if (!r || typeof r !== 'object' || !fMode || fMode === 'all') return true;
            if (fMode === 'hot') return $scope.getLeadQualityInfo(r).score >= 70;
            if (fMode === 'phone') return !!String(rowPhoneValue(r) || '').trim();
            if (fMode === 'email') {
                const em = String(r.email_1 || r.email || '').trim();
                return !!em && em.includes('@') && !/^(no email found|can't access website|blacklisted email)$/i.test(em);
            }
            if (fMode === 'website') return !!String(r.website || r.websiteUrl || '').trim();
            if (fMode === 'wa') return /^(valid|available|yes|true|verified|active)$/i.test(String(r.whatsapp_status || '').trim());
            if (fMode === 'rating4') {
                const num = parseFloat(String(r.review || r.rating || '').replace(/[^0-9.]/g, ''));
                return Number.isFinite(num) && num >= 4.0;
            }
            if (fMode === 'open') {
                const st = String(r.status || r.current_status || '').trim();
                return /open/i.test(st) && !/closed/i.test(st);
            }
            return true;
        };
        const filtered = (qLower || (fMode && fMode !== 'all'))
            ? rows.filter(r => matchesFilterChip(r) && (!qLower || matchesMobileLeadQuery(r, qLower)))
            : rows;
        $scope.mobileTotalFilteredCount = qLower ? filtered.length : Math.max(filtered.length, storeCount);
        $scope.mobileVisibleLeads = filtered.slice(0, limit);
        enqueueVisibleLeadsPhotoEnrichment($scope.mobileVisibleLeads);

        // If preview mode is active and user searches or requests beyond in-memory preview, query canonical IndexedDB
        if ($scope.local && $scope.local.collectIsPreview && (qLower || limit > rows.length)) {
            if (mobileSearchTimer) clearTimeout(mobileSearchTimer);
            mobileSearchTimer = setTimeout(async function() {
                mobileSearchTimer = null;
                try {
                    const res = await runtimeMessageAsync({
                        action: 'result_store_query',
                        query: { query: qLower, offset: 0, limit: limit }
                    });
                    if (res && res.ok && Array.isArray(res.rows)) {
                        $scope.$evalAsync(function() {
                            $scope.mobileVisibleLeads = res.rows;
                            if (Number.isFinite(res.count)) {
                                $scope.mobileTotalFilteredCount = res.count;
                            }
                        });
                    }
                } catch (_) {}
            }, 180);
        }
    }

    $scope.onMobileLeadSearchChange = function() {
        $scope.mobileLeadLimit = 40;
        refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
    };

    $scope.clearMobileLeadSearch = function() {
        $scope.mobileLeadSearch = '';
        $scope.mobileLeadLimit = 40;
        refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
    };

    $scope.loadMoreMobileLeads = function() {
        $scope.mobileLeadLimit = (parseInt($scope.mobileLeadLimit, 10) || 40) + 40;
        refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
    };

    $scope.getMobileLeadTrackKey = function(row, index) {
        if (!row || typeof row !== 'object') return 'm_lead_' + index;
        return String(ensureDashboardRowKey(row, index) || ('m_lead_' + index));
    };

    $scope.getMobileLeadTitle = function(row) {
        if (!row) return 'Unnamed Business';
        return String(row.company_name || row.name || row.title || 'Unnamed Business').trim();
    };

    $scope.getMobileLeadInitial = function(row) {
        const title = $scope.getMobileLeadTitle(row);
        const match = title.match(/[A-Za-z0-9]/);
        return match ? match[0].toUpperCase() : 'B';
    };

    const MOBILE_AVATAR_PALETTE = [
        '#8a4f38', '#255f85', '#6c3b8c', '#1e6b52', '#9c4221', '#3b4d71', '#7c3aed', '#0f766e'
    ];
    $scope.getMobileLeadAvatarBg = function(row) {
        const title = $scope.getMobileLeadTitle(row);
        let hash = 0;
        for (let i = 0; i < title.length; i++) {
            hash = ((hash << 5) - hash) + title.charCodeAt(i);
            hash |= 0;
        }
        return MOBILE_AVATAR_PALETTE[Math.abs(hash) % MOBILE_AVATAR_PALETTE.length];
    };

    $scope.getLeadPhotosSample = function(row) {
        if (!row || typeof row !== 'object') return [];
        const list = [];
        const seen = new Set();
        const addPair = (small, large) => {
            const cleanSmall = upgradeDashboardPhotoUrl(small || large || '', small);
            const cleanLarge = upgradeDashboardPhotoUrl(large || small || '', cleanSmall || small);
            const sUrl = cleanSmall || cleanLarge;
            if (!sUrl || !/^https?:\/\//i.test(sUrl)) return;
            const lUrl = (/\/(?:gps-cs-s|gps-proxy)\/|streetviewpixels/i.test(sUrl)) ? sUrl : (cleanLarge || sUrl);
            const key = canonicalDashboardPhotoKey(sUrl) || sUrl;
            if (seen.has(key)) return;
            seen.add(key);
            list.push({ photo_url: sUrl, photo_url_large: lUrl });
        };
        if (Array.isArray(row.photos_sample)) {
            row.photos_sample.forEach(p => {
                if (!p) return;
                if (typeof p === 'string') addPair(p, p);
                else if (typeof p === 'object') addPair(p.photo_url || p.photoUrl || p.thumbnail || p.url, p.photo_url_large || p.photoUrlLarge || p.photo_url || p.url);
            });
        }
        if (row.photo_url || row.photo_url_large) {
            addPair(row.photo_url, row.photo_url_large);
        }
        if (typeof row.photo_urls === 'string' && row.photo_urls.trim()) {
            row.photo_urls.split(/\s*,\s*/).forEach(u => addPair(u, u));
        }
        const legacy = String(row.image || row.photo || row.thumbnail || row.featured_image || row.imageUrl || row.photoUrl || row.mainPhoto || '').trim();
        if (legacy) addPair(legacy, legacy);
        return list;
    };

    $scope.getLeadAllPhotoUrls = function(row) {
        const samples = $scope.getLeadPhotosSample(row);
        const urls = [];
        samples.forEach(s => {
            if (s.photo_url && !urls.includes(s.photo_url)) urls.push(s.photo_url);
        });
        return urls;
    };

    $scope.getLeadRestPhotoUrls = function(row) {
        return $scope.getLeadAllPhotoUrls(row);
    };

    // Always return the verified signed photo_url for immediate, 400-free rendering on cards
    $scope.getMobileLeadImage = function(row) {
        if (!row || typeof row !== 'object') return '';
        const samples = $scope.getLeadPhotosSample(row);
        if (samples.length) {
            return samples[0].photo_url || samples[0].photo_url_large || '';
        }
        const candidate = upgradeDashboardPhotoUrl(row.photo_url || row.photo_url_large || row.image || row.photo || row.thumbnail || row.featured_image || row.imageUrl || row.photoUrl || row.mainPhoto || '');
        return /^https?:\/\//i.test(candidate) ? candidate : '';
    };

    $scope.getMobileLeadFallbackImage = function(row) {
        if (!row || typeof row !== 'object') return '';
        const primary = $scope.getMobileLeadImage(row);
        const samples = $scope.getLeadPhotosSample(row);
        if (samples.length > 1 && samples[1].photo_url && samples[1].photo_url !== primary) {
            return samples[1].photo_url;
        }
        return '';
    };

    // Background & On-Demand Google Maps Place Photo Enricher
    const photoEnrichAttempted = new Set();
    const photoEnrichQueue = [];
    let photoEnrichActiveWorkers = 0;

    async function enrichLeadPhotosFromMaps(row, priority) {
        if (!row || typeof row !== 'object') return false;
        const rowKey = String(ensureDashboardRowKey(row, 0) || row.place_id || row.cid || row.company_name || '').trim();
        if (!rowKey) return false;
        if (!priority && photoEnrichAttempted.has(rowKey)) return false;
        photoEnrichAttempted.add(rowKey);

        const placeId = String(row.place_id || row.placeId || '').trim();
        const cid = String(row.cid || '').trim();
        const title = String(row.company_name || row.name || row.title || '').trim();
        const addr = String(row.address || row.city || row.location || '').trim();
        const query = [title, addr].filter(Boolean).join(', ');
        if (!placeId && !cid && !query) return false;

        try {
            const resp = await runtimeMessageAsync({
                action: 'pocketleads_fetch_place_photos',
                placeId,
                cid,
                query
            });
            if (!resp || !resp.ok || !Array.isArray(resp.photos) || !resp.photos.length) return false;

            const existing = $scope.getLeadPhotosSample(row);
            const merged = existing.slice();
            const seen = new Set(merged.map(p => canonicalDashboardPhotoKey(p.photo_url) || p.photo_url));
            let addedAny = false;
            resp.photos.forEach(p => {
                if (!p || !p.photo_url) return;
                const cleanSmall = upgradeDashboardPhotoUrl(p.photo_url, p.photo_url);
                const cleanLarge = upgradeDashboardPhotoUrl(p.photo_url_large || p.photo_url, cleanSmall);
                if (!cleanSmall) return;
                const k = canonicalDashboardPhotoKey(cleanSmall) || cleanSmall;
                if (seen.has(k)) return;
                seen.add(k);
                merged.push({ photo_url: cleanSmall, photo_url_large: cleanLarge || cleanSmall });
                addedAny = true;
            });
            if (!addedAny) return false;

            const cappedPhotos = merged.slice(0, 5);
            row.photos_sample = cappedPhotos;
            row.photo_url = cappedPhotos[0].photo_url;
            row.photo_url_large = cappedPhotos[0].photo_url_large || cappedPhotos[0].photo_url;
            row.photo_urls = cappedPhotos.map(p => p.photo_url).join(', ');
            row._imgBroken = false;

            try {
                void runtimeMessageAsync({ action: 'result_store_upsert', rows: [row] });
            } catch (_) {}

            $scope.$evalAsync(() => {
                if ($scope.activeLeadDetail === row && typeof buildMobileLeadDetailVm === 'function') {
                    $scope.activeLeadDetailVm = buildMobileLeadDetailVm(row);
                }
                if ($scope.photoLightbox && $scope.photoLightbox.open && $scope.photoLightbox.row === row) {
                    $scope.photoLightbox.photos = merged.slice();
                    $scope.photoLightbox.enriching = false;
                }
                if (dataGrid && typeof dataGrid.repaint === 'function') {
                    dataGrid.repaint();
                }
            });
            return true;
        } catch (_) {
            return false;
        }
    }

    function pumpPhotoEnrichQueue() {
        while (photoEnrichActiveWorkers < 2 && photoEnrichQueue.length > 0) {
            const nextRow = photoEnrichQueue.shift();
            photoEnrichActiveWorkers++;
            enrichLeadPhotosFromMaps(nextRow, false).finally(() => {
                photoEnrichActiveWorkers = Math.max(0, photoEnrichActiveWorkers - 1);
                setTimeout(pumpPhotoEnrichQueue, 120);
            });
        }
    }

    function enqueueVisibleLeadsPhotoEnrichment(rows) {
        if (!Array.isArray(rows) || !rows.length) return;
        rows.slice(0, 40).forEach(r => {
            if (!r || typeof r !== 'object') return;
            const key = String(ensureDashboardRowKey(r, 0) || r.place_id || r.cid || r.company_name || '').trim();
            if (!key || photoEnrichAttempted.has(key)) return;
            const samples = $scope.getLeadPhotosSample(r);
            const hasAf1 = samples.some(s => /\/p\/AF1Qip/i.test(String(s && s.photo_url || '')));
            if (samples.length <= 1 || !hasAf1) {
                photoEnrichQueue.push(r);
            }
        });
        pumpPhotoEnrichQueue();
    }

    $scope.onLeadImageError = function(row) {
        if (!row || typeof row !== 'object') return;
        row._imgBroken = true;
        void enrichLeadPhotosFromMaps(row, true);
    };

    // In-App Full-Screen Business Photo Lightbox Viewer with Interactive Zoom & Pan
    $scope.photoLightbox = {
        open: false,
        photos: [],
        index: 0,
        title: '',
        zoom: 1,
        panX: 0,
        panY: 0,
        enriching: false,
        row: null
    };

    let lbPinchStartDist = 0;
    let lbPinchStartZoom = 1;
    let lbDragActive = false;
    let lbDragStartX = 0;
    let lbDragStartY = 0;
    let lbStartPanX = 0;
    let lbStartPanY = 0;
    let lbLastTapTime = 0;

    function preverifyHdLightboxPhotos(photosList) {
        if (!Array.isArray(photosList)) return;
        photosList.forEach(item => {
            if (!item || !item.photo_url_large || item.photo_url_large === item.photo_url) return;
            if (/\/(?:gps-cs-s|gps-proxy)\/|streetviewpixels/i.test(item.photo_url_large)) {
                item.photo_url_large = item.photo_url;
                return;
            }
            const candidateHd = item.photo_url_large;
            item._verifiedLarge = item.photo_url;
            const tester = new Image();
            tester.referrerPolicy = 'no-referrer';
            tester.onload = function() {
                if (tester.naturalWidth > 0) {
                    $scope.$evalAsync(() => {
                        item._verifiedLarge = candidateHd;
                    });
                }
            };
            tester.onerror = function() {
                item.photo_url_large = item.photo_url;
                item._verifiedLarge = item.photo_url;
            };
            tester.src = candidateHd;
        });
    }

    $scope.openPhotoLightbox = function(photosArray, startIndex, title, $event, sourceRow) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        const list = (Array.isArray(photosArray) ? photosArray : []).map(p => {
            if (typeof p === 'string') {
                const clean = upgradeDashboardPhotoUrl(p, p);
                return { photo_url: clean, photo_url_large: clean, _verifiedLarge: clean };
            }
            const cleanSmall = upgradeDashboardPhotoUrl(p.photo_url || p.photo_url_large || '', p.photo_url);
            const cleanLarge = upgradeDashboardPhotoUrl(p.photo_url_large || p.photo_url || '', cleanSmall);
            return {
                photo_url: cleanSmall || cleanLarge,
                photo_url_large: cleanLarge || cleanSmall,
                _verifiedLarge: cleanSmall || cleanLarge
            };
        }).filter(p => p.photo_url || p.photo_url_large);
        if (!list.length) return;
        preverifyHdLightboxPhotos(list);
        const targetRow = sourceRow || $scope.activeLeadDetail || null;
        const needsMorePhotos = !!(targetRow && list.length <= 1);
        $scope.photoLightbox = {
            open: true,
            photos: list,
            index: Math.max(0, Math.min(list.length - 1, Number(startIndex) || 0)),
            title: String(title || (targetRow && $scope.getMobileLeadTitle(targetRow)) || 'Business Photo'),
            zoom: 1,
            panX: 0,
            panY: 0,
            enriching: needsMorePhotos,
            row: targetRow
        };
        if (needsMorePhotos) {
            enrichLeadPhotosFromMaps(targetRow, true).finally(() => {
                $scope.$evalAsync(() => {
                    if ($scope.photoLightbox) $scope.photoLightbox.enriching = false;
                });
            });
        }
    };

    $scope.openLeadPhotoZoom = function(row, $event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        if (!row || typeof row !== 'object') return;
        const photos = $scope.getLeadPhotosSample(row);
        if (!photos.length) return;
        $scope.openPhotoLightbox(photos, 0, $scope.getMobileLeadTitle(row), $event, row);
    };

    if (typeof window !== 'undefined') {
        window.__plOpenLeadPhotoZoom = function(row, startIdx) {
            $scope.$evalAsync(() => {
                if (!row) return;
                const photos = $scope.getLeadPhotosSample(row);
                if (photos.length) {
                    $scope.openPhotoLightbox(photos, startIdx || 0, $scope.getMobileLeadTitle(row), null, row);
                }
            });
        };
    }

    $scope.closePhotoLightbox = function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        $scope.photoLightbox.open = false;
        $scope.photoLightbox.zoom = 1;
        $scope.photoLightbox.panX = 0;
        $scope.photoLightbox.panY = 0;
    };

    $scope.prevLightboxPhoto = function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        const len = ($scope.photoLightbox.photos || []).length;
        if (len <= 1) return;
        $scope.photoLightbox.index = ($scope.photoLightbox.index - 1 + len) % len;
        $scope.photoLightbox.zoom = 1;
        $scope.photoLightbox.panX = 0;
        $scope.photoLightbox.panY = 0;
    };

    $scope.nextLightboxPhoto = function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        const len = ($scope.photoLightbox.photos || []).length;
        if (len <= 1) return;
        $scope.photoLightbox.index = ($scope.photoLightbox.index + 1) % len;
        $scope.photoLightbox.zoom = 1;
        $scope.photoLightbox.panX = 0;
        $scope.photoLightbox.panY = 0;
    };

    $scope.selectLightboxPhoto = function(idx, $event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        $scope.photoLightbox.index = idx;
        $scope.photoLightbox.zoom = 1;
        $scope.photoLightbox.panX = 0;
        $scope.photoLightbox.panY = 0;
    };

    $scope.zoomInLightbox = function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        const cur = Number($scope.photoLightbox.zoom) || 1;
        $scope.photoLightbox.zoom = Math.min(4, Math.round((cur + 0.5) * 10) / 10);
    };

    $scope.zoomOutLightbox = function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        const cur = Number($scope.photoLightbox.zoom) || 1;
        const next = Math.max(1, Math.round((cur - 0.5) * 10) / 10);
        $scope.photoLightbox.zoom = next;
        if (next <= 1) {
            $scope.photoLightbox.panX = 0;
            $scope.photoLightbox.panY = 0;
        }
    };

    $scope.resetLightboxZoom = function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        $scope.photoLightbox.zoom = 1;
        $scope.photoLightbox.panX = 0;
        $scope.photoLightbox.panY = 0;
    };

    $scope.toggleLightboxDoubleTapZoom = function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        if (($scope.photoLightbox.zoom || 1) > 1.05) {
            $scope.photoLightbox.zoom = 1;
            $scope.photoLightbox.panX = 0;
            $scope.photoLightbox.panY = 0;
        } else {
            $scope.photoLightbox.zoom = 2.5;
            $scope.photoLightbox.panX = 0;
            $scope.photoLightbox.panY = 0;
        }
    };

    $scope.onLightboxWheel = function($event) {
        if (!$event) return;
        $event.preventDefault();
        $event.stopPropagation();
        const delta = ($event.deltaY || -$event.wheelDelta || 0) < 0 ? 0.35 : -0.35;
        const cur = Number($scope.photoLightbox.zoom) || 1;
        const next = Math.max(1, Math.min(4, Math.round((cur + delta) * 100) / 100));
        $scope.photoLightbox.zoom = next;
        if (next <= 1) {
            $scope.photoLightbox.panX = 0;
            $scope.photoLightbox.panY = 0;
        }
    };

    let lbOneFingerZoomActive = false;
    let lbOneFingerStartY = 0;
    let lbOneFingerBaseZoom = 1;
    let lbDoubleTapMoved = false;

    $scope.onLightboxTouchStart = function($event) {
        if (!$event) return;
        const touches = $event.touches || ($event.originalEvent && $event.originalEvent.touches);
        if (!touches) return;
        if (touches.length === 2) {
            if (typeof $event.preventDefault === 'function') $event.preventDefault();
            const dx = touches[0].clientX - touches[1].clientX;
            const dy = touches[0].clientY - touches[1].clientY;
            lbPinchStartDist = Math.hypot(dx, dy);
            lbPinchStartZoom = Number($scope.photoLightbox.zoom) || 1;
            lbDragActive = false;
            lbOneFingerZoomActive = false;
        } else if (touches.length === 1) {
            const now = Date.now();
            if (now - lbLastTapTime < 320) {
                if (typeof $event.preventDefault === 'function') $event.preventDefault();
                lbOneFingerZoomActive = true;
                lbDoubleTapMoved = false;
                lbOneFingerStartY = touches[0].clientY;
                lbOneFingerBaseZoom = Number($scope.photoLightbox.zoom) || 1;
                lbLastTapTime = 0;
                return;
            }
            lbLastTapTime = now;
            lbOneFingerZoomActive = false;
            lbDragActive = true;
            lbDragStartX = touches[0].clientX;
            lbDragStartY = touches[0].clientY;
            lbStartPanX = Number($scope.photoLightbox.panX) || 0;
            lbStartPanY = Number($scope.photoLightbox.panY) || 0;
        }
    };

    $scope.onLightboxTouchMove = function($event) {
        if (!$event) return;
        const touches = $event.touches || ($event.originalEvent && $event.originalEvent.touches);
        if (!touches) return;
        if (touches.length === 2 && lbPinchStartDist > 15) {
            if (typeof $event.preventDefault === 'function') $event.preventDefault();
            const dx = touches[0].clientX - touches[1].clientX;
            const dy = touches[0].clientY - touches[1].clientY;
            const dist = Math.hypot(dx, dy);
            const next = Math.max(1, Math.min(4, Math.round((lbPinchStartZoom * (dist / lbPinchStartDist)) * 100) / 100));
            $scope.photoLightbox.zoom = next;
            if (next <= 1.02) {
                $scope.photoLightbox.panX = 0;
                $scope.photoLightbox.panY = 0;
            }
        } else if (touches.length === 1 && lbOneFingerZoomActive) {
            if (typeof $event.preventDefault === 'function') $event.preventDefault();
            const dy = touches[0].clientY - lbOneFingerStartY;
            if (Math.abs(dy) > 6) {
                lbDoubleTapMoved = true;
                const scaleFactor = 1 + (dy / 160);
                const next = Math.max(1, Math.min(4, Math.round((lbOneFingerBaseZoom * scaleFactor) * 100) / 100));
                $scope.photoLightbox.zoom = next;
                if (next <= 1.02) {
                    $scope.photoLightbox.panX = 0;
                    $scope.photoLightbox.panY = 0;
                }
            }
        } else if (touches.length === 1 && lbDragActive && ($scope.photoLightbox.zoom || 1) > 1.02) {
            if (typeof $event.preventDefault === 'function') $event.preventDefault();
            const dx = touches[0].clientX - lbDragStartX;
            const dy = touches[0].clientY - lbDragStartY;
            $scope.photoLightbox.panX = lbStartPanX + dx;
            $scope.photoLightbox.panY = lbStartPanY + dy;
        }
    };

    $scope.onLightboxTouchEnd = function($event) {
        if (lbOneFingerZoomActive && !lbDoubleTapMoved) {
            $scope.toggleLightboxDoubleTapZoom($event);
        }
        lbOneFingerZoomActive = false;
        lbDoubleTapMoved = false;
        lbPinchStartDist = 0;
        lbDragActive = false;
    };

    $scope.onLightboxMouseDown = function($event) {
        if (!$event || ($scope.photoLightbox.zoom || 1) <= 1.02) return;
        $event.preventDefault();
        lbDragActive = true;
        lbDragStartX = $event.clientX;
        lbDragStartY = $event.clientY;
        lbStartPanX = Number($scope.photoLightbox.panX) || 0;
        lbStartPanY = Number($scope.photoLightbox.panY) || 0;
    };

    $scope.onLightboxMouseMove = function($event) {
        if (!lbDragActive || !$event || ($scope.photoLightbox.zoom || 1) <= 1.02) return;
        const dx = $event.clientX - lbDragStartX;
        const dy = $event.clientY - lbDragStartY;
        $scope.photoLightbox.panX = Math.max(-500, Math.min(500, lbStartPanX + dx));
        $scope.photoLightbox.panY = Math.max(-500, Math.min(500, lbStartPanY + dy));
    };

    $scope.onLightboxMouseUp = function() {
        lbDragActive = false;
    };

    $scope.getLightboxTransformStyle = function() {
        const z = Number($scope.photoLightbox && $scope.photoLightbox.zoom) || 1;
        const x = Number($scope.photoLightbox && $scope.photoLightbox.panX) || 0;
        const y = Number($scope.photoLightbox && $scope.photoLightbox.panY) || 0;
        return {
            transform: 'translate3d(' + x + 'px, ' + y + 'px, 0) scale(' + z + ')',
            cursor: z > 1.02 ? 'grab' : 'zoom-in'
        };
    };

    $scope.cardExpandedPhotosMap = {};
    $scope.toggleCardPhotosExpand = function(row, index, $event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        const key = $scope.getMobileLeadTrackKey(row, index);
        $scope.cardExpandedPhotosMap[key] = !$scope.cardExpandedPhotosMap[key];
    };

    // -----------------------------------------------------------------------
    // 3-Dot Card Menu, Long-Press Selection Mode, Bulk Delete & Export
    // -----------------------------------------------------------------------
    $scope.activeCardMenuKey = '';
    $scope.selectedRowsByKey = {};
    $scope.mobileSelectionMode = false;
    let pressTimer = null;
    let pressStartPos = null;
    let longPressTriggered = false;

    $scope.getSelectedLeadsCount = function() {
        if (!$scope.mobileSelectedMap) return 0;
        return Object.keys($scope.mobileSelectedMap).filter(k => !!$scope.mobileSelectedMap[k]).length;
    };

    $scope.isLeadSelected = function(row, index) {
        const key = $scope.getMobileLeadTrackKey(row, index);
        return !!($scope.mobileSelectedMap && $scope.mobileSelectedMap[key]);
    };

    $scope.toggleLeadSelection = function(row, index, $event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        if (!row || typeof row !== 'object') return;
        const key = $scope.getMobileLeadTrackKey(row, index);
        const nextVal = !($scope.mobileSelectedMap && $scope.mobileSelectedMap[key]);
        if (nextVal) {
            $scope.mobileSelectedMap[key] = true;
            $scope.selectedRowsByKey[key] = row;
        } else {
            delete $scope.mobileSelectedMap[key];
            delete $scope.selectedRowsByKey[key];
        }
        const count = $scope.getSelectedLeadsCount();
        $scope.mobileSelectionMode = count > 0;
        $scope.activeCardMenuKey = '';
        if (dataGrid && typeof dataGrid.repaint === 'function') dataGrid.repaint();
    };

    $scope.clearLeadSelection = function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        $scope.mobileSelectedMap = {};
        $scope.selectedRowsByKey = {};
        $scope.mobileSelectionMode = false;
        $scope.activeCardMenuKey = '';
        if (dataGrid && typeof dataGrid.repaint === 'function') dataGrid.repaint();
    };

    $scope.isAllVisibleLeadsSelected = function() {
        const list = Array.isArray($scope.mobileVisibleLeads) && $scope.mobileVisibleLeads.length
            ? $scope.mobileVisibleLeads
            : (($scope.local && $scope.local.collect) || []);
        if (!list.length) return false;
        return list.every((r, idx) => $scope.isLeadSelected(r, idx));
    };

    $scope.toggleSelectAllVisibleLeads = function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        const list = Array.isArray($scope.mobileVisibleLeads) && $scope.mobileVisibleLeads.length
            ? $scope.mobileVisibleLeads
            : (($scope.local && $scope.local.collect) || []);
        const allSelected = $scope.isAllVisibleLeadsSelected();
        if (allSelected) {
            list.forEach((r, idx) => {
                const k = $scope.getMobileLeadTrackKey(r, idx);
                delete $scope.mobileSelectedMap[k];
                delete $scope.selectedRowsByKey[k];
            });
        } else {
            list.forEach((r, idx) => {
                const k = $scope.getMobileLeadTrackKey(r, idx);
                $scope.mobileSelectedMap[k] = true;
                $scope.selectedRowsByKey[k] = r;
            });
        }
        $scope.mobileSelectionMode = $scope.getSelectedLeadsCount() > 0;
        if (dataGrid && typeof dataGrid.repaint === 'function') dataGrid.repaint();
    };

    function triggerLeadHoldSelect(row, index) {
        if (!row) return;
        longPressTriggered = true;
        $scope.safeApply(function() {
            const key = $scope.getMobileLeadTrackKey(row, index);
            const nextState = !$scope.mobileSelectedMap[key];
            if (nextState) {
                $scope.mobileSelectedMap[key] = true;
                $scope.selectedRowsByKey[key] = row;
            } else {
                delete $scope.mobileSelectedMap[key];
                delete $scope.selectedRowsByKey[key];
            }
            $scope.mobileSelectionMode = $scope.getSelectedLeadsCount() > 0;
            $scope.activeCardMenuKey = '';
            try {
                if (navigator && typeof navigator.vibrate === 'function') navigator.vibrate(28);
            } catch (_) {}
            if (dataGrid && typeof dataGrid.repaint === 'function') dataGrid.repaint();
        });
    }

    $scope.onLeadCardContextMenu = function(row, index, $event) {
        if ($event && $event.target && $event.target.closest && $event.target.closest('button, a, input, .pl-m-card-dropdown')) {
            return;
        }
        if ($event && typeof $event.preventDefault === 'function') {
            $event.preventDefault();
            $event.stopPropagation();
        }
        if (pressTimer) {
            clearTimeout(pressTimer);
            pressTimer = null;
            triggerLeadHoldSelect(row, index);
        } else if (!longPressTriggered) {
            triggerLeadHoldSelect(row, index);
        }
    };

    $scope.onLeadCardPressStart = function(row, index, $event) {
        if ($event && $event.target && $event.target.closest && $event.target.closest('button, a, input, .pl-m-card-dropdown, .pl-m-card-photos-drawer')) {
            return;
        }
        if (pressTimer) clearTimeout(pressTimer);
        longPressTriggered = false;
        const pt = ($event && (($event.touches && $event.touches[0]) || ($event.originalEvent && $event.originalEvent.touches && $event.originalEvent.touches[0]))) || $event;
        pressStartPos = pt ? { x: Number(pt.clientX) || 0, y: Number(pt.clientY) || 0 } : null;
        pressTimer = setTimeout(function() {
            pressTimer = null;
            triggerLeadHoldSelect(row, index);
        }, 350);
    };

    $scope.onLeadCardPressMove = function($event) {
        if (!pressTimer || !pressStartPos) return;
        const pt = ($event && (($event.touches && $event.touches[0]) || ($event.originalEvent && $event.originalEvent.touches && $event.originalEvent.touches[0]))) || $event;
        if (!pt) return;
        const dx = Math.abs((Number(pt.clientX) || 0) - pressStartPos.x);
        const dy = Math.abs((Number(pt.clientY) || 0) - pressStartPos.y);
        if (dx > 22 || dy > 22) {
            clearTimeout(pressTimer);
            pressTimer = null;
        }
    };

    $scope.onLeadCardPressEnd = function() {
        if (pressTimer) {
            clearTimeout(pressTimer);
            pressTimer = null;
        }
    };

    $scope.onLeadCardPressCancel = function() {
        if (pressTimer) {
            clearTimeout(pressTimer);
            pressTimer = null;
        }
    };

    $scope.toggleLeadCardMenu = function(row, index, $event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        const key = $scope.getMobileLeadTrackKey(row, index);
        $scope.activeCardMenuKey = ($scope.activeCardMenuKey === key) ? '' : key;
    };

    $scope.closeLeadCardMenu = function() {
        if ($scope.activeCardMenuKey) $scope.activeCardMenuKey = '';
    };

    document.addEventListener('click', function(ev) {
        if ($scope.activeCardMenuKey && (!ev.target || !ev.target.closest || !ev.target.closest('.pl-m-card-menu-wrap'))) {
            $scope.$evalAsync(function() { $scope.activeCardMenuKey = ''; });
        }
    });

    $scope.copyLeadSummary = function(row, $event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        $scope.activeCardMenuKey = '';
        if (!row) return;
        const lines = [
            'Business: ' + $scope.getMobileLeadTitle(row),
            'Phone: ' + ($scope.getMobileLeadPhone(row) || 'N/A'),
            'Website: ' + ($scope.getMobileLeadWebsite(row) || 'N/A'),
            'Email: ' + ($scope.getMobileLeadEmailList(row).join(', ') || 'N/A'),
            'Address: ' + ($scope.getMobileLeadLocation(row) || 'N/A'),
            'Map: ' + ($scope.getMobileLeadMapHref(row) || 'N/A')
        ];
        const photo = $scope.getMobileLeadImage(row);
        if (photo) lines.push('Photo URL: ' + photo);
        $scope.copyLeadDetailValue(lines.join('\n'), 'Lead summary', $event);
    };

    function getSelectedLeadRowsArray() {
        const selectedKeys = Object.keys($scope.mobileSelectedMap || {}).filter(k => !!$scope.mobileSelectedMap[k]);
        if (!selectedKeys.length) return [];
        const keySet = new Set(selectedKeys);
        const found = [];
        const seen = new Set();
        const allCollect = ($scope.local && Array.isArray($scope.local.collect)) ? $scope.local.collect : [];
        allCollect.forEach((r, idx) => {
            const k = $scope.getMobileLeadTrackKey(r, idx);
            if (keySet.has(k) && !seen.has(k)) {
                seen.add(k);
                found.push(r);
            }
        });
        selectedKeys.forEach(k => {
            if (!seen.has(k) && $scope.selectedRowsByKey && $scope.selectedRowsByKey[k]) {
                seen.add(k);
                found.push($scope.selectedRowsByKey[k]);
            }
        });
        return found;
    }

    async function performDeleteLeads(leadsToDelete) {
        const targetList = (Array.isArray(leadsToDelete) ? leadsToDelete : []).filter(Boolean);
        if (!targetList.length) return;
        const delKeys = new Set();
        const delCids = new Set();
        const delPlaceIds = new Set();
        targetList.forEach((r, idx) => {
            if (typeof r === 'string') {
                delKeys.add(r);
                delCids.add(r);
                return;
            }
            const k = $scope.getMobileLeadTrackKey(r, idx);
            if (k) delKeys.add(k);
            if (r.cid) delCids.add(String(r.cid).trim());
            if (r.place_id || r.placeId) delPlaceIds.add(String(r.place_id || r.placeId).trim());
        });

        const matchesTarget = (r, idx) => {
            if (!r || typeof r !== 'object') return false;
            const k = $scope.getMobileLeadTrackKey(r, idx);
            if (k && delKeys.has(k)) return true;
            if (r.cid && delCids.has(String(r.cid).trim())) return true;
            const pid = String(r.place_id || r.placeId || '').trim();
            if (pid && delPlaceIds.has(pid)) return true;
            return false;
        };

        if ($scope.local && Array.isArray($scope.local.collect)) {
            $scope.local.collect = $scope.local.collect.filter((r, idx) => !matchesTarget(r, idx));
        }

        delKeys.forEach(k => {
            if ($scope.mobileSelectedMap) delete $scope.mobileSelectedMap[k];
            if ($scope.selectedRowsByKey) delete $scope.selectedRowsByKey[k];
        });
        $scope.mobileSelectionMode = $scope.getSelectedLeadsCount() > 0;
        $scope.activeCardMenuKey = '';

        if ($scope.activeLeadDetail && matchesTarget($scope.activeLeadDetail, 0)) {
            $scope.closeMobileLeadDetail();
        }

        let newStoreTotal = ($scope.local && Array.isArray($scope.local.collect)) ? $scope.local.collect.length : 0;
        try {
            const res = await runtimeMessageAsync({ action: 'result_store_delete', rows: targetList });
            if (res && res.ok && res.result && Number.isFinite(res.result.total)) {
                newStoreTotal = res.result.total;
            }
        } catch (_) {}

        $scope.safeApply(function() {
            if ($scope.local) {
                $scope.local.resultStoreCount = newStoreTotal;
                if ($scope.local.apifyQueue && typeof $scope.local.apifyQueue === 'object') {
                    $scope.local.apifyQueue.scrapedCount = newStoreTotal;
                }
                $scope.saveLocal();
            }
            const remaining = ($scope.local && $scope.local.collect) || [];
            if (productsStore && typeof productsStore.setRows === 'function') {
                productsStore.setRows(safeCollectRows($scope.local || {}));
            }
            if (dataGrid && typeof dataGrid.refresh === 'function') {
                dataGrid.refresh();
            }
            refreshMobileLeadsView(remaining);
            refreshDashboardMetricCounts(remaining);
            const msg = '✓ Deleted ' + targetList.length + (targetList.length === 1 ? ' lead' : ' leads');
            if (typeof showTopStatusToast === 'function') showTopStatusToast(msg, 'info');
            else if ($scope.snackbar && typeof $scope.snackbar.show === 'function') $scope.snackbar.show(msg);
        });
    }

    $scope.deleteSingleLead = function(row, index, $event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        $scope.activeCardMenuKey = '';
        if (!row) return;
        performDeleteLeads([row]);
    };

    $scope.deleteSelectedLeads = function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        const selectedRows = getSelectedLeadRowsArray();
        if (!selectedRows.length) return;
        performDeleteLeads(selectedRows);
    };

    $scope.exportSelectedLeads = function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        if (!$scope.licenseActive) {
            $scope.snackbar.show("Please activate your licence first");
            return;
        }
        const selectedRows = dedupeCanonicalRows(getSelectedLeadRowsArray());
        if (!selectedRows.length) {
            $scope.download();
            return;
        }
        const sortExportColumnsPriority = (cols) => {
            const priority = ['keyword', 'location', 'company_name', 'phone_number', 'whatsapp_status', 'review', 'total_reviews', 'category', 'address', 'city', 'state', 'pincode', 'website', 'email_1', 'map_link', 'photo_url', 'photo_url_large', 'photo_urls', 'status', 'facebook', 'instagram', 'linkedin', 'twitter', 'youtube', 'place_id', 'cid', 'latitude', 'longitude', 'source', 'scraped_at'];
            const rank = k => { const idx = priority.indexOf(k); return idx >= 0 ? idx : 999; };
            return [...cols].sort((a, b) => rank(a) - rank(b));
        };
        const labels = sortExportColumnsPriority(Array.from(new Set(['keyword', 'location', ...PocketLeadsExport.fields(selectedRows, baseColumnList), 'photo_url', 'photo_url_large', 'photo_urls'])));
        const selected = {};
        labels.forEach(label => {
            if (label === 'keyword' || label === 'location' || label === 'photo_url' || label === 'photo_url_large' || label === 'photo_urls') selected[label] = true;
            else selected[label] = rememberedExportFields[label] !== false;
        });
        $scope.exportModal = {
            show: true,
            step: 'fields',
            activePreset: 'all',
            uniqueBy: '',
            loading: false,
            fields: labels,
            selected: selected,
            format: 'excel',
            rows: selectedRows,
            largeMode: false,
            rowCount: selectedRows.length
        };
    };

    if (typeof window !== 'undefined') {
        window.__plGridBridge = {
            isRowSelected: (row, key) => {
                const k = String(key || $scope.getMobileLeadTrackKey(row, 0));
                return !!($scope.mobileSelectedMap && $scope.mobileSelectedMap[k]);
            },
            getSelectedCount: () => $scope.getSelectedLeadsCount(),
            onToggleSelect: (row, key, checked) => {
                $scope.safeApply(() => {
                    const k = String(key || $scope.getMobileLeadTrackKey(row, 0));
                    if (checked) {
                        $scope.mobileSelectedMap[k] = true;
                        $scope.selectedRowsByKey[k] = row;
                    } else {
                        delete $scope.mobileSelectedMap[k];
                        delete $scope.selectedRowsByKey[k];
                    }
                    $scope.mobileSelectionMode = $scope.getSelectedLeadsCount() > 0;
                });
            },
            onToggleSelectMany: (rowsList, checked) => {
                $scope.safeApply(() => {
                    (rowsList || []).forEach((r, i) => {
                        const k = $scope.getMobileLeadTrackKey(r, i);
                        if (checked) {
                            $scope.mobileSelectedMap[k] = true;
                            $scope.selectedRowsByKey[k] = r;
                        } else {
                            delete $scope.mobileSelectedMap[k];
                            delete $scope.selectedRowsByKey[k];
                        }
                    });
                    $scope.mobileSelectionMode = $scope.getSelectedLeadsCount() > 0;
                });
            },
            onDeleteRow: (row) => {
                $scope.deleteSingleLead(row, 0);
            },
            onDeleteSelected: () => {
                $scope.deleteSelectedLeads();
            },
            onExportSelected: () => {
                $scope.exportSelectedLeads();
            },
            onClearSelection: () => {
                $scope.clearLeadSelection();
            },
            onOpenRowDetail: (row) => {
                $scope.safeApply(() => {
                    $scope.openMobileLeadDetail(row);
                });
            }
        };
    }

    $scope.getMobileLeadLocation = function(row) {
        if (!row || typeof row !== 'object') return 'Location not available';
        const city = String(row.city || '').trim();
        const loc = String(row.location || '').trim();
        const addr = String(row.address || row.formattedAddress || row.fullAddress || '').trim();
        if (addr) {
            const parts = addr.split(',').map(s => s.trim()).filter(Boolean);
            if (parts.length >= 2) {
                const tail = parts.slice(-3, -1).join(', ') || parts.slice(0, 2).join(', ');
                if (tail.length <= 42) return tail;
            }
            return addr.length > 44 ? (addr.slice(0, 42) + '…') : addr;
        }
        if (loc && city && loc.toLowerCase() !== city.toLowerCase()) return loc + ', ' + city;
        return city || loc || 'Location not listed';
    };

    $scope.getMobileLeadPhone = function(row) {
        if (!row || typeof row !== 'object') return '';
        const raw = String(rowPhoneValue(row) || '').trim();
        return raw;
    };

    $scope.getMobileLeadWebsite = function(row) {
        if (!row || typeof row !== 'object') return '';
        const raw = String(row.website || row.websiteUrl || row.url || '').trim();
        if (!raw || /^(no website|n\/a|—|-)$/i.test(raw)) return '';
        return raw.replace(/^https?:\/\//i, '').replace(/\/+$/, '');
    };

    $scope.getMobileLeadWebsiteHref = function(row) {
        if (!row || typeof row !== 'object') return '#';
        const raw = String(row.website || row.websiteUrl || row.url || '').trim();
        if (!raw) return '#';
        return /^https?:\/\//i.test(raw) ? raw : ('https://' + raw);
    };

    $scope.getMobileLeadWaState = function(row) {
        if (!row || typeof row !== 'object') return 'unchecked';
        const st = String(row.whatsapp_status || row.wa_status || '').trim().toLowerCase();
        if (!st) return 'unchecked';
        if (/^(available|valid|verified|yes|true|registered|active|on whatsapp)$/.test(st)) return 'verified';
        if (/^(not available|not_available|invalid|not found|not_found|no|false|unregistered|failed|no result|cancelled)$/.test(st)) return 'not_found';
        if (/checking|queued|pending|started|running|api/.test(st)) return 'checking';
        return 'unchecked';
    };

    $scope.getMobileLeadWaLabel = function(row) {
        const state = $scope.getMobileLeadWaState(row);
        if (state === 'verified') return 'WA Valid';
        if (state === 'not_found') return 'WA Invalid';
        if (state === 'checking') return 'Checking WA...';
        return 'WA Unchecked';
    };

    $scope.getMobileLeadMapHref = function(row) {
        if (!row || typeof row !== 'object') return '';
        return resolveLeadProfileMapsUrl(row) || '';
    };

    $scope.getMobileLeadWhatsappHref = function(row) {
        const phone = $scope.getMobileLeadPhone(row);
        if (!phone) return '';
        const digits = String(phone).replace(/\D+/g, '').replace(/^0+/, '');
        if (!digits || digits.length < 8) return '';
        return 'https://wa.me/' + digits;
    };

    $scope.getMobileLeadEmailList = function(row) {
        if (!row || typeof row !== 'object') return [];
        const found = [];
        ['email_1', 'email_2', 'email_3', 'email', 'emailAddress', 'emails'].forEach(k => {
            const val = String(row[k] || '').trim();
            if (!val || /^(no email|can't access|blacklisted)/i.test(val)) return;
            val.split(/[;,\s]+/).forEach(part => {
                const clean = part.trim().toLowerCase().replace(/[.,;:]+$/, '');
                if (clean.includes('@') && clean.includes('.') && !found.includes(clean)) {
                    found.push(clean);
                }
            });
        });
        return found;
    };

    $scope.getMobileLeadEmailCount = function(row) {
        return $scope.getMobileLeadEmailList(row).length;
    };

    $scope.getMobileLeadEmailLabel = function(row) {
        const count = $scope.getMobileLeadEmailCount(row);
        if (count > 0) return count + (count === 1 ? ' Email' : ' Emails');
        const raw = String(row && (row.email_1 || row.email) || '').trim();
        if (/^no email found$/i.test(raw)) return 'No Email';
        if (/^can't access/i.test(raw)) return 'Site Offline';
        return '0 Emails';
    };

    $scope.getMobileLeadEmailsTooltip = function(row) {
        if (!row || typeof row !== 'object') return 'No emails extracted yet';
        const list = $scope.getMobileLeadEmailList(row);
        if (list.length) return list.join(', ');
        const em = String(row.email_1 || row.email || '').trim();
        return em || 'Run Email / Social Scrape to extract emails';
    };

    const SOCIAL_META_MAP = {
        facebook: { label: 'Facebook', color: '#1877F2' },
        instagram: { label: 'Instagram', color: '#E4405F' },
        linkedin: { label: 'LinkedIn', color: '#0A66C2' },
        twitter: { label: 'X / Twitter', color: '#1DA1F2' },
        youtube: { label: 'YouTube', color: '#FF0000' }
    };

    $scope.getMobileLeadSocialList = function(row) {
        if (!row || typeof row !== 'object') return [];
        const items = [];
        const seen = new Set();
        ['facebook', 'instagram', 'linkedin', 'twitter', 'youtube'].forEach(k => {
            const val = String(row[k] || '').trim();
            if (!val || /^(none|n\/a|—|-)$/i.test(val)) return;
            val.split(/[;,\s]+/).forEach(part => {
                let clean = part.trim().replace(/["'<>\\),;]+$/, '');
                if (!clean || clean.length < 4) return;
                if (!/^https?:\/\//i.test(clean)) clean = 'https://' + clean.replace(/^\/+/, '');
                const key = k + ':' + clean.toLowerCase();
                if (seen.has(key)) return;
                seen.add(key);
                let handle = clean.replace(/^https?:\/\/(?:www\.|m\.)?/i, '').replace(/\/+$/, '');
                if (handle.length > 36) handle = handle.slice(0, 34) + '…';
                items.push({
                    key: k,
                    label: (SOCIAL_META_MAP[k] && SOCIAL_META_MAP[k].label) || k,
                    url: clean,
                    handle: handle
                });
            });
        });
        return items;
    };

    $scope.getMobileLeadSocialCount = function(row) {
        return $scope.getMobileLeadSocialList(row).length;
    };

    $scope.getMobileLeadSocialLabel = function(row) {
        const count = $scope.getMobileLeadSocialCount(row);
        return count + ' Social';
    };

    $scope.activeLeadDetail = null;
    $scope.activeLeadDetailVm = null;
    $scope.singleLeadScraping = false;

    function buildMobileLeadDetailVm(row) {
        if (!row || typeof row !== 'object') return null;
        normalizeDashboardRow(row);
        const phone = $scope.getMobileLeadPhone(row);
        const website = $scope.getMobileLeadWebsite(row);
        const websiteHref = website ? $scope.getMobileLeadWebsiteHref(row) : '';
        const mapHref = $scope.getMobileLeadMapHref(row);
        const whatsappHref = $scope.getMobileLeadWhatsappHref(row);
        const emails = $scope.getMobileLeadEmailList(row);
        const socials = $scope.getMobileLeadSocialList(row);
        const rawEmailField = String(row.email_1 || row.email || '').trim();
        let emailStatus = '';
        if (!emails.length) {
            if (/^no email found$/i.test(rawEmailField)) emailStatus = 'No email listed on business website';
            else if (/^can't access/i.test(rawEmailField)) emailStatus = 'Website could not be reached';
            else if (!website) emailStatus = 'No business website available to extract email';
            else emailStatus = 'Not extracted yet — tap "Extract Email & Social" below';
        }
        const fullAddrParts = [
            row.address || row.formattedAddress || row.fullAddress,
            row.city,
            row.state,
            row.pincode,
            row.country
        ].map(x => String(x || '').trim()).filter(Boolean);
        let fullAddress = fullAddrParts[0] || row.location || 'Address not listed';
        if (fullAddress && row.pincode && !fullAddress.includes(String(row.pincode))) {
            fullAddress += ', ' + row.pincode;
        }
        return {
            title: $scope.getMobileLeadTitle(row),
            initial: $scope.getMobileLeadInitial(row),
            avatarBg: $scope.getMobileLeadAvatarBg(row),
            image: $scope.getMobileLeadImage(row),
            category: String(row.category || row.type || row.categories || '').trim(),
            rating: String(row.review || row.rating || '').trim(),
            totalReviews: String(row.total_reviews || row.reviewCount || '').trim(),
            status: String(row.status || '').trim(),
            fullAddress: fullAddress,
            phone: phone,
            whatsappHref: whatsappHref,
            waState: $scope.getMobileLeadWaState(row),
            waLabel: $scope.getMobileLeadWaLabel(row),
            website: website,
            websiteHref: websiteHref,
            mapHref: mapHref,
            emails: emails,
            emailStatus: emailStatus,
            socials: socials,
            photosSample: $scope.getLeadPhotosSample(row).slice(0, 5),
            allPhotoUrls: $scope.getLeadAllPhotoUrls(row).slice(0, 5),
            restPhotoUrls: $scope.getLeadRestPhotoUrls(row).slice(0, 5),
            statusLabel: (function() {
                const st = String(row.status || row.current_status || '').trim();
                if (!st || /^unknown$/i.test(st)) return '';
                return st;
            })(),
            isOpen: /open/i.test(String(row.status || row.current_status || '')) && !/closed/i.test(String(row.status || row.current_status || '')),
            isClosed: /closed/i.test(String(row.status || row.current_status || '')),
            openingHoursList: (function() {
                const raw = row.opening_hours_raw || row.opening_hours || '';
                if (!raw) return [];
                if (Array.isArray(raw)) {
                    return raw.map(item => {
                        if (!item) return null;
                        if (typeof item === 'string') return { day: '', hours: item.trim() };
                        const d = String(item.day || item.name || item.weekday || '').trim();
                        const h = Array.isArray(item.hours) ? item.hours.join(', ') : String(item.hours || item.time || item.value || '').trim();
                        return (d || h) ? { day: d, hours: h } : null;
                    }).filter(Boolean);
                }
                if (typeof raw === 'string' && raw.trim()) {
                    return raw.split(/\s*\|\s*|\n+/).map(part => {
                        const idx = part.indexOf(':');
                        if (idx > 0 && idx < 15) {
                            return { day: part.slice(0, idx).trim(), hours: part.slice(idx + 1).trim() };
                        }
                        return { day: '', hours: part.trim() };
                    }).filter(x => x.hours);
                }
                return [];
            })(),
            source: String(row.source || '').trim()
        };
    }

    $scope.openMobileLeadDetail = function(row, $event, index) {
        if (longPressTriggered) {
            longPressTriggered = false;
            return;
        }
        if ($event) {
            const tag = ($event.target && $event.target.tagName) ? $event.target.tagName.toLowerCase() : '';
            if (tag === 'input' || tag === 'label' || tag === 'a' || ($event.target && $event.target.closest && $event.target.closest('a, label, input, button, .pl-m-card-menu-wrap, .pl-m-card-photos-drawer'))) {
                return;
            }
        }
        if (!row || typeof row !== 'object') return;
        if ($scope.mobileSelectionMode || $scope.getSelectedLeadsCount() > 0) {
            $scope.toggleLeadSelection(row, index || 0, $event);
            return;
        }
        $scope.activeLeadDetail = row;
        $scope.activeLeadDetailVm = buildMobileLeadDetailVm(row);
        if ($scope.getLeadPhotosSample(row).length <= 1) {
            void enrichLeadPhotosFromMaps(row, true);
        }
    };

    $scope.closeMobileLeadDetail = function() {
        $scope.activeLeadDetail = null;
        $scope.activeLeadDetailVm = null;
    };

    $scope.copyLeadDetailValue = function(value, label, $event) {
        if ($event && typeof $event.stopPropagation === 'function') $event.stopPropagation();
        const text = String(value || '').trim();
        if (!text) return;
        const notify = () => {
            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                $scope.snackbar.show((label || 'Value') + ' copied to clipboard');
            }
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(notify).catch(() => {
                apiLiveCopyPlainText(text).then(notify);
            });
        } else {
            apiLiveCopyPlainText(text).then(notify);
        }
    };

    $scope.scrapeSingleLeadEmail = async function(row, $event) {
        if ($event && typeof $event.stopPropagation === 'function') $event.stopPropagation();
        const target = row || $scope.activeLeadDetail;
        if (!target || !target.website || $scope.singleLeadScraping) return;
        $scope.singleLeadScraping = true;
        try {
            const home = canonicalWebsiteUrl(target.website);
            if (home) websiteScrapeCache.delete(home);
            const token = emailRunToken;
            const res = await scrapeWebsiteEmails(target.website, token);
            if (res && !res.cancelled) {
                target.email_1 = res.value || 'No Email found';
                if (res.socials && typeof res.socials === 'object') {
                    ['facebook', 'instagram', 'linkedin', 'twitter', 'youtube'].forEach(k => {
                        if (res.socials[k]) target[k] = res.socials[k];
                    });
                }
                normalizeDashboardRow(target);
                syncEnrichedRowToLiveCollections(target, $scope.local && $scope.local.collect);
                try {
                    await runtimeMessageAsync({ action: 'result_store_upsert', rows: [target] });
                } catch (e) {}
            }
        } catch (e) {
            target.email_1 = "Can't Access Website";
        } finally {
            $scope.$evalAsync(() => {
                $scope.singleLeadScraping = false;
                if ($scope.activeLeadDetail) {
                    $scope.activeLeadDetailVm = buildMobileLeadDetailVm($scope.activeLeadDetail);
                }
                refreshDashboardMetricCounts($scope.local && $scope.local.collect);
                refreshMobileLeadsView($scope.local && $scope.local.collect);
                $scope.saveLocal();
            });
        }
    };


    /* --------------------------------------------------------------------
     * Scraping History
     * Stores a compact snapshot of each completed/stopped scraping session
     * in chrome.storage via the existing local model. The History button
     * opens a modal with View, CSV, Excel and Delete actions.
     */
    $scope.historyModal = {
        show: false,
        search: '',
        fromDate: '',
        toDate: '',
        viewSession: null,
        viewPage: 1,
        viewPageSize: 25
    };

    function clonePlain(obj) {
        try { return JSON.parse(JSON.stringify(obj || null)); } catch (e) { return obj; }
    }

    function normaliseDateInput(value, endOfDay) {
        if (!value) return null;
        let d = value instanceof Date ? new Date(value.getTime()) : new Date(String(value));
        if (!isNaN(d.getTime())) {
            if (endOfDay) d.setHours(23, 59, 59, 999);
            else d.setHours(0, 0, 0, 0);
            return d.getTime();
        }
        const m = String(value).trim().match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/);
        if (m) {
            d = new Date(parseInt(m[3], 10), parseInt(m[2], 10) - 1, parseInt(m[1], 10));
            if (endOfDay) d.setHours(23, 59, 59, 999);
            return d.getTime();
        }
        return null;
    }

    function historyFileDate(session) {
        const d = new Date(session && (session.timestamp || session.finishedAt || session.startedAt) || Date.now());
        const pad = n => String(n).padStart(2, '0');
        return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + '_' + pad(d.getHours()) + pad(d.getMinutes());
    }

    function showTopStatusToast(message, tone) {
        try {
            if (typeof document === 'undefined' || !document.body || !message) return;
            let pill = document.getElementById('pl-top-status-pill-toast');
            if (pill) pill.remove();
            pill = document.createElement('div');
            pill.id = 'pl-top-status-pill-toast';
            const isWarn = tone === 'warn' || /please|warn|pause|stop|fail|error|unable/i.test(String(message));
            const borderCol = isWarn ? 'rgba(245, 158, 11, 0.55)' : 'rgba(16, 185, 129, 0.55)';
            const dotCol = isWarn ? '#FBBF24' : '#10B981';
            pill.style.cssText = 'position:fixed;top:12px;left:50%;transform:translate(-50%,-140%);z-index:2147483646;max-width:92vw;padding:8px 15px;border-radius:999px;background:rgba(11,18,32,0.96);border:1px solid ' + borderCol + ';box-shadow:0 10px 28px rgba(0,0,0,0.65);color:#F8FAFC;font-family:Inter,system-ui,sans-serif;font-size:12.5px;font-weight:700;display:inline-flex;align-items:center;gap:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none;transition:transform 0.22s cubic-bezier(0.22,1,0.36,1),opacity 0.22s ease;opacity:0;';
            pill.innerHTML = '<span style="width:8px;height:8px;border-radius:50%;background:' + dotCol + ';flex-shrink:0;box-shadow:0 0 8px ' + dotCol + ';"></span><span style="overflow:hidden;text-overflow:ellipsis;">' + String(message) + '</span>';
            document.body.appendChild(pill);
            requestAnimationFrame(function() {
                requestAnimationFrame(function() {
                    pill.style.transform = 'translate(-50%,0)';
                    pill.style.opacity = '1';
                });
            });
            setTimeout(function() {
                if (pill && pill.parentNode) {
                    pill.style.transform = 'translate(-50%,-140%)';
                    pill.style.opacity = '0';
                    setTimeout(function() { if (pill && pill.parentNode) pill.remove(); }, 240);
                }
            }, 2600);
        } catch (_) {}
    }
    if (typeof window !== 'undefined') {
        window.showTopStatusToast = showTopStatusToast;
    }

    function saveBlobDownload(blob, filename) {
        if (typeof window !== 'undefined' && typeof window.__plHandleDirectDownloadAndShare === 'function' && (window.AndroidChromeBridge || window.__plInProcessAndroid)) {
            try {
                window.__plHandleDirectDownloadAndShare(blob, filename);
                return;
            } catch (directErr) {
                console.warn('Direct Android download handler fallback:', directErr);
            }
        }
        const a = document.createElement('a');
        document.body.appendChild(a);
        a.style = 'display:none';
        const url = window.URL.createObjectURL(blob);
        a.href = url;
        a.download = filename;
        a.click();
        if (!(typeof window !== 'undefined' && window.__plIsDesktopApp)) {
            showTopStatusToast('⬇ File downloaded: ' + String(filename || 'Export'), 'success');
        }
        setTimeout(() => {
            try { window.URL.revokeObjectURL(url); } catch (e) {}
            try { a.remove(); } catch (e) {}
        }, 1500);
    }

    const EMPTY_HISTORY_ROWS = Object.freeze([]);
    function getRowsFromHistory(session) {
        return (session && Array.isArray(session.rows)) ? session.rows : EMPTY_HISTORY_ROWS;
    }

    function openHistoryIdbDirect() {
        return new Promise(resolve => {
            try {
                if (typeof window !== 'undefined' && window.PocketLeadsApifyFlow && window.PocketLeadsApifyFlow.ResultStore && typeof window.PocketLeadsApifyFlow.ResultStore.open === 'function') {
                    window.PocketLeadsApifyFlow.ResultStore.open().then(resolve).catch(() => resolve(null));
                    return;
                }
                if (typeof indexedDB === 'undefined') return resolve(null);
                const req = indexedDB.open('PocketLeadsDB', 4);
                req.onupgradeneeded = event => {
                    try {
                        const db = event.target.result;
                        if (!db.objectStoreNames.contains('results')) {
                            const store = db.createObjectStore('results', { keyPath: '_key' });
                            store.createIndex('order', '_order', { unique: false });
                        }
                        if (!db.objectStoreNames.contains('jobs')) {
                            const jobs = db.createObjectStore('jobs', { keyPath: 'id' });
                            jobs.createIndex('runId', 'runId', { unique: false });
                            jobs.createIndex('status', 'status', { unique: false });
                        }
                        if (!db.objectStoreNames.contains('history')) {
                            const history = db.createObjectStore('history', { keyPath: 'id' });
                            history.createIndex('timestamp', 'timestamp', { unique: false });
                        }
                        if (!db.objectStoreNames.contains('history_rows')) {
                            db.createObjectStore('history_rows', { keyPath: 'id' });
                        }
                    } catch (_) {}
                };
                req.onsuccess = () => resolve(req.result || null);
                req.onerror = () => resolve(null);
            } catch (_) { resolve(null); }
        });
    }

    async function directIdbPutHistorySession(fullSession) {
        try {
            if (!fullSession || !fullSession.id) return false;
            const db = await openHistoryIdbDirect();
            if (!db) return false;
            const hasHist = db.objectStoreNames.contains('history');
            const hasRows = db.objectStoreNames.contains('history_rows');
            if (!hasHist) return false;
            return await new Promise(resolve => {
                try {
                    const stores = hasRows ? ['history', 'history_rows'] : ['history'];
                    const tx = db.transaction(stores, 'readwrite');
                    const rows = Array.isArray(fullSession.rows) ? fullSession.rows : [];
                    const meta = Object.assign({}, fullSession);
                    if (hasRows) {
                        delete meta.rows;
                        meta.hasRows = rows.length > 0;
                        meta.rowCount = Math.max(0, parseInt(fullSession.rowCount || fullSession.leadCount, 10) || rows.length);
                        meta.leadCount = Math.max(0, parseInt(fullSession.leadCount, 10) || meta.rowCount);
                        tx.objectStore('history').put(meta);
                        tx.objectStore('history_rows').put({ id: String(fullSession.id), rows: rows, updatedAt: new Date().toISOString() });
                    } else {
                        tx.objectStore('history').put(fullSession);
                    }
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => resolve(false);
                } catch (_) { resolve(false); }
            });
        } catch (_) { return false; }
    }

    async function directIdbGetAllHistorySessions() {
        try {
            const db = await openHistoryIdbDirect();
            if (!db || !db.objectStoreNames.contains('history')) return [];
            const hasRows = db.objectStoreNames.contains('history_rows');
            return await new Promise(resolve => {
                try {
                    const stores = hasRows ? ['history', 'history_rows'] : ['history'];
                    const tx = db.transaction(stores, 'readonly');
                    const mReq = tx.objectStore('history').getAll();
                    const rReq = hasRows ? tx.objectStore('history_rows').getAll() : null;
                    tx.oncomplete = () => {
                        const metas = Array.isArray(mReq.result) ? mReq.result : [];
                        const rowList = (rReq && Array.isArray(rReq.result)) ? rReq.result : [];
                        const rowsById = new Map();
                        rowList.forEach(item => {
                            if (item && item.id && Array.isArray(item.rows)) {
                                rowsById.set(String(item.id), item.rows);
                            }
                        });
                        const out = metas.map(m => {
                            if (!m || !m.id) return null;
                            const id = String(m.id);
                            const r = rowsById.get(id) || (Array.isArray(m.rows) ? m.rows : []);
                            const cnt = Math.max(parseInt(m.leadCount, 10) || 0, parseInt(m.rowCount, 10) || 0, r.length);
                            return Object.assign({}, m, { rows: r, leadCount: cnt, rowCount: cnt, isCompactPreview: false });
                        }).filter(Boolean);
                        resolve(out);
                    };
                    tx.onerror = () => resolve([]);
                } catch (_) { resolve([]); }
            });
        } catch (_) { return []; }
    }

    async function directIdbGetHistorySession(id) {
        try {
            if (!id) return null;
            const db = await openHistoryIdbDirect();
            if (!db) return null;
            const hasHist = db.objectStoreNames.contains('history');
            const hasRows = db.objectStoreNames.contains('history_rows');
            if (!hasHist) return null;
            return await new Promise(resolve => {
                try {
                    const stores = hasRows ? ['history', 'history_rows'] : ['history'];
                    const tx = db.transaction(stores, 'readonly');
                    const mReq = tx.objectStore('history').get(String(id));
                    const rReq = hasRows ? tx.objectStore('history_rows').get(String(id)) : null;
                    tx.oncomplete = () => {
                        const meta = mReq.result;
                        const rowRec = rReq ? rReq.result : null;
                        const rows = (rowRec && Array.isArray(rowRec.rows) && rowRec.rows.length)
                            ? rowRec.rows
                            : ((meta && Array.isArray(meta.rows)) ? meta.rows : []);
                        if (!meta && !rows.length) return resolve(null);
                        resolve(Object.assign({}, meta || { id: String(id) }, { rows }));
                    };
                    tx.onerror = () => resolve(null);
                } catch (_) { resolve(null); }
            });
        } catch (_) { return null; }
    }

    async function directIdbGetResultsFallback(expectedCount) {
        try {
            const db = await openHistoryIdbDirect();
            if (!db || !db.objectStoreNames.contains('results')) return [];
            return await new Promise(resolve => {
                try {
                    const tx = db.transaction(['results'], 'readonly');
                    const req = tx.objectStore('results').getAll();
                    req.onsuccess = () => {
                        const all = Array.isArray(req.result) ? req.result : [];
                        resolve(expectedCount > 0 ? all.slice(0, expectedCount) : all);
                    };
                    req.onerror = () => resolve([]);
                } catch (_) { resolve([]); }
            });
        } catch (_) { return []; }
    }

    async function loadHistorySessionRows(session) {
        if (!session || !session.id) return session || null;
        const expected = Math.max(0, parseInt(session.leadCount || session.rowCount, 10) || 0);
        const existingRows = Array.isArray(session.rows) ? session.rows : [];
        if (existingRows.length > 0 && !session.isCompactPreview && (expected === 0 || existingRows.length >= expected)) {
            return session;
        }
        // 1. Try direct IndexedDB history_rows read first (fastest, works in-process & offline)
        const directSession = await directIdbGetHistorySession(session.id);
        if (directSession && Array.isArray(directSession.rows) && directSession.rows.length > existingRows.length) {
            session.rows = directSession.rows;
            session.isCompactPreview = false;
            session.leadCount = Math.max(expected, directSession.rows.length);
            session.rowCount = session.leadCount;
            return Object.assign({}, session, directSession, { rows: directSession.rows, leadCount: session.leadCount, rowCount: session.rowCount, isCompactPreview: false });
        }
        // 2. Try background HistoryStore message
        const response = await runtimeMessageAsync({ action: 'scrape_history_get', id: session.id });
        if (response && response.session && Array.isArray(response.session.rows) && response.session.rows.length > existingRows.length) {
            session.rows = response.session.rows;
            session.isCompactPreview = false;
            session.leadCount = Math.max(expected, response.session.rows.length);
            session.rowCount = session.leadCount;
            return Object.assign({}, session, response.session, { rows: response.session.rows, leadCount: session.leadCount, rowCount: session.rowCount, isCompactPreview: false });
        }
        // 3. Fallback to canonical ResultStore or live $scope.local.collect if this is the active/recent session
        const idbResults = await directIdbGetResultsFallback(0);
        if (idbResults.length > existingRows.length && (expected === 0 || idbResults.length >= existingRows.length)) {
            session.rows = idbResults;
            session.isCompactPreview = false;
            session.leadCount = Math.max(expected, idbResults.length);
            session.rowCount = session.leadCount;
            void directIdbPutHistorySession(session);
            return session;
        }
        const localCollect = Array.isArray($scope.local && $scope.local.collect) ? $scope.local.collect : [];
        if (localCollect.length > existingRows.length) {
            session.rows = clonePlain(localCollect);
            session.isCompactPreview = false;
            session.leadCount = Math.max(expected, localCollect.length);
            session.rowCount = session.leadCount;
            void directIdbPutHistorySession(session);
            return session;
        }
        return session;
    }

    function buildCsvFromRows(rows, selectedLabels) {
        rows = Array.isArray(rows) ? rows : [];
        const labels = Array.isArray(selectedLabels) && selectedLabels.length ? selectedLabels : refreshColumnList(rows);
        let CSV = '\uFEFF';
        if (labels.length) {
            CSV += labels.map(label => {
                let header;
                try { header = (typeof FoxCommon !== 'undefined' && FoxCommon.getKeyFromMap) ? FoxCommon.getKeyFromMap(label) : undefined; } catch (e) { header = undefined; }
                if (!header || header === label) header = FoxCommon.downloadAs.keyToColumnHeader(label);
                return '"' + String(header).replace(/"/g, '""') + '"';
            }).join(',') + '\r\n';
        }
        rows.forEach(row => {
            CSV += labels.map(label => {
                let value = exportValueFor(row, label);
                if (label === 'map_link' && value) value = resolveLeadProfileMapsUrl(row) || value;
                return '"' + String(value).replace(/"/g, '""') + '"';
            }).join(',') + '\r\n';
        });
        return CSV;
    }

    function buildExcelHtmlFromRows(rows, selectedLabels) {
        rows = Array.isArray(rows) ? rows : [];
        const labels = Array.isArray(selectedLabels) && selectedLabels.length ? selectedLabels : refreshColumnList(rows);
        const esc = value => String(value === null || typeof value === 'undefined' ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        let html = '<html><head><meta charset="utf-8"></head><body><table border="1"><thead><tr>';
        labels.forEach(label => {
            let header;
            try { header = (typeof FoxCommon !== 'undefined' && FoxCommon.getKeyFromMap) ? FoxCommon.getKeyFromMap(label) : undefined; } catch (e) { header = undefined; }
            if (!header || header === label) header = FoxCommon.downloadAs.keyToColumnHeader(label);
            html += '<th>' + esc(header) + '</th>';
        });
        html += '</tr></thead><tbody>';
        rows.forEach(row => {
            html += '<tr>';
            labels.forEach(label => {
                const value = exportValueFor(row, label);
                if (label === 'map_link' && value) {
                    html += '<td><a href="' + esc(value) + '">' + esc(value) + '</a></td>';
                } else {
                    html += '<td>' + esc(value) + '</td>';
                }
            });
            html += '</tr>';
        });
        html += '</tbody></table></body></html>';
        return html;
    }

    function buildTrueXlsxBlob(rows, selectedLabels) {
        rows = Array.isArray(rows) ? rows : [];
        const labels = Array.isArray(selectedLabels) && selectedLabels.length ? selectedLabels : refreshColumnList(rows);
        const headerFor = label => {
            if (typeof $scope.getExportFieldLabel === 'function') return $scope.getExportFieldLabel(label);
            return String(label || '').replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
        };
        const escXml = str => String(str == null ? '' : str)
            .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&apos;');
        const colName = idx => {
            let s = '';
            let n = idx + 1;
            while (n > 0) {
                const rem = (n - 1) % 26;
                s = String.fromCharCode(65 + rem) + s;
                n = Math.floor((n - 1) / 26);
            }
            return s;
        };
        const colsXml = labels.map((l, i) => {
            const w = (l === 'company_name' || l === 'address' || l === 'website' || l === 'map_link') ? 32 : 18;
            return '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + w + '" customWidth="1"/>';
        }).join('');
        let sheetRowsXml = '<row r="1" ht="24" customHeight="1">' +
            labels.map((l, cIdx) => {
                const ref = colName(cIdx) + '1';
                return '<c r="' + ref + '" t="inlineStr" s="1"><is><t>' + escXml(headerFor(l)) + '</t></is></c>';
            }).join('') +
            '</row>';
        for (let rIdx = 0; rIdx < rows.length; rIdx++) {
            const row = rows[rIdx];
            const rowNum = rIdx + 2;
            let cells = '';
            for (let cIdx = 0; cIdx < labels.length; cIdx++) {
                const label = labels[cIdx];
                let rawVal = exportValueFor(row, label);
                if (label === 'map_link' && rawVal) rawVal = resolveLeadProfileMapsUrl(row) || rawVal;
                const strVal = rawVal == null ? '' : String(rawVal);
                const ref = colName(cIdx) + rowNum;
                if ((label === 'review' || label === 'total_reviews' || label === 'latitude' || label === 'longitude') &&
                    strVal !== '' && /^-?\d+(\.\d+)?$/.test(strVal.trim())) {
                    cells += '<c r="' + ref + '"><v>' + strVal.trim() + '</v></c>';
                } else {
                    cells += '<c r="' + ref + '" t="inlineStr"><is><t>' + escXml(strVal) + '</t></is></c>';
                }
            }
            sheetRowsXml += '<row r="' + rowNum + '">' + cells + '</row>';
        }
        const files = [
            {
                name: '[Content_Types].xml',
                content: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
                    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
                    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
                    '<Default Extension="xml" ContentType="application/xml"/>' +
                    '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
                    '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' +
                    '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
                    '</Types>'
            },
            {
                name: '_rels/.rels',
                content: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
                    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
                    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
                    '</Relationships>'
            },
            {
                name: 'xl/workbook.xml',
                content: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
                    '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
                    '<sheets><sheet name="Extracted Leads" sheetId="1" r:id="rId1"/></sheets>' +
                    '</workbook>'
            },
            {
                name: 'xl/_rels/workbook.xml.rels',
                content: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
                    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
                    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>' +
                    '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' +
                    '</Relationships>'
            },
            {
                name: 'xl/styles.xml',
                content: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
                    '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
                    '<fonts count="2">' +
                    '<font><sz val="11"/><name val="Calibri"/></font>' +
                    '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>' +
                    '</fonts>' +
                    '<fills count="3">' +
                    '<fill><patternFill patternType="none"/></fill>' +
                    '<fill><patternFill patternType="gray125"/></fill>' +
                    '<fill><patternFill patternType="solid"><fgColor rgb="FF1E293B"/><bgColor indexed="64"/></patternFill></fill>' +
                    '</fills>' +
                    '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>' +
                    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
                    '<cellXfs count="2">' +
                    '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' +
                    '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>' +
                    '</cellXfs>' +
                    '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' +
                    '</styleSheet>'
            },
            {
                name: 'xl/worksheets/sheet1.xml',
                content: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
                    '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
                    (colsXml ? '<cols>' + colsXml + '</cols>' : '') +
                    '<sheetData>' + sheetRowsXml + '</sheetData>' +
                    '</worksheet>'
            }
        ];
        const enc = new TextEncoder();
        const crcTable = new Uint32Array(256);
        for (let n = 0; n < 256; n++) {
            let c = n;
            for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
            crcTable[n] = c >>> 0;
        }
        const crc32 = bytes => {
            let c = 0xFFFFFFFF;
            for (let i = 0; i < bytes.length; i++) c = crcTable[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
            return (c ^ 0xFFFFFFFF) >>> 0;
        };
        const localChunks = [];
        const centralChunks = [];
        let offset = 0;
        for (const f of files) {
            const nameBytes = enc.encode(f.name);
            const dataBytes = enc.encode(f.content);
            const crc = crc32(dataBytes);
            const lh = new Uint8Array(30 + nameBytes.length);
            const lhv = new DataView(lh.buffer);
            lhv.setUint32(0, 0x04034b50, true);
            lhv.setUint16(4, 20, true);
            lhv.setUint16(6, 0, true);
            lhv.setUint16(8, 0, true);
            lhv.setUint16(10, 0, true);
            lhv.setUint16(12, 0x5421, true);
            lhv.setUint32(14, crc, true);
            lhv.setUint32(18, dataBytes.length, true);
            lhv.setUint32(22, dataBytes.length, true);
            lhv.setUint16(26, nameBytes.length, true);
            lhv.setUint16(28, 0, true);
            lh.set(nameBytes, 30);
            localChunks.push(lh, dataBytes);
            const ch = new Uint8Array(46 + nameBytes.length);
            const chv = new DataView(ch.buffer);
            chv.setUint32(0, 0x02014b50, true);
            chv.setUint16(4, 20, true);
            chv.setUint16(6, 20, true);
            chv.setUint16(8, 0, true);
            chv.setUint16(10, 0, true);
            chv.setUint16(12, 0, true);
            chv.setUint16(14, 0x5421, true);
            chv.setUint32(16, crc, true);
            chv.setUint32(20, dataBytes.length, true);
            chv.setUint32(24, dataBytes.length, true);
            chv.setUint16(28, nameBytes.length, true);
            chv.setUint16(30, 0, true);
            chv.setUint16(32, 0, true);
            chv.setUint16(34, 0, true);
            chv.setUint16(36, 0, true);
            chv.setUint32(38, 0, true);
            chv.setUint32(42, offset, true);
            ch.set(nameBytes, 46);
            centralChunks.push(ch);
            offset += lh.length + dataBytes.length;
        }
        let centralSize = 0;
        for (const c of centralChunks) centralSize += c.length;
        const eocd = new Uint8Array(22);
        const eocdv = new DataView(eocd.buffer);
        eocdv.setUint32(0, 0x06054b50, true);
        eocdv.setUint16(4, 0, true);
        eocdv.setUint16(6, 0, true);
        eocdv.setUint16(8, files.length, true);
        eocdv.setUint16(10, files.length, true);
        eocdv.setUint32(12, centralSize, true);
        eocdv.setUint32(16, offset, true);
        eocdv.setUint16(20, 0, true);
        return new Blob([...localChunks, ...centralChunks, eocd], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        });
    }

    function countSessionPhonesAndWa(rows) {
        if (!Array.isArray(rows) || !rows.length) return { phoneCount: 0, waAvailableCount: 0 };
        let phoneCount = 0;
        let waAvailableCount = 0;
        for (let i = 0; i < rows.length; i++) {
            const r = rows[i];
            if (!r || typeof r !== 'object') continue;
            const p = String(r.phone_number || r.phone || (Array.isArray(r.phone_numbers) ? r.phone_numbers[0] : '') || '').replace(/\D+/g, '');
            if (p.length >= 7) phoneCount++;
            if (/^(valid|available|yes|true|verified)$/i.test(String(r.whatsapp_status || '').trim())) waAvailableCount++;
        }
        return { phoneCount, waAvailableCount };
    }

    function computeHistorySessionSig(s) {
        if (!s || typeof s !== 'object') return '';
        const kw = Array.isArray(s.keywords) ? s.keywords.map(k => String(k || '').trim().toLowerCase()).filter(Boolean).sort().join('|') : '';
        const loc = Array.isArray(s.locations) ? s.locations.map(l => String(l || '').trim().toLowerCase()).filter(Boolean).sort().join('|') : '';
        const rList = Array.isArray(s.rows) ? s.rows : [];
        const firstRow = rList[0] || {};
        const lastRow = rList[rList.length - 1] || {};
        const firstId = String(firstRow.place_id || firstRow.cid || firstRow.phone_number || firstRow.phone || firstRow.company_name || '').trim().toLowerCase();
        const lastId = String(lastRow.place_id || lastRow.cid || lastRow.phone_number || lastRow.phone || lastRow.company_name || '').trim().toLowerCase();
        const cnt = Math.max(parseInt(s.leadCount, 10) || 0, parseInt(s.rowCount, 10) || 0, rList.length);
        if (!firstId && !kw && cnt <= 0) return '';
        return [kw, loc, cnt, firstId, lastId].join('::');
    }

    function mergeHistoryRowsPreservingWa(rowsA, rowsB) {
        const primary = (Array.isArray(rowsA) && rowsA.length >= (Array.isArray(rowsB) ? rowsB.length : 0)) ? rowsA : (Array.isArray(rowsB) ? rowsB : []);
        const secondary = (primary === rowsA) ? (Array.isArray(rowsB) ? rowsB : []) : (Array.isArray(rowsA) ? rowsA : []);
        if (!secondary.length) return primary;
        const waMap = new Map();
        for (let i = 0; i < secondary.length; i++) {
            const sr = secondary[i];
            if (!sr || !sr.whatsapp_status || /checking|pending|queued/i.test(String(sr.whatsapp_status))) continue;
            const k = String(sr.place_id || sr.cid || sr.phone_number || sr.phone || sr.company_name || '').trim().toLowerCase();
            if (k) waMap.set(k, { status: sr.whatsapp_status, provider: sr.whatsapp_api_provider || '' });
        }
        if (waMap.size > 0) {
            for (let j = 0; j < primary.length; j++) {
                const pr = primary[j];
                if (!pr) continue;
                const curSt = String(pr.whatsapp_status || '').trim();
                if (!curSt || /checking|pending|queued/i.test(curSt)) {
                    const k2 = String(pr.place_id || pr.cid || pr.phone_number || pr.phone || pr.company_name || '').trim().toLowerCase();
                    if (k2 && waMap.has(k2)) {
                        const hit = waMap.get(k2);
                        pr.whatsapp_status = hit.status;
                        if (hit.provider) pr.whatsapp_api_provider = hit.provider;
                    }
                }
            }
        }
        return primary;
    }

    function deduplicateHistorySessionArray(sessions, duplicateIdsOut) {
        const byId = new Map();
        const sigToId = new Map();
        (Array.isArray(sessions) ? sessions : []).forEach(session => {
            if (!session || !session.id) return;
            const rawId = String(session.id).trim();
            if (!rawId) return;
            const sRows = Array.isArray(session.rows) ? session.rows : [];
            const sLeadCnt = Math.max(parseInt(session.leadCount, 10) || 0, parseInt(session.rowCount, 10) || 0, sRows.length);
            if (sLeadCnt <= 0 && !sRows.length) return;
            const sig = computeHistorySessionSig(session);
            let targetId = rawId;
            if (!byId.has(rawId) && sig && sigToId.has(sig)) {
                targetId = sigToId.get(sig);
                if (Array.isArray(duplicateIdsOut) && rawId !== targetId) duplicateIdsOut.push(rawId);
            }
            if (sig && !sigToId.has(sig)) sigToId.set(sig, targetId);
            const prior = byId.get(targetId);
            if (!prior) {
                const stats = countSessionPhonesAndWa(sRows);
                const estPhones = (sLeadCnt > sRows.length && sRows.length > 0)
                    ? Math.round((stats.phoneCount / sRows.length) * sLeadCnt)
                    : stats.phoneCount;
                byId.set(targetId, Object.assign({}, session, {
                    id: targetId,
                    rows: sRows,
                    leadCount: sLeadCnt,
                    rowCount: sLeadCnt,
                    phoneCount: Math.max(parseInt(session.phoneCount, 10) || 0, estPhones),
                    waAvailableCount: Math.max(parseInt(session.waAvailableCount, 10) || 0, stats.waAvailableCount)
                }));
            } else {
                const mergedRows = mergeHistoryRowsPreservingWa(prior.rows, sRows);
                const bestCount = Math.max(
                    parseInt(session.leadCount, 10) || 0,
                    parseInt(session.rowCount, 10) || 0,
                    parseInt(prior.leadCount, 10) || 0,
                    parseInt(prior.rowCount, 10) || 0,
                    mergedRows.length
                );
                const stats = countSessionPhonesAndWa(mergedRows);
                const estPhones = (bestCount > mergedRows.length && mergedRows.length > 0)
                    ? Math.round((stats.phoneCount / mergedRows.length) * bestCount)
                    : stats.phoneCount;
                byId.set(targetId, Object.assign({}, prior, session, {
                    id: targetId,
                    rows: mergedRows,
                    note: session.note || prior.note || '',
                    timestamp: prior.timestamp || session.timestamp,
                    leadCount: bestCount,
                    rowCount: bestCount,
                    phoneCount: Math.max(parseInt(prior.phoneCount, 10) || 0, parseInt(session.phoneCount, 10) || 0, estPhones),
                    waAvailableCount: Math.max(parseInt(prior.waAvailableCount, 10) || 0, parseInt(session.waAvailableCount, 10) || 0, stats.waAvailableCount),
                    isCompactPreview: bestCount > mergedRows.length
                }));
            }
        });
        return Array.from(byId.values())
            .sort((a, b) => String(b.timestamp || '').localeCompare(String(a.timestamp || '')))
            .slice(0, 50);
    }

    $scope.ensureScrapingHistory = () => {
        if (!$scope.local) $scope.local = {};
        if (!Array.isArray($scope.local._scrapeHistory)) $scope.local._scrapeHistory = [];
        return $scope.local._scrapeHistory;
    };

    $scope.saveScrapingHistory = () => {
        const history = deduplicateHistorySessionArray($scope.ensureScrapingHistory());
        $scope.local._scrapeHistory = history.slice(0, 50);
        $scope.saveLocal();
        history.forEach(session => {
            if (!session || !session.id) return;
            try {
                chrome.runtime.sendMessage({ action: 'scrape_history_update_meta', id: session.id, patch: {
                    note: session.note || '', status: session.status || '', timestamp: session.timestamp || '',
                    finishedAt: session.finishedAt || '', startedAt: session.startedAt || ''
                }}, function() { try { void chrome.runtime.lastError; } catch (e) {} });
            } catch (e) {}
        });
    };

    $scope.recordScrapingHistory = (status, persist) => {
        try {
            const collectRows = Array.isArray($scope.local && $scope.local.collect) ? clonePlain($scope.local.collect) : [];
            const advertisedTotal = Math.max(
                parseInt($scope.local && $scope.local.resultStoreCount, 10) || 0,
                parseInt($scope._monotonicResultCount, 10) || 0,
                parseInt($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.scrapedCount, 10) || 0,
                collectRows.length
            );
            if (!collectRows.length && advertisedTotal <= 0) return;
            const now = new Date().toISOString();
            const rawKeywords = Array.isArray($scope.local.keywordList) ? $scope.local.keywordList : [];
            const rawLocations = Array.isArray($scope.local.locationList) ? $scope.local.locationList : [];
            const totalKwCount = rawKeywords.length || $scope.getKeywordLineCount() || Math.max(1, (collectRows[0] && collectRows[0].keyword) ? 1 : 0);
            const totalLocCount = rawLocations.length || $scope.getLocationLineCount() || 0;
            const keywords = rawKeywords.slice(0, 100);
            const locations = rawLocations.slice(0, 150);

            const history = $scope.ensureScrapingHistory();
            const candSig = computeHistorySessionSig({
                keywords,
                locations,
                rows: collectRows,
                leadCount: Math.max(collectRows.length, advertisedTotal)
            });

            const explicitRunId = ($scope.local.apifyQueue && $scope.local.apifyQueue.runEventId) || '';
            const startedAt = ($scope.local.apifyQueue && $scope.local.apifyQueue.startedAt) || $scope.local.scrapeStartedAt || now;
            const candidateId = explicitRunId
                ? ('session_' + String(explicitRunId).replace(/[^a-zA-Z0-9_-]/g, '_'))
                : ('session_' + String(Date.parse(startedAt || now) || Date.now()).replace(/[^a-zA-Z0-9_-]/g, '_'));

            const existing = history.find(x => x && (x.id === candidateId || (candSig && computeHistorySessionSig(x) === candSig)));
            const id = existing ? existing.id : candidateId;
            const finishedAt = (existing && existing.finishedAt && status === 'saved' && collectRows.length <= (existing.leadCount || 0))
                ? existing.finishedAt
                : now;
            const trueLeadCount = Math.max(collectRows.length, advertisedTotal, (existing && existing.leadCount) || 0);
            const stats = countSessionPhonesAndWa(collectRows);
            const estPhones = (trueLeadCount > collectRows.length && collectRows.length > 0)
                ? Math.round((stats.phoneCount / collectRows.length) * trueLeadCount)
                : stats.phoneCount;

            const fullSession = Object.assign({}, existing || {}, {
                id,
                status: status || 'saved',
                timestamp: (existing && existing.timestamp) ? existing.timestamp : finishedAt,
                startedAt: (existing && existing.startedAt) ? existing.startedAt : startedAt,
                finishedAt,
                elapsedMs: Date.parse(finishedAt) - Date.parse(startedAt || finishedAt),
                note: existing && existing.note ? existing.note : '',
                rows: collectRows,
                leadCount: trueLeadCount,
                rowCount: trueLeadCount,
                phoneCount: Math.max((existing && existing.phoneCount) || 0, estPhones),
                waAvailableCount: Math.max((existing && existing.waAvailableCount) || 0, stats.waAvailableCount),
                keywords,
                locations,
                keywordCount: totalKwCount,
                locationCount: totalLocCount,
                isCompactPreview: false
            });
            const compactSession = Object.assign({}, fullSession, {
                rows: collectRows.slice(0, 100),
                leadCount: trueLeadCount,
                rowCount: trueLeadCount,
                phoneCount: fullSession.phoneCount,
                waAvailableCount: fullSession.waAvailableCount,
                isCompactPreview: trueLeadCount > 100,
                keywords: keywords.slice(0, 40),
                locations: locations.slice(0, 40),
                hasRows: true
            });
            const idx = history.findIndex(x => x && x.id === id);
            if (idx >= 0) history[idx] = Object.assign({}, history[idx], compactSession);
            else history.unshift(compactSession);
            $scope.local._scrapeHistory = deduplicateHistorySessionArray(history).slice(0, 50);
            void directIdbPutHistorySession(fullSession);
            try {
                chrome.runtime.sendMessage({ action: 'scrape_history_put', session: fullSession }, function() { try { void chrome.runtime.lastError; } catch (e) {} });
            } catch (e) {}
            if (trueLeadCount > collectRows.length) {
                directIdbGetResultsFallback(0).then(idbRows => {
                    if (Array.isArray(idbRows) && idbRows.length > collectRows.length) {
                        const completeCount = Math.max(trueLeadCount, idbRows.length);
                        const fullStats = countSessionPhonesAndWa(idbRows);
                        const completeSession = Object.assign({}, fullSession, {
                            rows: idbRows,
                            leadCount: completeCount,
                            rowCount: completeCount,
                            phoneCount: fullStats.phoneCount,
                            waAvailableCount: fullStats.waAvailableCount,
                            isCompactPreview: false
                        });
                        void directIdbPutHistorySession(completeSession);
                        try {
                            chrome.runtime.sendMessage({ action: 'scrape_history_put', session: completeSession }, function() { try { void chrome.runtime.lastError; } catch (e) {} });
                        } catch (e) {}
                    }
                }).catch(() => {});
            }
            if (persist !== false) $scope.saveLocal();
            if (status !== 'checkpoint' && typeof window !== 'undefined' && typeof window.__plScheduleAutoCloudBackup === 'function') {
                window.__plScheduleAutoCloudBackup();
            }
        } catch (err) {
            console.warn('recordScrapingHistory failed', err);
        }
    };

    if (typeof window !== 'undefined') {
        window.__plOpenScrapingHistoryFromCloud = function() {
            $scope.$evalAsync(() => {
                $scope.openScrapingHistory();
            });
        };

        window.__plGetLocalHistoryForCloudSync = async function() {
            try {
                const memList = $scope.ensureScrapingHistory();
                // Only record current dashboard collect if it is NOT already present in History!
                if ($scope.local && Array.isArray($scope.local.collect) && $scope.local.collect.length > 0) {
                    const curSig = computeHistorySessionSig({
                        keywords: $scope.local.keywordList || [],
                        locations: $scope.local.locationList || [],
                        rows: $scope.local.collect,
                        leadCount: Math.max(parseInt($scope.local.resultStoreCount, 10) || 0, $scope.local.collect.length)
                    });
                    const alreadySaved = memList.some(s => s && computeHistorySessionSig(s) === curSig);
                    if (!alreadySaved) {
                        try { $scope.recordScrapingHistory('saved', false); } catch (_) {}
                    }
                }
                const idbList = await directIdbGetAllHistorySessions().catch(() => []);
                const dupIds = [];
                const deduplicated = deduplicateHistorySessionArray($scope.ensureScrapingHistory().concat(idbList), dupIds);
                if (dupIds.length) {
                    dupIds.forEach(did => {
                        try { chrome.runtime.sendMessage({ action: 'scrape_history_delete', id: did }, function() { try { void chrome.runtime.lastError; } catch (_) {} }); } catch (_) {}
                    });
                }
                const list = deduplicated.slice(0, 25);
                const hydrated = [];
                for (let i = 0; i < list.length; i++) {
                    const s = list[i];
                    if (!s || !s.id) continue;
                    const fullS = await loadHistorySessionRows(Object.assign({}, s)).catch(() => s);
                    const rows = Array.isArray(fullS && fullS.rows) ? fullS.rows.slice(0, 500) : [];
                    const bestCnt = Math.max(parseInt((fullS || s).leadCount, 10) || 0, parseInt((fullS || s).rowCount, 10) || 0, rows.length);
                    if (bestCnt <= 0 && rows.length === 0) continue;
                    const stats = countSessionPhonesAndWa(Array.isArray(fullS && fullS.rows) ? fullS.rows : rows);
                    hydrated.push(Object.assign({}, fullS || s, {
                        rows: rows,
                        leadCount: bestCnt,
                        rowCount: bestCnt,
                        phoneCount: Math.max(parseInt((fullS || s).phoneCount, 10) || 0, stats.phoneCount),
                        waAvailableCount: Math.max(parseInt((fullS || s).waAvailableCount, 10) || 0, stats.waAvailableCount)
                    }));
                }
                return deduplicateHistorySessionArray(hydrated).slice(0, 25);
            } catch (_) {
                return [];
            }
        };

        window.__plMergeCloudHistorySessions = async function(cloudSessions) {
            try {
                if (!Array.isArray(cloudSessions) || !cloudSessions.length) return 0;
                const current = $scope.ensureScrapingHistory();
                const idbCurrent = await directIdbGetAllHistorySessions().catch(() => []);
                const dupIds = [];
                const mergedAll = deduplicateHistorySessionArray(cloudSessions.concat(current, idbCurrent), dupIds);
                if (dupIds.length) {
                    try {
                        const db = await openHistoryIdbDirect();
                        if (db) {
                            const stores = [];
                            if (db.objectStoreNames.contains('history')) stores.push('history');
                            if (db.objectStoreNames.contains('history_rows')) stores.push('history_rows');
                            if (stores.length) {
                                const tx = db.transaction(stores, 'readwrite');
                                dupIds.forEach(did => stores.forEach(s => { try { tx.objectStore(s).delete(String(did)); } catch (_) {} }));
                            }
                        }
                    } catch (_) {}
                }
                let restoredLeadsTotal = 0;
                const compactMergedList = [];
                for (let i = 0; i < mergedAll.length; i++) {
                    const cs = mergedAll[i];
                    if (!cs || !cs.id) continue;
                    const id = String(cs.id);
                    const cRows = Array.isArray(cs.rows) ? cs.rows : [];
                    const bestCount = Math.max(parseInt(cs.leadCount, 10) || 0, parseInt(cs.rowCount, 10) || 0, cRows.length);
                    restoredLeadsTotal += bestCount;
                    const stats = countSessionPhonesAndWa(cRows);
                    const fullSession = Object.assign({}, cs, {
                        id: id,
                        rows: cRows,
                        leadCount: bestCount,
                        rowCount: bestCount,
                        phoneCount: Math.max(parseInt(cs.phoneCount, 10) || 0, stats.phoneCount),
                        waAvailableCount: Math.max(parseInt(cs.waAvailableCount, 10) || 0, stats.waAvailableCount),
                        isCompactPreview: false,
                        hasRows: cRows.length > 0
                    });
                    await directIdbPutHistorySession(fullSession);
                    try {
                        if (window.PocketLeadsApifyFlow && window.PocketLeadsApifyFlow.HistoryStore && typeof window.PocketLeadsApifyFlow.HistoryStore.put === 'function') {
                            await window.PocketLeadsApifyFlow.HistoryStore.put(fullSession);
                        } else {
                            chrome.runtime.sendMessage({ action: 'scrape_history_put', session: fullSession }, function() { try { void chrome.runtime.lastError; } catch (_) {} });
                        }
                    } catch (_) {}
                    const memRows = cRows.slice(0, 300);
                    compactMergedList.push(Object.assign({}, fullSession, {
                        rows: memRows,
                        leadCount: bestCount,
                        rowCount: bestCount,
                        isCompactPreview: bestCount > memRows.length,
                        hasRows: true
                    }));
                }
                $scope.safeApply(() => {
                    if (!$scope.local) $scope.local = {};
                    $scope.local._scrapeHistory = compactMergedList.slice(0, 50);
                    $scope.saveLocal();
                    if ($scope.historyModal && $scope.historyModal.show) {
                        $scope.historyModal.loading = false;
                    }
                });
                return restoredLeadsTotal;
            } catch (e) {
                console.warn('Cloud history merge failed', e);
                return 0;
            }
        };
    }

    $scope.openScrapingHistory = () => {
        $scope.ensureScrapingHistory();
        if (!$scope.historyModal.selectedIds) $scope.historyModal.selectedIds = {};
        $scope.historyModal.viewSession = null;
        $scope.historyModal.viewPage = 1;
        $scope.historyModal.show = true;
        $scope.refreshScrapingHistory();
    };
    $scope.closeScrapingHistory = () => {
        $scope.historyModal.show = false;
        $scope.historyModal.viewSession = null;
        $scope.historyModal.viewPage = 1;
    };
    $scope.applyHistoryFilter = () => { /* model-bound filters apply automatically */ };
    $scope.clearHistoryFilter = () => {
        $scope.historyModal.search = '';
        $scope.historyModal.fromDate = '';
        $scope.historyModal.toDate = '';
        $scope.historyModal.viewSession = null;
        $scope.historyModal.viewPage = 1;
    };
    $scope.refreshScrapingHistory = () => {
        $scope.historyModal.loading = true;
        try {
            $box.getLocal(local => {
                let localMeta = local && Array.isArray(local._scrapeHistory) ? local._scrapeHistory : [];
                if (!localMeta.length && local && Array.isArray(local.collect) && local.collect.length && !local.status && !(local._taskManager && local._taskManager.isWorking)) {
                    try { $scope.recordScrapingHistory('recovered', false); } catch (e) {}
                    localMeta = $scope.ensureScrapingHistory();
                }
                $scope.$evalAsync(() => { if (localMeta.length) $scope.local._scrapeHistory = deduplicateHistorySessionArray(localMeta); });
                try {
                    chrome.runtime.sendMessage({ action: 'scrape_history_get_all' }, response => {
                        try { void chrome.runtime.lastError; } catch (e) {}
                        $scope.$evalAsync(() => {
                            const stored = response && response.ok && Array.isArray(response.sessions) ? response.sessions : [];
                            const currentMeta = $scope.ensureScrapingHistory();
                            const dupIds = [];
                            const mergedSessions = deduplicateHistorySessionArray(currentMeta.concat(localMeta, stored), dupIds);
                            $scope.local._scrapeHistory = mergedSessions.slice(0, 50);
                            if (dupIds.length) {
                                dupIds.forEach(did => {
                                    try { chrome.runtime.sendMessage({ action: 'scrape_history_delete', id: did }, function() { try { void chrome.runtime.lastError; } catch (e) {} }); } catch (e) {}
                                });
                            }
                            if (!stored.length) {
                                $scope.local._scrapeHistory.filter(session => session && session.id && Array.isArray(session.rows) && session.rows.length).forEach(session => {
                                    try { chrome.runtime.sendMessage({ action: 'scrape_history_put', session }, function() { try { void chrome.runtime.lastError; } catch (e) {} }); } catch (e) {}
                                });
                            }
                            $scope.historyModal.loading = false;
                        });
                    });
                } catch (e) { $scope.$evalAsync(() => { $scope.historyModal.loading = false; }); }
            });
        } catch (err) { $scope.historyModal.loading = false; console.warn('refreshScrapingHistory failed', err); }
    };
    $scope.getFilteredScrapingHistory = () => {
        const search = String($scope.historyModal.search || '').trim().toLowerCase();
        const fromMs = normaliseDateInput($scope.historyModal.fromDate, false);
        const toMs = normaliseDateInput($scope.historyModal.toDate, true);
        return $scope.ensureScrapingHistory().filter(session => {
            const stamp = Date.parse(session.timestamp || session.finishedAt || session.startedAt || '') || 0;
            if (fromMs && stamp < fromMs) return false;
            if (toMs && stamp > toMs) return false;
            if (search) {
                const hay = [session.note, session.name, (session.keywords || []).join(' '), (session.locations || []).join(' ')].join(' ').toLowerCase();
                if (!hay.includes(search)) return false;
            }
            return true;
        });
    };
    $scope.formatHistoryDate = value => {
        const d = new Date(value || Date.now());
        if (isNaN(d.getTime())) return '';
        return d.toLocaleString();
    };
    $scope.getHistoryLeadCount = session => {
        if (!session) return 0;
        return Math.max(
            parseInt(session.leadCount, 10) || 0,
            parseInt(session.rowCount, 10) || 0,
            Array.isArray(session.rows) ? session.rows.length : 0
        );
    };
    $scope.getHistoryPhoneCount = session => {
        if (!session) return 0;
        if (Number.isFinite(Number(session.phoneCount)) && Number(session.phoneCount) > 0) {
            return parseInt(session.phoneCount, 10);
        }
        const rows = Array.isArray(session.rows) ? session.rows : [];
        if (rows.length > 0) {
            const stats = countSessionPhonesAndWa(rows);
            const totalLeads = $scope.getHistoryLeadCount(session);
            const est = (totalLeads > rows.length && rows.length > 0)
                ? Math.round((stats.phoneCount / rows.length) * totalLeads)
                : stats.phoneCount;
            session.phoneCount = est;
            session.waAvailableCount = stats.waAvailableCount;
            return est;
        }
        return $scope.getHistoryLeadCount(session);
    };
    $scope.getHistoryVerifiedWaCount = session => {
        if (!session) return 0;
        if (Number.isFinite(Number(session.waAvailableCount)) && Number(session.waAvailableCount) > 0) {
            return parseInt(session.waAvailableCount, 10);
        }
        const rows = Array.isArray(session.rows) ? session.rows : [];
        if (rows.length > 0) {
            const stats = countSessionPhonesAndWa(rows);
            session.waAvailableCount = stats.waAvailableCount;
            return stats.waAvailableCount;
        }
        return 0;
    };
    $scope.isHistorySessionSelected = function(session) {
        if (!session || !session.id || !$scope.historyModal || !$scope.historyModal.selectedIds) return false;
        return !!$scope.historyModal.selectedIds[session.id];
    };
    $scope.toggleHistorySessionSelect = function(session, $event) {
        if ($event && typeof $event.stopPropagation === 'function') $event.stopPropagation();
        if (!session || !session.id) return;
        if (!$scope.historyModal.selectedIds) $scope.historyModal.selectedIds = {};
        $scope.historyModal.selectedIds[session.id] = !$scope.historyModal.selectedIds[session.id];
    };
    $scope.areAllFilteredHistorySelected = function() {
        const list = $scope.getFilteredScrapingHistory();
        if (!list.length || !$scope.historyModal || !$scope.historyModal.selectedIds) return false;
        return list.every(s => s && s.id && $scope.historyModal.selectedIds[s.id]);
    };
    $scope.toggleSelectAllHistorySessions = function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        if (!$scope.historyModal.selectedIds) $scope.historyModal.selectedIds = {};
        const list = $scope.getFilteredScrapingHistory();
        const allSelected = $scope.areAllFilteredHistorySelected();
        list.forEach(s => {
            if (s && s.id) $scope.historyModal.selectedIds[s.id] = !allSelected;
        });
    };
    $scope.clearHistorySelection = function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        if ($scope.historyModal) $scope.historyModal.selectedIds = {};
    };
    $scope.getHistorySelectedSessions = function() {
        if (!$scope.historyModal || !$scope.historyModal.selectedIds) return [];
        const selMap = $scope.historyModal.selectedIds;
        return $scope.ensureScrapingHistory().filter(s => s && s.id && selMap[s.id]);
    };
    $scope.getHistorySelectedSessionCount = function() {
        return $scope.getHistorySelectedSessions().length;
    };
    $scope.getHistorySelectedPhoneCount = function() {
        return $scope.getHistorySelectedSessions().reduce((sum, s) => sum + $scope.getHistoryPhoneCount(s), 0);
    };
    $scope.viewHistorySession = session => {
        $scope.historyModal.viewPage = 1;
        $scope.historyModal.loadingRows = true;
        loadHistorySessionRows(session).then(fullSession => {
            $scope.$evalAsync(() => {
                $scope.historyModal.viewSession = fullSession || session || null;
                $scope.historyModal.loadingRows = false;
            });
        }).catch(() => {
            $scope.$evalAsync(() => { $scope.historyModal.viewSession = session || null; $scope.historyModal.loadingRows = false; });
        });
    };
    $scope.backToHistoryList = () => {
        $scope.historyModal.viewSession = null;
        $scope.historyModal.viewPage = 1;
    };
    $scope.restoreHistorySessionToDashboard = async session => {
        $scope._isClearedSession = false;
        const fullSession = await loadHistorySessionRows(session);
        const rows = getRowsFromHistory(fullSession);
        if (!rows.length) {
            try { $scope.snackbar.show('History rows are not available for this session.'); } catch (e) {}
            return;
        }
        $scope.local.collect = clonePlain(rows);
        if (Array.isArray(fullSession && fullSession.keywords)) {
            $scope.local.keywordList = clonePlain(fullSession.keywords);
            $scope.local.keywordTextarea = fullSession.keywords.join('\n');
        }
        if (Array.isArray(fullSession && fullSession.locations)) {
            $scope.local.locationList = clonePlain(fullSession.locations);
            $scope.local.locationTextarea = fullSession.locations.join('\n');
        }
        $scope.local.resultStoreCount = rows.length;
        try { refreshDashboardMetricCounts($scope.local.collect); } catch (_) {}
        try { refreshMobileLeadsView($scope.local.collect); } catch (_) {}
        try { void runtimeMessageAsync({ action: 'result_store_upsert', rows: $scope.local.collect }); } catch (_) {}
        $scope.saveLocal();
        lastCollectDataCount = 0;
        buildDataTable();
        insertIntoDataTable($scope.local);
        updateDataTable($scope.local);
        $scope.historyModal.show = false;
        $scope.historyModal.viewSession = null;
        if ($scope.viewMode === 'mobile' && typeof $scope.setMobileTab === 'function') {
            $scope.setMobileTab('leads');
        }
        try { showTopStatusToast('✓ Loaded ' + rows.length + ' leads from History', 'success'); } catch (_) {}
    };

    $scope.getHistoryViewRows = () => applyWaVerifiedCacheToRows(getRowsFromHistory($scope.historyModal.viewSession));
    $scope.getHistoryViewColumns = () => {
        const rows = $scope.getHistoryViewRows();
        return buildColumnListFromRows(rows).filter(key => rows.some(row => row && row[key] !== undefined && row[key] !== null && row[key] !== '') || baseColumnList.includes(key));
    };
    $scope.getHistoryViewPageRows = () => {
        const rows = $scope.getHistoryViewRows();
        const size = parseInt($scope.historyModal.viewPageSize, 10) || 25;
        const page = Math.max(1, parseInt($scope.historyModal.viewPage, 10) || 1);
        return rows.slice((page - 1) * size, page * size);
    };
    $scope.historyViewTotalPages = () => {
        const rows = $scope.getHistoryViewRows();
        const size = parseInt($scope.historyModal.viewPageSize, 10) || 25;
        return Math.max(1, Math.ceil(rows.length / size));
    };
    $scope.historyViewRangeLabel = () => {
        const rows = $scope.getHistoryViewRows();
        if (!rows.length) return 'No leads';
        const size = parseInt($scope.historyModal.viewPageSize, 10) || 25;
        const page = Math.max(1, Math.min($scope.historyViewTotalPages(), parseInt($scope.historyModal.viewPage, 10) || 1));
        const start = ((page - 1) * size) + 1;
        const end = Math.min(rows.length, page * size);
        return 'Showing ' + start + '-' + end + ' of ' + rows.length + ' leads';
    };
    $scope.historyViewNextPage = () => {
        const total = $scope.historyViewTotalPages();
        $scope.historyModal.viewPage = Math.min(total, (parseInt($scope.historyModal.viewPage, 10) || 1) + 1);
    };
    $scope.historyViewPrevPage = () => {
        $scope.historyModal.viewPage = Math.max(1, (parseInt($scope.historyModal.viewPage, 10) || 1) - 1);
    };
    $scope.getHistoryCell = (row, col) => {
        const value = row && row[col];
        if (value === null || typeof value === 'undefined') return '';
        if (typeof value === 'object') {
            try { return JSON.stringify(value); } catch (e) { return ''; }
        }
        return String(value);
    };
    $scope.historyColumnHeader = col => {
        try {
            const mapped = (typeof FoxCommon !== 'undefined' && FoxCommon.getKeyFromMap) ? FoxCommon.getKeyFromMap(col) : '';
            if (mapped && mapped !== col) return mapped;
            return FoxCommon.downloadAs.keyToColumnHeader(col);
        } catch (e) {
            return String(col || '').replace(/_/g, ' ').replace(/\b\w/g, m => m.toUpperCase());
        }
    };
    $scope.downloadHistorySheets = session => $scope.restoreHistorySessionToDashboard(session);
    // History Note Lock & Pencil Edit Helpers
    $scope.isHistoryNoteLocked = function(session) {
        if (!session) return false;
        if (session._editingNote) return false;
        return String(session.note || '').trim().length > 0;
    };
    $scope.startHistoryNoteEdit = function(session, $event) {
        if ($event && typeof $event.stopPropagation === 'function') $event.stopPropagation();
        if (!session) return;
        session._editingNote = true;
        setTimeout(function() {
            try {
                const el = document.getElementById('histNote_' + session.id);
                if (el) {
                    el.focus();
                    if (typeof el.select === 'function') el.select();
                }
            } catch (_) {}
        }, 30);
    };
    $scope.onHistoryNoteInputClick = function(session, $event) {
        if (!session) return;
        if (!String(session.note || '').trim()) {
            session._editingNote = true;
        }
    };
    $scope.onHistoryNoteKeydown = function(session, $event) {
        if ($event && ($event.key === 'Enter' || $event.keyCode === 13)) {
            $event.preventDefault();
            $scope.finishHistoryNoteEdit(session, true);
            try { if ($event.target && typeof $event.target.blur === 'function') $event.target.blur(); } catch (_) {}
        }
    };
    $scope.finishHistoryNoteEdit = function(session, showToast) {
        if (!session) return;
        session.note = String(session.note || '').trim();
        const wasEditing = !!session._editingNote;
        session._editingNote = false;
        $scope.saveScrapingHistory();
        // Only write full rows to IDB if session is not a compact preview; metadata is updated via scrape_history_update_meta
        if (!session.isCompactPreview && Array.isArray(session.rows) && session.rows.length >= (parseInt(session.leadCount || session.rowCount, 10) || 0)) {
            void directIdbPutHistorySession(session);
        }
        if (showToast && wasEditing && session.note) {
            showTopStatusToast('✓ Note saved & locked', 'success');
        }
    };

    // Open Choose Columns Modal for History CSV / Excel Export
    async function openHistoryChooseColumnsModal(session, defaultFormat) {
        const fullSession = await loadHistorySessionRows(session);
        const rows = applyWaVerifiedCacheToRows(dedupeCanonicalRows(getRowsFromHistory(fullSession)));
        if (!rows.length) {
            showTopStatusToast('No saved rows found for this history session', 'warn');
            return;
        }
        if (!(await allowExportRows(rows.length))) return;
        const priority = ['keyword', 'location', 'company_name', 'phone_number', 'whatsapp_status', 'review', 'total_reviews', 'category', 'address', 'city', 'state', 'pincode', 'website', 'email_1', 'map_link', 'photo_url', 'photo_url_large', 'photo_urls', 'status', 'facebook', 'instagram', 'linkedin', 'twitter', 'youtube', 'place_id', 'cid', 'latitude', 'longitude', 'source', 'scraped_at'];
        const rank = k => { const idx = priority.indexOf(k); return idx >= 0 ? idx : 999; };
        const fieldSet = new Set(['keyword', 'location', ...PocketLeadsExport.fields(rows, baseColumnList), 'photo_url', 'photo_url_large', 'photo_urls']);
        const labels = Array.from(fieldSet).sort((a, b) => rank(a) - rank(b));
        const selected = {};
        labels.forEach(label => { selected[label] = rememberedExportFields[label] !== false; });
        const fmt = (String(defaultFormat || 'csv').toLowerCase() === 'excel') ? 'excel' : 'csv';
        $scope.safeApply(() => {
            $scope.exportModal = {
                show: true,
                step: 'fields',
                activePreset: 'all',
                uniqueBy: '',
                loading: false,
                fields: labels,
                selected: selected,
                format: fmt,
                rows: rows,
                largeMode: false,
                rowCount: rows.length,
                isHistoryExport: true,
                customStamp: 'History_' + historyFileDate(fullSession || session)
            };
        });
    }

    $scope.downloadHistoryCsv = session => {
        void openHistoryChooseColumnsModal(session, 'csv');
    };
    $scope.downloadHistoryExcel = session => {
        void openHistoryChooseColumnsModal(session, 'excel');
    };
    $scope.deleteHistorySession = async session => {
        const id = session && session.id;
        if (!id) return;
        $scope.local._scrapeHistory = $scope.ensureScrapingHistory().filter(x => x && x.id !== id);
        if ($scope.historyModal && $scope.historyModal.viewSession && $scope.historyModal.viewSession.id === id) {
            $scope.historyModal.viewSession = null;
        }
        $scope.saveLocal();
        try {
            const db = await openHistoryIdbDirect();
            if (db) {
                const stores = [];
                if (db.objectStoreNames.contains('history')) stores.push('history');
                if (db.objectStoreNames.contains('history_rows')) stores.push('history_rows');
                if (stores.length) {
                    const tx = db.transaction(stores, 'readwrite');
                    stores.forEach(s => { try { tx.objectStore(s).delete(String(id)); } catch (_) {} });
                }
            }
        } catch (_) {}
        try { chrome.runtime.sendMessage({ action: 'scrape_history_delete', id }, function() { try { void chrome.runtime.lastError; } catch (e) {} }); } catch (e) {}
        showTopStatusToast('✓ History session deleted', 'success');
    };
    $scope.confirmDeleteHistoryModal = { show: false };
    $scope.openDeleteAllHistoryConfirm = function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        $scope.confirmDeleteHistoryModal.show = true;
    };
    $scope.closeDeleteAllHistoryConfirm = function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        $scope.confirmDeleteHistoryModal.show = false;
    };
    $scope.confirmDeleteAllScrapingHistory = async function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        $scope.confirmDeleteHistoryModal.show = false;
        await $scope.deleteAllScrapingHistory();
    };
    $scope.deleteAllScrapingHistory = async () => {
        $scope.confirmDeleteHistoryModal.show = false;
        $scope.local._scrapeHistory = [];
        if ($scope.historyModal) $scope.historyModal.viewSession = null;
        $scope.saveLocal();
        try {
            const db = await openHistoryIdbDirect();
            if (db) {
                const stores = [];
                if (db.objectStoreNames.contains('history')) stores.push('history');
                if (db.objectStoreNames.contains('history_rows')) stores.push('history_rows');
                if (stores.length) {
                    const tx = db.transaction(stores, 'readwrite');
                    stores.forEach(s => { try { tx.objectStore(s).clear(); } catch (_) {} });
                }
            }
        } catch (_) {}
        try { chrome.runtime.sendMessage({ action: 'scrape_history_clear' }, function() { try { void chrome.runtime.lastError; } catch (e) {} }); } catch (e) {}
        // Also perform full temporary session, URL & browsing cache cleanup
        try { clearIndexedDbResultsOnly(); } catch (_) {}
        showTopStatusToast('✓ All scraping history & temporary caches cleared', 'success');
    };
    // Backward-compatible alias for old Clear History button references.
    $scope.clearHistory = () => $scope.openScrapingHistory();

    /**
     * Close the current search tab if it exists.  The TaskManager stores
     * the tab ID under _taskManager.searchTabId.  This helper can be
     * called from stop, clear, or completion handlers to ensure that
     * background tabs opened for scraping are cleaned up.  After
     * removing the tab the stored ID is reset and persisted.
     */
    $scope.closeSearchTab = () => {
        try {
            const id = $scope.local && $scope.local._taskManager && $scope.local._taskManager.searchTabId;
            if (id && chrome && chrome.tabs && typeof chrome.tabs.remove === 'function') {
                // Only attempt to remove the tab if the ID appears to be a valid number
                const tabId = Number(id);
                if (!isNaN(tabId) && tabId > 0) {
                    chrome.tabs.remove(tabId, function() {
                        if (chrome.runtime && chrome.runtime.lastError) {
                            const err = chrome.runtime.lastError;
                            const msg = err && (err.message || String(err));
                            // Suppress the common "No tab with id" error silently
                            if (!msg || msg.indexOf('No tab with id') === -1) {
                                console.warn('closeSearchTab: tab remove error', msg);
                            }
                        }
                    });
                }
                // Reset the stored ID and persist the update
                $scope.local._taskManager.searchTabId = null;
                $scope.saveLocal();
            }
        } catch (err) {
            console.warn('closeSearchTab: failed to close search tab', err);
        }
    };
    
    /* -------------------------------- Material Design -------------------------------- */
    $scope.initiMaterialDesignComponents = () => {
        MaterialDesignLite.init();
    };
    $scope.initiMaterialDesignComponents();
    /* -------------------------------- Material Design -------------------------------- */
    
    /* ---------------------------------- Login (Removed) --------------------------------- */
    // The original extension supported activating the full version via a license key.
    // For this open build we do not implement licensing.  The login and logout
    // handlers have been removed to avoid misleading UI and unused logic.  If the
    // user triggers these actions (e.g., via leftover UI elements), simply show
    // a snackbar message indicating that licensing is not required.
    $scope.login = () => {
        /*
         * The login handler is kept as a no‑op because the extension
         * automatically operates in full mode once a valid licence has been
         * activated.  There is no separate account login required.  If the
         * user somehow triggers the login action we simply inform them
         * that no login is necessary.
         */
        $scope.snackbar.show("No login required – activate your licence to use all features.");
    };

    /**
     * Release the currently stored licence key.  When invoked from the
     * Settings menu this function calls the globally defined
     * releaseLicenceInternal() helper to notify the Apps Script backend
     * and clear the local licence record.  After a successful release
     * the licence activation modal is displayed again so the user can
     * enter a new key if desired.  Errors are surfaced via the snackbar.
     */
    $scope.logout = () => {
        try {
            $scope._wasRunningInThisSession = false;
            $scope.scrapingCompleteShown = true;
            if ($scope.completePopup) $scope.completePopup.show = false;
            try {
                if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.cancelAllNotifications === 'function') {
                    window.AndroidChromeBridge.cancelAllNotifications();
                }
            } catch (_) {}
            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                $scope.snackbar.show("Releasing licence…");
            }
            const releasePromise = (typeof window.releaseLicenceInternal === 'function')
                ? window.releaseLicenceInternal()
                : Promise.resolve();
            releasePromise.then(() => {
                $scope.safeApply(() => {
                    $scope.licenseActive = false;
                    $scope.completePopup.show = false;
                });
                if (typeof window.showLicenseModal === 'function') {
                    window.showLicenseModal();
                }
                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                    $scope.snackbar.show("Licence released successfully");
                }
            }).catch((err) => {
                console.error('Error releasing licence via logout()', err);
                if (typeof window.showLicenseModal === 'function') {
                    window.showLicenseModal();
                }
            });
        } catch (err) {
            console.error('Unexpected error in logout()', err);
        }
    };
    
    /* -------------------------------- Snackbar -------------------------------- */
    $scope.snackbar = {
        isShown : false,
        text: '',
        show:(text,closeAfterSec=3)=>{
            $scope.snackbar.text = text;
            $scope.snackbar.isShown = true;
            $scope.snackbar.closeAfter(closeAfterSec);
        },
        hide:()=>{
            $scope.snackbar.isShown = false;
        },
        closeAfter :(closeAfterSec)=>{
            setTimeout(()=>{
                $scope.$apply(()=>{
                    $scope.snackbar.isShown = false;
                });
            },closeAfterSec*1000);
        }
    };
    /* -------------------------------- Snackbar -------------------------------- */

    /* -------------------------------- Captcha/Error Popup -------------------------------- */

    /* -------------------------------- Completion Popup -------------------------------- */
    // Define a completion modal object.  When scraping finishes we display this
    // modal to inform the user.  It mirrors the captcha popup styling and
    // behaviour.  The message can be customized when invoking
    // showCompletePopup().
    $scope.completePopup = {
        show: false,
        message: ''
    };
    /**
     * Display the completion popup with a given message.  Called when
     * scraping completes successfully.  The popup is dismissed via
     * closeCompletePopup().
     * @param {string} msg - The message to display in the popup.
     */
    $scope.soundVibrateEnabled = (function() {
        try {
            const v = localStorage.getItem('pl_sound_vibrate_enabled_v1');
            return v === null ? true : (v === '1' || v === 'true');
        } catch (_) {
            return true;
        }
    })();

    $scope.toggleSoundVibrateAlerts = function($event) {
        if ($event) {
            $event.preventDefault();
            $event.stopPropagation();
        }
        $scope.soundVibrateEnabled = !$scope.soundVibrateEnabled;
        try {
            localStorage.setItem('pl_sound_vibrate_enabled_v1', $scope.soundVibrateEnabled ? '1' : '0');
        } catch (_) {}
        showTopStatusToast($scope.soundVibrateEnabled ? '🔔 Completion Sound & Vibration: ON' : '🔕 Completion Sound & Vibration: OFF', 'info');
    };

    function triggerCompletionSoundVibrateAndNotification(kindLabel) {
        try {
            const rows = Array.isArray($scope.local && $scope.local.collect) ? $scope.local.collect : [];
            const totalLeads = Math.max(Number($scope.local && $scope.local.resultStoreCount) || 0, rows.length);
            const phonesCount = Number($scope.metricCounts && $scope.metricCounts.phone_number) || 0;
            const webCount = Number($scope.metricCounts && $scope.metricCounts.website) || 0;
            const emailCount = Number($scope.metricCounts && $scope.metricCounts.email_1) || 0;

            if ($scope.soundVibrateEnabled) {
                try {
                    if (navigator && typeof navigator.vibrate === 'function') {
                        navigator.vibrate([90, 50, 140]);
                    }
                } catch (_) {}
                try {
                    const AudioCtx = window.AudioContext || window.webkitAudioContext;
                    if (AudioCtx) {
                        const ctx = new AudioCtx();
                        const playNote = (freq, startSec, durSec) => {
                            const osc = ctx.createOscillator();
                            const gain = ctx.createGain();
                            osc.type = 'sine';
                            osc.frequency.setValueAtTime(freq, ctx.currentTime + startSec);
                            gain.gain.setValueAtTime(0.14, ctx.currentTime + startSec);
                            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + startSec + durSec);
                            osc.connect(gain);
                            gain.connect(ctx.destination);
                            osc.start(ctx.currentTime + startSec);
                            osc.stop(ctx.currentTime + startSec + durSec);
                        };
                        playNote(587.33, 0, 0.14);
                        playNote(880.0, 0.15, 0.24);
                        setTimeout(() => { try { ctx.close(); } catch (_) {} }, 600);
                    }
                } catch (_) {}
            }

            const notifTitle = '✅ ' + (kindLabel || 'Extraction Complete') + ': ' + totalLeads + ' Leads';
            const notifBody = '📞 ' + phonesCount + ' Phones · 🌐 ' + webCount + ' Websites · ✉️ ' + emailCount + ' Emails';
            if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.showNotification === 'function') {
                window.AndroidChromeBridge.showNotification('pl_complete_' + Date.now(), notifTitle, notifBody);
            } else if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage({
                    type: 'notify',
                    title: notifTitle,
                    message: notifBody,
                    cooldownMs: 3000
                }, () => { try { void chrome.runtime.lastError; } catch (_) {} });
            }
        } catch (_) {}
    }

    $scope.showCompletePopup = (msg) => {
        try {
            if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.setExtractionActive === 'function' && !($scope.local && $scope.local.isScrapingEmail)) {
                window.AndroidChromeBridge.setExtractionActive(false, '');
            }
        } catch (_) {}
        if (typeof localStorage !== 'undefined' && localStorage.getItem('pl_explicit_logout_v1') === '1') {
            $scope.completePopup.show = false;
            return;
        }
        $scope.completePopup.message = msg || 'Scraping completed successfully!';
        $scope.completePopup.show = true;
        $scope._lastHistoryCheckpointAtCount = 0;
        try { $scope.recordScrapingHistory('completed', false); } catch (_) {}
        triggerCompletionSoundVibrateAndNotification('Extraction Complete');
        try { $scope.$evalAsync(); } catch (_) {}
    };
    /**
     * Hide the completion popup.  Bound to the close button on the
     * modal.
     */
    $scope.closeCompletePopup = () => {
        $scope.completePopup.show = false;
    };
    $scope.previewExtractedLeads = () => {
        $scope.completePopup.show = false;
        if (typeof $scope.setMobileTab === 'function') {
            $scope.setMobileTab('leads');
        } else {
            $scope.mobileTab = 'leads';
        }
        refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
        if ($scope.viewMode === 'desktop') {
            syncGridLayoutSoon();
            setTimeout(() => {
                try {
                    const gridEl = document.getElementById('dataTable');
                    if (gridEl && typeof gridEl.scrollIntoView === 'function') {
                        gridEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }
                } catch (_) {}
            }, 60);
        }
    };
    // Show a dedicated popup for captcha or scraping errors.  This
    // modal remains visible until the user manually closes it.  It is
    // toggled via the scraping_error event handler below.
    $scope.captchaPopup = {
        show: false,
        title: 'Attention Required',
        message: '',
        upgrade: false,
        supportEmail: PocketLeadsConfig.supportEmail
    };
    /**
     * Display the captcha/error popup with a given message.  Call this
     * function when an error is detected (e.g., captcha or unusual
     * traffic).  The popup is dismissed via closeCaptchaPopup().
     * @param {string} msg - The message to display in the popup.
     */
    $scope.refreshCreditBalance = async () => {
        $scope.captchaPopup.refreshMessage = 'Refreshing balance...';
        try {
            await PocketLeadsAccount.refresh();
            const state = await new Promise(resolve=>chrome.storage.local.get('pocketleadsAccount',resolve));
            const a=state.pocketleadsAccount || {};
            $scope.safeApply(()=>{
                $scope.captchaPopup.availableCredit=a.availableCredit;
                $scope.captchaPopup.purchasedCredit=a.purchasedCredit;
                $scope.captchaPopup.refreshMessage = a.syncState === 'ready' ? 'Balance updated. Close this window and Resume to continue.' : 'Refresh unavailable. Please retry.';
            });
        } catch(e) { $scope.safeApply(()=>{$scope.captchaPopup.refreshMessage='Refresh failed. Please retry.';}); }
    };
    function isNetworkSlowIssue(rawMsg, code) {
        const text = String(rawMsg || '').trim();
        const c = String(code || '').trim().toUpperCase();
        if (/LICENSE_CREDIT_EXHAUSTED|ALL_CREDITS_EXHAUSTED|LICENCE_CREDIT_EXHAUSTED|LICENSE_EXPIRED|LICENCE_EXPIRED|LICENSE_INACTIVE/i.test(c)) return false;
        if (/please add at least one search query|please activate your licence/i.test(text)) return false;
        return (
            /NETWORK_SLOW|PROVIDER_NETWORK_TIMEOUT|REQUEST_UNCERTAIN|REQUEST_PENDING|PREFLIGHT_NOT_READY|ACCOUNT_PREFLIGHT|BACKEND_UNAVAILABLE|GHOST_EXTRACTION_FAILED/i.test(c) ||
            /network|timeout|timed out|slow|abort|fetch failed|failed to fetch|offline|internet|connection|preparing in the background|did not finish loading|redirect dropped|temporarily unreachable|ghost tab|try again/i.test(text)
        );
    }

    function toCustomerSafeIssueMessage(rawMsg, code, isUpgrade) {
        const text = String(rawMsg || '').trim();
        if (isUpgrade || /LICENSE_CREDIT_EXHAUSTED|LICENSE_EXPIRED/i.test(code)) return text;
        if (/please add at least one search query|please activate your licence/i.test(text)) return text;
        if (isNetworkSlowIssue(text, code)) {
            return 'Network is slow or unstable right now. Your extracted leads and progress are 100% safe — please check your internet connection and tap "Try Again / Resume" below to continue.';
        }
        if (/api\s*key|provider|scrappa|serper|apify|google\s*sheet|assignment|cooldown|quota|403|401|402|429|row\s*\d+|billing|route|proxy/i.test(text) || /NO_ELIGIBLE_PROVIDER|PROVIDER_/i.test(code)) {
            return 'Extraction service is temporarily busy or under maintenance for your account. Your saved leads are safe — please click "Raise Support Ticket" below and our team will resolve your issue shortly.';
        }
        return text || 'Network is slow or temporarily unstable. Your saved leads are safe — please tap "Try Again / Resume" below.';
    }

    $scope.showCaptchaPopup = (msg, options) => {
        options = options || {};
        const rawTechMsg = String(msg || 'Network is slow. Please try again.').trim();
        const nowIsoStr = new Date().toISOString();
        const nowTimeText = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        let inferredCode = String(options.errorCode || '').trim().toUpperCase();
        if (!inferredCode) {
            if (isNetworkSlowIssue(rawTechMsg, '')) inferredCode = 'NETWORK_SLOW_RETRY';
            else if (/no assigned api key|no eligible provider/i.test(rawTechMsg)) inferredCode = 'NO_ELIGIBLE_PROVIDER';
            else if (/provider_auth|403|401|forbidden/i.test(rawTechMsg)) inferredCode = 'PROVIDER_AUTH';
            else if (/provider_quota|402|quota/i.test(rawTechMsg)) inferredCode = 'PROVIDER_QUOTA';
            else if (/rate_limit|429/i.test(rawTechMsg)) inferredCode = 'PROVIDER_RATE_LIMIT';
            else if (/credit.*exhausted|no.*credit/i.test(rawTechMsg)) inferredCode = 'LICENSE_CREDIT_EXHAUSTED';
            else if (/expired/i.test(rawTechMsg)) inferredCode = 'LICENSE_EXPIRED';
            else if (/inactive|disabled/i.test(rawTechMsg)) inferredCode = 'LICENSE_INACTIVE';
            else if (/captcha|unusual traffic/i.test(rawTechMsg)) inferredCode = 'CAPTCHA_CHALLENGE';
            else inferredCode = 'NETWORK_SLOW_RETRY';
        }
        const isNetSlow = !options.upgrade && isNetworkSlowIssue(rawTechMsg, inferredCode);
        const customerMsg = toCustomerSafeIssueMessage(rawTechMsg, inferredCode, !!options.upgrade);
        const refId = 'REF-' + String(Date.now()).slice(-5);

        $scope.captchaPopup.isNetworkSlow = isNetSlow;
        $scope.captchaPopup.kicker = options.upgrade ? 'PLAN / CREDIT ALERT' : (isNetSlow ? 'NETWORK CONNECTION ALERT' : 'EXTRACTION SERVICE NOTICE');
        $scope.captchaPopup.message = customerMsg;
        $scope.captchaPopup.rawTechMessage = rawTechMsg;
        $scope.captchaPopup.title = options.title || (options.upgrade ? 'Upgrade Required' : (isNetSlow ? 'Network Slow — Please Try Again' : 'Service Alert'));
        $scope.captchaPopup.upgrade = !!options.upgrade;
        $scope.captchaPopup.errorCode = inferredCode;
        $scope.captchaPopup.refId = refId;
        $scope.captchaPopup.statusLabel = options.upgrade ? 'Plan / Credit Alert' : (isNetSlow ? 'Auto-Saved · Ready to Resume' : 'Support Assisted');
        $scope.captchaPopup.timeText = nowTimeText;
        $scope.captchaPopup.copied = false;
        $scope.captchaPopup.supportEmail = options.supportEmail || PocketLeadsConfig.supportEmail;
        $scope.captchaPopup.purchaseUrl = 'mailto:' + $scope.captchaPopup.supportEmail + '?subject=PocketLeads%20Buy%20Credits';

        // Record customer-safe entry in local notifications/diagnostics
        try {
            if (!$scope.local) $scope.local = {};
            if (!$scope.local.apifyQueue) $scope.local.apifyQueue = {};
            const q = $scope.local.apifyQueue;
            q.lastErrorCode = inferredCode;
            q.lastErrorDetail = customerMsg;
            q.lastErrorAt = nowIsoStr;
            if (!Array.isArray(q.liveSpyEvents)) q.liveSpyEvents = [];
            const lastEv = q.liveSpyEvents[0];
            if (!lastEv || lastEv.message !== customerMsg || (Date.now() - Number(lastEv.ts || 0) > 8000)) {
                q.liveSpyEvents.unshift({
                    ts: Date.now(),
                    iso: nowIsoStr,
                    time: nowTimeText,
                    level: 'error',
                    type: refId,
                    provider: 'service',
                    query: String(q.currentQuery || ($scope.local.taskList && $scope.local.taskList[0]) || 'Extraction'),
                    message: customerMsg
                });
                if (q.liveSpyEvents.length > 80) q.liveSpyEvents = q.liveSpyEvents.slice(0, 80);
            }
        } catch (_logErr) {}

        // Only log to backend API Error Logs when it is a real service/extraction error (not "add a search query" or "buy credits")
        const isClientInputPrompt = /please add at least one search query|please activate your licence/i.test(rawTechMsg) || /^(LICENSE_CREDIT_EXHAUSTED|ALL_CREDITS_EXHAUSTED|LICENCE_CREDIT_EXHAUSTED)$/i.test(inferredCode);

        chrome.storage.local.get(['pocketleadsAccount', 'license', 'pocketleadsPreparedRoute'], function(res) {
            const a = (res && res.pocketleadsAccount) || {};
            const l = (res && res.license) || {};
            const rt = (res && res.pocketleadsPreparedRoute) || (a && a.route) || {};
            const licKey = String(a.key || l.key || ($scope.license && $scope.license.key) || '').trim();
            const rawApiId = String(options.apiId || rt.apiId || (a.route && a.route.apiId) || (rt.keyRow ? ('Row-' + rt.keyRow) : '') || 'UNASSIGNED');
            const rawKeyRow = parseInt(options.keyRow || rt.keyRow || rt.apiKeyRow || (a.route && a.route.keyRow), 10) || 0;
            const rawProvider = String(options.provider || rt.provider || (a.providerPriority && a.providerPriority[0]) || ($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.provider) || 'scrappa');
            const rawQuery = String(($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.currentQuery) || ($scope.local && Array.isArray($scope.local.taskList) && $scope.local.taskList[0]) || 'Start Extraction').replace(/~in~/g, ' in ');
            $scope.safeApply(function(){
                $scope.captchaPopup.availableCredit = a.availableCredit;
                $scope.captchaPopup.purchasedCredit = a.purchasedCredit;
                $scope.captchaPopup.licenceKey = licKey || 'Active Licence';
                $scope.captchaPopup.query = rawQuery;
                if (/^https:\/\//i.test(a.purchaseUrl || '')) $scope.captchaPopup.purchaseUrl = a.purchaseUrl;
            });
            if (!isClientInputPrompt && licKey) {
                const alertPayload = {
                    id: refId,
                    timestamp: Date.now(),
                    timeText: new Date().toLocaleString(),
                    licenceKey: licKey,
                    userName: String(a.userName || l.userName || ''),
                    apiId: rawApiId,
                    keyRow: rawKeyRow,
                    provider: rawProvider,
                    httpStatus: 0,
                    errorCode: inferredCode,
                    upstreamCode: String(rt.reason || ''),
                    upstreamError: rawTechMsg,
                    query: rawQuery
                };
                if (typeof window !== 'undefined' && typeof window.PocketLeadsLogAnyIssueToSheet === 'function') {
                    void window.PocketLeadsLogAnyIssueToSheet(alertPayload);
                } else if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
                    try {
                        chrome.runtime.sendMessage({ action: 'pocketleads_log_any_error', alert: alertPayload }, () => {
                            try { void chrome.runtime.lastError; } catch (_) {}
                        });
                    } catch (_) {}
                }
            }
        });
        $scope.captchaPopup.show = true;
    };

    $scope.openSupportFromCaptchaPopup = () => {
        const alertInfo = {
            licenceKey: $scope.captchaPopup.licenceKey || ($scope.license && $scope.license.key) || '',
            refId: $scope.captchaPopup.refId || 'REF-102',
            query: $scope.captchaPopup.query || '',
            timeText: $scope.captchaPopup.timeText || new Date().toLocaleString()
        };
        $scope.closeCaptchaPopup();
        if (typeof window !== 'undefined' && typeof window.PocketLeadsOpenSupportWithIssue === 'function') {
            window.PocketLeadsOpenSupportWithIssue(alertInfo);
        } else {
            const supportBtn = document.querySelector('[data-profile-action="support"]');
            if (supportBtn) supportBtn.click();
        }
    };

    $scope.copyCaptchaPopupError = async () => {
        const text = [
            'PocketLeads Support Reference',
            'Licence Key: ' + ($scope.captchaPopup.licenceKey || 'N/A'),
            'Reference ID: ' + ($scope.captchaPopup.refId || 'REF-102'),
            'Search Task: ' + ($scope.captchaPopup.query || 'N/A'),
            'Status: Please resolve this extraction issue for my account.',
            'Time: ' + ($scope.captchaPopup.timeText || new Date().toLocaleString())
        ].join('\n');
        try {
            await navigator.clipboard.writeText(text);
            $scope.safeApply(() => { $scope.captchaPopup.copied = true; });
            setTimeout(() => { $scope.safeApply(() => { $scope.captchaPopup.copied = false; }); }, 2000);
        } catch (_) {}
    };
    /**
     * Hide the captcha/error popup.  Bound to the close button on the
     * modal.
     */
    // If the hidden preflight completed before Angular finished creating the
    // popup helpers, surface commercial blocks now. This means zero credits can
    // show Upgrade Required immediately after opening the extension, before Start.
    try {
        chrome.storage.local.get('pocketleadsPreflightState', function(res){
            const state = (res && res.pocketleadsPreflightState) || $scope.pendingPreflightCommercialState || {};
            const code = String(state.errorCode || '').toUpperCase();
            const upgrade = !!state.upgradeRequired || /LICENSE_(?:EXPIRED|CREDIT_EXHAUSTED)|LICENCE_(?:EXPIRED|CREDIT_EXHAUSTED)|ALL_CREDITS_EXHAUSTED/.test(code);
            if (upgrade && String(state.status || '') === 'error') {
                $scope.safeApply(function(){
                    const msg = /CREDIT/.test(code)
                        ? 'Your scraping credits are exhausted. Upgrade your plan to continue. Contact ' + (state.supportEmail || PocketLeadsConfig.supportEmail) + '.'
                        : 'Your licence has expired. Contact ' + (state.supportEmail || PocketLeadsConfig.supportEmail) + ' to renew your licence.';
                    $scope.showCaptchaPopup(msg, { title:'Upgrade Required', upgrade:true, supportEmail:state.supportEmail || PocketLeadsConfig.supportEmail });
                });
            }
            $scope.pendingPreflightCommercialState = null;
        });
    } catch (e) {}

    $scope.closeCaptchaPopup = () => {
        // Hide the captcha/error modal
        $scope.captchaPopup.show = false;
        $scope.captchaPopup.upgrade = false;
        $scope.captchaPopup.title = 'Attention Required';
        // Reset any suppression so future stop notifications can fire
        $scope.ignoreNextStopNotification = false;
        // Refresh UI state to re-enable controls after solving captcha
        if (typeof $scope.updateUIState === 'function') {
            $scope.updateUIState();
        }
    };

    /* ------------------------ Expiring Licence & Low Credit Popup ------------------------ */
    const EXPIRING_LICENCE_CREDIT_LIMIT = 1000;
    const EXPIRING_LICENCE_DAYS_LIMIT = 3;
    $scope._expiringPopupDismissedSig = '';
    $scope.expiringPopup = {
        show: false,
        kicker: 'EXPIRING LICENCE ALERT',
        title: 'Expiring Licence Warning',
        message: '',
        isLowCredit: false,
        isExpiringSoon: false,
        remainingCredits: null,
        remainingCreditsText: '—',
        daysLeft: null,
        daysLeftText: 'Active',
        expiryDateText: 'Unlimited',
        supportEmail: PocketLeadsConfig.supportEmail,
        purchaseUrl: 'mailto:' + PocketLeadsConfig.supportEmail + '?subject=PocketLeads%20Licence%20Renewal%20%26%20Credits',
        refreshMessage: ''
    };

    function parseExpiryDateLocalEnd(rawDate) {
        if (!rawDate) return null;
        const text = String(rawDate).trim();
        if (!text || /^(unlimited|lifetime|permanent|none|no\s*expiry|no\s*limit)$/i.test(text)) return null;
        let m = text.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
        if (m) return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), 23, 59, 59, 999);
        m = text.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
        if (m) return new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]), 23, 59, 59, 999);
        const parsed = new Date(text);
        if (isNaN(parsed.getTime())) return null;
        parsed.setHours(23, 59, 59, 999);
        return parsed;
    }

    function resolveRemainingLicenceCredits(account, license, route) {
        const candidates = [
            account && account.availableCredit,
            route && route.licenceCreditRemaining,
            account && account.structuredCredit,
            account && account.googleMapsCredit,
            license && license.availableCredit,
            license && license.structuredCredit,
            license && license.googleMapsCredit
        ];
        for (const val of candidates) {
            if (String(val || '').toLowerCase() === 'unlimited') return 'unlimited';
        }
        const finiteVals = [];
        for (const val of candidates) {
            if (val !== null && typeof val !== 'undefined' && val !== '') {
                const n = Number(String(val).replace(/,/g, ''));
                if (Number.isFinite(n) && n >= 0) finiteVals.push(n);
            }
        }
        if (!finiteVals.length) return null;
        const positiveVals = finiteVals.filter(n => n > 0);
        return positiveVals.length ? positiveVals[0] : finiteVals[0];
    }

    $scope.evaluateExpiringLicenceState = (account, license, route, forceShow) => {
        account = account || {};
        license = license || {};
        route = route || {};
        if (!license.active && !account.active) return false;

        const remainingCredits = resolveRemainingLicenceCredits(account, license, route);
        const isLowCredit = typeof remainingCredits === 'number' && Number.isFinite(remainingCredits) && remainingCredits > 0 && remainingCredits <= EXPIRING_LICENCE_CREDIT_LIMIT;

        const expiryRaw = String(account.expiryDate || license.expiryDate || '').trim();
        let daysLeft = (typeof account.daysRemaining === 'number' && Number.isFinite(account.daysRemaining)) ? account.daysRemaining : null;
        const expiryObj = parseExpiryDateLocalEnd(expiryRaw);
        if (expiryObj) {
            const computedDays = Math.max(0, Math.ceil((expiryObj.getTime() - Date.now()) / (1000 * 60 * 60 * 24)));
            daysLeft = computedDays;
        }
        const isExpiringSoon = typeof daysLeft === 'number' && Number.isFinite(daysLeft) && daysLeft >= 0 && daysLeft <= EXPIRING_LICENCE_DAYS_LIMIT;

        if (!isLowCredit && !isExpiringSoon) {
            $scope.safeApply(() => {
                $scope.expiringPopup.isLowCredit = false;
                $scope.expiringPopup.isExpiringSoon = false;
                if (!forceShow) $scope.expiringPopup.show = false;
            });
            return false;
        }

        const keyId = String(license.key || account.key || 'active');
        const creditBucket = isLowCredit ? (remainingCredits <= 100 ? '100' : remainingCredits <= 500 ? '500' : '1000') : 'ok';
        const daysBucket = isExpiringSoon ? String(daysLeft) : 'ok';
        const sig = keyId + '|cred:' + creditBucket + '|days:' + daysBucket;
        if (!forceShow && $scope._expiringPopupDismissedSig === sig) {
            return false;
        }

        const supportEmail = account.supportEmail || license.supportEmail || PocketLeadsConfig.supportEmail;
        let purchaseUrl = 'mailto:' + supportEmail + '?subject=PocketLeads%20Licence%20Renewal%20%26%20Credits';
        if (/^https:\/\//i.test(account.purchaseUrl || '')) {
            purchaseUrl = account.purchaseUrl;
        }

        const creditsText = remainingCredits === 'unlimited'
            ? 'Unlimited'
            : (typeof remainingCredits === 'number' ? remainingCredits.toLocaleString() : '—');
        const daysText = typeof daysLeft === 'number'
            ? (daysLeft <= 0 ? 'Expires Today' : (daysLeft === 1 ? '1 Day Left' : (daysLeft + ' Days Left')))
            : 'Unlimited';
        const expiryDateText = expiryRaw || (account.validityLabel || license.validityLabel || 'Unlimited');

        let title = 'Expiring Licence Warning';
        let kicker = 'EXPIRING LICENCE ALERT';
        let msg = '';
        if (isLowCredit && isExpiringSoon) {
            kicker = 'LOW CREDITS & EXPIRY ALERT';
            title = 'Licence Expiring Soon & Low Credits';
            msg = 'Your licence has only ' + creditsText + ' credits remaining (≤ 1,000) and will expire in ' + (daysLeft <= 0 ? 'less than 1 day' : (daysLeft + ' day(s)')) + (expiryRaw ? ' on ' + expiryRaw : '') + '. Please renew or top up soon for uninterrupted lead extraction.';
        } else if (isLowCredit) {
            kicker = 'LOW CREDIT ALERT (≤ 1,000)';
            title = 'Expiring Licence Credits Alert';
            msg = 'Your licence has only ' + creditsText + ' credits remaining (≤ 1,000 limit). Please top up or renew your licence soon so your lead extraction continues without interruption.';
        } else {
            kicker = 'EXPIRING WITHIN ' + Math.max(1, daysLeft) + ' DAY' + (daysLeft === 1 ? '' : 'S');
            title = 'Licence Expiring Soon';
            msg = 'Your licence will expire in ' + (daysLeft <= 0 ? 'less than 1 day' : (daysLeft + ' day(s)')) + (expiryRaw ? ' (on ' + expiryRaw + ')' : '') + '. Please renew your licence soon to keep uninterrupted access.';
        }

        $scope.safeApply(() => {
            $scope.expiringPopup.kicker = kicker;
            $scope.expiringPopup.title = title;
            $scope.expiringPopup.message = msg;
            $scope.expiringPopup.isLowCredit = isLowCredit;
            $scope.expiringPopup.isExpiringSoon = isExpiringSoon;
            $scope.expiringPopup.remainingCredits = remainingCredits;
            $scope.expiringPopup.remainingCreditsText = creditsText;
            $scope.expiringPopup.daysLeft = daysLeft;
            $scope.expiringPopup.daysLeftText = daysText;
            $scope.expiringPopup.expiryDateText = expiryDateText;
            $scope.expiringPopup.supportEmail = supportEmail;
            $scope.expiringPopup.purchaseUrl = purchaseUrl;
            $scope.expiringPopup.refreshMessage = '';
            $scope.expiringPopup._currentSig = sig;
            if (!$scope.captchaPopup.show) {
                $scope.expiringPopup.show = true;
            }
        });
        return true;
    };

    $scope.checkExpiringLicencePopup = (forceShow) => {
        try {
            if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;
            chrome.storage.local.get(['license', 'pocketleadsAccount', 'pocketleadsPreparedRoute'], res => {
                if (!res) return;
                $scope.evaluateExpiringLicenceState(res.pocketleadsAccount, res.license, res.pocketleadsPreparedRoute, !!forceShow);
            });
        } catch (e) {}
    };

    $scope.closeExpiringPopup = () => {
        if ($scope.expiringPopup._currentSig) {
            $scope._expiringPopupDismissedSig = $scope.expiringPopup._currentSig;
        }
        $scope.expiringPopup.show = false;
    };

    $scope.refreshExpiringPopupBalance = async () => {
        $scope.expiringPopup.refreshMessage = 'Refreshing licence & credit status...';
        try {
            await PocketLeadsAccount.refresh({ force: true });
            const state = await new Promise(resolve => chrome.storage.local.get(['license', 'pocketleadsAccount', 'pocketleadsPreparedRoute'], resolve));
            $scope._expiringPopupDismissedSig = '';
            const stillExpiring = $scope.evaluateExpiringLicenceState(state.pocketleadsAccount, state.license, state.pocketleadsPreparedRoute, true);
            $scope.safeApply(() => {
                $scope.expiringPopup.refreshMessage = stillExpiring
                    ? 'Status updated from Admin Sheet.'
                    : 'Licence & credits topped up! You are good to go.';
            });
        } catch (e) {
            $scope.safeApply(() => {
                $scope.expiringPopup.refreshMessage = 'Refresh failed. Please try again.';
            });
        }
    };

    if (typeof window !== 'undefined') {
        window.checkExpiringLicencePopup = $scope.checkExpiringLicencePopup;
    }
    setTimeout(() => { $scope.checkExpiringLicencePopup(false); }, 450);
    /* -------------------------------- Captcha/Error Popup -------------------------------- */
    
    // NEW: Function to handle scraping completion
    $scope.handleScrapingComplete = () => {
        /*
         * If the completion popup is suppressed because a WA check
         * started while scraping was still running, update state to
         * indicate scraping has finished but do not surface the
         * completion modal yet.  Instead mark that a completion is
         * pending so that it can be displayed after WA processing
         * completes.  We intentionally avoid setting
         * scrapingCompleteShown here so that the popup will show later.
         */
        if ($scope.suppressScrapingComplete) {
            /*
             * When a completion event is suppressed (usually because a
             * WhatsApp number check is running), we should mark that
             * a completion is pending but we must not prematurely
             * terminate the scraping session.  Previously this branch
             * reset local.status and _taskManager.isWorking to false,
             * which caused openEachStore/openEachStoreFast to abort
             * mid‑run.  Instead, only clear the suppression flag and
             * record that a completion needs to be shown later.  Only
             * if scraping is truly inactive (status and isWorking are
             * both false) should we perform the final cleanup (clear
             * activeQuery, close the search tab and save local).
             */
            // Mark that a completion should be shown after WA ends
            $scope.scrapingCompletePending = true;
            // Clear the suppression flag so subsequent calls will show
            // the popup when appropriate
            $scope.suppressScrapingComplete = false;

            // Determine whether scraping is still active by inspecting
            // the status flags directly.  We avoid using
            // $scope.isScrapingActive() here because that function
            // relies on local.status and _taskManager.isWorking,
            // which may not yet reflect the true state when this
            // handler is invoked (e.g. while a WA run is in progress).
            let stillActive = false;
            try {
                stillActive = !!($scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking)));
            } catch (e) {
                stillActive = false;
            }
            if (!stillActive) {
                // Only when scraping is truly inactive do we reset
                // status flags and perform cleanup.  This ensures we
                // don't interrupt an ongoing scrape when a false
                // completion event fires.
                $scope.local.status = false;
                if ($scope.local._taskManager) {
                    $scope.local._taskManager.isWorking = false;
                }
                $scope.scrapingActive = false;
                // Clear the active query so the UI reflects idle state.
                $scope.local.activeQuery = "";
                // Attempt to close any leftover search tab but ignore
                // failures.  Persist the reset searchTabId so future runs
                // don't attempt to remove a closed tab.
                try {
                    const tabId = $scope.local._taskManager ? $scope.local._taskManager.searchTabId : null;
                    if (tabId && chrome && chrome.tabs && typeof chrome.tabs.remove === 'function') {
                        chrome.tabs.remove(tabId, function() {
                            if (chrome.runtime && chrome.runtime.lastError) {
                                console.warn('handleScrapingComplete (suppressed): tab remove error', chrome.runtime.lastError);
                            }
                        });
                        if ($scope.local._taskManager) {
                            $scope.local._taskManager.searchTabId = null;
                        }
                    }
                } catch (closeErr) {
                    console.warn('handleScrapingComplete (suppressed): failed to close search tab', closeErr);
                }
                // Save a recoverable snapshot for the History modal before persisting.
                try { $scope.recordScrapingHistory('completed', false); } catch (historyErr) { console.warn('history snapshot failed', historyErr); }
                // Persist the updated local model
                try {
                    $scope.saveLocal();
                } catch (saveErr) {
                    console.warn('handleScrapingComplete (suppressed): saveLocal failed', saveErr);
                }
                // Refresh UI state to re-enable controls
                if (typeof $scope.updateUIState === 'function') {
                    $scope.updateUIState();
                }
            }
            return;
        }
        // Avoid duplicate notifications if a completion event is fired
        // multiple times.  Only proceed when the completion flag has
        // not been set.  Once handled we set the flag so that subsequent
        // calls during the same run are ignored.
        if ($scope.scrapingCompleteShown && $scope.completePopup && $scope.completePopup.show) {
            return;
        }
        $scope.scrapingCompleteShown = true;
        $scope._wasRunningInThisSession = false;
        // When scraping finishes we want to surface feedback in the UI,
        // persist a record in the local notifications list, and send an
        // operating system notification.  Wrapping the updates in
        // $scope.$apply ensures Angular notices the changes.
        $scope.safeApply(() => {
            // Reset status flags so the UI shows scraping as idle.
            $scope.local.status = false;
            if ($scope.local._taskManager) {
                $scope.local._taskManager.isWorking = false;
                // Mark scraping as inactive.  This allows WA completion logic to
                // detect that scraping has finished and show final messages.
                $scope.scrapingActive = false;
                // Close any open search tab when scraping completes.  The
                // searchTabId is stored on the task manager.  Removing
                // the tab here prevents stray tabs from lingering after
                // completion on both desktop and mobile.  Guard against
                // undefined chrome.tabs and provide a callback to log
                // runtime errors.
                try {
                    const tabId = $scope.local._taskManager.searchTabId;
                    if (tabId && chrome && chrome.tabs && typeof chrome.tabs.remove === 'function') {
                        chrome.tabs.remove(tabId, function() {
                            if (chrome.runtime && chrome.runtime.lastError) {
                                console.warn('handleScrapingComplete: tab remove error', chrome.runtime.lastError);
                            }
                        });
                        // Reset the stored searchTabId so subsequent runs do not attempt
                        // to close an already removed tab.  Persist the update.
                        $scope.local._taskManager.searchTabId = null;
                        $scope.saveLocal();
                    }
                } catch (closeErr) {
                    console.warn('handleScrapingComplete: failed to close search tab', closeErr);
                }
            }
            $scope.local.activeQuery = "";
            // Initialise the notifications list if it doesn't exist.  The
            // extension persists notifications in chrome.storage.local so
            // that they survive popup reloads.  Each entry contains a
            // type, human‑readable message and ISO timestamp.
            if (!$scope.local._notifications || !$scope.local._notifications.list) {
                $scope.local._notifications = { list: [] };
            }
            try {
                $scope.local._notifications.list.push({
                    type: 'complete',
                    message: ($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.statusMessage) || 'Scraping completed successfully!',
                    timestamp: new Date().toISOString()
                });
            } catch (pushErr) {
                console.warn('Failed to append to notifications list', pushErr);
            }
            // Save a recoverable snapshot for the History modal before persisting.
            try { $scope.recordScrapingHistory('completed', false); } catch (historyErr) { console.warn('history snapshot failed', historyErr); }
            // Persist the updated local model before firing UI updates.
            $scope.saveLocal();
            // Show a completion modal overlay.  This provides a more
            // prominent notification in the UI similar to the captcha
            // overlay.  We intentionally do not show the bottom snackbar
            // here to avoid cluttering the interface.  Users will see
            // the completion popup and receive a desktop notification.
            const completionMessage = ($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.statusMessage)
                ? $scope.local.apifyQueue.statusMessage
                : 'Scraping completed successfully!';
            $scope.showCompletePopup(completionMessage);
            // The controller/background owns the single operating-system
            // notification. Dashboard tabs only render the in-app popup.
            // Refresh button states and other UI indicators.
            if (typeof $scope.updateUIState === 'function') {
                $scope.updateUIState();
            }
            if (typeof $scope.checkExpiringLicencePopup === 'function') {
                setTimeout(() => { $scope.checkExpiringLicencePopup(false); }, 300);
            }
        });
    };

    // ---------------------------------------------------------------------
    // WhatsApp number check completion handler
    //
    // When the WA number check run finishes, reset WA‑specific flags,
    // persist a notification entry, show a completion popup and dispatch a
    // desktop notification.  A `waCompleteShown` guard prevents
    // duplicate handling during a single run (similar to
    // scrapingCompleteShown).
    $scope.waCompleteShown = false;
    $scope.handleWaCheckComplete = (finished, total) => {
        if ($scope.waCompleteShown) {
            return;
        }
        $scope.waCompleteShown = true;
        // Schedule UI updates at the end of the current digest cycle.  Using
        // $evalAsync prevents nested $apply/$digest errors that would
        // otherwise occur when this handler is invoked from within
        // an existing digest (e.g. during wa_check_complete handling).
        $scope.$evalAsync(() => {
            try {
                // Reset WA flags and stop the login waiting prompt
                $scope.waChecking = false;
                $scope.waLoginWaiting = false;
                // Do not overwrite waFinished/waTotal with values from the
                // background.  The UI already maintains correct counts when
                // numbers are appended dynamically and rows are processed.
                // Clear the enqueued rows set and processed count so that the
                // next run starts fresh.  These values are initialised in
                // waNumberCheck when a new check begins.
                $scope.waEnqueuedRows = {};
                $scope.waProcessedCount = 0;
                // Record a notification entry
                if (!$scope.local._notifications || !$scope.local._notifications.list) {
                    $scope.local._notifications = { list: [] };
                }
                try {
                    $scope.local._notifications.list.push({
                        type: 'wa_complete',
                        message: 'WhatsApp number check completed successfully!',
                        timestamp: new Date().toISOString()
                    });
                } catch (pushErr) {
                    console.warn('handleWaCheckComplete: failed to append to notifications', pushErr);
                }
                // Persist the updated local model before firing UI updates.  Use a
                // callback to avoid potential digest conflicts.
                try {
                    $scope.saveLocal();
                } catch (saveErr) {
                    console.warn('handleWaCheckComplete: saveLocal failed', saveErr);
                }
                // Use the existing completion popup for consistency.  We do not
                // show the snackbar here to avoid a bottom bar overlay.  The
                // completion popup and desktop notification provide sufficient
                // feedback.
                try {
                    $scope.showCompletePopup('WhatsApp number check completed successfully!');
                } catch (popupErr) {
                    console.warn('handleWaCheckComplete: showCompletePopup failed', popupErr);
                }
                // Dispatch a desktop notification via the background worker
                try {
                    chrome.runtime.sendMessage({
                        type: 'notify',
                        title: 'WA Number Check Complete',
                        message: 'WhatsApp number check completed successfully!'
                    }, () => {
                        void chrome.runtime.lastError;
                    });
                } catch (notifyErr) {
                    console.warn('handleWaCheckComplete: failed to send notify message', notifyErr);
                }
                // Reset the guard after a brief delay so that subsequent runs can display
                // a new completion popup.  Without this the next run may be suppressed.
                setTimeout(() => {
                    $scope.waCompleteShown = false;
                }, 100);
                // Reset the WA start timestamp so that future scraping
                // completion events are not suppressed due to an old
                // timestamp.  This ensures that if the user performs a new
                // scraping run without starting a WA check, the
                // completion popup is displayed immediately when the
                // scraper finishes.
                try {
                    $scope.waStartTimestamp = 0;
                } catch (tsErr) {
                    // Ignore any assignment errors
                }
            } catch (err) {
                // Log any unexpected errors to the console.  As a fallback,
                // ensure the guard resets so future runs can show the popup.
                console.warn('handleWaCheckComplete: unexpected error', err);
                setTimeout(() => {
                    $scope.waCompleteShown = false;
                }, 100);
            }
        });
    };

    // NEW: Function to handle manual stop
    $scope.manualStopScraping = (stopReason) => {
        console.log("Manual stop requested", stopReason || 'user');
        $scope._lastStopTimerTickMs = 0;
        syncBackgroundAudioKeepAlive(false);
        try {
            if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.setExtractionActive === 'function') {
                window.AndroidChromeBridge.setExtractionActive(false, '');
            }
        } catch (_) {}

        // Mark that a manual stop is in progress.  This flag will
        // suppress any "Scraping stopped" notifications in the event
        // handler and is cleared after the stop has been fully
        // processed.  Without this, restarting WA or scraping during
        // an active session can lead to duplicate or unwanted
        // notifications when the stop event fires.
        $scope.manualStopInProgress = true;

        // Also set ignoreNextStopNotification so that the subsequent
        // scraping_stopped event is treated as suppressed.  This flag
        // complements manualStopInProgress to ensure no toast or
        // desktop notification is shown when the user stops manually.
        $scope.ignoreNextStopNotification = true;
        
        // Request the background script to stop scraping.  Provide a callback
        // to avoid unhandled promise rejection if no background listener
        // responds (e.g. if the background script has unloaded).
        try {
            chrome.runtime.sendMessage({ action: "stop_scraping" }, function() {
                if (chrome.runtime.lastError) {
                    console.warn('stop_scraping message failed', chrome.runtime.lastError);
                }
            });
        } catch (err) {
            console.warn('Error sending stop_scraping', err);
        }
        
        $scope.safeApply(() => {
            $scope.startLaunchPending = false;
            $scope.local.status = false;
            if (!$scope.local._taskManager) $scope.local._taskManager = {};
            $scope.local._taskManager.isWorking = false;
            $scope.local._taskManager.activeTask = 'openMap';
            if (!$scope.local.apifyQueue) $scope.local.apifyQueue = {};
            $scope.local.apifyQueue.status = 'stopped';
            $scope.local.apifyQueue.resumeAvailable = true;
            $scope.resumeAvailable = true;
            $scope.scrapingActive = false;
            if (typeof $scope.updateUIState === 'function') $scope.updateUIState();
            if (stopReason === 'offline') {
                if ($scope.local && $scope.local.apifyQueue) {
                    $scope.local.apifyQueue.statusMessage = 'Stopped: Internet disconnected / Flight Mode. Tap Resume when online.';
                }
                showTopStatusToast('🛑 No Internet / Flight Mode — Extraction stopped immediately', 'warn');
            } else {
                showTopStatusToast('⏸ Extraction paused · Tap Resume to continue', 'warn');
            }
        });
    };
    
    // NEW: Function to handle manual start.  Before initiating a scrape
    // check that a licence is active.  If not, display a prompt and abort
    // the operation.  Otherwise proceed with the original start logic.
    $scope.startConfirmModal = {
        open: false,
        existingLeadsCount: 0,
        newKeywordCount: 0,
        newLocationCount: 0,
        newTotalTasks: 0,
        isRunningNow: false
    };

    $scope.closeStartConfirmModal = function($event) {
        if ($event && typeof $event.stopPropagation === 'function') $event.stopPropagation();
        $scope.startConfirmModal.open = false;
    };

    $scope.confirmStartWithMode = function(mode) {
        $scope.startConfirmModal.open = false;
        if (mode === 'clear') {
            $scope.manualStartScraping({ startMode: 'clear', bypassConfirmModal: true });
        } else if (mode === 'append') {
            $scope.manualStartScraping({ startMode: 'append', bypassConfirmModal: true });
        }
    };

    $scope.manualStartScraping = (options) => {
        const opts = (options && typeof options === 'object') ? options : {};
        if (_saveAsListPersistTimer) {
            clearTimeout(_saveAsListPersistTimer);
            _saveAsListPersistTimer = null;
        }
        const _chosenCountry = String(($scope.local && $scope.local.country) || getPermanentUserSelectedCountry() || '').trim();
        if (!_chosenCountry) {
            const countryMsg = 'Please select your Country first';
            showTopStatusToast('⚠ ' + countryMsg, 'warn');
            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                $scope.snackbar.show(countryMsg);
            }
            try {
                const cEl = document.getElementById($scope.viewMode === 'mobile' ? 'mobileCountrySelect' : 'countrySelect');
                if (cEl) cEl.focus();
            } catch (_) {}
            return;
        }
        if ($scope.local.country !== _chosenCountry) {
            $scope.setCountry(_chosenCountry);
        }

        // Preserve resume state BEFORE rebuilding preview list
        const _resumeQueueBefore = Object.assign({}, ($scope.local && $scope.local.apifyQueue) || {});
        const _pendingTasksBefore = Array.isArray($scope.local.taskList) ? $scope.local.taskList.slice() : [];
        const _signatureBefore = String($scope.local.apifyTaskSignature || '').trim();
        const _pendingProfilesBefore = Array.isArray(_resumeQueueBefore.placeIdQueue) && _resumeQueueBefore.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
        const _resumeErrorCode = String(_resumeQueueBefore.lastErrorCode || '').toUpperCase();
        const _commercialStopBefore = /LICENSE_(?:EXPIRED|CREDIT_EXHAUSTED|INACTIVE)|LICENCE_(?:EXPIRED|CREDIT_EXHAUSTED)|ALL_CREDITS_EXHAUSTED|PREFLIGHT_/i.test(_resumeErrorCode);
        const _resumableBefore = !_commercialStopBefore && (_pendingTasksBefore.length > 0 || _pendingProfilesBefore || !!_resumeQueueBefore.resumeAvailable) && /^(stopped|failed|partial_results|paused_recoverable|memory_recovery|google_pipeline_running|google_pipeline_draining|dataset_saved|streaming_results|serper_streaming|switching_key|api_switching|resuming|no_results|no_results_after_filter)$/i.test(String(_resumeQueueBefore.status || ''));

        // Fast deduplicate & build preview via memoized saveAsList(true)
        const _rawKwLineCount = String(($scope.local && $scope.local.keywordTextarea) || '').split(/\r?\n/).filter(x => x.trim()).length;
        const _rawLocLineCount = String(($scope.local && $scope.local.locationTextarea) || '').split(/\r?\n/).filter(x => x.trim()).length;
        $scope.saveAsList(true);
        const _chkKw = Array.isArray($scope.local.keywordList) ? $scope.local.keywordList : [];
        const _chkLoc = Array.isArray($scope.local.locationList) ? $scope.local.locationList : [];
        if (_chkKw.length < _rawKwLineCount || _chkLoc.length < _rawLocLineCount) {
            $scope.local.keywordTextarea = _chkKw.join('\n');
            $scope.local.locationTextarea = _chkLoc.join('\n');
            _memoKwRaw = $scope.local.keywordTextarea;
            _memoLocRaw = $scope.local.locationTextarea;
            showTopStatusToast('✨ Merged duplicate keywords/locations automatically', 'info');
        }

        if (!_chkKw.length || !_chkLoc.length) {
            const missingMsg = (!_chkKw.length && !_chkLoc.length)
                ? 'Please enter keywords and locations'
                : (!_chkKw.length ? 'Please enter keywords' : 'Please select locations');
            showTopStatusToast('⚠ ' + missingMsg, 'warn');
            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                $scope.snackbar.show(missingMsg);
            }
            return;
        }
        if (!$scope.licenseActive) {
            $scope.showCaptchaPopup("Please activate your licence first");
            return;
        }

        const _freshSignature = computeFastTaskSignature(_chkKw, _chkLoc);
        const _totalTasksCount = _chkKw.length * _chkLoc.length;
        // Strict same-input check: ONLY true if previous signature exists and equals fresh signature!
        const _sameInputs = Boolean(_signatureBefore && _freshSignature && _freshSignature === _signatureBefore);
        const _existingLeadsCount = Math.max(
            Number($scope.local && $scope.local.resultStoreCount) || 0,
            Array.isArray($scope.local && $scope.local.collect) ? $scope.local.collect.length : 0,
            parseInt(_resumeQueueBefore.scrapedCount, 10) || 0
        );
        const _isRunningNow = !!($scope.isScrapingActive() || ($scope.local && $scope.local.status));
        const _hasPrevSessionState = !$scope._isClearedSession && (
            _existingLeadsCount > 0 ||
            _isRunningNow ||
            (parseInt(_resumeQueueBefore.completedTasks, 10) || 0) > 0 ||
            /^(completed|completed_with_errors|stopped|failed|partial_results|paused_recoverable)$/i.test(String(_resumeQueueBefore.status || ''))
        );

        // Exact same-run checkpoint resume (user paused and clicked Resume without modifying inputs)
        const _isExactResume = !opts.startMode && !_isRunningNow && _resumableBefore && _sameInputs && !$scope._isClearedSession;

        // Show Confirmation Modal (Clear Previous Results vs Keep & Append vs Cancel)
        // whenever previous results/session exist and this is NOT an unchanged checkpoint resume
        if (!opts.bypassConfirmModal && !_isExactResume && _hasPrevSessionState) {
            $scope.startConfirmModal = {
                open: true,
                existingLeadsCount: _existingLeadsCount,
                newKeywordCount: _chkKw.length,
                newLocationCount: _chkLoc.length,
                newTotalTasks: _totalTasksCount,
                isRunningNow: _isRunningNow
            };
            $scope.$evalAsync();
            return;
        }

        const chosenMode = opts.startMode || (_isExactResume ? 'resume' : 'clear');
        $scope._isClearedSession = false;

        if (chosenMode === 'clear') {
            // Archive existing leads into Scraping History before clearing
            if ($scope.local && Array.isArray($scope.local.collect) && $scope.local.collect.length > 0) {
                try { $scope.recordScrapingHistory('saved', false); } catch (_) {}
            }
            $scope._canonicalGeneration++;
            $scope._pendingResultEdits.clear();
            clearIndexedDbResultsOnly();
            try {
                chrome.runtime.sendMessage({ action: 'result_store_clear' }, function() { try { void chrome.runtime.lastError; } catch (_) {} });
            } catch (_) {}
            $scope.local.collect = [];
            $scope.local.collectIsPreview = false;
            $scope.local.resultStoreCount = 0;
            $scope._monotonicResultCount = 0;
            $scope._monotonicTaskCompleted = 0;
            $scope._monotonicProgressRunId = '';
            $scope.mobileSelectedMap = {};
            $scope.mobileVisibleLeads = [];
            $scope.mobileTotalFilteredCount = 0;
            $scope.metricCounts = { website: 0, phone_number: 0, email_1: 0 };
            $scope._stopTimerElapsedMs = 0;
            $scope._lastStopTimerTickMs = 0;
            try { localStorage.setItem('pl_stop_active_elapsed_ms', '0'); } catch (_) {}
            $scope.totalScrapingTimeText = '00:00';
            $scope.local.scrapeStartedAt = new Date().toISOString();
            $scope.local.scrapeFinishedAt = '';
            $scope.local.scrapeElapsedMs = 0;
            $scope.local.apifyTaskSignature = _freshSignature;
            $scope.local.apifyTaskTotal = _totalTasksCount;
            $scope.local._startMode = 'clear';
            $scope.saveAsList(true);
            $scope.local.apifyQueue = {
                status: 'preparing',
                statusMessage: 'Starting fresh extraction (0/' + _totalTasksCount + ' tasks)...',
                startedAt: new Date().toISOString(),
                finishedAt: '',
                elapsedMs: 0,
                _activeElapsedMs: 0,
                currentQuery: _chkKw[0] + ' in ' + _chkLoc[0] + ' ' + _chosenCountry,
                currentTaskIndex: 1,
                totalTasks: _totalTasksCount,
                completedTasks: 0,
                apiTasksTotal: _totalTasksCount,
                apiTasksDone: 0,
                apiTasksFailed: 0,
                apiTasksSettled: 0,
                domTotal: 0,
                domProcessed: 0,
                domPending: 0,
                domRunning: 0,
                scrapedCount: 0,
                placeIdQueue: [],
                pincodeStatuses: {},
                resumeAvailable: false,
                lastUpdatedAt: new Date().toISOString()
            };
        } else if (chosenMode === 'append') {
            // Keep all existing leads in IndexedDB & dashboard, reset task counters for the new batch
            $scope._monotonicTaskCompleted = 0;
            $scope._monotonicProgressRunId = '';
            $scope._lastStopTimerTickMs = Date.now();
            $scope.local.scrapeFinishedAt = '';
            $scope.local.apifyTaskSignature = _freshSignature;
            $scope.local.apifyTaskTotal = _totalTasksCount;
            $scope.local._startMode = 'append';
            $scope.saveAsList(true);
            const preservedElapsed = Math.max(0, Number($scope._stopTimerElapsedMs) || parseInt(_resumeQueueBefore._activeElapsedMs || _resumeQueueBefore.elapsedMs, 10) || 0);
            $scope.local.apifyQueue = Object.assign({}, _resumeQueueBefore, {
                status: 'preparing',
                statusMessage: 'Appending new leads (' + _existingLeadsCount + ' preserved · 0/' + _totalTasksCount + ' tasks)...',
                finishedAt: '',
                elapsedMs: preservedElapsed,
                _activeElapsedMs: preservedElapsed,
                currentQuery: _chkKw[0] + ' in ' + _chkLoc[0] + ' ' + _chosenCountry,
                currentTaskIndex: 1,
                totalTasks: _totalTasksCount,
                completedTasks: 0,
                apiTasksTotal: _totalTasksCount,
                apiTasksDone: 0,
                apiTasksFailed: 0,
                apiTasksSettled: 0,
                domTotal: 0,
                domProcessed: 0,
                domPending: 0,
                domRunning: 0,
                scrapedCount: _existingLeadsCount,
                placeIdQueue: [],
                resumeAvailable: false,
                producerDone: false,
                consumerDone: false,
                lastUpdatedAt: new Date().toISOString()
            });
        } else {
            // Exact checkpoint resume
            $scope.local._startMode = 'resume';
            $scope._lastStopTimerTickMs = Date.now();
            if (_pendingTasksBefore.length > 0) {
                $scope.local.taskList = _pendingTasksBefore.slice(0, MAX_UI_TASK_PREVIEW);
            }
            const preservedElapsed = Math.max(0, Number($scope._stopTimerElapsedMs) || parseInt(_resumeQueueBefore._activeElapsedMs || _resumeQueueBefore.elapsedMs, 10) || 0);
            $scope.local.apifyQueue = Object.assign({}, _resumeQueueBefore, {
                status: 'resuming',
                statusMessage: 'Resuming from last pending search/profile checkpoint...',
                elapsedMs: preservedElapsed,
                _activeElapsedMs: preservedElapsed,
                resumeAvailable: false,
                finishedAt: '',
                lastUpdatedAt: new Date().toISOString()
            });
        }

        const _hasResumeProfiles = chosenMode === 'resume' && Array.isArray($scope.local.apifyQueue && $scope.local.apifyQueue.placeIdQueue) && $scope.local.apifyQueue.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
        if ((!$scope.local.taskList || $scope.local.taskList.length === 0) && !_hasResumeProfiles) {
            showTopStatusToast('⚠ Please input Keywords and Location first', 'warn');
            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                $scope.snackbar.show('Please input Keywords and Location first');
            }
            return;
        }
        $scope.local.fastMode = false;
        if (!$scope.local._taskManager) $scope.local._taskManager = {};
        $scope.local._taskManager.activeTask = 'openMap';

        $scope.startLaunchPending = true;
        $scope._wasRunningInThisSession = true;
        $scope.scrapingCompleteShown = false;
        if ($scope.completePopup) $scope.completePopup.show = false;
        $scope.updateProgress();
        if ($scope.viewMode === 'mobile') {
            $scope.setMobileTab('progress');
        }
        $scope.saveLocal(function() {
            $scope.sendMessage('start');
            setTimeout(function() {
                try {
                    const actuallyRunning = !!($scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking)));
                    if ($scope.startLaunchPending && !actuallyRunning) {
                        $scope.$evalAsync(function() {
                            $scope.startLaunchPending = false;
                            if (typeof $scope.updateUIState === 'function') $scope.updateUIState();
                        });
                    }
                } catch (e) {}
            }, 6000);
        });
        // Do not show the bottom snackbar when starting scraping.  The
        // UI state will reflect the running status and a desktop
        // notification will be sent by the background script if
        // necessary.
        // Trigger the UI update asynchronously using $evalAsync.  This
        // schedules updateUIState to run after the current digest cycle
        // completes, preventing `$rootScope:inprog` errors caused by
        // nested $apply/$digest calls.  Calling updateUIState directly
        // here can sometimes trigger a nested digest when this
        // function is invoked inside an ng-click handler during an
        // active digest cycle.
        $scope.$evalAsync(() => {
            if (typeof $scope.updateUIState === 'function') {
                $scope.updateUIState();
            }
        });
    };
    
    // NEW: Listen for scraping events and surface feedback accordingly.
    // Terminal events can arrive through more than one legacy transport. Keep a
    // short event-id/fingerprint guard so one run produces one popup/history row.
    
    try {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage && typeof chrome.runtime.onMessage.addListener === 'function') {
            chrome.runtime.onMessage.addListener(function(msg) {
                if (!msg || typeof msg !== 'object') return;
                if (msg.action === 'PL_SCRAPING_COMPLETE' || msg.event === 'scraping_complete') {
                    const payload = (msg.data && typeof msg.data === 'object') ? msg.data : msg;
                    $scope.$evalAsync(function() {
                        $scope.startLaunchPending = false;
                        $scope._wasRunningInThisSession = true;
                        if ($scope.local) {
                            $scope.local.status = false;
                            if (!$scope.local._taskManager) $scope.local._taskManager = {};
                            $scope.local._taskManager.isWorking = false;
                            if (!$scope.local.apifyQueue) $scope.local.apifyQueue = {};
                            if (payload.message) $scope.local.apifyQueue.statusMessage = String(payload.message);
                            $scope.local.apifyQueue.status = payload.completedWithErrors ? 'completed_with_errors' : 'completed';
                            $scope.local.apifyQueue.resumeAvailable = false;
                        }
                        if (!($scope.completePopup && $scope.completePopup.show)) {
                            $scope.scrapingCompleteShown = false;
                            if (typeof $scope.handleScrapingComplete === 'function') {
                                $scope.handleScrapingComplete();
                            }
                        }
                    });
                }
            });
        }
    } catch (_) {}

    $scope._terminalEventGuard = $scope._terminalEventGuard || {};
    $box.on((event, data) => {
        if (/^(scraping_complete|scraping_error|scraping_stopped)$/.test(String(event || ''))) {
            const payload = data && typeof data === 'object' ? data : {};
            const messagePart = String(payload.message || '').slice(0, 240);
            const eventKey = String(payload.eventId || (event + ':' + messagePart));
            const fingerprintKey = 'fingerprint:' + String(event || '') + ':' + messagePart.toLowerCase();
            const nowMs = Date.now();
            const lastAt = Math.max(
                Number($scope._terminalEventGuard[eventKey] || 0),
                Number($scope._terminalEventGuard[fingerprintKey] || 0)
            );
            if (lastAt && nowMs - lastAt < 15000) {
                console.debug('[PocketLeads] Ignored duplicate terminal event', event, eventKey);
                return;
            }
            $scope._terminalEventGuard[eventKey] = nowMs;
            $scope._terminalEventGuard[fingerprintKey] = nowMs;
            Object.keys($scope._terminalEventGuard).forEach(key => {
                if (nowMs - Number($scope._terminalEventGuard[key] || 0) > 60000) delete $scope._terminalEventGuard[key];
            });
        }
        // When scraping completes, update the UI, persist a notification
        // entry and dispatch a system notification.  Delegating to
        // handleScrapingComplete encapsulates this logic.
        if (event === "scraping_complete") {
            $scope.startLaunchPending = false;
            const completionPayload = data && typeof data === 'object' ? data : {};
            const authoritativeComplete = /:complete$/i.test(String(completionPayload.eventId || ''));
            if (authoritativeComplete) {
                $scope._wasRunningInThisSession = true;
                if (!($scope.completePopup && $scope.completePopup.show)) {
                    $scope.scrapingCompleteShown = false;
                }
            }
            if (authoritativeComplete && $scope.local) {
                // Bring the visible model forward to the controller-owned terminal
                // state immediately. The storage snapshot can arrive a few ms later.
                $scope.local.status = false;
                if (!$scope.local._taskManager) $scope.local._taskManager = {};
                $scope.local._taskManager.isWorking = false;
                if (!$scope.local.apifyQueue) $scope.local.apifyQueue = {};
                if (completionPayload.message) $scope.local.apifyQueue.statusMessage = String(completionPayload.message);
                $scope.local.apifyQueue.status = completionPayload.completedWithErrors ? 'completed_with_errors' : 'completed';
                $scope.local.apifyQueue.resumeAvailable = false;
                $scope.local.apifyQueue.producerDone = true;
                $scope.local.apifyQueue.consumerDone = true;
            }
            const completionQueue = Object.assign({}, ($scope.local && $scope.local.apifyQueue) || {});
            const completionJobs = Array.isArray(completionQueue.placeIdQueue) ? completionQueue.placeIdQueue : [];
            const completionPending = completionJobs.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
            const completionTasksRemain = Array.isArray($scope.local && $scope.local.taskList) && $scope.local.taskList.length > 0;
            const completionApiTotal = Math.max(0, parseInt(completionQueue.apiTasksTotal || completionQueue.totalTasks, 10) || 0);
            const completionApiSettled = Math.max(0, parseInt(completionQueue.apiTasksSettled || completionQueue.completedTasks, 10) || 0);
            const completionGooglePipeline = String(completionQueue.provider || '').toLowerCase() === 'googlemaps' || completionJobs.length > 0 || /^google_pipeline/i.test(String(completionQueue.status || ''));
            // DailyController.complete() emits an eventId ending in :complete only
            // AFTER it has checked task/API/DOM queues and persisted terminal state.
            // Angular's local preview can lag that storage write by one digest; the
            // old UI-side guard then swallowed the only completion event forever.
            // Keep the legacy guard for untrusted/legacy events, but trust the
            // controller-owned terminal event so Download + Close always appears.
            if (!authoritativeComplete && (($scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking))) || completionPending || completionTasksRemain || (completionApiTotal > completionApiSettled) || (completionGooglePipeline && completionApiTotal > 0 && completionQueue.producerDone !== true))) {
                console.debug('[PocketLeads] Ignored legacy premature scraping_complete because queue work remains.');
                if (typeof $scope.updateUIState === 'function') $scope.updateUIState();
                return;
            }
            /*
             * When scraping completes very shortly after starting a WA run,
             * an immediate completion popup can be confusing.  In fast
             * mode the asynchronous notification from the content
             * script may race with the WA start.  Suppress the popup
             * if the last WA run began within the last 5 seconds or
             * if suppressScrapingComplete is flagged.  The suppressed
             * completion will be shown later when WA completes.
             */
            const now = Date.now();
            const waStartedRecently = ($scope.waStartTimestamp && (now - $scope.waStartTimestamp < 5000));
            const waIsRunning = $scope.waChecking;
            if ($scope.suppressScrapingComplete || waStartedRecently || waIsRunning) {
                // Handle completion in suppressed mode.  This updates
                // internal status flags but does not show the popup.  The
                // handleScrapingComplete function will detect
                // suppressScrapingComplete and mark the completion as
                // pending.  We intentionally do not finalise WA here; it
                // will be handled when WA finishes.
                try {
                    $scope.handleScrapingComplete();
                } catch (suppErr) {
                    console.warn('Error handling suppressed scraping complete', suppErr);
                }
                // Do not trigger WA completion or show any popup now.
                return;
            }
            // Scraping has finished.  Process completion and then
            // finalise any pending WA runs.  handleScrapingComplete
            // updates local status and persists notifications.  After
            // that, if a WA run finished earlier and we were waiting
            // for scraping to end, trigger the final WA completion.
            $scope.handleScrapingComplete();
            // If WA is pending and not currently running, show final popup
            $scope.$evalAsync(() => {
                try {
                    if ($scope.waPendingComplete && !$scope.waChecking) {
                        $scope.waPendingComplete = false;
                        $scope.handleWaCheckComplete($scope.waFinished, $scope.waTotal);
                    }
                } catch (waCompleteErr) {
                    console.warn('Error finalising WA after scraping complete', waCompleteErr);
                }
            });
            return;
        }
        // When an error such as a captcha is encountered we display a
        // modal in the dashboard, record a notification entry and
        // dispatch a desktop notification.  The message from the
        // content script is included in both the popup and the
        // notification when available.
        if (event === "scraping_error") {
            $scope.startLaunchPending = false;
            /*
             * Use safeApply here to avoid nested $apply/$digest errors that can
             * occur if a stop is triggered while Angular is already
             * processing an update (for example, during a WA check update or
             * onLocalChange callback).  safeApply executes the callback
             * immediately if a digest is in progress, or wraps it in
             * $apply otherwise.
             */
            $scope.safeApply(() => {
                const msg = (data && data.message) ? data.message : "Unknown error";
                // Set flag so the subsequent scraping_stopped event does not
                // surface an additional stop notification.  This ensures
                // users only see the captcha pause message and not a
                // redundant "Scraping stopped" toast/notification.
                $scope.ignoreNextStopNotification = true;
                // Show a persistent popup so the user can read the
                // captcha/error message and take action.
                const errorCode = String(data && data.errorCode || '');
                const upgrade = !!(data && data.upgradeRequired) || /LICENSE_(?:EXPIRED|CREDIT_EXHAUSTED)/i.test(errorCode);
                $scope.showCaptchaPopup(msg, {
                    title: upgrade ? 'Upgrade Required' : 'Attention Required',
                    upgrade,
                    errorCode,
                    apiId: data && data.apiId || '',
                    keyRow: data && data.keyRow || 0,
                    provider: data && data.provider || '',
                    supportEmail: (data && data.supportEmail) || PocketLeadsConfig.supportEmail
                });
                // Append to the notifications list. Initialise the
                // container if missing or missing the list property.
                if (!$scope.local._notifications || !$scope.local._notifications.list) {
                    $scope.local._notifications = { list: [] };
                }
                try {
                    $scope.local._notifications.list.push({
                        type: 'error',
                        message: msg,
                        timestamp: new Date().toISOString()
                    });
                } catch (pushErr) {
                    console.warn('Failed to append error notification', pushErr);
                }
                $scope.saveLocal();
                // The controller/background owns the single operating-system
                // notification. Avoid one notification per open dashboard tab.
            });
            return;
        }
        // When scraping is manually stopped (either by the user or
        // automatically in the background after an error) update state,
        // surface a snackbar message, persist a notification entry and
        // send a system notification.  Without this, the user might
        // miss the fact that scraping has stopped when the popup is
        // closed or minimised.
        if (event === "scraping_stopped") {
            $scope.startLaunchPending = false;
            $scope.safeApply(() => {
                // Always update status flags and active query so the UI
                // accurately reflects that scraping is no longer running.
                $scope.local.status = false;
                if ($scope.local._taskManager) {
                    $scope.local._taskManager.isWorking = false;
                }
                // Mark scraping as inactive so WA logic knows scraping has ended.
                $scope.scrapingActive = false;
                // Preserve the last query/checkpoint so Resume can continue exactly.
                try {
                    const q = Object.assign({}, $scope.local.apifyQueue || {});
                    const pending = Array.isArray(q.placeIdQueue) && q.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
                    const stopErrorCode = String(q.lastErrorCode || '').toUpperCase();
                    const commercialStop = /LICENSE_(?:EXPIRED|CREDIT_EXHAUSTED|INACTIVE)|LICENCE_(?:EXPIRED|CREDIT_EXHAUSTED)|ALL_CREDITS_EXHAUSTED|PREFLIGHT_/i.test(stopErrorCode);
                    q.resumeAvailable = (!!q.resumeAvailable || pending || (Array.isArray($scope.local.taskList) && $scope.local.taskList.length > 0));
                    if (q.resumeAvailable && !/^(stopped|paused_recoverable)$/i.test(String(q.status || ''))) q.status = 'stopped';
                    $scope.local.apifyQueue = q;
                    if (!$scope.local._taskManager) $scope.local._taskManager = {};
                    $scope.local._taskManager.activeTask = q.resumeAvailable ? 'openMap' : null;
                } catch (e) {}

                // If a manual stop is in progress, do not record a
                // notification or send any system messages.  Simply
                // persist the model, refresh the UI and reset the
                // manualStopInProgress flag.  This ensures that user‑initiated
                // stops do not trigger unwanted "Scraping Stopped"
                // notifications.
                if ($scope.manualStopInProgress) {
                    try { $scope.recordScrapingHistory('stopped', false); } catch (historyErr) { console.warn('history snapshot failed', historyErr); }
                    $scope.saveLocal();
                    $scope.manualStopInProgress = false;
                    if (typeof $scope.updateUIState === 'function') {
                        $scope.updateUIState();
                    }
                    try {
                        if ($scope.waPendingComplete && !$scope.waChecking) {
                            $scope.waPendingComplete = false;
                            $scope.handleWaCheckComplete($scope.waFinished, $scope.waTotal);
                        }
                    } catch (waPendingErr) {
                        console.warn('Error finalising WA after manual stop', waPendingErr);
                    }
                    return;
                }

                // If this stop event immediately follows a captcha pause
                // (indicated by ignoreNextStopNotification), do not record a
                // stop notification or show a snackbar/desktop message.  Just
                // persist the updated model and proceed.
                if ($scope.ignoreNextStopNotification) {
                    try { $scope.recordScrapingHistory('stopped', false); } catch (historyErr) { console.warn('history snapshot failed', historyErr); }
                    $scope.saveLocal();
                } else {
                    // Otherwise record the stop event and send a desktop
                    // notification to inform the user.  Initialise the
                    // notifications list if necessary.
                    if (!$scope.local._notifications || !$scope.local._notifications.list) {
                        $scope.local._notifications = { list: [] };
                    }
                    try {
                        $scope.local._notifications.list.push({
                            type: 'stopped',
                            message: 'Scraping stopped',
                            timestamp: new Date().toISOString()
                        });
                    } catch (pushErr) {
                        console.warn('Failed to append stopped notification', pushErr);
                    }
                    try { $scope.recordScrapingHistory('stopped', false); } catch (historyErr) { console.warn('history snapshot failed', historyErr); }
                    $scope.saveLocal();
                    // Do not dispatch a desktop notification here.  The
                    // dashboard UI will indicate that scraping has stopped
                    // without triggering an external system alert.  This
                    // suppresses a "Scraping Stopped" notification for
                    // both automatic and manual stop events.  Previously
                    // a notify message was sent here, which resulted in
                    // unnecessary alerts.
                }
                // Clear the suppression flag so future stop events behave normally.
                $scope.ignoreNextStopNotification = false;
                // Refresh the UI state (e.g. enable the start button).
                if (typeof $scope.updateUIState === 'function') {
                    $scope.updateUIState();
                }
                // After handling the stop, if a WA run finished earlier and
                // scraping has now ended, complete any pending WA run.
                try {
                    if ($scope.waPendingComplete && !$scope.waChecking) {
                        $scope.waPendingComplete = false;
                        $scope.handleWaCheckComplete($scope.waFinished, $scope.waTotal);
                    }
                } catch (waPendingErr) {
                    console.warn('Error finalising WA after scraping stopped', waPendingErr);
                }
            });
            return;
        }
    });
    
    // NEW: Function to check if scraping is active
    $scope.isScrapingActive = () => {
        // Guard against _taskManager being undefined.  When the local
        // model is initialised from scratch on mobile, _taskManager may
        // not exist until after the first start.  Coerce undefined to
        // false so that the result reflects the correct state.
        return $scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking);
    };

        // The suppression flag has been moved to $scope.ignoreNextStopNotification
        // so that it persists across digest cycles and remains visible to
        // the scraping event handler above.  The separate local
        // declaration is removed to avoid confusion.
    
    $scope.init = ()=>{
        
        // Removed Auth.check: licensing is disabled in this build.  The
        // extension always runs in full mode without contacting any licensing
        // service.  Previously the license was validated here on startup.
        // We keep the delay to preserve timing but do nothing when it fires.
        setTimeout(() => {
            /* no-op */
        }, $fc.randBetween(300, 700));
        
        setTimeout(()=>{     
            $scope.$apply(()=>{
                $scope.local.isScrapingEmail = false;
                // Keep the real service-worker state. The popup/dashboard can be
                // closed and reopened while extraction continues.
                if (!$scope.local._taskManager) {
                    $scope.local._taskManager = { isWorking: false, activeTask: null, searchTabId: null };
                }
                $scope.showItemExtensionFooter = true;
                $scope.updateUIState();
            });
        },200);
        
    };
    
    $scope.refreshTable = ()=>{
        setTimeout(()=>{
            buildDataTable();
        },800);
    };
    
    $scope.percentComplete = () => {
        return $scope.progressData || { completed: 0, total: 0, percent: 0, percentExact: 0 };
    };
    $scope.pagePercent = ()=>{
        let data = {};
        data.total = 20;  
        data.completed = $scope.local.collect.length;
        data.percent = ""+ (data.completed/data.total).toFixed(2);
        data.percent = data.percent.split('.')[1];
        return data;
    };
    
    // Initialize UI state
    $scope.updateUIState();
    
    $scope.init();

    /* -----------------------------------------------------------------------
     * Clear Data Modal Support
     *
     * The dashboard previously cleared all scraped results instantly when the
     * user clicked "Clear Data".  Users requested an option to clear both
     * dashboard data and browsing history.  However, requesting the history
     * permission triggers a prominent "Read and change your browsing history"
     * warning in Chrome.  To avoid this, the extension now only clears
     * dashboard data; any request to clear browser history is ignored.  We
     * still maintain the modal state for future flexibility or UI feedback.
     */

    // Whether the clear data modal is visible
    $scope.showClearDataModal = false;
    // Checkboxes bound to the modal options; default both true (recommended)
    $scope.clearBrowserHistorySelected = true;
    $scope.clearDashboardSelected = true;

    /**
     * Display the Clear Data modal.  This is invoked from the UI when the
     * user clicks the "Clear Data" button.  It resets the checkbox
     * selections to the recommended defaults (both options enabled).
     */
    $scope.openClearDataModal = () => {
        $scope.clearBrowserHistorySelected = true;
        $scope.clearDashboardSelected = true;
        $scope.showClearDataModal = true;
    };

    /**
     * Execute the selected clear data actions.  If the user opts to clear
     * dashboard data we empty the local.collect array, persist to storage and
     * refresh the table.  Browser history is no longer cleared in order to
     * avoid requesting additional permissions that would trigger warning
     * messages.  The clearBrowserHistorySelected flag is therefore ignored.
     * After completion a snackbar notification is shown.
     */
    $scope.executeClearData = () => {
        // v92 authoritative hidden refresh: every Clear Data execution checks
        // this licence's remaining credits and currently eligible provider, then
        // stores only the non-secret prepared route. The Start button never repeats
        // this source-discovery request.
        try {
            chrome.runtime.sendMessage({ action: 'pocketleads_warm_backend', reason: 'clear_data', force: true }, function(){
                try { void chrome.runtime.lastError; } catch (e) {}
            });
        } catch (e) {}
        // Hide the modal immediately
        $scope.showClearDataModal = false;

        // Clear dashboard results if requested
        if ($scope.clearDashboardSelected) {
            $scope._canonicalGeneration++;
            $scope._pendingResultEdits.clear();
            clearTimeout($scope._resultStoreSyncTimer);
            $scope._resultStoreSyncTimer = null;
            /*
             * Cancel any running WhatsApp number check and scraping tasks,
             * wipe all session‑scoped state and reset UI flags so that the
             * start button becomes enabled.  This block ensures that both
             * WhatsApp and scraping progress are fully cleared when the user
             * chooses to clear the dashboard.
             */
            // If scraping is currently active, mark that we are performing
            // a manual stop as part of the clear operation.  This will
            // suppress any "Scraping stopped" notifications when the
            // stop event is processed.  Only set these flags when there
            // is an active run; otherwise they remain false.  These flags
            // will be reset either in the scraping_stopped handler or at
            // the end of this clearData function for inactive sessions.
            const activeScraping = $scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking));
            if (activeScraping) {
                $scope.manualStopInProgress = true;
                $scope.ignoreNextStopNotification = true;
            }
            try {
                // Stop any ongoing WA check via the background script
                chrome.runtime.sendMessage({ action: 'stop_wa_check' }, function() {});
            } catch (err) {
                // suppress errors when stopping WA
            }
            try {
                // Stop scraping via the background script
                chrome.runtime.sendMessage({ action: 'stop_scraping', clearData: true }, function() {});
                // Broadcast stop_scraping to content scripts immediately
                if (typeof $scope.sendMessage === 'function') {
                    $scope.sendMessage('stop_scraping');
                }
            } catch (err) {
                console.warn('executeClearData: failed to send stop_scraping', err);
            }
            // Remove all collected results and reset session data.
            $scope.local.collect = [];
            $scope.local.collectIsPreview = false;
            $scope.local.resultStoreCount = 0;
            $scope._monotonicResultCount = 0;
            $scope._monotonicTaskCompleted = 0;
            $scope._monotonicProgressRunId = '';
            $scope.mobileSelectedMap = {};
            try { refreshDashboardMetricCounts([]); } catch (e) {}
            $scope.local.resultStoreMigrated = true;
            $scope.resultStoreHydrated = false;
            $scope._lastResultStoreSyncSignature = '';
            $scope._resultStoreRowHashes = new Map();
            try { clearIndexedDbResultsOnly(); } catch (_) {}
            try {
                chrome.runtime.sendMessage({ action: 'result_store_clear' }, function() { try { void chrome.runtime.lastError; } catch (e) {} });
            } catch (e) {}
            $scope.local.apifyQueue = {
                status: 'idle',
                statusMessage: 'Cleared. Ready for a fresh run.',
                currentQuery: '',
                currentProfileUrl: '',
                totalPlaceIds: 0,
                totalApiResults: 0,
                totalTasks: 0,
                completedTasks: 0,
                apiSwitchCount: 0,
                scrapedCount: 0,
                failedCount: 0,
                filteredCount: 0,
                duplicateSkippedCount: 0,
                apiKeyRow: 0,
                apiUsageBefore: 0,
                apiUsageAfter: 0,
                apiUsageLimit: 0,
                pendingPlaceIds: [],
                processing: null,
                completed: [],
                failed: [],
                retryCount: {},
                apiTasksTotal: 0,
                apiTasksDone: 0,
                apiTasksFailed: 0,
                apiTasksSettled: 0,
                domTotal: 0,
                domProcessed: 0,
                domPending: 0,
                domRunning: 0,
                placeIdQueue: [],
                resumeAvailable: false,
                producerDone: false,
                consumerDone: false,
                managedTabIds: [],
                lastUpdatedAt: new Date().toISOString()
            };
            $scope.local.apifySeenKeys = [];
            $scope.local.apifyLastDatasetId = '';
            $scope.local.apifyLastRunId = '';
            // Reset scraping status flags
            $scope.local.status = false;
            if (!$scope.local._taskManager) {
                $scope.local._taskManager = {};
            }
            // Fully reset the task manager state.  Clearing isWorking is not
            // sufficient when starting a brand new scrape: the activeTask,
            // searchTabId and scrapeStarted properties may retain values
            // from the previous session.  Leaving these fields populated can
            // cause inconsistent behaviour, such as resuming from a stale
            // task or failing to initiate fast mode scraping.  Explicitly
            // reset these fields so the next start begins from a clean
            // state.  Note: searchTabId is used by the content script to
            // open Google Maps in a specific tab; clearing it ensures a
            // fresh tab is opened on the next run.
            $scope.local._taskManager.isWorking = false;
            $scope.local._taskManager.activeTask = null;
            $scope.local._taskManager.searchTabId = null;
            $scope.local._taskManager.scrapeStarted = false;
            $scope.scrapingActive = false;
            // Clear the active query context
            try {
                $scope.local.activeQuery = "";
            } catch (err) {
                // ignore assignment errors
            }
            // Reset scraping progress metrics
            if ($scope.progressData) {
                $scope.progressData.completed = 0;
                $scope.progressData.total = 0;
                $scope.progressData.percent = 0;
            }
            // Reset all WhatsApp checking state and counters
            $scope.waChecking = false;
            $scope.waLoginWaiting = false;
            $scope.waPendingComplete = false;
            $scope.waCompletedRows = {};
            $scope.waEnqueuedRows = {};
            $scope.waCompletedIds = {};
            $scope.waEnqueuedIds = {};
            $scope.waDiscoveredIds = {};
            $scope.waFinished = 0;
            $scope.waTotal = 0;
            $scope.waInitialTotal = 0;
            $scope.waProcessedCount = 0;
            $scope.waCompleteShown = false;
            $scope.waStartTimestamp = 0;
            if ($scope.whatsappProgress) {
                $scope.whatsappProgress.total = 0;
                $scope.whatsappProgress.completed = 0;
                $scope.whatsappProgress.percent = 0;
            }
            // Clear any lingering whatsapp_status values on rows (defensive)
            try {
                ($scope.local.collect || []).forEach(r => {
                    if (r && typeof r === 'object' && 'whatsapp_status' in r) {
                        r.whatsapp_status = '';
                    }
                });
            } catch (err) {
                // ignore errors when clearing statuses
            }
            // Close any open search tab
            try {
                if (typeof $scope.closeSearchTab === 'function') {
                    $scope.closeSearchTab();
                }
            } catch (err) {
                // ignore errors closing search tab
            }
            // Reset scraping delay slider to default
            try {
                $scope.local.delayTime = 1;
            } catch (err) {
                // ignore assignment errors
            }

            // Rebuild the task list from the current keyword and location lists.  During
            // scraping the taskList is consumed by shift() calls and may
            // become empty or partially depleted.  Without rebuilding the
            // list here a subsequent scrape would operate on an empty or
            // truncated task list, leading to missing or inconsistent
            // results.  Construct the Cartesian product of keywordList and
            // locationList exactly as in saveAsList().  Preserve the
            // existing keyword/location arrays, removing only empty lines.
            try {
                const kwList = Array.isArray($scope.local.keywordList) ? $scope.local.keywordList.filter(x => x) : [];
                const locList = Array.isArray($scope.local.locationList) ? $scope.local.locationList.filter(x => x) : [];
                let tasks = [];
                if (kwList.length && locList.length) {
                    kwList.forEach(keyword => {
                        locList.forEach(location => {
                            tasks.push(`${keyword}~in~${location}`);
                        });
                    });
                } else if (kwList.length) {
                    tasks = kwList.slice();
                }
                $scope.local.taskList = tasks.slice(0, MAX_UI_TASK_PREVIEW);
                $scope.local.apifyTaskTotal = kwList.length * locList.length;
                $scope.local.apifyTaskSignature = computeFastTaskSignature(kwList, locList);
            } catch (rebuildErr) {
                console.warn('executeClearData: failed to rebuild task list', rebuildErr);
            }
            // Persist the cleared model and refresh the table
            $scope.saveLocal();
            if (typeof $scope.refreshTable === 'function') {
                $scope.refreshTable();
            }
            // Update UI state so controls reflect the reset state
            if (typeof $scope.updateUIState === 'function') {
                $scope.updateUIState();
            }
        }

        // Clearing browser history has been removed.  The extension no longer
        // requests the 'history' permission, so we intentionally do not delete
        // any entries from the browser's history.  This prevents permission
        // warnings like "Read and change your browsing history".

        // Provide feedback to the user
        if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
            $scope.snackbar.show('Selected data cleared successfully');
        }
    };

    /**
     * Directly clear both dashboard data and extension‑specific history without
     * showing the options modal.  This helper ensures that both flags are
     * enabled before calling executeClearData().  It is invoked when the
     * user clicks the Clear Data button in the UI.
     */
    function clearIndexedDbResultsOnly() {
        try {
            if (typeof indexedDB !== 'undefined') {
                const req0 = indexedDB.open('PocketLeadsDB');
                req0.onsuccess = function() {
                    try {
                        const db = req0.result;
                        const stores = [];
                        if (db.objectStoreNames.contains('results')) stores.push('results');
                        if (db.objectStoreNames.contains('jobs')) stores.push('jobs');
                        if (stores.length) {
                            const tx = db.transaction(stores, 'readwrite');
                            stores.forEach(s => { try { tx.objectStore(s).clear(); } catch (_) {} });
                        }
                    } catch (_) {}
                };
                const req = indexedDB.open('pocketleads_results_v1');
                req.onsuccess = (ev) => {
                    try {
                        const db = ev.target.result;
                        const stores = Array.from(db.objectStoreNames || []).filter(s => s !== 'history' && s !== 'history_rows');
                        if (stores.length) {
                            const tx = db.transaction(stores, 'readwrite');
                            stores.forEach(s => { try { tx.objectStore(s).clear(); } catch (_) {} });
                        }
                    } catch (_) {}
                };
                // Also wipe request_journal IndexedDB so stale scrape transaction journals don't bloat app storage
                const jReq = indexedDB.open('pocketleads_request_journal');
                jReq.onsuccess = (ev) => {
                    try {
                        const db = ev.target.result;
                        const stores = Array.from(db.objectStoreNames || []);
                        if (stores.length) {
                            const tx = db.transaction(stores, 'readwrite');
                            stores.forEach(s => { try { tx.objectStore(s).clear(); } catch (_) {} });
                        }
                    } catch (_) {}
                };
            }
        } catch (_) {}
        // Wipe all in-memory URL open caches, website scrape caches, photo queues, and blob caches
        try { if (typeof websiteScrapeCache !== 'undefined' && websiteScrapeCache) websiteScrapeCache.clear(); } catch (_) {}
        try { if (typeof photoEnrichAttempted !== 'undefined' && photoEnrichAttempted) photoEnrichAttempted.clear(); } catch (_) {}
        try { if (typeof photoEnrichQueue !== 'undefined' && Array.isArray(photoEnrichQueue)) photoEnrichQueue.length = 0; } catch (_) {}
        try {
            if (typeof emailControllers !== 'undefined' && emailControllers) {
                emailControllers.forEach(c => { try { c.abort(); } catch (_) {} });
                emailControllers.clear();
            }
        } catch (_) {}
        try { window.__plLastExportedSheet = null; } catch (_) {}
        try { if (typeof window.__plClearRuntimeCaches === 'function') window.__plClearRuntimeCaches(); } catch (_) {}
        try {
            if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.clearBrowsingCache === 'function') {
                window.AndroidChromeBridge.clearBrowsingCache();
            }
        } catch (_) {}
        try {
            if (typeof sessionStorage !== 'undefined') sessionStorage.clear();
        } catch (_) {}
        try {
            if (typeof caches !== 'undefined' && caches && typeof caches.keys === 'function') {
                caches.keys().then(keys => {
                    keys.forEach(k => { try { caches.delete(k); } catch (_) {} });
                }).catch(() => {});
            }
        } catch (_) {}
        try {
            if (chrome && chrome.storage && chrome.storage.local) {
                chrome.storage.local.remove([
                    'plSessionSkippedRecords',
                    'plLiveSpySnapshot',
                    'plServerDownAlert',
                    'plPendingProviderRequest',
                    'plTempScrapeCache',
                    'searchTabId'
                ], () => { try { void chrome.runtime.lastError; } catch (_) {} });
            }
        } catch (_) {}
    }

    $scope.clearDataDirect = () => {
        try {
            // Preserve current leads in Scraping History before clearing dashboard
            if ($scope.local && Array.isArray($scope.local.collect) && $scope.local.collect.length > 0) {
                try { $scope.recordScrapingHistory('saved', false); } catch (_) {}
            }
            $scope._isClearedSession = true;
            clearIndexedDbResultsOnly();
            if ($scope.local) {
                $scope.local.scrapeStartedAt = '';
                $scope.local.scrapeFinishedAt = '';
                $scope.local.scrapeElapsedMs = 0;
                $scope.local.apifyTaskTotal = 0;
                $scope.local.apifyTaskSignature = '';
                $scope.local.collect = [];
                $scope.local.collectIsPreview = false;
                $scope.local.resultStoreCount = 0;
                if ($scope.local.apifyQueue) {
                    $scope.local.apifyQueue.startedAt = '';
                    $scope.local.apifyQueue.finishedAt = '';
                    $scope.local.apifyQueue.elapsedMs = 0;
                    $scope.local.apifyQueue._activeElapsedMs = 0;
                    $scope.local.apifyQueue._lastActiveTickMs = 0;
                    $scope.local.apifyQueue.scrapedCount = 0;
                    $scope.local.apifyQueue.totalPlaceIds = 0;
                    $scope.local.apifyQueue.totalApiResults = 0;
                    $scope.local.apifyQueue.totalTasks = 0;
                    $scope.local.apifyQueue.completedTasks = 0;
                    $scope.local.apifyQueue.domTotal = 0;
                    $scope.local.apifyQueue.domProcessed = 0;
                    $scope.local.apifyQueue.domSaved = 0;
                    $scope.local.apifyQueue.resumeAvailable = false;
                    $scope.local.apifyQueue.status = 'idle';
                }
            }
            $scope._monotonicResultCount = 0;
            $scope._monotonicTaskCompleted = 0;
            $scope._stopTimerElapsedMs = 0;
            $scope._lastStopTimerTickMs = 0;
            try { localStorage.setItem('pl_stop_active_elapsed_ms', '0'); } catch (_) {}
            $scope.resumeAvailable = false;
            $scope.isStopEnabled = false;
            $scope.startButtonText = 'Start';
            $scope.totalScrapingTimeText = '00:00';
            $scope.metricCounts = { website: 0, phone_number: 0, email_1: 0 };
            $scope.progressData = { completed: 0, total: 0, percent: 0, percentExact: 0, phase: 'Ready', detail: '' };
            $scope.mobileVisibleLeads = [];
            $scope.mobileTotalFilteredCount = 0;
        } catch (timerClearErr) {}
        $scope.clearDashboardSelected = true;
        $scope.clearBrowserHistorySelected = false;
        $scope.executeClearData();
        showTopStatusToast('✓ Session data, URL cache & browsing cache cleared', 'success');
    };

    /**
     * The old browser-history cleanup button is replaced by the scraping
     * history viewer. This keeps the extension away from browser history
     * deletion and opens the saved scraping session modal instead.
     */
    $scope.clearHistory = () => $scope.openScrapingHistory();


    /**
     * Check scraped phone numbers for WhatsApp availability.  When invoked this
     * function opens WhatsApp Web in a new tab (if not already open) and then
     * communicates with the injected content script to determine whether each
     * phone number is registered on WhatsApp.  Results are stored in the
     * whatsapp_status field of the local.collect records and displayed in the
     * grid.  If the user is not logged into WhatsApp Web, a message is shown
     * prompting them to log in and re‑run the check.
     */
    $scope.whatsappCheck = async () => {
        try {
            if($scope.local.collectIsPreview)$scope.local.collect=await getCompleteRowsForExport();
            // Reset the automatic retry counter when this function is invoked
            // manually.  When invoked via an auto‑retry (waAutoRetry),
            // preserve the existing counter and clear the flag.
            if (!$scope.waAutoRetry) {
                $scope.waRetryCount = 0;
            } else {
                $scope.waAutoRetry = false;
            }

            // Assign a unique identifier to the current run.  Async
            // callbacks capture this identifier and abort if they
            // correspond to an outdated run.
            try {
                $scope.waRunId = ($scope.waRunId || 0) + 1;
            } catch (err) {
                $scope.waRunId = 1;
            }

            // Clear paused and stop flags at the start of every run.
            $scope.local.pausedWhatsapp = false;
            $scope.local.stopWhatsappCheck = false;

            // Build a list of rows that need WhatsApp checking.  Exclude
            // rows whose whatsapp_status is already a final value
            // (Available/Not available).  Normalise each phone number to
            // remove non‑digits and leading zeros, storing the digits on
            // the row for later lookup.  Clear any existing interim
            // statuses on rows that will be checked.
            const rows = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
            const rowsWithPhone = [];
            const phonesForCheck = [];
            rows.forEach((row, idx) => {
                const raw = row && row.phone ? String(row.phone).trim() : '';
                if (!raw) return;
                const status = (row.whatsapp_status || '').toLowerCase();
                if (status === 'available' || status === 'not available') {
                    return;
                }
                let digits = raw.replace(/\D/g, '');
                digits = digits.replace(/^0+/, '');
                if (!digits) return;
                if (String(row.phone).replace(/\D/g, '').replace(/^0+/, '') !== digits) {
                    row.phone = digits;
                }
                row._waDigits = digits;
                phonesForCheck.push(digits);
                // Store the index of this row rather than the object itself.
                rowsWithPhone.push(idx);
                // Clear interim statuses (blank or "Started").
                row.whatsapp_status = '';
            });
            // If there are no rows to check, notify the user and exit.
            if (!phonesForCheck.length) {
                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                    $scope.snackbar.show('No phone numbers to check.');
                }
                return;
            }
            // Prevent starting a new check if one is already in progress.
            if ($scope.local.isCheckingWhatsapp) {
                return;
            }
            // Persist cleared statuses and refresh the grid.
            try {
                if (typeof $scope.saveLocal === 'function') {
                    $scope.saveLocal();
                }
                updateDataTable($scope.local);
            } catch (err) {
                console.warn('whatsappCheck: failed to clear interim statuses', err);
            }
            // Initialise flags and progress tracker for this run.
            $scope.local.stopWhatsappCheck = false;
            $scope.local.isCheckingWhatsapp = true;
            $scope.whatsappProgress = {
                completed: 0,
                total: phonesForCheck.length,
                percent: 0
            };
            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                $scope.snackbar.show('Checking WhatsApp availability for ' + phonesForCheck.length + ' numbers...');
            }

            // Helper that waits for a WhatsApp Web tab to finish loading.  The
            // content script (whatsapp/inject.js) is registered via the
            // manifest and will only be ready once the tab reaches the
            // "complete" state.  This helper polls chrome.tabs.get until the
            // tab’s status is "complete" or until a maximum number of
            // attempts is reached.  When the tab disappears (e.g. the user
            // closed it) the callback is invoked with false.
            function waitForTabReady(tabId, callback, attempts = 60) {
                if (attempts <= 0) {
                    callback(false);
                    return;
                }
                try {
                    chrome.tabs.get(tabId, function(tab) {
                        if (chrome.runtime.lastError || !tab) {
                            callback(false);
                        } else if (tab.status === 'complete') {
                            callback(true);
                        } else {
                            setTimeout(() => waitForTabReady(tabId, callback, attempts - 1), 500);
                        }
                    });
                } catch (err) {
                    callback(false);
                }
            }

            // Start the login check and batch processing once the tab is fully
            // loaded.  Inject the page bridge script into the page context
            // after the load completes.  If the tab fails to load or is
            // closed, attempt to reacquire a new tab via the existing
            // logic.  This helper centralises the waiting logic so that
            // multiple callers can reuse it.
            function startProcessWithTab(tabId) {
                waitForTabReady(tabId, function(isReady) {
                    if (!isReady) {
                        // If the tab never became ready (perhaps it was
                        // closed or the URL changed), try to acquire a
                        // different tab and continue.  We re‑invoke
                        // findOrCreateTab() which will locate an existing
                        // WhatsApp tab or create a new one.  Avoid calling
                        // reacquireTabAndContinue() here because that helper
                        // is scoped inside processBatches and unavailable
                        // outside its closure.
                        try {
                            findOrCreateTab();
                        } catch (e) {
                            console.warn('whatsappCheck: failed to reacquire tab from startProcessWithTab', e);
                            // As a fallback, clear the checking state so the
                            // user can try again.
                            $scope.$apply(() => {
                                $scope.local.isCheckingWhatsapp = false;
                                $scope.local.pausedWhatsapp = false;
                                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                    $scope.snackbar.show('Unable to load WhatsApp Web. Please try again.');
                                }
                                $scope.saveLocal();
                            });
                        }
                        return;
                    }
                    // Inject the bridge script into the page context.  If
                    // injection fails we still proceed with the login check;
                    // the content script alone may be sufficient.
                    try {
                        chrome.scripting.executeScript({
                            target: { tabId: tabId, allFrames: true },
                            files: ['whatsapp/pageBridge.js'],
                            world: 'MAIN'
                        }, function() {
                            try {
                                performLoginAndCheck(tabId);
                            } catch (err) {
                                console.warn('whatsappCheck: error during performLoginAndCheck after bridge injection', err);
                                // If the login check fails after injection, try
                                // to start over by finding or creating a new tab.
                                try {
                                    findOrCreateTab();
                                } catch (e) {
                                    console.warn('whatsappCheck: failed to retry after bridge injection error', e);
                                    $scope.$apply(() => {
                                        $scope.local.isCheckingWhatsapp = false;
                                        $scope.local.pausedWhatsapp = false;
                                        if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                            $scope.snackbar.show('Error communicating with WhatsApp Web.');
                                        }
                                        $scope.saveLocal();
                                    });
                                }
                            }
                        });
                    } catch (err) {
                        console.warn('whatsappCheck: error injecting bridge in startProcessWithTab', err);
                        try {
                            performLoginAndCheck(tabId);
                        } catch (e) {
                            console.warn('whatsappCheck: error invoking performLoginAndCheck from startProcessWithTab', e);
                            try {
                                findOrCreateTab();
                            } catch (err2) {
                                console.warn('whatsappCheck: failed to reacquire tab after performLoginAndCheck error', err2);
                                $scope.$apply(() => {
                                    $scope.local.isCheckingWhatsapp = false;
                                    $scope.local.pausedWhatsapp = false;
                                    if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                        $scope.snackbar.show('Unable to continue WhatsApp check.');
                                    }
                                    $scope.saveLocal();
                                });
                            }
                        }
                    }
                });
            }

            // Process numbers in batches after verifying login.  The delay between
            // batches has been reduced and robust tab/message handling is used to
            // recover from closed tabs or missing receivers without user
            // intervention.  See comments within for details.
            function processBatches(tabId) {
                // Capture the current run identifier so that outdated async
                // callbacks from prior runs can detect when they should no
                // longer update the UI or progress.  whatsappCheck increments
                // $scope.waRunId at the beginning of each invocation.
                const currentRunId = $scope.waRunId;
                // Keep the current WhatsApp tab ID so it can be updated if the tab
                // disappears or a new one is needed.
                let currentTabId = tabId;
                // Process one number at a time to avoid overlapping UI actions.
                const batchSize = 1;
                // No artificial delay between numbers.  The only waits occur within
                // the WhatsApp UI automation itself (500ms after the chat opens
                // and 1s after pasting).  Setting delayMs to 0 allows
                // processing to continue as soon as the previous check
                // completes.
                const delayMs = 0;
                // Iterate through all rows requiring WhatsApp checking.  The
                // index represents the position within rowsWithPhone.  Since
                // rowsWithPhone contains only rows whose whatsapp_status is
                // not yet final (i.e. neither 'Available' nor 'Not available'),
                // there is no need to skip over completed rows when
                // resuming a check.
                let index = 0;
                // The total number of rows that require checking.  This is
                // derived from the list built in whatsappCheck and aligns
                // with whatsappProgress.total.
                const total = $scope.whatsappProgress ? $scope.whatsappProgress.total : 0;
                const updateResults = (results, start) => {
                    // Abort if this update belongs to an old run.  When the user
                    // stops and restarts a WhatsApp check quickly, asynchronous
                    // callbacks from the previous run can still fire.  Use
                    // currentRunId captured in the closure to detect these
                    // stale updates and ignore them.
                    if (currentRunId !== $scope.waRunId) {
                        return;
                    }
                    results = Array.isArray(results) ? results : [];
                    $scope.$apply(() => {
                        let processed = 0;
                        for (let i = 0; i < results.length; i++) {
                            const rowIndex = rowsWithPhone[start + i];
                            const row = Array.isArray($scope.local.collect) ? $scope.local.collect[rowIndex] : undefined;
                            if (!row) continue;
                            const result = results[i] || {};
                            // Preserve any logs sent back from the injected script
                            if (Array.isArray(result.logs)) {
                                row.whatsapp_log = result.logs;
                            }
                            // Assign a final status only when the lookup succeeds.  If
                            // an error is returned (e.g. due to a temporary
                            // communication failure) leave the status blank so that
                            // the row can be retried.  Only increment the processed
                            // counter for successful lookups so that the progress
                            // bar does not reach 100% while blank statuses remain.
                            if (result.error) {
                                row.whatsapp_status = '';
                            } else {
                                row.whatsapp_status = result.exists ? 'Available' : 'Not available';
                                processed++;
                            }
                        }
                        if ($scope.whatsappProgress && $scope.whatsappProgress.total > 0) {
                            $scope.whatsappProgress.completed += processed;
                            const perc = Math.round(($scope.whatsappProgress.completed / $scope.whatsappProgress.total) * 100);
                            $scope.whatsappProgress.percent = perc > 100 ? 100 : perc;
                        }
                        try {
                            if (typeof $scope.saveLocal === 'function') {
                                $scope.saveLocal();
                            }
                            updateDataTable($scope.local);
                        } catch (err) {
                            console.warn('whatsappCheck: failed to update grid after batch', err);
                        }
                    });
                };
                // Helper to reacquire or create a WhatsApp tab and resume processing
                function reacquireTabAndContinue() {
                    try {
                        chrome.tabs.query({ url: ['https://web.whatsapp.com/*', 'https://*.whatsapp.com/*'] }, function(tabs) {
                            if (chrome.runtime.lastError) {
                                console.warn('whatsappCheck: error querying tabs during reacquire', chrome.runtime.lastError);
                                // On failure, cancel remaining rows and stop
                                $scope.$apply(() => {
                                    for (let j = index; j < rowsWithPhone.length; j++) {
                                        const idxRow = rowsWithPhone[j];
                                        if (typeof idxRow !== 'undefined') {
                                            const cancelObj = Array.isArray($scope.local.collect) ? $scope.local.collect[idxRow] : undefined;
                                            if (cancelObj) {
                                                cancelObj.whatsapp_status = 'Cancelled';
                                            }
                                        }
                                    }
                                    if ($scope.whatsappProgress) {
                                        $scope.whatsappProgress.total = 0;
                                        $scope.whatsappProgress.completed = 0;
                                        $scope.whatsappProgress.percent = 0;
                                    }
                                    $scope.local.pausedWhatsapp = true;
                                    $scope.local.isCheckingWhatsapp = false;
                                    if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                        $scope.snackbar.show('WhatsApp Web tab could not be found.');
                                    }
                                    try {
                                        if (typeof $scope.saveLocal === 'function') {
                                            $scope.saveLocal();
                                        }
                                        updateDataTable($scope.local);
                                    } catch (err2) {
                                        console.warn('whatsappCheck: failed to update grid after tab reacquire error', err2);
                                    }
                                });
                                return;
                            }
                            if (tabs && tabs.length > 0) {
                                currentTabId = tabs[0].id;
                                try {
                                    chrome.scripting.executeScript({
                                        target: { tabId: currentTabId, allFrames: true },
                                        files: ['whatsapp/pageBridge.js'],
                                        world: 'MAIN'
                                    }, function() {
                                        setTimeout(() => {
                                            handleBatch();
                                        }, 1000);
                                    });
                                } catch (err) {
                                    console.warn('whatsappCheck: error injecting bridge during reacquire', err);
                                    setTimeout(() => {
                                        handleBatch();
                                    }, 1000);
                                }
                            } else {
                                chrome.tabs.create({ url: 'https://web.whatsapp.com/', active: false }, function(newTab) {
                                    if (newTab && newTab.id != null) {
                                        currentTabId = newTab.id;
                                        try {
                                            setTimeout(() => {
                                                chrome.scripting.executeScript({
                                                    target: { tabId: currentTabId, allFrames: true },
                                                    files: ['whatsapp/pageBridge.js'],
                                                    world: 'MAIN'
                                                }, function() {
                                                    setTimeout(() => {
                                                        handleBatch();
                                                    }, 1000);
                                                });
                                            }, 1000);
                                        } catch (err) {
                                            console.warn('whatsappCheck: error injecting bridge into new tab during reacquire', err);
                                            setTimeout(() => {
                                                handleBatch();
                                            }, 2000);
                                        }
                                    } else {
                                        $scope.$apply(() => {
                                            for (let j = index; j < rowsWithPhone.length; j++) {
                                                const idxRow = rowsWithPhone[j];
                                                if (typeof idxRow !== 'undefined') {
                                                    const cancelObj = Array.isArray($scope.local.collect) ? $scope.local.collect[idxRow] : undefined;
                                                    if (cancelObj) {
                                                        cancelObj.whatsapp_status = 'Cancelled';
                                                    }
                                                }
                                            }
                                            if ($scope.whatsappProgress) {
                                                $scope.whatsappProgress.total = 0;
                                                $scope.whatsappProgress.completed = 0;
                                                $scope.whatsappProgress.percent = 0;
                                            }
                                            $scope.local.pausedWhatsapp = true;
                                            $scope.local.isCheckingWhatsapp = false;
                                            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                                $scope.snackbar.show('Failed to open WhatsApp Web tab.');
                                            }
                                            try {
                                                if (typeof $scope.saveLocal === 'function') {
                                                    $scope.saveLocal();
                                                }
                                                updateDataTable($scope.local);
                                            } catch (err2) {
                                                console.warn('whatsappCheck: failed to update grid after new tab failure', err2);
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    } catch (err) {
                        console.warn('whatsappCheck: unexpected error during tab reacquire', err);
                        $scope.$apply(() => {
                            for (let j = index; j < rowsWithPhone.length; j++) {
                                const idxRow = rowsWithPhone[j];
                                if (typeof idxRow !== 'undefined') {
                                    const cancelObj = Array.isArray($scope.local.collect) ? $scope.local.collect[idxRow] : undefined;
                                    if (cancelObj) {
                                        cancelObj.whatsapp_status = 'Cancelled';
                                    }
                                }
                            }
                            if ($scope.whatsappProgress) {
                                $scope.whatsappProgress.total = 0;
                                $scope.whatsappProgress.completed = 0;
                                $scope.whatsappProgress.percent = 0;
                            }
                            $scope.local.pausedWhatsapp = true;
                            $scope.local.isCheckingWhatsapp = false;
                            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                $scope.snackbar.show('Unexpected error while recovering WhatsApp tab.');
                            }
                            try {
                                if (typeof $scope.saveLocal === 'function') {
                                    $scope.saveLocal();
                                }
                                updateDataTable($scope.local);
                            } catch (err2) {
                                console.warn('whatsappCheck: failed to update grid after unexpected reacquire error', err2);
                            }
                        });
                    }
                }
                const handleBatch = () => {
                    // Skip this batch if it belongs to a previous run.  Without this
                    // guard, an old handleBatch may continue running after the user
                    // has cancelled the check and started a new one, resulting in
                    // gaps or premature completion popups.
                    if (currentRunId !== $scope.waRunId) {
                        return;
                    }
                    if ($scope.local.stopWhatsappCheck) {
                        $scope.$apply(() => {
                            for (let j = index; j < rowsWithPhone.length; j++) {
                                const idxRow = rowsWithPhone[j];
                                if (typeof idxRow !== 'undefined') {
                                    const cancelObj = Array.isArray($scope.local.collect) ? $scope.local.collect[idxRow] : undefined;
                                    if (cancelObj) {
                                        cancelObj.whatsapp_status = 'Cancelled';
                                    }
                                }
                            }
                            if ($scope.whatsappProgress) {
                                $scope.whatsappProgress.total = 0;
                                $scope.whatsappProgress.completed = 0;
                                $scope.whatsappProgress.percent = 0;
                            }
                            $scope.local.pausedWhatsapp = true;
                            $scope.local.isCheckingWhatsapp = false;
                            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                $scope.snackbar.show('WhatsApp number check stopped.');
                            }
                            try {
                                if (typeof $scope.saveLocal === 'function') {
                                    $scope.saveLocal();
                                }
                                updateDataTable($scope.local);
                            } catch (err) {
                                console.warn('whatsappCheck: failed to update grid after stop', err);
                            }
                        });
                        return;
                    }
                        // If the scanning index has reached or passed the end of
                        // rowsWithPhone, then we have examined every row (either
                        // processed or skipped) and the current pass is
                        // complete.
                        if (index >= rowsWithPhone.length) {
                            // Completed one full pass over all numbers.  Determine if
                            // any rows remain without a final status.  Blank or
                            // "Started" statuses indicate that an error occurred
                            // during lookup (e.g. a transient network issue) and
                            // should be retried.  We attempt a limited number of
                            // automatic retries before finalising.  If no blanks
                            // remain, mark the run as complete and show a
                            // completion message.
                            $scope.$apply(() => {
                                try {
                                    // Determine if any phone numbers across the entire collection remain
                                    // without a final status.  We cannot rely solely on rowsWithPhone
                                    // here because the DataTable pagination or prior runs may have
                                    // affected which rows are included.  A row still counts as
                                    // requiring processing if it contains a phone number and its
                                    // whatsapp_status is blank, "started" or any other non‑final
                                    // value (excluding "available" and "not available").
                                    const blanks = [];
                                    const rowsAll = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
                                    for (let ii = 0; ii < rowsAll.length; ii++) {
                                        const r = rowsAll[ii];
                                        // Skip rows without a phone number
                                        if (!r || !r.phone) continue;
                                        const st = String(r.whatsapp_status || '').toLowerCase();
                                        if (st === 'available' || st === 'not available') {
                                            continue;
                                        }
                                        blanks.push(ii);
                                    }
                                    if (blanks.length > 0) {
                                        // Initialise the retry counter if undefined.  This
                                        // counter persists across automatic retries and is
                                        // not reset when the user manually invokes
                                        // whatsappCheck().
                                        if (typeof $scope.waRetryCount === 'undefined') {
                                            $scope.waRetryCount = 0;
                                        }
                                        // Continue retrying blank statuses until all numbers
                                        // are resolved or until a high retry threshold is
                                        // reached.  Do not mark blanks as "Not available" here;
                                        // instead allow additional passes to attempt actual
                                        // lookups.  When the retry threshold is exceeded,
                                        // stop trying further and leave the blanks unresolved.
                                        const RETRY_LIMIT = 5;
                                        if ($scope.waRetryCount < RETRY_LIMIT) {
                                            $scope.waRetryCount++;
                                            // Clear the isChecking flag so the new run can start.
                                            $scope.local.isCheckingWhatsapp = false;
                                            // Save current state before retrying to persist partial results.
                                            if (typeof $scope.saveLocal === 'function') {
                                                $scope.saveLocal();
                                            }
                                            // Schedule another pass after a short delay.  Flag this
                                            // invocation as an auto‑retry so whatsappCheck() does
                                            // not reset the retry counter.
                                            setTimeout(() => {
                                                try {
                                                    $scope.waAutoRetry = true;
                                                    $scope.whatsappCheck();
                                                } catch (e) {
                                                    console.warn('whatsappCheck: error during automatic retry', e);
                                                }
                                            }, 500);
                                            return;
                                        } else {
                                            // Too many retries without resolving blanks.  Do not
                                            // show the completion popup; instead notify the user
                                            // that some numbers could not be processed.  Leave
                                            // unresolved statuses blank so they are obvious in
                                            // the grid.
                                            $scope.local.isCheckingWhatsapp = false;
                                            if ($scope.whatsappProgress) {
                                                // Do not force progress to 100% as the run is
                                                // incomplete.  Leave the progress bar at its
                                                // current value.
                                            }
                                            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                                $scope.snackbar.show('Some numbers could not be processed. Please resume the check.');
                                            }
                                            if (typeof $scope.saveLocal === 'function') {
                                                $scope.saveLocal();
                                            }
                                            updateDataTable($scope.local);
                                            return;
                                        }
                                    }
                                    // At this point either no blanks remain or we have
                                    // filled them with Not available after exhausting
                                    // retries.  Mark the run as complete and display
                                    // the completion message.
                                    $scope.local.isCheckingWhatsapp = false;
                                    // Ensure the progress bar reflects completion.
                                    if ($scope.whatsappProgress) {
                                        $scope.whatsappProgress.completed = $scope.whatsappProgress.total;
                                        $scope.whatsappProgress.percent = 100;
                                    }
                                    if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                        $scope.snackbar.show('WhatsApp number check completed.');
                                    }
                                    if (typeof $scope.saveLocal === 'function') {
                                        $scope.saveLocal();
                                    }
                                    updateDataTable($scope.local);
                                } catch (finalErr) {
                                    console.warn('whatsappCheck: error during finalisation', finalErr);
                                    $scope.local.isCheckingWhatsapp = false;
                                    if (typeof $scope.saveLocal === 'function') {
                                        $scope.saveLocal();
                                    }
                                }
                            });
                            return;
                        }
                    // rowsWithPhone contains only rows that still require
                    // checking, so there is no need to skip over rows with
                    // final statuses here.
                    const start = index;
                    // Resolve the row index and row object from rowsWithPhone.
                    const idxRow = rowsWithPhone[start];
                    const row = Array.isArray($scope.local.collect) ? $scope.local.collect[idxRow] : undefined;
                    const digits = row && row._waDigits ? row._waDigits : null;
                    if (!digits) {
                        // No digits found for this row; mark as not available and continue.
                        $scope.$apply(() => {
                            if (row) {
                                row.whatsapp_status = 'Not available';
                            }
                            try {
                                if (typeof $scope.saveLocal === 'function') {
                                    $scope.saveLocal();
                                }
                                updateDataTable($scope.local);
                            } catch (err) {
                                console.warn('whatsappCheck: failed to mark missing digits row', err);
                            }
                        });
                        index++;
                        setTimeout(handleBatch, delayMs);
                        return;
                    }
                    // Mark this row as started before sending to the content script.
                    (function markStarted() {
                        $scope.$apply(() => {
                            if (row) {
                                row.whatsapp_status = 'Started';
                            }
                            try {
                                if (typeof $scope.saveLocal === 'function') {
                                    $scope.saveLocal();
                                }
                                updateDataTable($scope.local);
                            } catch (err) {
                                console.warn('whatsappCheck: failed to mark row as started', err);
                            }
                        });
                    })();
                    try {
                        chrome.tabs.get(currentTabId, function(tabInfo) {
                            if (chrome.runtime.lastError || !tabInfo) {
                                console.warn('whatsappCheck: current tab invalid before sending batch', chrome.runtime.lastError);
                                reacquireTabAndContinue();
                                return;
                            }
                            chrome.tabs.sendMessage(currentTabId, { action: 'checkPhones', numbers: [digits] }, function(res) {
                                if (chrome.runtime.lastError) {
                                    const err = chrome.runtime.lastError;
                                    console.warn('whatsappCheck: error sending phone batch', err);
                                    const msg = String(err && err.message || '').toLowerCase();
                                    if (msg.includes('no tab with id') || msg.includes('receiving end does not exist') || msg.includes('could not establish connection')) {
                                        // The tab may have closed or the content script may not be ready.
                                        // Wait for the tab to finish loading and retry the batch.  If the
                                        // tab disappears, reacquire or create a new tab and resume.
                                        waitForTabReady(currentTabId, function(ready) {
                                            if (ready) {
                                                setTimeout(() => {
                                                    handleBatch();
                                                }, 1000);
                                            } else {
                                                reacquireTabAndContinue();
                                            }
                                        });
                                        return;
                                    }
                                    // On communication errors, treat this row as not available.
                                    const fallback = [{ exists: false }];
                                    updateResults(fallback, start);
                                    $scope.$apply(() => {
                                        $scope.local.isCheckingWhatsapp = false;
                                        if ($scope.whatsappProgress && $scope.whatsappProgress.total > 0) {
                                            $scope.whatsappProgress.completed = $scope.whatsappProgress.total;
                                            $scope.whatsappProgress.percent = 100;
                                        }
                                        if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                            $scope.snackbar.show('Unable to communicate with WhatsApp Web.');
                                        }
                                        $scope.saveLocal();
                                    });
                                    return;
                                }
                                const results = res && Array.isArray(res.results) ? res.results : [{ exists: false }];
                                updateResults(results, start);
                                // Move to the next row for the next iteration.
                                index++;
                                setTimeout(handleBatch, delayMs);
                            });
                        });
                    } catch (sendErr) {
                        console.warn('whatsappCheck: unexpected error before send', sendErr);
                        reacquireTabAndContinue();
                    }
                };
                handleBatch();
            }

            // Perform login check.  If logged in, begin batch processing.  Retry
            // injection if no receiver is found.  Use a finite number of attempts.
            function performLoginAndCheck(tabId, attempts = 10) {
                try {
                    chrome.tabs.sendMessage(tabId, { action: 'checkLogin' }, function(res) {
                        if (chrome.runtime.lastError) {
                            console.warn('whatsappCheck: no receiver yet', chrome.runtime.lastError);
                            // When the content script is not yet ready, wait for the tab to
                            // finish loading and retry.  Avoid reinjecting the bridge here;
                            // that is handled when the tab first loads.  Decrement
                            // the attempts counter to avoid infinite loops.  If the tab
                            // disappears, attempt to find or create a new WhatsApp tab.
                            if (attempts > 0) {
                                waitForTabReady(tabId, function(ready) {
                                    if (ready) {
                                        setTimeout(() => performLoginAndCheck(tabId, attempts - 1), 1000);
                                    } else {
                                        // Tab is not ready or was closed; start over
                                        try {
                                            findOrCreateTab();
                                        } catch (e) {
                                            console.warn('whatsappCheck: failed to reacquire tab during login retry', e);
                                            $scope.$apply(() => {
                                                // rowsWithPhone contains row indexes; update each row's status via index
                                                rowsWithPhone.forEach(idx => {
                                                    const rowObj = $scope.local.collect && typeof idx === 'number' ? $scope.local.collect[idx] : null;
                                                    if (rowObj) {
                                                        rowObj.whatsapp_status = 'Failed';
                                                    }
                                                });
                                                $scope.local.isCheckingWhatsapp = false;
                                                if ($scope.whatsappProgress && $scope.whatsappProgress.total > 0) {
                                                    $scope.whatsappProgress.completed = $scope.whatsappProgress.total;
                                                    $scope.whatsappProgress.percent = 100;
                                                }
                                                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                                    $scope.snackbar.show('Unable to reach WhatsApp Web.');
                                                }
                                                try {
                                                    updateDataTable($scope.local);
                                                } catch (e2) {
                                                    console.warn('whatsappCheck: failed to refresh grid on receiver exhaustion', e2);
                                                }
                                                $scope.saveLocal();
                                            });
                                        }
                                    }
                                });
                            } else {
                                // Exhausted retries: fail and mark rows as Failed
                                $scope.$apply(() => {
                                    // rowsWithPhone contains row indexes; update each row's status via index
                                    rowsWithPhone.forEach(idx => {
                                        const rowObj = $scope.local.collect && typeof idx === 'number' ? $scope.local.collect[idx] : null;
                                        if (rowObj) {
                                            rowObj.whatsapp_status = 'Failed';
                                        }
                                    });
                                    $scope.local.isCheckingWhatsapp = false;
                                    if ($scope.whatsappProgress && $scope.whatsappProgress.total > 0) {
                                        $scope.whatsappProgress.completed = $scope.whatsappProgress.total;
                                        $scope.whatsappProgress.percent = 100;
                                    }
                                    if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                        $scope.snackbar.show('WhatsApp Web is not responding. Please reload the page and try again.');
                                    }
                                    try {
                                        updateDataTable($scope.local);
                                    } catch (e) {
                                        console.warn('whatsappCheck: failed to refresh grid on receiver exhaustion', e);
                                    }
                                    $scope.saveLocal();
                                });
                            }
                            return;
                        }
                        if (!res || !res.loggedIn) {
                            // If the user is not logged in, immediately stop the process and
                            // notify them via a clear error message.  Do not schedule
                            // retries or leave the progress bar active.  Clear any
                            // outstanding progress and leave row statuses blank so it is
                            // obvious that the check did not run.
                            $scope.$apply(() => {
                                // Reset row statuses for remaining entries
                                // Reset row statuses for remaining entries using indexes
                                rowsWithPhone.forEach(idx => {
                                    const rowObj = $scope.local.collect && typeof idx === 'number' ? $scope.local.collect[idx] : null;
                                    if (rowObj) {
                                        rowObj.whatsapp_status = '';
                                    }
                                });
                                // Reset progress indicators
                                if ($scope.whatsappProgress) {
                                    $scope.whatsappProgress.total = 0;
                                    $scope.whatsappProgress.completed = 0;
                                    $scope.whatsappProgress.percent = 0;
                                }
                                // Clear flags so the UI knows the check has ended
                                $scope.local.pausedWhatsapp = false;
                                $scope.local.isCheckingWhatsapp = false;
                                $scope.local.stopWhatsappCheck = false;
                                // Display an explicit not‑logged‑in message.  Avoid generic
                                // wording so users know why the check ended.
                                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                    $scope.snackbar.show('WhatsApp not logged in');
                                }
                                try {
                                    updateDataTable($scope.local);
                                } catch (e) {
                                    console.warn('whatsappCheck: failed to refresh grid after login check', e);
                                }
                                if (typeof $scope.saveLocal === 'function') {
                                    $scope.saveLocal();
                                }
                            });
                            return;
                        }
                        // logged in
                        processBatches(tabId);
                    });
                } catch (err) {
                    console.warn('whatsappCheck: error sending login message', err);
                    $scope.$apply(() => {
                        $scope.local.isCheckingWhatsapp = false;
                        if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                            $scope.snackbar.show('Failed to communicate with WhatsApp Web.');
                        }
                        $scope.saveLocal();
                    });
                }
            }

            // Find or open a WhatsApp Web tab.  Do not cache the tab ID; always
            // query for existing tabs.  If no tab is found, open one and prompt
            // the user to log in.
            function findOrCreateTab() {
                try {
                    chrome.tabs.query({ url: ['https://web.whatsapp.com/*', 'https://*.whatsapp.com/*'] }, function(tabs) {
                        if (chrome.runtime.lastError) {
                            console.warn('whatsappCheck: error querying tabs', chrome.runtime.lastError);
                            $scope.$apply(() => {
                                $scope.local.isCheckingWhatsapp = false;
                                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                    $scope.snackbar.show('Failed to find WhatsApp Web tab.');
                                }
                                $scope.saveLocal();
                            });
                            return;
                        }
                        if (tabs && tabs.length > 0) {
                            // Use the first existing tab and do not activate it.  Rather than
                            // injecting immediately and starting the login check, wait for the
                            // tab to finish loading and then begin the process via
                            // startProcessWithTab().  This avoids sending messages to
                            // tabs that have not yet finished loading the content script.
                            const tabId = tabs[0].id;
                            startProcessWithTab(tabId);
                        } else {
                            // No WhatsApp tab open; create one in the background.  Do not
                            // activate it so the user’s current tab remains focused.  Once
                            // created, wait for it to load and then inject the bridge and
                            // start processing.  If creation fails, mark rows as failed.
                            chrome.tabs.create({ url: 'https://web.whatsapp.com/', active: false }, function(newTab) {
                                if (newTab && newTab.id != null) {
                                    const newTabId = newTab.id;
                                    // Wait for the tab to load before injecting and starting.
                                    startProcessWithTab(newTabId);
                                } else {
                                    $scope.$apply(() => {
                                    // rowsWithPhone contains row indexes; update each row's status via index
                                    rowsWithPhone.forEach(idx => {
                                        const rowObj = $scope.local.collect && typeof idx === 'number' ? $scope.local.collect[idx] : null;
                                        if (rowObj) {
                                            rowObj.whatsapp_status = 'Failed';
                                        }
                                    });
                                        $scope.local.isCheckingWhatsapp = false;
                                        if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                            $scope.snackbar.show('Unable to open WhatsApp Web.');
                                        }
                                        try {
                                            updateDataTable($scope.local);
                                        } catch (e) {
                                            console.warn('whatsappCheck: failed to refresh grid after tab creation failure', e);
                                        }
                                        $scope.saveLocal();
                                    });
                                }
                            });
                        }
                    });
                } catch (err) {
                    console.warn('whatsappCheck: error during tab lookup or creation', err);
                    $scope.$apply(() => {
                        $scope.local.isCheckingWhatsapp = false;
                        // rowsWithPhone contains row indexes; update each row's status via index
                        rowsWithPhone.forEach(idx => {
                            const rowObj = $scope.local.collect && typeof idx === 'number' ? $scope.local.collect[idx] : null;
                            if (rowObj) {
                                rowObj.whatsapp_status = 'Failed';
                            }
                        });
                        if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                            $scope.snackbar.show('Failed to open WhatsApp Web.');
                        }
                        try {
                            updateDataTable($scope.local);
                        } catch (e) {
                            console.warn('whatsappCheck: failed to refresh grid after tab error', e);
                        }
                        $scope.saveLocal();
                    });
                }
            }
            // Start process by finding or creating a tab
            findOrCreateTab();
        } catch (err) {
            console.warn('whatsappCheck: unexpected error', err);
            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                $scope.snackbar.show('An error occurred during WhatsApp check.');
            }
            $scope.local.isCheckingWhatsapp = false;
            $scope.saveLocal();
        }
    };

    /**
     * Cancel an ongoing WhatsApp number check.  Sets a flag that
     * causes the current batch processor to abort after the current
     * number finishes.  When invoked while a check is in progress,
     * remaining numbers are marked as Cancelled and the progress bar
     * completes.
     */
    $scope.stopWhatsappCheck = function() {
        try {
            if ($scope.local.isCheckingWhatsapp) {
                $scope.local.stopWhatsappCheck = true;
                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                    $scope.snackbar.show('Stopping WhatsApp number check...');
                }
            }
        } catch (err) {
            console.warn('stopWhatsappCheck: error stopping WhatsApp check', err);
        }
    };

    /**
     * Toggle the WhatsApp number check.  When a check is not currently
     * running this will start a new session by invoking whatsappCheck().  If
     * a check is already in progress it will request cancellation via
     * stopWhatsappCheck().  This mirrors the Start/Stop behaviour of the
     * main scraper button so that users only need to click one control to
     * begin or end the WhatsApp lookup process.
     */
    $scope.toggleWhatsappCheck = function() {
        try {
            // If already checking, request a stop.  Otherwise begin a new check.
            if ($scope.local.isCheckingWhatsapp) {
                $scope.stopWhatsappCheck();
            } else {
                $scope.whatsappCheck();
            }
        } catch (err) {
            console.warn('toggleWhatsappCheck: error toggling WhatsApp check', err);
        }
    };

    /**
     * Resume a paused WhatsApp number check.  When invoked this function
     * simply calls whatsappCheck again.  The whatsappCheck logic
     * automatically skips rows that already have a final status and
     * reprocesses any rows marked as Cancelled.  The paused flag is
     * cleared within whatsappCheck.  If no check is currently running
     * this will start a new session; if a check is in progress the
     * resume request is ignored.
     */
    $scope.resumeWhatsappCheck = function() {
        try {
            if (!$scope.local.isCheckingWhatsapp) {
                $scope.whatsappCheck();
            }
        } catch (err) {
            console.warn('resumeWhatsappCheck: error resuming WhatsApp check', err);
        }
    };

    /**
     * Start the WA number check using the local-only workflow.
     *
     * This function collects all phone numbers from the current
     * local.collect array, normalises them to remove non-digits and
     * leading zeros, and sends a message to the background service
     * worker to begin processing.  Each row's index is used as the
     * rowId so that results can be mapped back onto the grid.  Prior
     * statuses are cleared before starting.  If no phone numbers are
     * found a snackbar message is displayed.
     */
    /**
     * Initiate or stop a WhatsApp number check.
     *
     * When not currently running a WA check this function gathers all
     * phone numbers from the current table, clears any existing WA
     * status fields, resets the progress counters and sends a
     * start_wa_check message to the background service worker.  While
     * a WA check is in progress the same button acts as a cancel
     * control.  Clicking during an active check sends a stop_wa_check
     * message and immediately resets the UI state.  Progress is
     * tracked via waTotal and waFinished, and waChecking indicates
     * whether a check is currently running.
     */
    const WA_COUNTRY_DIAL_CODES = {
        'afghanistan': '93', 'albania': '355', 'algeria': '213', 'american samoa': '1', 'andorra': '376',
        'angola': '244', 'anguilla': '1', 'antigua and barbuda': '1', 'argentina': '54', 'armenia': '374',
        'aruba': '297', 'australia': '61', 'austria': '43', 'azerbaijan': '994', 'bahamas': '1',
        'bahrain': '973', 'bangladesh': '880', 'barbados': '1', 'belarus': '375', 'belgium': '32',
        'belize': '501', 'benin': '229', 'bermuda': '1', 'bhutan': '975', 'bolivia': '591',
        'bolivia, plurinational state of': '591', 'bosnia and herzegovina': '387', 'botswana': '267',
        'brazil': '55', 'brunei darussalam': '673', 'bulgaria': '359', 'burkina faso': '226', 'burundi': '257',
        'cabo verde': '238', 'cambodia': '855', 'cameroon': '237', 'canada': '1', 'cayman islands': '1',
        'central african republic': '236', 'chad': '235', 'chile': '56', 'china': '86', 'colombia': '57',
        'comoros': '269', 'congo': '242', 'congo, the democratic republic of the': '243', 'costa rica': '506',
        'croatia': '385', 'cuba': '53', 'cyprus': '357', 'czechia': '420', "côte d'ivoire": '225',
        'denmark': '45', 'djibouti': '253', 'dominica': '1', 'dominican republic': '1', 'ecuador': '593',
        'egypt': '20', 'el salvador': '503', 'equatorial guinea': '240', 'eritrea': '291', 'estonia': '372',
        'eswatini': '268', 'ethiopia': '251', 'fiji': '679', 'finland': '358', 'france': '33',
        'french guiana': '594', 'french polynesia': '689', 'gabon': '241', 'gambia': '220', 'georgia': '995',
        'germany': '49', 'ghana': '233', 'gibraltar': '350', 'greece': '30', 'greenland': '299',
        'grenada': '1', 'guadeloupe': '590', 'guam': '1', 'guatemala': '502', 'guinea': '224',
        'guinea-bissau': '245', 'guyana': '592', 'haiti': '509', 'honduras': '504', 'hong kong': '852',
        'hungary': '36', 'iceland': '354', 'india': '91', 'bharat': '91', 'indonesia': '62',
        'iran, islamic republic of': '98', 'iraq': '964', 'ireland': '353', 'israel': '972', 'italy': '39',
        'jamaica': '1', 'japan': '81', 'jordan': '962', 'kazakhstan': '7', 'kenya': '254',
        'kiribati': '686', 'korea, republic of': '82', 'south korea': '82', 'kuwait': '965', 'kyrgyzstan': '996',
        "lao people's democratic republic": '856', 'latvia': '371', 'lebanon': '961', 'lesotho': '266',
        'liberia': '231', 'libya': '218', 'liechtenstein': '423', 'lithuania': '370', 'luxembourg': '352',
        'macao': '853', 'madagascar': '261', 'malawi': '265', 'malaysia': '60', 'maldives': '960',
        'mali': '223', 'malta': '356', 'marshall islands': '692', 'martinique': '596', 'mauritania': '222',
        'mauritius': '230', 'mexico': '52', 'micronesia, federated states of': '691', 'moldova, republic of': '373',
        'monaco': '377', 'mongolia': '976', 'montenegro': '382', 'morocco': '212', 'mozambique': '258',
        'myanmar': '95', 'namibia': '264', 'nauru': '674', 'nepal': '977', 'netherlands': '31',
        'new caledonia': '687', 'new zealand': '64', 'nicaragua': '505', 'niger': '227', 'nigeria': '234',
        'north macedonia': '389', 'norway': '47', 'oman': '968', 'pakistan': '92', 'palau': '680',
        'palestine, state of': '970', 'panama': '507', 'papua new guinea': '675', 'paraguay': '595',
        'peru': '51', 'philippines': '63', 'poland': '48', 'portugal': '351', 'puerto rico': '1',
        'qatar': '974', 'romania': '40', 'russian federation': '7', 'russia': '7', 'rwanda': '250',
        'saudi arabia': '966', 'senegal': '221', 'serbia': '381', 'seychelles': '248', 'sierra leone': '232',
        'singapore': '65', 'slovakia': '421', 'slovenia': '386', 'solomon islands': '677', 'somalia': '252',
        'south africa': '27', 'south sudan': '211', 'spain': '34', 'sri lanka': '94', 'sudan': '249',
        'suriname': '597', 'sweden': '46', 'switzerland': '41', 'syrian arab republic': '963',
        'taiwan, province of china': '886', 'tajikistan': '992', 'tanzania, united republic of': '255',
        'thailand': '66', 'timor-leste': '670', 'togo': '228', 'tonga': '676', 'trinidad and tobago': '1',
        'tunisia': '216', 'turkmenistan': '993', 'türkiye': '90', 'turkey': '90', 'uganda': '256',
        'ukraine': '380', 'united arab emirates': '971', 'uae': '971', 'united kingdom': '44', 'uk': '44',
        'united states': '1', 'usa': '1', 'us': '1', 'uruguay': '598', 'uzbekistan': '998',
        'vanuatu': '678', 'venezuela, bolivarian republic of': '58', 'viet nam': '84', 'vietnam': '84',
        'yemen': '967', 'zambia': '260', 'zimbabwe': '263'
    };

    function waCountryDialPrefix() {
        const country = String(($scope.local && ($scope.local.country || ($scope.local.apifySettings && $scope.local.apifySettings.countryFilter))) || 'India').trim().toLowerCase();
        return WA_COUNTRY_DIAL_CODES[country] || '91';
    }

    function waNormalizeDigits(value) {
        let digits = String(value || '').replace(/\D/g, '').replace(/^0+/, '');
        return digits;
    }

    function waNumberForApi(rawInput) {
        const rawStr = String(rawInput || '').trim();
        let digits = rawStr.replace(/\D/g, '');
        if (!digits) return '';
        const prefix = String(waCountryDialPrefix() || '91').replace(/\D/g, '') || '91';
        // Strip international 00 prefix (e.g. 0091...)
        if (digits.startsWith('00') && digits.length > 10) {
            digits = digits.replace(/^00+/, '');
        }
        // Strip leading trunk 0s
        digits = digits.replace(/^0+/, '');
        if (!digits) return '';
        if (prefix === '91') {
            // Fix +91 080... / 91098... (13 digits with trunk 0 after 91) -> 12 digits (91 + 10 digits)
            if (/^910+\d{10}$/.test(digits)) {
                return '91' + digits.slice(-10);
            }
            if (/^91\d{10}$/.test(digits)) return digits;
            if (/^\d{10}$/.test(digits)) return '91' + digits;
            // Any >10 digit number in +91 mode: extract last 10 subscriber digits so every number is strictly 12 digits
            if (digits.length > 10) {
                return '91' + digits.slice(-10);
            }
            return '';
        }
        // Generic country prefix trunk-zero fix (e.g., +44 0..., +880 0...)
        if (prefix && digits.startsWith(prefix + '0') && digits.length > prefix.length + 8) {
            digits = prefix + digits.slice(prefix.length).replace(/^0+/, '');
        }
        if (prefix && !digits.startsWith(prefix) && digits.length <= 10) {
            return prefix + digits;
        }
        return digits;
    }

    function waNumberForE164(rawInput) {
        const apiDigits = waNumberForApi(rawInput);
        return apiDigits ? ('+' + apiDigits.replace(/^\++/, '')) : '';
    }

    function waNormalizePhoneForDisplay(value) {
        return waNumberForE164(value);
    }

    function waResultKey(value) {
        const digits = waNormalizeDigits(value);
        if (!digits) return '';
        const prefix = waCountryDialPrefix() || '91';
        if (digits.startsWith('91') && digits.length === 12) return digits.slice(2);
        if (prefix && digits.startsWith(prefix) && digits.length > prefix.length + 6) return digits.slice(prefix.length);
        return digits;
    }

    function waSafeJson(value) {
        if (value === undefined || value === null) return '';
        if (typeof value === 'string') return value;
        if (typeof value === 'number' || typeof value === 'boolean') return String(value);
        try { return JSON.stringify(value); } catch (e) { return String(value); }
    }

    function waParseJsonMaybe(value) {
        if (!value) return null;
        if (typeof value === 'object') return value;
        if (typeof value !== 'string') return null;
        try { return JSON.parse(value); } catch (e) { return null; }
    }

    function waSchemaProperties(schema) {
        schema = waParseJsonMaybe(schema) || schema || {};
        if (schema.data) schema = waParseJsonMaybe(schema.data.inputSchema) || schema.data.inputSchema || schema.data;
        if (schema.inputSchema) schema = waParseJsonMaybe(schema.inputSchema) || schema.inputSchema;
        if (schema.schema) schema = waParseJsonMaybe(schema.schema) || schema.schema;
        if (schema.properties && typeof schema.properties === 'object') return schema.properties;
        return {};
    }

    function waAddSchemaInputVariants(variants, schema, clean, withPlus, prefix) {
        const props = waSchemaProperties(schema);
        const names = Object.keys(props || {});
        if (!names.length) return;
        const phoneNames = names.filter(name => /phone|mobile|number|contact|whatsapp|wa|input|text|list/i.test(name));
        const countryNames = names.filter(name => /country(code)?|dial(code)?|calling(code)?/i.test(name));
        const proxyName = names.find(name => /proxy/i.test(name));
        const addCommon = payload => {
            countryNames.forEach(name => {
                const prop = props[name] || {};
                const type = String(prop.type || '').toLowerCase();
                if (/code|dial|calling/i.test(name) || type === 'integer' || type === 'number') payload[name] = prefix || '91';
                else payload[name] = (($scope.local && $scope.local.country) || 'India');
            });
            if (proxyName && !payload[proxyName]) payload[proxyName] = { useApifyProxy: true };
            return payload;
        };
        phoneNames.forEach(name => {
            const prop = props[name] || {};
            const type = String(prop.type || '').toLowerCase();
            const itemType = prop.items && String(prop.items.type || '').toLowerCase();
            const list = /noPlus|raw|digits/i.test(name) ? clean : withPlus;
            if (type === 'string') {
                variants.push(addCommon({ [name]: list.join('\n') }));
                variants.push(addCommon({ [name]: list.join(',') }));
            } else if (type === 'array' && itemType === 'object') {
                variants.push(addCommon({ [name]: list.map((n, idx) => ({ phone: n, number: n, phoneNumber: n, mobile: n, name: 'Contact ' + (idx + 1) })) }));
            } else {
                variants.push(addCommon({ [name]: list }));
                variants.push(addCommon({ [name]: clean }));
            }
        });
    }

    function waPushUniqueVariant(out, seen, payload) {
        try {
            const key = JSON.stringify(payload);
            if (!seen.has(key)) { seen.add(key); out.push(payload); }
        } catch (e) { out.push(payload); }
    }

    function waBuildInputVariants(numbers, config) {
        const clean = Array.from(new Set((numbers || []).map(waNumberForApi).filter(Boolean)));
        const withPlus = clean.map(n => n.startsWith('+') ? n : '+' + n);
        const prefix = waCountryDialPrefix() || '91';
        const variants = [];
        const schemaVariants = [];
        waAddSchemaInputVariants(schemaVariants, config && config.inputSchema, clean, withPlus, prefix);
        const common = [
            // Many Apify WhatsApp validators require nested snake_case input,
            // for example: { input: { phone_numbers: [...] } }. Keep these first
            // so the known required field is satisfied before trying legacy names.
            { input: { phone_numbers: withPlus, country_code: prefix } },
            { input: { phone_numbers: clean, country_code: prefix } },
            { input: { phone_numbers: withPlus } },
            { input: { phone_numbers: clean } },
            { input: { phone_numbers: withPlus.join('\n'), country_code: prefix } },
            { input: { phone_numbers: clean.join('\n'), country_code: prefix } },
            { input: { numbers: withPlus, countryCode: prefix } },
            { input: { numbers: clean, countryCode: prefix } },
            { input: { phones: withPlus, countryCode: prefix } },
            { input: { phones: clean, countryCode: prefix } },
            { phone_numbers: withPlus, country_code: prefix },
            { phone_numbers: clean, country_code: prefix },
            { phone_numbers: withPlus },
            { phone_numbers: clean },
            { phone_numbers: withPlus.join('\n'), country_code: prefix },
            { phone_numbers: clean.join('\n'), country_code: prefix },
            { phone_number: withPlus.join('\n'), country_code: prefix },
            ...schemaVariants,
            { phoneNumbers: withPlus, countryCode: prefix },
            { numbers: withPlus, countryCode: prefix },
            { phones: withPlus, countryCode: prefix },
            { mobileNumbers: withPlus, countryCode: prefix },
            { whatsappNumbers: withPlus, countryCode: prefix },
            { contacts: withPlus.map((n, idx) => ({ phone: n, number: n, phoneNumber: n, name: 'Contact ' + (idx + 1) })), countryCode: prefix },
            { phoneNumbers: withPlus },
            { numbers: withPlus },
            { phones: withPlus },
            { mobileNumbers: withPlus },
            { whatsappNumbers: withPlus },
            { contacts: withPlus.map((n, idx) => ({ phone: n, number: n, phoneNumber: n, name: 'Contact ' + (idx + 1) })) },
            { phoneNumbers: clean, countryCode: prefix },
            { numbers: clean, countryCode: prefix },
            { phones: clean, countryCode: prefix },
            { phoneNumbers: clean },
            { numbers: clean },
            { phones: clean },
            { phone: withPlus.join('\n'), countryCode: prefix },
            { phones: withPlus.join('\n'), countryCode: prefix },
            { numbers: withPlus.join('\n'), countryCode: prefix },
            { phoneNumbers: withPlus.join('\n'), countryCode: prefix },
            { input: withPlus.join('\n'), countryCode: prefix },
            { text: withPlus.join('\n'), countryCode: prefix },
            { data: withPlus.join('\n'), countryCode: prefix },
            { phoneNumbers: withPlus.join('\n') },
            { input: withPlus.join('\n') },
            { numbers: clean.join('\n') }
        ];
        const seen = new Set();
        common.forEach(payload => waPushUniqueVariant(variants, seen, payload));
        return variants;
    }

    function waEncodeActorId(actorId) {
        let id = String(actorId || '').trim();
        try {
            if (/^https?:\/\//i.test(id)) {
                const url = new URL(id);
                const parts = url.pathname.split('/').filter(Boolean);
                const idx = parts.indexOf('acts');
                if (idx >= 0 && parts[idx + 1]) id = decodeURIComponent(parts[idx + 1]);
            }
        } catch (e) {}
        id = id.replace(/^https?:\/\/api\.apify\.com\/v2\/acts\//i, '').replace(/\/runs.*$/i, '');
        id = id.replace(/^\/+|\/+$/g, '');
        if (id.includes('/') && !id.includes('~')) id = id.split('/').slice(0, 2).join('~');
        return encodeURIComponent(id);
    }

    function waExtractApifyError(payload, text, response) {
        const candidates = [];
        if (payload) {
            candidates.push(payload.message);
            if (payload.error && typeof payload.error === 'object') {
                candidates.push(payload.error.message, payload.error.type, payload.error.details, payload.error);
            } else {
                candidates.push(payload.error);
            }
            if (payload.data && typeof payload.data === 'object') {
                candidates.push(payload.data.message, payload.data.error, payload.data.statusMessage);
            }
        }
        candidates.push(text);
        for (const item of candidates) {
            const msg = waSafeJson(item).trim();
            if (msg && msg !== '{}' && msg !== '[]') return msg;
        }
        return (response.status + ' ' + response.statusText).trim();
    }

    function waIsInputSchemaError(err) {
        const msg = err && err.message ? err.message : String(err || '');
        return (err && err.status === 400) || /input|schema|required|invalid|property|field|must have|type mismatch|not allowed|validation/i.test(msg);
    }

    async function waProviderProxy(config, operation, payload) {
        const licence = await apiLiveGetStoredLicence();
        const key = licence && licence.key ? String(licence.key).trim() : '';
        if (!key) throw new Error('Please activate your licence first.');
        const provider = String(config && config.provider || 'numberchecker').trim().toLowerCase();
        const response = await apiLiveCallAppsScript('providerProxy', {
            key,
            provider,
            keyRow: parseInt(config && (config.apiKeyRow || config.apifyKeyRow), 10) || 0,
            operation,
            payload: payload || {}
        });
        if (!response || response.status !== 'ok') {
            const rawDetail = String((response && (response.message || response.reason)) || 'secure provider proxy failed');
            const dbg = response && response.debugTrace ? response.debugTrace : null;
            const err = new Error(rawDetail);
            err.status = parseInt(response && response.httpStatus, 10) || 0;
            err.code = String((response && (response.errorCode || response.reason || response.status)) || '');
            err.payload = response && response.data;
            err.debugTrace = dbg;
            err.targetUrl = response && response._targetUrl;
            err.elapsedMs = response && response._clientElapsedMs;
            err.rawResponse = response;
            throw err;
        }
        const outData = (response.data && typeof response.data === 'object') ? response.data : { data: response.data };
        outData._clientElapsedMs = response._clientElapsedMs;
        outData._targetUrl = response._targetUrl;
        if (response.debugTrace && !outData.debugTrace) outData.debugTrace = response.debugTrace;
        return outData;
    }

    async function waApifyRequest(url, options, token) {
        throw new Error('Direct Apify requests are disabled in PocketLeads v82. Use secure server proxy.');
    }

    async function waFetchActorInputSchema(config) {
        if (!config || !(config.apiKeyRow || config.apifyKeyRow)) return null;
        try {
            const payload = await waProviderProxy(config, 'getInputSchema', {});
            const data = payload && payload.data ? payload.data : payload;
            const schema = (data && (data.inputSchema || data.input_schema || data.schema)) || data;
            const parsed = waParseJsonMaybe(schema) || schema;
            if (parsed && Object.keys(waSchemaProperties(parsed)).length) return parsed;
        } catch (e) {}
        return null;
    }

    async function waStartApifyRun(config, numbers) {
        if (!config || !(config.apiKeyRow || config.apifyKeyRow)) throw new Error('No active Apify WP API provider found. Sheet me Provider = apify wp api, API Key and Source ID/Actor ID fill karo.');
        if (!config.inputSchema) config.inputSchema = await waFetchActorInputSchema(config).catch(() => null);
        const variants = waBuildInputVariants(numbers, config);
        let lastError = null;
        for (let i = 0; i < variants.length; i += 1) {
            try {
                const payload = await waProviderProxy(config, 'runActor', { input: variants[i], maxItems: Math.max(0, numbers && numbers.length || 0) });
                const run = payload && payload.data ? payload.data : payload;
                if (run && run.id) return run;
                throw new Error('Apify WP API did not return run ID.');
            } catch (err) {
                lastError = err;
                if (!waIsInputSchemaError(err) || i === variants.length - 1) throw err;
            }
        }
        throw lastError || new Error('Apify WP API actor could not be started.');
    }

    function waDatasetIdFromRun(run) {
        return (run && (run.defaultDatasetId ||
            (run.storageIds && run.storageIds.datasets && run.storageIds.datasets.default) ||
            (run.storageIds && run.storageIds.defaultDatasetId))) || '';
    }

    async function waPollRun(config, runId, onPartial, expectedTotal) {
        const started = Date.now();
        const maxMs = Math.max(60000, Math.min(180000, parseInt(config && (config.waMaxWaitMs || config.maxWaitMs), 10) || 120000));
        let lastRun = null;
        let lastPartialRead = 0;
        let lastDatasetId = '';
        let lastReadAt = 0;
        while (Date.now() - started < maxMs) {
            if ($scope.waApiStopRequested) throw new Error('WA API check stopped by user.');
            const payload = await waProviderProxy(config, 'getRun', { runId });
            const run = payload && payload.data ? payload.data : payload;
            lastRun = run;
            const status = String(run && run.status || '').toUpperCase();
            const datasetId = waDatasetIdFromRun(run);
            if (datasetId) lastDatasetId = datasetId;
            const now = Date.now();
            if (datasetId && typeof onPartial === 'function' && now - lastReadAt >= 1200) {
                lastReadAt = now;
                try {
                    const partial = await waFetchDatasetItems(config, datasetId, Math.max(100, expectedTotal || 100));
                    const parsedCount = waCollectParsedResults(partial).length;
                    if (parsedCount > lastPartialRead || partial.length > lastPartialRead) {
                        lastPartialRead = Math.max(parsedCount, partial.length, lastPartialRead);
                        await onPartial(partial, run);
                    }
                } catch (partialErr) {
                    console.warn('WA API partial dataset read failed', partialErr);
                }
            }
            $scope.safeApply(() => {
                const seconds = Math.max(1, Math.round((Date.now() - started) / 1000));
                $scope.waApiStatusText = 'Apify WP API: ' + (status || 'RUNNING') + ' · ' + seconds + 's' + (lastPartialRead ? ' · live ' + lastPartialRead : '');
            });
            if (['SUCCEEDED', 'FAILED', 'ABORTED', 'TIMED-OUT'].includes(status)) {
                if (status !== 'SUCCEEDED') throw new Error('Apify WP API actor failed: ' + status);
                return run;
            }
            await new Promise(resolve => setTimeout(resolve, 700));
        }
        if (lastRun && lastDatasetId && lastPartialRead) {
            lastRun._partialTimeout = true;
            lastRun.defaultDatasetId = lastRun.defaultDatasetId || lastDatasetId;
            return lastRun;
        }
        throw new Error('Apify WP API is still running and no result came within ' + Math.round(maxMs / 1000) + ' sec. Try fewer numbers or check actor speed in Apify.');
    }

    async function waFetchDatasetItems(config, datasetId, limit) {
        if (!datasetId) return [];
        const payload = await waProviderProxy(config, 'getDatasetItems', { datasetId, offset: 0, limit: Math.max(100, limit || 100) });
        return Array.isArray(payload) ? payload : [];
    }

    function waKeyValueStoreIdFromRun(run) {
        return (run && (run.defaultKeyValueStoreId ||
            (run.storageIds && run.storageIds.keyValueStores && run.storageIds.keyValueStores.default) ||
            (run.storageIds && run.storageIds.defaultKeyValueStoreId))) || '';
    }

    async function waFetchRunOutput(config, run) {
        const storeId = waKeyValueStoreIdFromRun(run);
        if (!storeId) return [];
        try {
            const payload = await waProviderProxy(config, 'getKeyValueOutput', { storeId });
            if (Array.isArray(payload)) return payload;
            if (payload && typeof payload === 'object') return [payload];
        } catch (e) {
            const msg = String((e && e.message) || e || '');
            if (!/record was not found|404/i.test(msg)) console.info('WA API optional OUTPUT read skipped:', msg);
        }
        return [];
    }

    function waFlattenResultItems(items) {
        const out = [];
        const seen = new WeakSet();
        const usefulKey = /result|results|data|item|items|output|outputs|contact|contacts|phone|phones|number|numbers|mobile|valid|invalid|whatsapp|wa|exists|registered|records/i;
        function visit(value, depth) {
            if (depth > 7 || value === null || typeof value === 'undefined') return;
            if (Array.isArray(value)) {
                value.forEach(v => visit(v, depth + 1));
                return;
            }
            if (typeof value !== 'object') return;
            if (seen.has(value)) return;
            seen.add(value);
            out.push(value);
            Object.keys(value).forEach(key => {
                const child = value[key];
                if (child && typeof child === 'object' && usefulKey.test(key)) visit(child, depth + 1);
            });
        }
        visit(items, 0);
        return out;
    }

    function waLooksLikePhoneKey(key) {
        const d = waNormalizeDigits(key);
        return d.length >= 8 && d.length <= 15;
    }

    function waObjectPhoneMapResults(obj) {
        const out = [];
        if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return out;
        Object.keys(obj).forEach(key => {
            if (!waLooksLikePhoneKey(key)) return;
            const value = obj[key];
            const statusValue = (value && typeof value === 'object') ? waDeepFindStatus(value, 0) : value;
            out.push({ key: waResultKey(key), status: waStatusFromValue(statusValue, value), raw: waSafeJson({ [key]: value }).slice(0, 500), noKeyEligible: false });
        });
        return out;
    }

    function waLooksLikeWaRecord(item) {
        if (!item || typeof item !== 'object' || Array.isArray(item)) return false;
        const keys = Object.keys(item).join(' ').toLowerCase();
        if (/^status id actid actorid startedat finishedat buildid defaultdatasetid defaultkeyvaluestoreid/.test(keys)) return false;
        if (/\b(defaultdatasetid|defaultkeyvaluestoreid|actid|actorid|buildid|startedat|finishedat|stats|usage)\b/.test(keys) && !/phone|mobile|number|whatsapp|wa|contact/.test(keys)) return false;
        return /phone|mobile|number|whatsapp|wa|valid|registered|exists|available|contact|result/.test(keys);
    }

    function waDeepFindPhone(value, depth) {
        if (depth > 6 || value === null || typeof value === 'undefined') return '';
        if (typeof value === 'string' || typeof value === 'number') {
            const d = waNormalizeDigits(value);
            return d.length >= 8 && d.length <= 15 ? d : '';
        }
        if (Array.isArray(value)) {
            for (const entry of value) {
                const found = waDeepFindPhone(entry, depth + 1);
                if (found) return found;
            }
            return '';
        }
        if (typeof value !== 'object') return '';
        const preferred = ['phone_number','phone_numbers','phoneNumber','phone','number','mobile','mobileNumber','inputPhoneNumber','input_phone_number','whatsappNumber','waNumber','contact','query','input','value'];
        for (const key of preferred) {
            if (Object.prototype.hasOwnProperty.call(value, key)) {
                const found = waDeepFindPhone(value[key], depth + 1);
                if (found) return found;
            }
        }
        for (const key of Object.keys(value)) {
            if (waLooksLikePhoneKey(key)) return waNormalizeDigits(key);
            if (/phone|mobile|number|contact|whatsapp|wa|input|query/i.test(key)) {
                const found = waDeepFindPhone(value[key], depth + 1);
                if (found) return found;
            }
        }
        return '';
    }

    function waDeepFindStatus(value, depth) {
        if (depth > 6 || value === null || typeof value === 'undefined') return undefined;
        if (typeof value !== 'object') return value;
        if (Array.isArray(value)) {
            for (const entry of value) {
                const st = waDeepFindStatus(entry, depth + 1);
                if (typeof st !== 'undefined') return st;
            }
            return undefined;
        }
        // IMPORTANT: phone validators often return { valid: true } even when the
        // WhatsApp result is separate (for example { whatsappCapable: false }).
        // Always read explicit WhatsApp fields before generic phone-valid fields.
        const preferred = ['activated','Activated','whatsappCapable','isWhatsappCapable','isWhatsAppCapable','hasWhatsapp','hasWhatsApp','whatsappAvailable','isWhatsapp','isWhatsApp','is_on_whatsapp','onWhatsApp','is_on_wa','onWa','whatsapp','whatsappExists','wa_status','whatsapp_status','canReceiveMessage','can_receive_message','isRegisteredOnWhatsapp','is_registered_on_whatsapp','available','isAvailable','isRegistered','registered','exists','isValid','valid','result','status','message','is_valid','is_registered','is_available','isBusiness','business'];
        for (const key of preferred) {
            if (Object.prototype.hasOwnProperty.call(value, key)) return value[key];
        }
        for (const key of Object.keys(value)) {
            if (/valid|exist|registered|whatsapp|available|status|result|message/i.test(key)) {
                const st = value[key];
                if (typeof st !== 'object' || st === null) return st;
                const nested = waDeepFindStatus(st, depth + 1);
                if (typeof nested !== 'undefined') return nested;
            }
        }
        return undefined;
    }

    function waExplicitWhatsappStatus(item, depth) {
        if (depth > 6 || item === null || typeof item === 'undefined') return '';
        if (Array.isArray(item)) {
            for (const entry of item) {
                const st = waExplicitWhatsappStatus(entry, depth + 1);
                if (st) return st;
            }
            return '';
        }
        if (typeof item !== 'object') return '';
        const directKeys = ['activated','Activated','whatsappCapable','isWhatsappCapable','isWhatsAppCapable','hasWhatsapp','hasWhatsApp','whatsappAvailable','whatsappExists','isWhatsapp','isWhatsApp','is_on_whatsapp','onWhatsApp','onWa','is_on_wa','canReceiveMessage','can_receive_message','isRegisteredOnWhatsapp','is_registered_on_whatsapp'];
        for (const key of directKeys) {
            if (Object.prototype.hasOwnProperty.call(item, key)) {
                const value = item[key];
                if (value === true) return 'Valid';
                if (value === false) return 'Invalid';
                const txt = String(value === undefined || value === null ? '' : value).trim().toLowerCase();
                if (/^(true|yes|1|valid|available|active|registered|exists|capable|on whatsapp|found)$/i.test(txt)) return 'Valid';
                if (/^(false|no|0|invalid|unavailable|not available|inactive|not registered|not found|not capable)$/i.test(txt)) return 'Invalid';
                if (/not.*whatsapp|no.*whatsapp|not.*registered|not.*capable|unavailable|invalid/.test(txt)) return 'Invalid';
                if (/whatsapp.*true|on whatsapp|registered.*whatsapp|capable|available|valid/.test(txt)) return 'Valid';
            }
        }
        // Some actors return a generic `whatsapp` object/string. Read it, but
        // do not let unrelated `valid:true` override a WhatsApp-specific false.
        if (Object.prototype.hasOwnProperty.call(item, 'whatsapp')) {
            const value = item.whatsapp;
            if (value === true) return 'Available';
            if (value === false) return 'Not available';
            if (value && typeof value === 'object') {
                const st = waExplicitWhatsappStatus(value, depth + 1);
                if (st) return st;
            } else {
                const txt = String(value === undefined || value === null ? '' : value).trim().toLowerCase();
                if (/not.*whatsapp|no.*whatsapp|false|unavailable|not registered|not found/.test(txt)) return 'Not available';
                if (/true|available|registered|exists|on whatsapp/.test(txt)) return 'Available';
            }
        }
        for (const key of Object.keys(item)) {
            if (/whatsapp|wa/i.test(key)) {
                const child = item[key];
                if (child && typeof child === 'object') {
                    const st = waExplicitWhatsappStatus(child, depth + 1);
                    if (st) return st;
                }
            }
        }
        return '';
    }

    function waStatusFromValue(statusValue, item) {
        const explicitWa = waExplicitWhatsappStatus(item, 0);
        if (explicitWa) return explicitWa === 'Available' ? 'Valid' : (explicitWa === 'Not available' ? 'Invalid' : explicitWa);
        const statusText = String(statusValue === undefined || statusValue === null ? '' : statusValue).trim().toLowerCase();
        if (statusValue === true || /^(true|yes|valid|registered|exists|available|active|on whatsapp|found)$/i.test(statusText)) return 'Valid';
        if (statusValue === false || /^(false|no|invalid|not registered|not_registered|not exists|not_exists|unavailable|not available|not_available|inactive|failed|fail|error|not found)$/i.test(statusText)) return 'Invalid';
        const full = statusText || waSafeJson(item).toLowerCase();
        if (/no whatsapp|not on whatsapp|does not exist|not found|not registered|invalid|unavailable/i.test(full)) return 'Invalid';
        if (/whatsapp.*true|on whatsapp|registered.*whatsapp|whatsapp.*available|whatsapp.*exists/i.test(full)) return 'Valid';
        if (/registered|valid|available|exists/i.test(full) && /whatsapp|wa/i.test(full)) return 'Valid';
        return 'Unknown';
    }

    function waParseResultItem(item) {
        item = item || {};
        const rawNumber = waDeepFindPhone(item, 0);
        const statusValue = waDeepFindStatus(item, 0);
        const finalStatus = waStatusFromValue(statusValue, item);
        const hasStatus = typeof statusValue !== 'undefined';
        const raw = waSafeJson(item).slice(0, 800);
        return { key: waResultKey(rawNumber), status: finalStatus, raw: raw, hasStatus: hasStatus, noKeyEligible: !rawNumber && hasStatus && finalStatus !== 'Unknown' && waLooksLikeWaRecord(item) };
    }

    function waArrayStatusGroupResults(root) {
        const out = [];
        const seen = new WeakSet();
        function statusFromKey(key) {
            const k = String(key || '').toLowerCase();
            if (/invalid|not[_ -]?registered|not[_ -]?found|not[_ -]?exist|unavailable|failed|errors?/.test(k)) return 'Invalid';
            if (/valid|registered|exists?|available|on[_ -]?(whatsapp|wa)|whatsapp[_ -]?numbers?/.test(k)) return 'Valid';
            return '';
        }
        function visit(value, depth) {
            if (depth > 6 || !value || typeof value !== 'object') return;
            if (seen.has(value)) return;
            seen.add(value);
            if (Array.isArray(value)) { value.forEach(v => visit(v, depth + 1)); return; }
            Object.keys(value).forEach(key => {
                const child = value[key];
                const st = statusFromKey(key);
                if (st && Array.isArray(child)) {
                    child.forEach(entry => {
                        const phone = waDeepFindPhone(entry, 0) || (waLooksLikePhoneKey(entry) ? waNormalizeDigits(entry) : '');
                        if (phone) out.push({ key: waResultKey(phone), status: st, raw: waSafeJson({ [key]: entry }).slice(0, 500), hasStatus: true, noKeyEligible: false });
                    });
                } else if (child && typeof child === 'object') {
                    visit(child, depth + 1);
                }
            });
        }
        visit(root, 0);
        return out;
    }

    function waCollectParsedResults(resultItems) {
        const flat = waFlattenResultItems(resultItems || []);
        const out = [];
        const seen = new Set();
        function pushParsed(parsed) {
            if (!parsed) return;
            if (!parsed.noKeyEligible && (!parsed.key || (!parsed.hasStatus && !parsed.status))) return;
            const id = (parsed.key || 'idx') + '|' + parsed.status + '|' + parsed.raw;
            if (!seen.has(id)) { seen.add(id); out.push(parsed); }
        }
        waArrayStatusGroupResults(resultItems || []).forEach(pushParsed);
        flat.forEach(item => {
            waObjectPhoneMapResults(item).forEach(pushParsed);
            pushParsed(waParseResultItem(item));
        });
        return out;
    }

    function waCommitDashboardRows(targets) {
        try {
            const targetRows = [];
            (Array.isArray(targets) ? targets : []).forEach(item => {
                const row = item && item.row ? item.row : item;
                if (row && typeof row === 'object' && !targetRows.includes(row)) targetRows.push(row);
            });
            if (!targetRows.length) return;
            targetRows.forEach((row, idx) => {
                try { ensureDashboardRowKey(row, idx); } catch (e) {}
                try {
                    const displayPhone = waNormalizePhoneForDisplay(rowPhoneValue(row));
                    if (displayPhone) row.phone_number = displayPhone;
                } catch (e) {}
                try {
                    if (productsStore && typeof productsStore.update === 'function' && row.cid) {
                        const updateResult = productsStore.update(row.cid, row);
                        if (updateResult && typeof updateResult.catch === 'function') updateResult.catch(function(){});
                    }
                } catch (e) {
                    try { if (productsStore && row.cid) productsStore.push([{ type: 'update', key: row.cid, data: row }]); } catch (e2) {}
                }
                try {
                    if (dataGrid && row.cid && typeof dataGrid.getRowIndexByKey === 'function') {
                        const rIdx = dataGrid.getRowIndexByKey(row.cid);
                        if (rIdx >= 0 && typeof dataGrid.cellValue === 'function') {
                            dataGrid.cellValue(rIdx, 'whatsapp_status', row.whatsapp_status || '');
                            dataGrid.cellValue(rIdx, 'phone_number', row.phone_number || '');
                        }
                    }
                } catch (e) {}
            });
        } catch (err) {
            console.warn('WA dashboard direct row commit failed', err);
        }
    }

    function waRefreshDashboardNow() {
        try {
            let rows = [];
            if ($scope.local && Array.isArray($scope.local.collect)) {
                rows = safeCollectRows($scope.local);
                // Keep the original collection objects updated, but rebuild the grid
                // store from the latest array. DevExtreme push updates can silently
                // miss rows when cid was created after the grid was built; rebuilding
                // the ArrayStore guarantees WhatsApp Status leaves "Checking via API...".
                $scope.local.collect = rows;
            }
            if (typeof $scope.saveLocal === 'function') $scope.saveLocal();
            if (productsStore && rows.length && typeof DevExpress !== 'undefined' && DevExpress.data && DevExpress.data.ArrayStore) {
                try {
                    refreshColumnList(rows);
                    productsStore = new DevExpress.data.ArrayStore({ key: 'cid', data: rows });
                } catch (storeErr) {
                    console.warn('WA dashboard store rebuild failed, falling back to push update', storeErr);
                    try { updateDataTable($scope.local); } catch (pushErr) {}
                }
            } else if (productsStore && $scope.local) {
                try { updateDataTable($scope.local); } catch (pushErr) {}
            }
            if (dataGrid) {
                try { dataGrid.option('dataSource', { store: productsStore, reshapeOnPush: true }); } catch (e1) {}
                try { if (dataGrid.getDataSource && dataGrid.getDataSource()) dataGrid.getDataSource().reload(); } catch (e0) {}
                try { if (dataGrid.refresh) dataGrid.refresh(); } catch (e2) {}
                try { if (dataGrid.repaint) dataGrid.repaint(); } catch (e3) {}
            }
            try { refreshDashboardMetricCounts(rows); } catch (e5) {}
            try { $scope.$applyAsync(); } catch (e4) {}
        } catch (e) {
            console.warn('WA dashboard refresh failed', e);
        }
    }

    function waSetRowStatus(row, status, raw, providerName) {
        if (!row) return false;
        const previous = row.whatsapp_status;
        row.whatsapp_status = status || 'Unknown';
        row.whatsapp_api_raw = raw || '';
        row.whatsapp_checked_at = new Date().toISOString();
        row.whatsapp_api_provider = providerName || row.whatsapp_api_provider || 'NumberChecker.AI';
        const displayPhone = waNormalizePhoneForDisplay(rowPhoneValue(row));
        if (displayPhone) row.phone_number = displayPhone;
        return previous !== row.whatsapp_status;
    }

    function waIsPendingStatus(status) {
        const text = String(status || '').trim().toLowerCase();
        return !text || /checking via api|queued|pending|running|starting|processing|api started/.test(text);
    }

    function waApplyResultsToBatch(resultItems, batchItems, byKey, seenRows) {
        const parsedList = waCollectParsedResults(resultItems || []);
        let updated = 0;
        const pending = (batchItems || []).filter(item => item && item.row && !seenRows.has(item.row));
        parsedList.forEach(parsed => {
            if (!parsed || !parsed.key) return;
            const keys = [parsed.key];
            const prefix = waCountryDialPrefix();
            if (prefix && parsed.key.startsWith(prefix) && parsed.key.length > prefix.length + 6) keys.push(parsed.key.slice(prefix.length));
            if (prefix && !parsed.key.startsWith(prefix) && parsed.key.length <= 10) keys.push(prefix + parsed.key);
            keys.filter(Boolean).forEach(key => {
                (byKey[key] || []).forEach(row => {
                    if (!row) return;
                    if (waSetRowStatus(row, parsed.status, parsed.raw) || !seenRows.has(row)) updated += 1;
                    seenRows.add(row);
                });
            });
        });
        const noKeyList = parsedList.filter(p => p && !p.key && p.noKeyEligible);
        if (noKeyList.length) {
            pending.forEach((item, idx) => {
                if (seenRows.has(item.row)) return;
                const parsed = noKeyList[idx];
                if (!parsed) return;
                waSetRowStatus(item.row, parsed.status, parsed.raw);
                seenRows.add(item.row);
                updated += 1;
            });
        }
        // Some Apify actors return only a list of booleans/status objects without
        // returning the phone number. In that case, apply results by original input
        // order so the dashboard never remains blank after a successful run.
        if (parsedList.length) {
            (batchItems || []).forEach((item, idx) => {
                if (!item || !item.row || seenRows.has(item.row)) return;
                const parsed = parsedList[idx];
                if (!parsed) return;
                waSetRowStatus(item.row, parsed.status || 'Unknown', parsed.raw);
                seenRows.add(item.row);
                updated += 1;
            });
        }
        if (updated) {
            waCommitDashboardRows(batchItems || []);
            waRefreshDashboardNow();
        }
        return updated;
    }

    async function waRequestSingleProviderConfig(providerName, preferNext, excludeRows) {
        excludeRows = Array.isArray(excludeRows) ? excludeRows.filter(Boolean) : [];
        const licence = await apiLiveGetStoredLicence();
        const key = licence && licence.key ? String(licence.key).trim() : '';
        if (!key) throw new Error('Please activate your licence first.');
        const data = await apiLiveCallAppsScript('getApiConfig', { key, preferNext: !!preferNext, provider: providerName, excludeRows: excludeRows.join(',') });
        if (!data || data.status !== 'ok') {
            if (data && data.status === 'expired') throw new Error(`Licence expired${data.expiryDate ? ' on ' + data.expiryDate : ''}. Contact ${data.supportEmail || PocketLeadsConfig.supportEmail} to renew.`);
            if (data && data.status === 'credits_exhausted') throw new Error('Your scraping/verification credits are exhausted. Upgrade your plan or contact samimn7890@gmail.com.');
            if (data && data.status === 'inactive') throw new Error('This licence is inactive. Contact samimn7890@gmail.com.');
            if (data && data.status === 'no_api_key') {
                const noKeyErr = new Error('No active ' + (providerName === 'numberchecker' ? 'NumberChecker.AI' : 'WhatsApp API') + ' key configured in Admin Sheet.');
                noKeyErr.code = 'NO_ELIGIBLE_PROVIDER';
                throw noKeyErr;
            }
            if (data && data.status === 'invalid' && !data.backend) throw new Error('Apps Script old version hai. ZIP ke apps_script_code.js ko paste karke Deploy > Manage deployments > Edit > New version > Deploy karo.');
            throw new Error((data && data.message) || 'Unable to get WhatsApp API setup from Admin Sheet.');
        }
        return {
            provider: String(data.provider || providerName).trim().toLowerCase(),
            providerLabel: String(data.providerLabel || 'NumberChecker.cloud'),
            apiId: String(data.apiId || ''),
            poolSize: Math.max(1, parseInt(data.poolSize, 10) || 1),
            edgeAccelerated: !!data.edgeAccelerated,
            apiToken: '',
            actorId: '',
            sourceId: '',
            secureProxy: data.secureProxy === true,
            apiKeyRow: parseInt(data.keyRow, 10) || 0,
            apifyKeyRow: parseInt(data.keyRow, 10) || 0,
            apiUsageBefore: parseInt(data.usageCount, 10) || 0,
            apiUsageLimit: Math.max(0, Number(data.usageLimit) || 0),
            _targetUrl: data._targetUrl || '',
            _clientElapsedMs: data._clientElapsedMs || 0
        };
    }

    let waCachedRouteConfig = null;
    let waCachedRouteAt = 0;
    let waStudioPreparedCache = null;

    function cleanWaErrorMessage(err) {
        const raw = String((err && err.message) || err || 'WhatsApp verification error').trim();
        if (/signal is aborted|aborted without reason|The user aborted/i.test(raw)) {
            return 'Connection timed out while contacting the verification server. Please click Start Verification again.';
        }
        return raw;
    }

    async function waGetApiConfig(preferNext, excludeRows) {
        const hasExclude = Array.isArray(excludeRows) && excludeRows.filter(Boolean).length > 0;
        if (!preferNext && !hasExclude && waCachedRouteConfig && (Date.now() - waCachedRouteAt < 180000)) {
            return waCachedRouteConfig;
        }
        let ncError = null;
        try {
            const cfg = await waRequestSingleProviderConfig('numberchecker', preferNext, excludeRows);
            if (!preferNext && !hasExclude && cfg) {
                waCachedRouteConfig = cfg;
                waCachedRouteAt = Date.now();
            }
            return cfg;
        } catch (err) {
            ncError = err;
            if (!/NO_ELIGIBLE_PROVIDER|No active NumberChecker|temporarily unavailable|no usable configured row/i.test(String((err && (err.code || err.message)) || ''))) {
                throw err;
            }
        }
        try {
            const fbCfg = await waRequestSingleProviderConfig('apifywpapi', preferNext, excludeRows);
            if (!preferNext && !hasExclude && fbCfg) {
                waCachedRouteConfig = fbCfg;
                waCachedRouteAt = Date.now();
            }
            return fbCfg;
        } catch (fallbackErr) {
            throw ncError || fallbackErr;
        }
    }

    async function waStartNumberCheckerTask(config, e164Numbers) {
        if (!config || !(config.apiKeyRow || config.apifyKeyRow)) {
            throw new Error('No active NumberChecker.AI API key found in Admin Sheet. Set Provider = numberchecker and paste your X-API-Key.');
        }
        const prefix = waCountryDialPrefix() || '91';
        const payload = await waProviderProxy(config, 'createTask', {
            numbers: e164Numbers,
            countryCode: prefix,
            taskType: 'ws'
        });
        const taskObj = (payload && payload.data && typeof payload.data === 'object') ? payload.data : payload;
        const taskId = String((taskObj && (taskObj.task_id || taskObj.taskId || taskObj.id)) || '').trim();
        if (!taskId) {
            throw new Error('NumberChecker.AI did not return a task_id.');
        }
        return { taskId, raw: taskObj };
    }

    function pushWaDiagStep(stepNum, stepTitle, status, detail, extraMeta) {
        if (!$scope.waStudioModal) return;
        if (!Array.isArray($scope.waStudioModal.diagLogs)) $scope.waStudioModal.diagLogs = [];
        const timeStr = new Date().toLocaleTimeString();
        const existingIdx = $scope.waStudioModal.diagLogs.findIndex(x => x && x.stepNum === stepNum);
        const entry = {
            stepNum,
            stepTitle: String(stepTitle || ('Step ' + stepNum)),
            status: status || 'running', // 'pass' | 'running' | 'fail'
            detail: String(detail || ''),
            time: timeStr,
            meta: extraMeta || null
        };
        $scope.safeApply(() => {
            if (existingIdx >= 0) {
                $scope.waStudioModal.diagLogs[existingIdx] = entry;
            } else {
                $scope.waStudioModal.diagLogs.push(entry);
            }
            if (status === 'fail') {
                const passed = $scope.waStudioModal.diagLogs
                    .filter(x => x && x.status === 'pass')
                    .map(x => `Step ${x.stepNum} (${x.stepTitle})`);
                const workingRange = passed.length
                    ? `Worked from ${passed[0]} up to ${passed[passed.length - 1]}`
                    : `Failed at initial step (Step ${stepNum}) before any upstream step completed`;
                $scope.waStudioModal.diagFailure = {
                    workingRange,
                    failedAtStep: `Step ${stepNum}: ${stepTitle}`,
                    fullReason: String(detail || 'Unknown error'),
                    time: timeStr,
                    meta: extraMeta || null
                };
            }
        });
    }

    $scope.copyWaDiagLogs = function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        if (!$scope.waStudioModal) return;
        const lines = [];
        lines.push('=== POCKETLEADS WHATSAPP VERIFICATION DEV DIAGNOSIS (v10.19.58) ===');
        if ($scope.waStudioModal.diagFailure) {
            lines.push('WORKING RANGE: ' + $scope.waStudioModal.diagFailure.workingRange);
            lines.push('FAILED AT:     ' + $scope.waStudioModal.diagFailure.failedAtStep);
            lines.push('FAILURE REASON:' + $scope.waStudioModal.diagFailure.fullReason);
            if ($scope.waStudioModal.diagFailure.meta) {
                try { lines.push('RAW TRACE:     ' + JSON.stringify($scope.waStudioModal.diagFailure.meta)); } catch (_) {}
            }
            lines.push('-------------------------------------------------------------------');
        }
        ($scope.waStudioModal.diagLogs || []).forEach(log => {
            const badge = log.status === 'pass' ? '[PASS]' : (log.status === 'fail' ? '[FAIL]' : '[RUN ]');
            lines.push(`${badge} Step ${log.stepNum} (${log.time}) - ${log.stepTitle}: ${log.detail}`);
            if (log.meta) {
                try { lines.push('   trace: ' + JSON.stringify(log.meta)); } catch (_) {}
            }
        });
        const fullText = lines.join('\n');
        try {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(fullText);
            }
            showTopStatusToast('✓ Full diagnostic log copied to clipboard!', 'success');
        } catch (_) {}
    };

    $scope.clearWaDiagLogs = function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        if (!$scope.waStudioModal) return;
        $scope.safeApply(() => {
            $scope.waStudioModal.diagLogs = [];
            $scope.waStudioModal.diagFailure = null;
            $scope.waStudioModal.errorMessage = '';
        });
    };

    async function waPollNumberCheckerTask(config, taskId, expectedTotal) {
        const started = Date.now();
        const dynamicMaxMs = Math.max(300000, Math.min(600000, (Number(expectedTotal) || 500) * 160));
        const maxMs = Math.max(dynamicMaxMs, parseInt(config && (config.waMaxWaitMs || config.maxWaitMs), 10) || 0);
        let pollCount = 0;
        while (Date.now() - started < maxMs) {
            if ($scope.waApiStopRequested) throw new Error('WA API check stopped by user.');
            pollCount += 1;
            let payload = null;
            try {
                payload = await waProviderProxy(config, 'getTask', { taskId });
            } catch (pollErr) {
                const pDetail = `Poll #${pollCount} for ${taskId} failed: ${pollErr.message || pollErr}`;
                pushWaDiagStep(4, 'Poll Cloud Job Status (getTask)', 'fail', pDetail, pollErr.debugTrace || { targetUrl: pollErr.targetUrl, httpStatus: pollErr.status, elapsedMs: pollErr.elapsedMs });
                throw pollErr;
            }
            const task = (payload && payload.data && typeof payload.data === 'object') ? payload.data : (payload || {});
            const status = String(task.status || 'processing').trim().toLowerCase();
            const successCount = parseInt(task.success, 10) || 0;
            const totalCount = parseInt(task.total, 10) || expectedTotal || 0;
            const seconds = Math.max(1, Math.round((Date.now() - started) / 1000));
            const dbg = task.debugTrace || payload.debugTrace || null;
            pushWaDiagStep(
                4,
                'Poll Cloud Job Status (getTask)',
                status === 'exported' ? 'pass' : 'running',
                `Poll #${pollCount} (${seconds}s elapsed): status="${status.toUpperCase()}", jobId="${taskId}", downloadReady=${status === 'exported' ? 'YES' : 'waiting'}, clientMs=${payload._clientElapsedMs || 0}ms`,
                dbg
            );
            $scope.safeApply(() => {
                const isCloudTask = String(taskId || '').startsWith('cloud:');
                const pName = isCloudTask ? 'NumberChecker.cloud' : 'NumberChecker.AI';
                const estDone = successCount > 0 ? successCount : Math.min(Math.floor(totalCount * 0.85), Math.floor((seconds / 15) * totalCount));
                const progressStr = estDone > 0 ? (' · ' + estDone.toLocaleString() + '/' + totalCount.toLocaleString()) : '';
                const msg = pName + ': ' + status.toUpperCase() + progressStr + ' · ' + seconds + 's';
                $scope.waApiStatusText = msg;
                if ($scope.historyModal && $scope.historyModal.waBulkRunning) {
                    $scope.historyModal.waBulkStatusText = msg;
                    if (estDone > 0) $scope.historyModal.waBulkFinished = estDone;
                }
            });
            if (status === 'exported' || status === 'completed' || status === 'finished' || status === 'done' || status === 'filtered' || status === 'ready' || status === 'success' || task.download_available === true) {
                let items = Array.isArray(task.items) ? task.items : [];
                const resultUrl = String(task.result_url || task.resultUrl || '').trim();
                const dlTrace = dbg && dbg.downloadTrace ? dbg.downloadTrace : null;
                if (!items.length && resultUrl && (!dlTrace || !dlTrace.isPlainText)) {
                    pushWaDiagStep(5, 'Download & Parse Active Numbers', 'running', `Fetching result file from ${resultUrl}...`, dlTrace);
                    const dl = await waProviderProxy(config, 'getTaskResult', { resultUrl, taskId });
                    const dlObj = (dl && dl.data && typeof dl.data === 'object') ? dl.data : (dl || {});
                    if (Array.isArray(dlObj.items)) items = dlObj.items;
                }
                pushWaDiagStep(
                    5,
                    'Download & Parse Active Numbers',
                    'pass',
                    `Downloaded from ${resultUrl || '/download?format=txt_numbers'} -> Parsed ${items.length.toLocaleString()} Active (Valid) WhatsApp numbers out of ${expectedTotal.toLocaleString()} submitted`,
                    dlTrace || { resultUrl, parsedItems: items.length }
                );
                return { status: 'exported', taskId, items, resultUrl, raw: task };
            }
            if (status === 'failed' || status === 'error') {
                const fMsg = 'NumberChecker task failed on cloud: ' + (task.message || status);
                pushWaDiagStep(4, 'Poll Cloud Job Status (getTask)', 'fail', fMsg, task);
                throw new Error(fMsg);
            }
            const pollWaitMs = (Date.now() - started) < 30000 ? 2000 : ((Date.now() - started) < 90000 ? 3200 : 4500);
            await new Promise(resolve => setTimeout(resolve, pollWaitMs));
        }
        const tMsg = 'NumberChecker verification timed out after ' + Math.round(maxMs / 1000) + 's.';
        pushWaDiagStep(4, 'Poll Cloud Job Status (getTask)', 'fail', tMsg, { taskId, maxMs });
        throw new Error(tMsg);
    }

    async function waReportApiUsage(config, usedCount) {
        const count = Math.max(0, parseInt(usedCount, 10) || 0);
        if (!count || !config) return null;
        const flow = window.PocketLeadsApifyFlow;
        if (flow && flow.ApiBackendManager && typeof flow.ApiBackendManager.reportUsage === 'function') {
            return await flow.ApiBackendManager.reportUsage(config, count);
        }
        const licence = await apiLiveGetStoredLicence();
        const key = licence && licence.key ? String(licence.key).trim() : '';
        if (!key) return null;
        return await apiLiveCallAppsScript('reportApiUsage', {
            key,
            keyRow: config.apiKeyRow || config.apifyKeyRow || 0,
            usedCount: count
        });
    }

    function waShouldTryNextProvider(err) {
        return false; // Dev mode: No blind automatic retries!
    }

    $scope.waRequirementModal = {
        show: false,
        mode: 'min_2000',
        currentCount: 0,
        minRequired: 2000,
        availableCredit: null,
        title: '',
        message: ''
    };

    $scope.waStudioModal = {
        show: false,
        step: 'configure', // 'configure' | 'running' | 'complete'
        sourceMode: 'leads', // 'leads' | 'history'
        serviceSlug: 'whatsapp-checker',
        skipAlreadyVerified: true,
        sessionCount: 1,
        totalLeadsCount: 0,
        totalPhoneCount: 0,
        pendingPhoneCount: 0,
        alreadyVerifiedCount: 0,
        availableCredit: '...',
        unlimitedCredit: true,
        apiRouteStatus: 'Ready (Auto-Routing)',
        apiRouteProvider: 'NumberChecker.cloud / Multi-Provider',
        apiKeyValidating: false,
        apiKeyValid: null,
        pipelineStep: 1,
        progressDone: 0,
        progressTotal: 0,
        progressPercent: 0,
        elapsedSeconds: 0,
        statusMessage: '',
        errorMessage: '',
        diagLogs: [],
        diagFailure: null,
        summary: {
            total: 0,
            valid: 0,
            invalid: 0,
            unknown: 0
        }
    };

    $scope.openWaRequirementModal = function(mode, currentCount, availableCredit) {
        const cnt = Math.max(0, parseInt(currentCount, 10) || 0);
        const avail = (availableCredit !== null && availableCredit !== undefined && Number.isFinite(Number(availableCredit)))
            ? Math.max(0, parseInt(availableCredit, 10) || 0)
            : null;
        $scope.safeApply(() => {
            if (mode === 'credit_limit') {
                $scope.waRequirementModal = {
                    show: true,
                    mode: 'credit_limit',
                    currentCount: cnt,
                    minRequired: 2000,
                    availableCredit: avail,
                    title: 'Available Credit Limit Exceeded',
                    message: 'You selected ' + cnt.toLocaleString() + ' phone numbers for WhatsApp verification, which exceeds your Available Credit (' + (avail !== null ? avail.toLocaleString() : '0') + ' credits). You cannot verify more numbers than your purchased/available credit.'
                };
            } else {
                $scope.waRequirementModal = {
                    show: true,
                    mode: 'min_2000',
                    currentCount: cnt,
                    minRequired: 2000,
                    availableCredit: avail,
                    title: 'Minimum 2,000 Phone Numbers Required',
                    message: 'WhatsApp number verification requires at least 2,000 phone numbers (currently ' + cnt.toLocaleString() + ' phone numbers selected). You can also verify in bulk from the Scraping History section by selecting multiple sessions together!'
                };
            }
        });
    };

    $scope.closeWaRequirementModal = function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        if ($scope.waRequirementModal) $scope.waRequirementModal.show = false;
    };

    $scope.openHistoryFromWaRequirementModal = function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        if ($scope.waRequirementModal) $scope.waRequirementModal.show = false;
        if ($scope.waStudioModal) $scope.waStudioModal.show = false;
        $scope.openScrapingHistory();
    };

    $scope.closeWaStudioModal = function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        if ($scope.waStudioModal) $scope.waStudioModal.show = false;
    };

    async function getLiveUserAvailableCreditForWa() {
        try {
            if (typeof PocketLeadsAccount !== 'undefined' && typeof PocketLeadsAccount.read === 'function') {
                const state = await PocketLeadsAccount.read();
                const acct = (state && state.pocketleadsAccount) || {};
                const rawAvail = acct.availableCredit !== undefined ? acct.availableCredit : (acct.structuredCredit !== undefined ? acct.structuredCredit : acct.googleMapsCredit);
                if (String(rawAvail || '').toLowerCase() === 'unlimited') {
                    return { unlimited: true, available: 999999999 };
                }
                if (rawAvail !== null && rawAvail !== undefined && rawAvail !== '' && Number.isFinite(Number(rawAvail))) {
                    return { unlimited: false, available: Math.max(0, Math.floor(Number(rawAvail))) };
                }
            }
        } catch (_) {}
        return { unlimited: true, available: 999999999 };
    }

    $scope.validateWaApiKeyNow = async function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        if ($scope.waStudioModal.apiKeyValidating) return;
        $scope.safeApply(() => {
            $scope.waStudioModal.apiKeyValidating = true;
            $scope.waStudioModal.apiRouteStatus = 'Checking Admin Sheet WhatsApp API Key...';
            $scope.waStudioModal.errorMessage = '';
            $scope.waStudioModal.diagFailure = null;
            $scope.waStudioModal.diagLogs = [];
        });
        try {
            pushWaDiagStep(1, 'Fetch API Route (getApiConfig)', 'running', 'Requesting active WhatsApp API key route from backend...');
            const t0 = Date.now();
            const cfg = await waGetApiConfig(false, []);
            waCachedRouteConfig = cfg;
            waCachedRouteAt = Date.now();
            pushWaDiagStep(
                1,
                'Fetch API Route (getApiConfig)',
                'pass',
                `Resolved provider="${cfg.provider}", apiId="${cfg.apiId || ('ROW-' + cfg.apiKeyRow)}", keyRow=${cfg.apiKeyRow} in ${cfg._clientElapsedMs || (Date.now() - t0)}ms via ${cfg._targetUrl || 'edge'}`,
                cfg
            );

            pushWaDiagStep(2, 'Validate Key & Balance (validateKey)', 'running', 'Testing API key against NumberChecker.cloud (/api/v1/test & /api/v1/balance)...');
            const res = await waProviderProxy(cfg, 'validateKey', {});
            const data = (res && res.data && typeof res.data === 'object') ? res.data : (res || {});
            const modeLabel = data.providerMode || cfg.providerLabel || 'NumberChecker.cloud';
            const rawProvBal = (data.balance && data.balance.active_credits !== undefined) ? Number(data.balance.active_credits) : null;
            const numCap = (rawProvBal !== null && Number.isFinite(rawProvBal)) ? (rawProvBal * 40000) : null;
            const balVal = (rawProvBal !== null && Number.isFinite(rawProvBal))
                ? (` · Balance: ${rawProvBal} credit${rawProvBal === 1 ? '' : 's'} (≈ ${numCap.toLocaleString()} numbers)`)
                : '';
            pushWaDiagStep(
                2,
                'Validate Key & Balance (validateKey)',
                'pass',
                `Key Valid on ${modeLabel}${balVal} in ${res._clientElapsedMs || 0}ms`,
                data
            );
            $scope.safeApply(() => {
                $scope.waStudioModal.apiKeyValidating = false;
                $scope.waStudioModal.apiKeyValid = true;
                $scope.waStudioModal.providerBalance = rawProvBal;
                $scope.waStudioModal.apiRouteProvider = modeLabel + (data.apiId ? ' (' + data.apiId + ')' : '');
                $scope.waStudioModal.apiRouteStatus = '✓ Active & Verified (' + modeLabel + balVal + ')';
            });
        } catch (err) {
            const msg = (err && err.message) ? err.message : String(err);
            const failedStepNum = ($scope.waStudioModal.diagLogs && $scope.waStudioModal.diagLogs.length >= 2) ? 2 : 1;
            const failedStepTitle = failedStepNum === 2 ? 'Validate Key & Balance (validateKey)' : 'Fetch API Route (getApiConfig)';
            pushWaDiagStep(failedStepNum, failedStepTitle, 'fail', msg, err.debugTrace || { targetUrl: err.targetUrl, httpStatus: err.status, elapsedMs: err.elapsedMs });
            $scope.safeApply(() => {
                $scope.waStudioModal.apiKeyValidating = false;
                $scope.waStudioModal.apiKeyValid = false;
                $scope.waStudioModal.apiRouteStatus = '⚠ ' + msg;
                $scope.waStudioModal.errorMessage = msg;
            });
        }
    };

    // Bidirectional Data Sync: Updates Verified WhatsApp Statuses ('Valid'/'Invalid'/'Unknown') across:
    // 1) Persistent WaVerifiedPhoneCache (localStorage)
    // 2) Live Dashboard / Mobile Leads ($scope.local.collect + DevExtreme dataGrid + IndexedDB ResultStore)
    // 3) All Scraping History Sessions ($scope.local._scrapeHistory + IndexedDB HistoryStore) without duplicates!
    async function syncVerifiedPhonesEverywhere(verifiedItems, alsoRecordLeadsSessionToHistory) {
        try {
            (Array.isArray(verifiedItems) ? verifiedItems : []).forEach(item => {
                const row = item && item.row ? item.row : item;
                if (!row || !row.whatsapp_status) return;
                const canonicalSt = normalizeCanonicalWaStatusLabel(row.whatsapp_status);
                row.whatsapp_status = canonicalSt;
                recordPhoneInWaVerifiedCache(rowPhoneValue(row), canonicalSt);
            });
            saveWaVerifiedPhoneMap();

            const map = loadWaVerifiedPhoneMap();

            if ($scope.local && Array.isArray($scope.local.collect) && $scope.local.collect.length) {
                applyWaVerifiedCacheToRows($scope.local.collect);
                waCommitDashboardRows($scope.local.collect);
                waRefreshDashboardNow();
                try {
                    await runtimeMessageAsync({ action: 'result_store_upsert', rows: $scope.local.collect });
                } catch (_) {}
            }

            if (alsoRecordLeadsSessionToHistory && $scope.local && Array.isArray($scope.local.collect) && $scope.local.collect.length) {
                try { $scope.recordScrapingHistory('saved', false); } catch (_) {}
            }

            const histList = $scope.ensureScrapingHistory();
            const idbSessions = await directIdbGetAllHistorySessions().catch(() => []);
            const byId = new Map();
            histList.concat(idbSessions).forEach(s => {
                if (s && s.id) {
                    const prev = byId.get(String(s.id));
                    if (!prev || ((s.rows && s.rows.length) || 0) > ((prev.rows && prev.rows.length) || 0)) {
                        byId.set(String(s.id), s);
                    }
                }
            });

            for (const [sid, sess] of byId.entries()) {
                const fullSess = await loadHistorySessionRows(Object.assign({}, sess)).catch(() => sess);
                const rows = Array.isArray(fullSess && fullSess.rows) ? fullSess.rows : (Array.isArray(sess.rows) ? sess.rows : []);
                if (!rows.length) continue;
                let changed = false;
                for (let rIdx = 0; rIdx < rows.length; rIdx++) {
                    const r = rows[rIdx];
                    if (!r || typeof r !== 'object') continue;
                    const digits = String(rowPhoneValue(r) || '').replace(/\D+/g, '').replace(/^0+/, '');
                    if (digits.length < 7) continue;
                    const cachedSt = map.get(digits) || (digits.length > 10 ? map.get(digits.slice(-10)) : '');
                    if (cachedSt && r.whatsapp_status !== cachedSt) {
                        r.whatsapp_status = cachedSt;
                        changed = true;
                    }
                }
                const stats = countSessionPhonesAndWa(rows);
                const bestCount = Math.max(parseInt(fullSess.leadCount, 10) || 0, parseInt(fullSess.rowCount, 10) || 0, rows.length);
                if (changed || fullSess.waAvailableCount !== stats.waAvailableCount) {
                    const updatedFull = Object.assign({}, fullSess, {
                        id: sid,
                        rows: rows,
                        leadCount: bestCount,
                        rowCount: bestCount,
                        phoneCount: stats.phoneCount,
                        waAvailableCount: stats.waAvailableCount,
                        isCompactPreview: false
                    });
                    await directIdbPutHistorySession(updatedFull);
                    try {
                        chrome.runtime.sendMessage({ action: 'scrape_history_put', session: updatedFull }, function() { try { void chrome.runtime.lastError; } catch (_) {} });
                    } catch (_) {}
                    const mIdx = histList.findIndex(x => x && String(x.id) === sid);
                    if (mIdx >= 0) {
                        histList[mIdx] = Object.assign({}, histList[mIdx], {
                            rows: rows.slice(0, 300),
                            leadCount: bestCount,
                            rowCount: bestCount,
                            phoneCount: stats.phoneCount,
                            waAvailableCount: stats.waAvailableCount,
                            isCompactPreview: bestCount > 300
                        });
                    }
                }
            }

            $scope.local._scrapeHistory = deduplicateHistorySessionArray(histList).slice(0, 50);
            $scope.saveLocal();
            if (typeof window !== 'undefined' && typeof window.__plScheduleAutoCloudBackup === 'function') {
                window.__plScheduleAutoCloudBackup();
            }
        } catch (syncErr) {
            console.warn('syncVerifiedPhonesEverywhere error', syncErr);
        }
    }

    async function executeWaBatchVerification(items, byKey, serviceSlug, onProgressUpdate) {
        const seenRows = new Set();
        const dialCode = String(waCountryDialPrefix() || '91').replace(/\D/g, '') || '91';
        // Enforce uniform digit length across all numbers in the batch (e.g. 12 digits for +91)
        const freq = {};
        let majorityLen = dialCode === '91' ? 12 : 0;
        let maxF = 0;
        items.forEach(x => {
            const d = String(x.apiNumber || '').replace(/\D/g, '');
            if (d.length >= 8) {
                freq[d.length] = (freq[d.length] || 0) + 1;
                if (freq[d.length] > maxF) { maxF = freq[d.length]; majorityLen = d.length; }
            }
        });
        const subLen = Math.max(6, majorityLen - dialCode.length);
        let correctedLenCount = 0;
        const allNumbers = [];
        const allE164Numbers = [];
        items.forEach(x => {
            let d = String(x.apiNumber || '').replace(/\D/g, '');
            if (majorityLen > 0 && d.length !== majorityLen) {
                if (d.length > majorityLen) {
                    if (d.startsWith(dialCode + '0')) {
                        const s = dialCode + d.slice(dialCode.length).replace(/^0+/, '');
                        d = s.length === majorityLen ? s : (dialCode + s.slice(-subLen));
                    } else {
                        d = dialCode + d.slice(-subLen);
                    }
                    correctedLenCount++;
                }
            }
            if (!majorityLen || d.length === majorityLen) {
                x.apiNumber = d;
                x.e164Number = '+' + d;
                allNumbers.push(d);
                allE164Numbers.push('+' + d);
                const k10 = d.slice(-10);
                [d, '+' + d, k10].filter(Boolean).forEach(k => {
                    if (!byKey[k]) byKey[k] = [];
                    if (!byKey[k].includes(x.row)) byKey[k].push(x.row);
                });
            }
        });
        const sampleNums = allE164Numbers.slice(0, 3).join(', ');

        pushWaDiagStep(
            1,
            'Prepare & Normalize Phone Numbers',
            'pass',
            `Prepared ${allE164Numbers.length.toLocaleString()} uniform ${majorityLen}-digit E.164 numbers (country_cc=${dialCode}${correctedLenCount > 0 ? ', auto-fixed ' + correctedLenCount + ' trunk-0/length outliers' : ''}, sample: ${sampleNums})`
        );

        let config = null;
        let finishedRun = null;
        let isFilteredActiveList = false;

        // STEP 2: Resolve API Route (SINGLE DIRECT CALL — NO RETRIES!)
        const usedCachedRoute = !!(waCachedRouteConfig && (Date.now() - waCachedRouteAt < 180000));
        pushWaDiagStep(
            2,
            'Resolve API Route (getApiConfig)',
            'running',
            usedCachedRoute ? 'Using pre-verified WhatsApp API route from cache...' : 'Fetching active WhatsApp API route from backend...'
        );
        if (onProgressUpdate) onProgressUpdate('Resolving active WhatsApp API route...', 0, 1);

        try {
            const tRoute = Date.now();
            config = await waGetApiConfig(false, []);
            const routeMs = Date.now() - tRoute;
            pushWaDiagStep(
                2,
                'Resolve API Route (getApiConfig)',
                'pass',
                `${usedCachedRoute ? '[0ms CACHED]' : `[${config._clientElapsedMs || routeMs}ms LIVE]`} provider="${config.provider}", apiId="${config.apiId || ('ROW-' + config.apiKeyRow)}", keyRow=${config.apiKeyRow}, url=${config._targetUrl || 'edge'}`,
                config
            );
        } catch (routeErr) {
            const rMsg = `Failed at getApiConfig: ${routeErr.message || routeErr}`;
            pushWaDiagStep(
                2,
                'Resolve API Route (getApiConfig)',
                'fail',
                rMsg,
                { targetUrl: routeErr.targetUrl, httpStatus: routeErr.status, elapsedMs: routeErr.elapsedMs, code: routeErr.code }
            );
            throw routeErr;
        }

        const isNumberChecker = String(config && config.provider || '').toLowerCase() === 'numberchecker';
        if (isNumberChecker) {
            // STEP 3: Create Cloud Job (SINGLE DIRECT CALL — NO RETRIES!)
            const effSlug = serviceSlug || 'whatsapp-checker';
            pushWaDiagStep(
                3,
                'Upload Batch Job (createTask -> POST /api/v1/jobs)',
                'running',
                `Uploading ${allE164Numbers.length.toLocaleString()} numbers (service_slug="${effSlug}", country_cc="${dialCode}") via keyRow=${config.apiKeyRow}...`
            );
            if (onProgressUpdate) {
                onProgressUpdate('Uploading ' + items.length.toLocaleString() + ' E.164 numbers (+' + dialCode + ') to NumberChecker.cloud...', Math.min(items.length, Math.floor(items.length * 0.1)), 2);
            }

            let payload = null;
            try {
                payload = await waProviderProxy(config, 'createTask', {
                    numbers: allE164Numbers,
                    countryCode: dialCode,
                    serviceSlug: effSlug,
                    taskType: effSlug === 'ws-business' ? 'ws_business' : 'ws'
                });
            } catch (createErr) {
                const dbg = createErr.debugTrace || {};
                const cMsg = `createTask failed (HTTP ${createErr.status || dbg.upstreamHttpStatus || '?'}, ${createErr.elapsedMs || 0}ms via ${dbg.handledBy || createErr.targetUrl || 'proxy'}): ${createErr.message || createErr}`;
                pushWaDiagStep(
                    3,
                    'Upload Batch Job (createTask -> POST /api/v1/jobs)',
                    'fail',
                    cMsg,
                    dbg.handledBy ? dbg : { targetUrl: createErr.targetUrl, httpStatus: createErr.status, elapsedMs: createErr.elapsedMs, rawResponse: createErr.rawResponse }
                );
                throw createErr;
            }

            const taskObj = (payload && payload.data && typeof payload.data === 'object') ? payload.data : payload;
            const taskId = String((taskObj && (taskObj.task_id || taskObj.taskId || taskObj.job_id || taskObj.id)) || '').trim();
            const cDbg = (taskObj && taskObj.debugTrace) || (payload && payload.debugTrace) || null;
            if (!taskId) {
                const noIdMsg = 'NumberChecker did not return a valid task_id / job_id.';
                pushWaDiagStep(3, 'Upload Batch Job (createTask -> POST /api/v1/jobs)', 'fail', noIdMsg, taskObj);
                throw new Error(noIdMsg);
            }

            pushWaDiagStep(
                3,
                'Upload Batch Job (createTask -> POST /api/v1/jobs)',
                'pass',
                `Job created! taskId="${taskId}", providerMode="${taskObj.providerMode || 'numberchecker.cloud'}", clientMs=${payload._clientElapsedMs || 0}ms, upstreamMs=${(cDbg && cDbg.upstreamElapsedMs) || 0}ms`,
                cDbg || taskObj
            );

            // STEP 4 & 5: Poll Cloud Job Status & Download Active Numbers
            if (onProgressUpdate) onProgressUpdate('Filtering WhatsApp statuses on cloud (' + taskId + ')...', Math.min(items.length, Math.floor(items.length * 0.25)), 3);
            const exportedTask = await waPollNumberCheckerTask(config, taskId, items.length);
            finishedRun = exportedTask;
            isFilteredActiveList = !!(
                String(taskId).startsWith('cloud:') ||
                (exportedTask && exportedTask.raw && (exportedTask.raw.isFilteredActiveList || exportedTask.raw.providerMode === 'numberchecker.cloud'))
            );
            if (Array.isArray(exportedTask.items) && exportedTask.items.length) {
                waApplyResultsToBatch(exportedTask.items, items, byKey, seenRows);
            }
            if (onProgressUpdate) onProgressUpdate('Syncing verified statuses to Leads, History & Storage...', items.length, 4);
        } else {
            pushWaDiagStep(3, 'Start Apify WhatsApp Actor', 'running', `Starting Apify actor for ${items.length} numbers...`);
            if (onProgressUpdate) onProgressUpdate('Starting Apify WhatsApp Actor for ' + items.length.toLocaleString() + ' numbers...', 0, 2);
            const run = await waStartApifyRun(config, allNumbers);
            pushWaDiagStep(3, 'Start Apify WhatsApp Actor', 'pass', `Started Apify run ${run.id}`);
            const partialHandler = async partialItems => {
                const updated = waApplyResultsToBatch(partialItems, items, byKey, seenRows);
                if (updated && onProgressUpdate) {
                    onProgressUpdate('Live WA check: ' + Math.min(items.length, seenRows.size) + '/' + items.length + ' updated', Math.min(items.length, seenRows.size), 3);
                }
            };
            finishedRun = await waPollRun(config, run.id, partialHandler, items.length + 100);
            const datasetId = waDatasetIdFromRun(finishedRun);
            if (datasetId) {
                const finalItems = await waFetchDatasetItems(config, datasetId, items.length + 500);
                waApplyResultsToBatch(finalItems, items, byKey, seenRows);
            }
            const outputItems = await waFetchRunOutput(config, finishedRun);
            if (outputItems.length) waApplyResultsToBatch(outputItems, items, byKey, seenRows);
        }

        const timedOut = finishedRun && finishedRun._partialTimeout;
        items.forEach(item => {
            if (!item || !item.row) return;
            const curSt = String(item.row.whatsapp_status || '').trim();
            const stillPending = waIsPendingStatus(curSt);
            if (!seenRows.has(item.row) || stillPending) {
                const finalStatus = timedOut ? 'Unknown' : (isFilteredActiveList ? 'Invalid' : 'Invalid');
                waSetRowStatus(
                    item.row,
                    finalStatus,
                    timedOut ? 'Verification timed out.' : 'Verified: Not registered on WhatsApp.',
                    isFilteredActiveList ? 'NumberChecker.cloud' : 'NumberChecker'
                );
                seenRows.add(item.row);
            } else {
                item.row.whatsapp_status = normalizeCanonicalWaStatusLabel(item.row.whatsapp_status);
            }
        });

        try {
            await waReportApiUsage(config, items.length);
        } catch (_) {}

        return { config, finishedRun, seenCount: seenRows.size };
    }

    // Prepare items from an array of lead rows
    function collectPhoneVerificationItems(rows, skipAlreadyVerified) {
        const items = [];
        const byKey = {};
        let totalWithPhone = 0;
        let alreadyVerified = 0;
        (Array.isArray(rows) ? rows : []).forEach((row, idx) => {
            if (!row || typeof row !== 'object') return;
            try { ensureDashboardRowKey(row, idx); } catch (_) {}
            const rawPhone = rowPhoneValue(row);
            const digits = waNormalizeDigits(rawPhone);
            const apiNumber = waNumberForApi(rawPhone);
            if (!digits || !apiNumber || apiNumber.length < 10) return;
            totalWithPhone++;
            const e164Number = '+' + apiNumber;
            try { row.phone_number = e164Number || waNormalizePhoneForDisplay(rawPhone) || rawPhone; } catch (_) {}
            const normSt = normalizeCanonicalWaStatusLabel(row.whatsapp_status);
            if (normSt === 'Valid' || normSt === 'Invalid') {
                row.whatsapp_status = normSt;
                alreadyVerified++;
                if (skipAlreadyVerified) return;
            }
            const key = waResultKey(apiNumber);
            const item = { row, rowId: idx, digits, apiNumber, e164Number, key };
            items.push(item);
            const last10 = digits.length > 10 ? digits.slice(-10) : '';
            [key, waResultKey(digits), apiNumber, e164Number, digits, last10].filter(Boolean).forEach(k => {
                if (!byKey[k]) byKey[k] = [];
                if (!byKey[k].includes(row)) byKey[k].push(row);
            });
        });
        return { items, byKey, totalWithPhone, alreadyVerified };
    }

    // Open Step-by-Step WhatsApp Verification Studio (from Leads Page or History Bulk Selection)
    $scope.openWaVerificationStudio = async function(sourceMode) {
        const isHistory = sourceMode === 'history';
        const credState = await getLiveUserAvailableCreditForWa();
        let rowsToInspect = [];
        let sessionCnt = 1;

        if (isHistory) {
            const selectedSessions = $scope.getHistorySelectedSessions();
            sessionCnt = selectedSessions.length;
            const estPhones = $scope.getHistorySelectedPhoneCount();
            if (!selectedSessions.length || estPhones < 2000) {
                $scope.openWaRequirementModal('min_2000', estPhones, credState.unlimited ? null : credState.available);
                return;
            }
            for (let i = 0; i < selectedSessions.length; i++) {
                const fullS = await loadHistorySessionRows(Object.assign({}, selectedSessions[i])).catch(() => selectedSessions[i]);
                const sRows = Array.isArray(fullS && fullS.rows) ? fullS.rows : (Array.isArray(selectedSessions[i].rows) ? selectedSessions[i].rows : []);
                rowsToInspect = rowsToInspect.concat(sRows);
            }
        } else {
            $scope.local.collect = await getCompleteRowsForExport();
            rowsToInspect = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
        }

        applyWaVerifiedCacheToRows(rowsToInspect);
        const collectedAll = collectPhoneVerificationItems(rowsToInspect, false);
        const collectedPending = collectPhoneVerificationItems(rowsToInspect, true);
        const effectiveCount = collectedPending.items.length >= 2000 ? collectedPending.items.length : collectedAll.items.length;

        if (effectiveCount < 2000) {
            $scope.openWaRequirementModal('min_2000', effectiveCount, credState.unlimited ? null : credState.available);
            return;
        }
        if (!credState.unlimited && effectiveCount > credState.available) {
            $scope.openWaRequirementModal('credit_limit', effectiveCount, credState.available);
            return;
        }

        waStudioPreparedCache = {
            sourceMode: isHistory ? 'history' : 'leads',
            rowsToInspect,
            collectedAll,
            collectedPending,
            credState,
            createdAt: Date.now()
        };

        $scope.safeApply(() => {
            $scope.waStudioModal = {
                show: true,
                step: 'configure',
                sourceMode: isHistory ? 'history' : 'leads',
                serviceSlug: 'whatsapp-checker',
                skipAlreadyVerified: collectedPending.items.length >= 2000,
                sessionCount: sessionCnt,
                totalLeadsCount: rowsToInspect.length,
                totalPhoneCount: collectedAll.totalWithPhone,
                pendingPhoneCount: collectedPending.items.length,
                alreadyVerifiedCount: collectedAll.alreadyVerified,
                availableCredit: credState.unlimited ? 'Unlimited' : credState.available,
                unlimitedCredit: credState.unlimited,
                apiRouteStatus: waCachedRouteConfig ? ('✓ Ready (' + (waCachedRouteConfig.providerLabel || 'NumberChecker.cloud') + ')') : 'Auto-Routing (NumberChecker.cloud / Admin Pool)',
                apiRouteProvider: (waCachedRouteConfig && waCachedRouteConfig.providerLabel) || 'NumberChecker.cloud',
                apiKeyValidating: false,
                apiKeyValid: waCachedRouteConfig ? true : null,
                pipelineStep: 1,
                progressDone: 0,
                progressTotal: effectiveCount,
                progressPercent: 0,
                elapsedSeconds: 0,
                statusMessage: '',
                errorMessage: '',
                diagLogs: [],
                diagFailure: null,
                summary: { total: 0, valid: 0, invalid: 0, unknown: 0 }
            };
        });
    };

    $scope.getWaStudioEffectivePhoneCount = function() {
        if (!$scope.waStudioModal) return 0;
        return $scope.waStudioModal.skipAlreadyVerified
            ? $scope.waStudioModal.pendingPhoneCount
            : $scope.waStudioModal.totalPhoneCount;
    };

    $scope.startWaStudioVerificationNow = async function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        const isHistory = $scope.waStudioModal && $scope.waStudioModal.sourceMode === 'history';
        const skipVerified = !!($scope.waStudioModal && $scope.waStudioModal.skipAlreadyVerified);
        const serviceSlug = ($scope.waStudioModal && $scope.waStudioModal.serviceSlug) || 'whatsapp-checker';

        let hydratedSessions = [];
        let targetRows = [];

        let collected = null;
        if (!isHistory && waStudioPreparedCache && waStudioPreparedCache.sourceMode === 'leads' && Array.isArray(waStudioPreparedCache.rowsToInspect) && waStudioPreparedCache.rowsToInspect.length) {
            targetRows = waStudioPreparedCache.rowsToInspect;
            collected = skipVerified ? waStudioPreparedCache.collectedPending : waStudioPreparedCache.collectedAll;
        } else if (isHistory) {
            const selectedSessions = $scope.getHistorySelectedSessions();
            for (let sIdx = 0; sIdx < selectedSessions.length; sIdx++) {
                const memSess = selectedSessions[sIdx];
                const fullSess = await loadHistorySessionRows(Object.assign({}, memSess)).catch(() => memSess);
                const rows = Array.isArray(fullSess && fullSess.rows) ? fullSess.rows : (Array.isArray(memSess.rows) ? memSess.rows : []);
                applyWaVerifiedCacheToRows(rows);
                hydratedSessions.push({ memSess, fullSess, rows });
                targetRows = targetRows.concat(rows);
            }
            collected = collectPhoneVerificationItems(targetRows, skipVerified);
        } else {
            $scope.local.collect = await getCompleteRowsForExport();
            targetRows = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
            collected = collectPhoneVerificationItems(targetRows, skipVerified);
        }

        const items = collected.items;
        const byKey = collected.byKey;

        if (items.length < 2000) {
            $scope.openWaRequirementModal('min_2000', items.length, null);
            return;
        }
        const credState = await getLiveUserAvailableCreditForWa();
        if (!credState.unlimited && items.length > credState.available) {
            $scope.openWaRequirementModal('credit_limit', items.length, credState.available);
            return;
        }

        items.forEach(item => {
            item.row.whatsapp_status = 'Checking via API...';
            item.row.whatsapp_api_raw = '';
        });

        const startedAtMs = Date.now();
        $scope.waApiMode = true;
        $scope.waApiStopRequested = false;
        $scope.waChecking = true;
        $scope.waFinished = 0;
        $scope.waTotal = items.length;
        $scope.waApiStatusText = 'Starting WhatsApp verification for ' + items.length.toLocaleString() + ' numbers...';

        if (isHistory && $scope.historyModal) {
            $scope.historyModal.waBulkRunning = true;
            $scope.historyModal.waBulkTotal = items.length;
            $scope.historyModal.waBulkFinished = 0;
            $scope.historyModal.waBulkStatusText = $scope.waApiStatusText;
        }

        $scope.safeApply(() => {
            $scope.waStudioModal.step = 'running';
            $scope.waStudioModal.pipelineStep = 1;
            $scope.waStudioModal.progressDone = 0;
            $scope.waStudioModal.progressTotal = items.length;
            $scope.waStudioModal.progressPercent = 5;
            $scope.waStudioModal.statusMessage = 'Preparing & normalizing ' + items.length.toLocaleString() + ' E.164 phone numbers...';
            $scope.waStudioModal.errorMessage = '';
            $scope.waStudioModal.diagFailure = null;
            $scope.waStudioModal.diagLogs = [];
        });

        try {
            await executeWaBatchVerification(items, byKey, serviceSlug, (statusMsg, doneCount, pipeStep) => {
                $scope.safeApply(() => {
                    const done = doneCount > 0 ? doneCount : $scope.waStudioModal.progressDone;
                    const pct = items.length > 0 ? Math.min(99, Math.max(8, Math.round((done / items.length) * 100))) : 10;
                    $scope.waStudioModal.statusMessage = statusMsg;
                    $scope.waStudioModal.progressDone = done;
                    $scope.waStudioModal.progressPercent = pct;
                    $scope.waStudioModal.elapsedSeconds = Math.max(1, Math.round((Date.now() - startedAtMs) / 1000));
                    if (pipeStep) $scope.waStudioModal.pipelineStep = pipeStep;
                    $scope.waApiStatusText = statusMsg;
                    $scope.waFinished = done;
                    if (isHistory && $scope.historyModal) {
                        $scope.historyModal.waBulkStatusText = statusMsg;
                        $scope.historyModal.waBulkFinished = done;
                    }
                });
            });

            const syncStartMs = Date.now();
            pushWaDiagStep(6, 'Sync Leads, History & Storage', 'running', `Saving verified statuses for ${items.length.toLocaleString()} leads...`);

            if (isHistory && hydratedSessions.length) {
                for (let h = 0; h < hydratedSessions.length; h++) {
                    const entry = hydratedSessions[h];
                    const stats = countSessionPhonesAndWa(entry.rows);
                    const bestCount = Math.max(parseInt(entry.fullSess.leadCount, 10) || 0, parseInt(entry.fullSess.rowCount, 10) || 0, entry.rows.length);
                    const updatedFull = Object.assign({}, entry.fullSess, {
                        rows: entry.rows,
                        leadCount: bestCount,
                        rowCount: bestCount,
                        phoneCount: stats.phoneCount,
                        waAvailableCount: stats.waAvailableCount,
                        isCompactPreview: false
                    });
                    await directIdbPutHistorySession(updatedFull);
                    try {
                        chrome.runtime.sendMessage({ action: 'scrape_history_put', session: updatedFull }, function() { try { void chrome.runtime.lastError; } catch (_) {} });
                    } catch (_) {}
                }
            }

            await syncVerifiedPhonesEverywhere(items, !isHistory);

            let validCnt = 0;
            let invalidCnt = 0;
            let unknownCnt = 0;
            items.forEach(item => {
                const st = normalizeCanonicalWaStatusLabel(item && item.row && item.row.whatsapp_status);
                if (st === 'Valid') validCnt++;
                else if (st === 'Invalid') invalidCnt++;
                else unknownCnt++;
            });

            pushWaDiagStep(
                6,
                'Sync Leads, History & Storage',
                'pass',
                `Synced ${validCnt.toLocaleString()} Valid & ${invalidCnt.toLocaleString()} Invalid across Leads, History & IndexedDB in ${Date.now() - syncStartMs}ms`
            );

            $scope.safeApply(() => {
                $scope.waChecking = false;
                $scope.waApiMode = false;
                $scope.waFinished = items.length;
                $scope.waApiStatusText = '✓ WhatsApp Verification Complete: ' + validCnt.toLocaleString() + ' Valid · ' + invalidCnt.toLocaleString() + ' Invalid';
                if ($scope.historyModal) {
                    $scope.historyModal.waBulkRunning = false;
                    $scope.historyModal.waBulkFinished = items.length;
                    $scope.historyModal.waBulkStatusText = $scope.waApiStatusText;
                }
                $scope.waStudioModal.step = 'complete';
                $scope.waStudioModal.pipelineStep = 4;
                $scope.waStudioModal.progressDone = items.length;
                $scope.waStudioModal.progressPercent = 100;
                $scope.waStudioModal.statusMessage = 'All leads updated across Leads, History, Storage & Exports!';
                $scope.waStudioModal.summary = {
                    total: items.length,
                    valid: validCnt,
                    invalid: invalidCnt,
                    unknown: unknownCnt
                };
                try { showTopStatusToast('✓ Verified ' + items.length.toLocaleString() + ' numbers (' + validCnt.toLocaleString() + ' Valid WhatsApp)!', 'success'); } catch (_) {}
            });
        } catch (err) {
            const msg = (err && err.message) ? err.message : String(err);
            items.forEach(item => {
                if (item && item.row && /checking via api|queued|pending/i.test(String(item.row.whatsapp_status || ''))) {
                    item.row.whatsapp_status = '';
                }
            });
            $scope.safeApply(() => {
                $scope.waChecking = false;
                $scope.waApiMode = false;
                $scope.waApiStatusText = '⚠ ' + msg;
                if ($scope.historyModal) {
                    $scope.historyModal.waBulkRunning = false;
                    $scope.historyModal.waBulkStatusText = '⚠ ' + msg;
                }
                $scope.waStudioModal.step = 'configure';
                $scope.waStudioModal.errorMessage = msg;
                try { showTopStatusToast('⚠ ' + msg, 'error'); } catch (_) {}
            });
        }
    };

    $scope.exportFromWaStudio = async function(onlyValid, format) {
        const isHistory = $scope.waStudioModal && $scope.waStudioModal.sourceMode === 'history';
        let rows = [];
        if (isHistory) {
            const selectedSessions = $scope.getHistorySelectedSessions();
            for (let i = 0; i < selectedSessions.length; i++) {
                const fullS = await loadHistorySessionRows(Object.assign({}, selectedSessions[i])).catch(() => selectedSessions[i]);
                rows = rows.concat(getRowsFromHistory(fullS));
            }
        } else {
            rows = await getCompleteRowsForExport();
        }
        rows = applyWaVerifiedCacheToRows(dedupeCanonicalRows(rows));
        if (onlyValid) {
            rows = rows.filter(r => r && normalizeCanonicalWaStatusLabel(r.whatsapp_status) === 'Valid');
        }
        if (!rows.length) {
            try { showTopStatusToast('⚠ No matching rows to export.', 'warn'); } catch (_) {}
            return;
        }
        $scope.waStudioModal.show = false;
        const priority = ['keyword', 'location', 'company_name', 'phone_number', 'whatsapp_status', 'review', 'total_reviews', 'category', 'address', 'city', 'state', 'pincode', 'website', 'email_1', 'map_link', 'photo_url', 'status', 'facebook', 'instagram', 'linkedin', 'twitter', 'youtube', 'place_id', 'cid'];
        const rank = k => { const idx = priority.indexOf(k); return idx >= 0 ? idx : 999; };
        const fieldSet = new Set(['keyword', 'location', 'company_name', 'phone_number', 'whatsapp_status', ...PocketLeadsExport.fields(rows, baseColumnList)]);
        const labels = Array.from(fieldSet).sort((a, b) => rank(a) - rank(b));
        const selected = {};
        labels.forEach(l => { selected[l] = true; });
        $scope.safeApply(() => {
            $scope.exportModal = {
                show: true,
                step: 'fields',
                activePreset: 'all',
                uniqueBy: 'phone_number',
                loading: false,
                fields: labels,
                selected: selected,
                format: format || 'csv',
                rows: rows,
                largeMode: false,
                rowCount: rows.length,
                isHistoryExport: true,
                customStamp: onlyValid ? 'WhatsApp_Valid_Leads' : 'WhatsApp_Verified_All'
            };
        });
    };

    $scope.waNumberCheck = async function() {
        if ($scope.waChecking) {
            $scope.waApiStopRequested = true;
            $scope.waChecking = false;
            $scope.waApiMode = false;
            $scope.waApiStatusText = 'Stopping WA API check...';
            return;
        }
        await $scope.openWaVerificationStudio('leads');
    };

    $scope.verifySelectedHistoryWhatsApp = async function($event) {
        if ($event) { $event.preventDefault(); $event.stopPropagation(); }
        if ($scope.historyModal && $scope.historyModal.waBulkRunning) {
            $scope.waApiStopRequested = true;
            $scope.historyModal.waBulkRunning = false;
            $scope.historyModal.waBulkStatusText = 'Stopping Bulk WhatsApp Verification...';
            return;
        }
        await $scope.openWaVerificationStudio('history');
    };

        /**
     * Listener for WA check updates sent from the background service worker.
     * When a message of type 'wa_check_update' is received the
     * corresponding row's whatsapp_status field is updated.  The
     * status strings returned from the background script ('REGISTERED'
     * or 'NOT_REGISTERED') are converted into human-friendly values
     * ('Available' / 'Not available').  Unknown or custom statuses are
     * displayed verbatim.  After updating the row the grid is
     * refreshed.
     */
    chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
        try {
            // v87 canonical realtime feed from the background ResultStore writer.
            // This bypasses chrome.storage preview/debounce latency entirely.
            if (msg && msg.action === 'PL_RESULT_STORE_DELTA' && Array.isArray(msg.rows)) {
                const currentRunId = $scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.runEventId;
                if (msg.runId && ($scope.startLaunchPending || !currentRunId)) {
                    $scope.startLaunchPending = false;
                    if ($scope.local) {
                        if (!$scope.local.apifyQueue) $scope.local.apifyQueue = {};
                        $scope.local.apifyQueue.runEventId = msg.runId;
                        $scope.local.apifyQueue.status = 'running';
                    }
                } else if (msg.runId && currentRunId && msg.runId !== currentRunId) {
                    return;
                }
                if (/^(stopped|cleared)$/.test(String($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.status || ''))) return;
                $scope.$evalAsync(() => {
                    try {
                        if (!$scope.local) return;
                        if (!Array.isArray($scope.local.collect)) $scope.local.collect = [];
                        const rows = $scope.local.collect;
                        const indexByKey = new Map();
                        const keyOf = (row, idx) => String((row && (row.place_id || row.cid || row.map_link || row.phone || ((row.company_name || row.name || '') + '|' + (row.address || '')))) || ('row_' + idx));
                        rows.forEach((row, idx) => indexByKey.set(keyOf(row, idx), idx));
                        msg.rows.forEach((incoming, idx) => {
                            if (!incoming || typeof incoming !== 'object') return;
                            normalizeDashboardRow(incoming);
                            ensureDashboardRowKey(incoming, rows.length + idx);
                            const key = keyOf(incoming, rows.length + idx);
                            if (key && indexByKey.has(key)) rows[indexByKey.get(key)] = Object.assign({}, rows[indexByKey.get(key)], incoming);
                            else { indexByKey.set(key, rows.length); rows.push(incoming); }
                        });
                        $scope.local.collect = dedupeDashboardRows(rows).slice(-5000);
                        const total = Math.max(parseInt(msg.total, 10) || 0, parseInt($scope._monotonicResultCount, 10) || 0, $scope.local.collect.length);
                        $scope.local.resultStoreCount = Math.max(parseInt($scope.local.resultStoreCount, 10) || 0, total);
                        $scope._monotonicResultCount = $scope.local.resultStoreCount;
                        try {
                            const curCnt = $scope.local.resultStoreCount || $scope.local.collect.length;
                            const nowCkptMs = Date.now();
                            if (curCnt > 0 && (curCnt - ($scope._lastHistoryCheckpointAtCount || 0)) >= 100 && (nowCkptMs - ($scope._lastHistoryCheckpointAtMs || 0)) >= 15000) {
                                $scope._lastHistoryCheckpointAtCount = curCnt;
                                $scope._lastHistoryCheckpointAtMs = nowCkptMs;
                                $scope.recordScrapingHistory('checkpoint', false);
                            }
                        } catch (_) {}
                        $scope.local.collectIsPreview = $scope.local.collect.length < $scope.local.resultStoreCount;
                        $scope.resultStoreHydrated = true;
                        refreshDashboardMetricCounts($scope.local.collect);
                        // Authoritative live write: never depend on a second async
                        // chrome.storage read to initialise the grid. That old race
                        // was the reason KPI/unique count could move while rows only
                        // appeared after a manual dashboard refresh.
                        const deferHiddenMobileGrid = ($scope.viewMode === 'mobile' && !$scope.mobileDataDrawerOpen && PocketLeadsRunState.isRunning($scope.local));
                        if (!deferHiddenMobileGrid) {
                            if (!dataGrid || !productsStore) buildDataTable($scope.local);
                            if (productsStore && typeof productsStore.setRows === 'function') {
                                const liveRows = safeCollectRows($scope.local);
                                productsStore.setRows(liveRows);
                                syncGridTrackingFromRows(liveRows);
                            } else {
                                insertIntoDataTable($scope.local);
                                updateDataTable($scope.local);
                            }
                        }
                        lastCollectDataCount = $scope.local.collect.length;
                        lastCollectUiSignature = computeCollectUiSignature($scope.local.collect);
                        try { $scope.updateUIState(); } catch (e) {}
                        if ($scope.local.collect.length < Math.min(5000, $scope.local.resultStoreCount) && typeof $scope.syncLiveCanonicalTable === 'function') {
                            $scope.syncLiveCanonicalTable($scope.local.resultStoreCount);
                        }
                    } catch (deltaUiErr) {
                        console.warn('PL_RESULT_STORE_DELTA UI update failed', deltaUiErr);
                    }
                });
                if (typeof sendResponse === 'function') sendResponse({ status: 'received' });
                return;
            }

            // Handle realtime updates from fast mode scraping.  The content script
            // sends a 'fast_update' message with a single row of data whenever
            // a new business is collected.  This branch inserts the row
            // directly into the local.collect array and refreshes the grid
            // without requiring the Maps tab to be active.  By updating
            // Angular’s model and the DataGrid here, the dashboard shows
            // results even when the search tab is hidden.
            // Unified handler for fast_mode updates.  Content scripts may send
            // messages via $box.sendToAll() (using an 'event' property) or
            // directly via chrome.runtime.sendMessage() (using either
            // 'action' or 'event').  Check both fields so the dashboard
            // responds to updates regardless of how they were sent.
            if (msg && (msg.action === 'fast_update' || msg.event === 'fast_update') && msg.data) {
                $scope.$evalAsync(() => {
                    try {
                        // Initialise collect array if missing
                        if (!$scope.local.collect) {
                            $scope.local.collect = [];
                        }
                        const rows = $scope.local.collect;
                        // Skip if this cid already exists
                        let duplicate = false;
                        if (msg.data.cid) {
                            duplicate = rows.some(item => item && item.cid === msg.data.cid);
                        }
                        if (!duplicate) {
                            rows.push(msg.data);
                            // Persist changes to storage
                            if (typeof $scope.saveLocal === 'function') {
                                $scope.saveLocal();
                            }
                            // Ensure the data grid exists.  If not, build and insert all rows.
                            if (typeof dataGrid !== 'undefined' && dataGrid) {
                                // Preserve scroll position during refresh
                                let scrollTop = 0;
                                try {
                                    const scrollable = dataGrid.getScrollable && dataGrid.getScrollable();
                                    if (scrollable && typeof scrollable.scrollTop === 'function') {
                                        scrollTop = scrollable.scrollTop();
                                    }
                                } catch (err) {
                                    // ignore scroll capture errors
                                }
                                insertIntoDataTable($scope.local);
                                updateDataTable($scope.local);
                                // Refresh the grid to reflect the new row
                                try {
                                    dataGrid.refresh && dataGrid.refresh();
                                } catch (err) {
                                    console.warn('fast_update: failed to refresh dataGrid', err);
                                }
                                // Restore previous scroll position
                                try {
                                    const scrollable2 = dataGrid.getScrollable && dataGrid.getScrollable();
                                    if (scrollable2 && typeof scrollable2.scrollTo === 'function') {
                                        scrollable2.scrollTo({ top: scrollTop });
                                    }
                                } catch (err) {
                                    // ignore scroll restore errors
                                }
                                // Update count tracker
                                lastCollectDataCount = rows.length;
                            } else {
                                // Data grid not yet built
                                lastCollectDataCount = 0;
                                buildDataTable();
                                insertIntoDataTable($scope.local);
                                lastCollectDataCount = rows.length;
                            }
                            // Update UI state such as progress bars and buttons
                            if (typeof $scope.updateUIState === 'function') {
                                $scope.updateUIState();
                            }
                        }
                    } catch (fastErr) {
                        console.warn('fast_update: error updating UI', fastErr);
                    }
                });
                // Respond to the sender (optional)
                if (typeof sendResponse === 'function') {
                    sendResponse({ status: 'received' });
                }
                return;
            }
            if (msg && msg.action === 'wa_check_update' && typeof msg.rowId !== 'undefined') {
                // Ignore updates when a WA check is not running.  This
                // prevents stale updates from a previous run after the
                // user has cancelled.
                if (!$scope.waChecking) {
                    return;
                }
                // Hide the login waiting prompt once a real update arrives.
                $scope.waLoginWaiting = false;
                const idx = msg.rowId;
                const statusStr = (msg.status || '').toString();
                const rows = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
                if (rows[idx]) {
                    // Convert machine status into a user‑friendly label
                    let formatted;
                    const low = statusStr.toLowerCase();
                    if (low === 'registered') {
                        formatted = 'Available';
                    } else if (low === 'not_registered' || low === 'not registered') {
                        formatted = 'Not available';
                    } else if (low === 'unknown') {
                        // Leave blank when the status is unknown.  This occurs
                        // when a lookup fails due to the user not being
                        // logged in or a communication error.  Showing an
                        // empty value avoids confusing "UNKNOWN" labels.
                        formatted = '';
                    } else {
                        formatted = statusStr;
                    }
                    rows[idx].whatsapp_status = formatted;
                    // Persist change and refresh grid
                    try {
                        if (typeof $scope.saveLocal === 'function') {
                            $scope.saveLocal();
                        }
                        updateDataTable($scope.local);
                    } catch (e) {
                        console.warn('wa_check_update: failed to refresh grid', e);
                    }
                    // Update progress counters.  Only count each row once
                    // even if multiple updates arrive (e.g. retries).  If
                    // msg.finished and msg.total are provided use them
                    // directly.  Otherwise compute finished by counting
                    // unique rows processed.
                        /*
                         * Updating progress counters inside a digest can throw
                         * a $rootScope:inprog error if $apply is invoked while
                         * Angular is already processing an update cycle.  Use
                         * safeApply (defined on the scope) to detect the
                         * current phase and either call the function directly
                         * or wrap it in $apply as appropriate.  This avoids
                         * nested $apply/$digest errors when WA updates arrive
                         * during other UI updates (e.g. scrolling or grid
                         * refreshes).
                         */
                        $scope.safeApply(() => {
                            try {
                                const cid = rows[idx] && rows[idx].cid;
                                // Only mark this cid as completed for progress if the status is final.
                                if (cid && !$scope.waCompletedIds[cid] && (rows[idx].whatsapp_status === 'Available' || rows[idx].whatsapp_status === 'Not available')) {
                                    $scope.waCompletedIds[cid] = true;
                                    // Remove this cid from the enqueued set as it is no longer pending.
                                    if ($scope.waEnqueuedIds[cid]) {
                                        delete $scope.waEnqueuedIds[cid];
                                    }
                                    // Mark the row index as completed for backwards compatibility.
                                    $scope.waCompletedRows[idx] = true;
                                    // Remove the row index from the enqueued rows map.
                                    if ($scope.waEnqueuedRows[idx]) {
                                        delete $scope.waEnqueuedRows[idx];
                                    }
                                }
                                // Update finished count based on unique completed IDs.
                                $scope.waFinished = Object.keys($scope.waCompletedIds).length;
                            } catch (progressErr) {
                                console.warn('wa_check_update: error updating progress', progressErr);
                            }
                            // Do not automatically mark the check as finished based solely on counts.
                            // Completion will be handled when the background run signals completion.
                        });
                }
            }
            // When the background script signals completion of the WA
            // check we mark the UI as idle.  This message arrives
            // regardless of whether the run finished normally or was
            // cancelled by the user.
            if (msg && msg.action === 'wa_check_complete') {
                // When the WA check finishes, determine whether there are
                // additional numbers to process.  Do not reset the local
                // progress counters based on the message's finished/total
                // values; instead use the existing waFinished/waTotal.  This
                // ensures that progress remains cumulative across runs during
                // an active scraping session.  Only on explicit stop/reset or
                // after scraping has ended will the progress be finalised.
                $scope.$evalAsync(() => {
                    try {
                        // Identify pending numbers: phone numbers whose cid has not
                        // yet been processed and is not currently enqueued.  Use
                        // stable cid identifiers to avoid rechecking numbers when
                        // row order changes.  Normalise phone numbers to digits.
                        const rows = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
                        const pending = [];
                        // Identify numbers whose status is not final (blank or interim).  Iterate through
                        // all rows in order so that unresolved entries near the top are processed first.
                        rows.forEach((row, idx) => {
                            const raw = row && row.phone ? String(row.phone).trim() : '';
                            if (!raw) return;
                            let digits = raw.replace(/\D/g, '');
                            digits = digits.replace(/^0+/, '');
                            if (!digits) return;
                            // Skip rows that already have a final status
                            if (row && (row.whatsapp_status === 'Available' || row.whatsapp_status === 'Not available')) {
                                return;
                            }
                            pending.push({ number: digits, rowId: idx });
                        });
                        if (pending.length > 0) {
                            // Start a new WA run with the remaining unresolved numbers.  Continue
                            // from the existing progress counters.  Reset the pending completion flag.
                            $scope.waChecking = true;
                            $scope.waPendingComplete = false;
                            // Reset the enqueued rows and identifiers, then populate
                            $scope.waEnqueuedRows = {};
                            $scope.waEnqueuedIds = {};
                            pending.forEach(item => {
                                const rowIdx = item.rowId;
                                const row = rows[rowIdx];
                                if (row && row.cid) {
                                    $scope.waEnqueuedIds[row.cid] = true;
                                }
                                $scope.waEnqueuedRows[rowIdx] = true;
                            });
                            // Do not update waTotal here.  New phone numbers will be
                            // accounted for via onLocalChange.  Pending numbers represent
                            // existing rows and should not change the session total.
                            try {
                                chrome.runtime.sendMessage({ action: 'start_wa_check', items: pending }, function() {});
                            } catch (err) {
                                console.warn('wa_check_complete: failed to restart WA run', err);
                            }
                        } else {
                            // No unresolved numbers remain.  If scraping is still active, enter a
                            // pending state and wait for new numbers to arrive via onLocalChange.
                            if ($scope.scrapingActive) {
                                $scope.waPendingComplete = true;
                                $scope.waChecking = false;
                            } else {
                                // Scraping is no longer active, complete the WA run.  Ensure
                                // progress counters reflect final values based on completed IDs.
                                $scope.waChecking = false;
                                $scope.waPendingComplete = false;
                                $scope.waFinished = Object.keys($scope.waCompletedIds).length;
                                // Update waTotal to reflect the current number of discovered phone numbers
                                $scope.waTotal = Object.keys($scope.waDiscoveredIds).length;
                                // Show the WA completion popup exactly once
                                $scope.handleWaCheckComplete($scope.waFinished, $scope.waTotal);
                                // If a scraping completion was suppressed earlier, now is
                                // the appropriate time to display it.
                                if ($scope.scrapingCompletePending) {
                                    $scope.scrapingCompletePending = false;
                                    try {
                                        $scope.handleScrapingComplete();
                                    } catch (scrapeCompleteErr) {
                                        console.warn('Failed to show suppressed scraping completion after WA', scrapeCompleteErr);
                                    }
                                }
                            }
                        }
                    } catch (completeErr) {
                        console.warn('wa_check_complete: error handling completion', completeErr);
                        // Fallback to showing the completion popup to avoid leaving
                        // the UI in an inconsistent state.  Use local counts.
                        try {
                            $scope.waChecking = false;
                            $scope.waPendingComplete = false;
                            // Ensure finished reflects completed IDs.  Do not modify
                            // waTotal here; it already represents the number of
                            // discovered phone numbers in the session.
                            $scope.waFinished = Object.keys($scope.waCompletedIds).length;
                            $scope.handleWaCheckComplete($scope.waFinished, $scope.waTotal);
                        } catch (fallbackErr) {
                            console.warn('wa_check_complete: fallback completion handler failed', fallbackErr);
                        }
                    }
                });
            }

            // When the background script reports that a WA run was
            // cancelled, reset the UI without showing a completion
            // popup.  Display a snackbar message instead.  This
            // message indicates that the user stopped the run.
            if (msg && msg.action === 'wa_check_cancelled') {
                // Use safeApply to avoid nested digest when cancelling WA run
                $scope.safeApply(() => {
                    // A WA run was cancelled (typically after the user pressed stop).
                    // Do not clear completed IDs so that progress persists for the
                    // current scraping session.  Only clear enqueued sets so that
                    // pending numbers are re-queued on the next start.
                    $scope.waChecking = false;
                    $scope.waLoginWaiting = false;
                    $scope.waPendingComplete = false;
                    $scope.waEnqueuedRows = {};
                    $scope.waEnqueuedIds = {};
                    // Recompute finished based on completed IDs to keep counters
                    // accurate.  Do not modify waTotal.
                    $scope.waFinished = Object.keys($scope.waCompletedIds).length;
                    // Recompute the total number of discovered phone numbers.
                    $scope.waTotal = Object.keys($scope.waDiscoveredIds).length;
                });
                try {
                    // Do not show the bottom snackbar when the user cancels.
                    // A desktop notification will still be sent by the
                    // background script, and the progress counters will be
                    // updated to reflect the partial run.
                } catch (err) {
                    // Suppress errors
                }
            }

            // When the background script reports that the extension is waiting
            // for the user to log in.  Set waLoginWaiting so the UI can
            // display a helpful message.  Initialize progress to zero and
            // assign the total from the message if provided.
            if (msg && msg.action === 'wa_check_login_waiting') {
                // Use safeApply to update UI during login waiting without nested digest
                $scope.safeApply(() => {
                    $scope.waChecking = true;
                    $scope.waLoginWaiting = true;
                    // Preserve the current finished/total counts while waiting for login.
                    $scope.waFinished = Object.keys($scope.waCompletedIds).length;
                    $scope.waTotal = Object.keys($scope.waDiscoveredIds).length;
                });
            }
            // When login has been detected after waiting, hide the login prompt.
            if (msg && msg.action === 'wa_check_login_success') {
                // Use safeApply to update login waiting flag without nested digest
                $scope.safeApply(() => {
                    $scope.waLoginWaiting = false;
                });
            }
            // When the background script reports that login failed (timed out or
            // user cancelled) reset the UI and show a warning notification.
            if (msg && msg.action === 'wa_check_login_failed') {
                // Login failed (user not logged in).  Stop the WA check, reset
                // progress counters and clear any temporary statuses.  Notify
                // the user with a clear message indicating the cause.
                $scope.safeApply(() => {
                    $scope.waChecking = false;
                    $scope.waLoginWaiting = false;
                    // Reset all session-scoped progress counters on login failure
                    $scope.waCompletedRows = {};
                    $scope.waEnqueuedRows = {};
                    $scope.waCompletedIds = {};
                    $scope.waEnqueuedIds = {};
                    $scope.waDiscoveredIds = {};
                    $scope.waFinished = 0;
                    $scope.waTotal = 0;
                    // Clear temporary whatsapp_status values on all rows so it
                    // is obvious that no check was performed.
                    const rows = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
                    rows.forEach(r => {
                        if (r) {
                            r.whatsapp_status = '';
                        }
                    });
                });
                try {
                    // Do not display the bottom snackbar when login fails.  A
                    // desktop notification is dispatched via the background
                    // script and the UI reflects the stopped state.
                } catch (err) {
                    // Suppress errors
                }
            }
        } catch (e) {
            console.warn('wa_check_update: error handling update', e);
        }
    });

});

// Jquery Data Table
// Hold a reference to the DevExtreme grid instance.  This is
// initialised on first load and re‑initialised whenever we rebuild
// the grid.  Using a module level variable allows us to persist
// settings such as the current page size across rebuilds.
var dataGrid = null;
// Underlying data store used by the DevExtreme data grid.  The
// ArrayStore is re‑created whenever the local.collect array
// changes.
var productsStore  = null;
// Track the previous number of rows inserted into the grid.  This
// prevents duplicate insert operations and reduces flicker when
// repeatedly pushing new items into the grid.
var lastCollectDataCount = 0;
var lastCollectUiSignature = '';
var lastCollectRowKeys = new Set();
var lastCollectRowHashes = new Map();

function computeCollectUiSignature(rows) {
    rows = Array.isArray(rows) ? rows : [];
    let hash = 2166136261;
    for (let i = 0; i < rows.length; i += 1) {
        const row = rows[i] || {};
        const text = [row.cid, row.place_id, row.company_name, row.name, row.phone, row.phone_number, row.email_1, row.email, row.website, row.address, row.category, row.whatsapp_status, row.wa_status, row.facebook, row.instagram, row.linkedin, row.twitter, row.youtube].join('|');
        for (let j = 0; j < text.length; j += 1) {
            hash ^= text.charCodeAt(j);
            hash = Math.imul(hash, 16777619);
        }
    }
    return rows.length + ':' + (hash >>> 0);
}
// Remember the last selected page size for the results grid.  When
// the user chooses 25/50/100 from the pager this value is updated.
// On subsequent rebuilds the same value is reused instead of
// defaulting back to 25.  Without this the grid resets to 25
// whenever new data arrives, causing the pager to jump back and
// triggering a distracting blink.
var currentPageSize = 25;
var lastColumnSignature = columnList.join("|");

function ensureDashboardRowKey(row, idx) {
    if (!row || typeof row !== 'object') return '';
    if (row.cid) return row.cid;
    const phone = waNormalizeDigitsSafe(rowPhoneValue(row));
    const base = row.place_id || row.map_link || row.company_name || row.website || phone || ('row_' + (idx || 0));
    row.cid = 'pl_' + String(base).replace(/[^a-zA-Z0-9]+/g, '_').slice(0, 80) + '_' + String(idx || 0);
    return row.cid;
}

function waNormalizeDigitsSafe(value) {
    return String(value || '').replace(/\D/g, '').replace(/^0+/, '');
}

function dedupeDashboardRows(rows) {
    const input = Array.isArray(rows) ? rows : [];
    const seen = new Set();
    return input.filter((row, index) => {
        if (!row || typeof row !== 'object') return false;
        const key = String(row.place_id || row.placeId || row.cid || row.map_link || row.phone ||
            ((row.company_name || row.name || '') + '|' + (row.address || row.formattedAddress || '')) || ('row_' + index));
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

function safeCollectRows(local){
    const rows = local && Array.isArray(local.collect) ? local.collect : [];
    repairLegacyProviderSources(rows, local);
    return rows.filter(row => row && typeof row === 'object').map((row, idx) => {
        normalizeDashboardRow(row);
        ensureDashboardRowKey(row, idx);
        return row;
    });
}

function gridRowHash(row) {
    try { return JSON.stringify(row || {}); } catch (e) { return String(row || ''); }
}

function insertIntoDataTable(local){
    if (!productsStore) return;
    const rows = safeCollectRows(local);
    const inserts = [];
    rows.forEach((row, idx) => {
        if (!row || typeof row !== 'object') return;
        const key = String(ensureDashboardRowKey(row, idx));
        const hash = gridRowHash(row);
        if (!lastCollectRowKeys.has(key)) {
            lastCollectRowKeys.add(key);
            lastCollectRowHashes.set(key, hash);
            inserts.push({ type: 'insert', data: row });
        } else if (!lastCollectRowHashes.has(key)) {
            lastCollectRowHashes.set(key, hash);
        }
    });
    lastCollectDataCount = rows.length;
    if (!inserts.length) return;
    try {
        productsStore.push(inserts);
    } catch (err) {
        console.debug('[PocketLeads] Batched grid insert deferred', err);
    }
}

function updateDataTable(local){
    if (!productsStore) return;
    const rows = safeCollectRows(local);
    const updates = [];
    rows.forEach((row, idx) => {
        if (!row || typeof row !== 'object') return;
        const key = String(ensureDashboardRowKey(row, idx));
        const hash = gridRowHash(row);
        const previous = lastCollectRowHashes.get(key);
        if (lastCollectRowKeys.has(key) && previous && previous !== hash) {
            lastCollectRowHashes.set(key, hash);
            updates.push({ type: 'update', key, data: row });
        }
    });
    if (!updates.length) return;
    try {
        productsStore.push(updates);
        if (dataGrid && dataGrid.refresh) dataGrid.refresh();
    } catch (err) {
        console.debug('[PocketLeads] Batched grid update deferred', err);
    }
}

function enableGridDragScroll(rootElement) {
    try {
        const root = rootElement && rootElement.jquery ? rootElement[0] : rootElement;
        if (!root || root.__pocketLeadsDragScrollBound) return;
        root.__pocketLeadsDragScrollBound = true;
        let active = false;
        let moved = false;
        let startX = 0;
        let startY = 0;
        let startLeft = 0;
        let startTop = 0;
        let scroller = null;
        const findScroller = target => {
            const rowsView = target && target.closest ? target.closest('.dx-datagrid-rowsview') : null;
            return rowsView ? rowsView.querySelector('.dx-scrollable-container') : root.querySelector('.dx-datagrid-rowsview .dx-scrollable-container');
        };
        root.addEventListener('mousedown', function(e) {
            if (e.button !== 0) return;
            const tag = String((e.target && e.target.tagName) || '').toLowerCase();
            if (['a', 'button', 'input', 'textarea', 'select', 'label'].includes(tag)) return;
            scroller = findScroller(e.target);
            if (!scroller) return;
            active = true;
            moved = false;
            startX = e.clientX;
            startY = e.clientY;
            startLeft = scroller.scrollLeft;
            startTop = scroller.scrollTop;
        }, true);
        document.addEventListener('mousemove', function(e) {
            if (!active || !scroller) return;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            if (!moved && Math.abs(dx) + Math.abs(dy) < 5) return;
            moved = true;
            root.classList.add('grid-dragging');
            scroller.scrollLeft = startLeft - dx;
            scroller.scrollTop = startTop - dy;
            e.preventDefault();
        }, true);
        document.addEventListener('mouseup', function() {
            if (active) root.classList.remove('grid-dragging');
            active = false;
            moved = false;
            scroller = null;
        }, true);
        root.addEventListener('wheel', function(e) {
            const sc = findScroller(e.target);
            if (!sc) return;
            if (Math.abs(e.deltaX) > Math.abs(e.deltaY) || e.shiftKey) {
                sc.scrollLeft += e.deltaX || e.deltaY;
                e.preventDefault();
            }
        }, { passive: false });
    } catch (err) {
        console.warn('enableGridDragScroll failed', err);
    }
}

let liveGridRenderEpoch = 0;

function syncGridTrackingFromRows(rows){
    const list = Array.isArray(rows) ? rows : [];
    lastCollectRowKeys = new Set();
    lastCollectRowHashes = new Map();
    list.forEach((row, idx) => {
        const key = String(ensureDashboardRowKey(row, idx));
        lastCollectRowKeys.add(key);
        lastCollectRowHashes.set(key, gridRowHash(row));
    });
    lastCollectDataCount = list.length;
    lastCollectUiSignature = computeCollectUiSignature(list);
}

function buildDataTable(sourceLocal){
    const render = local => {
        local = local || {};
        const container = document.getElementById('gridContainer');
        if (!container || !window.PocketLeadsLightGrid) return;
        const rows = safeCollectRows(local);
        const cols = buildColumnListFromRows(rows);
        if (dataGrid && dataGrid.__pocketLeadsLightGrid && productsStore) {
            productsStore.setRows(rows);
            syncGridTrackingFromRows(rows);
            // Columns may expand when the first rich provider row arrives.
            const nextColumnSignature = cols.join('|');
            if (nextColumnSignature !== lastColumnSignature && dataGrid && typeof dataGrid.setColumns === 'function') {
                try { dataGrid.setColumns(cols); } catch (e) {}
                lastColumnSignature = nextColumnSignature;
            }
            return;
        }
        try { if (dataGrid && typeof dataGrid.dispose === 'function') dataGrid.dispose(); } catch (e) {}
        productsStore = window.PocketLeadsLightGrid.createStore(rows, (row, idx) => String(ensureDashboardRowKey(row, idx)));
        syncGridTrackingFromRows(rows);
        dataGrid = window.PocketLeadsLightGrid.mount(container, {
            store: productsStore,
            columns: cols,
            pageSize: currentPageSize,
            isRowSelected: (row, key) => !!(window.__plGridBridge && window.__plGridBridge.isRowSelected(row, key)),
            getSelectedCount: () => (window.__plGridBridge ? window.__plGridBridge.getSelectedCount() : 0),
            onToggleSelect: (row, key, checked) => { if (window.__plGridBridge) window.__plGridBridge.onToggleSelect(row, key, checked); },
            onToggleSelectMany: (rowsList, checked) => { if (window.__plGridBridge) window.__plGridBridge.onToggleSelectMany(rowsList, checked); },
            onDeleteRow: (row, key) => { if (window.__plGridBridge) window.__plGridBridge.onDeleteRow(row, key); },
            onDeleteSelected: () => { if (window.__plGridBridge) window.__plGridBridge.onDeleteSelected(); },
            onExportSelected: () => { if (window.__plGridBridge) window.__plGridBridge.onExportSelected(); },
            onClearSelection: () => { if (window.__plGridBridge) window.__plGridBridge.onClearSelection(); },
            onOpenRowDetail: (row) => { if (window.__plGridBridge) window.__plGridBridge.onOpenRowDetail(row); },
            load: query => new Promise((resolve,reject)=>chrome.runtime.sendMessage({action:'result_store_query',query},r=>{if(chrome.runtime.lastError||!r?.ok)reject(Error('Results unavailable. Retry.'));else resolve(r);})),
            values: column => new Promise((resolve,reject)=>chrome.runtime.sendMessage({action:'result_store_query',query:{facet:column,limit:1}},r=>{if(chrome.runtime.lastError||!r?.ok)reject(Error('Filter values unavailable'));else resolve(r.values||[]);}))
        });
        if (dataGrid) dataGrid.__pocketLeadsLightGrid = true;
        lastColumnSignature = cols.join('|');
    };

    // Live/storage listeners already hold the newest merged model. Use it
    // synchronously so a stale storage callback can never overwrite a fresh
    // IndexedDB delta. Initial page load still hydrates from storage normally.
    if (sourceLocal && typeof sourceLocal === 'object') {
        // Any direct model is newer than an in-flight initial storage read.
        liveGridRenderEpoch += 1;
        render(sourceLocal);
        return;
    }
    const requestedAtEpoch = liveGridRenderEpoch;
    $box.getLocal(local => {
        // If a live delta/storage listener rendered while this async read was
        // pending, the callback is stale and must never replace fresher rows.
        if (liveGridRenderEpoch !== requestedAtEpoch) return;
        render(local);
    });
}
// On Window Load
$(()=>{    
    buildDataTable();
    
    // Removed the legacy interval that injected the "Results per page" label.
    // The label is now added once via the DataGrid's onContentReady hook to
    // avoid flicker and scroll jumps during scraping.

});

/* ---------------------------------------------------------------------------
 * Licence Modal Logic
 *
 * The following self‑invoking function implements a non‑blocking licence
 * activation modal overlay on top of the dashboard.  It mirrors the
 * functionality of popup/license.js but is adapted for an embedded modal.
 * When the extension loads it checks chrome.storage for an active licence.
 * If none is found the modal is displayed.  The modal validates input
 * client‑side, fetches the public IP, posts activation/release requests to
 * the Apps Script backend and stores licence state in chrome.storage.local.
 * It also exposes helper functions on the window object so that the
 * Angular controller can trigger a release from the navbar.
 * -------------------------------------------------------------------------*/
(function() {
    // The URL of the deployed Apps Script backend.  This must match the
    // endpoint configured in your Google Apps Script project.  The same
    // constant is defined in popup/license.js.  Update in one place
    // whenever your backend URL changes.
    const APPS_SCRIPT_URL = PocketLeadsConfig.endpoint;
    const LICENSE_SUPPORT_EMAIL = PocketLeadsConfig.supportEmail;

    // v99 license performance layer
    let backendRequestCache = new Map();
    let lastPingCache = null;
    let lastPingAt = 0;
    let licenceActivationInProgress = null;
    let licenceSessionValidated = false;

    /**
     * Retrieve the stored licence object from chrome.storage.local.
     *
     * @param {function(Object|undefined)} callback Invoked with the licence
     *        object or undefined if no licence is stored.
     */
    function getStoredLicence(callback) {
        try {
            chrome.storage.local.get('license', (result) => {
                let lic = result && result.license;
                if ((!lic || !lic.key) && !(lic && lic.invalidatedAt)) {
                    try {
                        if (localStorage.getItem('pl_explicit_logout_v1') !== '1') {
                            const raw = localStorage.getItem('pl_activated_licence_backup_v1');
                            if (raw) {
                                const parsed = JSON.parse(raw);
                                if (parsed && parsed.license && parsed.license.key && parsed.license.active) {
                                    lic = parsed.license;
                                    chrome.storage.local.set({
                                        license: parsed.license,
                                        ...(parsed.pocketleadsAccount ? { pocketleadsAccount: parsed.pocketleadsAccount } : {})
                                    });
                                }
                            }
                        }
                    } catch (_) {}
                }
                callback(lic);
            });
        } catch (err) {
            console.error('Error reading licence from storage', err);
            callback(undefined);
        }
    }

    /**
     * Persist the given licence to chrome.storage.local.  Passing null
     * removes the entry entirely.
     *
     * @param {Object|null} licence
     */
    function setStoredLicence(licence) {
        try {
            if (!licence) {
                chrome.storage.local.remove(['license','pocketleadsAccount','pocketleadsPreparedRoute','pocketleadsPreflightState']);
            } else {
                chrome.storage.local.set({ license: licence });
            }
        } catch (err) {
            console.error('Error saving licence to storage', err);
        }
    }

    /**
     * Obtain the user's public IPv4 address from ipify.org.  On error
     * the promise rejects.
     *
     * @returns {Promise<string>}
     */
    async function getInstallationId() {
        try {
            const permId = String(localStorage.getItem('pl_permanent_device_id_v1') || '').trim();
            if (permId && permId.length >= 10) return permId;
        } catch (e) {}
        const saved = (await PocketLeadsAccount.read()).license;
        if (saved && saved.installationId) {
            try { localStorage.setItem('pl_permanent_device_id_v1', String(saved.installationId)); } catch (e) {}
            return saved.installationId;
        }
        try {
            const existingFallback = String(localStorage.getItem('pl_mobile_fallback_device_id') || '').trim();
            if (existingFallback && existingFallback.length >= 10) {
                try { localStorage.setItem('pl_permanent_device_id_v1', existingFallback); } catch (e) {}
                return existingFallback;
            }
        } catch (e) {}
        try {
            if (window.PocketLeadsDeviceIdentity && typeof window.PocketLeadsDeviceIdentity.get === 'function') {
                const identity = await Promise.race([
                    window.PocketLeadsDeviceIdentity.get(),
                    new Promise(resolve => setTimeout(() => resolve(null), 1500))
                ]);
                const id = String(identity && identity.id || '').trim();
                if (id) {
                    try {
                        localStorage.setItem('pl_permanent_device_id_v1', id);
                        localStorage.setItem('pl_mobile_fallback_device_id', id);
                    } catch (e) {}
                    return id;
                }
            }
        } catch (e) {}
        const fallback = 'pl_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2);
        try {
            localStorage.setItem('pl_permanent_device_id_v1', fallback);
            localStorage.setItem('pl_mobile_fallback_device_id', fallback);
        } catch (e) {}
        return fallback;
    }


    // Legacy-only fallback for releasing pre-v82 IP-bound activations.
    async function fetchPublicIP() {
        const resp = await fetch('https://api.ipify.org?format=json');
        const json = await resp.json();
        if (!json || !json.ip) throw new Error('Invalid IP response');
        return json.ip;
    }

    /**
     * Send a JSON POST request to the Apps Script backend.  The payload
     * must include an action ('activate' or 'release'), the licence key
     * and the public IP.  Returns the parsed JSON response or undefined
     * if parsing fails.
     *
     * @param {string} action
     * @param {string} key
     * @param {string} ip
     * @returns {Promise<Object|undefined>}
     */
    async function callBackend(action, key, deviceId, legacyIp, legacyDeviceId) {
        return PocketLeadsAccount.request(action, key, deviceId, legacyIp, legacyDeviceId);
    }

    async function migrateLicenceDeviceIfNeeded(lic) {
        if (!lic || !lic.key) return lic;
        const stableDeviceId = await getInstallationId();
        if (!stableDeviceId) return lic;
        const previousDeviceId = String(lic.installationId || '').trim();
        if (previousDeviceId === stableDeviceId && Number(lic.identityVersion || 0) >= 2) return lic;
        const ping = await callBackend('ping', '', '', '');
        if (!ping || ping.status !== 'ok' || ping.physicalDeviceLicensing !== true) return lic;
        let legacyIp = '';
        try { legacyIp = await fetchPublicIP(); } catch (e) {}
        const resp = await callBackend('activate', lic.key, stableDeviceId, legacyIp, previousDeviceId);
        if (!resp || resp.status !== 'ok') return lic;
        const updated = Object.assign({}, lic, {
            active: true,
            installationId: stableDeviceId,
            identityVersion: 2,
            devices: resp.count != null ? resp.count : lic.devices,
            expiryDate: resp.expiryDate || lic.expiryDate || '',
            googleMapsCredit: resp.googleMapsCredit != null ? resp.googleMapsCredit : lic.googleMapsCredit,
            structuredCredit: resp.structuredCredit != null ? resp.structuredCredit : lic.structuredCredit,
            purchaseCredit: resp.purchaseCredit != null ? resp.purchaseCredit : lic.purchaseCredit,
            supportEmail: resp.supportEmail || LICENSE_SUPPORT_EMAIL
        });
        setStoredLicence(updated);
        return updated;
    }

    /**
     * Display the licence modal overlay.  Before showing, update the UI
     * based on the currently stored licence to show either the login or
     * logged section.
     */
    function showLicenseModal() {
        const overlay=document.getElementById('licenseOverlay');
        getStoredLicence(lic=>{updateModalUI(lic);if(overlay)overlay.style.display='flex';});
    }

    /**
     * Hide the licence modal overlay.
     */
    function hideLicenseModal() {
        const overlay = document.getElementById('licenseOverlay');
        if (overlay && licenceSessionValidated) {
            overlay.style.display = 'none';
        }
    }

    /**
     * Update the modal UI to reflect the given licence object.  If the
     * licence is active, hide the login section and display the logged
     * section along with the device count.  If inactive, show the login
     * form and reset inputs.
     *
     * @param {Object|undefined} lic
     */
    function updateModalUI(lic) {
        try {
            const $scope = angular.element(document.body).scope() || angular.element(document.querySelector('[ng-controller="indexController"]')).scope();
            if ($scope) {
                $scope.$applyAsync(() => {
                    $scope.licenseActive = !!(lic && lic.active);
                    $scope.licenseDevices = (lic && lic.devices != null) ? lic.devices : 0;
                    if (typeof $scope.updateUIState === 'function') $scope.updateUIState();
                });
            }
        } catch (_) {}
        const loginSec = document.getElementById('loginSection');
        const loggedSec = document.getElementById('loggedSection');
        const deviceCountEl = document.getElementById('deviceCountModal');
        const planMetaEl = document.getElementById('licensePlanMetaModal');
        if (!loginSec || !loggedSec) {
            return;
        }
        if (lic && lic.active) {
            loginSec.style.display = 'none';
            loggedSec.style.display = 'block';
            if (deviceCountEl) deviceCountEl.textContent = lic.devices != null ? lic.devices : '0';
            if (planMetaEl) {
                const fmt = value => value == null || value === '' ? 'Unavailable' : String(value).toLowerCase() === 'unlimited' ? 'Unlimited' : String(value);
                const expiry = lic.expiryDate ? `Valid until: ${lic.expiryDate}` : 'Validity: ' + (lic.validityLabel || 'Server managed');
                planMetaEl.textContent = `${expiry} • Available Credit: ${fmt(lic.availableCredit)} • Purchased Credit: ${fmt(lic.purchasedCredit)}`;
            }
            // Update angular scope values to keep navbar in sync
            try {
                const $scope = angular.element(document.body).scope();
                $scope.$applyAsync(() => {
                    $scope.licenseActive = true;
                    $scope.licenseDevices = lic.devices != null ? lic.devices : 0;
                });
            } catch (err) {
                // ignore if Angular is not ready
            }
        } else {
            loginSec.style.display = 'block';
            loggedSec.style.display = 'none';
            if (deviceCountEl) deviceCountEl.textContent = '0';
            if (planMetaEl) planMetaEl.textContent = '';
            const pStep = document.getElementById('phoneStepModal');
            const oStep = document.getElementById('otpStepModal');
            if (pStep) pStep.style.display = 'block';
            if (oStep) oStep.style.display = 'none';
            const otpIn = document.getElementById('otpInputModal');
            if (otpIn) otpIn.value = '';
            const phoneIn = document.getElementById('phoneInputModal');
            if (phoneIn) phoneIn.disabled = false;
            const sendBtn = document.getElementById('sendOtpBtnModal');
            if (sendBtn) sendBtn.disabled = false;
            try {
                const $scope = angular.element(document.body).scope();
                $scope.$applyAsync(() => {
                    $scope.licenseActive = false;
                    $scope.licenseDevices = 0;
                });
            } catch (err) {
                // ignore
            }
        }
        // Hide any previous error and spinner
        const errEl = document.getElementById('licenseErrorModal');
        const spinner = document.getElementById('spinnerModal');
        const submitBtn = document.getElementById('submitButtonModal');
        const keyInput = document.getElementById('licenseKeyInputModal');
        if (errEl) errEl.style.display = 'none';
        if (spinner) spinner.style.display = 'none';
        if (submitBtn) submitBtn.disabled = false;
        if (keyInput) keyInput.disabled = false;
        const logoutBtn = document.getElementById('logoutButtonModal');
        if (logoutBtn) logoutBtn.disabled = false;
    }

    /**
     * Release the stored licence via the backend.  Returns a promise that
     * resolves on success or rejects on error.  On success the local
     * licence entry is removed.
     *
     * @returns {Promise<void>}
     */
    async function releaseLicenceInternal() {
        return new Promise((resolve) => {
            getStoredLicence(async (lic) => {
                const keyToRelease = (lic && lic.key) ? String(lic.key).trim() : '';
                const installationId = (lic && lic.installationId) ? String(lic.installationId).trim() : '';
                // Immediately clear local state so logout is 1-click instant and never blocked
                licenceSessionValidated = false;
                try {
                    if (typeof localStorage !== 'undefined') {
                        localStorage.setItem('pl_explicit_logout_v1', '1');
                        localStorage.removeItem('pl_activated_licence_backup_v1');
                    }
                } catch (_) {}
                try {
                    if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.cancelAllNotifications === 'function') {
                        window.AndroidChromeBridge.cancelAllNotifications();
                    }
                } catch (_) {}
                setStoredLicence(null);
                if (!keyToRelease) {
                    resolve();
                    return;
                }
                try {
                    let legacyIp = '';
                    if (!installationId) {
                        try { legacyIp = await fetchPublicIP(); } catch (_) {}
                    }
                    await callBackend('release', keyToRelease, installationId, legacyIp);
                } catch (err) {
                    console.warn('Backend release completed locally (offline/slow network):', err);
                }
                resolve();
            });
        });
    }

    // Expose functions so Angular controller can call them
    window.showLicenseModal = showLicenseModal;
    window.hideLicenseModal = hideLicenseModal;
    window.releaseLicenceInternal = releaseLicenceInternal;

    // When the document is ready, initialise the modal logic
    $(function() {
        // Cached confirmed state is display-only; server preflight protects paid actions.
        const initialOverlay = document.getElementById('licenseOverlay');
        if (initialOverlay) initialOverlay.style.display = 'none';
        getStoredLicence(async lic => {
            if (lic && (lic.active || lic.validating) && lic.key) {
                licenceSessionValidated = true;
                if (lic.validating) { lic = Object.assign({},lic,{active:true,validating:false}); setStoredLicence(lic); }
                updateModalUI(lic); hideLicenseModal();
                try {
                    const status = await PocketLeadsAccount.refresh({maxAgeMs:30000});
                    const latest = (await PocketLeadsAccount.read()).license;
                    if (latest && latest.active) { updateModalUI(latest); hideLicenseModal(); }
                    else if (latest && !latest.active) { licenceSessionValidated=false; updateModalUI(latest); if(initialOverlay) initialOverlay.style.display='flex'; }
                } catch (_) { /* Account panel exposes retry; keep confirmed cached UI. */ }
            } else { updateModalUI(null); if(initialOverlay) initialOverlay.style.display='flex'; }
        });
        chrome.storage.onChanged.addListener((changes,area)=>{
            if(area!=='local'||!changes.license)return;
            const lic=changes.license.newValue;
            licenceSessionValidated=!!(lic&&lic.active);
            updateModalUI(lic);
            if(initialOverlay)initialOverlay.style.display=licenceSessionValidated?'none':'flex';
        });

        // Listen for events broadcast from the background script.  When
        // 'open_license_modal' is received we refresh the modal UI from
        // storage and display it.  Using $box.on ensures the event is
        // routed through the extension's internal messaging bus.
        try {
            $box.on((evt, data) => {
                if (evt === 'open_license_modal') {
                    getStoredLicence((lic) => {
                        updateModalUI(lic);
                        showLicenseModal();
                    });
                }
            });
        } catch (err) {
            console.warn('Failed to register open_license_modal listener', err);
        }

        
        // Listen for background Admin Sheet licence revocation (inactive/expired)
        try {
            chrome.runtime.onMessage.addListener((msg) => {
                if (msg && msg.action === 'pl_licence_revoked_by_admin') {
                    licenceSessionValidated = false;
                    try {
                        const $scope = angular.element(document.body).scope();
                        if ($scope) {
                            if ($scope.local && $scope.local.isScrapingEmail && typeof $scope.stopEmailScraping === 'function') {
                                $scope.stopEmailScraping();
                            }
                            if (typeof showTopStatusToast === 'function') {
                                showTopStatusToast('⚠ ' + (msg.message || 'This licence is inactive. Please contact admin.'), 'warn');
                            }
                        }
                    } catch (_) {}
                    updateModalUI(null);
                    const overlay = document.getElementById('licenseOverlay');
                    if (overlay) overlay.style.display = 'flex';
                    const errEl = document.getElementById('licenseErrorModal');
                    if (errEl) {
                        errEl.textContent = msg.message || 'This licence is inactive. Please contact admin.';
                        errEl.style.display = 'block';
                    }
                }
            });
        } catch (_) {}

        // =====================================================================
        // Phone Number + 6-Digit OTP Login Flow (with Android SMS User Consent)
        // =====================================================================
        let modalOtpSession = { phone10: '', otpToken: '', resendTimer: null, resendLeft: 0 };

        function stopAndroidSmsConsentModal() {
            try {
                if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.stopSmsUserConsent === 'function') {
                    window.AndroidChromeBridge.stopSmsUserConsent();
                }
            } catch (_) {}
        }

        function startAndroidSmsConsentModal() {
            try {
                if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.startSmsUserConsentAsync === 'function') {
                    const cbId = 'pl_sms_otp_modal_' + Date.now();
                    window.__plNativeCallbacks = window.__plNativeCallbacks || {};
                    window.__plNativeCallbacks[cbId] = function(rawJson) {
                        try {
                            const res = typeof rawJson === 'string' ? JSON.parse(rawJson) : rawJson;
                            if (res && res.ok && res.otp) {
                                handleAutoFilledOtpModal(String(res.otp));
                            }
                        } catch (_) {}
                    };
                    window.AndroidChromeBridge.startSmsUserConsentAsync(cbId);
                }
            } catch (_) {}
        }

        function syncOtpBoxesToHiddenModal() {
            let code = '';
            $('#otpBoxesModal .pl-otp-box').each(function() {
                const v = String($(this).val() || '').replace(/\D+/g, '').slice(-1);
                $(this).val(v).toggleClass('is-filled', v.length === 1);
                code += v;
            });
            $('#otpInputModal').val(code);
            return code;
        }
        function fillOtpBoxesModal(rawCode) {
            const digits = String(rawCode || '').replace(/\D+/g, '').slice(0, 6);
            $('#otpBoxesModal .pl-otp-box').each(function(i) {
                const ch = digits.charAt(i) || '';
                $(this).val(ch).toggleClass('is-filled', ch.length === 1);
            });
            $('#otpInputModal').val(digits);
            return digits;
        }
        function clearOtpBoxesModal() {
            fillOtpBoxesModal('');
        }
        $('#otpBoxesModal').on('input', '.pl-otp-box', function() {
            const raw = String($(this).val() || '').replace(/\D+/g, '');
            const idx = Number($(this).attr('data-otp-idx')) || 0;
            if (raw.length > 1) {
                const filled = fillOtpBoxesModal(raw);
                if (filled.length === 6) $('#verifyOtpBtnModal').trigger('click');
                return;
            }
            $(this).val(raw).toggleClass('is-filled', raw.length === 1);
            const code = syncOtpBoxesToHiddenModal();
            if (raw.length === 1 && idx < 5) {
                $('#otpBoxesModal .pl-otp-box[data-otp-idx="' + (idx + 1) + '"]').focus();
            } else if (code.length === 6) {
                $('#verifyOtpBtnModal').trigger('click');
            }
        });
        $('#otpBoxesModal').on('keydown', '.pl-otp-box', function(e) {
            const idx = Number($(this).attr('data-otp-idx')) || 0;
            if (e.key === 'Backspace' && !$(this).val() && idx > 0) {
                const prev = $('#otpBoxesModal .pl-otp-box[data-otp-idx="' + (idx - 1) + '"]');
                prev.val('').removeClass('is-filled').focus();
                syncOtpBoxesToHiddenModal();
            } else if (e.key === 'Enter') {
                e.preventDefault();
                $('#verifyOtpBtnModal').trigger('click');
            }
        });
        $('#otpBoxesModal').on('paste', '.pl-otp-box', function(e) {
            const clip = (e.originalEvent && e.originalEvent.clipboardData) ? e.originalEvent.clipboardData.getData('text') : '';
            const digits = String(clip || '').replace(/\D+/g, '').slice(0, 6);
            if (digits.length > 0) {
                e.preventDefault();
                fillOtpBoxesModal(digits);
                if (digits.length === 6) $('#verifyOtpBtnModal').trigger('click');
            }
        });
        function handleAutoFilledOtpModal(otpCode) {
            const clean = String(otpCode || '').replace(/\D+/g, '').slice(0, 6);
            if (clean.length !== 6) return;
            const otpStepVisible = $('#otpStepModal').is(':visible');
            if (!otpStepVisible) return;
            fillOtpBoxesModal(clean);
            $('#verifyOtpBtnModal').trigger('click');
        }

        window.__onAndroidSmsOtpReceived = function(otpCode) {
            handleAutoFilledOtpModal(otpCode);
        };

        function startModalResendCountdown(seconds) {
            if (modalOtpSession.resendTimer) clearInterval(modalOtpSession.resendTimer);
            modalOtpSession.resendLeft = Math.max(1, Number(seconds) || 30);
            const btn = $('#resendOtpBtnModal');
            btn.prop('disabled', true).text('Resend in ' + modalOtpSession.resendLeft + 's');
            modalOtpSession.resendTimer = setInterval(function() {
                modalOtpSession.resendLeft--;
                if (modalOtpSession.resendLeft <= 0) {
                    clearInterval(modalOtpSession.resendTimer);
                    modalOtpSession.resendTimer = null;
                    btn.prop('disabled', false).text('Resend OTP');
                } else {
                    btn.prop('disabled', true).text('Resend in ' + modalOtpSession.resendLeft + 's');
                }
            }, 1000);
        }

        $('#phoneInputModal').on('input', function() {
            const cleaned = String($(this).val() || '').replace(/\D+/g, '').slice(0, 10);
            $(this).val(cleaned);
        });
        $('#otpInputModal').on('input', function() {
            const cleaned = String($(this).val() || '').replace(/\D+/g, '').slice(0, 6);
            $(this).val(cleaned);
        });
        $('#phoneInputModal').on('keydown', function(e) {
            if (e.key === 'Enter') { e.preventDefault(); $('#sendOtpBtnModal').trigger('click'); }
        });
        $('#otpInputModal').on('keydown', function(e) {
            if (e.key === 'Enter') { e.preventDefault(); $('#verifyOtpBtnModal').trigger('click'); }
        });

        $('#changePhoneBtnModal').on('click', function() {
            stopAndroidSmsConsentModal();
            if (modalOtpSession.resendTimer) { clearInterval(modalOtpSession.resendTimer); modalOtpSession.resendTimer = null; }
            modalOtpSession.otpToken = '';
            $('#licenseErrorModal').hide();
            $('#otpInputModal').val('');
            $('#otpStepModal').hide();
            $('#phoneStepModal').show();
            $('#phoneInputModal').focus();
        });

        async function triggerSendOtpModal() {
            const errEl = $('#licenseErrorModal');
            errEl.hide();
            const phone10 = String($('#phoneInputModal').val() || '').replace(/\D+/g, '').slice(-10);
            $('#phoneInputModal').val(phone10);
            if (!/^[6-9]\d{9}$/.test(phone10)) {
                errEl.text('Please enter a valid 10-digit Indian mobile number.').show();
                return;
            }
            const sendBtn = $('#sendOtpBtnModal');
            const resendBtn = $('#resendOtpBtnModal');
            sendBtn.prop('disabled', true).html('<span class="pl-btn-spinner"></span>Checking & Sending OTP...');
            resendBtn.prop('disabled', true);
            $('#phoneInputModal').prop('disabled', true);
            $('#spinnerModal').text('Checking registration & sending OTP...').show();
            try {
                const deviceId = await Promise.race([
                    getInstallationId(),
                    new Promise(resolve => setTimeout(() => resolve(''), 2500))
                ]);
                const resp = await PocketLeadsAccount.sendOtp(phone10, deviceId);
                if (!resp || !resp.status) {
                    errEl.text('Network error. Please check your internet connection and try again.').show();
                } else if (resp.status === 'ok' && resp.otpSent) {
                    modalOtpSession.phone10 = phone10;
                    modalOtpSession.otpToken = String(resp.otpToken || '');
                    $('#otpSentInfoModal').text('OTP sent to +91 ' + phone10 + ' • Valid for 5 minutes');
                    $('#phoneStepModal').hide();
                    $('#otpStepModal').show();
                    clearOtpBoxesModal();
                    $('#otpBoxesModal .pl-otp-box[data-otp-idx="0"]').focus();
                    startModalResendCountdown(resp.resendAfterSec || 30);
                    startAndroidSmsConsentModal();
                } else if (resp.status === 'not_registered' || resp.reason === 'phone_not_registered') {
                    errEl.text('This phone number is not registered. Please contact admin.').show();
                } else if (resp.status === 'inactive') {
                    errEl.text('This account is inactive. Please contact admin.').show();
                } else if (resp.status === 'expired') {
                    errEl.text(`This licence expired${resp.expiryDate ? ' on ' + resp.expiryDate : ''}. Contact ${resp.supportEmail || LICENSE_SUPPORT_EMAIL} to renew.`).show();
                } else if (resp.status === 'rate_limited') {
                    const waitS = Number(resp.retryAfterSec || 30);
                    errEl.text(resp.message || ('Please wait ' + waitS + ' seconds before trying again.')).show();
                } else {
                    errEl.text(resp.message || 'Unable to send OTP right now. Please try again.').show();
                }
            } catch (err) {
                console.error('Error sending OTP', err);
                errEl.text((err && err.message) || 'Network error while sending OTP. Please retry.').show();
            } finally {
                $('#spinnerModal').hide();
                sendBtn.prop('disabled', false).text('Send OTP');
                $('#phoneInputModal').prop('disabled', false);
                if (!modalOtpSession.resendTimer) resendBtn.prop('disabled', false);
            }
        }

        $('#sendOtpBtnModal').on('click', triggerSendOtpModal);
        $('#resendOtpBtnModal').on('click', triggerSendOtpModal);

        $('#verifyOtpBtnModal').on('click', async function() {
            const errEl = $('#licenseErrorModal');
            errEl.hide();
            const phone10 = modalOtpSession.phone10 || String($('#phoneInputModal').val() || '').replace(/\D+/g, '').slice(-10);
            const otpCode = syncOtpBoxesToHiddenModal() || String($('#otpInputModal').val() || '').replace(/\D+/g, '').trim();
            if (!/^\d{6}$/.test(otpCode)) {
                errEl.text('Please enter the complete 6-digit OTP sent to your phone.').show();
                $('#otpBoxesModal .pl-otp-box').filter(function(){ return !$(this).val(); }).first().focus();
                return;
            }
            try { if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); } catch (_) {}
            const verifyBtn = $('#verifyOtpBtnModal');
            verifyBtn.prop('disabled', true).html('<span class="pl-btn-spinner"></span>Verifying OTP...');
            $('#otpBoxesModal .pl-otp-box').prop('disabled', true);
            $('#spinnerModal').text('Verifying OTP & logging you in...').show();
            try {
                const activationInstallationId = await Promise.race([
                    getInstallationId(),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('Device identity timeout')), 3000))
                ]);
                const previousLicence = await new Promise(resolve => getStoredLicence(resolve));
                const previousDeviceId = previousLicence && previousLicence.installationId ? String(previousLicence.installationId) : '';
                const resp = await PocketLeadsAccount.verifyOtp(phone10, otpCode, modalOtpSession.otpToken, activationInstallationId, previousDeviceId);
                if (!resp || !resp.status) {
                    errEl.text('Network is slow. Please check your internet connection and try again.').show();
                } else if (resp.status === 'ok') {
                    stopAndroidSmsConsentModal();
                    if (modalOtpSession.resendTimer) { clearInterval(modalOtpSession.resendTimer); modalOtpSession.resendTimer = null; }
                    const count = (resp.count != null ? resp.count : 1);
                    const storedLicence = {
                        key: resp.key || resp.licenceKey || '',
                        phone: phone10,
                        active: true,
                        devices: count,
                        installationId: activationInstallationId,
                        identityVersion: 2,
                        expiryDate: resp.expiryDate || '',
                        googleMapsCredit: resp.googleMapsCredit != null ? resp.googleMapsCredit : null,
                        structuredCredit: resp.structuredCredit != null ? resp.structuredCredit : null,
                        purchaseCredit: resp.purchaseCredit != null ? resp.purchaseCredit : null,
                        supportEmail: resp.supportEmail || LICENSE_SUPPORT_EMAIL
                    };
                    Object.assign(storedLicence, (await PocketLeadsAccount.read()).license);
                    try { chrome.runtime.sendMessage({ action: 'pocketleads_warm_backend', reason: 'licence_activation', force: false }, function(){ void chrome.runtime.lastError; }); } catch (e) {}
                    licenceSessionValidated = true;
                    updateModalUI(storedLicence);
                    hideLicenseModal();
                    try {
                        if (typeof window.triggerPrivacyPolicyPrompt === 'function') {
                            setTimeout(function() { window.triggerPrivacyPolicyPrompt(false); }, 80);
                        }
                    } catch (_) {}
                } else if (resp.status === 'expired') {
                    errEl.text(`This licence expired${resp.expiryDate ? ' on ' + resp.expiryDate : ''}. Contact ${resp.supportEmail || LICENSE_SUPPORT_EMAIL} to renew.`).show();
                } else if (resp.status === 'inactive') {
                    errEl.text('This licence is inactive. Please contact admin.').show();
                } else if (resp.status === 'rate_limited') {
                    errEl.text(resp.message || 'Too many attempts. Please wait and request a new OTP.').show();
                } else if (resp.status === 'denied') {
                    const reason = String(resp.reason || '');
                    if (/device|installation/i.test(reason)) errEl.text('This device is not authorized for this licence. Activate it if fewer than 3 devices are currently active.').show();
                    else errEl.text('This licence already has 3 active devices. Release one device before activating a new device.').show();
                } else {
                    errEl.text(resp.message || 'Invalid or expired OTP. Please try again.').show();
                }
            } catch (err) {
                console.error('Error verifying OTP', err);
                errEl.text((err && err.message) || 'Network error while verifying OTP. Please retry.').show();
            } finally {
                $('#spinnerModal').hide();
                verifyBtn.prop('disabled', false).text('Verify & Login');
                $('#otpBoxesModal .pl-otp-box').prop('disabled', false);
            }
        });

        // Bind activation handler (legacy licence key fallback)
        $('#submitButtonModal').on('click', async function() {
            const errEl = $('#licenseErrorModal');
            errEl.hide();
            const input = $('#licenseKeyInputModal');
            // Normalize mobile clipboard invisible chars, spaces, and en/em dashes
            const key = String(input.val() || '')
                .replace(/[\u200B-\u200D\uFEFF\u00A0\s]+/g, '')
                .replace(/[\u2010-\u2015\u2212]/g, '-')
                .replace(/^[`'"<>{}\[\]()]+|[`'"<>{}\[\](),;]+$/g, '')
                .toUpperCase();
            input.val(key);
            const regex = /^[A-Z0-9]{4,8}-[A-Z0-9]{4,8}$/;
            if (!regex.test(key)) {
                errEl.text('Invalid license key format (expected e.g. ABCDE-12345).').show();
                return;
            }
            const submitBtn = $('#submitButtonModal');
            let activationInstallationId = '';
            submitBtn.prop('disabled', true);
            input.prop('disabled', true);
            $('#spinnerModal').show();
            try {
                if (licenceActivationInProgress) {
                    const existing = await licenceActivationInProgress;
                    if (existing) return;
                }
                licenceActivationInProgress = (async () => {
                    activationInstallationId = await Promise.race([
                        getInstallationId(),
                        new Promise((_, reject) => setTimeout(() => reject(new Error('Device identity timeout')), 3000))
                    ]);
                    const legacyIp = '';
                    const previousLicence = await new Promise(resolve => getStoredLicence(resolve));
                    const previousDeviceId = previousLicence && String(previousLicence.key || '').toUpperCase() === key ? String(previousLicence.installationId || '') : '';
                    return await callBackend('activate', key, activationInstallationId, legacyIp, previousDeviceId);
                })();
                const resp = await licenceActivationInProgress;
                if (!resp || !resp.status) {
                    errEl.text('Network is slow. Please check your internet connection and try again.').show();
                } else if (resp.status === 'ok') {
                    const count = (resp.count != null ? resp.count : 1);
                    const storedLicence = {
                        key: key, active: true, devices: count, installationId: activationInstallationId, identityVersion: 2,
                        expiryDate: resp.expiryDate || '',
                        googleMapsCredit: resp.googleMapsCredit != null ? resp.googleMapsCredit : null,
                        structuredCredit: resp.structuredCredit != null ? resp.structuredCredit : null,
                        purchaseCredit: resp.purchaseCredit != null ? resp.purchaseCredit : null,
                        supportEmail: resp.supportEmail || LICENSE_SUPPORT_EMAIL
                    };
                    Object.assign(storedLicence, (await PocketLeadsAccount.read()).license);
                    try { chrome.runtime.sendMessage({ action: 'pocketleads_warm_backend', reason: 'licence_activation', force: false }, function(){ void chrome.runtime.lastError; }); } catch (e) {}
                    licenceSessionValidated = true;
                    updateModalUI(storedLicence);
                    hideLicenseModal();
                    try {
                        if (typeof window.triggerPrivacyPolicyPrompt === 'function') {
                            setTimeout(function() { window.triggerPrivacyPolicyPrompt(false); }, 80);
                        }
                    } catch (_) {}
                } else if (resp.status === 'expired') {
                    errEl.text(`This licence expired${resp.expiryDate ? ' on ' + resp.expiryDate : ''}. Contact ${resp.supportEmail || LICENSE_SUPPORT_EMAIL} to renew.`).show();
                } else if (resp.status === 'inactive') {
                    errEl.text('This licence is inactive. Please contact admin.').show();
                } else if (resp.status === 'invalid') {
                    const reason = String(resp.reason || '');
                    if (/missing_key_or_(?:ip|device)|old_backend|backend/i.test(reason)) {
                        errEl.text('Backend version mismatch. Please update the Apps Script deployment.').show();
                    } else if (reason === 'licence_not_found') {
                        errEl.text('Licence key was not found in Admin Sheet. Please check the key and try again.').show();
                    } else {
                        errEl.text('Licence validation failed' + (reason ? ': ' + reason : '.')).show();
                    }
                } else if (resp.status === 'rate_limited') {
                    const waitS = Number(resp.retryAfterSec || resp.rateLimitWaitSec || 60);
                    errEl.text('Too many login attempts. Please wait ' + waitS + ' seconds before trying again.').show();
                } else if (resp.status === 'denied') {
                    const reason = String(resp.reason || '');
                    if (/device|installation/i.test(reason)) errEl.text('This device is not authorized for this licence. Activate it if fewer than 3 devices are currently active.').show();
                    else errEl.text('This licence already has 3 active devices. Release one device before activating a new device.').show();
                } else if (resp.status === 'credits_exhausted') {
                    errEl.text('This licence has 0 Available Credit remaining. Please contact admin to top up credits.').show();
                } else if (resp.status === 'credit_config_error') {
                    errEl.text('Licence Available Credit column in Admin Sheet has an invalid value. Please check the sheet row.').show();
                } else {
                    const detailMsg = String(resp.message || resp.error || resp.reason || '').trim();
                    errEl.text(detailMsg ? ('Server message: ' + detailMsg) : 'Unable to verify licence right now. Please check Admin Sheet configuration and retry.').show();
                    try {
                        if (typeof window.reportPocketLeadsErrorToAdminSheet === 'function') {
                            window.reportPocketLeadsErrorToAdminSheet({
                                licenceKey: key,
                                deviceId: activationInstallationId,
                                actionName: 'activate_modal',
                                errorCode: 'LOGIN_UNEXPECTED_STATUS_' + String(resp.status || 'UNKNOWN').toUpperCase(),
                                upstreamError: detailMsg || JSON.stringify(resp)
                            });
                        }
                    } catch (_) {}
                }
            } catch (err) {
                console.error('Error during licence activation', err);
                const errText = (err && err.message && !/network|fetch|timeout|abort/i.test(err.message))
                    ? err.message
                    : 'Network is slow. Please check your internet connection and try again.';
                errEl.text(errText).show();
                try {
                    if (typeof window.reportPocketLeadsErrorToAdminSheet === 'function') {
                        window.reportPocketLeadsErrorToAdminSheet({
                            licenceKey: key,
                            deviceId: activationInstallationId,
                            actionName: 'activate_modal_catch',
                            errorCode: 'LOGIN_EXCEPTION',
                            upstreamError: String(err && err.message || err || errText)
                        });
                    }
                } catch (_) {}
            } finally {
                licenceActivationInProgress = null;
                $('#spinnerModal').hide();
                submitBtn.prop('disabled', false);
                input.prop('disabled', false);
            }
        });

        // Bind 1-click release handler inside modal (no confirm dialog focus-race, no privacyAcceptance deletion!)
        $('#logoutButtonModal').on('click', async function() {
            $('#licenseErrorModal').hide();
            $('#spinnerModal').show();
            const logoutBtn = $('#logoutButtonModal');
            logoutBtn.prop('disabled', true);
            try {
                try {
                    const $scope = angular.element(document.body).scope();
                    if ($scope) {
                        $scope._wasRunningInThisSession = false;
                        $scope.scrapingCompleteShown = true;
                        if ($scope.completePopup) $scope.completePopup.show = false;
                    }
                } catch (_) {}
                await releaseLicenceInternal();
                licenceSessionValidated = false;
                updateModalUI(null);
                showLicenseModal();
            } catch (err) {
                console.error('Error releasing licence', err);
                licenceSessionValidated = false;
                updateModalUI(null);
                showLicenseModal();
            } finally {
                $('#spinnerModal').hide();
                logoutBtn.prop('disabled', false);
            }
        });
    });

    // Automatically close any open search tab when the dashboard (this
    // extension page) is about to be unloaded.  This listener runs
    // once when the script is evaluated and remains registered for the
    // lifetime of the page.  It retrieves the persisted local model via
    // $box.getLocal to find the stored searchTabId and removes that tab
    // using chrome.tabs.remove if it exists.  Running this cleanup on
    // unload prevents stray Google search pages from remaining open
    // when the user closes the dashboard or reloads the extension.
    try {
        window.addEventListener('beforeunload', function() {
            try {
                if (typeof $box !== 'undefined' && $box && typeof $box.getLocal === 'function') {
                    $box.getLocal(local => {
                        try {
                            const id = local && local._taskManager && local._taskManager.searchTabId;
                            if (id && chrome && chrome.tabs && typeof chrome.tabs.remove === 'function') {
                                chrome.tabs.remove(id, function() {
                                    if (chrome.runtime && chrome.runtime.lastError) {
                                        console.warn('beforeunload: tab remove error', chrome.runtime.lastError);
                                    }
                                });
                            }
                        } catch (err2) {
                            console.warn('beforeunload: failed to close search tab', err2);
                        }
                    });
                }
            } catch (err) {
                console.warn('beforeunload: error retrieving local', err);
            }
        });
    } catch (err) {
        console.warn('Failed to register beforeunload listener', err);
    }

    // -----------------------------------------------------------------------
    // Initialise DevExtreme DropDownBox for the country selector (single‑select)
    //
    // The dashboard includes a country selector in the sidebar.  To provide a
    // searchable single‑select dropdown without checkboxes, we initialise a
    // DevExtreme DropDownBox on the #countryDropDown element.  The dropdown
    // embeds a dxList configured for single selection.  When the user
    // selects a country, we update local.countries (stored as a one‑element
    // array) and local.country (the first and only selection for backward
    // compatibility) and persist the change via saveLocal().
    try {
        $(function() {
            /*
             * Define a mapping of ISO country names to their corresponding flag
             * emoji.  The keys in this object correspond to the country
             * names used throughout the dashboard (including certain ISO
             * synonym forms) and the values are the Unicode regional
             * indicator symbols that render as flags.  This mapping is used
             * by the country selector to prepend the correct flag for each
             * option.  If a flag is not found for a given name, an empty
             * string is returned.  The mapping is attached to the global
             * `window.countryFlags` so that it can be reused elsewhere if
             * needed.
             *
             * NOTE: This extension now also defines a separate mapping
             * window.countryIsoCodes (see below) which maps each country
             * name to its ISO‑3166 alpha‑2 code.  That mapping is used to
             * display real flag icons via Semantic UI's flag sprites.  The
             * emoji map is retained for backwards compatibility and may be
             * used elsewhere in the dashboard.
             */
            if (!window.countryFlags) {
                window.countryFlags = {
                    "Afghanistan": "\uD83C\uDDE6\uD83C\uDDEB",
                    "Albania": "\uD83C\uDDE6\uD83C\uDDF1",
                    "Algeria": "\uD83C\uDDE9\uD83C\uDDFF",
                    "American Samoa": "\uD83C\uDDE6\uD83C\uDDF8",
                    "Andorra": "\uD83C\uDDE6\uD83C\uDDE9",
                    "Angola": "\uD83C\uDDE6\uD83C\uDDF4",
                    "Anguilla": "\uD83C\uDDE6\uD83C\uDDEE",
                    "Antarctica": "\uD83C\uDDE6\uD83C\uDDF6",
                    "Antigua and Barbuda": "\uD83C\uDDE6\uD83C\uDDEC",
                    "Argentina": "\uD83C\uDDE6\uD83C\uDDF7",
                    "Armenia": "\uD83C\uDDE6\uD83C\uDDF2",
                    "Aruba": "\uD83C\uDDE6\uD83C\uDDFC",
                    "Australia": "\uD83C\uDDE6\uD83C\uDDFA",
                    "Austria": "\uD83C\uDDE6\uD83C\uDDF9",
                    "Azerbaijan": "\uD83C\uDDE6\uD83C\uDDFF",
                    "Bahamas": "\uD83C\uDDE7\uD83C\uDDF8",
                    "Bahrain": "\uD83C\uDDE7\uD83C\uDDED",
                    "Bangladesh": "\uD83C\uDDE7\uD83C\uDDE9",
                    "Barbados": "\uD83C\uDDE7\uD83C\uDDE7",
                    "Belarus": "\uD83C\uDDE7\uD83C\uDDFE",
                    "Belgium": "\uD83C\uDDE7\uD83C\uDDEA",
                    "Belize": "\uD83C\uDDE7\uD83C\uDDF9",
                    "Benin": "\uD83C\uDDE7\uD83C\uDDEF",
                    "Bermuda": "\uD83C\uDDE7\uD83C\uDDF2",
                    "Bhutan": "\uD83C\uDDE7\uD83C\uDDF9",
                    "Bolivia, Plurinational State of": "\uD83C\uDDE7\uD83C\uDDF4",
                    "Bonaire, Sint Eustatius and Saba": "\uD83C\uDDE7\uD83C\uDDF6",
                    "Bosnia and Herzegovina": "\uD83C\uDDE7\uD83C\uDDE8",
                    "Botswana": "\uD83C\uDDE7\uD83C\uDDFC",
                    "Bouvet Island": "\uD83C\uDDE7\uD83C\uDDFB",
                    "Brazil": "\uD83C\uDDE7\uD83C\uDDFA",
                    "British Indian Ocean Territory": "\uD83C\uDDEE\uD83C\uDDF4",
                    "Brunei Darussalam": "\uD83C\uDDE7\uD83C\uDDF3",
                    "Bulgaria": "\uD83C\uDDE7\uD83C\uDDEC",
                    "Burkina Faso": "\uD83C\uDDE7\uD83C\uDDEB",
                    "Burundi": "\uD83C\uDDE7\uD83C\uDDEE",
                    "Cabo Verde": "\uD83C\uDDE8\uD83C\uDDFB",
                    "Cambodia": "\uD83C\uDDF0\uD83C\uDDED",
                    "Cameroon": "\uD83C\uDDE8\uD83C\uDDF2",
                    "Canada": "\uD83C\uDDE8\uD83C\uDDE6",
                    "Cayman Islands": "\uD83C\uDDF0\uD83C\uDDFE",
                    "Central African Republic": "\uD83C\uDDE8\uD83C\uDDF3",
                    "Chad": "\uD83C\uDDF9\uD83C\uDDE9",
                    "Chile": "\uD83C\uDDE8\uD83C\uDDF1",
                    "China": "\uD83C\uDDE8\uD83C\uDDF3",
                    "Christmas Island": "\uD83C\uDDE8\uD83C\uDDFD",
                    "Cocos (Keeling) Islands": "\uD83C\uDDE8\uD83C\uDDEC",
                    "Colombia": "\uD83C\uDDE8\uD83C\uDDF4",
                    "Comoros": "\uD83C\uDDF0\uD83C\uDDF2",
                    "Congo": "\uD83C\uDDE8\uD83C\uDDEC",
                    "Congo, The Democratic Republic of the": "\uD83C\uDDE8\uD83C\uDDF4",
                    "Cook Islands": "\uD83C\uDDE8\uD83C\uDDF0",
                    "Costa Rica": "\uD83C\uDDE8\uD83C\uDDF7",
                    "Croatia": "\uD83C\uDDED\uD83C\uDDF7",
                    "Cuba": "\uD83C\uDDE8\uD83C\uDDFA",
                    "Curaçao": "\uD83C\uDDE8\uD83C\uDDFC",
                    "Cyprus": "\uD83C\uDDF2\uD83C\uDDFE",
                    "Czechia": "\uD83C\uDDE9\uD83C\uDDF9",
                    "Côte d'Ivoire": "\uD83C\uDDEE\uD83C\uDDF7",
                    "Denmark": "\uD83C\uDDE9\uD83C\uDDF0",
                    "Djibouti": "\uD83C\uDDE9\uD83C\uDDEF",
                    "Dominica": "\uD83C\uDDE9\uD83C\uDDF2",
                    "Dominican Republic": "\uD83C\uDDE9\uD83C\uDDF4",
                    "Ecuador": "\uD83C\uDDEA\uD83C\uDDE8",
                    "Egypt": "\uD83C\uDDEA\uD83C\uDDEC",
                    "El Salvador": "\uD83C\uDDF2\uD83C\uDDF8",
                    "Equatorial Guinea": "\uD83C\uDDEC\uD83C\uDDF6",
                    "Eritrea": "\uD83C\uDDEA\uD83C\uDDF7",
                    "Estonia": "\uD83C\uDDEA\uD83C\uDDFA",
                    "Eswatini": "\uD83C\uDDFF\uD83C\uDDF8",
                    "Ethiopia": "\uD83C\uDDEA\uD83C\uDDF9",
                    "Falkland Islands (Malvinas)": "\uD83C\uDDEB\uD83C\uDDF0",
                    "Faroe Islands": "\uD83C\uDDEB\uD83C\uDDF4",
                    "Fiji": "\uD83C\uDDEB\uD83C\uDDEF",
                    "Finland": "\uD83C\uDDEB\uD83C\uDDEE",
                    "France": "\uD83C\uDDEB\uD83C\uDDF7",
                    "French Guiana": "\uD83C\uDDEC\uD83C\uDDEB",
                    "French Polynesia": "\uD83C\uDDF5\uD83C\uDDEB",
                    "French Southern Territories": "\uD83C\uDDF9\uD83C\uDDEB",
                    "Gabon": "\uD83C\uDDEC\uD83C\uDDF2",
                    "Gambia": "\uD83C\uDDEC\uD83C\uDDF2",
                    "Georgia": "\uD83C\uDDEC\uD83C\uDDEA",
                    "Germany": "\uD83C\uDDE9\uD83C\uDDEA",
                    "Ghana": "\uD83C\uDDEC\uD83C\uDDDD",
                    "Gibraltar": "\uD83C\uDDEC\uD83C\uDDEE",
                    "Greece": "\uD83C\uDDEC\uD83C\uDDF7",
                    "Greenland": "\uD83C\uDDEC\uD83C\uDDEB",
                    "Grenada": "\uD83C\uDDEC\uD83C\uDDE9",
                    "Guadeloupe": "\uD83C\uDDEC\uD83C\uDDEB",
                    "Guam": "\uD83C\uDDEC\uD83C\uDDF8",
                    "Guatemala": "\uD83C\uDDEC\uD83C\uDDF9",
                    "Guernsey": "\uD83C\uDDEC\uD83C\uDDED",
                    "Guinea": "\uD83C\uDDEC\uD83C\uDDF3",
                    "Guinea-Bissau": "\uD83C\uDDEC\uD83C\uDDFC",
                    "Guyana": "\uD83C\uDDEC\uD83C\uDDFE",
                    "Haiti": "\uD83C\uDDED\uD83C\uDDF9",
                    "Heard Island and McDonald Islands": "\uD83C\uDDED\uD83C\uDDF0",
                    "Holy See (Vatican City State)": "\uD83C\uDDFB\uD83C\uDDEA",
                    "Honduras": "\uD83C\uDDED\uD83C\uDDF3",
                    "Hong Kong": "\uD83C\uDDED\uD83C\uDDF0",
                    "Hungary": "\uD83C\uDDED\uD83C\uDDFA",
                    "Iceland": "\uD83C\uDDEE\uD83C\uDDF8",
                    "India": "\uD83C\uDDEE\uD83C\uDDF3",
                    "Indonesia": "\uD83C\uDDEE\uD83C\uDDE9",
                    "Iran, Islamic Republic of": "\uD83C\uDDEE\uD83C\uDDF7",
                    "Iraq": "\uD83C\uDDEE\uD83C\uDDFA",
                    "Ireland": "\uD83C\uDDEE\uD83C\uDDEA",
                    "Isle of Man": "\uD83C\uDDEE\uD83C\uDDEC",
                    "Israel": "\uD83C\uDDEE\uD83C\uDDF1",
                    "Italy": "\uD83C\uDDEE\uD83C\uDDF9",
                    "Jamaica": "\uD83C\uDDEF\uD83C\uDDF2",
                    "Japan": "\uD83C\uDDEF\uD83C\uDDF5",
                    "Jersey": "\uD83C\uDDEF\uD83C\uDDED",
                    "Jordan": "\uD83C\uDDEF\uD83C\uDDF4",
                    "Kazakhstan": "\uD83C\uDDDF\uD83C\uDDF0",
                    "Kenya": "\uD83C\uDDDF\uD83C\uDDEA",
                    "Kiribati": "\uD83C\uDDDF\uD83C\uDDEE",
                    "Korea, Democratic People's Republic of": "\uD83C\uDDF0\uD83C\uDDF5",
                    "Korea, Republic of": "\uD83C\uDDF0\uD83C\uDDF7",
                    "Kuwait": "\uD83C\uDDDF\uD83C\uDDFC",
                    "Kyrgyzstan": "\uD83C\uDDDF\uD83C\uDDEC",
                    "Lao People's Democratic Republic": "\uD83C\uDDF1\uD83C\uDDFA",
                    "Latvia": "\uD83C\uDDF1\uD83C\uDDFB",
                    "Lebanon": "\uD83C\uDDF1\uD83C\uDDEE",
                    "Lesotho": "\uD83C\uDDF1\uD83C\uDDF8",
                    "Liberia": "\uD83C\uDDF1\uD83C\uDDF7",
                    "Libya": "\uD83C\uDDF1\uD83C\uDDFF",
                    "Liechtenstein": "\uD83C\uDDF1\uD83C\uDDEE",
                    "Lithuania": "\uD83C\uDDF1\uD83C\uDDF9",
                    "Luxembourg": "\uD83C\uDDF1\uD83C\uDDFA",
                    "Macao": "\uD83C\uDDF2\uD83C\uDDF4",
                    "Madagascar": "\uD83C\uDDF2\uD83C\uDDDA",
                    "Malawi": "\uD83C\uDDF2\uD83C\uDDFC",
                    "Malaysia": "\uD83C\uDDF2\uD83C\uDDFE",
                    "Maldives": "\uD83C\uDDF2\uD83C\uDDFA",
                    "Mali": "\uD83C\uDDF2\uD83C\uDDF1",
                    "Malta": "\uD83C\uDDF2\uD83C\uDDDF",
                    "Marshall Islands": "\uD83C\uDDF2\uD83C\uDDF8",
                    "Martinique": "\uD83C\uDDF2\uD83C\uDDEC",
                    "Mauritania": "\uD83C\uDDF2\uD83C\uDDDF",
                    "Mauritius": "\uD83C\uDDF2\uD83C\uDDEA",
                    "Mayotte": "\uD83C\uDDFE\uD83C\uDDF9",
                    "Mexico": "\uD83C\uDDF2\uD83C\uDDFD",
                    "Micronesia, Federated States of": "\uD83C\uDDEB\uD83C\uDDFA",
                    "Moldova, Republic of": "\uD83C\uDDF2\uD83C\uDDE9",
                    "Monaco": "\uD83C\uDDF2\uD83C\uDDE8",
                    "Mongolia": "\uD83C\uDDF2\uD83C\uDDF3",
                    "Montenegro": "\uD83C\uDDF2\uD83C\uDDEA",
                    "Montserrat": "\uD83C\uDDF2\uD83C\uDDF8",
                    "Morocco": "\uD83C\uDDF2\uD83C\uDDE6",
                    "Mozambique": "\uD83C\uDDF2\uD83C\uDDFF",
                    "Myanmar": "\uD83C\uDDF2\uD83C\uDDF2",
                    "Namibia": "\uD83C\uDDF3\uD83C\uDDE6",
                    "Nauru": "\uD83C\uDDF3\uD83C\uDDF7",
                    "Netherlands": "\uD83C\uDDF3\uD83C\uDDF1",
                    "New Caledonia": "\uD83C\uDDF3\uD83C\uDDE8",
                    "New Zealand": "\uD83C\uDDF3\uD83C\uDDFF",
                    "Nicaragua": "\uD83C\uDDF3\uD83C\uDDF7",
                    "Niger": "\uD83C\uDDF3\uD83C\uDDEA",
                    "Nigeria": "\uD83C\uDDF3\uD83C\uDDEC",
                    "Niue": "\uD83C\uDDF3\uD83C\uDDFC",
                    "Norfolk Island": "\uD83C\uDDF3\uD83C\uDDEB",
                    "North Macedonia": "\uD83C\uDDF2\uD83C\uDDF0",
                    "Northern Mariana Islands": "\uD83C\uDDF2\uD83C\uDDF5",
                    "Norway": "\uD83C\uDDF3\uD83C\uDDF4",
                    "Oman": "\uD83C\uDDF4\uD83C\uDDF4",
                    "Pakistan": "\uD83C\uDDDF\uD83C\uDDF6",
                    "Palau": "\uD83C\uDDF5\uD83C\uDDFD",
                    "Palestine, State of": "\uD83C\uDDF5\uD83C\uDDF8",
                    "Panama": "\uD83C\uDDDF\uD83C\uDDE6",
                    "Papua New Guinea": "\uD83C\uDDDF\uD83C\uDDEC",
                    "Paraguay": "\uD83C\uDDF5\uD83C\uDDFE",
                    "Peru": "\uD83C\uDDF5\uD83C\uDDEA",
                    "Philippines": "\uD83C\uDDF5\uD83C\uDDED",
                    "Pitcairn": "\uD83C\uDDF5\uD83C\uDDF3",
                    "Poland": "\uD83C\uDDF5\uD83C\uDDF1",
                    "Portugal": "\uD83C\uDDF5\uD83C\uDDF9",
                    "Puerto Rico": "\uD83C\uDDF5\uD83C\uDDF7",
                    "Qatar": "\uD83C\uDDF6\uD83C\uDDE6",
                    "Romania": "\uD83C\uDDF7\uD83C\uDDF4",
                    "Russian Federation": "\uD83C\uDDF7\uD83C\uDDFA",
                    "Rwanda": "\uD83C\uDDF7\uD83C\uDDFC",
                    "Réunion": "\uD83C\uDDF7\uD83C\uDDEA",
                    "Saint Barthélemy": "\uD83C\uDDE7\uD83C\uDDF1",
                    "Saint Helena, Ascension and Tristan da Cunha": "\uD83C\uDDF8\uD83C\uDDED",
                    "Saint Kitts and Nevis": "\uD83C\uDDF0\uD83C\uDDF3",
                    "Saint Lucia": "\uD83C\uDDF1\uD83C\uDDE9",
                    "Saint Martin (French part)": "\uD83C\uDDF0\uD83C\uDDF4",
                    "Saint Pierre and Miquelon": "\uD83C\uDDF5\uD83C\uDDED",
                    "Saint Vincent and the Grenadines": "\uD83C\uDDF1\uD83C\uDDE8",
                    "Samoa": "\uD83C\uDDDF\uD83C\uDDF8",
                    "San Marino": "\uD83C\uDDF8\uD83C\uDDEE",
                    "Sao Tome and Principe": "\uD83C\uDDF8\uD83C\uDDF2",
                    "Saudi Arabia": "\uD83C\uDDEA\uD83C\uDDF0",
                    "Senegal": "\uD83C\uDDE9\uD83C\uDDF8",
                    "Serbia": "\uD83C\uDDF7\uD83C\uDDF8",
                    "Seychelles": "\uD83C\uDDF8\uD83C\uDDED",
                    "Sierra Leone": "\uD83C\uDDF8\uD83C\uDDF1",
                    "Singapore": "\uD83C\uDDEE\uD83C\uDDF7",
                    "Sint Maarten (Dutch part)": "\uD83C\uDDF8\uD83C\uDDDF",
                    "Slovakia": "\uD83C\uDDF8\uD83C\uDDF0",
                    "Slovenia": "\uD83C\uDDF8\uD83C\uDDEE",
                    "Solomon Islands": "\uD83C\uDDF8\uD83C\uDDDF",
                    "Somalia": "\uD83C\uDDF8\uD83C\uDDDC",
                    "South Africa": "\uD83C\uDDFF\uD83C\uDDEC",
                    "South Georgia and the South Sandwich Islands": "\uD83C\uDDE5\uD83C\uDDEB",
                    "South Sudan": "\uD83C\uDDF8\uD83C\uDDF8",
                    "Spain": "\uD83C\uDDEA\uD83C\uDDF8",
                    "Sri Lanka": "\uD83C\uDDF1\uD83C\uDDF0",
                    "St. Barthélemy": "\uD83C\uDDE7\uD83C\uDDF1",
                    "Sudan": "\uD83C\uDDF8\uD83C\uDDE9",
                    "Suriname": "\uD83C\uDDF8\uD83C\uDDE7",
                    "Svalbard and Jan Mayen": "\uD83C\uDDF8\uD83C\uDDED",
                    "Sweden": "\uD83C\uDDF8\uD83C\uDDEA",
                    "Switzerland": "\uD83C\uDDE8\uD83C\uDDED",
                    "Syrian Arab Republic": "\uD83C\uDDF4\uD83C\uDDE6",
                    "Taiwan, Province of China": "\uD83C\uDDF9\uD83C\uDDFC",
                    "Tajikistan": "\uD83C\uDDF9\uD83C\uDDEC",
                    "Tanzania, United Republic of": "\uD83C\uDDF9\uD83C\uDDFF",
                    "Thailand": "\uD83C\uDDF9\uD83C\uDDED",
                    "Timor-Leste": "\uD83C\uDDF9\uD83C\uDDF1",
                    "Togo": "\uD83C\uDDF9\uD83C\uDDEC",
                    "Tokelau": "\uD83C\uDDF9\uD83C\uDDF0",
                    "Tonga": "\uD83C\uDDF9\uD83C\uDDF4",
                    "Trinidad and Tobago": "\uD83C\uDDF9\uD83C\uDDF9",
                    "Tunisia": "\uD83C\uDDF9\uD83C\uDDF3",
                    "Turkmenistan": "\uD83C\uDDF9\uD83C\uDDF2",
                    "Turks and Caicos Islands": "\uD83C\uDDF4\uD83C\uDDF0",
                    "Tuvalu": "\uD83C\uDDF9\uD83C\uDDFC",
                    "Türkiye": "\uD83C\uDDF9\uD83C\uDDF7",
                    "Uganda": "\uD83C\uDDFE\uD83C\uDDEC",
                    "Ukraine": "\uD83C\uDDFA\uD83C\uDDE6",
                    "United Arab Emirates": "\uD83C\uDDE6\uD83C\uDDEA",
                    "United Kingdom": "\uD83C\uDDEC\uD83C\uDDE7",
                    "United States": "\uD83C\uDDFA\uD83C\uDDF8",
                    "United States Minor Outlying Islands": "\uD83C\uDDFA\uD83C\uDDF2",
                    "Uruguay": "\uD83C\uDDFA\uD83C\uDDFE",
                    "Uzbekistan": "\uD83C\uDDFA\uD83C\uDDEC",
                    "Vanuatu": "\uD83C\uDDFA\uD83C\uDDFA",
                    "Venezuela, Bolivarian Republic of": "\uD83C\uDDFA\uD83C\uDDF9",
                    "Viet Nam": "\uD83C\uDDFB\uD83C\uDDF3",
                    "Virgin Islands, British": "\uD83C\uDDFB\uD83C\uDDEC",
                    "Virgin Islands, U.S.": "\uD83C\uDDFA\uD83C\uDDEE",
                    "Wallis and Futuna": "\uD83C\uDDFB\uD83C\uDDEB",
                    "Western Sahara": "\uD83C\uDDEA\uD83C\uDDE9",
                    "Yemen": "\uD83C\uDDFE\uD83C\uDDEA",
                    "Zambia": "\uD83C\uDDF5\uD83C\uDDFC",
                    "Zimbabwe": "\uD83C\uDDF5\uD83C\uDDF0",
                    "Åland Islands": "\uD83C\uDDE6\uD83C\uDDF9"
                };

            /*
             * Define a mapping from country names to their ISO‑3166 alpha‑2
             * codes.  These codes are used with Semantic UI's flag sprite
             * classes to render real flag icons (see the itemTemplate in
             * initializeCountryDropDown below).  If a name cannot be found
             * or mapped, the code will be left blank and no icon will be
             * rendered.  This mapping is attached to the global
             * window.countryIsoCodes so that it can be reused elsewhere if
             * needed.  The mapping below was generated programmatically
             * using pycountry and includes fallbacks for common aliases and
             * multi‑word names.
             */
            if (!window.countryIsoCodes) {
                window.countryIsoCodes = {
                    "Aruba": "aw",
                    "Afghanistan": "af",
                    "Angola": "ao",
                    "Anguilla": "ai",
                    "Åland Islands": "ax",
                    "Albania": "al",
                    "Andorra": "ad",
                    "United Arab Emirates": "ae",
                    "Argentina": "ar",
                    "Armenia": "am",
                    "American Samoa": "as",
                    "Antarctica": "aq",
                    "French Southern Territories": "tf",
                    "Antigua and Barbuda": "ag",
                    "Australia": "au",
                    "Austria": "at",
                    "Azerbaijan": "az",
                    "Burundi": "bi",
                    "Belgium": "be",
                    "Benin": "bj",
                    "Bonaire, Sint Eustatius and Saba": "bq",
                    "Burkina Faso": "bf",
                    "Bangladesh": "bd",
                    "Bulgaria": "bg",
                    "Bahrain": "bh",
                    "Bahamas": "bs",
                    "Bosnia and Herzegovina": "ba",
                    "Saint Barthélemy": "bl",
                    "Belarus": "by",
                    "Belize": "bz",
                    "Bermuda": "bm",
                    "Bolivia, Plurinational State of": "bo",
                    "Brazil": "br",
                    "Barbados": "bb",
                    "Brunei Darussalam": "bn",
                    "Bhutan": "bt",
                    "Bouvet Island": "bv",
                    "Botswana": "bw",
                    "Central African Republic": "cf",
                    "Canada": "ca",
                    "Cocos (Keeling) Islands": "cc",
                    "Switzerland": "ch",
                    "Chile": "cl",
                    "China": "cn",
                    "Côte d'Ivoire": "ci",
                    "Cameroon": "cm",
                    "Congo, The Democratic Republic of the": "cd",
                    "Congo": "cg",
                    "Cook Islands": "ck",
                    "Colombia": "co",
                    "Comoros": "km",
                    "Cabo Verde": "cv",
                    "Costa Rica": "cr",
                    "Cuba": "cu",
                    "Curaçao": "cw",
                    "Christmas Island": "cx",
                    "Cayman Islands": "ky",
                    "Cyprus": "cy",
                    "Czechia": "cz",
                    "Germany": "de",
                    "Djibouti": "dj",
                    "Dominica": "dm",
                    "Denmark": "dk",
                    "Dominican Republic": "do",
                    "Algeria": "dz",
                    "Ecuador": "ec",
                    "Egypt": "eg",
                    "Eritrea": "er",
                    "Western Sahara": "eh",
                    "Spain": "es",
                    "Estonia": "ee",
                    "Ethiopia": "et",
                    "Finland": "fi",
                    "Fiji": "fj",
                    "Falkland Islands (Malvinas)": "fk",
                    "France": "fr",
                    "Faroe Islands": "fo",
                    "Micronesia, Federated States of": "fm",
                    "Gabon": "ga",
                    "United Kingdom": "gb",
                    "Georgia": "ge",
                    "Guernsey": "gg",
                    "Ghana": "gh",
                    "Gibraltar": "gi",
                    "Guinea": "gn",
                    "Guadeloupe": "gp",
                    "Gambia": "gm",
                    "Guinea-Bissau": "gw",
                    "Equatorial Guinea": "gq",
                    "Greece": "gr",
                    "Grenada": "gd",
                    "Greenland": "gl",
                    "Guatemala": "gt",
                    "French Guiana": "gf",
                    "Guam": "gu",
                    "Guyana": "gy",
                    "Hong Kong": "hk",
                    "Heard Island and McDonald Islands": "hm",
                    "Honduras": "hn",
                    "Croatia": "hr",
                    "Haiti": "ht",
                    "Hungary": "hu",
                    "Indonesia": "id",
                    "Isle of Man": "im",
                    "India": "in",
                    "British Indian Ocean Territory": "io",
                    "Ireland": "ie",
                    "Iran, Islamic Republic of": "ir",
                    "Iraq": "iq",
                    "Iceland": "is",
                    "Israel": "il",
                    "Italy": "it",
                    "Jamaica": "jm",
                    "Jersey": "je",
                    "Jordan": "jo",
                    "Japan": "jp",
                    "Kazakhstan": "kz",
                    "Kenya": "ke",
                    "Kyrgyzstan": "kg",
                    "Cambodia": "kh",
                    "Kiribati": "ki",
                    "Saint Kitts and Nevis": "kn",
                    "Korea, Republic of": "kr",
                    "Kuwait": "kw",
                    "Lao People's Democratic Republic": "la",
                    "Lebanon": "lb",
                    "Liberia": "lr",
                    "Libya": "ly",
                    "Saint Lucia": "lc",
                    "Liechtenstein": "li",
                    "Sri Lanka": "lk",
                    "Lesotho": "ls",
                    "Lithuania": "lt",
                    "Luxembourg": "lu",
                    "Latvia": "lv",
                    "Macao": "mo",
                    "Saint Martin (French part)": "mf",
                    "Morocco": "ma",
                    "Monaco": "mc",
                    "Moldova, Republic of": "md",
                    "Madagascar": "mg",
                    "Maldives": "mv",
                    "Mexico": "mx",
                    "Marshall Islands": "mh",
                    "North Macedonia": "mk",
                    "Mali": "ml",
                    "Malta": "mt",
                    "Myanmar": "mm",
                    "Montenegro": "me",
                    "Mongolia": "mn",
                    "Northern Mariana Islands": "mp",
                    "Mozambique": "mz",
                    "Mauritania": "mr",
                    "Montserrat": "ms",
                    "Martinique": "mq",
                    "Mauritius": "mu",
                    "Malawi": "mw",
                    "Malaysia": "my",
                    "Mayotte": "yt",
                    "Namibia": "na",
                    "New Caledonia": "nc",
                    "Niger": "ne",
                    "Norfolk Island": "nf",
                    "Nigeria": "ng",
                    "Nicaragua": "ni",
                    "Niue": "nu",
                    "Netherlands": "nl",
                    "Norway": "no",
                    "Nauru": "nr",
                    "New Zealand": "nz",
                    "Oman": "om",
                    "Pakistan": "pk",
                    "Panama": "pa",
                    "Pitcairn": "pn",
                    "Peru": "pe",
                    "Philippines": "ph",
                    "Palau": "pw",
                    "Papua New Guinea": "pg",
                    "Poland": "pl",
                    "Puerto Rico": "pr",
                    "Korea, Democratic People's Republic of": "kp",
                    "Portugal": "pt",
                    "Paraguay": "py",
                    "Palestine, State of": "ps",
                    "French Polynesia": "pf",
                    "Qatar": "qa",
                    "Réunion": "re",
                    "Romania": "ro",
                    "Russian Federation": "ru",
                    "Rwanda": "rw",
                    "Saudi Arabia": "sa",
                    "Sudan": "sd",
                    "Senegal": "sn",
                    "Singapore": "sg",
                    "South Georgia and the South Sandwich Islands": "gs",
                    "Saint Helena, Ascension and Tristan da Cunha": "sh",
                    "Svalbard and Jan Mayen": "sj",
                    "Solomon Islands": "sb",
                    "Sierra Leone": "sl",
                    "El Salvador": "sv",
                    "San Marino": "sm",
                    "Somalia": "so",
                    "Saint Pierre and Miquelon": "pm",
                    "Serbia": "rs",
                    "South Sudan": "ss",
                    "Sao Tome and Principe": "st",
                    "Suriname": "sr",
                    "Slovakia": "sk",
                    "Slovenia": "si",
                    "Sweden": "se",
                    "Eswatini": "sz",
                    "Sint Maarten (Dutch part)": "sx",
                    "Seychelles": "sc",
                    "Syrian Arab Republic": "sy",
                    "Turks and Caicos Islands": "tc",
                    "Chad": "td",
                    "Togo": "tg",
                    "Thailand": "th",
                    "Tajikistan": "tj",
                    "Tokelau": "tk",
                    "Turkmenistan": "tm",
                    "Timor-Leste": "tl",
                    "Tonga": "to",
                    "Trinidad and Tobago": "tt",
                    "Tunisia": "tn",
                    "Türkiye": "tr",
                    "Tuvalu": "tv",
                    "Taiwan, Province of China": "tw",
                    "Tanzania, United Republic of": "tz",
                    "Uganda": "ug",
                    "Ukraine": "ua",
                    "United States Minor Outlying Islands": "um",
                    "Uruguay": "uy",
                    "United States": "us",
                    "Uzbekistan": "uz",
                    "Holy See (Vatican City State)": "va",
                    "Saint Vincent and the Grenadines": "vc",
                    "Venezuela, Bolivarian Republic of": "ve",
                    "Virgin Islands, British": "vg",
                    "Virgin Islands, U.S.": "vi",
                    "Viet Nam": "vn",
                    "Vanuatu": "vu",
                    "Wallis and Futuna": "wf",
                    "Samoa": "ws",
                    "Yemen": "ye",
                    "South Africa": "za",
                    "Zambia": "zm",
                    "Zimbabwe": "zw"
                };
            }
            }
            /**
             * Initialise a DevExtreme DropDownBox on the given DOM element.
             * This helper encapsulates the logic for retrieving the data source,
             * loading any saved selection and configuring the drop‑down list.  It is
             * invoked both when the dropdown element is present at page load and
             * when it appears later (e.g. inside the navbar via ng‑include).
             *
             * @param {HTMLElement} domEl The DOM element on which to instantiate the DropDownBox.
             */
            function initializeCountryDropDown(domEl) {
                try {
                    // Obtain the Angular scope from the country‑select container, if available.
                    const scopeElem = document.querySelector('.country-select');
                    const scope = scopeElem ? angular.element(scopeElem).scope() : null;

                    // Determine the data source using global fallbacks first, then the Angular scope.
                    let dataSrc = [];
                    if (window.countryList && Array.isArray(window.countryList) && window.countryList.length) {
                        dataSrc = window.countryList;
                    } else if (scope && Array.isArray(scope.countries) && scope.countries.length) {
                        dataSrc = scope.countries;
                    } else {
                        /*
                         * Fallback: use a static list of country names identical to $scope.countries.
                         * We mirror the ISO 3166 derived list defined in $scope.countries above.  This ensures
                         * the dropdown is populated with all countries even if window.countryList or
                         * scope.countries are unavailable at initialisation time.  Do not alter the order or
                         * content of this array unless you update $scope.countries accordingly.
                         */
                        dataSrc = [
                            "Aruba", "Afghanistan", "Angola", "Anguilla", "Åland Islands", "Albania", "Andorra", "United Arab Emirates", "Argentina",
                            "Armenia", "American Samoa", "Antarctica", "French Southern Territories", "Antigua and Barbuda", "Australia", "Austria",
                            "Azerbaijan", "Burundi", "Belgium", "Benin", "Bonaire, Sint Eustatius and Saba", "Burkina Faso", "Bangladesh", "Bulgaria",
                            "Bahrain", "Bahamas", "Bosnia and Herzegovina", "Saint Barthélemy", "Belarus", "Belize", "Bermuda",
                            "Bolivia, Plurinational State of", "Brazil", "Barbados", "Brunei Darussalam", "Bhutan", "Bouvet Island", "Botswana",
                            "Central African Republic", "Canada", "Cocos (Keeling) Islands", "Switzerland", "Chile", "China", "Côte d'Ivoire",
                            "Cameroon", "Congo, The Democratic Republic of the", "Congo", "Cook Islands", "Colombia", "Comoros", "Cabo Verde",
                            "Costa Rica", "Cuba", "Curaçao", "Christmas Island", "Cayman Islands", "Cyprus", "Czechia", "Germany", "Djibouti",
                            "Dominica", "Denmark", "Dominican Republic", "Algeria", "Ecuador", "Egypt", "Eritrea", "Western Sahara", "Spain",
                            "Estonia", "Ethiopia", "Finland", "Fiji", "Falkland Islands (Malvinas)", "France", "Faroe Islands",
                            "Micronesia, Federated States of", "Gabon", "United Kingdom", "Georgia", "Guernsey", "Ghana", "Gibraltar", "Guinea",
                            "Guadeloupe", "Gambia", "Guinea-Bissau", "Equatorial Guinea", "Greece", "Grenada", "Greenland", "Guatemala",
                            "French Guiana", "Guam", "Guyana", "Hong Kong", "Heard Island and McDonald Islands", "Honduras", "Croatia", "Haiti",
                            "Hungary", "Indonesia", "Isle of Man", "India", "British Indian Ocean Territory", "Ireland", "Iran, Islamic Republic of",
                            "Iraq", "Iceland", "Israel", "Italy", "Jamaica", "Jersey", "Jordan", "Japan", "Kazakhstan", "Kenya", "Kyrgyzstan",
                            "Cambodia", "Kiribati", "Saint Kitts and Nevis", "Korea, Republic of", "Kuwait", "Lao People's Democratic Republic",
                            "Lebanon", "Liberia", "Libya", "Saint Lucia", "Liechtenstein", "Sri Lanka", "Lesotho", "Lithuania", "Luxembourg",
                            "Latvia", "Macao", "Saint Martin (French part)", "Morocco", "Monaco", "Moldova, Republic of", "Madagascar", "Maldives",
                            "Mexico", "Marshall Islands", "North Macedonia", "Mali", "Malta", "Myanmar", "Montenegro", "Mongolia",
                            "Northern Mariana Islands", "Mozambique", "Mauritania", "Montserrat", "Martinique", "Mauritius", "Malawi", "Malaysia",
                            "Mayotte", "Namibia", "New Caledonia", "Niger", "Norfolk Island", "Nigeria", "Nicaragua", "Niue", "Netherlands",
                            "Norway", "Nauru", "New Zealand", "Oman", "Pakistan", "Panama", "Pitcairn", "Peru", "Philippines", "Palau",
                            "Papua New Guinea", "Poland", "Puerto Rico", "Korea, Democratic People's Republic of", "Portugal", "Paraguay",
                            "Palestine, State of", "French Polynesia", "Qatar", "Réunion", "Romania", "Russian Federation", "Rwanda", "Saudi Arabia",
                            "Sudan", "Senegal", "Singapore", "South Georgia and the South Sandwich Islands", "Saint Helena, Ascension and Tristan da Cunha",
                            "Svalbard and Jan Mayen", "Solomon Islands", "Sierra Leone", "El Salvador", "San Marino", "Somalia",
                            "Saint Pierre and Miquelon", "Serbia", "South Sudan", "Sao Tome and Principe", "Suriname", "Slovakia", "Slovenia",
                            "Sweden", "Eswatini", "Sint Maarten (Dutch part)", "Seychelles", "Syrian Arab Republic", "Turks and Caicos Islands", "Chad",
                            "Togo", "Thailand", "Tajikistan", "Tokelau", "Turkmenistan", "Timor-Leste", "Tonga", "Trinidad and Tobago", "Tunisia",
                            "Türkiye", "Tuvalu", "Taiwan, Province of China", "Tanzania, United Republic of", "Uganda", "Ukraine",
                            "United States Minor Outlying Islands", "Uruguay", "United States", "Uzbekistan", "Holy See (Vatican City State)",
                            "Saint Vincent and the Grenadines", "Venezuela, Bolivarian Republic of", "Virgin Islands, British", "Virgin Islands, U.S.",
                            "Viet Nam", "Vanuatu", "Wallis and Futuna", "Samoa", "Yemen", "South Africa", "Zambia", "Zimbabwe"
                        ];
                    }

                    // Determine any previously saved selections.  Prefer the Angular scope if available.
                    let savedSelection = [];
                    if (scope && scope.local) {
                        if (Array.isArray(scope.local.countries) && scope.local.countries.length) {
                            savedSelection = scope.local.countries.slice();
                        } else if (scope.local.country) {
                            savedSelection = [scope.local.country];
                        }
                    } else {
                        if (Array.isArray(window.localCountries) && window.localCountries.length) {
                            savedSelection = window.localCountries.slice();
                        } else if (window.localCountry) {
                            savedSelection = [window.localCountry];
                        }
                    }

                    // Only restore a country if the user has explicitly selected one before
                    const permCountry = (typeof localStorage !== 'undefined' && localStorage.getItem('pl_user_selected_country_v1')) || '';
                    if (!permCountry) {
                        savedSelection = [];
                    } else if (!savedSelection || savedSelection.length === 0) {
                        savedSelection = [permCountry];
                    }

                    /*
                     * Helper to update the local model and persist via saveLocal().
                     * This keeps the array of selected countries under local.countries and
                     * sets local.country to the first selected item for backward
                     * compatibility.  The selected value may be an object (with a
                     * `name` property) or a simple string; we normalise to the country
                     * name before persisting.
                     */
                    function persistSelection(selected) {
                        let selectionArray;
                        if (Array.isArray(selected)) {
                            selectionArray = selected.map(function(item) {
                                return (item && typeof item === 'object' && item.name) ? item.name : item;
                            });
                        } else if (selected) {
                            selectionArray = [ (selected && typeof selected === 'object' && selected.name) ? selected.name : selected ];
                        } else {
                            selectionArray = [];
                        }
                        if (scope) {
                            if (!scope.local) scope.local = {};
                            scope.local.countries = selectionArray.slice();
                            scope.local.country = selectionArray.length ? selectionArray[0] : '';
                            if (typeof scope.saveLocal === 'function') {
                                scope.saveLocal();
                            }
                            scope.$applyAsync();
                        } else {
                            window.localCountries = selectionArray.slice();
                            window.localCountry = selectionArray.length ? selectionArray[0] : '';
                        }
                    }

                    // Build a data source of objects with name, flag emoji and ISO code.
                    // Each item includes:
                    //   - `name`: the country name
                    //   - `flag`: a fallback emoji (from window.countryFlags) used only if no ISO code exists
                    //   - `code`: the ISO‑3166 alpha‑2 code (lowercase) used with Semantic UI's flag icons
                    //   - `display`: the plain country name (we avoid prepending the emoji here because
                    //               the actual icon will be rendered by the item template via <i class="flag xx"></i>)
                    const items = dataSrc.map(function(name) {
                        const flagEmoji = (window.countryFlags && window.countryFlags[name]) || '';
                        const isoCode = (window.countryIsoCodes && window.countryIsoCodes[name]) || '';
                        return {
                            name: name,
                            flag: flagEmoji,
                            code: isoCode,
                            display: name
                        };
                    });

                    // Convert the saved selection (array of names) into the
                    // corresponding objects from the items array.  If the
                    // selection cannot be resolved (e.g. name missing), leave it
                    // undefined so that the dropdown displays the default.
                    const selectedObjects = (savedSelection && savedSelection.length)
                        ? items.filter(function(item) { return savedSelection.indexOf(item.name) !== -1; })
                        : [];

                    // Define options for the DropDownBox.  For a single‑select
                    // configuration we bind the value to the selected country name
                    // (valueExpr) and provide a custom displayExpr to show the
                    // flag and name in the input.  The embedded dxList uses the
                    // same items array and a custom itemTemplate to render
                    // country flags.  When the selection changes we update the
                    // DropDownBox value and persist the chosen country via
                    // persistSelection().
                    const options = {
                        dataSource: items,
                        valueExpr: 'name',
                        displayExpr: function(item) {
                            if (!item) return '';
                            return item.display;
                        },
                        // Use the first saved selection as the initial value
                        value: (selectedObjects.length) ? selectedObjects[0].name : null,
                        placeholder: '',
                        contentTemplate: function(e, contentElement) {
                            const $listContainer = $('<div>');
                            new DevExpress.ui.dxList($listContainer.get(0), {
                                dataSource: items,
                                selectionMode: 'single',
                                // Provide the selected object in an array
                                selectedItems: selectedObjects,
                                searchEnabled: true,
                                searchMode: 'contains',
                                searchExpr: 'name',
                                searchEditorOptions: {
                                    placeholder: ''
                                },
                                showSelectionControls: false,
                                // Custom item template to render a real flag icon and name.
                                // We use Semantic UI's flag sprite by adding the ISO code as a class.
                                // When no ISO code is available, we fall back to rendering the emoji stored in
                                // itemData.flag within a simple <span>.  The .country-item class suppresses
                                // the generic pseudo‑icon defined in custom-styles.css.
                                itemTemplate: function(itemData, itemIndex, itemElement) {
                                    // Render the real flag icon when an ISO code is available.  If no code
                                    // exists for a given name we fall back to a generic Material Icons
                                    // flag glyph.  Emoji flags are no longer used to avoid mixing icon
                                    // styles.  The .country-item class suppresses the generic pseudo
                                    // element defined in custom-styles.css.
                                    let $icon;
                                    if (itemData.code) {
                                        $icon = $('<i>').addClass('flag').addClass(itemData.code);
                                    } else {
                                        // Use Material Icons 'flag' glyph as a fallback when no ISO code is available
                                        $icon = $('<span>').addClass('material-icons').text('flag');
                                    }
                                    const $name = $('<span>').addClass('country-name').text(itemData.name);
                                    $(itemElement).addClass('country-item');
                                    $(itemElement).empty().append($icon).append($name);
                                },
                                onSelectionChanged: function(args) {
                                    const selectedItems = args.component.option('selectedItems');
                                    const selectedObj = (Array.isArray(selectedItems) && selectedItems.length) ? selectedItems[0] : null;
                                    // Reflect selection in the DropDownBox value.
                                    e.component.option('value', selectedObj ? selectedObj.name : null);
                                    // Persist using the object (persistSelection will normalise to name)
                                    persistSelection(selectedObj);
                                    // Close the drop‑down after a selection is made.
                                    if (typeof e.component.close === 'function') {
                                        e.component.close();
                                    }
                                }
                            });
                            $(contentElement).append($listContainer);
                        },
                        onValueChanged: function(e) {
                            const val = e.value;
                            persistSelection(val);
                        }
                    };

                    // Instantiate the DropDownBox using DevExtreme if available; fall back to
                    // jQuery plugin method when appropriate.
                    if (typeof DevExpress !== 'undefined' && DevExpress.ui && DevExpress.ui.dxDropDownBox) {
                        new DevExpress.ui.dxDropDownBox(domEl, options);
                    } else if (typeof $(domEl).dxDropDownBox === 'function') {
                        $(domEl).dxDropDownBox(options);
                    } else {
                        console.warn('DevExtreme DropDownBox plugin not found; country list will not render');
                    }

                    // Persist the initial selection to storage so that default values are saved when
                    // none were previously provided.
                    persistSelection(savedSelection);
                } catch (initErr) {
                    console.warn('Error while initialising DevExtreme country dropdown', initErr);
                }
            }

            // Look for a country dropdown rendered at page load and initialise it.
            const $dropDown = $('#countryDropDown');
            if ($dropDown.length) {
                initializeCountryDropDown($dropDown.get(0));
            }

            // After attempting initialisation on any existing #countryDropDown, schedule
            // a fallback initialiser.  This runs periodically to detect when the
            // element is added to the DOM (e.g. via ng-include) and applies the
            // configuration.  Once the dropdown is created or after a maximum
            // number of attempts, the interval is cleared.
            try {
                var _plReinitAttempts = 0;
                var _plReinitMax = 20;
                var _plReinitInterval = setInterval(function() {
                    _plReinitAttempts++;
                    var navEl = document.getElementById('countryDropDown');
                    if (navEl && typeof $(navEl).dxDropDownBox === 'function') {
                        var isInitialized;
                        try {
                            isInitialized = !!$(navEl).data('dxDropDownBox');
                        } catch (errCheck) {
                            isInitialized = false;
                        }
                        if (!isInitialized) {
                            initializeCountryDropDown(navEl);
                        }
                        // Stop polling once the element exists (whether initialised now or previously).
                        clearInterval(_plReinitInterval);
                    } else if (_plReinitAttempts >= _plReinitMax) {
                        // Give up after max attempts if the element never appears.
                        clearInterval(_plReinitInterval);
                    }
                }, 500);
            } catch (_plErr) {
                console.warn('Failed to schedule fallback initialiser for country dropdown', _plErr);
            }
        });
    } catch (err) {
        console.warn('Failed to initialise DevExtreme country dropdown', err);
    }

})();
