var ngApp = angular.module("popupApp",[]).config(function($sceProvider) {
    $sceProvider.enabled(false);
});

/*
 * Some third‑party libraries (or legacy parts of this codebase) invoke
 * chrome.runtime.sendMessage without a callback.  In Chrome Manifest V3
 * this causes sendMessage to return a Promise which will reject with
 * "Could not establish connection. Receiving end does not exist." when
 * there is no listener.  To prevent unhandled promise rejections from
 * surfacing in the console, we override sendMessage to always use a
 * dummy callback when none is provided.  This wrapper forwards the
 * original arguments and suppresses the returned promise when no
 * callback is supplied.
 */
try {
    if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
        const _origSendMessage = chrome.runtime.sendMessage.bind(chrome.runtime);
        chrome.runtime.sendMessage = function(message, arg2, arg3) {
            // Detect invocation patterns:
            //   sendMessage(message)
            //   sendMessage(message, options)
            //   sendMessage(message, callback)
            //   sendMessage(message, options, callback)
            // Chrome docs: the second parameter is optional options or callback.
            // The third parameter is callback if second is options.
            let callback;
            if (typeof arg2 === 'function') {
                callback = arg2;
            } else if (typeof arg3 === 'function') {
                callback = arg3;
            }
            // Provide a wrapper callback that always reads chrome.runtime.lastError
            // so that runtime errors are marked as handled.  Without reading
            // lastError, Chrome will log "Unchecked runtime.lastError" when
            // there is no receiving end.  If the caller did not provide
            // a callback, we insert a dummy callback that reads lastError.
            const wrappedCallback = function(...cbArgs) {
                try {
                    // Access lastError to mark it as handled
                    void chrome.runtime.lastError;
                } catch (e) {
                    // ignore
                }
                if (typeof callback === 'function') {
                    try {
                        callback.apply(this, cbArgs);
                    } catch (cbErr) {
                        // Avoid letting callback errors propagate
                        console.warn('Error in runtime.sendMessage callback', cbErr);
                    }
                }
            };
            // If no callback provided, pass our dummy wrapper as the second arg
            if (!callback) {
                return _origSendMessage(message, wrappedCallback);
            }
            // Determine whether arg2 is options or callback and invoke accordingly
            if (typeof arg2 === 'function') {
                // Only message and callback provided
                return _origSendMessage(message, wrappedCallback);
            }
            // message, options and callback provided
            return _origSendMessage(message, arg2, wrappedCallback);
        };
    }
} catch (sendWrapErr) {
    console.warn('Failed to wrap chrome.runtime.sendMessage', sendWrapErr);
}

/*
 * Globally suppress unhandled promise rejections originating from Chrome
 * messaging when there is no receiving end.  Without a listener,
 * chrome.runtime.sendMessage() returns a promise that rejects with
 * "Could not establish connection. Receiving end does not exist.".
 * This handler prevents those rejections from surfacing as uncaught
 * errors in the console.  Other unhandled rejection reasons are
 * untouched so legitimate errors still appear.
 */
window.addEventListener('unhandledrejection', event => {
    try {
        const reason = event && event.reason;
        const msg = reason && (reason.message || reason.toString());
        if (msg && msg.includes('Could not establish connection')) {
            // Prevent default logging of this rejection
            // We intentionally do not emit our own warning here to avoid cluttering
            // the console with benign messaging errors.  Prior versions of this
            // extension logged a suppressed warning, but that still annoyed
            // users.  Simply prevent the default unhandled rejection and
            // silently ignore the message.
            event.preventDefault();
            return;
        }
    } catch (err) {
        // Silently ignore any issues in the rejection handler itself
    }
});

// v89: if the dashboard was opened directly (bookmark/reload rather than the
// toolbar icon), still warm licence/provider routing in the background.
try {
    const warmDashboardBackend = function(reason) {
        try { chrome.runtime.sendMessage({ action: 'pocketleads_warm_backend', reason: reason || 'dashboard_load', force: false }, function(){ void chrome.runtime.lastError; }); } catch (e) {}
    };
    setTimeout(function(){ warmDashboardBackend('dashboard_load'); }, 0);
    // Keep routeVerifiedAt fresh (<30s) while dashboard is open so clicking Start
    // never blocks on a synchronous preflight round-trip to Apps Script.
    setInterval(function(){
        try { if (typeof document === 'undefined' || !document.hidden) warmDashboardBackend('dashboard_keepwarm'); } catch (e) {}
    }, 20000);
} catch (e) {}

window.addEventListener('error', event => {
    try {
        const msg = event && event.message ? String(event.message) : '';
        const file = event && event.filename ? String(event.filename) : '';
        if (/Cannot read properties of null \(reading ['\"]data['\"]\)/i.test(msg) && /dx\.all\.js/i.test(file)) {
            event.preventDefault();
        }
    } catch (err) {}
});


// Include a new 'status' column to indicate whether a business is temporarily closed.
// Include WhatsApp status column to show availability of WhatsApp for each phone number.
var baseColumnList = [
    "keyword",
    "location",
    "company_name",
    "website",
    "phone_number",
    // New column to display whether the scraped phone is available on WhatsApp.  Values will be
    // populated via the WhatsApp number check feature.  See $scope.whatsappCheck for logic.
    "whatsapp_status",
    // Only a single email column is needed.  Additional emails will be
    // concatenated and stored in email_1, separated by commas.
    "email_1",
    "facebook",
    "instagram",
    "linkedin",
    "twitter",
    "youtube",
    "address",
    "city",
    "state",
    "pincode",
    // Rename rating_count to total_reviews for clarity
    "total_reviews",
    "review",
    "category",
    "categories",
    "latitude",
    "longitude",
    "place_id",
    "cid",
    // Insert a new column for the map link.  This column will hold a Google
    // Maps URL constructed from the listing's CID.  The order here dictates
    // where the column appears in the data grid and the exported CSV.
    "map_link",
    "status", // New column for the business status (e.g., temporarily closed)
    "source",
    "scraped_at"
];

var columnList = baseColumnList.slice();

function dashboardCountryDialPrefix() {
    try {
        const local = window && window.angular ? null : null;
    } catch (e) {}
    // This helper is intentionally scope-free. It defaults to India because the
    // dashboard mostly scrapes Indian leads and selected-country logic is applied
    // again inside WA validation.
    return '91';
}

function normalizeDashboardPhone(value) {
    const text = String(value == null ? '' : value).trim();
    if (!text) return '';
    const cleaned = text.replace(/^\s*(?:phone|mobile|tel|telephone)\s*[:：-]\s*/i, '').trim();
    const parts = cleaned.split(/(?:\s*(?:,|;|\||\/|\n|\r)\s*)+/).filter(Boolean);
    let best = '';
    for (const part of parts.length ? parts : [cleaned]) {
        let digits = String(part || '').replace(/\D/g, '').replace(/^0+/, '');
        if (!digits) continue;
        // Prefer real mobile/phone length. Avoid treating ratings or pincodes as phones.
        if (digits.length >= 8 && digits.length <= 15) { best = digits; break; }
    }
    if (!best) best = cleaned.replace(/\s+/g, ' ').trim();
    if (/^\+/.test(cleaned) && /^\d{8,15}$/.test(best)) return '+' + best;
    const prefix = dashboardCountryDialPrefix();
    if (prefix === '91') {
        if (/^91\d{10}$/.test(best)) return '+' + best;
        if (/^\d{10}$/.test(best)) return '+91' + best;
    }
    if (/^\d{8,15}$/.test(best)) return '+' + best;
    return best;
}

function rowPhoneValue(row) {
    if (!row || typeof row !== 'object') return '';
    const candidates = [
        row.phone_number, row.phoneNumber, row.phone, row.telephone, row.mobile,
        row.contactPhone, row.contact_number, row.businessPhone, row.primaryPhone,
        row.formattedPhone, row.formatted_phone_number, row.internationalPhoneNumber,
        row.international_phone_number, row.phoneNumberUnformatted, row.phoneUnformatted,
        row.phone_number_unformatted
    ];
    for (const value of candidates) {
        const formatted = normalizeDashboardPhone(value);
        if (formatted) return formatted;
    }
    return '';
}

function dashboardFirstValue(row, keys) {
    for (const key of keys || []) {
        const value = row && row[key];
        if (value !== null && typeof value !== 'undefined' && String(value).trim()) return String(value).trim();
    }
    return '';
}

function normalizeDashboardEmails(value) {
    const text = String(value == null ? '' : value)
        .replace(/&commat;|&#64;|&#x40;/gi, '@')
        .replace(/&period;|&#46;|&#x2e;/gi, '.')
        .replace(/\s*(?:\[|\(|\{)\s*at\s*(?:\]|\)|\})\s*/gi, '@')
        .replace(/\s+at\s+/gi, '@')
        .replace(/\s*(?:\[|\(|\{)\s*dot\s*(?:\]|\)|\})\s*/gi, '.')
        .replace(/\s+dot\s+/gi, '.');
    const emails = [];
    const re = /[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+/gi;
    let match;
    while ((match = re.exec(text)) !== null) {
        const email = match[0].toLowerCase().replace(/[.,;:]+$/, '');
        if (email && !emails.includes(email) && email.length <= 254) emails.push(email);
    }
    return emails.join(', ');
}

function canonicalDashboardSource(value) {
    const text = String(value || '').trim();
    const lower = text.toLowerCase().replace(/[\s_-]+/g, '');
    if (!lower) return '';
    if (lower.includes('scrappa')) return 'Scrappa';
    if (lower.includes('serper')) return 'Serper';
    if (lower.includes('apify')) return 'Apify';
    if (lower.includes('googlemaps') || lower.includes('googleplace') || lower.includes('placeidprofile')) return 'Google Maps';
    return text;
}

function repairLegacyProviderSources(rows, local) {
    const list = Array.isArray(rows) ? rows : [];
    const queue = local && local.apifyQueue ? local.apifyQueue : {};
    const provider = String(queue.provider || '').trim().toLowerCase();
    const startedMs = Date.parse(queue.startedAt || (local && local.scrapeStartedAt) || '');
    const changed = [];
    list.forEach(row => {
        if (!row || typeof row !== 'object') return;
        const before = String(row.source || '');
        const canonical = canonicalDashboardSource(before);
        if (canonical && canonical !== before && canonical !== 'apify_dataset') row.source = canonical;
        // v80 wrote Serper rows as apify_dataset. Repair only rows belonging to
        // the currently known Serper run, never historical/mixed rows blindly.
        const scrapedMs = Date.parse(row.scraped_at || row.createdAt || '');
        const isCurrentRun = Number.isFinite(startedMs) && Number.isFinite(scrapedMs) && scrapedMs >= (startedMs - 60000);
        if (provider === 'serper' && /^(apify|apify_dataset)$/i.test(before) && isCurrentRun) {
            row.source = 'Serper';
            row._provider = 'serper';
            row._source_detail = row._source_detail || 'legacy_v80_source_repair';
        }
        if (row.source !== before) changed.push(row);
    });
    return changed;
}

function normalizeDashboardRow(row) {
    if (!row || typeof row !== 'object') return row;
    const phone = rowPhoneValue(row);
    if (phone) row.phone_number = phone;
    const email = normalizeDashboardEmails([
        row.email_1, row.email, row.email1, row.emailAddress, row.email_address,
        row.contactEmail, row.contact_email, row.businessEmail, row.business_email,
        row.mail, row.mailAddress, row.mail_address
    ].filter(Boolean).join(', '));
    if (email) row.email_1 = email;
    else if (row.email_1 && /^(no email found|can't access website|blacklisted email)$/i.test(String(row.email_1).trim())) row.email_1 = String(row.email_1).trim();
    else row.email_1 = '';
    row.company_name = row.company_name || dashboardFirstValue(row, ['name', 'title', 'businessName', 'business_name', 'placeName', 'displayName']);
    row.website = row.website || dashboardFirstValue(row, ['websiteUrl', 'websiteURL', 'urlWebsite', 'officialWebsite', 'official_website', 'site']);
    row.address = row.address || dashboardFirstValue(row, ['formattedAddress', 'formatted_address', 'fullAddress', 'full_address', 'streetAddress', 'vicinity']);
    row.city = row.city || dashboardFirstValue(row, ['municipality', 'locality', 'town', 'district']);
    row.state = row.state || dashboardFirstValue(row, ['region', 'province', 'administrativeArea']);
    row.pincode = row.pincode || dashboardFirstValue(row, ['pinCode', 'postalCode', 'postal_code', 'postcode', 'zip', 'zipCode']);
    row.total_reviews = row.total_reviews || dashboardFirstValue(row, ['reviewCount', 'reviewsCount', 'reviews_count', 'ratingCount', 'ratingsCount', 'userRatingsTotal', 'user_ratings_total']);
    row.review = row.review || dashboardFirstValue(row, ['rating', 'stars', 'score', 'ratingValue', 'averageRating', 'average_rating']);
    row.place_id = row.place_id || dashboardFirstValue(row, ['placeId', 'placeID', 'googlePlaceId', 'googleMapsPlaceId', 'google_maps_place_id']);
    row.map_link = row.map_link || dashboardFirstValue(row, ['googleMapsUrl', 'googleMapsURL', 'mapsUrl', 'mapsURL', 'googleMapsLink', 'link', 'url']);
    row.facebook = row.facebook || dashboardFirstValue(row, ['facebookUrl', 'facebook_url', 'fb']);
    row.instagram = row.instagram || dashboardFirstValue(row, ['instagramUrl', 'instagram_url', 'ig']);
    row.linkedin = row.linkedin || dashboardFirstValue(row, ['linkedinUrl', 'linkedin_url']);
    row.twitter = row.twitter || dashboardFirstValue(row, ['twitterUrl', 'twitter_url', 'x_url']);
    row.youtube = row.youtube || dashboardFirstValue(row, ['youtubeUrl', 'youtube_url']);
    if (row.source) row.source = canonicalDashboardSource(row.source);
    // Remove provider aliases from the in-memory row as well, reducing payload
    // size and preventing accidental reintroduction by legacy code paths.
    try {
        ['phoneNumber','telephone','tel','mobile','formattedPhone','formatted_phone_number','internationalPhoneNumber','international_phone_number','phoneNumberUnformatted','phoneUnformatted','phone_number_unformatted','contactPhone','contact_number','businessPhone','primaryPhone','email','email1','emailAddress','email_address','contactEmail','contact_email','businessEmail','business_email','mail','mailAddress','mail_address','serper_raw_json','serper_endpoint'].forEach(k => { if (k in row) delete row[k]; });
    } catch (e) {}
    return row;
}

function isHiddenPhoneAliasColumn(key) {
    const normalized = String(key || '')
        .replace(/([a-z0-9])([A-Z])/g, '$1_$2')
        .replace(/[^a-zA-Z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '')
        .toLowerCase();
    if (!normalized) return false;
    // Keep only the canonical snake_case field. Hide camelCase/header variants
    // such as phoneNumber / Phone Number because the canonical column already
    // renders their value through rowPhoneValue().
    if (normalized === 'phone_number') return String(key || '') !== 'phone_number';
    return [
        'phone', 'phone_number_raw', 'phone_number_display', 'phone_number_formatted',
        'phone_number_unformatted', 'phone_number_unformatted_raw', 'phone_unformatted',
        'phone_formatted', 'formatted_phone', 'formatted_phone_number',
        'international_phone_number', 'telephone', 'tel', 'mobile', 'contact_phone',
        'contact_number', 'business_phone', 'primary_phone', 'whatsapp_number',
        'wa_number'
    ].includes(normalized);
}

function buildColumnListFromRows(rows) {
    // Deliberately fixed for both Engine 1 and Engine 2. Raw provider keys,
    // debug payloads and aliases must never become user-facing headers.
    (rows || []).forEach(row => { if (row && typeof row === 'object') normalizeDashboardRow(row); });
    return baseColumnList.slice();
}

function refreshColumnList(rows) {
    columnList = buildColumnListFromRows(rows || []);
    return columnList;
}

ngApp.controller("indexController", function($scope, $http,$sce) {
    
    $scope.developer = DEVELOPER_INFO;
    $scope.manifest = chrome.runtime.getManifest();
    $scope.welcome = WelcomeController.model;
    $scope.Tabs = Tabs;
    $scope.$fc = FoxCommon;
    $scope.$auth = Auth;
    $scope.$config = Config;

    // -----------------------------------------------------------------------
    // Page limit dropdown controls
    //
    // We implement a custom dropdown for selecting the maximum number of pages
    // to scrape per pincode search.  Unlike a native <select>, this
    // dropdown uses a button and menu to allow for full styling in the
    // dark dashboard.  The dropdown is toggled via
    // togglePageLimitDropdown(), and selecting an option calls
    // setPageLimit(value) which stores the choice and hides the menu.
    $scope.pageLimitDropdownVisible = false;
    $scope.togglePageLimitDropdown = () => {
        $scope.pageLimitDropdownVisible = !$scope.pageLimitDropdownVisible;
    };
    $scope.setPageLimit = (value) => {
        $scope.local.pageLimit = value;
        $scope.saveLocal();
        $scope.pageLimitDropdownVisible = false;
    };

    // -----------------------------------------------------------------------
    // WA number check progress tracking
    //
    // These properties track the progress of the local‑only WA number
    // check feature.  waTotal is the number of phone numbers to process,
    // waFinished counts how many have completed, and waChecking is true
    // while the check is running.  waCompletedRows is a map of row
    // indices that have already been counted so we do not double‑count
    // retries or duplicate updates.
    $scope.waTotal = 0;
    $scope.waFinished = 0;
    $scope.waChecking = false;
    $scope.waCompletedRows = {};
    /*
     * Maintain sets of completed and enqueued rows keyed by a stable
     * identifier (cid) rather than the row index.  Using the row index
     * alone can lead to incorrect progress tracking when new results
     * are inserted into local.collect, shifting indices and causing
     * previously processed rows to be considered pending again.  The
     * cid property is unique per record and does not change when
     * records are reordered or new results are inserted.  We use
     * waCompletedIds and waEnqueuedIds alongside the legacy
     * waCompletedRows/waEnqueuedRows to ensure that progress is
     * session‑scoped and cumulative.
     */
    $scope.waCompletedIds = {};
    $scope.waEnqueuedIds = {};
    // Track all phone numbers discovered during the current scraping session.
    // Keys are stable cids.  This allows the total (waTotal) to represent
    // the number of unique phone numbers encountered so far, regardless of
    // whether they have been processed or enqueued.  Do not clear this
    // object when stopping a WA run; clear it only when starting a new
    // scraping session.
    $scope.waDiscoveredIds = {};
    // Capture the initial total number of phone numbers at the moment a
    // WhatsApp number check begins.  This value is used for the
    // progress bar denominator so that the total count displayed to
    // the user remains constant even when new numbers are added
    // during scraping.  We update waInitialTotal at the start of
    // each WA check and keep it unchanged during subsequent runs until
    // the next WA check begins.  Resets to zero when the user
    // manually stops the check.
    $scope.waInitialTotal = 0;
    // Track rows that have been enqueued for the current WhatsApp check.  When
    // scraping is running concurrently with a WA check we may discover new
    // phone numbers.  To avoid sending duplicates to the background
    // service worker we record each rowId as soon as it is queued.  Only
    // rows not present in this object will be added when new data arrives.
    $scope.waEnqueuedRows = {};

    // When a WA run finishes while scraping is still active we defer showing
    // the completion popup until scraping has truly ended.  This flag is
    // true when a WA run has completed but more numbers may still arrive.
    $scope.waPendingComplete = false;
        // Record the timestamp when a WA check starts.  This is used to
        // suppress an immediate scraping completion popup if the
        // completion event arrives within a few seconds of starting a
        // WA check.  Without this, a race condition in fast mode may
        // cause the scraping completion popup to appear right after
        // initiating the WA check.
        $scope.waStartTimestamp = 0;
    // Track whether scraping is currently active.  This is updated when
    // scraping starts and stops so that WA checking logic can decide
    // whether to wait for new numbers or show a completion notification.
    $scope.scrapingActive = false;

        // When true we suppress the "Scraping completed" UI and desktop
        // notification because a WhatsApp number check is currently
        // running or has completed and is waiting for late numbers.
        // Scraping may finish while WA is still active; in that case we
        // defer the completion popup until WA finishes.  The flag is
        // reset when the WA run ends and the deferred popup is shown.
        $scope.suppressScrapingComplete = false;
        // Internal flag set when a scraping_complete event occurs while
        // suppressScrapingComplete is true.  It indicates that the
        // scraping completion logic should run after WA finishes.
        $scope.scrapingCompletePending = false;

    // Flag to indicate that a manual stop is in progress.  When true, any
    // subsequent scraping_stopped events will not trigger notifications or
    // duplicate "Scraping stopped" alerts.  This flag is set by
    // manualStopScraping and cleared after the stop has been fully handled.
    $scope.manualStopInProgress = false;

    // When true, the UI is waiting for the user to log in to
    // WhatsApp Web.  During this period waChecking is true but no
    // numbers are processed.  The user should switch to the
    // WhatsApp tab and scan the QR code.  Once login is detected
    // processing will begin automatically.
    $scope.waLoginWaiting = false;

    /**
     * Safely execute a function within Angular's digest cycle.  When called
     * during an existing $apply/$digest this helper will execute the
     * callback immediately without triggering a new digest.  Otherwise it
     * delegates to $apply so that changes are picked up.  Use this
     * function instead of $scope.$apply() in asynchronous callbacks to
     * avoid `$rootScope:inprog` errors.
     *
     * @param {Function} fn The function to execute
     */
    $scope.safeApply = function(fn) {
        try {
            const phase = $scope.$root && $scope.$root.$$phase;
            if (phase === '$apply' || phase === '$digest') {
                if (typeof fn === 'function') {
                    fn();
                }
            } else {
                $scope.$apply(fn);
            }
        } catch (err) {
            // Log and suppress errors; never throw from safeApply
            console.warn('safeApply: error executing callback', err);
            try {
                if (typeof fn === 'function') {
                    fn();
                }
            } catch (innerErr) {
                /* ignore */
            }
        }
    };

    // Country selector used by Serper/Google/Apify query restriction. Keep this
    // inside the dashboard model so the selected country is saved and used by
    // the API before credits are spent.
    const DASHBOARD_COUNTRY_CODES = {
        'India': 'IN', 'Bangladesh': 'BD', 'Pakistan': 'PK', 'Nepal': 'NP', 'Sri Lanka': 'LK', 'Bhutan': 'BT',
        'United States': 'US', 'United Kingdom': 'GB', 'United Arab Emirates': 'AE', 'Canada': 'CA', 'Australia': 'AU',
        'Singapore': 'SG', 'Malaysia': 'MY', 'Thailand': 'TH', 'Indonesia': 'ID', 'Philippines': 'PH',
        'Germany': 'DE', 'France': 'FR', 'Italy': 'IT', 'Spain': 'ES', 'Netherlands': 'NL', 'Brazil': 'BR', 'Mexico': 'MX',
        'South Africa': 'ZA', 'Saudi Arabia': 'SA', 'Qatar': 'QA', 'Oman': 'OM', 'Kuwait': 'KW'
    };
    $scope.countries = Object.keys(DASHBOARD_COUNTRY_CODES);
    if (typeof window !== 'undefined') {
        window.countryList = $scope.countries;
        window.countryIsoCodes = Object.assign({}, window.countryIsoCodes || {}, DASHBOARD_COUNTRY_CODES);
    }
    function dashboardCountryCode(country) {
        const c = String(country || '').trim();
        if (!c) return 'IN';
        return DASHBOARD_COUNTRY_CODES[c] || (typeof window !== 'undefined' && window.countryIsoCodes && window.countryIsoCodes[c]) || 'IN';
    }
    $scope.setCountry = function(country) {
        if (!$scope.local) $scope.local = {};
        const selected = String(country || $scope.local.country || 'India').trim() || 'India';
        $scope.local.country = selected;
        $scope.local.countryCode = dashboardCountryCode(selected);
        $scope.local.apifySettings = Object.assign({}, $scope.local.apifySettings || {}, {
            countryFilter: selected,
            countryCodeFilter: $scope.local.countryCode,
            enforceCountryFilter: true
        });
        if (typeof window !== 'undefined') window.localCountry = selected;
        try { $scope.saveLocal(); } catch (e) {}
    };

    $scope.exportModal = {
        show: false,
        fields: [],
        selected: {},
        format: 'csv'
    };

    // Track whether a valid licence has been activated.  This flag
    // defaults to false until storage is queried.  When true, the
    // dashboard's start button is enabled and export functionality
    // operates normally.  When false, attempts to start scraping or
    // export will display a prompt asking the user to activate their
    // licence first.
    $scope.licenseActive = false;
    // Store the number of active devices returned by the backend.  This
    // value is displayed in the navbar and defaults to zero until the
    // licence state is read from storage.
    $scope.licenseDevices = 0;

    // Initialize licenceActive based on stored licence information.  If
    // storage access fails we leave licenceActive false to ensure the
    // user is prompted for activation.  This check runs only once
    // during controller initialization.
    try {
        chrome.storage.local.get('license', function(res) {
            const lic = res && res.license;
            $scope.$apply(() => {
                $scope.licenseActive = !!(lic && lic.active);
                // After retrieving licence state, update the UI to
                // reflect start button availability.
                if (typeof $scope.updateUIState === 'function') {
                    $scope.updateUIState();
                }
            });
        });
    } catch (err) {
        console.error('Failed to read licence from storage', err);
    }

    // Listen for licence changes in storage so the UI responds when a
    // licence is activated or released while the popup is open.  This
    // ensures the start button updates without requiring a refresh.
    try {
        chrome.storage.onChanged.addListener(function(changes, areaName) {
            if(areaName==='local' && changes.pocketleadsPreflightState?.newValue?.errorCode==='ACCOUNT_PREFLIGHT'){
                const message=changes.pocketleadsPreflightState.newValue.message;
                $scope.$evalAsync(()=>{ $scope.startLaunchPending=false; if($scope.showCaptchaPopup)$scope.showCaptchaPopup(message); });
            }
            if (areaName === 'local' && changes.license) {
                const newLic = changes.license.newValue;
                $scope.$apply(() => {
                    $scope.licenseActive = !!(newLic && newLic.active);
                    if (typeof $scope.updateUIState === 'function') {
                        $scope.updateUIState();
                    }
                });
            }
            if (areaName === 'local' && (changes.pocketleadsAccount || changes.license || changes.pocketleadsPreparedRoute)) {
                if (typeof $scope.checkExpiringLicencePopup === 'function') {
                    $scope.checkExpiringLicencePopup(false);
                }
            }
            if (areaName === 'local' && changes.pocketleadsPreflightState) {
                const state = changes.pocketleadsPreflightState.newValue || {};
                const code = String(state.errorCode || '').toUpperCase();
                const upgrade = !!state.upgradeRequired || /LICENSE_(?:EXPIRED|CREDIT_EXHAUSTED)|LICENCE_(?:EXPIRED|CREDIT_EXHAUSTED)|ALL_CREDITS_EXHAUSTED/.test(code);
                if (upgrade && String(state.status || '') === 'error') {
                    const show = function(){
                        if (typeof $scope.showCaptchaPopup === 'function') {
                            const msg = /CREDIT/.test(code)
                                ? 'Your scraping credits are exhausted. Upgrade your plan to continue. Contact ' + (state.supportEmail || PocketLeadsConfig.supportEmail) + '.'
                                : 'Your licence has expired. Contact ' + (state.supportEmail || PocketLeadsConfig.supportEmail) + ' to renew your licence.';
                            $scope.showCaptchaPopup(msg, { title:'Upgrade Required', upgrade:true, supportEmail:state.supportEmail || PocketLeadsConfig.supportEmail });
                        } else {
                            $scope.pendingPreflightCommercialState = state;
                        }
                    };
                    try { $scope.safeApply ? $scope.safeApply(show) : $scope.$evalAsync(show); } catch (e) { $scope.pendingPreflightCommercialState = state; }
                }
            }
        });
    } catch (err) {
        console.error('Failed to register licence change listener', err);
    }
    
    $scope.isCheckingLicense = false;
    // v91: short UI-only launch guard. Running/timer state is owned by the
    // background controller after a prepared data source has been accepted.
    $scope.startLaunchPending = false;
    
    /* ------------------------------- Login Page ------------------------------- */
    $scope.loginPage = {
        email : "",
        password : "",
        isLoading : false,
    };
    
    /* ---------------------------------- Local --------------------------------- */
    $scope.local = $box.getDefaultLocalModel();
    // Track whether a WhatsApp check has been paused.  When true the
    // resume button is shown and subsequent calls to whatsappCheck
    // will continue processing cancelled rows rather than starting
    // from scratch.  This flag is reset automatically when a new
    // WhatsApp check begins or after resuming.
    $scope.local.pausedWhatsapp = false;

    // Flag to suppress the next stop notification after a captcha
    // pause.  When scraping_error is received we set this to true.
    // The next scraping_stopped event resets it to false and
    // prevents additional notifications from showing.
    $scope.ignoreNextStopNotification = false;

    // Flag to indicate whether a scraping completion notification has
    // already been displayed during the current run.  This prevents
    // duplicate "Scraping Complete" notifications from showing if
    // multiple scraping_complete events are fired.  It is reset to
    // false whenever scraping starts again.
    $scope.scrapingCompleteShown = false;

    // Initialize settings panel visibility flag.  When false, the panel is
    // hidden; toggled to true by clicking the Settings button in the
    // dashboard header.  We store this on the local object so that
    // changes propagate through Angular's binding system.  See
    // views/index.html for the corresponding ng-show directive.
    $scope.local.showSettings = false;

    // ------------------------------------------------------------------------
    // Progress bar management (initial definitions)
    // ------------------------------------------------------------------------
    // Define the progressData object up front so it is available when
    // updateUIState first runs.  Without this early definition,
    // updateUIState may attempt to call updateProgress before the latter
    // has been assigned.
    $scope.progressData = { completed: 0, total: 0, percent: 0 };

    // Separate progress tracker for WhatsApp number checking.  This
    // object will be updated during the WhatsApp check to reflect
    // how many numbers have been processed out of the total.  When
    // total is zero the progress bar is hidden in the UI (via
    // ng-if).  Define it here so it exists before any checks run.
    $scope.whatsappProgress = { completed: 0, total: 0, percent: 0 };

    // Scraping timer for the dashboard stat card. It updates every second only
    // while scraping is active and also keeps the final completed/stopped time.
    $scope.scrapeTimerTick = Date.now();
    $scope.totalScrapingTimeText = '00:00';
    $scope.formatDurationMs = function(ms) {
        ms = Math.max(0, parseInt(ms, 10) || 0);
        const totalSeconds = Math.floor(ms / 1000);
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
        const pad = n => String(n).padStart(2, '0');
        return hours > 0 ? (hours + ':' + pad(minutes) + ':' + pad(seconds)) : (pad(minutes) + ':' + pad(seconds));
    };
    let _activeScreenWakeLock = null;
    async function syncScreenWakeLock(shouldHold) {
        try {
            if (typeof navigator === 'undefined' || !navigator.wakeLock || typeof navigator.wakeLock.request !== 'function') return;
            if (shouldHold && !document.hidden) {
                if (!_activeScreenWakeLock) {
                    _activeScreenWakeLock = await navigator.wakeLock.request('screen').catch(() => null);
                    if (_activeScreenWakeLock && typeof _activeScreenWakeLock.addEventListener === 'function') {
                        _activeScreenWakeLock.addEventListener('release', () => { _activeScreenWakeLock = null; });
                    }
                }
            } else if (!shouldHold && _activeScreenWakeLock) {
                try { await _activeScreenWakeLock.release(); } catch (_) {}
                _activeScreenWakeLock = null;
            }
        } catch (_) {}
    }

    if (typeof document !== 'undefined' && !document.documentElement.dataset.plWakeRecoveryBound) {
        document.documentElement.dataset.plWakeRecoveryBound = '1';
        const onWakeOrFocus = () => {
            try {
                const local = $scope.local || {};
                if (PocketLeadsRunState.isRunning(local)) {
                    void syncScreenWakeLock(true);
                    if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
                        chrome.runtime.sendMessage({ action: 'ensure_engine_alive' }, () => { try { void chrome.runtime.lastError; } catch (_) {} });
                    }
                }
            } catch (_) {}
        };
        document.addEventListener('visibilitychange', () => { if (!document.hidden) onWakeOrFocus(); });
        if (typeof window !== 'undefined') {
            window.addEventListener('focus', onWakeOrFocus);
            window.addEventListener('online', onWakeOrFocus);
        }
    }

    $scope.recalculateScrapingTimeText = function() {
        const local = $scope.local || {};
        const q = local.apifyQueue || {};
        let effectiveNow = $scope.scrapeTimerTick || Date.now();
        // If phone screen locked and OS paused background network sockets for >25s, freeze timer at last active window so duration does not inflate while 0 results arrive
        const lastCheckpointMs = Date.parse(q.lastUpdatedAt || '');
        if (PocketLeadsRunState.isRunning(local) && Number.isFinite(lastCheckpointMs) && effectiveNow - lastCheckpointMs > 25000) {
            effectiveNow = lastCheckpointMs + 25000;
        }
        const value = $scope.formatDurationMs(PocketLeadsRunState.elapsed(local, effectiveNow));
        $scope.totalScrapingTimeText = value;
        return value;
    };
    $scope.getTotalScrapingTime = function() {
        return $scope.totalScrapingTimeText || $scope.recalculateScrapingTimeText();
    };
    try {
        setInterval(function() {
            const local = $scope.local || {};
            const running = PocketLeadsRunState.isRunning(local);
            void syncScreenWakeLock(running);
            if (running) {
                $scope.$applyAsync(function() {
                    $scope.scrapeTimerTick = Date.now();
                    $scope.recalculateScrapingTimeText();
                });
            }
        }, 1000);
    } catch (timerErr) {
        console.warn('Scraping timer init failed', timerErr);
    }

    // Storage-change events can occasionally be missed while the extension page
    // is being reopened. Poll only during an active run as a low-cost watchdog.
    try {
        setInterval(function() {
            const current = $scope.local || {};
            const isActive = PocketLeadsRunState.isRunning(current);
            if (!isActive) return;
            const lastAt = Date.parse((current.apifyQueue && current.apifyQueue.lastUpdatedAt) || '');
            if (Number.isFinite(lastAt) && Date.now() - lastAt > 9000) {
                try {
                    if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
                        chrome.runtime.sendMessage({ action: 'ensure_engine_alive' }, () => { try { void chrome.runtime.lastError; } catch (_) {} });
                    }
                } catch (_) {}
            }
            $box.getLocal(function(fresh) {
                if (!fresh) return;
                const oldStamp = String(current.apifyQueue && current.apifyQueue.lastUpdatedAt || '');
                const newStamp = String(fresh.apifyQueue && fresh.apifyQueue.lastUpdatedAt || '');
                if (!newStamp || newStamp === oldStamp) return;
                fresh.collect = dedupeDashboardRows(fresh.collect || []);
                $scope.$applyAsync(function() {
                    const sameRun = (fresh.apifyQueue || {}).runEventId === (($scope.local || {}).apifyQueue || {}).runEventId;
                    if (sameRun && $scope.local && Array.isArray($scope.local.collect) && $scope.local.collect.length > 0) {
                        const fullRows = $scope.local.collect.slice();
                        const rowKey = row => String((row && (row.place_id || row.cid || row.map_link || row.phone || row.company_name || ((row.company_name || row.name || '') + '|' + (row.address || '')))) || '');
                        const indexByKey = new Map();
                        fullRows.forEach((row, idx) => indexByKey.set(rowKey(row), idx));
                        (fresh.collect || []).forEach(row => {
                            const key = rowKey(row);
                            if (key && indexByKey.has(key)) fullRows[indexByKey.get(key)] = Object.assign({}, fullRows[indexByKey.get(key)], row);
                            else { indexByKey.set(key, fullRows.length); fullRows.push(row); }
                        });
                        fresh.collect = dedupeDashboardRows(fullRows).slice(-250);
                    }
                    const bestCount = Math.max(
                        sameRun ? (parseInt($scope._monotonicResultCount, 10) || 0) : 0,
                        sameRun ? (parseInt($scope.local && $scope.local.resultStoreCount, 10) || 0) : 0,
                        parseInt(fresh.resultStoreCount, 10) || 0,
                        Array.isArray(fresh.collect) ? fresh.collect.length : 0
                    );
                    fresh.resultStoreCount = bestCount;
                    fresh.collectIsPreview = bestCount > (Array.isArray(fresh.collect) ? fresh.collect.length : 0);
                    $scope._monotonicResultCount = bestCount;
                    $scope.local = fresh;
                    refreshDashboardMetricCounts(fresh.collect || []);
                    if (typeof $scope.recalculateScrapingTimeText === 'function') $scope.recalculateScrapingTimeText();
                    $scope.updateUIState();
                });
            });
        }, 1500);
    } catch (watchdogErr) {
        console.warn('Progress watchdog init failed', watchdogErr);
    }

    /**
     * Compute and update the scraping progress.  See the detailed
     * documentation later in this file for the full description.  This
     * duplicate definition ensures that updateProgress exists before it is
     * invoked inside updateUIState.  The later definition will simply
     * overwrite this one with identical logic.
     */
    $scope.updateProgress = function() {
        const local = $scope.local || {};
        const q = local.apifyQueue || {};
        const status = String(q.status || '').toLowerCase();
        const active = PocketLeadsRunState.isRunning(local);
        const terminal = /^(completed|completed_with_errors)$/.test(status);
        const stopped = status === 'stopped';
        const listTotalKeywords = Array.isArray(local.keywordList) ? local.keywordList.length : 0;
        const listTotalLocations = Array.isArray(local.locationList) ? local.locationList.length : 0;
        const listTotal = listTotalKeywords && listTotalLocations ? (listTotalKeywords * listTotalLocations) : listTotalKeywords;
        const taskTotal = Math.max(0, parseInt(q.totalTasks || local.apifyTaskTotal || listTotal, 10) || 0);
        const rawCompleted = Math.max(0, Math.min(taskTotal || Number.MAX_SAFE_INTEGER, Math.max(parseInt(q.completedTasks, 10) || 0, parseInt(q.apiTasksSettled, 10) || 0)));
        const runId = String(q.runEventId || '');
        if (runId && $scope._monotonicProgressRunId !== runId) {
            $scope._monotonicProgressRunId = runId;
            $scope._monotonicTaskCompleted = rawCompleted;
        } else if (active || (rawCompleted > 0 && status !== 'idle' && status !== 'cleared')) {
            $scope._monotonicTaskCompleted = Math.max($scope._monotonicTaskCompleted || 0, rawCompleted);
        } else if (!active && rawCompleted === 0 && (status === 'idle' || status === 'cleared')) {
            $scope._monotonicTaskCompleted = 0;
        }
        const taskCompleted = Math.min(taskTotal || Number.MAX_SAFE_INTEGER, Math.max(rawCompleted, $scope._monotonicTaskCompleted || 0));
        const apiTotal = Math.max(0, parseInt(q.apiTasksTotal || taskTotal, 10) || 0);
        const apiDone = Math.max(0, parseInt(q.apiTasksDone, 10) || 0);
        const apiFailed = Math.max(0, parseInt(q.apiTasksFailed, 10) || 0);
        const apiSettled = Math.max(taskCompleted, Math.min(apiTotal || Number.MAX_SAFE_INTEGER, parseInt(q.apiTasksSettled, 10) || (apiDone + apiFailed)));
        const domTotal = Math.max(0, parseInt(q.domTotal, 10) || 0);
        const domProcessed = Math.max(0, Math.min(domTotal || Number.MAX_SAFE_INTEGER, parseInt(q.domProcessed, 10) || 0));
        const provider = String(q.provider || '').toLowerCase();
        const googleFlow = provider === 'googlemaps' || /google_/.test(status) || domTotal > 0;
        const hasSessionProgress = taskTotal > 0 || apiTotal > 0 || domTotal > 0 || (q.scrapedCount || 0) > 0 || active;
        if (!hasSessionProgress) {
            $scope.progressData = { completed: 0, total: 0, percent: 0, percentExact: 0, phase: 'Ready', detail: '' };
            return;
        }

        const currentTaskIdx = Math.max(0, Math.min(taskTotal || Number.MAX_SAFE_INTEGER, active && taskTotal > 0 ? Math.min(taskTotal, taskCompleted + 1) : taskCompleted));
        let completed = terminal ? taskTotal : taskCompleted;
        let total = taskTotal;
        let phase = 'Searches';
        let detail = taskTotal ? (completed + '/' + taskTotal + ' searches') : '';
        let percentExact = terminal ? 100 : (taskTotal > 0 ? (completed / taskTotal) * 100 : 0);

        if (googleFlow) {
            // Google flow has two real stages. API query collection is 15% of the
            // run and profile/DOM extraction is 85%. Once DOM extraction starts for
            // the active search, count its API search stage so 60/60 reaches 100%.
            const effectiveApiDone = domTotal > 0 ? Math.max(apiSettled, taskCompleted + (domProcessed > 0 || q.producerDone ? 1 : 0)) : apiSettled;
            const apiRatio = apiTotal ? Math.min(1, effectiveApiDone / apiTotal) : (domTotal > 0 ? 1 : 0);
            const domRatio = domTotal ? Math.min(1, domProcessed / domTotal) : 0;
            const domStarted = domTotal > 0 || /google_dom|google_profile|dataset_saved/.test(status);
            percentExact = domStarted ? (15 * apiRatio + 85 * domRatio) : (15 * apiRatio);
            if (domTotal > 0 && domProcessed >= domTotal && (parseInt(q.domPending, 10) || 0) === 0 && (parseInt(q.domRunning, 10) || 0) === 0 && (!apiTotal || effectiveApiDone >= apiTotal)) {
                percentExact = 100;
            }
            if (domStarted) {
                completed = domProcessed;
                total = domTotal;
                phase = 'Profiles';
                detail = domProcessed + '/' + domTotal + ' profiles';
            } else {
                completed = apiSettled;
                total = apiTotal;
                phase = 'API searches';
                detail = apiSettled + '/' + apiTotal + ' searches checked';
            }
        }

        if (terminal) percentExact = 100;
        if (stopped) percentExact = Math.min(99.9, percentExact);
        percentExact = Math.max(0, Math.min(100, percentExact));
        $scope.progressData = {
            completed: completed,
            completedSettled: taskCompleted,
            currentTaskIndex: currentTaskIdx,
            total: total,
            percent: Math.round(percentExact),
            percentExact: percentExact,
            phase: phase,
            detail: detail,
            apiCompleted: active && !googleFlow && apiTotal > 0 ? currentTaskIdx : apiSettled,
            apiTotal: apiTotal,
            domCompleted: domProcessed,
            domTotal: domTotal
        };
    };

    // Provide a stub for percentComplete to avoid undefined errors prior to
    // the later compatibility definition.
    $scope.percentComplete = () => {
        return $scope.progressData;
    };
    
    /* ----------------------------- On Local Change ---------------------------- */
    // The service worker can persist several result batches within a few
    // milliseconds. Reading/applying every notification separately makes
    // Angular evaluate local.collect.length repeatedly in one digest and can
    // trigger [$rootScope:infdig]. Coalesce to the latest storage snapshot.
    let localChangeTimer = null;
    let localChangeSerial = 0;
    let localReadSerial = 0;
    let localAppliedSerial = 0;
    $box.onLocalChange(() => {
        // v87 leading throttle instead of trailing debounce. Rapid background
        // writes used to keep clearing the timer forever, starving the live table
        // while KPI cards continued to move. One snapshot is now applied at least
        // every ~55ms during a busy stream.
        localChangeSerial += 1;
        if (localChangeTimer) return;
        localChangeTimer = setTimeout(() => {
            localChangeTimer = null;
            const readSerial = ++localReadSerial;
            const generation = $scope._canonicalGeneration;
            $box.getLocal(local => {
                if (readSerial < localAppliedSerial || generation !== $scope._canonicalGeneration) return;
                // v83 migration guard: storage can contain a model written by an
                // older extension build without nested runtime objects.  Always
                // merge defaults before Angular consumes it so bindings such as
                // local._taskManager.isWorking can never dereference undefined.
                const defaultLocal = $box.getDefaultLocalModel ? $box.getDefaultLocalModel() : {};
                local = Object.assign({}, defaultLocal || {}, local || {});
                local._taskManager = Object.assign({ isWorking: false, activeTask: null, searchTabId: null }, (defaultLocal && defaultLocal._taskManager) || {}, local._taskManager || {});
                local._notifications = Object.assign({ last_show_notification_hash: '', list: [] }, (defaultLocal && defaultLocal._notifications) || {}, local._notifications || {});
                if (!Array.isArray(local._notifications.list)) local._notifications.list = [];
                local.apifyQueue = Object.assign({}, (defaultLocal && defaultLocal.apifyQueue) || {}, local.apifyQueue || {});
                local.apifySettings = Object.assign({}, (defaultLocal && defaultLocal.apifySettings) || {}, local.apifySettings || {});
                if (!Array.isArray(local.collect)) local.collect = [];
                if (!Array.isArray(local.taskList)) local.taskList = [];
            /*
             * Always remove duplicate entries based on the unique cid field
             * before assigning the collection to the view model.  This keeps
             * the displayed record count consistent with the data grid,
             * avoiding discrepancies where the dashboard count lags behind
             * the true number of unique items.  Without deduplication here
             * stale or duplicate entries could persist in local.collect even
             * though the data grid (which is keyed by cid) only tracks
             * unique rows.
             */
            local.collect = dedupeDashboardRows(local.collect || []);
            const advertisedStoreCount = Math.max(0, parseInt(local.resultStoreCount, 10) || 0, parseInt((local.apifyQueue || {}).scrapedCount, 10) || 0);
            const qStatus = String((local.apifyQueue || {}).status || '').toLowerCase();
            const isClearedState = qStatus === 'idle' && advertisedStoreCount === 0 && (!local.collect || local.collect.length === 0) && !PocketLeadsRunState.isRunning(local);
            const sameRun = !isClearedState && ((local.apifyQueue || {}).runEventId === (($scope.local || {}).apifyQueue || {}).runEventId);
            if (isClearedState) {
                $scope._monotonicResultCount = 0;
                $scope._monotonicTaskCompleted = 0;
            }
            // Preserve live in-memory rows & email/social enrichments during the same session
            if ((sameRun || $scope.local && $scope.local.isScrapingEmail) && $scope.local && Array.isArray($scope.local.collect) && $scope.local.collect.length > 0 && !isClearedState) {
                const fullRows = $scope.local.collect.slice();
                const rowKey = row => String((row && (row.place_id || row.cid || row.map_link || row.phone || row.company_name || ((row.company_name || row.name || '') + '|' + (row.address || '')))) || '');
                const indexByKey = new Map();
                fullRows.forEach((row, idx) => indexByKey.set(rowKey(row), idx));
                (local.collect || []).forEach(row => {
                    const key = rowKey(row);
                    if (key && indexByKey.has(key)) fullRows[indexByKey.get(key)] = Object.assign({}, row, fullRows[indexByKey.get(key)]);
                    else { indexByKey.set(key, fullRows.length); fullRows.push(row); }
                });
                const maxKeep = ($scope.local && $scope.local.isScrapingEmail) ? Math.max(250, fullRows.length) : 250;
                local.collect = dedupeDashboardRows(fullRows).slice(-maxKeep);
                if ($scope.local && $scope.local.isScrapingEmail) local.isScrapingEmail = true;
            }
            const monotonicFloor = (sameRun && !isClearedState)
                ? Math.max(0, parseInt($scope._monotonicResultCount, 10) || 0, parseInt($scope.local && $scope.local.resultStoreCount, 10) || 0)
                : 0;
            const effectiveStoreCount = isClearedState
                ? 0
                : Math.max(advertisedStoreCount, monotonicFloor, Array.isArray(local.collect) ? local.collect.length : 0);
            local.resultStoreCount = effectiveStoreCount;
            local.collectIsPreview = effectiveStoreCount > (Array.isArray(local.collect) ? local.collect.length : 0);
            $scope._monotonicResultCount = effectiveStoreCount;
            if (effectiveStoreCount === 0 && !local.collectIsPreview) {
                local.collect = [];
                $scope.resultStoreHydrated = false;
            }
            $scope.$applyAsync(() => {
                if (readSerial < localAppliedSerial || generation !== $scope._canonicalGeneration) return;
                localAppliedSerial = readSerial;
                if (!sameRun) {
                    $scope._canonicalGeneration++;
                    $scope._pendingResultEdits.clear();
                    if ($scope._resultStoreSyncTimer) clearTimeout($scope._resultStoreSyncTimer);
                    $scope._resultStoreSyncTimer = null;
                    $scope.resultStoreHydrated = false;
                }
                // Do not log every storage event.  DevTools retains console
                // arguments, which can materially increase memory during long runs.
                $scope.local = local;
                // v92 completion watchdog: chrome.runtime terminal messages can be
                // dropped if the dashboard/service worker wakes at an awkward moment.
                // Persisted queue state is authoritative, so a completed transition
                // must still surface the dashboard Download + Close modal exactly once.
                try {
                    const terminalStatus = String(local && local.apifyQueue && local.apifyQueue.status || '').toLowerCase();
                    const terminalReady = /^(completed|completed_with_errors)$/.test(terminalStatus)
                        && !(local && (local.status || (local._taskManager && local._taskManager.isWorking)))
                        && !(local && local.apifyQueue && local.apifyQueue.resumeAvailable);
                    if (terminalReady && !$scope.scrapingCompleteShown && !$scope.waChecking && !$scope.suppressScrapingComplete) {
                        setTimeout(function(){
                            try {
                                if (!$scope.scrapingCompleteShown && typeof $scope.handleScrapingComplete === 'function') {
                                    $scope.handleScrapingComplete();
                                }
                            } catch (e) { console.warn('Completion watchdog failed', e); }
                        }, 0);
                    }
                } catch (e) {}
                refreshDashboardMetricCounts(local.collect || []);
                try {
                    const targetStoreCount = Math.max(0, parseInt(local.resultStoreCount, 10) || 0);
                    const expectedPreviewCount = Math.min(250, targetStoreCount);
                    if (expectedPreviewCount > (Array.isArray(local.collect) ? local.collect.length : 0) && typeof $scope.syncLiveCanonicalTable === 'function') {
                        $scope.syncLiveCanonicalTable(targetStoreCount);
                    }
                } catch (e) {}
                /*
                 * If the grid has not yet been created, build it once to
                 * initialise the data source.  Otherwise, avoid
                 * reinitialising the grid on every change to prevent the
                 * pager from resetting or the scroll position jumping.  When
                 * the grid already exists we push new items into the
                 * productsStore and update existing rows.  This keeps
                 * scrolling stable while scraping results are inserted.
                 */
                const nextCollectSignature = computeCollectUiSignature(local.collect || []);
                const collectChanged = nextCollectSignature !== lastCollectUiSignature;
                const deferHiddenMobileGrid = ($scope.viewMode === 'mobile' && !$scope.mobileDataDrawerOpen && PocketLeadsRunState.isRunning(local));
                if (!dataGrid && !deferHiddenMobileGrid) {
                    // Build from THIS already-merged snapshot. Re-reading storage here
                    // can race the live IndexedDB delta and create an empty/stale grid.
                    lastCollectDataCount = 0;
                    buildDataTable(local);
                    lastCollectUiSignature = nextCollectSignature;
                } else if (collectChanged && !deferHiddenMobileGrid) {
                    // Only touch the heavy DevExtreme grid when result rows actually changed.
                    // Progress updates now stay lightweight and render immediately.
                    let scrollTop = 0;
                    try {
                        const scrollable = dataGrid.getScrollable && dataGrid.getScrollable();
                        if (scrollable && typeof scrollable.scrollTop === 'function') scrollTop = scrollable.scrollTop();
                    } catch (err) {
                        console.warn('Unable to capture scroll position', err);
                    }
                    insertIntoDataTable(local);
                    updateDataTable(local);
                    try {
                        const scrollable2 = dataGrid.getScrollable && dataGrid.getScrollable();
                        if (scrollable2 && typeof scrollable2.scrollTo === 'function') scrollable2.scrollTo({ top: scrollTop });
                    } catch (err) {
                        console.warn('Unable to restore scroll position', err);
                    }
                    lastCollectDataCount = local.collect.length;
                    lastCollectUiSignature = nextCollectSignature;
                }

                // Always update the set of discovered phone numbers to ensure that
                // waTotal reflects the total number of unique phone numbers seen
                // during the current scraping session.  This update occurs
                // regardless of whether a WA run is active or pending.  When WA
                // progress is visible (either because waFinished > 0 or a run
                // has been started), the denominator will update in real time.
                try {
                    const rows = Array.isArray(local.collect) ? local.collect : [];
                    let newlyDiscovered = 0;
                    rows.forEach(row => {
                        const raw = row && row.phone ? String(row.phone).trim() : '';
                        if (!raw) return;
                        let digits = raw.replace(/\D/g, '');
                        digits = digits.replace(/^0+/, '');
                        if (!digits) return;
                        const cid = row.cid;
                        if (cid && !$scope.waDiscoveredIds[cid]) {
                            $scope.waDiscoveredIds[cid] = true;
                            newlyDiscovered++;
                        }
                    });
                    // Increment the total count by the number of newly discovered numbers.
                    // This count grows monotonically and will never decrease.  Even
                    // when WA is not active, we keep track of new numbers so that a
                    // subsequent run can resume from the correct denominator.
                    if (newlyDiscovered > 0) {
                        $scope.waTotal += newlyDiscovered;
                    }
                } catch (discErr) {
                    console.warn('onLocalChange: error updating discovered phone numbers', discErr);
                }

                // When a WhatsApp number check is active or pending completion,
                // identify newly discovered phone numbers that still need to be
                // processed in the current run.  New numbers will be either
                // appended to the existing WA queue or will trigger a new run
                // if the previous run has finished.  Note that we no longer
                // update waDiscoveredIds or waTotal inside this block; those
                // updates are performed above to ensure consistent totals even
                // when WA is not running.
                if (($scope.waChecking || $scope.waPendingComplete) && !$scope.waApiMode) {
                    try {
                        const rows = Array.isArray(local.collect) ? local.collect : [];
                        const newItems = [];
                        rows.forEach((row, idx) => {
                            const raw = row && row.phone ? String(row.phone).trim() : '';
                            if (!raw) return;
                            let digits = raw.replace(/\D/g, '');
                            digits = digits.replace(/^0+/, '');
                            if (!digits) return;
                            const cid = row.cid;
                            // Skip numbers already processed or currently enqueued
                            if ($scope.waCompletedIds[cid] || $scope.waEnqueuedIds[cid]) {
                                return;
                            }
                            newItems.push({ number: digits, rowId: idx });
                            // Mark the cid and row index as enqueued
                            if (cid) {
                                $scope.waEnqueuedIds[cid] = true;
                            }
                            $scope.waEnqueuedRows[idx] = true;
                        });
                        if (newItems.length > 0) {
                            if ($scope.waChecking) {
                                // A run is in progress; append the new numbers.
                                try {
                                    chrome.runtime.sendMessage({ action: 'append_wa_check', items: newItems }, function() {});
                                } catch (err) {
                                    console.warn('Failed to append WA numbers', err);
                                }
                            } else {
                                // A run completed earlier and we were waiting for new numbers.
                                // Start a new WA run now.  Preserve finished count, reset the
                                // pending flag and mark the new run as active.
                                $scope.waChecking = true;
                                $scope.waPendingComplete = false;
                                // Reset enqueued rows and repopulate them based on newItems.
                                $scope.waEnqueuedRows = {};

    // -----------------------------------------------------------------------
    // Country list for the dashboard selector
    //
    // Provide a comprehensive list of countries and territories that users can
    // select from when specifying the country for their Google Maps
    // queries.  The array below is derived from the ISO 3166 standard via
    // the pycountry library.  Each country name appears exactly as
    // recognised by international standards.  If additional entities are
    // required, they can be appended to this array.
    $scope.countries = [
        "Aruba", "Afghanistan", "Angola", "Anguilla", "Åland Islands", "Albania", "Andorra", "United Arab Emirates", "Argentina",
        "Armenia", "American Samoa", "Antarctica", "French Southern Territories", "Antigua and Barbuda", "Australia", "Austria",
        "Azerbaijan", "Burundi", "Belgium", "Benin", "Bonaire, Sint Eustatius and Saba", "Burkina Faso", "Bangladesh", "Bulgaria",
        "Bahrain", "Bahamas", "Bosnia and Herzegovina", "Saint Barthélemy", "Belarus", "Belize", "Bermuda",
        "Bolivia, Plurinational State of", "Brazil", "Barbados", "Brunei Darussalam", "Bhutan", "Bouvet Island", "Botswana",
        "Central African Republic", "Canada", "Cocos (Keeling) Islands", "Switzerland", "Chile", "China", "Côte d'Ivoire",
        "Cameroon", "Congo, The Democratic Republic of the", "Congo", "Cook Islands", "Colombia", "Comoros", "Cabo Verde",
        "Costa Rica", "Cuba", "Curaçao", "Christmas Island", "Cayman Islands", "Cyprus", "Czechia", "Germany", "Djibouti",
        "Dominica", "Denmark", "Dominican Republic", "Algeria", "Ecuador", "Egypt", "Eritrea", "Western Sahara", "Spain",
        "Estonia", "Ethiopia", "Finland", "Fiji", "Falkland Islands (Malvinas)", "France", "Faroe Islands",
        "Micronesia, Federated States of", "Gabon", "United Kingdom", "Georgia", "Guernsey", "Ghana", "Gibraltar", "Guinea",
        "Guadeloupe", "Gambia", "Guinea-Bissau", "Equatorial Guinea", "Greece", "Grenada", "Greenland", "Guatemala",
        "French Guiana", "Guam", "Guyana", "Hong Kong", "Heard Island and McDonald Islands", "Honduras", "Croatia", "Haiti",
        "Hungary", "Indonesia", "Isle of Man", "India", "British Indian Ocean Territory", "Ireland", "Iran, Islamic Republic of",
        "Iraq", "Iceland", "Israel", "Italy", "Jamaica", "Jersey", "Jordan", "Japan", "Kazakhstan", "Kenya", "Kyrgyzstan",
        "Cambodia", "Kiribati", "Saint Kitts and Nevis", "Korea, Republic of", "Kuwait", "Lao People's Democratic Republic",
        "Lebanon", "Liberia", "Libya", "Saint Lucia", "Liechtenstein", "Sri Lanka", "Lesotho", "Lithuania", "Luxembourg",
        "Latvia", "Macao", "Saint Martin (French part)", "Morocco", "Monaco", "Moldova, Republic of", "Madagascar", "Maldives",
        "Mexico", "Marshall Islands", "North Macedonia", "Mali", "Malta", "Myanmar", "Montenegro", "Mongolia",
        "Northern Mariana Islands", "Mozambique", "Mauritania", "Montserrat", "Martinique", "Mauritius", "Malawi", "Malaysia",
        "Mayotte", "Namibia", "New Caledonia", "Niger", "Norfolk Island", "Nigeria", "Nicaragua", "Niue", "Netherlands",
        "Norway", "Nepal", "Nauru", "New Zealand", "Oman", "Pakistan", "Panama", "Pitcairn", "Peru", "Philippines", "Palau",
        "Papua New Guinea", "Poland", "Puerto Rico", "Korea, Democratic People's Republic of", "Portugal", "Paraguay",
        "Palestine, State of", "French Polynesia", "Qatar", "Réunion", "Romania", "Russian Federation", "Rwanda", "Saudi Arabia",
        "Sudan", "Senegal", "Singapore", "South Georgia and the South Sandwich Islands", "Saint Helena, Ascension and Tristan da Cunha",
        "Svalbard and Jan Mayen", "Solomon Islands", "Sierra Leone", "El Salvador", "San Marino", "Somalia",
        "Saint Pierre and Miquelon", "Serbia", "South Sudan", "Sao Tome and Principe", "Suriname", "Slovakia", "Slovenia",
        "Sweden", "Eswatini", "Sint Maarten (Dutch part)", "Seychelles", "Syrian Arab Republic", "Turks and Caicos Islands", "Chad",
        "Togo", "Thailand", "Tajikistan", "Tokelau", "Turkmenistan", "Timor-Leste", "Tonga", "Trinidad and Tobago", "Tunisia",
        "Türkiye", "Tuvalu", "Taiwan, Province of China", "Tanzania, United Republic of", "Uganda", "Ukraine",
        "United States Minor Outlying Islands", "Uruguay", "United States", "Uzbekistan", "Holy See (Vatican City State)",
        "Saint Vincent and the Grenadines", "Venezuela, Bolivarian Republic of", "Virgin Islands, British", "Virgin Islands, U.S.",
        "Viet Nam", "Vanuatu", "Wallis and Futuna", "Samoa", "Yemen", "South Africa", "Zambia", "Zimbabwe"
    ];

    // Expose the full countries list on the global window so that non‑Angular
    // scripts (e.g. DevExtreme SelectBox initialiser) can access it without
    // relying on scope traversal.  Without this assignment, the country
    // dropdown may appear empty because jQuery code cannot retrieve the
    // Angular scope before it initialises.
    if (typeof window !== 'undefined') {
        window.countryList = $scope.countries;
    }
                                $scope.waEnqueuedIds = {};
                                newItems.forEach(item => {
                                    const rowIdx = item.rowId;
                                    const row = rows[rowIdx];
                                    if (row && row.cid) {
                                        $scope.waEnqueuedIds[row.cid] = true;
                                    }
                                    $scope.waEnqueuedRows[rowIdx] = true;
                                });
                                try {
                                    chrome.runtime.sendMessage({ action: 'start_wa_check', items: newItems }, function() {});
                                } catch (startErr) {
                                    console.warn('Failed to start WA check for new items', startErr);
                                }
                            }
                        } else {
                            // No new items found.  If a WA run had finished and we were
                            // waiting for new numbers, and scraping has also finished,
                            // finalise the WA check now.  Without this, the WA
                            // completion popup may never appear when scraping ends
                            // without producing additional numbers.
                            if (!$scope.waChecking && $scope.waPendingComplete && !$scope.scrapingActive) {
                                $scope.waPendingComplete = false;
                                // Ensure finished count reflects the number of completed IDs.
                                $scope.waFinished = Object.keys($scope.waCompletedIds).length;
                                try {
                                    $scope.handleWaCheckComplete($scope.waFinished, $scope.waTotal);
                                } catch (completeErr) {
                                    console.warn('Error finalising WA check on local change', completeErr);
                                }
                            }
                        }
                    } catch (appendErr) {
                        console.warn('Error while processing WA numbers on local change', appendErr);
                    }
                }
                // Update scrapingActive based on the current status.  This
                // ensures WA logic accurately knows whether scraping is
                // ongoing or has finished after each local change.  Use
                // isScrapingActive() helper to compute the state.
                try {
                    if (typeof $scope.isScrapingActive === 'function') {
                        $scope.scrapingActive = !!$scope.isScrapingActive();
                    }
                } catch (stateErr) {
                    // ignore errors computing scraping state
                }
                // Update UI state based on current status
                if (typeof $scope.recalculateScrapingTimeText === 'function') $scope.recalculateScrapingTimeText();
                $scope.updateUIState();
            });
            });
        }, 55);
    });
    /* ----------------------------- On Local Change ---------------------------- */
    
    /* ------------------------------- Init Local ------------------------------- */
    $box.getLocal(local => {
        $scope.$apply(() => {
            // Ensure proper initialization with safe defaults.  Retrieve
            // the default model from $box (typically an empty object)
            // and merge it with any persisted values.  Provide an empty
            // object when local is undefined to avoid TypeErrors on
            // spreading undefined.
            const defaultLocal = $box.getDefaultLocalModel();
            const persisted = local || {};
            $scope.local = { ...defaultLocal, ...persisted };
            refreshDashboardMetricCounts($scope.local.collect || []);

            // Expose the currently selected country to the global window.  This allows
            // non‑Angular scripts (e.g. DevExtreme SelectBox initialiser) to
            // populate the SelectBox with the correct initial value when the
            // dashboard loads.  If undefined, default to an empty string.
            if (typeof window !== 'undefined') {
                window.localCountry = $scope.local && $scope.local.country ? $scope.local.country : '';
            }
            // Ensure notifications structure exists with a list array
            if (!$scope.local._notifications || !$scope.local._notifications.list) {
                $scope.local._notifications = { list: [] };
            }
            // Ensure the task manager object exists with sensible defaults
            if (!$scope.local._taskManager) {
                $scope.local._taskManager = { isWorking: false, activeTask: null, searchTabId: null };
            } else {
                if (typeof $scope.local._taskManager.isWorking !== 'boolean') {
                    $scope.local._taskManager.isWorking = false;
                }
                if (!('activeTask' in $scope.local._taskManager)) {
                    $scope.local._taskManager.activeTask = null;
                }
                if (!('searchTabId' in $scope.local._taskManager)) {
                    $scope.local._taskManager.searchTabId = null;
                }
            }

            // Apify direct dataset flow defaults. Persisted users may not have these
            // keys yet, so initialise them without disturbing existing values.
            $scope.local.fastMode = false;
            $scope.local.apifySettings = Object.assign({
                provider: 'sheet-managed',
                apiKeyRow: 0,
                apiUsageLimit: 0,
                autoPageMode: true,
                maxPagesPerSearch: 50,
                maxResultsPerSearch: 1000,
                countryFilter: 'India',
                countryCodeFilter: 'IN',
                enforceCountryFilter: true,
                streamResults: true
            }, $scope.local.apifySettings || {});
            $scope.local.country = String($scope.local.country || $scope.local.apifySettings.countryFilter || 'India').trim() || 'India';
            $scope.local.countryCode = dashboardCountryCode($scope.local.country);
            $scope.local.apifySettings.countryFilter = $scope.local.country;
            $scope.local.apifySettings.countryCodeFilter = $scope.local.countryCode;
            $scope.local.apifySettings.enforceCountryFilter = true;
            // Manual page selector removed: city/location searches run in auto-page mode
            // up to the safe internal cap, while pincode searches are capped to 3 pages.
            $scope.local.apifySettings.autoPageMode = true;
            $scope.local.apifySettings.maxPagesPerSearch = 50;
            $scope.local.apifySettings.maxResultsPerSearch = 1000;
            // Clean old locally-stored API credentials from previous builds.
            $scope.local.apifySettings.provider = 'sheet-managed';
            $scope.local.apifySettings.apiKeyRow = 0;
            $scope.local.apifySettings.apiUsageLimit = $scope.local.apifySettings.apiUsageLimit ?? 0;
            $scope.local.apifySettings.apiToken = '';
            $scope.local.apifySettings.actorId = '';
            $scope.local.apifyQueue = Object.assign({
                status: 'idle',
                statusMessage: '',
                provider: '',
                currentQuery: '',
                currentProfileUrl: '',
                totalPlaceIds: 0,
                totalApiResults: 0,
                totalTasks: 0,
                completedTasks: 0,
                apiTasksTotal: 0,
                apiTasksDone: 0,
                apiTasksFailed: 0,
                apiTasksSettled: 0,
                domTotal: 0,
                domProcessed: 0,
                domPending: 0,
                domRunning: 0,
                domSaved: 0,
                domFailed: 0,
                domSkipped: 0,
                apiSwitchCount: 0,
                scrapedCount: 0,
                failedCount: 0,
                filteredCount: 0,
                duplicateSkippedCount: 0,
                apiKeyRow: 0,
                apiUsageBefore: 0,
                apiUsageAfter: 0,
                apiUsageLimit: 0,
                pendingPlaceIds: [],
                skipped: [],
                processing: null,
                completed: [],
                failed: [],
                retryCount: {},
                placeIdQueue: [],
                resumeAvailable: false,
                producerDone: false,
                consumerDone: false,
                domConcurrency: 1,
                domSuccessStreak: 0,
                domSuccessRate: 0,
                domTransientErrors: 0,
                lastCheckpointAt: '',
                resultStoreCount: 0,
                managedTabIds: []
            }, $scope.local.apifyQueue || {});
            if (typeof $scope.local.showApifySettings === 'undefined') {
                $scope.local.showApifySettings = false;
            }
            $scope.local.showLimitModal = false;

            // Remove any duplicate rows from the collect array on load.  If
            // previous sessions stored duplicate entries, this ensures the
            // dashboard's result count reflects only unique records.
            $scope.local.collect = dedupeDashboardRows($scope.local.collect || []);
            $scope.local.collectIsPreview = !!$scope.local.collectIsPreview;
            // A full hydrated collection is authoritative. Never retain a
            // stale preview/queue count (for example 921) when the actual
            // unique rows available to the grid are 650.
            $scope.local.resultStoreCount = $scope.local.collectIsPreview
                ? Math.max(parseInt($scope.local.resultStoreCount, 10) || 0, $scope.local.collect.length)
                : $scope.local.collect.length;
            $scope.local.resultStoreMigrated = !!$scope.local.resultStoreMigrated;

            // Rebuild the data table on first load to ensure the grid row
            // count matches the deduplicated collection.  Without resetting
            // the last count here the previous session's duplicate rows may
            // linger in the grid, leading to inconsistent counts between
            // "RESULTS FOUND" and the grid's pager.
            lastCollectDataCount = 0;
            buildDataTable();

            // Preserve persisted background state when the dashboard is reopened.
            // Resetting status here made an active run appear idle and stopped live
            // progress until another storage event happened.
            if (!$scope.local._taskManager) {
                $scope.local._taskManager = { isWorking: false, activeTask: null, searchTabId: null };
            }
            $scope.updateUIState();
            setTimeout(() => {
                try { if (typeof $scope.hydrateResultsFromIndexedDB === 'function') $scope.hydrateResultsFromIndexedDB(0); } catch (e) {}
            }, 100);
        });
        
        /* Get the active tab URL*/
        // When retrieving the active tab, guard against undefined results.
        // On some mobile browsers (e.g. Kiwi on Android) the callback may
        // receive an empty array or an undefined tab.  Accessing tab.url
        // directly would throw a TypeError.  Instead, check for the
        // existence of the tab and url property and fall back to an
        // empty string when either is missing.
        $box.activeTab(tab => {
            $scope.$apply(() => {
                let url = '';
                try {
                    if (tab && typeof tab.url === 'string') {
                        url = tab.url;
                    }
                } catch (e) {
                    console.warn('Error reading active tab url', e);
                }
                $scope.local.activeTabUrl = url;
            });
        });
    });
    /* ------------------------------- Init Local ------------------------------- */
    
    // NEW: Function to update UI state based on scraping status
    $scope.updateUIState = () => {
        // Always recalculate progress metrics when updating UI state.  This
        // ensures the progress bar reflects the current number of tasks
        // completed and prevents stale progress values from persisting.
        $scope.updateProgress();

        const active = !!($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking));
        if (active) $scope.startLaunchPending = false;
        const queue = $scope.local.apifyQueue || {};
        const domAllProcessed = (parseInt(queue.domTotal, 10) || 0) > 0 && (parseInt(queue.domProcessed, 10) || 0) >= (parseInt(queue.domTotal, 10) || 0) && (parseInt(queue.domPending, 10) || 0) === 0 && (parseInt(queue.domRunning, 10) || 0) === 0;
        const hasPendingSearches = Array.isArray($scope.local.taskList) && $scope.local.taskList.length > 0;
        const hasPendingProfiles = !domAllProcessed && Array.isArray(queue.placeIdQueue) && queue.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
        const terminalStatus = /^(completed|completed_with_errors|dataset_saved|dataset_saved_with_errors|no_results|no_results_after_filter)$/i.test(String(queue.status || ''));
        const progressFinished = Number($scope.progressData && $scope.progressData.percent || 0) >= 100 || (domAllProcessed && !hasPendingSearches);
        const hasFinishedCleanly = !active && (terminalStatus || progressFinished) && !hasPendingProfiles && !hasPendingSearches;
        const queueErrorCode = String(queue.lastErrorCode || '').toUpperCase();
        const nonResumableCommercialStop = /LICENSE_(?:EXPIRED|CREDIT_EXHAUSTED|INACTIVE)|LICENCE_(?:EXPIRED|CREDIT_EXHAUSTED)|ALL_CREDITS_EXHAUSTED|PREFLIGHT_/i.test(queueErrorCode);
        const resumable = !nonResumableCommercialStop && !hasFinishedCleanly && !active && (!!queue.resumeAvailable || hasPendingProfiles || (hasPendingSearches && /^(stopped|failed|paused_recoverable|partial_results|memory_recovery)$/i.test(String(queue.status || ''))));
        const hasFreshInput = Array.isArray($scope.local.keywordList) && $scope.local.keywordList.length > 0;

        const launchPending = !!$scope.startLaunchPending;
        $scope.isStopEnabled = active;
        $scope.isStartEnabled = !active && !launchPending && (hasFreshInput || resumable) && $scope.licenseActive;
        $scope.startButtonText = launchPending ? "Starting…" : (active ? "Stop" : (resumable ? "Resume" : "Start"));
        $scope.resumeAvailable = resumable;
        if (hasFinishedCleanly) {
            queue.resumeAvailable = false;
            if (!terminalStatus && progressFinished) queue.status = 'completed';
            queue.statusMessage = queue.status === 'completed_with_errors' ? 'Scraping completed with some skipped or failed records.' : 'Scraping completed successfully.';
            if (!$scope.scrapingCompleteShown && !$scope.waChecking && !$scope.suppressScrapingComplete && ((parseInt(queue.scrapedCount, 10) || 0) > 0 || (parseInt(queue.domProcessed, 10) || 0) > 0 || /^completed/i.test(String(queue.status || '')))) {
                setTimeout(() => {
                    try {
                        if (!$scope.scrapingCompleteShown && typeof $scope.handleScrapingComplete === 'function') {
                            $scope.handleScrapingComplete();
                        }
                    } catch (_) {}
                }, 0);
            }
        }
        
        // Show/hide spinner only when there's a valid query and work
        // in progress.  This logic remains unchanged.
        $scope.showSpinner = !!($scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking)) &&
                            $scope.local.activeQuery && $scope.local.activeQuery !== " in ");
    };

    // ------------------------------------------------------------------------
    // Progress bar management
    // ------------------------------------------------------------------------
    /**
     * Holds the current progress metrics for the scrape.  The view binds to
     * this object rather than repeatedly invoking percentComplete() directly
     * from the template.  Updating a single object avoids unnecessary
     * recalculations during Angular's digest and ensures that the progress
     * bar always animates smoothly from 0% on the left to 100% on the right.
     * @type {{completed:number,total:number,percent:number}}
     */
    $scope.progressData = { completed: 0, total: 0, percent: 0 };

    /**
     * Recalculate the scraping progress based on the current keywords,
     * locations and remaining task list.  This function should be invoked
     * whenever the number of keywords or locations changes, or when tasks
     * are consumed by the scraper.  It updates `$scope.progressData` with
     * the completed count, total count and percent complete (rounded to an
     * integer).  When there are no tasks defined, all values are reset to
     * zero to avoid NaN widths in the progress bar.
     */
    $scope.updateProgress = function() {
        const local = $scope.local || {};
        const q = local.apifyQueue || {};
        const status = String(q.status || '').toLowerCase();
        const active = PocketLeadsRunState.isRunning(local);
        const terminal = /^(completed|completed_with_errors|failed)$/.test(status);
        const stopped = status === 'stopped';
        const listTotalKeywords = Array.isArray(local.keywordList) ? local.keywordList.length : 0;
        const listTotalLocations = Array.isArray(local.locationList) ? local.locationList.length : 0;
        const listTotal = listTotalKeywords && listTotalLocations ? (listTotalKeywords * listTotalLocations) : listTotalKeywords;
        const taskTotal = Math.max(0, parseInt(q.totalTasks || local.apifyTaskTotal || listTotal, 10) || 0);
        const rawCompleted = Math.max(0, Math.min(taskTotal || Number.MAX_SAFE_INTEGER, Math.max(parseInt(q.completedTasks, 10) || 0, parseInt(q.apiTasksSettled, 10) || 0)));
        const runId = String(q.runEventId || '');
        if (runId && $scope._monotonicProgressRunId !== runId) {
            $scope._monotonicProgressRunId = runId;
            $scope._monotonicTaskCompleted = rawCompleted;
        } else if (active || (rawCompleted > 0 && status !== 'idle' && status !== 'cleared')) {
            $scope._monotonicTaskCompleted = Math.max($scope._monotonicTaskCompleted || 0, rawCompleted);
        } else if (!active && rawCompleted === 0 && (status === 'idle' || status === 'cleared')) {
            $scope._monotonicTaskCompleted = 0;
        }
        const taskCompleted = Math.min(taskTotal || Number.MAX_SAFE_INTEGER, Math.max(rawCompleted, $scope._monotonicTaskCompleted || 0));
        const apiTotal = Math.max(0, parseInt(q.apiTasksTotal || taskTotal, 10) || 0);
        const apiDone = Math.max(0, parseInt(q.apiTasksDone, 10) || 0);
        const apiFailed = Math.max(0, parseInt(q.apiTasksFailed, 10) || 0);
        const apiSettled = Math.max(taskCompleted, Math.min(apiTotal || Number.MAX_SAFE_INTEGER, parseInt(q.apiTasksSettled, 10) || (apiDone + apiFailed)));
        const domTotal = Math.max(0, parseInt(q.domTotal, 10) || 0);
        const domProcessed = Math.max(0, Math.min(domTotal || Number.MAX_SAFE_INTEGER, parseInt(q.domProcessed, 10) || 0));
        const provider = String(q.provider || '').toLowerCase();
        const googleFlow = provider === 'googlemaps' || /google_/.test(status) || domTotal > 0;
        const hasSessionProgress = taskTotal > 0 || apiTotal > 0 || domTotal > 0 || (q.scrapedCount || 0) > 0 || active;
        if (!hasSessionProgress) {
            $scope.progressData = { completed: 0, total: 0, percent: 0, percentExact: 0, phase: 'Ready', detail: '' };
            return;
        }

        const currentTaskIdx = Math.max(0, Math.min(taskTotal || Number.MAX_SAFE_INTEGER, active && taskTotal > 0 ? Math.min(taskTotal, taskCompleted + 1) : taskCompleted));
        let completed = terminal ? taskTotal : taskCompleted;
        let total = taskTotal;
        let phase = 'Searches';
        let detail = taskTotal ? (completed + '/' + taskTotal + ' searches') : '';
        let percentExact = terminal ? 100 : (taskTotal > 0 ? (completed / taskTotal) * 100 : 0);

        if (googleFlow) {
            // Google flow has two real stages. API query collection is 15% of the
            // run and profile/DOM extraction is 85%. This keeps the bar moving for
            // a single keyword instead of waiting until the whole keyword finishes.
            const apiRatio = apiTotal ? Math.min(1, apiSettled / apiTotal) : (domTotal > 0 ? 1 : 0);
            const domRatio = domTotal ? Math.min(1, domProcessed / domTotal) : 0;
            const domStarted = domTotal > 0 || /google_dom|google_profile|dataset_saved/.test(status);
            percentExact = domStarted ? (15 * apiRatio + 85 * domRatio) : (15 * apiRatio);
            if (domStarted) {
                completed = domProcessed;
                total = domTotal;
                phase = 'Profiles';
                detail = domProcessed + '/' + domTotal + ' profiles';
            } else {
                completed = apiSettled;
                total = apiTotal;
                phase = 'API searches';
                detail = apiSettled + '/' + apiTotal + ' searches checked';
            }
        }

        if (terminal) percentExact = 100;
        if (stopped) percentExact = Math.min(99.9, percentExact);
        percentExact = Math.max(0, Math.min(100, percentExact));
        $scope.progressData = {
            completed: completed,
            completedSettled: taskCompleted,
            currentTaskIndex: currentTaskIdx,
            total: total,
            percent: Math.round(percentExact),
            percentExact: percentExact,
            phase: phase,
            detail: detail,
            apiCompleted: active && !googleFlow && apiTotal > 0 ? currentTaskIdx : apiSettled,
            apiTotal: apiTotal,
            domCompleted: domProcessed,
            domTotal: domTotal
        };
    };

    /**
     * Provide backward compatibility for templates that still reference
     * percentComplete().  Instead of recalculating progress on every call,
     * simply return the already computed progressData.  This function may be
     * removed in a future version when templates are fully updated to use
     * progressData instead.
     */
    $scope.percentComplete = () => {
        return $scope.progressData;
    };

    $scope.getKeywordsProgressText = function() {
        const p = $scope.progressData || { completed: 0, total: 0 };
        return (p.completed || 0) + '/' + (p.total || 0);
    };

    $scope.getScrapingProgressText = function() {
        const p = $scope.progressData || { percentExact: 0 };
        const value = Number.isFinite(p.percentExact) ? p.percentExact : (parseFloat(p.percent) || 0);
        return value.toFixed(1) + '%';
    };


    const API_LIVE_APPS_SCRIPT_URL = PocketLeadsConfig.endpoint;
    const API_LIVE_FIELD_MASK = 'places.id,nextPageToken';

    function createEmptyApiLiveResult() {
        return {
            provider: 'googlemaps',
            query: '',
            fieldMask: API_LIVE_FIELD_MASK,
            selectedPages: 0,
            effectivePages: 0,
            pagesDone: 0,
            uniqueCount: 0,
            duplicateCount: 0,
            returnedCount: 0,
            rawCount: 0,
            rows: [],
            pages: [],
            filterNotes: [],
            allPlaceIdsText: '',
            acceptedIdsText: '',
            mapsLinksText: '',
            pageBreakdownText: ''
        };
    }

    $scope.apiLive = {
        loading: false,
        visible: false,
        error: '',
        statusText: 'Ready',
        progress: 0,
        currentQuery: '',
        steps: [],
        result: createEmptyApiLiveResult()
    };

    function apiLiveTime() {
        try {
            const d = new Date();
            return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + ':' + String(d.getSeconds()).padStart(2, '0');
        } catch (err) { return ''; }
    }

    function apiLiveApply() {
        try { $scope.$applyAsync(); } catch (err) {}
    }

    function apiLiveStep(text) {
        $scope.apiLive.steps = Array.isArray($scope.apiLive.steps) ? $scope.apiLive.steps : [];
        $scope.apiLive.steps.push({ time: apiLiveTime(), text: String(text || '') });
        if ($scope.apiLive.steps.length > 120) $scope.apiLive.steps = $scope.apiLive.steps.slice(-120);
        apiLiveApply();
    }

    function apiLiveSetProgress(value, statusText) {
        const v = Math.max(0, Math.min(100, parseInt(value, 10) || 0));
        $scope.apiLive.progress = v;
        if (statusText) $scope.apiLive.statusText = statusText;
        apiLiveApply();
    }

    function apiLiveRefreshIdTexts(result) {
        try {
            const rows = Array.isArray(result && result.rows) ? result.rows : [];
            const pages = Array.isArray(result && result.pages) ? result.pages : [];
            result.allPlaceIdsText = rows.map((row, idx) => {
                return (idx + 1) + '. Page ' + row.page + ' | ' + row.status + ' | ' + row.placeId + '\n' + (row.mapsUrl || '') + (row.reason ? '\nFilter: ' + row.reason : '');
            }).join('\n\n');
            const accepted = rows.filter(row => row.status === 'Accepted');
            result.acceptedIdsText = accepted.map(row => row.placeId).join('\n');
            result.mapsLinksText = accepted.map(row => row.mapsUrl).filter(Boolean).join('\n');
            result.pageBreakdownText = pages.map(page => {
                return 'Page ' + page.page + ': API returned ' + page.returned + ', accepted ' + page.accepted + ', duplicate ' + page.duplicate + ', nextPageToken=' + (page.nextPageToken ? 'yes' : 'no');
            }).join('\n');
        } catch (err) {}
    }

    $scope.copyApiLiveText = async function(kind) {
        try {
            const result = ($scope.apiLive && $scope.apiLive.result) || {};
            const text = kind === 'links' ? (result.mapsLinksText || '') : kind === 'accepted' ? (result.acceptedIdsText || '') : (result.allPlaceIdsText || '');
            if (!text) {
                apiLiveStep('Nothing to copy yet. Run API Live Result first.');
                return;
            }
            if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText(text);
            } else {
                const ta = document.createElement('textarea');
                ta.value = text;
                ta.style.position = 'fixed';
                ta.style.left = '-9999px';
                document.body.appendChild(ta);
                ta.focus();
                ta.select();
                document.execCommand('copy');
                document.body.removeChild(ta);
            }
            apiLiveStep((kind === 'links' ? 'Maps profile links' : kind === 'accepted' ? 'Accepted Place IDs' : 'All Place ID rows') + ' copied.');
        } catch (err) {
            apiLiveStep('Copy failed: ' + (err && err.message ? err.message : err));
        }
    };

    function buildPreviewTaskFromInputs() {
        try {
            const keywordLines = String(($scope.local && $scope.local.keywordTextarea) || '').split('\n').map(x => x.trim()).filter(Boolean);
            const locationLines = String(($scope.local && $scope.local.locationTextarea) || '').split('\n').map(x => x.trim()).filter(Boolean);
            if (keywordLines.length && locationLines.length) {
                return { keyword: keywordLines[0], location: locationLines[0], query: (keywordLines[0] + ' in ' + locationLines[0]).replace(/\s+/g, ' ').trim() };
            }
            if (keywordLines.length) return { keyword: keywordLines[0], location: '', query: keywordLines[0] };
            const q = ($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.currentQuery) || '';
            return { keyword: q, location: '', query: q };
        } catch (err) {
            return { keyword: '', location: '', query: '' };
        }
    }

    function apiLiveNormalizeQuery(value) {
        return String(value || '').replace(/\s+/g, ' ').trim();
    }

    function apiLiveEnsureCountry(query, country) {
        const q = apiLiveNormalizeQuery(query);
        const c = apiLiveNormalizeQuery(country || 'India');
        if (!q || !c) return q;
        if (new RegExp('\\b' + c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i').test(q)) return q;
        return (q + ' in ' + c).replace(/\s+/g, ' ').trim();
    }

    function apiLiveIsPincode(text) {
        return /(^|\D)[1-9][0-9]{5}(\D|$)/.test(String(text || ''));
    }

    function apiLiveEffectivePages(meta, settings) {
        const selected = Math.max(1, Math.min(50, parseInt(($scope.local && ($scope.local.maxPagesPerSearch || $scope.local.pageLimit)) || (settings && settings.maxPagesPerSearch) || 50, 10) || 50));
        const isPincode = apiLiveIsPincode((meta && (meta.location || meta.query || meta.queryForApi)) || '');
        const effective = isPincode ? Math.min(selected, 3) : selected;
        return { selected, effective, isPincode };
    }

    function apiLiveMapsUrl(placeId) {
        const id = String(placeId || '').trim();
        return id ? ('https://www.google.com/maps/place/?q=place_id:' + encodeURIComponent(id)) : '';
    }

    function apiLiveGetStoredLicence() {
        return new Promise(resolve => {
            try {
                if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return resolve(null);
                chrome.storage.local.get('license', res => resolve(res && res.license ? res.license : null));
            } catch (err) { resolve(null); }
        });
    }

    async function apiLiveCallAppsScript(action, payload) {
        const body = Object.assign({ action }, payload || {});
        // v82.1: every operational backend call is bound to the activated
        // installation. The licence string by itself cannot use the secure proxy.
        if (body.key && !body.deviceId && !/^(activate|release|ping|status)$/i.test(String(action || ''))) {
            const licence = await apiLiveGetStoredLicence();
            const installationId = String(licence && licence.installationId || '').trim();
            if (!installationId) throw new Error('PocketLeads secure device binding requires one-time licence reactivation on this device.');
            body.deviceId = installationId;
        }
        const controller=new AbortController();
        const timer=setTimeout(()=>controller.abort(),65000);
        try {
        const response = await fetch(API_LIVE_APPS_SCRIPT_URL, {
            signal:controller.signal,
            method: 'POST',
            headers: { 'Content-Type': 'text/plain;charset=utf-8' },
            body: JSON.stringify(body)
        });
        let data = null;
        try { data = await response.json(); } catch (err) { data = null; }
        if (!response.ok || !data) throw new Error('Backend response failed for ' + action + '. Apps Script deployment check karo.');
        await PocketLeadsAccount.observe(data,body.key,body.deviceId);
        return data;
        } finally {clearTimeout(timer);}
    }

    async function apiLiveGetGoogleSettings() {
        const licence = await apiLiveGetStoredLicence();
        const key = licence && licence.key ? String(licence.key).trim() : '';
        if (!key) throw new Error('Please activate your licence first.');
        const data = await apiLiveCallAppsScript('getApiConfig', { key, provider: 'googlemaps', preferNext: false });
        if (!data || data.status !== 'ok') {
            if (data && data.status === 'credits_exhausted') throw new Error('Google Maps plan credit is exhausted. Upgrade your plan or contact samimn7890@gmail.com.');
            if (data && data.status === 'expired') throw new Error(`Licence expired${data.expiryDate ? ' on ' + data.expiryDate : ''}. Contact ${data.supportEmail || PocketLeadsConfig.supportEmail} to renew.`);
            if (data && data.status === 'no_api_key') throw new Error('Google Maps service is temporarily unavailable. Please try again later.');
            if (data && data.status === 'invalid' && !data.backend) throw new Error('Apps Script old version hai. ZIP ke apps_script_code.js ko paste karke new deployment karo.');
            throw new Error((data && data.message) || 'Google Maps API config nahi mila.');
        }
        if (data.secureProxy !== true || String(data.providerContract || '') !== 'sheet_authoritative_secure_proxy_v3') throw new Error('Secure backend v30 required. Deploy ZIP apps_script_code.js first.');
        if (String(data.provider || '').toLowerCase() !== 'googlemaps') throw new Error('Google Maps row active nahi hai. API Live Result only googlemaps provider ko test karta hai.');
        return {
            provider: 'googlemaps',
            apiToken: '',
            secureProxy: data.secureProxy === true,
            apiKeyRow: parseInt(data.keyRow, 10) || 0,
            usageCount: parseInt(data.usageCount, 10) || 0,
            usageLimit: Math.max(0, Number(data.usageLimit) || 0),
            maxPagesPerSearch: Math.max(1, Math.min(50, parseInt(($scope.local && ($scope.local.maxPagesPerSearch || $scope.local.pageLimit)) || 50, 10) || 50)),
            countryFilter: ($scope.local && $scope.local.country) || 'India'
        };
    }

    function apiLiveAssertIdsOnly() {
        const normalized = API_LIVE_FIELD_MASK.replace(/\s+/g, '');
        if (normalized !== 'places.id,nextPageToken') throw new Error('Cost guard blocked: only places.id,nextPageToken is allowed.');
        if (/displayName|formattedAddress|internationalPhoneNumber|nationalPhoneNumber|websiteUri|rating|userRatingCount|reviews|types|primaryType/i.test(normalized)) {
            throw new Error('Cost guard blocked paid Google Places fields.');
        }
    }

    async function apiLiveRequestPage(query, settings, pageToken) {
        apiLiveAssertIdsOnly();
        const body = { textQuery: apiLiveNormalizeQuery(query), pageSize: 20 };
        if (pageToken) body.pageToken = String(pageToken);
        const licence = await apiLiveGetStoredLicence();
        const key = licence && licence.key ? String(licence.key).trim() : '';
        if (!key) throw new Error('Please activate your licence first.');
        const proxied = await apiLiveCallAppsScript('providerProxy', {
            key, provider: 'googlemaps', keyRow: settings.apiKeyRow || 0, operation: 'textSearch', payload: { body }
        });
        if (!proxied || proxied.status !== 'ok') {
            const detail = proxied && (proxied.message || proxied.reason) || 'Secure Google Places proxy failed.';
            const err = new Error(proxied && proxied.status === 'credits_exhausted'
                ? 'Google Maps plan credit is exhausted. Upgrade your plan or contact samimn7890@gmail.com.'
                : (proxied && proxied.status === 'expired'
                    ? `Licence expired${proxied.expiryDate ? ' on ' + proxied.expiryDate : ''}. Contact ${proxied.supportEmail || PocketLeadsConfig.supportEmail} to renew.`
                    : ('Google Places API error: ' + detail)));
            err.status = parseInt(proxied && proxied.httpStatus, 10) || 0;
            throw err;
        }
        const payload = proxied.data || {};
        const places = Array.isArray(payload && payload.places) ? payload.places : [];
        const responseFields = Object.keys(payload || {});
        const items = places.map(function(place, index) {
            const fields = Object.keys(place || {});
            const id = place && place.id ? String(place.id).trim() : '';
            return {
                apiIndex: index + 1,
                placeId: id,
                fields,
                responseFields,
                raw: place
            };
        });
        return { payload, places, items, nextPageToken: String(payload && payload.nextPageToken || '') };
    }

    $scope.hideApiLiveResult = function() {
        setGoogleApiLiveDebug(false);
        $scope.apiLive.visible = false;
        $scope.apiLive.loading = false;
    };

    let apiLiveMonitorOverlay = null;
    let apiLiveMonitorState = null;
    function setGoogleApiLiveDebug(enabled) {
        try {
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage({ action: 'pl_set_google_live_debug', enabled: !!enabled }, function() {
                    try { void chrome.runtime.lastError; } catch (e) {}
                });
            }
        } catch (e) {}
    }


    function createApiIdMonitorModal(queryText) {
        try { document.getElementById('plApiIdMonitorOverlay')?.remove(); } catch (e) {}
        const overlay = document.createElement('div');
        apiLiveMonitorOverlay = overlay;
        overlay.id = 'plApiIdMonitorOverlay';
        overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(2,6,23,.78);display:flex;align-items:center;justify-content:center;padding:18px;font-family:Arial,Helvetica,sans-serif;';
        overlay.innerHTML = `
            <div style="width:min(1280px,98vw);max-height:94vh;background:#ffffff;border-radius:16px;box-shadow:0 24px 80px rgba(0,0,0,.45);display:flex;flex-direction:column;overflow:hidden;color:#0f172a;">
                <div style="padding:14px 16px;background:#0f172a;color:#fff;display:flex;align-items:center;justify-content:space-between;gap:12px;">
                    <div>
                        <div style="font-size:18px;font-weight:900;">Live API Place ID Result</div>
                        <div id="plApiIdMonitorQuery" style="font-size:12px;color:#cbd5e1;margin-top:3px;word-break:break-word;">${apiLiveEscapeHtml(queryText || '-')}</div>
                    </div>
                    <button id="plApiIdMonitorClose" type="button" style="border:none;background:#334155;color:#fff;border-radius:10px;width:36px;height:36px;font-size:24px;line-height:1;cursor:pointer;">×</button>
                </div>
                <div style="padding:12px 16px;border-bottom:1px solid #e2e8f0;display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;background:#f8fafc;">
                    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:9px;"><div style="font-size:10px;color:#64748b;text-transform:uppercase;font-weight:800;">Status</div><div id="plApiIdMonitorStatus" style="font-size:13px;font-weight:900;color:#0f172a;margin-top:3px;">Waiting live...</div></div>
                    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:9px;"><div style="font-size:10px;color:#64748b;text-transform:uppercase;font-weight:800;">API Rows</div><div id="plApiIdMonitorReturned" style="font-size:18px;font-weight:900;color:#0f172a;margin-top:3px;">0</div></div>
                    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:9px;"><div style="font-size:10px;color:#64748b;text-transform:uppercase;font-weight:800;">Unique IDs</div><div id="plApiIdMonitorUnique" style="font-size:18px;font-weight:900;color:#0f172a;margin-top:3px;">0</div></div>
                    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:9px;"><div style="font-size:10px;color:#64748b;text-transform:uppercase;font-weight:800;">Skipped</div><div id="plApiIdMonitorSkipped" style="font-size:18px;font-weight:900;color:#b45309;margin-top:3px;">0</div></div>
                    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:9px;"><div style="font-size:10px;color:#64748b;text-transform:uppercase;font-weight:800;">Saved</div><div id="plApiIdMonitorSaved" style="font-size:18px;font-weight:900;color:#15803d;margin-top:3px;">0</div></div>
                    <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:9px;"><div style="font-size:10px;color:#64748b;text-transform:uppercase;font-weight:800;">Pages</div><div id="plApiIdMonitorPages" style="font-size:18px;font-weight:900;color:#0f172a;margin-top:3px;">0</div></div>
                </div>
                <div style="padding:10px 16px;display:flex;gap:8px;align-items:center;justify-content:space-between;border-bottom:1px solid #e2e8f0;background:#fff;">
                    <div style="font-size:12px;color:#475569;line-height:1.35;">
                        Endpoint: <b>places:searchText</b> &nbsp;|&nbsp; FieldMask locked: <b>places.id,nextPageToken</b><br>
                        <span id="plApiIdMonitorRequest" style="font-family:monospace;color:#334155;">Waiting for request...</span>
                    </div>
                    <div style="display:flex;gap:8px;">
                        <button id="plApiIdCopyIds" type="button" style="border:none;background:#2563eb;color:#fff;border-radius:9px;padding:8px 10px;font-size:12px;font-weight:800;cursor:pointer;">Copy IDs</button>
                        <button id="plApiIdCopyAll" type="button" style="border:none;background:#0f172a;color:#fff;border-radius:9px;padding:8px 10px;font-size:12px;font-weight:800;cursor:pointer;">Copy All</button>
                        <button id="plApiIdClear" type="button" style="border:none;background:#64748b;color:#fff;border-radius:9px;padding:8px 10px;font-size:12px;font-weight:800;cursor:pointer;">Clear</button>
                    </div>
                </div>
                <div id="plApiIdMonitorError" style="display:none;margin:10px 16px 0;padding:10px;border-radius:10px;background:#fee2e2;color:#991b1b;border:1px solid #fecaca;font-size:13px;white-space:pre-wrap;"></div>
                <div style="padding:0 16px 16px;overflow:auto;">
                    <table style="width:100%;border-collapse:collapse;font-size:12px;margin-top:12px;">
                        <thead style="position:sticky;top:0;background:#e2e8f0;z-index:1;">
                            <tr>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;width:48px;">#</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;width:66px;">Page</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;width:86px;">Stage</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;">Place ID returned by API</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;width:140px;">Status</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;">Reason / Skip reason</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;width:120px;">API fields</th>
                                <th style="text-align:left;padding:8px;border:1px solid #cbd5e1;">Maps Link</th>
                            </tr>
                        </thead>
                        <tbody id="plApiIdMonitorRows">
                            <tr id="plApiIdEmptyRow"><td colspan="8" style="padding:18px;text-align:center;color:#64748b;border:1px solid #cbd5e1;">Popup open hai. API call hota hi Place IDs yahan live append honge...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>`;
        document.body.appendChild(overlay);
        setGoogleApiLiveDebug(true);
        const close = overlay.querySelector('#plApiIdMonitorClose');
        if (close) close.onclick = () => { setGoogleApiLiveDebug(false); overlay.remove(); if (apiLiveMonitorOverlay === overlay) apiLiveMonitorOverlay = null; };
        const clear = overlay.querySelector('#plApiIdClear');
        if (clear) clear.onclick = () => {
            if (apiLiveMonitorState) {
                apiLiveMonitorState.rows = [];
                apiLiveMonitorState.rowByPlace = {};
                apiLiveMonitorState.uniqueSet = new Set();
                apiLiveMonitorState.skipped = 0;
                apiLiveMonitorState.saved = 0;
                apiLiveMonitorState.pagesDone = 0;
                rebuildApiIdMonitorRows(overlay, apiLiveMonitorState);
                updateApiIdMonitorSummary(overlay, apiLiveMonitorState);
            }
        };
        return overlay;
    }

    function apiLiveEscapeHtml(value) {
        return String(value == null ? '' : value).replace(/[&<>'"]/g, function(ch) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[ch] || ch;
        });
    }

    function initApiLiveState(query) {
        apiLiveMonitorState = {
            query: query || '',
            status: 'Watching live API events...',
            rows: [],
            rowByPlace: {},
            uniqueSet: new Set(),
            pagesDone: 0,
            skipped: 0,
            saved: 0,
            error: '',
            lastRequest: ''
        };
        return apiLiveMonitorState;
    }

    function updateApiIdMonitorSummary(overlay, state) {
        if (!overlay || !state) return;
        const setText = (id, value) => { const el = overlay.querySelector('#' + id); if (el) el.textContent = String(value == null ? '' : value); };
        setText('plApiIdMonitorStatus', state.status || 'Running...');
        setText('plApiIdMonitorReturned', state.rows.filter(r => r.stage === 'API').length || 0);
        setText('plApiIdMonitorUnique', state.uniqueSet.size || 0);
        setText('plApiIdMonitorSkipped', state.skipped || 0);
        setText('plApiIdMonitorSaved', state.saved || 0);
        setText('plApiIdMonitorPages', state.pagesDone || 0);
        const q = overlay.querySelector('#plApiIdMonitorQuery');
        if (q && state.query) q.textContent = state.query;
        const req = overlay.querySelector('#plApiIdMonitorRequest');
        if (req && state.lastRequest) req.textContent = state.lastRequest;
        const err = overlay.querySelector('#plApiIdMonitorError');
        if (err) {
            if (state.error) { err.style.display = 'block'; err.textContent = state.error; }
            else { err.style.display = 'none'; err.textContent = ''; }
        }
        const copyIds = overlay.querySelector('#plApiIdCopyIds');
        const copyAll = overlay.querySelector('#plApiIdCopyAll');
        const idsText = Array.from(state.uniqueSet).join('\n');
        const allText = state.rows.map((r, i) => (i + 1) + '. Page ' + (r.page || '-') + ' | ' + (r.stage || '-') + ' | ' + (r.placeId || '-') + ' | ' + (r.status || '-') + ' | ' + (r.reason || '-') + ' | fields=' + (r.fields || '-') + ' | ' + (r.mapsUrl || '')).join('\n');
        if (copyIds) copyIds.onclick = () => apiLiveCopyPlainText(idsText);
        if (copyAll) copyAll.onclick = () => apiLiveCopyPlainText(allText);
    }

    function appendApiIdMonitorRow(overlay, row, state) {
        if (!overlay || !row) return;
        const tbody = overlay.querySelector('#plApiIdMonitorRows');
        if (!tbody) return;
        const empty = overlay.querySelector('#plApiIdEmptyRow');
        if (empty) empty.remove();
        const idx = state.rows.length;
        const bg = /skip|duplicate|filter|failed/i.test(row.status || row.reason || '') ? '#fff7ed' : (/saved/i.test(row.status || '') ? '#f0fdf4' : '#ffffff');
        const tr = document.createElement('tr');
        tr.setAttribute('data-place-id', row.placeId || '');
        tr.style.background = bg;
        tr.innerHTML =
            '<td style="padding:7px;border:1px solid #e2e8f0;font-weight:800;">' + idx + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;">' + apiLiveEscapeHtml(row.page || '-') + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;font-weight:800;">' + apiLiveEscapeHtml(row.stage || '-') + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;font-family:monospace;font-size:12px;word-break:break-all;">' + apiLiveEscapeHtml(row.placeId || '-') + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;">' + apiLiveEscapeHtml(row.status || '-') + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;min-width:220px;">' + apiLiveEscapeHtml(row.reason || '-') + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;font-family:monospace;">' + apiLiveEscapeHtml(row.fields || '-') + '</td>' +
            '<td style="padding:7px;border:1px solid #e2e8f0;word-break:break-all;">' + (row.mapsUrl ? '<a href="' + apiLiveEscapeHtml(row.mapsUrl) + '" target="_blank">Open</a>' : '-') + '</td>';
        tbody.appendChild(tr);
        try { tbody.parentElement.parentElement.scrollTop = tbody.parentElement.parentElement.scrollHeight; } catch (e) {}
    }

    function rebuildApiIdMonitorRows(overlay, state) {
        const tbody = overlay && overlay.querySelector('#plApiIdMonitorRows');
        if (!tbody) return;
        tbody.innerHTML = '<tr id="plApiIdEmptyRow"><td colspan="8" style="padding:18px;text-align:center;color:#64748b;border:1px solid #cbd5e1;">Popup open hai. API call hota hi Place IDs yahan live append honge...</td></tr>';
        (state.rows || []).forEach(row => appendApiIdMonitorRow(overlay, row, state));
    }

    function apiLiveHandleEvent(event) {
        if (!event || !apiLiveMonitorOverlay) return;
        const state = apiLiveMonitorState || initApiLiveState(event.query || '');
        if (event.query) state.query = event.query;
        if (event.type === 'session_start') {
            state.status = 'API started';
            state.lastRequest = 'POST places:searchText | textQuery=' + (event.query || '-') + ' | fieldMask=' + (event.fieldMask || API_LIVE_FIELD_MASK);
        } else if (event.type === 'page_request') {
            state.status = 'Calling page ' + (event.page || '-');
            state.lastRequest = 'POST places:searchText | body=' + JSON.stringify(event.requestBody || {});
        } else if (event.type === 'place_id') {
            const placeId = event.placeId || '';
            const status = event.status === 'accepted_for_dom' ? 'Accepted' : 'Skipped';
            const reason = event.reason || (event.duplicate ? 'Duplicate Place ID' : '-');
            if (placeId && !event.duplicate && event.status !== 'skipped') state.uniqueSet.add(placeId);
            if (event.status === 'skipped' || event.duplicate) state.skipped += 1;
            const row = {
                page: event.page || '-',
                stage: 'API',
                placeId,
                status,
                reason,
                fields: (event.fieldsReturned || event.responseFields || []).join(', ') || 'id',
                mapsUrl: event.mapsUrl || (placeId ? apiLiveMapsUrl(placeId) : '')
            };
            state.rows.push(row);
            if (placeId) state.rowByPlace[placeId] = row;
            appendApiIdMonitorRow(apiLiveMonitorOverlay, row, state);
        } else if (event.type === 'page_done') {
            state.pagesDone = Math.max(state.pagesDone || 0, event.page || 0);
            state.status = event.message || ('Page ' + event.page + ' done');
        } else if (event.type === 'place_status') {
            const placeId = event.placeId || '';
            if (/skip|filter|failed/i.test(event.status || event.reason || '')) state.skipped += 1;
            if (/saved/i.test(event.status || '')) state.saved += 1;
            const row = {
                page: event.processed || '-',
                stage: String(event.stage || 'DOM').toUpperCase(),
                placeId,
                status: event.status || '-',
                reason: event.reason || '-',
                fields: 'DOM',
                mapsUrl: event.mapsUrl || (placeId ? apiLiveMapsUrl(placeId) : '')
            };
            state.rows.push(row);
            appendApiIdMonitorRow(apiLiveMonitorOverlay, row, state);
            state.status = event.reason || event.status || state.status;
        } else if (event.type === 'session_api_done') {
            state.status = event.message || 'API IDs complete';
        }
        updateApiIdMonitorSummary(apiLiveMonitorOverlay, state);
    }

    try {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage && !window.__plGoogleApiLiveListenerAdded) {
            window.__plGoogleApiLiveListenerAdded = true;
            chrome.runtime.onMessage.addListener(function(msg) {
                try {
                    if (msg && msg.action === 'pl_google_api_live_event') apiLiveHandleEvent(msg.payload || {});
                } catch (e) {}
            });
        }
    } catch (e) {}

    async function apiLiveCopyPlainText(text) {
        try {
            text = String(text || '');
            if (!text) return;
            if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(text);
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.left = '-9999px';
            document.body.appendChild(ta);
            ta.focus();
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
        } catch (err) {}
    }

    $scope.showApiLiveResult = async function() {
        const task = buildPreviewTaskFromInputs();
        const overlay = createApiIdMonitorModal(task.query || ($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.currentQuery) || '');
        const liveState = initApiLiveState(task.query || '');
        updateApiIdMonitorSummary(overlay, liveState);

        $scope.apiLive.loading = true;
        $scope.apiLive.visible = false; // simple DOM popup only
        apiLiveApply();

        const queue = ($scope.local && $scope.local.apifyQueue) || {};
        const isMainScrapingRunning = !!($scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking) || /starting|searching|streaming|scraping|google_|apify|serper|scrappa/i.test(String(queue.status || ''))));

        if (isMainScrapingRunning) {
            liveState.status = 'Watching current extraction live...';
            liveState.query = queue.currentQuery || task.query || liveState.query;
            liveState.lastRequest = 'Normal Start Extracting flow chal raha hai. API events yahan live append honge.';
            updateApiIdMonitorSummary(overlay, liveState);
            $scope.apiLive.loading = false;
            apiLiveApply();
            return;
        }

        if (!task.query) {
            liveState.status = 'Input needed';
            liveState.error = 'Keyword/query blank hai. Example: clinic in kolkata';
            updateApiIdMonitorSummary(overlay, liveState);
            $scope.apiLive.loading = false;
            apiLiveApply();
            return;
        }

        try {
            liveState.status = 'Reading API key...';
            updateApiIdMonitorSummary(overlay, liveState);
            const settings = await apiLiveGetGoogleSettings();
            const country = settings.countryFilter || 'India';
            const queryForApi = apiLiveEnsureCountry(task.query, country);
            const meta = { keyword: task.keyword, location: task.location, query: task.query, queryForApi, country };
            const pagePlan = apiLiveEffectivePages(meta, settings);
            liveState.query = queryForApi;
            liveState.status = 'Calling Places API...';
            liveState.lastRequest = 'POST places:searchText | textQuery=' + queryForApi + ' | fieldMask=' + API_LIVE_FIELD_MASK;
            updateApiIdMonitorSummary(overlay, liveState);

            let nextPageToken = '';
            for (let page = 1; page <= pagePlan.effective; page += 1) {
                liveState.status = 'Calling page ' + page + '/' + pagePlan.effective + '...';
                liveState.lastRequest = 'POST places:searchText | body=' + JSON.stringify({ textQuery: queryForApi, pageSize: 20, pageToken: nextPageToken ? '[nextPageToken]' : '' });
                updateApiIdMonitorSummary(overlay, liveState);

                const pageResult = await apiLiveRequestPage(queryForApi, settings, nextPageToken);
                liveState.pagesDone = page;
                const items = pageResult.items || [];
                for (let i = 0; i < items.length; i += 1) {
                    const item = items[i];
                    const placeId = item.placeId || '';
                    const key = placeId.toLowerCase();
                    let status = 'Accepted';
                    let reason = 'Accepted: API se Place ID return hua.';
                    let duplicate = false;
                    if (!key) {
                        status = 'Skipped';
                        reason = 'Skipped: API response me Place ID missing hai.';
                        liveState.skipped += 1;
                    } else if (liveState.uniqueSet.has(placeId)) {
                        status = 'Skipped';
                        reason = 'Skipped: duplicate Place ID from API.';
                        liveState.skipped += 1;
                        duplicate = true;
                    } else {
                        liveState.uniqueSet.add(placeId);
                    }
                    const row = {
                        page,
                        stage: 'API',
                        placeId,
                        status,
                        reason,
                        fields: (item.fields || item.responseFields || []).join(', ') || 'id',
                        mapsUrl: item.mapsUrl || (placeId ? apiLiveMapsUrl(placeId) : '')
                    };
                    liveState.rows.push(row);
                    if (placeId) liveState.rowByPlace[placeId] = row;
                    appendApiIdMonitorRow(overlay, row, liveState);
                    liveState.status = 'Live: page ' + page + ' row ' + (i + 1) + '/' + items.length;
                    updateApiIdMonitorSummary(overlay, liveState);
                    await new Promise(resolve => setTimeout(resolve, 0));
                }

                liveState.status = 'Page ' + page + ' returned ' + items.length + ' row(s)';
                updateApiIdMonitorSummary(overlay, liveState);
                if (!pageResult.nextPageToken) break;
                nextPageToken = pageResult.nextPageToken;
                if (page < pagePlan.effective) await new Promise(resolve => setTimeout(resolve, 250));
            }
            liveState.status = 'Completed: API returned ' + liveState.rows.filter(r => r.stage === 'API').length + ' row(s), unique ' + liveState.uniqueSet.size;
            updateApiIdMonitorSummary(overlay, liveState);
        } catch (err) {
            liveState.status = 'Error';
            liveState.error = err && err.message ? err.message : String(err || 'API Live Result failed');
            updateApiIdMonitorSummary(overlay, liveState);
        }

        $scope.apiLive.loading = false;
        apiLiveApply();
    };
    
    // Zero-overhead Live Spy & Diagnostic Telemetry state
    $scope.liveSpy = {
        open: true,
        filter: 'all',
        events: [],
        snapshot: {}
    };
    let liveSpyFlushTimer = null;
    const pendingSpyEvents = [];

    function scheduleLiveSpyUiFlush() {
        if (liveSpyFlushTimer) return;
        liveSpyFlushTimer = setTimeout(() => {
            liveSpyFlushTimer = null;
            if (!pendingSpyEvents.length) return;
            const batch = pendingSpyEvents.splice(0, pendingSpyEvents.length);
            const merged = [...($scope.liveSpy.events || []), ...batch].slice(-120);
            $scope.liveSpy.events = merged;
            if ($scope.showDiagnostics) {
                try { $scope.$applyAsync(); } catch (_) {}
            }
        }, 220);
    }

    try {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage && !window.__plLiveSpyListenerAdded) {
            window.__plLiveSpyListenerAdded = true;
            chrome.runtime.onMessage.addListener(function(msg) {
                try {
                    if (msg && msg.action === 'PL_LIVE_SPY_EVENT') {
                        if (msg.snapshot) $scope.liveSpy.snapshot = msg.snapshot;
                        if (msg.event) {
                            pendingSpyEvents.push(msg.event);
                            scheduleLiveSpyUiFlush();
                        }
                    }
                } catch (_) {}
            });
        }
    } catch (_) {}

    $scope.getLiveSpyEvents = function() {
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const fromQueue = Array.isArray(q.liveSpyEvents) ? q.liveSpyEvents : [];
        const fromLive = Array.isArray($scope.liveSpy && $scope.liveSpy.events) ? $scope.liveSpy.events : [];
        const byId = new Map();
        [...fromQueue, ...fromLive].forEach(ev => {
            if (ev && ev.id) byId.set(ev.id, ev);
        });
        const all = Array.from(byId.values()).slice(-100).reverse();
        const mode = String($scope.liveSpy && $scope.liveSpy.filter || 'all');
        if (mode === 'errors') {
            return all.filter(ev => ev.level === 'error' || ev.level === 'warn' || /ERROR|FAIL|SKIP|EMPTY/i.test(ev.type || ''));
        }
        if (mode === 'skips') {
            return all.filter(ev => (ev.skippedCount || 0) > 0 || /SKIP|FILTER|EMPTY/i.test(ev.type || ''));
        }
        return all;
    };

    $scope.clearLiveSpyEvents = function() {
        $scope.liveSpy.events = [];
        if ($scope.local && $scope.local.apifyQueue) {
            $scope.local.apifyQueue.liveSpyEvents = [];
        }
    };

    $scope.copyLiveSpyLog = function() {
        const events = $scope.getLiveSpyEvents().slice().reverse();
        const lines = events.map(ev => `[${ev.time || ev.iso || ''}] [${ev.type || 'INFO'}] ${ev.taskIndex ? '(' + ev.taskIndex + '/' + (ev.totalTasks || '?') + ') ' : ''}${ev.message || ''}`);
        apiLiveCopyPlainText(lines.join('\n') || 'No live spy events recorded yet.');
        try { $scope.snackbar && $scope.snackbar.show && $scope.snackbar.show('Copied ' + lines.length + ' Live Spy event(s).'); } catch (_) {}
    };

    $scope.exportSkippedReport = async function() {
        try {
            const collected = [];
            const seen = new Set();
            function addRow(r, source) {
                if (!r || typeof r !== 'object') return;
                const status = String(r.status || r.stageStatus || r.resultStatus || '').trim();
                const reason = String(r.reason || r.skipReason || r.error || r.message || r.filterReason || '').trim();
                const placeId = r.placeId || r.place_id || r.id || '';
                const cid = r.cid || '';
                const company = r.companyName || r.company_name || r.name || r.category || '';
                const addr = r.address || r.full_address || '';
                const key = [source || r.source || '', placeId, cid, company, addr, r.query || '', r.keyword || '', r.location || '', status, reason].join('|');
                if (seen.has(key)) return;
                const text = (status + ' ' + reason).toLowerCase();
                const isSkipped = /skip|fail|filter|duplicate|timeout|missing|blocked|error|invalid|no result|not found|all_skipped|no_results/.test(text);
                if (!isSkipped) return;
                seen.add(key);
                collected.push({
                    source: r.source || source || '',
                    placeId,
                    query: r.query || r.textQuery || '',
                    keyword: r.keyword || '',
                    location: r.location || '',
                    status: status || 'Skipped',
                    skipReason: reason || (status ? 'Skipped by status: ' + status : 'No detailed reason saved'),
                    category: company || r.category || '',
                    address: addr,
                    mapsUrl: r.mapsUrl || r.map_link || (placeId ? apiLiveMapsUrl(placeId) : ''),
                    updatedAt: r.lastUpdatedAt || r.createdAt || r.updatedAt || r.time || r.iso || ''
                });
            }
            const storedExtra = await new Promise(resolve => {
                try {
                    chrome.storage.local.get(['plSessionSkippedRecords', 'apifyQueue'], res => resolve(res || {}));
                } catch (_) { resolve({}); }
            });
            const q = Object.assign({}, ($scope.local && $scope.local.apifyQueue) || {}, (storedExtra && storedExtra.apifyQueue) || {});
            if (Array.isArray(storedExtra.plSessionSkippedRecords)) {
                storedExtra.plSessionSkippedRecords.forEach(r => addRow(r, r && r.source ? r.source : 'SessionSkipped'));
            }
            ['placeIdQueue','skipped','failed','filtered','items','logs','events'].forEach(name => {
                const arr = Array.isArray(q[name]) ? q[name] : [];
                arr.forEach(r => addRow(r, (r && r.source) || ('Queue:' + name)));
            });
            if (q.pincodeStatuses && typeof q.pincodeStatuses === 'object') {
                Object.values(q.pincodeStatuses).forEach(st => {
                    if (st && (/fail|no_results|all_skipped/i.test(st.status || '') || (st.failed || 0) > 0 || (st.error))) {
                        addRow({
                            source: 'LocationStatus',
                            query: st.query || '',
                            keyword: st.keyword || '',
                            location: st.location || st.key || '',
                            status: st.status || 'Skipped',
                            reason: st.error || `Location status: ${st.status} (API rows: ${st.apiIds || 0}, Saved: ${st.saved || 0}, Skipped: ${st.skipped || 0})`,
                            companyName: st.location || st.query || '',
                            lastUpdatedAt: st.lastUpdatedAt || ''
                        }, 'LocationStatus');
                    }
                });
            }
            const spyEvents = $scope.getLiveSpyEvents ? $scope.getLiveSpyEvents() : [];
            spyEvents.forEach(ev => {
                if (ev && (ev.level === 'error' || ev.level === 'warn')) {
                    addRow({
                        source: 'LiveSpy:' + (ev.type || 'EVENT'),
                        query: ev.query || '',
                        keyword: ev.keyword || '',
                        location: ev.location || '',
                        status: ev.type || 'Diagnostic',
                        reason: ev.message || '',
                        companyName: ev.provider || '',
                        lastUpdatedAt: ev.iso || ev.time || ''
                    }, 'LiveSpy');
                }
            });
            if (apiLiveMonitorState && Array.isArray(apiLiveMonitorState.rows)) apiLiveMonitorState.rows.forEach(r => addRow(r, 'API Live Monitor'));
            if ($scope.apiLive && $scope.apiLive.result && Array.isArray($scope.apiLive.result.rows)) $scope.apiLive.result.rows.forEach(r => addRow(r, 'API ID Live'));
            const headers = ['Source','Place ID','Query','Keyword','Location','Status','Skip Reason','Category/Company','Address','Maps URL','Updated At'];
            function csv(v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; }
            const csvRows = [headers.map(csv).join(',')];
            collected.forEach(r => {
                csvRows.push([
                    r.source, r.placeId, r.query, r.keyword, r.location, r.status, r.skipReason,
                    r.category, r.address, r.mapsUrl, r.updatedAt
                ].map(csv).join(','));
            });
            if (!collected.length) {
                csvRows.push(['No skipped/failed records found','','','','','','Current session did not save any skip reason records.','','','',''].map(csv).join(','));
            }
            const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'PocketLeads_Skipped_With_Reasons_' + new Date().toISOString().slice(0,19).replace(/[:T]/g,'-') + '.csv';
            document.body.appendChild(a);
            a.click();
            setTimeout(() => { try { URL.revokeObjectURL(url); a.remove(); } catch (e) {} }, 1000);
            try { $scope.snackbar.show('Skipped report exported: ' + collected.length + ' row(s).'); } catch (e) {}
        } catch (err) {
            try { $scope.snackbar && $scope.snackbar.show && $scope.snackbar.show('Export failed: ' + (err && err.message ? err.message : err)); } catch (e) {}
        }
    };

    /*	Toggle Tab*/
    $scope.toggleTab = tab => {
        $scope.local.activeTab = tab;
        $scope.saveLocal();
        $scope.initiMaterialDesignComponents();
    };
    
    $scope.resultStoreHydrated = false;
    $scope._canonicalGeneration = 0;
    $scope._pendingResultEdits = new Map();
    $scope._resultStoreSyncTimer = null;
    $scope._liveCanonicalSyncTimer = null;
    $scope._liveCanonicalSyncInFlight = false;
    $scope._liveCanonicalSyncTarget = 0;
    $scope._canonicalWatchdogBusy = false;

    // Reconcile the visible dashboard with IndexedDB, including idle/reopened
    // dashboards whose last runtime delta or storage notification was missed.
    $scope._canonicalWatchdogTimer = setInterval(async () => {
        try {
            const local = $scope.local || {};
            const queue = local.apifyQueue || {};
            const status = String(queue.status || '').toLowerCase();
            const active = PocketLeadsRunState.isRunning(local)
                || /starting|searching|streaming|google_pipeline|dataset_saved|switching_key|resuming/.test(status);
            if (document.hidden || $scope._canonicalWatchdogBusy) return;
            $scope._canonicalWatchdogBusy = true;
            const count = await getCanonicalStoreCount();
            const visible = Array.isArray(local.collect) ? local.collect.length : 0;
            const needHydrate = !$scope.resultStoreHydrated || (count > 0 && visible < Math.min(250, count) && !active) || !!$scope.resultStoreError;
            if (count !== Number(local.resultStoreCount) || needHydrate) {
                $scope.$evalAsync(() => {
                    if (!$scope.local) return;
                    const bestCount = active
                        ? Math.max(parseInt($scope._monotonicResultCount, 10) || 0, parseInt($scope.local.resultStoreCount, 10) || 0, count)
                        : (count > 0 ? Math.max(parseInt($scope._monotonicResultCount, 10) || 0, count) : 0);
                    $scope._monotonicResultCount = bestCount;
                    $scope.local.resultStoreCount = bestCount;
                    $scope.local.collectIsPreview = bestCount > visible;
                    if (needHydrate && typeof $scope.syncLiveCanonicalTable === 'function') {
                        $scope.syncLiveCanonicalTable(bestCount);
                    }
                });
            }
        } catch (e) {
            // The next interval is enough; never interrupt scraping for a UI check.
        } finally {
            $scope._canonicalWatchdogBusy = false;
        }
    }, 1500);
    $scope.$on('$destroy', function(){
        try { if ($scope._canonicalWatchdogTimer) clearInterval($scope._canonicalWatchdogTimer); } catch (e) {}
        try { if ($scope._liveCanonicalSyncTimer) clearTimeout($scope._liveCanonicalSyncTimer); } catch (e) {}
    });

    // v87 safety net for any missed realtime delta. This only hydrates when the
    // server/queue says IndexedDB contains MORE rows than the table currently has,
    // so it does not repeatedly reload a healthy live grid.
    $scope.syncLiveCanonicalTable = function() {
        if ($scope._liveCanonicalSyncInFlight) { $scope._canonicalReloadPending = true; return; }
        if ($scope._liveCanonicalSyncTimer) return;
        $scope._liveCanonicalSyncTimer = setTimeout(() => {
            $scope._liveCanonicalSyncTimer = null;
            $scope.hydrateResultsFromIndexedDB();
        }, 30);
    };
    $scope.hydrateResultsFromIndexedDB = async function() {
        if ($scope._liveCanonicalSyncInFlight) { $scope._canonicalReloadPending = true; return; }
        $scope._liveCanonicalSyncInFlight = true;
        const runId = $scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.runEventId;
        const generation = $scope._canonicalGeneration;
        try {
            const result = await runtimeMessageAsync({action:'result_store_query',query:{offset:0,limit:250}});
            if (!result || result.ok === false || !Array.isArray(result.rows) || !Number.isFinite(result.count)) throw Error('Canonical results unavailable');
            $scope.$evalAsync(() => {
                const latestRunId = $scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.runEventId;
                if (!$scope.local || (runId && latestRunId && runId !== latestRunId)) return;
                if (generation !== $scope._canonicalGeneration) return;
                const isRunningNow = PocketLeadsRunState.isRunning($scope.local);
                const bestTotal = isRunningNow
                    ? Math.max(parseInt($scope._monotonicResultCount, 10) || 0, parseInt($scope.local.resultStoreCount, 10) || 0, result.count, result.rows.length)
                    : Math.max(result.count, result.rows.length);
                $scope._monotonicResultCount = bestTotal;
                $scope.local.collect = result.rows;
                $scope.local.collectIsPreview = bestTotal > result.rows.length;
                $scope.local.resultStoreCount = bestTotal;
                $scope.resultStoreHydrated = true;
                $scope.resultStoreError = '';
                buildDataTable($scope.local);
            });
        } catch (e) { $scope.$evalAsync(() => { $scope.resultStoreError = 'Saved results unavailable. Retrying…'; }); }
        finally {
            $scope._liveCanonicalSyncInFlight = false;
            if ($scope._canonicalReloadPending) { $scope._canonicalReloadPending = false; $scope.syncLiveCanonicalTable(); }
        }
    };

    $scope.saveLocal = function(onSaved) {
        const rows = Array.isArray($scope.local && $scope.local.collect) ? $scope.local.collect : [];
        const currentSignature = computeCollectUiSignature(rows);
        // Results are canonical in IndexedDB. Only send rows whose content
        // actually changed; progress/settings saves must never re-send the full
        // hydrated dataset.
        if (currentSignature !== $scope._lastResultStoreSyncSignature) {
            try {
                if (!($scope._resultStoreRowHashes instanceof Map)) $scope._resultStoreRowHashes = new Map();
                const changedRows = [];
                rows.forEach((row, idx) => {
                    const key = String((row && (row.place_id || row.cid || row.map_link || row.phone || row.company_name)) || ('row_' + idx));
                    let hash = '';
                    try { hash = JSON.stringify(row || {}); } catch (e) { hash = String(row); }
                    if ($scope._resultStoreRowHashes.get(key) !== hash) {
                        $scope._resultStoreRowHashes.set(key, hash);
                        changedRows.push(row);
                    }
                });
                changedRows.forEach(row => $scope._pendingResultEdits.set(String(row.place_id || row.cid || row.map_link || row.phone || row.company_name), row));
                if (!$scope._resultStoreSyncTimer && $scope._pendingResultEdits.size) {
                    const generation = $scope._canonicalGeneration;
                    const runId = $scope.local.apifyQueue && $scope.local.apifyQueue.runEventId;
                    $scope._resultStoreSyncTimer = setTimeout(async () => {
                        $scope._resultStoreSyncTimer = null;
                        const edits = [...$scope._pendingResultEdits.values()];
                        $scope._pendingResultEdits.clear();
                        for (let attempt = 0; attempt < 3; attempt++) {
                            if (generation !== $scope._canonicalGeneration) return;
                            try {
                                const response = await runtimeMessageAsync({action:'result_store_upsert',rows:edits,runId});
                                if (!response || !response.ok || !response.result) throw Error('Result update not saved');
                                $scope.$evalAsync(() => {if(generation===$scope._canonicalGeneration)$scope.local.resultStoreCount=response.result.total;});
                                return;
                            } catch(e) {
                                if(attempt===2){$scope._lastResultStoreSyncSignature='';$scope._resultStoreRowHashes.clear();$scope.$evalAsync(()=>{$scope.resultStoreError='Result edits could not be saved. Retry after reopening the dashboard.';});}
                                else await new Promise(resolve=>setTimeout(resolve,200*(attempt+1)));
                            }
                        }
                    }, 250);
                }
                $scope._lastResultStoreSyncSignature = currentSignature;
            } catch (e) {
                console.warn('Result-store incremental sync failed', e);
            }
        }
        const previewLimit = 250;
        const storageLocal = Object.assign({}, $scope.local, {
            collect: rows.slice(-previewLimit),
            collectIsPreview: Number($scope.local.resultStoreCount) > Math.min(rows.length, previewLimit),
            resultStoreCount: Math.max(0, Number($scope.local.resultStoreCount) || 0),
            resultStoreMigrated: true
        });
        $box.setLocal(storageLocal, {
            onSet: function() {
                if (typeof onSaved === 'function') {
                    try { onSaved(); } catch (e) { console.warn('saveLocal callback failed', e); }
                }
            }
        });
    };

    $scope.sendMessage = function(action, data = {}) {
        console.log("Message sent: " + action);
        $box.send(action, data);
    };
    
    /* URL List */
    $scope.saveAsList = (skipPersist)=>{
        const keywordText = $scope.local.keywordTextarea || '';
        const locationText = $scope.local.locationTextarea || '';
        const blackListText = $scope.local.blackListTextarea || '';
        $scope.local.keywordList = keywordText.split('\n').map(x => x.trim()).filter(x=>x.length);
        $scope.local.locationList = locationText.split('\n').map(x => x.trim()).filter(x=>x.length);
        $scope.local.blackList = blackListText.split('\n').map(x => x.trim()).filter(x=>x.length);
        // New version has only one Apify-controlled mode. Disable legacy fast-mode limits.
        $scope.local.fastMode = false;
        // Build a fresh task list every time inputs change. If Location is blank,
        // each keyword line is treated as a full search query like "clinic in kolkata".
        let collect = [];
        if ($scope.local.keywordList.length && $scope.local.locationList.length) {
            $scope.local.keywordList.forEach((keyword)=>{
                $scope.local.locationList.forEach((location)=>{
                    collect.push(`${keyword}~in~${location}`);
                });
            });
        } else if ($scope.local.keywordList.length) {
            collect = $scope.local.keywordList.slice();
        }
        $scope.local.taskList = collect;
        console.log('PocketLeads Apify taskList rebuilt:', $scope.local.taskList);
        if (!skipPersist) {
            $scope.saveLocal();
            // Update UI after saving the list. updateUIState will recalculate progress metrics.
            $scope.updateUIState();
        }
    };

    // --------------------------------------------------------------------
    // Enforce fast mode limits on keyword and location textareas in real time.
    //
    // When the user types or pastes more than 20 lines into either textarea
    // while fast mode is enabled, immediately truncate the extra lines and
    // surface a snackbar message.  This watcher runs within Angular's digest
    // cycle, so updating the model will propagate to the view automatically.
    $scope.$watch('local.locationTextarea', function(newVal, oldVal) {
        if ($scope.local.fastMode && newVal !== oldVal) {
            const lines = newVal ? newVal.split('\n') : [];
            const limit = 20;
            if (lines.length > limit) {
                // Truncate to the first 20 lines and update both the textarea and list.
                $scope.local.locationTextarea = lines.slice(0, limit).join('\n');
                $scope.local.locationList = $scope.local.locationTextarea.split('\n').filter(x => x.length);
                // Show the limit modal instead of a snackbar.  Persist the flag so
                // the modal remains visible until dismissed.
                $scope.local.showLimitModal = true;
                $scope.saveLocal();
            }
        }
    });
    $scope.$watch('local.keywordTextarea', function(newVal, oldVal) {
        if ($scope.local.fastMode && newVal !== oldVal) {
            const lines = newVal ? newVal.split('\n') : [];
            const limit = 20;
            if (lines.length > limit) {
                $scope.local.keywordTextarea = lines.slice(0, limit).join('\n');
                $scope.local.keywordList = $scope.local.keywordTextarea.split('\n').filter(x => x.length);
                // Show the limit modal instead of a snackbar.  Persist the flag
                // so that the modal remains visible until dismissed.
                $scope.local.showLimitModal = true;
                $scope.saveLocal();
            }
        }
    });

    /* ------------------------------------------------------------------------
     * Watch for changes to the collected results.
     *
     * In fast scrape mode the background service worker updates the
     * local.collect array directly via chrome.storage without always
     * triggering the $box.onLocalChange callback in the popup.  As a
     * consequence the data grid can fail to update when new results are
     * inserted while scraping at high speed.  To ensure the dashboard
     * reflects newly added businesses regardless of how the array is
     * mutated, watch the length of local.collect.  Whenever the count
     * increases or decreases we refresh the data grid and update the UI
     * state.  Using $scope.$evalAsync defers execution until after
     * Angular’s current digest cycle completes, preventing infinite
     * digest errors.  The scroll position is preserved so that the
     * viewport does not jump when new rows are appended.
     */
    // Result batches are already handled by $box.onLocalChange above and the
    // IndexedDB hydration path. Do not watch local.collect.length here: rapid
    // storage batches can change it repeatedly inside the same Angular digest,
    // causing [$rootScope:infdig] while the table is being refreshed.
    // Direct feature flows (such as Email Scraping) update the grid explicitly.

    
    /* Fast email extraction: Maps profile emails first, then a bounded website
       worker pool. A page is fetched once; only same-origin contact/about
       links are visited when the homepage contains no address. */
    const EMAIL_WORKERS = 18;
    const EMAIL_TIMEOUT_MS = 4500;
    const EMAIL_FOLLOWUP_TIMEOUT_MS = 3000;
    let emailRunToken = 0;
    const emailControllers = new Set();
    const websiteScrapeCache = new Map();
    $scope.emailScrapeDone = 0;
    $scope.emailScrapeTotal = 0;

    function canonicalWebsiteUrl(value) {
        let raw = String(value || '').trim();
        if (!raw) return '';
        // Unwrap Google Maps redirect URLs like https://www.google.com/url?q=https://example.com&sa=...
        if (/^(?:https?:\/\/(?:www\.)?google\.[^/]+)?\/url\?/i.test(raw)) {
            try {
                const u = new URL(raw.startsWith('/') ? ('https://www.google.com' + raw) : raw);
                const target = u.searchParams.get('q') || u.searchParams.get('url') || '';
                if (target) raw = target.trim();
            } catch (e) {}
        }
        if (!/^https?:\/\//i.test(raw)) raw = 'https://' + raw.replace(/^\/+/, '');
        try {
            const url = new URL(raw);
            if (!/^https?:$/i.test(url.protocol) || /(^|\.)google\./i.test(url.hostname) || /gstatic\./i.test(url.hostname)) return '';
            url.hash = '';
            return url.href;
        } catch (e) { return ''; }
    }

    function decodeCfEmails(html) {
        const decoded = [];
        const text = String(html || '');
        const rx = /(?:data-cfemail=["']|email-protection#)([0-9a-fA-F]{10,160})/gi;
        let m;
        while ((m = rx.exec(text)) !== null) {
            try {
                const hex = m[1];
                const r = parseInt(hex.substr(0, 2), 16);
                let email = '';
                for (let n = 2; n < hex.length; n += 2) {
                    email += String.fromCharCode(parseInt(hex.substr(n, 2), 16) ^ r);
                }
                if (email.includes('@')) decoded.push(email);
            } catch (e) {}
        }
        return decoded.join(' ');
    }

    function extractEmailCandidates(value) {
        const rawHtml = String(value == null ? '' : value);
        const cfDecoded = decodeCfEmails(rawHtml);
        let decodedMailtos = '';
        try {
            const mailtoRx = /mailto:([^"'\s?>#]+)/gi;
            let mm;
            while ((mm = mailtoRx.exec(rawHtml)) !== null) {
                try { decodedMailtos += ' ' + decodeURIComponent(mm[1]); } catch (e) { decodedMailtos += ' ' + mm[1]; }
            }
        } catch (e) {}
        const text = (rawHtml + ' ' + cfDecoded + ' ' + decodedMailtos)
            .replace(/&commat;|&#64;|&#x40;|%40|\u0040/gi, '@')
            .replace(/&period;|&#46;|&#x2e;/gi, '.')
            .replace(/\s*(?:\[|\(|\{)\s*at\s*(?:\]|\)|\})\s*/gi, '@')
            .replace(/\s*(?:\[|\(|\{)\s*dot\s*(?:\]|\)|\})\s*/gi, '.');
        const found = [];
        const re = /[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+/gi;
        const junkDomains = /(?:sentry|wixpress|example|domain|yoursite|yourdomain|email|test|localhost|schema|w3\.org|cloudflare|wordpress|getbootstrap|googleapis|googleusercontent|gravatar)/i;
        let match;
        while ((match = re.exec(text)) !== null) {
            const email = match[0].toLowerCase().replace(/[.,;:]+$/, '').replace(/^(?:u003e|u003c|20)+/, '');
            if (!email || email.length < 5 || email.length > 254) continue;
            if (/\.(?:png|jpg|jpeg|gif|svg|webp|ico|css|js|woff|woff2|ttf|eot|mp4|mp3|pdf|zip)$/i.test(email)) continue;
            if (/^\d+x\d+@/i.test(email) || junkDomains.test(email)) continue;
            if (!found.includes(email)) found.push(email);
        }
        return found;
    }

    function emailLinksFromHtml(html, baseUrl) {
        const links = [];
        try {
            const parser = new DOMParser();
            const doc = parser.parseFromString(String(html || ''), 'text/html');
            doc.querySelectorAll('a[href]').forEach(anchor => {
                const href = String(anchor.getAttribute('href') || '').trim();
                if (!href || /^(?:mailto:|tel:|javascript:|#)/i.test(href)) return;
                const label = (String(anchor.textContent || '') + ' ' + href).toLowerCase();
                if (!/(contact|about|support|help|enquir|reach|connect|team|office|touch|impressum|info)/i.test(label)) return;
                try {
                    const url = new URL(href, baseUrl);
                    const base = new URL(baseUrl);
                    if (url.origin !== base.origin || !/^https?:$/i.test(url.protocol)) return;
                    url.hash = '';
                    const clean = url.href;
                    if (clean !== base.href && !links.includes(clean)) links.push(clean);
                } catch (e) {}
            });
            // Only add /contact fallback if anchor scan found no explicit contact/about link in the HTML
            if (links.length === 0) {
                try {
                    const base = new URL(baseUrl);
                    const fallbackUrl = new URL('/contact', base.origin).href;
                    if (fallbackUrl !== base.href) links.push(fallbackUrl);
                } catch (e) {}
            }
        } catch (e) {}
        return links.slice(0, 2);
    }

    async function fetchEmailPage(url, customTimeoutMs) {
        const timeoutMs = Math.max(1800, Number(customTimeoutMs) || EMAIL_TIMEOUT_MS);
        // 1. Primary: Service-Worker Background Fetch (bypasses CORS/mixed-content & retries HTTP/HTTPS within budget)
        try {
            if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
                const bgRes = await new Promise(resolve => {
                    let done = false;
                    const t = setTimeout(() => { if (!done) { done = true; resolve({ ok: false, timedOut: true }); } }, timeoutMs + 600);
                    try {
                        chrome.runtime.sendMessage({ action: 'pocketleads_fetch_website', url, timeoutMs }, resp => {
                            clearTimeout(t);
                            if (done) return;
                            done = true;
                            if (chrome.runtime && chrome.runtime.lastError) return resolve(null);
                            resolve(resp || { ok: false });
                        });
                    } catch (e) { clearTimeout(t); if (!done) { done = true; resolve(null); } }
                });
                if (bgRes && bgRes.ok && bgRes.html) {
                    return { ok: true, html: bgRes.html, url: bgRes.url || url };
                }
                // If background service worker handled the request and confirmed the site is unreachable/timed out,
                // do not waste another 9s retrying from the page context (which is also subject to CORS).
                if (bgRes && bgRes.ok === false) {
                    throw new Error(bgRes.error || 'Website unreachable');
                }
            }
        } catch (bgErr) {
            if (bgErr && /unreachable|failed/i.test(String(bgErr.message || ''))) throw bgErr;
        }

        // 2. Fallback: Direct fetch only when chrome.runtime.sendMessage was unavailable
        const controller = typeof AbortController === 'function' ? new AbortController() : null;
        if (controller) emailControllers.add(controller);
        const timer = setTimeout(() => { try { if (controller) controller.abort(); } catch (e) {} }, timeoutMs);
        try {
            if (typeof fetch === 'function') {
                const response = await fetch(url, {
                    method: 'GET', cache: 'no-store', credentials: 'omit', redirect: 'follow',
                    referrerPolicy: 'no-referrer', signal: controller ? controller.signal : undefined
                });
                const html = await response.text();
                if (html && html.length > 15) {
                    return { ok: response.ok || !!html, html, url: response.url || url };
                }
            }
        } finally {
            clearTimeout(timer);
            if (controller) emailControllers.delete(controller);
        }
        throw new Error('Website request failed');
    }

    function ensureWebsiteEmailHostPermission() {
        return new Promise(resolve => {
            try {
                if (!chrome || !chrome.permissions) return resolve(true);
                const request = { origins: ['<all_urls>'] };
                chrome.permissions.contains(request, already => {
                    if (already) return resolve(true);
                    try {
                        chrome.permissions.request(request, granted => {
                            resolve(granted !== false);
                        });
                    } catch (e) { resolve(true); }
                });
            } catch (e) { resolve(true); }
        });
    }

    function extractSocialLinksFromHtml(html, sourceUrl) {
        const text = String(html || '') + ' ' + String(sourceUrl || '');
        const socials = { facebook: '', instagram: '', linkedin: '', twitter: '', youtube: '' };
        const patterns = [
            ['facebook', /https?:\/\/(?:www\.|m\.)?(?:facebook|fb)\.com\/(?!sharer|plugins|tr\?|dialog|events|groups|watch|pages\/category|share\.php)(?:profile\.php\?id=\d+|pages\/[a-zA-Z0-9._\-%]+\/?\d*|people\/[a-zA-Z0-9._\-%]+\/?\d*|[a-zA-Z0-9._\-]{2,80})\/?/i],
            ['instagram', /https?:\/\/(?:www\.)?(?:instagram\.com|instagr\.am)\/(?!p\/|reel\/|reels\/|explore\/|accounts\/|stories\/|tv\/)[a-zA-Z0-9._]{2,60}\/?/i],
            ['linkedin', /https?:\/\/(?:[a-z]{2,3}\.)?linkedin\.com\/(?:company|in|school)\/[a-zA-Z0-9._\-%]{2,100}\/?/i],
            ['twitter', /https?:\/\/(?:www\.)?(?:twitter|x)\.com\/(?!intent|share|home|search|hashtag|i\/|privacy|tos)[a-zA-Z0-9_]{2,50}\/?/i],
            ['youtube', /https?:\/\/(?:www\.)?youtube\.com\/(?:@[a-zA-Z0-9._\-]+|channel\/[a-zA-Z0-9_\-]+|c\/[a-zA-Z0-9_\-]+|user\/[a-zA-Z0-9_\-]+)\/?/i]
        ];
        for (const [key, regex] of patterns) {
            const m = text.match(regex);
            if (m && m[0]) socials[key] = m[0].replace(/["'<>\\),;]+$/, '');
        }
        return socials;
    }

    async function scrapeWebsiteEmails(website, token) {
        const home = canonicalWebsiteUrl(website);
        if (!home) return { value: "Can't Access Website", inaccessible: true, socials: {} };
        // Direct social profile URL (e.g., business listed facebook.com/page or instagram.com/page as its website)
        const initialSocials = extractSocialLinksFromHtml('', home);
        if (/^(?:https?:\/\/)?(?:www\.|m\.)?(?:facebook\.com|fb\.com|instagram\.com|instagr\.am|linkedin\.com|twitter\.com|x\.com|youtube\.com)\//i.test(home)) {
            return { value: 'No Email found', inaccessible: false, socials: initialSocials };
        }
        if (websiteScrapeCache.has(home)) {
            const cached = await websiteScrapeCache.get(home);
            if (token !== emailRunToken) return { cancelled: true };
            return cached;
        }
        const taskPromise = (async () => {
            try {
                const first = await fetchEmailPage(home, EMAIL_TIMEOUT_MS);
                if (token !== emailRunToken) return { cancelled: true };
                let emails = extractEmailCandidates(first.html);
                let socials = Object.assign({}, initialSocials, extractSocialLinksFromHtml(first.html, first.url || home));
                // Fast-path: only crawl follow-up contact pages if the homepage had 0 emails!
                if (!emails.length) {
                    const followups = emailLinksFromHtml(first.html, first.url || home);
                    if (followups.length && token === emailRunToken) {
                        const settled = await Promise.allSettled(
                            followups.map(link => fetchEmailPage(link, EMAIL_FOLLOWUP_TIMEOUT_MS))
                        );
                        for (const item of settled) {
                            if (item.status === 'fulfilled' && item.value && item.value.html) {
                                emails = emails.concat(extractEmailCandidates(item.value.html));
                                const moreSocials = extractSocialLinksFromHtml(item.value.html, item.value.url || home);
                                Object.keys(socials).forEach(k => { if (!socials[k] && moreSocials[k]) socials[k] = moreSocials[k]; });
                            }
                        }
                    }
                }
                emails = emails.filter((email, index, all) => all.indexOf(email) === index).slice(0, 5);
                return { value: emails.length ? emails.join(', ') : 'No Email found', inaccessible: false, socials };
            } catch (e) {
                if (token !== emailRunToken) return { cancelled: true };
                return { value: "Can't Access Website", inaccessible: true, socials: initialSocials };
            }
        })();
        websiteScrapeCache.set(home, taskPromise);
        return taskPromise;
    }

    function isPendingEmailScrapeValue(val) {
        const s = String(val || '').trim();
        return !s || /^(no email found|can't access website)$/i.test(s);
    }

    $scope.scrapeEmails = async () => {
        if ($scope.local.isScrapingEmail) {
            emailRunToken += 1;
            emailControllers.forEach(controller => { try { controller.abort(); } catch (e) {} });
            $scope.local.isScrapingEmail = false;
            $scope.saveLocal();
            return;
        }
        await ensureWebsiteEmailHostPermission();
        const token = ++emailRunToken;
        websiteScrapeCache.clear();
        // Hydrate full canonical dataset from IndexedDB first if dashboard only holds a preview
        let canonicalRows = null;
        try {
            const allCanonical = await runtimeMessageAsync({ action: 'result_store_get_all' });
            if (allCanonical && Array.isArray(allCanonical.rows) && allCanonical.rows.length > 0) {
                canonicalRows = allCanonical.rows;
            }
        } catch (e) {}

        const rows = canonicalRows && canonicalRows.length >= (($scope.local.collect || []).length)
            ? canonicalRows
            : (Array.isArray($scope.local.collect) ? $scope.local.collect : []);
        rows.forEach((row, idx) => {
            if (row && typeof row === 'object') {
                normalizeDashboardRow(row);
                ensureDashboardRowKey(row, idx);
            }
        });
        // Keep preview collect synchronized with canonical rows during enrichment
        const previewByKey = new Map();
        const keyForRow = (r, i) => String((r && (r.place_id || r.cid || r.map_link || r.phone || ((r.company_name || r.name || '') + '|' + (r.address || '')))) || ('row_' + i));
        if (Array.isArray($scope.local.collect)) {
            $scope.local.collect.forEach((r, i) => previewByKey.set(keyForRow(r, i), r));
        }

        // First prefer completely unscraped websites; if all websites were already tried, retry ones with 'No Email found' / 'Can't Access Website' or missing socials
        let targets = rows.filter(row => row && row.website && !String(row.email_1 || '').trim());
        if (!targets.length) {
            targets = rows.filter(row => row && row.website && (isPendingEmailScrapeValue(row.email_1) || !(row.facebook || row.instagram || row.linkedin || row.twitter || row.youtube)));
        }
        if (!targets.length) return;

        $scope.local.isScrapingEmail = true;
        $scope.emailScrapeDone = 0;
        $scope.emailScrapeTotal = targets.length;
        $scope.saveLocal();
        let cursor = 0;
        let completed = 0;
        const dirtyRowsForIdb = new Map();
        let uiRefreshTimer = null;

        const scheduleEmailUiRefresh = () => {
            if (uiRefreshTimer) return;
            uiRefreshTimer = setTimeout(() => {
                uiRefreshTimer = null;
                $scope.$evalAsync(() => {
                    refreshDashboardMetricCounts($scope.local.collect);
                    try { updateDataTable($scope.local); } catch (e) {}
                });
            }, 220);
        };

        const flushDirtyRowsToIdb = async () => {
            if (!dirtyRowsForIdb.size) return;
            const batch = [...dirtyRowsForIdb.values()];
            dirtyRowsForIdb.clear();
            try {
                const runId = $scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.runEventId;
                await runtimeMessageAsync({ action: 'result_store_upsert', rows: batch, runId });
            } catch (e) {}
        };

        const blacklist = Array.isArray($scope.local.blackList) ? $scope.local.blackList.map(x => String(x).trim().toLowerCase()) : [];

        const applyResult = (row, result) => {
            if (token !== emailRunToken || !result || result.cancelled || !row) return;
            const values = String(result.value || '').split(/[,;\n]+/).map(x => x.trim()).filter(Boolean);
            const processed = values.map(value => blacklist.includes(value.toLowerCase()) ? 'Blacklisted Email' : value);
            const existingValid = !isPendingEmailScrapeValue(row.email_1) ? row.email_1 : '';
            const nextEmail = processed.join(', ') || 'No Email found';
            const finalEmail = (existingValid && isPendingEmailScrapeValue(nextEmail)) ? existingValid : nextEmail;
            row.email_1 = finalEmail;
            if (result.socials && typeof result.socials === 'object') {
                ['facebook', 'instagram', 'linkedin', 'twitter', 'youtube'].forEach(k => {
                    if (result.socials[k]) row[k] = result.socials[k];
                });
            }
            normalizeDashboardRow(row);
            const k = keyForRow(row, 0);
            const previewRow = previewByKey.get(k);
            if (previewRow && previewRow !== row) {
                previewRow.email_1 = row.email_1;
                ['facebook', 'instagram', 'linkedin', 'twitter', 'youtube'].forEach(sk => {
                    if (row[sk]) previewRow[sk] = row[sk];
                });
                normalizeDashboardRow(previewRow);
            }
            const rowKeyStr = String(ensureDashboardRowKey(row, 0) || k);
            dirtyRowsForIdb.set(rowKeyStr, row);
            scheduleEmailUiRefresh();
        };

        const worker = async () => {
            while (token === emailRunToken) {
                const index = cursor++;
                if (index >= targets.length) return;
                const targetRow = targets[index];
                try {
                    const result = await scrapeWebsiteEmails(targetRow.website, token);
                    if (token !== emailRunToken) return;
                    applyResult(targetRow, result);
                } catch (e) {
                    if (token !== emailRunToken) return;
                    applyResult(targetRow, { value: "Can't Access Website", socials: {} });
                }
                completed += 1;
                $scope.emailScrapeDone = completed;
                if (completed % 25 === 0) {
                    await flushDirtyRowsToIdb();
                }
            }
        };
        try {
            await Promise.all(Array.from({ length: Math.min(EMAIL_WORKERS, targets.length) }, worker));
        } catch (error) {
            try { console.warn('Email scraping workers stopped safely', error && error.message ? error.message : error); } catch (e) {}
        } finally {
            if (uiRefreshTimer) { clearTimeout(uiRefreshTimer); uiRefreshTimer = null; }
            await flushDirtyRowsToIdb();
            if (token === emailRunToken) {
                $scope.$evalAsync(() => {
                    $scope.local.isScrapingEmail = false;
                    $scope.emailScrapeDone = 0;
                    $scope.emailScrapeTotal = 0;
                    $scope.local.collect = rows.slice(-250);
                    $scope.local.collectIsPreview = rows.length > $scope.local.collect.length;
                    $scope.local.resultStoreCount = Math.max($scope.local.resultStoreCount || 0, rows.length);
                    refreshDashboardMetricCounts($scope.local.collect);
                    $scope.saveLocal();
                    try {
                        updateDataTable($scope.local);
                        if (dataGrid && typeof dataGrid.refresh === 'function') dataGrid.refresh();
                    } catch (e) {}
                });
            }
        }
    };

    $scope.emailFiltered = () => {
        const rows = Array.isArray($scope.local && $scope.local.collect) ? $scope.local.collect : [];
        const fresh = rows.filter(x => x && x.website && !String(x.email_1 || '').trim()).length;
        if (fresh > 0) return fresh;
        return rows.filter(x => x && x.website && isPendingEmailScrapeValue(x.email_1)).length;
    };

    // Download the scraped data as CSV.  This custom implementation ensures
    // that the map_link column remains a functional hyperlink in spreadsheet
    // applications by using the Excel HYPERLINK formula with proper
    // quoting.  It also leaves other values unchanged (besides doubling
    // double quotes for CSV escaping) and respects the column ordering
    // defined in columnList.
    function exportHeaderFor(label) {
        let header;
        try { header = (typeof FoxCommon !== 'undefined' && FoxCommon.getKeyFromMap) ? FoxCommon.getKeyFromMap(label) : undefined; } catch (e) { header = undefined; }
        if (!header || header === label) header = FoxCommon.downloadAs.keyToColumnHeader(label);
        return header;
    }

    function selectedExportLabels() {
        const modal = $scope.exportModal || {};
        return (modal.fields || []).filter(field => modal.selected && modal.selected[field]);
    }

    function exportValueFor(row, label) {
        if (!row || typeof row !== 'object') return '';
        if (label === 'phone_number') return rowPhoneValue(row);
        const value = row[label];
        return PocketLeadsExport.value(value);
    }

    function dedupeCanonicalRows(rows) {
        const input = Array.isArray(rows) ? rows : [];
        const seen = new Set();
        const out = [];
        input.forEach((row, index) => {
            if (!row || typeof row !== 'object') return;
            const key = String((row.place_id || row.placeId || row.cid || row.map_link || row.phone || row.company_name || ('row_' + index)));
            if (seen.has(key)) return;
            seen.add(key);
            out.push(row);
        });
        return out;
    }

    function runtimeMessageAsync(message) {
        return new Promise(resolve => {
            try {
                chrome.runtime.sendMessage(message, response => {
                    const last = chrome.runtime && chrome.runtime.lastError ? chrome.runtime.lastError : null;
                    if (last || !response || !response.ok) return resolve(null);
                    resolve(response);
                });
            } catch (e) { resolve(null); }
        });
    }

    const exportService=PocketLeadsExport.create(runtimeMessageAsync);
    async function requestCanonicalRowsForExport(){return exportService.rows();}
    async function getCanonicalStoreCount(){return exportService.count();}
    async function getCanonicalStorePage(offset,limit){return exportService.page(offset,limit);}

    async function buildLargeExportBlob(mode, labels) {
        const total = await getCanonicalStoreCount();
        if(total!==$scope.exportModal.rowCount)throw new Error('Results changed. Reopen Download to refresh the export.');
        if (!total) throw new Error('No data available for export.');
        const pageSize = total > 30000 ? 750 : 1500;
        const parts = [];
        const escHtml = value => String(value === null || typeof value === 'undefined' ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        if (mode === 'excel') {
            parts.push('<html><head><meta charset="utf-8"></head><body><table border="1"><thead><tr>');
            labels.forEach(label => {
                let header;
                try { header = (typeof FoxCommon !== 'undefined' && FoxCommon.getKeyFromMap) ? FoxCommon.getKeyFromMap(label) : undefined; } catch (e) { header = undefined; }
                if (!header || header === label) header = FoxCommon.downloadAs.keyToColumnHeader(label);
                parts.push('<th>' + escHtml(header) + '</th>');
            });
            parts.push('</tr></thead><tbody>');
        } else {
            parts.push(labels.map(label => {
                let header;
                try { header = (typeof FoxCommon !== 'undefined' && FoxCommon.getKeyFromMap) ? FoxCommon.getKeyFromMap(label) : undefined; } catch (e) { header = undefined; }
                if (!header || header === label) header = FoxCommon.downloadAs.keyToColumnHeader(label);
                return '"' + String(header).replace(/"/g, '""') + '"';
            }).join(',') + '\r\n');
        }
        const uniqueKey = $scope.exportModal && $scope.exportModal.uniqueBy ? String($scope.exportModal.uniqueBy).trim() : '';
        const seenUnique = new Set();
        const filterPageRow = row => {
            if (!uniqueKey) return true;
            const rawVal = String(exportValueFor(row, uniqueKey) || '').trim().toLowerCase();
            if (!rawVal || rawVal === '—' || rawVal === 'no email found' || rawVal === "can't access website") return false;
            const normVal = uniqueKey === 'phone_number' ? rawVal.replace(/\D/g, '').replace(/^0+/, '') : rawVal;
            if (!normVal || seenUnique.has(normVal)) return false;
            seenUnique.add(normVal);
            return true;
        };
        for (let offset = 0; offset < total; offset += pageSize) {
            const page = await getCanonicalStorePage(offset, pageSize);
            if(page.length!==Math.min(pageSize,total-offset))throw new Error('Results changed during export. Retry after scraping stops.');
            const filteredPage = uniqueKey ? page.filter(filterPageRow) : page;
            if (mode === 'excel') {
                let chunk = '';
                filteredPage.forEach(row => {
                    chunk += '<tr>';
                    labels.forEach(label => {
                        const value = exportValueFor(row, label);
                        chunk += label === 'map_link' && value
                            ? '<td><a href="' + escHtml(value) + '">' + escHtml(value) + '</a></td>'
                            : '<td>' + escHtml(value) + '</td>';
                    });
                    chunk += '</tr>';
                });
                parts.push(chunk);
            } else {
                let chunk = '';
                filteredPage.forEach(row => {
                    chunk += labels.map(label => {
                        let value = exportValueFor(row, label);
                        if (label === 'map_link' && value) value = '=HYPERLINK("' + value + '","' + value + '")';
                        return '"' + String(value).replace(/"/g, '""') + '"';
                    }).join(',') + '\r\n';
                });
                parts.push(chunk);
            }
            if (page.length < pageSize) break;
            await new Promise(resolve => setTimeout(resolve, 0));
        }
        if(await getCanonicalStoreCount()!==total)throw new Error('Results changed during export. Retry after scraping stops.');
        if (mode === 'excel') {
            parts.push('</tbody></table></body></html>');
            return new Blob(parts, { type: 'application/vnd.ms-excel;charset=utf-8' });
        }
        return new Blob(parts, { type: 'text/csv;charset=utf-8' });
    }

    async function getCompleteRowsForExport(){return exportService.rows();}

    let rememberedExportFields = {};
    chrome.storage.local.get('pocketleadsExportFields',v=>{rememberedExportFields=v.pocketleadsExportFields||{};});
    $scope.download = () => {
        if (!$scope.licenseActive) {
            $scope.snackbar.show("Please activate your licence first");
            return;
        }
        const localRows = dedupeCanonicalRows($scope.local && $scope.local.collect);
        const initialLabels = PocketLeadsExport.fields(localRows,baseColumnList);
        const initialSelected = {};
        initialLabels.forEach(label => { initialSelected[label] = rememberedExportFields[label] !== false; });
        $scope.exportModal = { show: true, step:'options', loading: true, fields: initialLabels, selected: initialSelected, format: 'csv', rows: localRows, largeMode: false, rowCount: localRows.length };

        getCanonicalStoreCount().then(async total => {
            if (total > 10000) {
                const union=new Set(PocketLeadsExport.fields(localRows,baseColumnList));
                for(let offset=0;offset<total;offset+=2000){
                    const page=await getCanonicalStorePage(offset,2000);
                    PocketLeadsExport.fields(page,baseColumnList).forEach(label=>union.add(label));
                }
                const labels=Array.from(union);
                const selected = {};
                labels.forEach(label => { selected[label] = rememberedExportFields[label] !== false; });
                $scope.safeApply(() => {
                    $scope.exportModal.fields = labels;
                    $scope.exportModal.selected = selected;
                    $scope.exportModal.rows = [];
                    $scope.exportModal.rowCount = total;
                    $scope.exportModal.largeMode = true;
                    $scope.exportModal.loading = false;
                });
                return;
            }
            const arrData = await getCompleteRowsForExport();
            if (!arrData.length) {
                $scope.safeApply(() => { $scope.exportModal.loading = false; $scope.closeExportModal(); $scope.snackbar.show('No data available for export.'); });
                return;
            }
            const labels = PocketLeadsExport.fields(arrData,baseColumnList);
            const selected = {};
            labels.forEach(label => { selected[label] = rememberedExportFields[label] !== false; });
            $scope.safeApply(() => { $scope.exportModal.fields = labels; $scope.exportModal.selected = selected; $scope.exportModal.rows = arrData; $scope.exportModal.rowCount = arrData.length; $scope.exportModal.loading = false; });
        }).catch(error => {
            $scope.safeApply(() => { $scope.exportModal.loading = false; $scope.exportModal.error = true; $scope.snackbar.show(error && error.message ? error.message : 'Unable to prepare export.'); });
        });
    };

    function compactMobileCrmRow(row, index) {
        row = row && typeof row === 'object' ? row : {};
        const pick = (keys, fallback) => {
            for (let i = 0; i < keys.length; i++) {
                const value = row[keys[i]];
                if (value !== null && typeof value !== 'undefined' && String(value).trim() !== '') return value;
            }
            return typeof fallback === 'undefined' ? '' : fallback;
        };
        return {
            id: pick(['id', 'place_id', 'cid'], 'lead_' + (index + 1)),
            company_name: pick(['company_name', 'title', 'name', 'business_name']),
            phone_number: rowPhoneValue(row),
            whatsapp_status: pick(['whatsapp_status', 'wa_status']),
            review: pick(['review', 'rating', 'stars'], 0),
            total_reviews: pick(['total_reviews', 'reviews', 'review_count', 'reviewCount'], 0),
            category: pick(['category', 'type', 'main_category']),
            address: pick(['address', 'full_address', 'complete_address']),
            city: pick(['city']),
            state: pick(['state']),
            pincode: pick(['pincode', 'postal_code', 'zip']),
            website: pick(['website', 'url']),
            map_link: pick(['map_link', 'google_maps_url', 'maps_url', 'googleMapsUrl']),
            place_id: pick(['place_id', 'placeId']),
            status: pick(['status', 'crm_status'], 'new'),
            starred: Boolean(row.starred),
            remark: pick(['remark', 'remarks', 'note', 'notes']),
            dirty: Boolean(row.dirty),
            changed_fields: Array.isArray(row.changed_fields) ? row.changed_fields : [],
            source: pick(['source']),
            scraped_at: pick(['scraped_at', 'created_at']),
            updated_at: pick(['updated_at'])
        };
    }

    function safeMobileCrmJson(payload) {
        return JSON.stringify(payload)
            .replace(/</g, '\\u003c')
            .replace(/>/g, '\\u003e')
            .replace(/&/g, '\\u0026')
            .replace(/\u2028/g, '\\u2028')
            .replace(/\u2029/g, '\\u2029');
    }

    async function allowExportRows(count) {
        const state=await PocketLeadsAccount.read();
        const a=state.pocketleadsAccount;
        const limit=a?.limits?.exportLimit;
        const allowed=state.license?.active && a?.entitlements?.export && (limit==='unlimited'||(Number.isFinite(limit)&&count<=limit));
        if(!allowed)$scope.snackbar.show('Export unavailable or above your plan limit. Refresh account or contact support.');
        return !!allowed;
    }
    $scope.mobileCrmExporting = false;
    $scope.exportMobileCrmHtml = () => {
        if (!$scope.licenseActive) {
            $scope.snackbar.show('Please activate your licence first');
            return;
        }
        if ($scope.mobileCrmExporting) return;
        $scope.mobileCrmExporting = true;
        const templateUrl = chrome.runtime.getURL('templates/PocketLeads_Mobile_CRM.html');
        getCompleteRowsForExport().then(async sourceRows => {
            if(!await allowExportRows(sourceRows.length))throw new Error("Export unavailable for this account or row count.");
            if (!sourceRows.length) throw new Error('No data available for Mobile CRM export.');
            return fetch(templateUrl, { cache: 'no-store' })
                .then(response => {
                    if (!response.ok) throw new Error('CRM template could not be loaded.');
                    return response.text();
                })
                .then(template => ({ template, sourceRows }));
        })
            .then(({ template, sourceRows }) => {
                const payload = {
                    workspaceId: 'pocketleads_' + Date.now().toString(36),
                    generatedAt: new Date().toISOString(),
                    source: 'PocketLeads extension export',
                    rows: sourceRows.map(compactMobileCrmRow)
                };
                const dataPattern = /(<script id="pocketleads-embedded-data" type="application\/json">)[\s\S]*?(<\/script>)/;
                if (!dataPattern.test(template)) throw new Error('CRM template data marker is missing.');
                const safePayload = safeMobileCrmJson(payload);
                const output = template.replace(dataPattern, (match, openTag, closeTag) => openTag + '\n' + safePayload + '\n  ' + closeTag);
                const stamp = new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
                saveBlobDownload(new Blob([output], { type: 'text/html;charset=utf-8' }), 'PocketLeads_Mobile_CRM_' + stamp + '.html');
                $scope.snackbar.show('Mobile CRM HTML exported successfully.');
            })
            .catch(error => {
                console.error('Mobile CRM export failed:', error);
                $scope.snackbar.show(error && error.message ? error.message : 'Mobile CRM export failed.');
            })
            .finally(() => {
                $scope.safeApply(() => { $scope.mobileCrmExporting = false; });
            });
    };

    $scope.closeExportModal = () => {
        $scope.exportModal.show = false;
    };

    $scope.selectAllExportFields = () => {
        ($scope.exportModal.fields || []).forEach(field => { $scope.exportModal.selected[field] = true; });
    };

    $scope.deselectAllExportFields = () => {
        ($scope.exportModal.fields || []).forEach(field => { $scope.exportModal.selected[field] = false; });
    };

    $scope.selectExportPreset = preset => {
        const fields = $scope.exportModal && Array.isArray($scope.exportModal.fields) ? $scope.exportModal.fields : [];
        $scope.deselectAllExportFields();
        if (preset === 'phone') {
            fields.forEach(f => { if (/^(company_name|phone_number|whatsapp_status)$/i.test(f)) $scope.exportModal.selected[f] = true; });
        } else if (preset === 'email') {
            fields.forEach(f => { if (/^(company_name|email_1|website|facebook|instagram|linkedin)$/i.test(f)) $scope.exportModal.selected[f] = true; });
        } else if (preset === 'telecalling') {
            fields.forEach(f => { if (/^(company_name|phone_number|whatsapp_status|city|category|address|map_link)$/i.test(f)) $scope.exportModal.selected[f] = true; });
        } else if (preset === 'single_phone') {
            fields.forEach(f => { if (f === 'phone_number') $scope.exportModal.selected[f] = true; });
        } else if (preset === 'single_email') {
            fields.forEach(f => { if (f === 'email_1') $scope.exportModal.selected[f] = true; });
        }
    };

    $scope.selectedExportCount = () => selectedExportLabels().length;
    $scope.downloadFullData = () => { $scope.selectAllExportFields(); return $scope.runSelectedExport($scope.exportModal.format, true); };
    $scope.runSelectedExport = async (format, full=false) => {
        if($scope.exportModal.loading || $scope.exportModal.error)return;
        const state=await PocketLeadsAccount.read();
        const account=state.pocketleadsAccount;
        if(!state.license?.active || !account?.entitlements?.export){$scope.snackbar.show('Export is unavailable for this account. Refresh account or contact support.');return;}
        const cap=account.limits?.exportLimit;
        if(cap!=='unlimited' && (!Number.isFinite(cap)||$scope.exportModal.rowCount>cap)){$scope.snackbar.show('Export exceeds your server-configured plan limit. Contact support.');return;}
        if(!full){rememberedExportFields={...$scope.exportModal.selected};chrome.storage.local.set({pocketleadsExportFields:rememberedExportFields});}
        const modalRows = $scope.exportModal && Array.isArray($scope.exportModal.rows) ? $scope.exportModal.rows : [];
        const labels = selectedExportLabels();
        if (!labels.length) {
            $scope.snackbar.show('Please select at least one field.');
            return;
        }
        const mode = String(format || $scope.exportModal.format || 'csv').toLowerCase();
        const stamp = new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
        if ($scope.exportModal && $scope.exportModal.largeMode) {
            if (mode === 'copy') {
                $scope.snackbar.show('Large datasets are exported in chunks. Use CSV or Excel instead of Copy.');
                return;
            }
            $scope.exportModal.loading = true;
            try {
                const blob = await buildLargeExportBlob(mode === 'excel' ? 'excel' : 'csv', labels);
                saveBlobDownload(blob, 'PocketLeads_Custom_Export_' + stamp + (mode === 'excel' ? '.xls' : '.csv'));
                $scope.closeExportModal();
            } catch (error) {
                $scope.snackbar.show(error && error.message ? error.message : 'Large export failed.');
            } finally {
                $scope.exportModal.loading = false;
            }
            return;
        }
        let rows = ($scope.exportModal && !$scope.exportModal.loading && modalRows.length) ? modalRows : await getCompleteRowsForExport();
        const uniqueKey = $scope.exportModal && $scope.exportModal.uniqueBy ? String($scope.exportModal.uniqueBy).trim() : '';
        if (uniqueKey && Array.isArray(rows)) {
            const seenUnique = new Set();
            rows = rows.filter(r => {
                const rawVal = String(exportValueFor(r, uniqueKey) || '').trim().toLowerCase();
                if (!rawVal || rawVal === '—' || rawVal === 'no email found' || rawVal === "can't access website") return false;
                const normVal = uniqueKey === 'phone_number' ? rawVal.replace(/\D/g, '').replace(/^0+/, '') : rawVal;
                if (!normVal || seenUnique.has(normVal)) return false;
                seenUnique.add(normVal);
                return true;
            });
        }
        if (mode === 'json') {
            const jsonRows = rows.map(row => {
                const obj = {};
                labels.forEach(label => { obj[label] = exportValueFor(row, label); });
                return obj;
            });
            saveBlobDownload(new Blob([JSON.stringify(jsonRows, null, 2)], { type: 'application/json;charset=utf-8' }), 'PocketLeads_Custom_Export_' + stamp + '.json');
            $scope.closeExportModal();
            return;
        }
        if (mode === 'excel') {
            saveBlobDownload(new Blob([buildExcelHtmlFromRows(rows, labels)], { type: 'application/vnd.ms-excel;charset=utf-8' }), 'PocketLeads_Custom_Export_' + stamp + '.xls');
            $scope.closeExportModal();
            return;
        }
        if (mode === 'copy') {
            const text = labels.map(exportHeaderFor).join('\t') + '\n' + rows.map(row => labels.map(label => {
                const value = exportValueFor(row, label);
                return String(value).replace(/[\t\r\n]+/g, ' ');
            }).join('\t')).join('\n');
            const done = () => { $scope.safeApply(() => { $scope.snackbar.show('Selected fields copied.'); $scope.closeExportModal(); }); };
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(done).catch(() => {
                    const ta = document.createElement('textarea');
                    ta.value = text;
                    document.body.appendChild(ta);
                    ta.select();
                    document.execCommand('copy');
                    ta.remove();
                    done();
                });
            } else {
                const ta = document.createElement('textarea');
                ta.value = text;
                document.body.appendChild(ta);
                ta.select();
                document.execCommand('copy');
                ta.remove();
                done();
            }
            return;
        }
        saveBlobDownload(new Blob([buildCsvFromRows(rows, labels)], { type: 'text/csv;charset=utf-8' }), 'PocketLeads_Custom_Export_' + stamp + '.csv');
        $scope.closeExportModal();
    };
    
    $scope.metricCounts = { website: 0, phone_number: 0, email_1: 0 };
    let metricsTimer=null;
    function refreshDashboardMetricCounts(rows) {
        try { refreshMobileLeadsView(rows); } catch (e) {}
        const isActiveRun = !!(($scope.local && PocketLeadsRunState.isRunning($scope.local)) || ($scope.local && $scope.local.isScrapingEmail));
        if($scope.local?.collectIsPreview){
            if(metricsTimer)return;
            metricsTimer=setTimeout(async()=>{
                try{
                    const r=await runtimeMessageAsync({action:'result_store_query',query:{metrics:true,metricsOnly:true,limit:1}});
                    if(r?.metrics){
                        $scope.$evalAsync(()=>{
                            if (isActiveRun && $scope.metricCounts) {
                                $scope.metricCounts = {
                                    website: Math.max($scope.metricCounts.website || 0, r.metrics.website || 0),
                                    phone_number: Math.max($scope.metricCounts.phone_number || 0, r.metrics.phone_number || 0),
                                    email_1: Math.max($scope.metricCounts.email_1 || 0, r.metrics.email_1 || 0)
                                };
                            } else {
                                $scope.metricCounts = r.metrics;
                            }
                        });
                    }
                }
                finally{metricsTimer=null;}
            },350);
            return;
        }
        const websites = new Set();
        const phones = new Set();
        const emails = new Set();
        (Array.isArray(rows) ? rows : []).forEach(row => {
            const website = String(row && row.website || '').trim().toLowerCase();
            if (website) websites.add(website);
            const digits = String(rowPhoneValue(row) || '').replace(/\D/g, '').replace(/^0+/, '');
            if (digits.length >= 8) phones.add(digits);
            const em = String(row && row.email_1 || '').trim().toLowerCase();
            if (em && !/^(no email|can't access|blacklisted)/i.test(em) && em.includes('@')) emails.add(em);
        });
        if (!Array.isArray(rows) || rows.length === 0) {
            if (!isActiveRun) {
                $scope.metricCounts.website = 0;
                $scope.metricCounts.phone_number = 0;
                $scope.metricCounts.email_1 = 0;
            }
            return;
        }
        $scope.metricCounts.website = isActiveRun ? Math.max($scope.metricCounts.website || 0, websites.size) : websites.size;
        $scope.metricCounts.phone_number = isActiveRun ? Math.max($scope.metricCounts.phone_number || 0, phones.size) : phones.size;
        $scope.metricCounts.email_1 = isActiveRun ? Math.max($scope.metricCounts.email_1 || 0, emails.size) : emails.size;
    }
    $scope.countOf = targetKey => Number($scope.metricCounts && $scope.metricCounts[targetKey]) || 0;
    $scope.countPhones = () => Number($scope.metricCounts && $scope.metricCounts.phone_number) || 0;

    /* --------------------------------------------------------------------
     * Mobile View State, Navigation, Progress & Lead Card Helpers
     * Provides a clean, responsive 3-tab mobile view (Home/Setup, Progress,
     * Leads) that shares 100% of triggers, models, and live extraction state
     * with Desktop View so switching views at any time is instant and smooth.
     */
    $scope.viewMode = (typeof window !== 'undefined' && window.pocketleadsViewMode && typeof window.pocketleadsViewMode.get === 'function')
        ? window.pocketleadsViewMode.get()
        : 'desktop';
    $scope.themeMode = (typeof window !== 'undefined' && window.pocketleadsTheme && typeof window.pocketleadsTheme.get === 'function')
        ? window.pocketleadsTheme.get()
        : 'dark';
    $scope.mobileTab = (function() {
        try {
            const saved = sessionStorage.getItem('pl_mobile_tab');
            return (saved === 'home' || saved === 'progress' || saved === 'leads') ? saved : 'home';
        } catch (_) {
            return 'home';
        }
    })();
    $scope.mobileDataDrawerOpen = false;
    $scope.mobileLeadSearch = '';
    $scope.mobileLeadLimit = 40;
    $scope.mobileSelectedMap = {};
    $scope.mobileVisibleLeads = [];
    $scope.mobileTotalFilteredCount = 0;
    let mobileSearchTimer = null;

    function syncGridLayoutSoon() {
        setTimeout(function() {
            try {
                if (dataGrid && typeof dataGrid.refresh === 'function') dataGrid.refresh();
                if (typeof window !== 'undefined') window.dispatchEvent(new Event('resize'));
            } catch (_) {}
        }, 40);
    }

    $scope.setViewMode = function(mode) {
        const next = (String(mode || '').toLowerCase() === 'mobile') ? 'mobile' : 'desktop';
        if (typeof window !== 'undefined' && window.pocketleadsViewMode && typeof window.pocketleadsViewMode.set === 'function') {
            $scope.viewMode = window.pocketleadsViewMode.set(next);
        } else {
            $scope.viewMode = next;
            try {
                document.documentElement.setAttribute('data-view-mode', next);
                if (document.body) document.body.setAttribute('data-view-mode', next);
            } catch (_) {}
        }
        if ($scope.viewMode === 'desktop') {
            $scope.mobileDataDrawerOpen = false;
            syncGridLayoutSoon();
        } else {
            refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
        }
    };

    $scope.setThemeMode = function(theme) {
        const next = (String(theme || '').toLowerCase() === 'light') ? 'light' : 'dark';
        if (typeof window !== 'undefined' && window.pocketleadsTheme && typeof window.pocketleadsTheme.set === 'function') {
            $scope.themeMode = window.pocketleadsTheme.set(next);
        } else {
            $scope.themeMode = next;
        }
    };

    $scope.setMobileTab = function(tab) {
        const next = (tab === 'progress' || tab === 'leads') ? tab : 'home';
        $scope.mobileTab = next;
        $scope.mobileDataDrawerOpen = false;
        try { sessionStorage.setItem('pl_mobile_tab', next); } catch (_) {}
        if (next === 'leads') {
            refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
        }
    };

    $scope.openMobileDataGrid = function() {
        $scope.mobileDataDrawerOpen = true;
        if (!dataGrid || !productsStore) {
            buildDataTable($scope.local || {});
        } else if (productsStore && typeof productsStore.setRows === 'function') {
            productsStore.setRows(safeCollectRows($scope.local || {}));
        }
        syncGridLayoutSoon();
    };

    $scope.closeMobileDataGrid = function() {
        $scope.mobileDataDrawerOpen = false;
    };

    $scope.onMobileMainAction = function() {
        if ($scope.isStopEnabled) {
            $scope.manualStopScraping();
        } else {
            $scope.manualStartScraping();
            if ($scope.startLaunchPending || $scope.isScrapingActive()) {
                $scope.setMobileTab('progress');
            }
        }
    };

    if (typeof document !== 'undefined' && !document.documentElement.dataset.plViewControllerBound) {
        document.documentElement.dataset.plViewControllerBound = '1';
        document.addEventListener('pocketleads-view-mode-change', function(ev) {
            const next = (ev && ev.detail && ev.detail.viewMode) || 'desktop';
            $scope.$evalAsync(function() {
                $scope.viewMode = next;
                if (next === 'desktop') {
                    $scope.mobileDataDrawerOpen = false;
                    syncGridLayoutSoon();
                } else {
                    refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
                }
            });
        });
        document.addEventListener('pocketleads-theme-change', function(ev) {
            const next = (ev && ev.detail && ev.detail.theme) || 'dark';
            $scope.$evalAsync(function() {
                $scope.themeMode = next;
            });
        });
    }

    $scope.getCountryIsoCode = function(country) {
        const name = String(country || ($scope.local && $scope.local.country) || 'India').trim();
        const code = DASHBOARD_COUNTRY_CODES[name] || (typeof window !== 'undefined' && window.countryIsoCodes && window.countryIsoCodes[name]) || 'IN';
        return String(code || 'IN').toLowerCase();
    };

    $scope.getMobileStatusText = function() {
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const active = $scope.isScrapingActive() || !!$scope.startLaunchPending;
        if (active) {
            return 'Extracting business leads...';
        }
        const totalSaved = Number($scope.local && ($scope.local.resultStoreCount || ($scope.local.collect && $scope.local.collect.length))) || 0;
        const status = String(q.status || '').toLowerCase();
        if (status === 'stopped' || $scope.resumeAvailable) {
            return 'Extraction paused · Ready to resume';
        }
        if (totalSaved > 0 || /^(completed|completed_with_errors|dataset_saved)$/.test(status)) {
            return 'All business leads extracted';
        }
        return 'Ready to extract business leads';
    };

    $scope.getMobileProgressPercent = function() {
        const active = $scope.isScrapingActive();
        const p = Number($scope.progressData && $scope.progressData.percent);
        if (active) {
            return Number.isFinite(p) ? Math.max(0, Math.min(99, Math.round(p))) : 0;
        }
        if (Number.isFinite(p) && p > 0) {
            return Math.max(0, Math.min(100, Math.round(p)));
        }
        const totalSaved = Number($scope.local && ($scope.local.resultStoreCount || ($scope.local.collect && $scope.local.collect.length))) || 0;
        if (totalSaved > 0) return 100;
        return 0;
    };

    $scope.getDesktopRingDashoffset = function() {
        const circumference = 477.5;
        const pct = $scope.getMobileProgressPercent();
        return circumference - (circumference * (pct / 100));
    };

    $scope.getMobileRingDashoffset = function() {
        const circumference = 527.79; // 2 * Math.PI * 84
        const pct = $scope.getMobileProgressPercent();
        return circumference - (circumference * (pct / 100));
    };

    $scope.getLiveActiveQueryBanner = function() {
        const local = $scope.local || {};
        const q = local.apifyQueue || {};
        const active = $scope.isScrapingActive();
        const total = Math.max(0, parseInt(q.totalTasks || ($scope.progressData && $scope.progressData.total), 10) || 0);
        const currentIdx = Math.max(0, parseInt(q.currentTaskIndex || ($scope.progressData && $scope.progressData.currentTaskIndex) || q.completedTasks, 10) || 0);
        const query = String(q.currentQuery || local.activeQuery || '').trim();
        const stepPrefix = total > 0 && currentIdx > 0 ? `[${Math.min(total, currentIdx)}/${total}] ` : '';
        if (active && query) {
            return `Scraping ${stepPrefix}${query}`;
        }
        if (query && !/^(completed|completed_with_errors)$/i.test(String(q.status || ''))) {
            return `${stepPrefix}${query}`;
        }
        return q.statusMessage || ((local.resultStoreCount || (local.collect && local.collect.length)) ? 'All leads captured successfully' : 'Waiting for start');
    };

    $scope.getMobileProfilesProcessedText = function() {
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const saved = Number($scope.local && ($scope.local.resultStoreCount || ($scope.local.collect && $scope.local.collect.length))) || 0;
        const domDone = Math.max(0, parseInt(q.domProcessed || ($scope.progressData && $scope.progressData.domCompleted), 10) || 0);
        const domTotal = Math.max(0, parseInt(q.domTotal || ($scope.progressData && $scope.progressData.domTotal), 10) || 0);
        if (domTotal > 0 && String(q.provider || '').toLowerCase() === 'googlemaps') {
            return Math.min(domDone, domTotal) + ' / ' + domTotal;
        }
        const totalTasks = Math.max(0, parseInt(($scope.progressData && $scope.progressData.total) || q.totalTasks, 10) || 0);
        const doneTasks = Math.max(0, parseInt(($scope.progressData && $scope.progressData.completed) ?? q.completedTasks, 10) || 0);
        if (totalTasks > 0) {
            return `${saved} saved (${Math.min(totalTasks, doneTasks)}/${totalTasks} tasks)`;
        }
        return saved + ' / ' + saved;
    };

    $scope.getMobileKeywordsStatText = function() {
        const kwText = String(($scope.local && $scope.local.keywordTextarea) || '').trim();
        const kwList = Array.isArray($scope.local && $scope.local.keywordList) && $scope.local.keywordList.length
            ? $scope.local.keywordList.filter(Boolean)
            : (kwText ? kwText.split('\n').map(x => x.trim()).filter(Boolean) : []);
        const kwTotal = kwList.length;
        if (!kwTotal) return '0 / 0';
        const locText = String(($scope.local && $scope.local.locationTextarea) || '').trim();
        const locList = Array.isArray($scope.local && $scope.local.locationList) && $scope.local.locationList.length
            ? $scope.local.locationList.filter(Boolean)
            : (locText ? locText.split('\n').map(x => x.trim()).filter(Boolean) : []);
        const locTotal = Math.max(1, locList.length);
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const completedTasks = Math.max(0, parseInt(($scope.progressData && $scope.progressData.completed) ?? q.completedTasks, 10) || 0);
        const totalSaved = Number($scope.local && ($scope.local.resultStoreCount || ($scope.local.collect && $scope.local.collect.length))) || 0;
        if (!$scope.isScrapingActive() && ($scope.getMobileProgressPercent() >= 100 || /^(completed|completed_with_errors)$/i.test(String(q.status || ''))) && (totalSaved > 0 || completedTasks > 0)) {
            return kwTotal + ' / ' + kwTotal;
        }
        const kwDone = Math.floor(completedTasks / locTotal) + ($scope.isScrapingActive() || completedTasks > 0 ? 1 : 0);
        return Math.min(kwTotal, Math.max(0, completedTasks >= kwTotal * locTotal ? kwTotal : (completedTasks > 0 || $scope.isScrapingActive() ? kwDone : 0))) + ' / ' + kwTotal;
    };

    $scope.getMobileLocationsStatText = function() {
        const locText = String(($scope.local && $scope.local.locationTextarea) || '').trim();
        const locList = Array.isArray($scope.local && $scope.local.locationList) && $scope.local.locationList.length
            ? $scope.local.locationList.filter(Boolean)
            : (locText ? locText.split('\n').map(x => x.trim()).filter(Boolean) : []);
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const totalTasks = Math.max(0, parseInt(($scope.progressData && $scope.progressData.total) || q.totalTasks, 10) || 0);
        const locTotal = totalTasks || locList.length;
        if (!locTotal) return '0 / 0';
        const completedTasks = Math.max(0, parseInt(($scope.progressData && $scope.progressData.completed) ?? q.completedTasks, 10) || 0);
        const totalSaved = Number($scope.local && ($scope.local.resultStoreCount || ($scope.local.collect && $scope.local.collect.length))) || 0;
        if (!$scope.isScrapingActive() && ($scope.getMobileProgressPercent() >= 100 || /^(completed|completed_with_errors)$/i.test(String(q.status || ''))) && (totalSaved > 0 || completedTasks >= locTotal)) {
            return locTotal + ' / ' + locTotal;
        }
        return Math.min(locTotal, completedTasks) + ' / ' + locTotal;
    };

    $scope.getMobileRemainingText = function() {
        const q = ($scope.local && $scope.local.apifyQueue) || {};
        const domDone = Math.max(0, parseInt(q.domProcessed || ($scope.progressData && $scope.progressData.domCompleted), 10) || 0);
        const domTotal = Math.max(0, parseInt(q.domTotal || ($scope.progressData && $scope.progressData.domTotal), 10) || 0);
        if (domTotal > 0 && String(q.provider || '').toLowerCase() === 'googlemaps') {
            const rem = Math.max(0, domTotal - domDone);
            return rem + (rem === 1 ? ' profile remaining' : ' profiles remaining');
        }
        const pDone = Math.max(0, parseInt(q.completedTasks || ($scope.progressData && ($scope.progressData.completedSettled ?? $scope.progressData.completed)), 10) || 0);
        const pTotal = Math.max(0, parseInt(q.totalTasks || ($scope.progressData && $scope.progressData.total), 10) || 0);
        if (pTotal > pDone) {
            const rem = Math.max(0, pTotal - pDone);
            return rem + (rem === 1 ? ' task remaining' : ' tasks remaining');
        }
        return '0 tasks remaining';
    };

    function matchesMobileLeadQuery(row, qLower) {
        if (!qLower) return true;
        if (!row || typeof row !== 'object') return false;
        const hay = [
            row.company_name, row.name, row.title,
            rowPhoneValue(row),
            row.website, row.websiteUrl, row.url,
            row.address, row.city, row.location, row.pincode,
            row.email_1, row.email, row.category
        ].filter(Boolean).join(' ').toLowerCase();
        return hay.includes(qLower);
    }

    function refreshMobileLeadsView(sourceRows) {
        const rows = Array.isArray(sourceRows)
            ? sourceRows
            : (Array.isArray($scope.local && $scope.local.collect) ? $scope.local.collect : []);
        const storeCount = Number($scope.local && $scope.local.resultStoreCount) || 0;
        if ($scope.viewMode === 'mobile' && $scope.mobileTab !== 'leads' && PocketLeadsRunState.isRunning($scope.local)) {
            $scope.mobileTotalFilteredCount = Math.max(rows.length, storeCount);
            return;
        }
        const qLower = String($scope.mobileLeadSearch || '').trim().toLowerCase();
        const limit = Math.max(20, parseInt($scope.mobileLeadLimit, 10) || 40);
        const filtered = qLower ? rows.filter(r => matchesMobileLeadQuery(r, qLower)) : rows;
        $scope.mobileTotalFilteredCount = qLower ? filtered.length : Math.max(filtered.length, storeCount);
        $scope.mobileVisibleLeads = filtered.slice(0, limit);

        // If preview mode is active and user searches or requests beyond in-memory preview, query canonical IndexedDB
        if ($scope.local && $scope.local.collectIsPreview && (qLower || limit > rows.length)) {
            if (mobileSearchTimer) clearTimeout(mobileSearchTimer);
            mobileSearchTimer = setTimeout(async function() {
                mobileSearchTimer = null;
                try {
                    const res = await runtimeMessageAsync({
                        action: 'result_store_query',
                        query: { query: qLower, offset: 0, limit: limit }
                    });
                    if (res && res.ok && Array.isArray(res.rows)) {
                        $scope.$evalAsync(function() {
                            $scope.mobileVisibleLeads = res.rows;
                            if (Number.isFinite(res.count)) {
                                $scope.mobileTotalFilteredCount = res.count;
                            }
                        });
                    }
                } catch (_) {}
            }, 180);
        }
    }

    $scope.onMobileLeadSearchChange = function() {
        $scope.mobileLeadLimit = 40;
        refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
    };

    $scope.clearMobileLeadSearch = function() {
        $scope.mobileLeadSearch = '';
        $scope.mobileLeadLimit = 40;
        refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
    };

    $scope.loadMoreMobileLeads = function() {
        $scope.mobileLeadLimit = (parseInt($scope.mobileLeadLimit, 10) || 40) + 40;
        refreshMobileLeadsView(($scope.local && $scope.local.collect) || []);
    };

    $scope.getMobileLeadTrackKey = function(row, index) {
        if (!row || typeof row !== 'object') return 'm_lead_' + index;
        return String(ensureDashboardRowKey(row, index) || ('m_lead_' + index));
    };

    $scope.getMobileLeadTitle = function(row) {
        if (!row) return 'Unnamed Business';
        return String(row.company_name || row.name || row.title || 'Unnamed Business').trim();
    };

    $scope.getMobileLeadInitial = function(row) {
        const title = $scope.getMobileLeadTitle(row);
        const match = title.match(/[A-Za-z0-9]/);
        return match ? match[0].toUpperCase() : 'B';
    };

    const MOBILE_AVATAR_PALETTE = [
        '#8a4f38', '#255f85', '#6c3b8c', '#1e6b52', '#9c4221', '#3b4d71', '#7c3aed', '#0f766e'
    ];
    $scope.getMobileLeadAvatarBg = function(row) {
        const title = $scope.getMobileLeadTitle(row);
        let hash = 0;
        for (let i = 0; i < title.length; i++) {
            hash = ((hash << 5) - hash) + title.charCodeAt(i);
            hash |= 0;
        }
        return MOBILE_AVATAR_PALETTE[Math.abs(hash) % MOBILE_AVATAR_PALETTE.length];
    };

    $scope.getMobileLeadImage = function(row) {
        if (!row || typeof row !== 'object') return '';
        const candidate = String(row.image || row.photo || row.thumbnail || row.featured_image || row.imageUrl || row.photoUrl || row.mainPhoto || '').trim();
        return /^https?:\/\//i.test(candidate) ? candidate : '';
    };

    $scope.getMobileLeadLocation = function(row) {
        if (!row || typeof row !== 'object') return 'Location not available';
        const city = String(row.city || '').trim();
        const loc = String(row.location || '').trim();
        const addr = String(row.address || row.formattedAddress || row.fullAddress || '').trim();
        if (addr) {
            const parts = addr.split(',').map(s => s.trim()).filter(Boolean);
            if (parts.length >= 2) {
                const tail = parts.slice(-3, -1).join(', ') || parts.slice(0, 2).join(', ');
                if (tail.length <= 42) return tail;
            }
            return addr.length > 44 ? (addr.slice(0, 42) + '…') : addr;
        }
        if (loc && city && loc.toLowerCase() !== city.toLowerCase()) return loc + ', ' + city;
        return city || loc || 'Location not listed';
    };

    $scope.getMobileLeadPhone = function(row) {
        if (!row || typeof row !== 'object') return '';
        const raw = String(rowPhoneValue(row) || '').trim();
        return raw;
    };

    $scope.getMobileLeadWebsite = function(row) {
        if (!row || typeof row !== 'object') return '';
        const raw = String(row.website || row.websiteUrl || row.url || '').trim();
        if (!raw || /^(no website|n\/a|—|-)$/i.test(raw)) return '';
        return raw.replace(/^https?:\/\//i, '').replace(/\/+$/, '');
    };

    $scope.getMobileLeadWebsiteHref = function(row) {
        if (!row || typeof row !== 'object') return '#';
        const raw = String(row.website || row.websiteUrl || row.url || '').trim();
        if (!raw) return '#';
        return /^https?:\/\//i.test(raw) ? raw : ('https://' + raw);
    };

    $scope.getMobileLeadWaState = function(row) {
        if (!row || typeof row !== 'object') return 'unchecked';
        const st = String(row.whatsapp_status || row.wa_status || '').trim().toLowerCase();
        if (!st) return 'unchecked';
        if (/^(available|valid|verified|yes|true|registered|active|on whatsapp)$/.test(st)) return 'verified';
        if (/^(not available|not_available|invalid|not found|not_found|no|false|unregistered|failed|no result|cancelled)$/.test(st)) return 'not_found';
        if (/checking|queued|pending|started|running|api/.test(st)) return 'checking';
        return 'unchecked';
    };

    $scope.getMobileLeadWaLabel = function(row) {
        const state = $scope.getMobileLeadWaState(row);
        if (state === 'verified') return 'WhatsApp Verified';
        if (state === 'not_found') return 'WhatsApp Not Found';
        if (state === 'checking') return 'Checking WA...';
        return 'WA Unchecked';
    };

    $scope.getMobileLeadEmailCount = function(row) {
        if (!row || typeof row !== 'object') return 0;
        const found = new Set();
        ['email_1', 'email_2', 'email_3', 'email', 'emailAddress', 'emails'].forEach(k => {
            const val = String(row[k] || '').trim();
            if (!val || /^(no email|can't access|blacklisted)/i.test(val)) return;
            val.split(/[;,\s]+/).forEach(part => {
                const clean = part.trim().toLowerCase();
                if (clean.includes('@') && clean.includes('.')) found.add(clean);
            });
        });
        return found.size;
    };

    $scope.getMobileLeadEmailLabel = function(row) {
        const count = $scope.getMobileLeadEmailCount(row);
        return count + (count === 1 ? ' Email' : ' Emails');
    };

    $scope.getMobileLeadEmailsTooltip = function(row) {
        if (!row || typeof row !== 'object') return 'No emails extracted yet';
        const em = String(row.email_1 || row.email || '').trim();
        return em || 'Run Email / Social Scrape to extract emails';
    };

    $scope.getMobileLeadSocialCount = function(row) {
        if (!row || typeof row !== 'object') return 0;
        const found = new Set();
        ['facebook', 'instagram', 'linkedin', 'twitter', 'youtube'].forEach(k => {
            const val = String(row[k] || '').trim();
            if (!val || /^(none|n\/a|—|-)$/i.test(val)) return;
            val.split(/[;,\s]+/).forEach(part => {
                const clean = part.trim().toLowerCase();
                if (clean && (clean.startsWith('http') || clean.includes('.com') || clean.includes('.in') || clean.length > 3)) {
                    found.add(k + ':' + clean);
                }
            });
        });
        return found.size;
    };

    $scope.getMobileLeadSocialLabel = function(row) {
        const count = $scope.getMobileLeadSocialCount(row);
        return count + ' Social';
    };

    /* --------------------------------------------------------------------
     * Scraping History
     * Stores a compact snapshot of each completed/stopped scraping session
     * in chrome.storage via the existing local model. The History button
     * opens a modal with View, CSV, Excel and Delete actions.
     */
    $scope.historyModal = {
        show: false,
        search: '',
        fromDate: '',
        toDate: '',
        viewSession: null,
        viewPage: 1,
        viewPageSize: 25
    };

    function clonePlain(obj) {
        try { return JSON.parse(JSON.stringify(obj || null)); } catch (e) { return obj; }
    }

    function normaliseDateInput(value, endOfDay) {
        if (!value) return null;
        let d = value instanceof Date ? new Date(value.getTime()) : new Date(String(value));
        if (!isNaN(d.getTime())) {
            if (endOfDay) d.setHours(23, 59, 59, 999);
            else d.setHours(0, 0, 0, 0);
            return d.getTime();
        }
        const m = String(value).trim().match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/);
        if (m) {
            d = new Date(parseInt(m[3], 10), parseInt(m[2], 10) - 1, parseInt(m[1], 10));
            if (endOfDay) d.setHours(23, 59, 59, 999);
            return d.getTime();
        }
        return null;
    }

    function historyFileDate(session) {
        const d = new Date(session && (session.timestamp || session.finishedAt || session.startedAt) || Date.now());
        const pad = n => String(n).padStart(2, '0');
        return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + '_' + pad(d.getHours()) + pad(d.getMinutes());
    }

    function saveBlobDownload(blob, filename) {
        const a = document.createElement('a');
        document.body.appendChild(a);
        a.style = 'display:none';
        const url = window.URL.createObjectURL(blob);
        a.href = url;
        a.download = filename;
        a.click();
        setTimeout(() => {
            try { window.URL.revokeObjectURL(url); } catch (e) {}
            try { a.remove(); } catch (e) {}
        }, 300);
    }

    const EMPTY_HISTORY_ROWS = Object.freeze([]);
    function getRowsFromHistory(session) {
        // Angular's ngRepeat compares row identities every digest. Cloning here
        // created 25 new objects on every pass and exhausted its ten-pass TTL.
        // Clone only at the explicit edit/restore boundary, never in a getter.
        return (session && Array.isArray(session.rows)) ? session.rows : EMPTY_HISTORY_ROWS;
    }

    async function loadHistorySessionRows(session) {
        if (!session || !session.id) return session || null;
        if (Array.isArray(session.rows) && session.rows.length) return session;
        const response = await runtimeMessageAsync({ action: 'scrape_history_get', id: session.id });
        if (response && response.session) return response.session;
        return session;
    }

    function buildCsvFromRows(rows, selectedLabels) {
        rows = Array.isArray(rows) ? rows : [];
        const labels = Array.isArray(selectedLabels) && selectedLabels.length ? selectedLabels : refreshColumnList(rows);
        let CSV = '';
        if (labels.length) {
            CSV += labels.map(label => {
                let header;
                try { header = (typeof FoxCommon !== 'undefined' && FoxCommon.getKeyFromMap) ? FoxCommon.getKeyFromMap(label) : undefined; } catch (e) { header = undefined; }
                if (!header || header === label) header = FoxCommon.downloadAs.keyToColumnHeader(label);
                return '"' + String(header).replace(/"/g, '""') + '"';
            }).join(',') + '\r\n';
        }
        rows.forEach(row => {
            CSV += labels.map(label => {
                let value = exportValueFor(row, label);
                if (label === 'map_link' && value) value = '=HYPERLINK("' + value + '","' + value + '")';
                return '"' + String(value).replace(/"/g, '""') + '"';
            }).join(',') + '\r\n';
        });
        return CSV;
    }

    function buildExcelHtmlFromRows(rows, selectedLabels) {
        rows = Array.isArray(rows) ? rows : [];
        const labels = Array.isArray(selectedLabels) && selectedLabels.length ? selectedLabels : refreshColumnList(rows);
        const esc = value => String(value === null || typeof value === 'undefined' ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        let html = '<html><head><meta charset="utf-8"></head><body><table border="1"><thead><tr>';
        labels.forEach(label => {
            let header;
            try { header = (typeof FoxCommon !== 'undefined' && FoxCommon.getKeyFromMap) ? FoxCommon.getKeyFromMap(label) : undefined; } catch (e) { header = undefined; }
            if (!header || header === label) header = FoxCommon.downloadAs.keyToColumnHeader(label);
            html += '<th>' + esc(header) + '</th>';
        });
        html += '</tr></thead><tbody>';
        rows.forEach(row => {
            html += '<tr>';
            labels.forEach(label => {
                const value = exportValueFor(row, label);
                if (label === 'map_link' && value) {
                    html += '<td><a href="' + esc(value) + '">' + esc(value) + '</a></td>';
                } else {
                    html += '<td>' + esc(value) + '</td>';
                }
            });
            html += '</tr>';
        });
        html += '</tbody></table></body></html>';
        return html;
    }

    $scope.ensureScrapingHistory = () => {
        if (!$scope.local) $scope.local = {};
        if (!Array.isArray($scope.local._scrapeHistory)) $scope.local._scrapeHistory = [];
        return $scope.local._scrapeHistory;
    };

    $scope.saveScrapingHistory = () => {
        const history = $scope.ensureScrapingHistory();
        $scope.local._scrapeHistory = history.slice(0, 50);
        $scope.saveLocal();
        // Notes/status metadata are kept in IndexedDB without overwriting the
        // full session rows stored there.
        history.forEach(session => {
            if (!session || !session.id) return;
            try {
                chrome.runtime.sendMessage({ action: 'scrape_history_update_meta', id: session.id, patch: {
                    note: session.note || '', status: session.status || '', timestamp: session.timestamp || '',
                    finishedAt: session.finishedAt || '', startedAt: session.startedAt || ''
                }}, function() { try { void chrome.runtime.lastError; } catch (e) {} });
            } catch (e) {}
        });
    };

    $scope.recordScrapingHistory = (status, persist) => {
        try {
            const rows = Array.isArray($scope.local.collect) ? clonePlain($scope.local.collect) : [];
            if (!rows.length) return;
            const now = new Date().toISOString();
            const startedAt = ($scope.local.apifyQueue && $scope.local.apifyQueue.startedAt) || $scope.local.scrapeStartedAt || now;
            const finishedAt = now;
            const id = 'session_' + Date.parse(startedAt || now) + '_' + rows.length;
            const keywords = Array.isArray($scope.local.keywordList) ? clonePlain($scope.local.keywordList) : [];
            const locations = Array.isArray($scope.local.locationList) ? clonePlain($scope.local.locationList) : [];
            const existing = $scope.ensureScrapingHistory().find(x => x && x.id === id);
            const fullSession = Object.assign({}, existing || {}, {
                id,
                status: status || 'saved',
                timestamp: finishedAt,
                startedAt,
                finishedAt,
                elapsedMs: Date.parse(finishedAt) - Date.parse(startedAt || finishedAt),
                note: existing && existing.note ? existing.note : '',
                rows,
                leadCount: rows.length,
                rowCount: rows.length,
                keywords,
                locations,
                keywordCount: keywords.length || Math.max(1, (rows[0] && rows[0].keyword) ? 1 : 0),
                locationCount: locations.length
            });
            // Keep the local snapshot small. Full rows are durable in IndexedDB.
            const compactSession = Object.assign({}, fullSession, { rows: [], hasRows: true });
            const history = $scope.ensureScrapingHistory();
            const idx = history.findIndex(x => x && x.id === id);
            if (idx >= 0) history[idx] = Object.assign({}, history[idx], compactSession);
            else history.unshift(compactSession);
            $scope.local._scrapeHistory = history.slice(0, 50);
            try {
                chrome.runtime.sendMessage({ action: 'scrape_history_put', session: fullSession }, function() { try { void chrome.runtime.lastError; } catch (e) {} });
            } catch (e) {}
            if (persist !== false) $scope.saveLocal();
        } catch (err) {
            console.warn('recordScrapingHistory failed', err);
        }
    };

    $scope.openScrapingHistory = () => {
        $scope.ensureScrapingHistory();
        $scope.historyModal.viewSession = null;
        $scope.historyModal.viewPage = 1;
        $scope.historyModal.show = true;
        $scope.refreshScrapingHistory();
    };
    $scope.closeScrapingHistory = () => {
        $scope.historyModal.show = false;
        $scope.historyModal.viewSession = null;
        $scope.historyModal.viewPage = 1;
    };
    $scope.applyHistoryFilter = () => { /* model-bound filters apply automatically */ };
    $scope.clearHistoryFilter = () => {
        $scope.historyModal.search = '';
        $scope.historyModal.fromDate = '';
        $scope.historyModal.toDate = '';
        $scope.historyModal.viewSession = null;
        $scope.historyModal.viewPage = 1;
    };
    $scope.refreshScrapingHistory = () => {
        $scope.historyModal.loading = true;
        try {
            $box.getLocal(local => {
                let localMeta = local && Array.isArray(local._scrapeHistory) ? local._scrapeHistory : [];
                // Recover a session for older builds that saved result rows but
                // never created a history snapshot. This is only done while idle.
                if (!localMeta.length && local && Array.isArray(local.collect) && local.collect.length && !local.status && !(local._taskManager && local._taskManager.isWorking)) {
                    try { $scope.recordScrapingHistory('recovered', false); } catch (e) {}
                    localMeta = $scope.ensureScrapingHistory();
                }
                $scope.$evalAsync(() => { if (localMeta.length) $scope.local._scrapeHistory = localMeta; });
                try {
                    chrome.runtime.sendMessage({ action: 'scrape_history_get_all' }, response => {
                        try { void chrome.runtime.lastError; } catch (e) {}
                        $scope.$evalAsync(() => {
                            const stored = response && response.ok && Array.isArray(response.sessions) ? response.sessions : [];
                            const byId = new Map();
                            const currentMeta = $scope.ensureScrapingHistory();
                            currentMeta.concat(localMeta, stored).forEach(session => {
                                if (!session || !session.id) return;
                                const prior = byId.get(String(session.id)) || {};
                                byId.set(String(session.id), Object.assign({}, prior, session, {
                                    note: session.note || prior.note || '',
                                    rowCount: session.rowCount || (Array.isArray(session.rows) ? session.rows.length : session.leadCount || prior.rowCount || 0)
                                }));
                            });
                            $scope.local._scrapeHistory = Array.from(byId.values()).sort((a,b) => String(b.timestamp || '').localeCompare(String(a.timestamp || ''))).slice(0, 50);
                            if (!stored.length) {
                                localMeta.filter(session => session && session.id && Array.isArray(session.rows) && session.rows.length).forEach(session => {
                                    try { chrome.runtime.sendMessage({ action: 'scrape_history_put', session }, function() { try { void chrome.runtime.lastError; } catch (e) {} }); } catch (e) {}
                                });
                            }
                            $scope.historyModal.loading = false;
                        });
                    });
                } catch (e) { $scope.$evalAsync(() => { $scope.historyModal.loading = false; }); }
            });
        } catch (err) { $scope.historyModal.loading = false; console.warn('refreshScrapingHistory failed', err); }
    };
    $scope.getFilteredScrapingHistory = () => {
        const search = String($scope.historyModal.search || '').trim().toLowerCase();
        const fromMs = normaliseDateInput($scope.historyModal.fromDate, false);
        const toMs = normaliseDateInput($scope.historyModal.toDate, true);
        return $scope.ensureScrapingHistory().filter(session => {
            const stamp = Date.parse(session.timestamp || session.finishedAt || session.startedAt || '') || 0;
            if (fromMs && stamp < fromMs) return false;
            if (toMs && stamp > toMs) return false;
            if (search) {
                const hay = [session.note, session.name, (session.keywords || []).join(' '), (session.locations || []).join(' ')].join(' ').toLowerCase();
                if (!hay.includes(search)) return false;
            }
            return true;
        });
    };
    $scope.formatHistoryDate = value => {
        const d = new Date(value || Date.now());
        if (isNaN(d.getTime())) return '';
        return d.toLocaleString();
    };
    $scope.getHistoryLeadCount = session => {
        if (!session) return 0;
        if (session.leadCount) return session.leadCount;
        return Array.isArray(session.rows) ? session.rows.length : 0;
    };
    $scope.viewHistorySession = session => {
        $scope.historyModal.viewPage = 1;
        $scope.historyModal.loadingRows = true;
        loadHistorySessionRows(session).then(fullSession => {
            $scope.$evalAsync(() => {
                $scope.historyModal.viewSession = fullSession || session || null;
                $scope.historyModal.loadingRows = false;
            });
        }).catch(() => {
            $scope.$evalAsync(() => { $scope.historyModal.viewSession = session || null; $scope.historyModal.loadingRows = false; });
        });
    };
    $scope.backToHistoryList = () => {
        $scope.historyModal.viewSession = null;
        $scope.historyModal.viewPage = 1;
    };
    $scope.restoreHistorySessionToDashboard = async session => {
        const fullSession = await loadHistorySessionRows(session);
        const rows = getRowsFromHistory(fullSession);
        if (!rows.length) {
            try { $scope.snackbar.show('History rows are not available for this session.'); } catch (e) {}
            return;
        }
        $scope.local.collect = clonePlain(rows);
        if (Array.isArray(fullSession && fullSession.keywords)) {
            $scope.local.keywordList = clonePlain(fullSession.keywords);
            $scope.local.keywordTextarea = fullSession.keywords.join('\n');
        }
        if (Array.isArray(fullSession && fullSession.locations)) {
            $scope.local.locationList = clonePlain(fullSession.locations);
            $scope.local.locationTextarea = fullSession.locations.join('\n');
        }
        $scope.saveLocal();
        lastCollectDataCount = 0;
        buildDataTable();
        insertIntoDataTable($scope.local);
        updateDataTable($scope.local);
        $scope.historyModal.show = false;
        $scope.historyModal.viewSession = null;
    };

    $scope.getHistoryViewRows = () => getRowsFromHistory($scope.historyModal.viewSession);
    $scope.getHistoryViewColumns = () => {
        const rows = $scope.getHistoryViewRows();
        return buildColumnListFromRows(rows).filter(key => rows.some(row => row && row[key] !== undefined && row[key] !== null && row[key] !== '') || baseColumnList.includes(key));
    };
    $scope.getHistoryViewPageRows = () => {
        const rows = $scope.getHistoryViewRows();
        const size = parseInt($scope.historyModal.viewPageSize, 10) || 25;
        const page = Math.max(1, parseInt($scope.historyModal.viewPage, 10) || 1);
        return rows.slice((page - 1) * size, page * size);
    };
    $scope.historyViewTotalPages = () => {
        const rows = $scope.getHistoryViewRows();
        const size = parseInt($scope.historyModal.viewPageSize, 10) || 25;
        return Math.max(1, Math.ceil(rows.length / size));
    };
    $scope.historyViewRangeLabel = () => {
        const rows = $scope.getHistoryViewRows();
        if (!rows.length) return 'No leads';
        const size = parseInt($scope.historyModal.viewPageSize, 10) || 25;
        const page = Math.max(1, Math.min($scope.historyViewTotalPages(), parseInt($scope.historyModal.viewPage, 10) || 1));
        const start = ((page - 1) * size) + 1;
        const end = Math.min(rows.length, page * size);
        return 'Showing ' + start + '-' + end + ' of ' + rows.length + ' leads';
    };
    $scope.historyViewNextPage = () => {
        const total = $scope.historyViewTotalPages();
        $scope.historyModal.viewPage = Math.min(total, (parseInt($scope.historyModal.viewPage, 10) || 1) + 1);
    };
    $scope.historyViewPrevPage = () => {
        $scope.historyModal.viewPage = Math.max(1, (parseInt($scope.historyModal.viewPage, 10) || 1) - 1);
    };
    $scope.getHistoryCell = (row, col) => {
        const value = row && row[col];
        if (value === null || typeof value === 'undefined') return '';
        if (typeof value === 'object') {
            try { return JSON.stringify(value); } catch (e) { return ''; }
        }
        return String(value);
    };
    $scope.historyColumnHeader = col => {
        try {
            const mapped = (typeof FoxCommon !== 'undefined' && FoxCommon.getKeyFromMap) ? FoxCommon.getKeyFromMap(col) : '';
            if (mapped && mapped !== col) return mapped;
            return FoxCommon.downloadAs.keyToColumnHeader(col);
        } catch (e) {
            return String(col || '').replace(/_/g, ' ').replace(/\b\w/g, m => m.toUpperCase());
        }
    };
    $scope.downloadHistorySheets = session => $scope.restoreHistorySessionToDashboard(session);
    $scope.downloadHistoryCsv = async session => {
        const fullSession = await loadHistorySessionRows(session);
        const rows = getRowsFromHistory(fullSession);
        if (!rows.length || !await allowExportRows(rows.length)) return;
        const csv = buildCsvFromRows(rows);
        saveBlobDownload(new Blob([csv], { type: 'text/csv;charset=utf-8' }), 'PocketLeads_History_' + historyFileDate(fullSession || session) + '.csv');
    };
    $scope.downloadHistoryExcel = async session => {
        const fullSession = await loadHistorySessionRows(session);
        const rows = getRowsFromHistory(fullSession);
        if (!rows.length || !await allowExportRows(rows.length)) return;
        const html = buildExcelHtmlFromRows(rows);
        saveBlobDownload(new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8' }), 'PocketLeads_History_' + historyFileDate(fullSession || session) + '.xls');
    };
    $scope.deleteHistorySession = session => {
        const id = session && session.id;
        if (!id) return;
        $scope.local._scrapeHistory = $scope.ensureScrapingHistory().filter(x => x && x.id !== id);
        $scope.saveLocal();
        try { chrome.runtime.sendMessage({ action: 'scrape_history_delete', id }, function() { try { void chrome.runtime.lastError; } catch (e) {} }); } catch (e) {}
    };
    $scope.deleteAllScrapingHistory = () => {
        $scope.local._scrapeHistory = [];
        $scope.saveLocal();
        try { chrome.runtime.sendMessage({ action: 'scrape_history_clear' }, function() { try { void chrome.runtime.lastError; } catch (e) {} }); } catch (e) {}
    };
    // Backward-compatible alias for old Clear History button references.
    $scope.clearHistory = () => $scope.openScrapingHistory();

    /**
     * Close the current search tab if it exists.  The TaskManager stores
     * the tab ID under _taskManager.searchTabId.  This helper can be
     * called from stop, clear, or completion handlers to ensure that
     * background tabs opened for scraping are cleaned up.  After
     * removing the tab the stored ID is reset and persisted.
     */
    $scope.closeSearchTab = () => {
        try {
            const id = $scope.local && $scope.local._taskManager && $scope.local._taskManager.searchTabId;
            if (id && chrome && chrome.tabs && typeof chrome.tabs.remove === 'function') {
                // Only attempt to remove the tab if the ID appears to be a valid number
                const tabId = Number(id);
                if (!isNaN(tabId) && tabId > 0) {
                    chrome.tabs.remove(tabId, function() {
                        if (chrome.runtime && chrome.runtime.lastError) {
                            const err = chrome.runtime.lastError;
                            const msg = err && (err.message || String(err));
                            // Suppress the common "No tab with id" error silently
                            if (!msg || msg.indexOf('No tab with id') === -1) {
                                console.warn('closeSearchTab: tab remove error', msg);
                            }
                        }
                    });
                }
                // Reset the stored ID and persist the update
                $scope.local._taskManager.searchTabId = null;
                $scope.saveLocal();
            }
        } catch (err) {
            console.warn('closeSearchTab: failed to close search tab', err);
        }
    };
    
    /* -------------------------------- Material Design -------------------------------- */
    $scope.initiMaterialDesignComponents = () => {
        MaterialDesignLite.init();
    };
    $scope.initiMaterialDesignComponents();
    /* -------------------------------- Material Design -------------------------------- */
    
    /* ---------------------------------- Login (Removed) --------------------------------- */
    // The original extension supported activating the full version via a license key.
    // For this open build we do not implement licensing.  The login and logout
    // handlers have been removed to avoid misleading UI and unused logic.  If the
    // user triggers these actions (e.g., via leftover UI elements), simply show
    // a snackbar message indicating that licensing is not required.
    $scope.login = () => {
        /*
         * The login handler is kept as a no‑op because the extension
         * automatically operates in full mode once a valid licence has been
         * activated.  There is no separate account login required.  If the
         * user somehow triggers the login action we simply inform them
         * that no login is necessary.
         */
        $scope.snackbar.show("No login required – activate your licence to use all features.");
    };

    /**
     * Release the currently stored licence key.  When invoked from the
     * Settings menu this function calls the globally defined
     * releaseLicenceInternal() helper to notify the Apps Script backend
     * and clear the local licence record.  After a successful release
     * the licence activation modal is displayed again so the user can
     * enter a new key if desired.  Errors are surfaced via the snackbar.
     */
    $scope.logout = () => {
        try {
            if (!window.confirm('Log out and release this licence from this device?')) return;
            $scope.snackbar.show("Releasing licence…");
            // Invoke the helper exposed on the window to release the licence
            const releasePromise = (typeof window.releaseLicenceInternal === 'function')
                ? window.releaseLicenceInternal()
                : Promise.reject(new Error('Release helper not available'));
            releasePromise.then(() => {
                // Clear local state; storage listener will update UI
                // Show the activation modal again for convenience
                if (typeof window.showLicenseModal === 'function') {
                    window.showLicenseModal();
                }
                $scope.snackbar.show("Licence released successfully");
            }).catch((err) => {
                console.error('Error releasing licence via logout()', err);
                $scope.snackbar.show("Failed to release licence. Please try again.");
            });
        } catch (err) {
            console.error('Unexpected error during licence logout', err);
            $scope.snackbar.show("Failed to release licence. Please try again.");
        }
    };
    
    /* -------------------------------- Snackbar -------------------------------- */
    $scope.snackbar = {
        isShown : false,
        text: '',
        show:(text,closeAfterSec=3)=>{
            $scope.snackbar.text = text;
            $scope.snackbar.isShown = true;
            $scope.snackbar.closeAfter(closeAfterSec);
        },
        hide:()=>{
            $scope.snackbar.isShown = false;
        },
        closeAfter :(closeAfterSec)=>{
            setTimeout(()=>{
                $scope.$apply(()=>{
                    $scope.snackbar.isShown = false;
                });
            },closeAfterSec*1000);
        }
    };
    /* -------------------------------- Snackbar -------------------------------- */

    /* -------------------------------- Captcha/Error Popup -------------------------------- */

    /* -------------------------------- Completion Popup -------------------------------- */
    // Define a completion modal object.  When scraping finishes we display this
    // modal to inform the user.  It mirrors the captcha popup styling and
    // behaviour.  The message can be customized when invoking
    // showCompletePopup().
    $scope.completePopup = {
        show: false,
        message: ''
    };
    /**
     * Display the completion popup with a given message.  Called when
     * scraping completes successfully.  The popup is dismissed via
     * closeCompletePopup().
     * @param {string} msg - The message to display in the popup.
     */
    $scope.showCompletePopup = (msg) => {
        $scope.completePopup.message = msg || 'Scraping completed successfully!';
        $scope.completePopup.show = true;
    };
    /**
     * Hide the completion popup.  Bound to the close button on the
     * modal.
     */
    $scope.closeCompletePopup = () => {
        $scope.completePopup.show = false;
    };
    // Show a dedicated popup for captcha or scraping errors.  This
    // modal remains visible until the user manually closes it.  It is
    // toggled via the scraping_error event handler below.
    $scope.captchaPopup = {
        show: false,
        title: 'Attention Required',
        message: '',
        upgrade: false,
        supportEmail: PocketLeadsConfig.supportEmail
    };
    /**
     * Display the captcha/error popup with a given message.  Call this
     * function when an error is detected (e.g., captcha or unusual
     * traffic).  The popup is dismissed via closeCaptchaPopup().
     * @param {string} msg - The message to display in the popup.
     */
    $scope.refreshCreditBalance = async () => {
        $scope.captchaPopup.refreshMessage = 'Refreshing balance...';
        try {
            await PocketLeadsAccount.refresh();
            const state = await new Promise(resolve=>chrome.storage.local.get('pocketleadsAccount',resolve));
            const a=state.pocketleadsAccount || {};
            $scope.safeApply(()=>{
                $scope.captchaPopup.availableCredit=a.availableCredit;
                $scope.captchaPopup.purchasedCredit=a.purchasedCredit;
                $scope.captchaPopup.refreshMessage = a.syncState === 'ready' ? 'Balance updated. Close this window and Resume to continue.' : 'Refresh unavailable. Please retry.';
            });
        } catch(e) { $scope.safeApply(()=>{$scope.captchaPopup.refreshMessage='Refresh failed. Please retry.';}); }
    };
    $scope.showCaptchaPopup = (msg, options) => {
        options = options || {};
        $scope.captchaPopup.message = msg || 'An unexpected error occurred.';
        $scope.captchaPopup.title = options.title || 'Attention Required';
        $scope.captchaPopup.upgrade = !!options.upgrade;
        $scope.captchaPopup.supportEmail = options.supportEmail || PocketLeadsConfig.supportEmail;
        $scope.captchaPopup.purchaseUrl = 'mailto:' + $scope.captchaPopup.supportEmail + '?subject=PocketLeads%20Buy%20Credits';
        chrome.storage.local.get('pocketleadsAccount', function(res) {
            const a=res.pocketleadsAccount || {};
            $scope.safeApply(function(){
                $scope.captchaPopup.availableCredit=a.availableCredit;
                $scope.captchaPopup.purchasedCredit=a.purchasedCredit;
                if (/^https:\/\//i.test(a.purchaseUrl || '')) $scope.captchaPopup.purchaseUrl=a.purchaseUrl;
            });
        });
        $scope.captchaPopup.show = true;
    };
    /**
     * Hide the captcha/error popup.  Bound to the close button on the
     * modal.
     */
    // If the hidden preflight completed before Angular finished creating the
    // popup helpers, surface commercial blocks now. This means zero credits can
    // show Upgrade Required immediately after opening the extension, before Start.
    try {
        chrome.storage.local.get('pocketleadsPreflightState', function(res){
            const state = (res && res.pocketleadsPreflightState) || $scope.pendingPreflightCommercialState || {};
            const code = String(state.errorCode || '').toUpperCase();
            const upgrade = !!state.upgradeRequired || /LICENSE_(?:EXPIRED|CREDIT_EXHAUSTED)|LICENCE_(?:EXPIRED|CREDIT_EXHAUSTED)|ALL_CREDITS_EXHAUSTED/.test(code);
            if (upgrade && String(state.status || '') === 'error') {
                $scope.safeApply(function(){
                    const msg = /CREDIT/.test(code)
                        ? 'Your scraping credits are exhausted. Upgrade your plan to continue. Contact ' + (state.supportEmail || PocketLeadsConfig.supportEmail) + '.'
                        : 'Your licence has expired. Contact ' + (state.supportEmail || PocketLeadsConfig.supportEmail) + ' to renew your licence.';
                    $scope.showCaptchaPopup(msg, { title:'Upgrade Required', upgrade:true, supportEmail:state.supportEmail || PocketLeadsConfig.supportEmail });
                });
            }
            $scope.pendingPreflightCommercialState = null;
        });
    } catch (e) {}

    $scope.closeCaptchaPopup = () => {
        // Hide the captcha/error modal
        $scope.captchaPopup.show = false;
        $scope.captchaPopup.upgrade = false;
        $scope.captchaPopup.title = 'Attention Required';
        // Reset any suppression so future stop notifications can fire
        $scope.ignoreNextStopNotification = false;
        // Refresh UI state to re-enable controls after solving captcha
        if (typeof $scope.updateUIState === 'function') {
            $scope.updateUIState();
        }
    };

    /* ------------------------ Expiring Licence & Low Credit Popup ------------------------ */
    const EXPIRING_LICENCE_CREDIT_LIMIT = 1000;
    const EXPIRING_LICENCE_DAYS_LIMIT = 3;
    $scope._expiringPopupDismissedSig = '';
    $scope.expiringPopup = {
        show: false,
        kicker: 'EXPIRING LICENCE ALERT',
        title: 'Expiring Licence Warning',
        message: '',
        isLowCredit: false,
        isExpiringSoon: false,
        remainingCredits: null,
        remainingCreditsText: '—',
        daysLeft: null,
        daysLeftText: 'Active',
        expiryDateText: 'Unlimited',
        supportEmail: PocketLeadsConfig.supportEmail,
        purchaseUrl: 'mailto:' + PocketLeadsConfig.supportEmail + '?subject=PocketLeads%20Licence%20Renewal%20%26%20Credits',
        refreshMessage: ''
    };

    function parseExpiryDateLocalEnd(rawDate) {
        if (!rawDate) return null;
        const text = String(rawDate).trim();
        if (!text || /^(unlimited|lifetime|permanent|none|no\s*expiry|no\s*limit)$/i.test(text)) return null;
        let m = text.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
        if (m) return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), 23, 59, 59, 999);
        m = text.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
        if (m) return new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]), 23, 59, 59, 999);
        const parsed = new Date(text);
        if (isNaN(parsed.getTime())) return null;
        parsed.setHours(23, 59, 59, 999);
        return parsed;
    }

    function resolveRemainingLicenceCredits(account, license, route) {
        const candidates = [
            account && account.availableCredit,
            route && route.licenceCreditRemaining,
            account && account.structuredCredit,
            account && account.googleMapsCredit,
            license && license.availableCredit,
            license && license.structuredCredit,
            license && license.googleMapsCredit
        ];
        for (const val of candidates) {
            if (String(val || '').toLowerCase() === 'unlimited') return 'unlimited';
        }
        const finiteVals = [];
        for (const val of candidates) {
            if (val !== null && typeof val !== 'undefined' && val !== '') {
                const n = Number(String(val).replace(/,/g, ''));
                if (Number.isFinite(n) && n >= 0) finiteVals.push(n);
            }
        }
        if (!finiteVals.length) return null;
        const positiveVals = finiteVals.filter(n => n > 0);
        return positiveVals.length ? positiveVals[0] : finiteVals[0];
    }

    $scope.evaluateExpiringLicenceState = (account, license, route, forceShow) => {
        account = account || {};
        license = license || {};
        route = route || {};
        if (!license.active && !account.active) return false;

        const remainingCredits = resolveRemainingLicenceCredits(account, license, route);
        const isLowCredit = typeof remainingCredits === 'number' && Number.isFinite(remainingCredits) && remainingCredits > 0 && remainingCredits <= EXPIRING_LICENCE_CREDIT_LIMIT;

        const expiryRaw = String(account.expiryDate || license.expiryDate || '').trim();
        let daysLeft = (typeof account.daysRemaining === 'number' && Number.isFinite(account.daysRemaining)) ? account.daysRemaining : null;
        const expiryObj = parseExpiryDateLocalEnd(expiryRaw);
        if (expiryObj) {
            const computedDays = Math.max(0, Math.ceil((expiryObj.getTime() - Date.now()) / (1000 * 60 * 60 * 24)));
            daysLeft = computedDays;
        }
        const isExpiringSoon = typeof daysLeft === 'number' && Number.isFinite(daysLeft) && daysLeft >= 0 && daysLeft <= EXPIRING_LICENCE_DAYS_LIMIT;

        if (!isLowCredit && !isExpiringSoon) {
            $scope.safeApply(() => {
                $scope.expiringPopup.isLowCredit = false;
                $scope.expiringPopup.isExpiringSoon = false;
                if (!forceShow) $scope.expiringPopup.show = false;
            });
            return false;
        }

        const keyId = String(license.key || account.key || 'active');
        const creditBucket = isLowCredit ? (remainingCredits <= 100 ? '100' : remainingCredits <= 500 ? '500' : '1000') : 'ok';
        const daysBucket = isExpiringSoon ? String(daysLeft) : 'ok';
        const sig = keyId + '|cred:' + creditBucket + '|days:' + daysBucket;
        if (!forceShow && $scope._expiringPopupDismissedSig === sig) {
            return false;
        }

        const supportEmail = account.supportEmail || license.supportEmail || PocketLeadsConfig.supportEmail;
        let purchaseUrl = 'mailto:' + supportEmail + '?subject=PocketLeads%20Licence%20Renewal%20%26%20Credits';
        if (/^https:\/\//i.test(account.purchaseUrl || '')) {
            purchaseUrl = account.purchaseUrl;
        }

        const creditsText = remainingCredits === 'unlimited'
            ? 'Unlimited'
            : (typeof remainingCredits === 'number' ? remainingCredits.toLocaleString() : '—');
        const daysText = typeof daysLeft === 'number'
            ? (daysLeft <= 0 ? 'Expires Today' : (daysLeft === 1 ? '1 Day Left' : (daysLeft + ' Days Left')))
            : 'Unlimited';
        const expiryDateText = expiryRaw || (account.validityLabel || license.validityLabel || 'Unlimited');

        let title = 'Expiring Licence Warning';
        let kicker = 'EXPIRING LICENCE ALERT';
        let msg = '';
        if (isLowCredit && isExpiringSoon) {
            kicker = 'LOW CREDITS & EXPIRY ALERT';
            title = 'Licence Expiring Soon & Low Credits';
            msg = 'Your licence has only ' + creditsText + ' credits remaining (≤ 1,000) and will expire in ' + (daysLeft <= 0 ? 'less than 1 day' : (daysLeft + ' day(s)')) + (expiryRaw ? ' on ' + expiryRaw : '') + '. Please renew or top up soon for uninterrupted lead extraction.';
        } else if (isLowCredit) {
            kicker = 'LOW CREDIT ALERT (≤ 1,000)';
            title = 'Expiring Licence Credits Alert';
            msg = 'Your licence has only ' + creditsText + ' credits remaining (≤ 1,000 limit). Please top up or renew your licence soon so your lead extraction continues without interruption.';
        } else {
            kicker = 'EXPIRING WITHIN ' + Math.max(1, daysLeft) + ' DAY' + (daysLeft === 1 ? '' : 'S');
            title = 'Licence Expiring Soon';
            msg = 'Your licence will expire in ' + (daysLeft <= 0 ? 'less than 1 day' : (daysLeft + ' day(s)')) + (expiryRaw ? ' (on ' + expiryRaw + ')' : '') + '. Please renew your licence soon to keep uninterrupted access.';
        }

        $scope.safeApply(() => {
            $scope.expiringPopup.kicker = kicker;
            $scope.expiringPopup.title = title;
            $scope.expiringPopup.message = msg;
            $scope.expiringPopup.isLowCredit = isLowCredit;
            $scope.expiringPopup.isExpiringSoon = isExpiringSoon;
            $scope.expiringPopup.remainingCredits = remainingCredits;
            $scope.expiringPopup.remainingCreditsText = creditsText;
            $scope.expiringPopup.daysLeft = daysLeft;
            $scope.expiringPopup.daysLeftText = daysText;
            $scope.expiringPopup.expiryDateText = expiryDateText;
            $scope.expiringPopup.supportEmail = supportEmail;
            $scope.expiringPopup.purchaseUrl = purchaseUrl;
            $scope.expiringPopup.refreshMessage = '';
            $scope.expiringPopup._currentSig = sig;
            if (!$scope.captchaPopup.show) {
                $scope.expiringPopup.show = true;
            }
        });
        return true;
    };

    $scope.checkExpiringLicencePopup = (forceShow) => {
        try {
            if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;
            chrome.storage.local.get(['license', 'pocketleadsAccount', 'pocketleadsPreparedRoute'], res => {
                if (!res) return;
                $scope.evaluateExpiringLicenceState(res.pocketleadsAccount, res.license, res.pocketleadsPreparedRoute, !!forceShow);
            });
        } catch (e) {}
    };

    $scope.closeExpiringPopup = () => {
        if ($scope.expiringPopup._currentSig) {
            $scope._expiringPopupDismissedSig = $scope.expiringPopup._currentSig;
        }
        $scope.expiringPopup.show = false;
    };

    $scope.refreshExpiringPopupBalance = async () => {
        $scope.expiringPopup.refreshMessage = 'Refreshing licence & credit status...';
        try {
            await PocketLeadsAccount.refresh({ force: true });
            const state = await new Promise(resolve => chrome.storage.local.get(['license', 'pocketleadsAccount', 'pocketleadsPreparedRoute'], resolve));
            $scope._expiringPopupDismissedSig = '';
            const stillExpiring = $scope.evaluateExpiringLicenceState(state.pocketleadsAccount, state.license, state.pocketleadsPreparedRoute, true);
            $scope.safeApply(() => {
                $scope.expiringPopup.refreshMessage = stillExpiring
                    ? 'Status updated from Admin Sheet.'
                    : 'Licence & credits topped up! You are good to go.';
            });
        } catch (e) {
            $scope.safeApply(() => {
                $scope.expiringPopup.refreshMessage = 'Refresh failed. Please try again.';
            });
        }
    };

    if (typeof window !== 'undefined') {
        window.checkExpiringLicencePopup = $scope.checkExpiringLicencePopup;
    }
    setTimeout(() => { $scope.checkExpiringLicencePopup(false); }, 450);
    /* -------------------------------- Captcha/Error Popup -------------------------------- */
    
    // NEW: Function to handle scraping completion
    $scope.handleScrapingComplete = () => {
        /*
         * If the completion popup is suppressed because a WA check
         * started while scraping was still running, update state to
         * indicate scraping has finished but do not surface the
         * completion modal yet.  Instead mark that a completion is
         * pending so that it can be displayed after WA processing
         * completes.  We intentionally avoid setting
         * scrapingCompleteShown here so that the popup will show later.
         */
        if ($scope.suppressScrapingComplete) {
            /*
             * When a completion event is suppressed (usually because a
             * WhatsApp number check is running), we should mark that
             * a completion is pending but we must not prematurely
             * terminate the scraping session.  Previously this branch
             * reset local.status and _taskManager.isWorking to false,
             * which caused openEachStore/openEachStoreFast to abort
             * mid‑run.  Instead, only clear the suppression flag and
             * record that a completion needs to be shown later.  Only
             * if scraping is truly inactive (status and isWorking are
             * both false) should we perform the final cleanup (clear
             * activeQuery, close the search tab and save local).
             */
            // Mark that a completion should be shown after WA ends
            $scope.scrapingCompletePending = true;
            // Clear the suppression flag so subsequent calls will show
            // the popup when appropriate
            $scope.suppressScrapingComplete = false;

            // Determine whether scraping is still active by inspecting
            // the status flags directly.  We avoid using
            // $scope.isScrapingActive() here because that function
            // relies on local.status and _taskManager.isWorking,
            // which may not yet reflect the true state when this
            // handler is invoked (e.g. while a WA run is in progress).
            let stillActive = false;
            try {
                stillActive = !!($scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking)));
            } catch (e) {
                stillActive = false;
            }
            if (!stillActive) {
                // Only when scraping is truly inactive do we reset
                // status flags and perform cleanup.  This ensures we
                // don't interrupt an ongoing scrape when a false
                // completion event fires.
                $scope.local.status = false;
                if ($scope.local._taskManager) {
                    $scope.local._taskManager.isWorking = false;
                }
                $scope.scrapingActive = false;
                // Clear the active query so the UI reflects idle state.
                $scope.local.activeQuery = "";
                // Attempt to close any leftover search tab but ignore
                // failures.  Persist the reset searchTabId so future runs
                // don't attempt to remove a closed tab.
                try {
                    const tabId = $scope.local._taskManager ? $scope.local._taskManager.searchTabId : null;
                    if (tabId && chrome && chrome.tabs && typeof chrome.tabs.remove === 'function') {
                        chrome.tabs.remove(tabId, function() {
                            if (chrome.runtime && chrome.runtime.lastError) {
                                console.warn('handleScrapingComplete (suppressed): tab remove error', chrome.runtime.lastError);
                            }
                        });
                        if ($scope.local._taskManager) {
                            $scope.local._taskManager.searchTabId = null;
                        }
                    }
                } catch (closeErr) {
                    console.warn('handleScrapingComplete (suppressed): failed to close search tab', closeErr);
                }
                // Save a recoverable snapshot for the History modal before persisting.
                try { $scope.recordScrapingHistory('completed', false); } catch (historyErr) { console.warn('history snapshot failed', historyErr); }
                // Persist the updated local model
                try {
                    $scope.saveLocal();
                } catch (saveErr) {
                    console.warn('handleScrapingComplete (suppressed): saveLocal failed', saveErr);
                }
                // Refresh UI state to re-enable controls
                if (typeof $scope.updateUIState === 'function') {
                    $scope.updateUIState();
                }
            }
            return;
        }
        // Avoid duplicate notifications if a completion event is fired
        // multiple times.  Only proceed when the completion flag has
        // not been set.  Once handled we set the flag so that subsequent
        // calls during the same run are ignored.
        if ($scope.scrapingCompleteShown) {
            return;
        }
        $scope.scrapingCompleteShown = true;
        // When scraping finishes we want to surface feedback in the UI,
        // persist a record in the local notifications list, and send an
        // operating system notification.  Wrapping the updates in
        // $scope.$apply ensures Angular notices the changes.
        $scope.safeApply(() => {
            // Reset status flags so the UI shows scraping as idle.
            $scope.local.status = false;
            if ($scope.local._taskManager) {
                $scope.local._taskManager.isWorking = false;
                // Mark scraping as inactive.  This allows WA completion logic to
                // detect that scraping has finished and show final messages.
                $scope.scrapingActive = false;
                // Close any open search tab when scraping completes.  The
                // searchTabId is stored on the task manager.  Removing
                // the tab here prevents stray tabs from lingering after
                // completion on both desktop and mobile.  Guard against
                // undefined chrome.tabs and provide a callback to log
                // runtime errors.
                try {
                    const tabId = $scope.local._taskManager.searchTabId;
                    if (tabId && chrome && chrome.tabs && typeof chrome.tabs.remove === 'function') {
                        chrome.tabs.remove(tabId, function() {
                            if (chrome.runtime && chrome.runtime.lastError) {
                                console.warn('handleScrapingComplete: tab remove error', chrome.runtime.lastError);
                            }
                        });
                        // Reset the stored searchTabId so subsequent runs do not attempt
                        // to close an already removed tab.  Persist the update.
                        $scope.local._taskManager.searchTabId = null;
                        $scope.saveLocal();
                    }
                } catch (closeErr) {
                    console.warn('handleScrapingComplete: failed to close search tab', closeErr);
                }
            }
            $scope.local.activeQuery = "";
            // Initialise the notifications list if it doesn't exist.  The
            // extension persists notifications in chrome.storage.local so
            // that they survive popup reloads.  Each entry contains a
            // type, human‑readable message and ISO timestamp.
            if (!$scope.local._notifications || !$scope.local._notifications.list) {
                $scope.local._notifications = { list: [] };
            }
            try {
                $scope.local._notifications.list.push({
                    type: 'complete',
                    message: ($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.statusMessage) || 'Scraping completed successfully!',
                    timestamp: new Date().toISOString()
                });
            } catch (pushErr) {
                console.warn('Failed to append to notifications list', pushErr);
            }
            // Save a recoverable snapshot for the History modal before persisting.
            try { $scope.recordScrapingHistory('completed', false); } catch (historyErr) { console.warn('history snapshot failed', historyErr); }
            // Persist the updated local model before firing UI updates.
            $scope.saveLocal();
            // Show a completion modal overlay.  This provides a more
            // prominent notification in the UI similar to the captcha
            // overlay.  We intentionally do not show the bottom snackbar
            // here to avoid cluttering the interface.  Users will see
            // the completion popup and receive a desktop notification.
            const completionMessage = ($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.statusMessage)
                ? $scope.local.apifyQueue.statusMessage
                : 'Scraping completed successfully!';
            $scope.showCompletePopup(completionMessage);
            // The controller/background owns the single operating-system
            // notification. Dashboard tabs only render the in-app popup.
            // Refresh button states and other UI indicators.
            if (typeof $scope.updateUIState === 'function') {
                $scope.updateUIState();
            }
            if (typeof $scope.checkExpiringLicencePopup === 'function') {
                setTimeout(() => { $scope.checkExpiringLicencePopup(false); }, 300);
            }
        });
    };

    // ---------------------------------------------------------------------
    // WhatsApp number check completion handler
    //
    // When the WA number check run finishes, reset WA‑specific flags,
    // persist a notification entry, show a completion popup and dispatch a
    // desktop notification.  A `waCompleteShown` guard prevents
    // duplicate handling during a single run (similar to
    // scrapingCompleteShown).
    $scope.waCompleteShown = false;
    $scope.handleWaCheckComplete = (finished, total) => {
        if ($scope.waCompleteShown) {
            return;
        }
        $scope.waCompleteShown = true;
        // Schedule UI updates at the end of the current digest cycle.  Using
        // $evalAsync prevents nested $apply/$digest errors that would
        // otherwise occur when this handler is invoked from within
        // an existing digest (e.g. during wa_check_complete handling).
        $scope.$evalAsync(() => {
            try {
                // Reset WA flags and stop the login waiting prompt
                $scope.waChecking = false;
                $scope.waLoginWaiting = false;
                // Do not overwrite waFinished/waTotal with values from the
                // background.  The UI already maintains correct counts when
                // numbers are appended dynamically and rows are processed.
                // Clear the enqueued rows set and processed count so that the
                // next run starts fresh.  These values are initialised in
                // waNumberCheck when a new check begins.
                $scope.waEnqueuedRows = {};
                $scope.waProcessedCount = 0;
                // Record a notification entry
                if (!$scope.local._notifications || !$scope.local._notifications.list) {
                    $scope.local._notifications = { list: [] };
                }
                try {
                    $scope.local._notifications.list.push({
                        type: 'wa_complete',
                        message: 'WhatsApp number check completed successfully!',
                        timestamp: new Date().toISOString()
                    });
                } catch (pushErr) {
                    console.warn('handleWaCheckComplete: failed to append to notifications', pushErr);
                }
                // Persist the updated local model before firing UI updates.  Use a
                // callback to avoid potential digest conflicts.
                try {
                    $scope.saveLocal();
                } catch (saveErr) {
                    console.warn('handleWaCheckComplete: saveLocal failed', saveErr);
                }
                // Use the existing completion popup for consistency.  We do not
                // show the snackbar here to avoid a bottom bar overlay.  The
                // completion popup and desktop notification provide sufficient
                // feedback.
                try {
                    $scope.showCompletePopup('WhatsApp number check completed successfully!');
                } catch (popupErr) {
                    console.warn('handleWaCheckComplete: showCompletePopup failed', popupErr);
                }
                // Dispatch a desktop notification via the background worker
                try {
                    chrome.runtime.sendMessage({
                        type: 'notify',
                        title: 'WA Number Check Complete',
                        message: 'WhatsApp number check completed successfully!'
                    }, () => {
                        void chrome.runtime.lastError;
                    });
                } catch (notifyErr) {
                    console.warn('handleWaCheckComplete: failed to send notify message', notifyErr);
                }
                // Reset the guard after a brief delay so that subsequent runs can display
                // a new completion popup.  Without this the next run may be suppressed.
                setTimeout(() => {
                    $scope.waCompleteShown = false;
                }, 100);
                // Reset the WA start timestamp so that future scraping
                // completion events are not suppressed due to an old
                // timestamp.  This ensures that if the user performs a new
                // scraping run without starting a WA check, the
                // completion popup is displayed immediately when the
                // scraper finishes.
                try {
                    $scope.waStartTimestamp = 0;
                } catch (tsErr) {
                    // Ignore any assignment errors
                }
            } catch (err) {
                // Log any unexpected errors to the console.  As a fallback,
                // ensure the guard resets so future runs can show the popup.
                console.warn('handleWaCheckComplete: unexpected error', err);
                setTimeout(() => {
                    $scope.waCompleteShown = false;
                }, 100);
            }
        });
    };

    // NEW: Function to handle manual stop
    $scope.manualStopScraping = () => {
        console.log("Manual stop requested");

        // Mark that a manual stop is in progress.  This flag will
        // suppress any "Scraping stopped" notifications in the event
        // handler and is cleared after the stop has been fully
        // processed.  Without this, restarting WA or scraping during
        // an active session can lead to duplicate or unwanted
        // notifications when the stop event fires.
        $scope.manualStopInProgress = true;

        // Also set ignoreNextStopNotification so that the subsequent
        // scraping_stopped event is treated as suppressed.  This flag
        // complements manualStopInProgress to ensure no toast or
        // desktop notification is shown when the user stops manually.
        $scope.ignoreNextStopNotification = true;
        
        // Request the background script to stop scraping.  Provide a callback
        // to avoid unhandled promise rejection if no background listener
        // responds (e.g. if the background script has unloaded).
        try {
            chrome.runtime.sendMessage({ action: "stop_scraping" }, function() {
                if (chrome.runtime.lastError) {
                    console.warn('stop_scraping message failed', chrome.runtime.lastError);
                }
            });
        } catch (err) {
            console.warn('Error sending stop_scraping', err);
        }
        
        $scope.safeApply(() => {
            // Update only the in-memory UI immediately. The background controller
            // writes the authoritative retry_pending queue/checkpoint. Persisting a
            // stale full local model here previously overwrote the controller's
            // Resume state when both writes completed at nearly the same time.
            $scope.local.status = false;
            if (!$scope.local._taskManager) $scope.local._taskManager = {};
            $scope.local._taskManager.isWorking = false;
            $scope.local._taskManager.activeTask = 'openMap';
            $scope.scrapingActive = false;
            if (typeof $scope.updateUIState === 'function') $scope.updateUIState();
        });
    };
    
    // NEW: Function to handle manual start.  Before initiating a scrape
    // check that a licence is active.  If not, display a prompt and abort
    // the operation.  Otherwise proceed with the original start logic.
    $scope.manualStartScraping = () => {
        // Preserve both pending API tasks and pending Place-ID checkpoints.
        // A stopped run may have no taskList left because all API searches
        // finished while profiles are still waiting for DOM extraction.
        const _resumeQueueBefore = Object.assign({}, ($scope.local && $scope.local.apifyQueue) || {});
        const _pendingTasksBefore = Array.isArray($scope.local.taskList) ? $scope.local.taskList.slice() : [];
        const _signatureBefore = String($scope.local.apifyTaskSignature || '');
        const _pendingProfilesBefore = Array.isArray(_resumeQueueBefore.placeIdQueue) && _resumeQueueBefore.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
        const _resumeErrorCode = String(_resumeQueueBefore.lastErrorCode || '').toUpperCase();
        const _commercialStopBefore = /LICENSE_(?:EXPIRED|CREDIT_EXHAUSTED|INACTIVE)|LICENCE_(?:EXPIRED|CREDIT_EXHAUSTED)|ALL_CREDITS_EXHAUSTED|PREFLIGHT_/i.test(_resumeErrorCode);
        const _resumableBefore = (_pendingTasksBefore.length > 0 || _pendingProfilesBefore || !!_resumeQueueBefore.resumeAvailable) && /^(stopped|failed|partial_results|paused_recoverable|memory_recovery|google_pipeline_running|google_pipeline_draining|dataset_saved|streaming_results|serper_streaming|switching_key|api_switching|resuming|no_results|no_results_after_filter)$/i.test(String(_resumeQueueBefore.status || ''));

        const _keywordLines = String($scope.local.keywordTextarea || '').split('\n').map(x => x.trim()).filter(Boolean);
        const _locationLines = String($scope.local.locationTextarea || '').split('\n').map(x => x.trim()).filter(Boolean);
        const _freshTasksPreview = [];
        if (_keywordLines.length && _locationLines.length) {
            _keywordLines.forEach(keyword => _locationLines.forEach(location => _freshTasksPreview.push(keyword + '~in~' + location)));
        } else {
            _keywordLines.forEach(query => _freshTasksPreview.push(query));
        }
        const _freshSignature = _freshTasksPreview.join('\n');
        const _sameInputs = !_signatureBefore || !_freshSignature || _freshSignature === _signatureBefore;
        const _resumeScrape = _resumableBefore && (_sameInputs || !!_resumeQueueBefore.resumeAvailable);
        if (_resumeScrape) {
            $scope.local.taskList = _pendingTasksBefore;
            $scope.local.apifyQueue = Object.assign({}, _resumeQueueBefore, {
                status: 'resuming',
                statusMessage: 'Resuming from last pending search/profile checkpoint...',
                resumeAvailable: false,
                finishedAt: '',
                lastUpdatedAt: new Date().toISOString()
            });
        } else {
            $scope.saveAsList(true);
            const _newSignature = Array.isArray($scope.local.taskList) ? $scope.local.taskList.join('\n') : '';
            $scope.local.apifyTaskSignature = _newSignature;
            $scope.local.apifyTaskTotal = Array.isArray($scope.local.taskList) ? $scope.local.taskList.length : 0;
        }
        // Ensure there is at least one query. Location is optional now because
        // a keyword line can already be a complete query like "clinic in kolkata".
        const _hasResumeProfiles = Array.isArray($scope.local.apifyQueue && $scope.local.apifyQueue.placeIdQueue) && $scope.local.apifyQueue.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
        if ((!$scope.local.taskList || $scope.local.taskList.length === 0) && !_hasResumeProfiles) {
            $scope.showCaptchaPopup("Please add at least one search query or resume a pending profile queue first");
            return;
        }
        // Require an active licence before starting
        if (!$scope.licenseActive) {
            // Display an activation prompt via popup instead of snackbar
            $scope.showCaptchaPopup("Please activate your licence first");
            return;
        }
        // API token and Actor ID are managed by the admin Google Sheet via Apps Script.
        // Do not require or show any API fields inside the extension dashboard.
        $scope.local.fastMode = false;
        if (!$scope.local._taskManager) $scope.local._taskManager = {};
        $scope.local._taskManager.activeTask = 'openMap';

        // v91: DO NOT mark the dashboard Running or start the scrape timer here.
        // The background controller has already-prepared provider metadata and is
        // the only component allowed to enter Running after it accepts that route.
        // This prevents 0-credit/source errors from creating fake progress rows.
        $scope.startLaunchPending = true;
        $scope.scrapingCompleteShown = false;
        // Persist the freshly rebuilt task list before the service worker reads it.
        // chrome.storage.set is asynchronous; sending Start first could make the
        // background read the previous task set and create confusing progress.
        $scope.saveLocal(function() {
            $scope.sendMessage('start');
            // Defensive launch watchdog: if the service worker never transitions
            // the model into Running (e.g. it was restarted), release the button
            // without fabricating scrape progress.
            setTimeout(function() {
                try {
                    const actuallyRunning = !!($scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking)));
                    if ($scope.startLaunchPending && !actuallyRunning) {
                        $scope.$evalAsync(function() {
                            $scope.startLaunchPending = false;
                            if (typeof $scope.updateUIState === 'function') $scope.updateUIState();
                        });
                    }
                } catch (e) {}
            }, 6000);
        });
        // Do not show the bottom snackbar when starting scraping.  The
        // UI state will reflect the running status and a desktop
        // notification will be sent by the background script if
        // necessary.
        // Trigger the UI update asynchronously using $evalAsync.  This
        // schedules updateUIState to run after the current digest cycle
        // completes, preventing `$rootScope:inprog` errors caused by
        // nested $apply/$digest calls.  Calling updateUIState directly
        // here can sometimes trigger a nested digest when this
        // function is invoked inside an ng-click handler during an
        // active digest cycle.
        $scope.$evalAsync(() => {
            if (typeof $scope.updateUIState === 'function') {
                $scope.updateUIState();
            }
        });
    };
    
    // NEW: Listen for scraping events and surface feedback accordingly.
    // Terminal events can arrive through more than one legacy transport. Keep a
    // short event-id/fingerprint guard so one run produces one popup/history row.
    $scope._terminalEventGuard = $scope._terminalEventGuard || {};
    $box.on((event, data) => {
        if (/^(scraping_complete|scraping_error|scraping_stopped)$/.test(String(event || ''))) {
            const payload = data && typeof data === 'object' ? data : {};
            const messagePart = String(payload.message || '').slice(0, 240);
            const eventKey = String(payload.eventId || (event + ':' + messagePart));
            const fingerprintKey = 'fingerprint:' + String(event || '') + ':' + messagePart.toLowerCase();
            const nowMs = Date.now();
            const lastAt = Math.max(
                Number($scope._terminalEventGuard[eventKey] || 0),
                Number($scope._terminalEventGuard[fingerprintKey] || 0)
            );
            if (lastAt && nowMs - lastAt < 15000) {
                console.debug('[PocketLeads] Ignored duplicate terminal event', event, eventKey);
                return;
            }
            $scope._terminalEventGuard[eventKey] = nowMs;
            $scope._terminalEventGuard[fingerprintKey] = nowMs;
            Object.keys($scope._terminalEventGuard).forEach(key => {
                if (nowMs - Number($scope._terminalEventGuard[key] || 0) > 60000) delete $scope._terminalEventGuard[key];
            });
        }
        // When scraping completes, update the UI, persist a notification
        // entry and dispatch a system notification.  Delegating to
        // handleScrapingComplete encapsulates this logic.
        if (event === "scraping_complete") {
            $scope.startLaunchPending = false;
            const completionPayload = data && typeof data === 'object' ? data : {};
            const authoritativeComplete = /:complete$/i.test(String(completionPayload.eventId || ''));
            if (authoritativeComplete && $scope.local) {
                // Bring the visible model forward to the controller-owned terminal
                // state immediately. The storage snapshot can arrive a few ms later.
                $scope.local.status = false;
                if (!$scope.local._taskManager) $scope.local._taskManager = {};
                $scope.local._taskManager.isWorking = false;
                if (!$scope.local.apifyQueue) $scope.local.apifyQueue = {};
                if (completionPayload.message) $scope.local.apifyQueue.statusMessage = String(completionPayload.message);
                $scope.local.apifyQueue.status = completionPayload.completedWithErrors ? 'completed_with_errors' : 'completed';
                $scope.local.apifyQueue.resumeAvailable = false;
                $scope.local.apifyQueue.producerDone = true;
                $scope.local.apifyQueue.consumerDone = true;
            }
            const completionQueue = Object.assign({}, ($scope.local && $scope.local.apifyQueue) || {});
            const completionJobs = Array.isArray(completionQueue.placeIdQueue) ? completionQueue.placeIdQueue : [];
            const completionPending = completionJobs.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
            const completionTasksRemain = Array.isArray($scope.local && $scope.local.taskList) && $scope.local.taskList.length > 0;
            const completionApiTotal = Math.max(0, parseInt(completionQueue.apiTasksTotal || completionQueue.totalTasks, 10) || 0);
            const completionApiSettled = Math.max(0, parseInt(completionQueue.apiTasksSettled || completionQueue.completedTasks, 10) || 0);
            const completionGooglePipeline = String(completionQueue.provider || '').toLowerCase() === 'googlemaps' || completionJobs.length > 0 || /^google_pipeline/i.test(String(completionQueue.status || ''));
            // DailyController.complete() emits an eventId ending in :complete only
            // AFTER it has checked task/API/DOM queues and persisted terminal state.
            // Angular's local preview can lag that storage write by one digest; the
            // old UI-side guard then swallowed the only completion event forever.
            // Keep the legacy guard for untrusted/legacy events, but trust the
            // controller-owned terminal event so Download + Close always appears.
            if (!authoritativeComplete && (($scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking))) || completionPending || completionTasksRemain || (completionApiTotal > completionApiSettled) || (completionGooglePipeline && completionApiTotal > 0 && completionQueue.producerDone !== true))) {
                console.debug('[PocketLeads] Ignored legacy premature scraping_complete because queue work remains.');
                if (typeof $scope.updateUIState === 'function') $scope.updateUIState();
                return;
            }
            /*
             * When scraping completes very shortly after starting a WA run,
             * an immediate completion popup can be confusing.  In fast
             * mode the asynchronous notification from the content
             * script may race with the WA start.  Suppress the popup
             * if the last WA run began within the last 5 seconds or
             * if suppressScrapingComplete is flagged.  The suppressed
             * completion will be shown later when WA completes.
             */
            const now = Date.now();
            const waStartedRecently = ($scope.waStartTimestamp && (now - $scope.waStartTimestamp < 5000));
            const waIsRunning = $scope.waChecking;
            if ($scope.suppressScrapingComplete || waStartedRecently || waIsRunning) {
                // Handle completion in suppressed mode.  This updates
                // internal status flags but does not show the popup.  The
                // handleScrapingComplete function will detect
                // suppressScrapingComplete and mark the completion as
                // pending.  We intentionally do not finalise WA here; it
                // will be handled when WA finishes.
                try {
                    $scope.handleScrapingComplete();
                } catch (suppErr) {
                    console.warn('Error handling suppressed scraping complete', suppErr);
                }
                // Do not trigger WA completion or show any popup now.
                return;
            }
            // Scraping has finished.  Process completion and then
            // finalise any pending WA runs.  handleScrapingComplete
            // updates local status and persists notifications.  After
            // that, if a WA run finished earlier and we were waiting
            // for scraping to end, trigger the final WA completion.
            $scope.handleScrapingComplete();
            // If WA is pending and not currently running, show final popup
            $scope.$evalAsync(() => {
                try {
                    if ($scope.waPendingComplete && !$scope.waChecking) {
                        $scope.waPendingComplete = false;
                        $scope.handleWaCheckComplete($scope.waFinished, $scope.waTotal);
                    }
                } catch (waCompleteErr) {
                    console.warn('Error finalising WA after scraping complete', waCompleteErr);
                }
            });
            return;
        }
        // When an error such as a captcha is encountered we display a
        // modal in the dashboard, record a notification entry and
        // dispatch a desktop notification.  The message from the
        // content script is included in both the popup and the
        // notification when available.
        if (event === "scraping_error") {
            $scope.startLaunchPending = false;
            /*
             * Use safeApply here to avoid nested $apply/$digest errors that can
             * occur if a stop is triggered while Angular is already
             * processing an update (for example, during a WA check update or
             * onLocalChange callback).  safeApply executes the callback
             * immediately if a digest is in progress, or wraps it in
             * $apply otherwise.
             */
            $scope.safeApply(() => {
                const msg = (data && data.message) ? data.message : "Unknown error";
                // Set flag so the subsequent scraping_stopped event does not
                // surface an additional stop notification.  This ensures
                // users only see the captcha pause message and not a
                // redundant "Scraping stopped" toast/notification.
                $scope.ignoreNextStopNotification = true;
                // Show a persistent popup so the user can read the
                // captcha/error message and take action.
                const errorCode = String(data && data.errorCode || '');
                const upgrade = !!(data && data.upgradeRequired) || /LICENSE_(?:EXPIRED|CREDIT_EXHAUSTED)/i.test(errorCode);
                $scope.showCaptchaPopup(msg, {
                    title: upgrade ? 'Upgrade Required' : 'Attention Required',
                    upgrade,
                    supportEmail: (data && data.supportEmail) || PocketLeadsConfig.supportEmail
                });
                // Append to the notifications list. Initialise the
                // container if missing or missing the list property.
                if (!$scope.local._notifications || !$scope.local._notifications.list) {
                    $scope.local._notifications = { list: [] };
                }
                try {
                    $scope.local._notifications.list.push({
                        type: 'error',
                        message: msg,
                        timestamp: new Date().toISOString()
                    });
                } catch (pushErr) {
                    console.warn('Failed to append error notification', pushErr);
                }
                $scope.saveLocal();
                // The controller/background owns the single operating-system
                // notification. Avoid one notification per open dashboard tab.
            });
            return;
        }
        // When scraping is manually stopped (either by the user or
        // automatically in the background after an error) update state,
        // surface a snackbar message, persist a notification entry and
        // send a system notification.  Without this, the user might
        // miss the fact that scraping has stopped when the popup is
        // closed or minimised.
        if (event === "scraping_stopped") {
            $scope.startLaunchPending = false;
            $scope.safeApply(() => {
                // Always update status flags and active query so the UI
                // accurately reflects that scraping is no longer running.
                $scope.local.status = false;
                if ($scope.local._taskManager) {
                    $scope.local._taskManager.isWorking = false;
                }
                // Mark scraping as inactive so WA logic knows scraping has ended.
                $scope.scrapingActive = false;
                // Preserve the last query/checkpoint so Resume can continue exactly.
                try {
                    const q = Object.assign({}, $scope.local.apifyQueue || {});
                    const pending = Array.isArray(q.placeIdQueue) && q.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
                    const stopErrorCode = String(q.lastErrorCode || '').toUpperCase();
                    const commercialStop = /LICENSE_(?:EXPIRED|CREDIT_EXHAUSTED|INACTIVE)|LICENCE_(?:EXPIRED|CREDIT_EXHAUSTED)|ALL_CREDITS_EXHAUSTED|PREFLIGHT_/i.test(stopErrorCode);
                    q.resumeAvailable = (!!q.resumeAvailable || pending || (Array.isArray($scope.local.taskList) && $scope.local.taskList.length > 0));
                    if (q.resumeAvailable && !/^(stopped|paused_recoverable)$/i.test(String(q.status || ''))) q.status = 'stopped';
                    $scope.local.apifyQueue = q;
                    if (!$scope.local._taskManager) $scope.local._taskManager = {};
                    $scope.local._taskManager.activeTask = q.resumeAvailable ? 'openMap' : null;
                } catch (e) {}

                // If a manual stop is in progress, do not record a
                // notification or send any system messages.  Simply
                // persist the model, refresh the UI and reset the
                // manualStopInProgress flag.  This ensures that user‑initiated
                // stops do not trigger unwanted "Scraping Stopped"
                // notifications.
                if ($scope.manualStopInProgress) {
                    try { $scope.recordScrapingHistory('stopped', false); } catch (historyErr) { console.warn('history snapshot failed', historyErr); }
                    $scope.saveLocal();
                    $scope.manualStopInProgress = false;
                    if (typeof $scope.updateUIState === 'function') {
                        $scope.updateUIState();
                    }
                    try {
                        if ($scope.waPendingComplete && !$scope.waChecking) {
                            $scope.waPendingComplete = false;
                            $scope.handleWaCheckComplete($scope.waFinished, $scope.waTotal);
                        }
                    } catch (waPendingErr) {
                        console.warn('Error finalising WA after manual stop', waPendingErr);
                    }
                    return;
                }

                // If this stop event immediately follows a captcha pause
                // (indicated by ignoreNextStopNotification), do not record a
                // stop notification or show a snackbar/desktop message.  Just
                // persist the updated model and proceed.
                if ($scope.ignoreNextStopNotification) {
                    try { $scope.recordScrapingHistory('stopped', false); } catch (historyErr) { console.warn('history snapshot failed', historyErr); }
                    $scope.saveLocal();
                } else {
                    // Otherwise record the stop event and send a desktop
                    // notification to inform the user.  Initialise the
                    // notifications list if necessary.
                    if (!$scope.local._notifications || !$scope.local._notifications.list) {
                        $scope.local._notifications = { list: [] };
                    }
                    try {
                        $scope.local._notifications.list.push({
                            type: 'stopped',
                            message: 'Scraping stopped',
                            timestamp: new Date().toISOString()
                        });
                    } catch (pushErr) {
                        console.warn('Failed to append stopped notification', pushErr);
                    }
                    try { $scope.recordScrapingHistory('stopped', false); } catch (historyErr) { console.warn('history snapshot failed', historyErr); }
                    $scope.saveLocal();
                    // Do not dispatch a desktop notification here.  The
                    // dashboard UI will indicate that scraping has stopped
                    // without triggering an external system alert.  This
                    // suppresses a "Scraping Stopped" notification for
                    // both automatic and manual stop events.  Previously
                    // a notify message was sent here, which resulted in
                    // unnecessary alerts.
                }
                // Clear the suppression flag so future stop events behave normally.
                $scope.ignoreNextStopNotification = false;
                // Refresh the UI state (e.g. enable the start button).
                if (typeof $scope.updateUIState === 'function') {
                    $scope.updateUIState();
                }
                // After handling the stop, if a WA run finished earlier and
                // scraping has now ended, complete any pending WA run.
                try {
                    if ($scope.waPendingComplete && !$scope.waChecking) {
                        $scope.waPendingComplete = false;
                        $scope.handleWaCheckComplete($scope.waFinished, $scope.waTotal);
                    }
                } catch (waPendingErr) {
                    console.warn('Error finalising WA after scraping stopped', waPendingErr);
                }
            });
            return;
        }
    });
    
    // NEW: Function to check if scraping is active
    $scope.isScrapingActive = () => {
        // Guard against _taskManager being undefined.  When the local
        // model is initialised from scratch on mobile, _taskManager may
        // not exist until after the first start.  Coerce undefined to
        // false so that the result reflects the correct state.
        return $scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking);
    };

        // The suppression flag has been moved to $scope.ignoreNextStopNotification
        // so that it persists across digest cycles and remains visible to
        // the scraping event handler above.  The separate local
        // declaration is removed to avoid confusion.
    
    $scope.init = ()=>{
        
        // Removed Auth.check: licensing is disabled in this build.  The
        // extension always runs in full mode without contacting any licensing
        // service.  Previously the license was validated here on startup.
        // We keep the delay to preserve timing but do nothing when it fires.
        setTimeout(() => {
            /* no-op */
        }, $fc.randBetween(300, 700));
        
        setTimeout(()=>{     
            $scope.$apply(()=>{
                $scope.local.isScrapingEmail = false;
                // Keep the real service-worker state. The popup/dashboard can be
                // closed and reopened while extraction continues.
                if (!$scope.local._taskManager) {
                    $scope.local._taskManager = { isWorking: false, activeTask: null, searchTabId: null };
                }
                $scope.showItemExtensionFooter = true;
                $scope.updateUIState();
            });
        },200);
        
    };
    
    $scope.refreshTable = ()=>{
        setTimeout(()=>{
            buildDataTable();
        },800);
    };
    
    $scope.percentComplete = () => {
        return $scope.progressData || { completed: 0, total: 0, percent: 0, percentExact: 0 };
    };
    $scope.pagePercent = ()=>{
        let data = {};
        data.total = 20;  
        data.completed = $scope.local.collect.length;
        data.percent = ""+ (data.completed/data.total).toFixed(2);
        data.percent = data.percent.split('.')[1];
        return data;
    };
    
    // Initialize UI state
    $scope.updateUIState();
    
    $scope.init();

    /* -----------------------------------------------------------------------
     * Clear Data Modal Support
     *
     * The dashboard previously cleared all scraped results instantly when the
     * user clicked "Clear Data".  Users requested an option to clear both
     * dashboard data and browsing history.  However, requesting the history
     * permission triggers a prominent "Read and change your browsing history"
     * warning in Chrome.  To avoid this, the extension now only clears
     * dashboard data; any request to clear browser history is ignored.  We
     * still maintain the modal state for future flexibility or UI feedback.
     */

    // Whether the clear data modal is visible
    $scope.showClearDataModal = false;
    // Checkboxes bound to the modal options; default both true (recommended)
    $scope.clearBrowserHistorySelected = true;
    $scope.clearDashboardSelected = true;

    /**
     * Display the Clear Data modal.  This is invoked from the UI when the
     * user clicks the "Clear Data" button.  It resets the checkbox
     * selections to the recommended defaults (both options enabled).
     */
    $scope.openClearDataModal = () => {
        $scope.clearBrowserHistorySelected = true;
        $scope.clearDashboardSelected = true;
        $scope.showClearDataModal = true;
    };

    /**
     * Execute the selected clear data actions.  If the user opts to clear
     * dashboard data we empty the local.collect array, persist to storage and
     * refresh the table.  Browser history is no longer cleared in order to
     * avoid requesting additional permissions that would trigger warning
     * messages.  The clearBrowserHistorySelected flag is therefore ignored.
     * After completion a snackbar notification is shown.
     */
    $scope.executeClearData = () => {
        // v92 authoritative hidden refresh: every Clear Data execution checks
        // this licence's remaining credits and currently eligible provider, then
        // stores only the non-secret prepared route. The Start button never repeats
        // this source-discovery request.
        try {
            chrome.runtime.sendMessage({ action: 'pocketleads_warm_backend', reason: 'clear_data', force: true }, function(){
                try { void chrome.runtime.lastError; } catch (e) {}
            });
        } catch (e) {}
        // Hide the modal immediately
        $scope.showClearDataModal = false;

        // Clear dashboard results if requested
        if ($scope.clearDashboardSelected) {
            $scope._canonicalGeneration++;
            $scope._pendingResultEdits.clear();
            clearTimeout($scope._resultStoreSyncTimer);
            $scope._resultStoreSyncTimer = null;
            /*
             * Cancel any running WhatsApp number check and scraping tasks,
             * wipe all session‑scoped state and reset UI flags so that the
             * start button becomes enabled.  This block ensures that both
             * WhatsApp and scraping progress are fully cleared when the user
             * chooses to clear the dashboard.
             */
            // If scraping is currently active, mark that we are performing
            // a manual stop as part of the clear operation.  This will
            // suppress any "Scraping stopped" notifications when the
            // stop event is processed.  Only set these flags when there
            // is an active run; otherwise they remain false.  These flags
            // will be reset either in the scraping_stopped handler or at
            // the end of this clearData function for inactive sessions.
            const activeScraping = $scope.local && ($scope.local.status || ($scope.local._taskManager && $scope.local._taskManager.isWorking));
            if (activeScraping) {
                $scope.manualStopInProgress = true;
                $scope.ignoreNextStopNotification = true;
            }
            try {
                // Stop any ongoing WA check via the background script
                chrome.runtime.sendMessage({ action: 'stop_wa_check' }, function() {});
            } catch (err) {
                // suppress errors when stopping WA
            }
            try {
                // Stop scraping via the background script
                chrome.runtime.sendMessage({ action: 'stop_scraping', clearData: true }, function() {});
                // Broadcast stop_scraping to content scripts immediately
                if (typeof $scope.sendMessage === 'function') {
                    $scope.sendMessage('stop_scraping');
                }
            } catch (err) {
                console.warn('executeClearData: failed to send stop_scraping', err);
            }
            // Remove all collected results and reset session data.
            $scope.local.collect = [];
            $scope.local.collectIsPreview = false;
            $scope.local.resultStoreCount = 0;
            $scope._monotonicResultCount = 0;
            $scope._monotonicTaskCompleted = 0;
            $scope._monotonicProgressRunId = '';
            $scope.mobileSelectedMap = {};
            try { refreshDashboardMetricCounts([]); } catch (e) {}
            $scope.local.resultStoreMigrated = true;
            $scope.resultStoreHydrated = false;
            $scope._lastResultStoreSyncSignature = '';
            $scope._resultStoreRowHashes = new Map();
            try {
                chrome.runtime.sendMessage({ action: 'result_store_clear' }, function() { try { void chrome.runtime.lastError; } catch (e) {} });
            } catch (e) {}
            $scope.local.apifyQueue = {
                status: 'idle',
                statusMessage: 'Cleared. Ready for a fresh run.',
                currentQuery: '',
                currentProfileUrl: '',
                totalPlaceIds: 0,
                totalApiResults: 0,
                totalTasks: 0,
                completedTasks: 0,
                apiSwitchCount: 0,
                scrapedCount: 0,
                failedCount: 0,
                filteredCount: 0,
                duplicateSkippedCount: 0,
                apiKeyRow: 0,
                apiUsageBefore: 0,
                apiUsageAfter: 0,
                apiUsageLimit: 0,
                pendingPlaceIds: [],
                processing: null,
                completed: [],
                failed: [],
                retryCount: {},
                apiTasksTotal: 0,
                apiTasksDone: 0,
                apiTasksFailed: 0,
                apiTasksSettled: 0,
                domTotal: 0,
                domProcessed: 0,
                domPending: 0,
                domRunning: 0,
                placeIdQueue: [],
                resumeAvailable: false,
                producerDone: false,
                consumerDone: false,
                managedTabIds: [],
                lastUpdatedAt: new Date().toISOString()
            };
            $scope.local.apifySeenKeys = [];
            $scope.local.apifyLastDatasetId = '';
            $scope.local.apifyLastRunId = '';
            // Reset scraping status flags
            $scope.local.status = false;
            if (!$scope.local._taskManager) {
                $scope.local._taskManager = {};
            }
            // Fully reset the task manager state.  Clearing isWorking is not
            // sufficient when starting a brand new scrape: the activeTask,
            // searchTabId and scrapeStarted properties may retain values
            // from the previous session.  Leaving these fields populated can
            // cause inconsistent behaviour, such as resuming from a stale
            // task or failing to initiate fast mode scraping.  Explicitly
            // reset these fields so the next start begins from a clean
            // state.  Note: searchTabId is used by the content script to
            // open Google Maps in a specific tab; clearing it ensures a
            // fresh tab is opened on the next run.
            $scope.local._taskManager.isWorking = false;
            $scope.local._taskManager.activeTask = null;
            $scope.local._taskManager.searchTabId = null;
            $scope.local._taskManager.scrapeStarted = false;
            $scope.scrapingActive = false;
            // Clear the active query context
            try {
                $scope.local.activeQuery = "";
            } catch (err) {
                // ignore assignment errors
            }
            // Reset scraping progress metrics
            if ($scope.progressData) {
                $scope.progressData.completed = 0;
                $scope.progressData.total = 0;
                $scope.progressData.percent = 0;
            }
            // Reset all WhatsApp checking state and counters
            $scope.waChecking = false;
            $scope.waLoginWaiting = false;
            $scope.waPendingComplete = false;
            $scope.waCompletedRows = {};
            $scope.waEnqueuedRows = {};
            $scope.waCompletedIds = {};
            $scope.waEnqueuedIds = {};
            $scope.waDiscoveredIds = {};
            $scope.waFinished = 0;
            $scope.waTotal = 0;
            $scope.waInitialTotal = 0;
            $scope.waProcessedCount = 0;
            $scope.waCompleteShown = false;
            $scope.waStartTimestamp = 0;
            if ($scope.whatsappProgress) {
                $scope.whatsappProgress.total = 0;
                $scope.whatsappProgress.completed = 0;
                $scope.whatsappProgress.percent = 0;
            }
            // Clear any lingering whatsapp_status values on rows (defensive)
            try {
                ($scope.local.collect || []).forEach(r => {
                    if (r && typeof r === 'object' && 'whatsapp_status' in r) {
                        r.whatsapp_status = '';
                    }
                });
            } catch (err) {
                // ignore errors when clearing statuses
            }
            // Close any open search tab
            try {
                if (typeof $scope.closeSearchTab === 'function') {
                    $scope.closeSearchTab();
                }
            } catch (err) {
                // ignore errors closing search tab
            }
            // Reset scraping delay slider to default
            try {
                $scope.local.delayTime = 1;
            } catch (err) {
                // ignore assignment errors
            }

            // Rebuild the task list from the current keyword and location lists.  During
            // scraping the taskList is consumed by shift() calls and may
            // become empty or partially depleted.  Without rebuilding the
            // list here a subsequent scrape would operate on an empty or
            // truncated task list, leading to missing or inconsistent
            // results.  Construct the Cartesian product of keywordList and
            // locationList exactly as in saveAsList().  Preserve the
            // existing keyword/location arrays, removing only empty lines.
            try {
                const kwList = Array.isArray($scope.local.keywordList) ? $scope.local.keywordList.filter(x => x) : [];
                const locList = Array.isArray($scope.local.locationList) ? $scope.local.locationList.filter(x => x) : [];
                let tasks = [];
                if (kwList.length && locList.length) {
                    kwList.forEach(keyword => {
                        locList.forEach(location => {
                            tasks.push(`${keyword}~in~${location}`);
                        });
                    });
                } else if (kwList.length) {
                    tasks = kwList.slice();
                }
                $scope.local.taskList = tasks;
            } catch (rebuildErr) {
                console.warn('executeClearData: failed to rebuild task list', rebuildErr);
            }
            // Persist the cleared model and refresh the table
            $scope.saveLocal();
            if (typeof $scope.refreshTable === 'function') {
                $scope.refreshTable();
            }
            // Update UI state so controls reflect the reset state
            if (typeof $scope.updateUIState === 'function') {
                $scope.updateUIState();
            }
        }

        // Clearing browser history has been removed.  The extension no longer
        // requests the 'history' permission, so we intentionally do not delete
        // any entries from the browser's history.  This prevents permission
        // warnings like "Read and change your browsing history".

        // Provide feedback to the user
        if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
            $scope.snackbar.show('Selected data cleared successfully');
        }
    };

    /**
     * Directly clear both dashboard data and extension‑specific history without
     * showing the options modal.  This helper ensures that both flags are
     * enabled before calling executeClearData().  It is invoked when the
     * user clicks the Clear Data button in the UI.
     */
    $scope.clearDataDirect = () => {
        try {
            if ($scope.local) {
                $scope.local.scrapeStartedAt = '';
                $scope.local.scrapeFinishedAt = '';
                $scope.local.scrapeElapsedMs = 0;
                if ($scope.local.apifyQueue) {
                    $scope.local.apifyQueue.startedAt = '';
                    $scope.local.apifyQueue.finishedAt = '';
                    $scope.local.apifyQueue.elapsedMs = 0;
                }
            }
        } catch (timerClearErr) {}
        $scope.clearDashboardSelected = true;
        $scope.clearBrowserHistorySelected = true;
        $scope.executeClearData();
    };

    /**
     * The old browser-history cleanup button is replaced by the scraping
     * history viewer. This keeps the extension away from browser history
     * deletion and opens the saved scraping session modal instead.
     */
    $scope.clearHistory = () => $scope.openScrapingHistory();


    /**
     * Check scraped phone numbers for WhatsApp availability.  When invoked this
     * function opens WhatsApp Web in a new tab (if not already open) and then
     * communicates with the injected content script to determine whether each
     * phone number is registered on WhatsApp.  Results are stored in the
     * whatsapp_status field of the local.collect records and displayed in the
     * grid.  If the user is not logged into WhatsApp Web, a message is shown
     * prompting them to log in and re‑run the check.
     */
    $scope.whatsappCheck = async () => {
        try {
            if($scope.local.collectIsPreview)$scope.local.collect=await getCompleteRowsForExport();
            // Reset the automatic retry counter when this function is invoked
            // manually.  When invoked via an auto‑retry (waAutoRetry),
            // preserve the existing counter and clear the flag.
            if (!$scope.waAutoRetry) {
                $scope.waRetryCount = 0;
            } else {
                $scope.waAutoRetry = false;
            }

            // Assign a unique identifier to the current run.  Async
            // callbacks capture this identifier and abort if they
            // correspond to an outdated run.
            try {
                $scope.waRunId = ($scope.waRunId || 0) + 1;
            } catch (err) {
                $scope.waRunId = 1;
            }

            // Clear paused and stop flags at the start of every run.
            $scope.local.pausedWhatsapp = false;
            $scope.local.stopWhatsappCheck = false;

            // Build a list of rows that need WhatsApp checking.  Exclude
            // rows whose whatsapp_status is already a final value
            // (Available/Not available).  Normalise each phone number to
            // remove non‑digits and leading zeros, storing the digits on
            // the row for later lookup.  Clear any existing interim
            // statuses on rows that will be checked.
            const rows = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
            const rowsWithPhone = [];
            const phonesForCheck = [];
            rows.forEach((row, idx) => {
                const raw = row && row.phone ? String(row.phone).trim() : '';
                if (!raw) return;
                const status = (row.whatsapp_status || '').toLowerCase();
                if (status === 'available' || status === 'not available') {
                    return;
                }
                let digits = raw.replace(/\D/g, '');
                digits = digits.replace(/^0+/, '');
                if (!digits) return;
                if (String(row.phone).replace(/\D/g, '').replace(/^0+/, '') !== digits) {
                    row.phone = digits;
                }
                row._waDigits = digits;
                phonesForCheck.push(digits);
                // Store the index of this row rather than the object itself.
                rowsWithPhone.push(idx);
                // Clear interim statuses (blank or "Started").
                row.whatsapp_status = '';
            });
            // If there are no rows to check, notify the user and exit.
            if (!phonesForCheck.length) {
                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                    $scope.snackbar.show('No phone numbers to check.');
                }
                return;
            }
            // Prevent starting a new check if one is already in progress.
            if ($scope.local.isCheckingWhatsapp) {
                return;
            }
            // Persist cleared statuses and refresh the grid.
            try {
                if (typeof $scope.saveLocal === 'function') {
                    $scope.saveLocal();
                }
                updateDataTable($scope.local);
            } catch (err) {
                console.warn('whatsappCheck: failed to clear interim statuses', err);
            }
            // Initialise flags and progress tracker for this run.
            $scope.local.stopWhatsappCheck = false;
            $scope.local.isCheckingWhatsapp = true;
            $scope.whatsappProgress = {
                completed: 0,
                total: phonesForCheck.length,
                percent: 0
            };
            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                $scope.snackbar.show('Checking WhatsApp availability for ' + phonesForCheck.length + ' numbers...');
            }

            // Helper that waits for a WhatsApp Web tab to finish loading.  The
            // content script (whatsapp/inject.js) is registered via the
            // manifest and will only be ready once the tab reaches the
            // "complete" state.  This helper polls chrome.tabs.get until the
            // tab’s status is "complete" or until a maximum number of
            // attempts is reached.  When the tab disappears (e.g. the user
            // closed it) the callback is invoked with false.
            function waitForTabReady(tabId, callback, attempts = 60) {
                if (attempts <= 0) {
                    callback(false);
                    return;
                }
                try {
                    chrome.tabs.get(tabId, function(tab) {
                        if (chrome.runtime.lastError || !tab) {
                            callback(false);
                        } else if (tab.status === 'complete') {
                            callback(true);
                        } else {
                            setTimeout(() => waitForTabReady(tabId, callback, attempts - 1), 500);
                        }
                    });
                } catch (err) {
                    callback(false);
                }
            }

            // Start the login check and batch processing once the tab is fully
            // loaded.  Inject the page bridge script into the page context
            // after the load completes.  If the tab fails to load or is
            // closed, attempt to reacquire a new tab via the existing
            // logic.  This helper centralises the waiting logic so that
            // multiple callers can reuse it.
            function startProcessWithTab(tabId) {
                waitForTabReady(tabId, function(isReady) {
                    if (!isReady) {
                        // If the tab never became ready (perhaps it was
                        // closed or the URL changed), try to acquire a
                        // different tab and continue.  We re‑invoke
                        // findOrCreateTab() which will locate an existing
                        // WhatsApp tab or create a new one.  Avoid calling
                        // reacquireTabAndContinue() here because that helper
                        // is scoped inside processBatches and unavailable
                        // outside its closure.
                        try {
                            findOrCreateTab();
                        } catch (e) {
                            console.warn('whatsappCheck: failed to reacquire tab from startProcessWithTab', e);
                            // As a fallback, clear the checking state so the
                            // user can try again.
                            $scope.$apply(() => {
                                $scope.local.isCheckingWhatsapp = false;
                                $scope.local.pausedWhatsapp = false;
                                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                    $scope.snackbar.show('Unable to load WhatsApp Web. Please try again.');
                                }
                                $scope.saveLocal();
                            });
                        }
                        return;
                    }
                    // Inject the bridge script into the page context.  If
                    // injection fails we still proceed with the login check;
                    // the content script alone may be sufficient.
                    try {
                        chrome.scripting.executeScript({
                            target: { tabId: tabId, allFrames: true },
                            files: ['whatsapp/pageBridge.js'],
                            world: 'MAIN'
                        }, function() {
                            try {
                                performLoginAndCheck(tabId);
                            } catch (err) {
                                console.warn('whatsappCheck: error during performLoginAndCheck after bridge injection', err);
                                // If the login check fails after injection, try
                                // to start over by finding or creating a new tab.
                                try {
                                    findOrCreateTab();
                                } catch (e) {
                                    console.warn('whatsappCheck: failed to retry after bridge injection error', e);
                                    $scope.$apply(() => {
                                        $scope.local.isCheckingWhatsapp = false;
                                        $scope.local.pausedWhatsapp = false;
                                        if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                            $scope.snackbar.show('Error communicating with WhatsApp Web.');
                                        }
                                        $scope.saveLocal();
                                    });
                                }
                            }
                        });
                    } catch (err) {
                        console.warn('whatsappCheck: error injecting bridge in startProcessWithTab', err);
                        try {
                            performLoginAndCheck(tabId);
                        } catch (e) {
                            console.warn('whatsappCheck: error invoking performLoginAndCheck from startProcessWithTab', e);
                            try {
                                findOrCreateTab();
                            } catch (err2) {
                                console.warn('whatsappCheck: failed to reacquire tab after performLoginAndCheck error', err2);
                                $scope.$apply(() => {
                                    $scope.local.isCheckingWhatsapp = false;
                                    $scope.local.pausedWhatsapp = false;
                                    if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                        $scope.snackbar.show('Unable to continue WhatsApp check.');
                                    }
                                    $scope.saveLocal();
                                });
                            }
                        }
                    }
                });
            }

            // Process numbers in batches after verifying login.  The delay between
            // batches has been reduced and robust tab/message handling is used to
            // recover from closed tabs or missing receivers without user
            // intervention.  See comments within for details.
            function processBatches(tabId) {
                // Capture the current run identifier so that outdated async
                // callbacks from prior runs can detect when they should no
                // longer update the UI or progress.  whatsappCheck increments
                // $scope.waRunId at the beginning of each invocation.
                const currentRunId = $scope.waRunId;
                // Keep the current WhatsApp tab ID so it can be updated if the tab
                // disappears or a new one is needed.
                let currentTabId = tabId;
                // Process one number at a time to avoid overlapping UI actions.
                const batchSize = 1;
                // No artificial delay between numbers.  The only waits occur within
                // the WhatsApp UI automation itself (500ms after the chat opens
                // and 1s after pasting).  Setting delayMs to 0 allows
                // processing to continue as soon as the previous check
                // completes.
                const delayMs = 0;
                // Iterate through all rows requiring WhatsApp checking.  The
                // index represents the position within rowsWithPhone.  Since
                // rowsWithPhone contains only rows whose whatsapp_status is
                // not yet final (i.e. neither 'Available' nor 'Not available'),
                // there is no need to skip over completed rows when
                // resuming a check.
                let index = 0;
                // The total number of rows that require checking.  This is
                // derived from the list built in whatsappCheck and aligns
                // with whatsappProgress.total.
                const total = $scope.whatsappProgress ? $scope.whatsappProgress.total : 0;
                const updateResults = (results, start) => {
                    // Abort if this update belongs to an old run.  When the user
                    // stops and restarts a WhatsApp check quickly, asynchronous
                    // callbacks from the previous run can still fire.  Use
                    // currentRunId captured in the closure to detect these
                    // stale updates and ignore them.
                    if (currentRunId !== $scope.waRunId) {
                        return;
                    }
                    results = Array.isArray(results) ? results : [];
                    $scope.$apply(() => {
                        let processed = 0;
                        for (let i = 0; i < results.length; i++) {
                            const rowIndex = rowsWithPhone[start + i];
                            const row = Array.isArray($scope.local.collect) ? $scope.local.collect[rowIndex] : undefined;
                            if (!row) continue;
                            const result = results[i] || {};
                            // Preserve any logs sent back from the injected script
                            if (Array.isArray(result.logs)) {
                                row.whatsapp_log = result.logs;
                            }
                            // Assign a final status only when the lookup succeeds.  If
                            // an error is returned (e.g. due to a temporary
                            // communication failure) leave the status blank so that
                            // the row can be retried.  Only increment the processed
                            // counter for successful lookups so that the progress
                            // bar does not reach 100% while blank statuses remain.
                            if (result.error) {
                                row.whatsapp_status = '';
                            } else {
                                row.whatsapp_status = result.exists ? 'Available' : 'Not available';
                                processed++;
                            }
                        }
                        if ($scope.whatsappProgress && $scope.whatsappProgress.total > 0) {
                            $scope.whatsappProgress.completed += processed;
                            const perc = Math.round(($scope.whatsappProgress.completed / $scope.whatsappProgress.total) * 100);
                            $scope.whatsappProgress.percent = perc > 100 ? 100 : perc;
                        }
                        try {
                            if (typeof $scope.saveLocal === 'function') {
                                $scope.saveLocal();
                            }
                            updateDataTable($scope.local);
                        } catch (err) {
                            console.warn('whatsappCheck: failed to update grid after batch', err);
                        }
                    });
                };
                // Helper to reacquire or create a WhatsApp tab and resume processing
                function reacquireTabAndContinue() {
                    try {
                        chrome.tabs.query({ url: ['https://web.whatsapp.com/*', 'https://*.whatsapp.com/*'] }, function(tabs) {
                            if (chrome.runtime.lastError) {
                                console.warn('whatsappCheck: error querying tabs during reacquire', chrome.runtime.lastError);
                                // On failure, cancel remaining rows and stop
                                $scope.$apply(() => {
                                    for (let j = index; j < rowsWithPhone.length; j++) {
                                        const idxRow = rowsWithPhone[j];
                                        if (typeof idxRow !== 'undefined') {
                                            const cancelObj = Array.isArray($scope.local.collect) ? $scope.local.collect[idxRow] : undefined;
                                            if (cancelObj) {
                                                cancelObj.whatsapp_status = 'Cancelled';
                                            }
                                        }
                                    }
                                    if ($scope.whatsappProgress) {
                                        $scope.whatsappProgress.total = 0;
                                        $scope.whatsappProgress.completed = 0;
                                        $scope.whatsappProgress.percent = 0;
                                    }
                                    $scope.local.pausedWhatsapp = true;
                                    $scope.local.isCheckingWhatsapp = false;
                                    if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                        $scope.snackbar.show('WhatsApp Web tab could not be found.');
                                    }
                                    try {
                                        if (typeof $scope.saveLocal === 'function') {
                                            $scope.saveLocal();
                                        }
                                        updateDataTable($scope.local);
                                    } catch (err2) {
                                        console.warn('whatsappCheck: failed to update grid after tab reacquire error', err2);
                                    }
                                });
                                return;
                            }
                            if (tabs && tabs.length > 0) {
                                currentTabId = tabs[0].id;
                                try {
                                    chrome.scripting.executeScript({
                                        target: { tabId: currentTabId, allFrames: true },
                                        files: ['whatsapp/pageBridge.js'],
                                        world: 'MAIN'
                                    }, function() {
                                        setTimeout(() => {
                                            handleBatch();
                                        }, 1000);
                                    });
                                } catch (err) {
                                    console.warn('whatsappCheck: error injecting bridge during reacquire', err);
                                    setTimeout(() => {
                                        handleBatch();
                                    }, 1000);
                                }
                            } else {
                                chrome.tabs.create({ url: 'https://web.whatsapp.com/', active: false }, function(newTab) {
                                    if (newTab && newTab.id != null) {
                                        currentTabId = newTab.id;
                                        try {
                                            setTimeout(() => {
                                                chrome.scripting.executeScript({
                                                    target: { tabId: currentTabId, allFrames: true },
                                                    files: ['whatsapp/pageBridge.js'],
                                                    world: 'MAIN'
                                                }, function() {
                                                    setTimeout(() => {
                                                        handleBatch();
                                                    }, 1000);
                                                });
                                            }, 1000);
                                        } catch (err) {
                                            console.warn('whatsappCheck: error injecting bridge into new tab during reacquire', err);
                                            setTimeout(() => {
                                                handleBatch();
                                            }, 2000);
                                        }
                                    } else {
                                        $scope.$apply(() => {
                                            for (let j = index; j < rowsWithPhone.length; j++) {
                                                const idxRow = rowsWithPhone[j];
                                                if (typeof idxRow !== 'undefined') {
                                                    const cancelObj = Array.isArray($scope.local.collect) ? $scope.local.collect[idxRow] : undefined;
                                                    if (cancelObj) {
                                                        cancelObj.whatsapp_status = 'Cancelled';
                                                    }
                                                }
                                            }
                                            if ($scope.whatsappProgress) {
                                                $scope.whatsappProgress.total = 0;
                                                $scope.whatsappProgress.completed = 0;
                                                $scope.whatsappProgress.percent = 0;
                                            }
                                            $scope.local.pausedWhatsapp = true;
                                            $scope.local.isCheckingWhatsapp = false;
                                            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                                $scope.snackbar.show('Failed to open WhatsApp Web tab.');
                                            }
                                            try {
                                                if (typeof $scope.saveLocal === 'function') {
                                                    $scope.saveLocal();
                                                }
                                                updateDataTable($scope.local);
                                            } catch (err2) {
                                                console.warn('whatsappCheck: failed to update grid after new tab failure', err2);
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    } catch (err) {
                        console.warn('whatsappCheck: unexpected error during tab reacquire', err);
                        $scope.$apply(() => {
                            for (let j = index; j < rowsWithPhone.length; j++) {
                                const idxRow = rowsWithPhone[j];
                                if (typeof idxRow !== 'undefined') {
                                    const cancelObj = Array.isArray($scope.local.collect) ? $scope.local.collect[idxRow] : undefined;
                                    if (cancelObj) {
                                        cancelObj.whatsapp_status = 'Cancelled';
                                    }
                                }
                            }
                            if ($scope.whatsappProgress) {
                                $scope.whatsappProgress.total = 0;
                                $scope.whatsappProgress.completed = 0;
                                $scope.whatsappProgress.percent = 0;
                            }
                            $scope.local.pausedWhatsapp = true;
                            $scope.local.isCheckingWhatsapp = false;
                            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                $scope.snackbar.show('Unexpected error while recovering WhatsApp tab.');
                            }
                            try {
                                if (typeof $scope.saveLocal === 'function') {
                                    $scope.saveLocal();
                                }
                                updateDataTable($scope.local);
                            } catch (err2) {
                                console.warn('whatsappCheck: failed to update grid after unexpected reacquire error', err2);
                            }
                        });
                    }
                }
                const handleBatch = () => {
                    // Skip this batch if it belongs to a previous run.  Without this
                    // guard, an old handleBatch may continue running after the user
                    // has cancelled the check and started a new one, resulting in
                    // gaps or premature completion popups.
                    if (currentRunId !== $scope.waRunId) {
                        return;
                    }
                    if ($scope.local.stopWhatsappCheck) {
                        $scope.$apply(() => {
                            for (let j = index; j < rowsWithPhone.length; j++) {
                                const idxRow = rowsWithPhone[j];
                                if (typeof idxRow !== 'undefined') {
                                    const cancelObj = Array.isArray($scope.local.collect) ? $scope.local.collect[idxRow] : undefined;
                                    if (cancelObj) {
                                        cancelObj.whatsapp_status = 'Cancelled';
                                    }
                                }
                            }
                            if ($scope.whatsappProgress) {
                                $scope.whatsappProgress.total = 0;
                                $scope.whatsappProgress.completed = 0;
                                $scope.whatsappProgress.percent = 0;
                            }
                            $scope.local.pausedWhatsapp = true;
                            $scope.local.isCheckingWhatsapp = false;
                            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                $scope.snackbar.show('WhatsApp number check stopped.');
                            }
                            try {
                                if (typeof $scope.saveLocal === 'function') {
                                    $scope.saveLocal();
                                }
                                updateDataTable($scope.local);
                            } catch (err) {
                                console.warn('whatsappCheck: failed to update grid after stop', err);
                            }
                        });
                        return;
                    }
                        // If the scanning index has reached or passed the end of
                        // rowsWithPhone, then we have examined every row (either
                        // processed or skipped) and the current pass is
                        // complete.
                        if (index >= rowsWithPhone.length) {
                            // Completed one full pass over all numbers.  Determine if
                            // any rows remain without a final status.  Blank or
                            // "Started" statuses indicate that an error occurred
                            // during lookup (e.g. a transient network issue) and
                            // should be retried.  We attempt a limited number of
                            // automatic retries before finalising.  If no blanks
                            // remain, mark the run as complete and show a
                            // completion message.
                            $scope.$apply(() => {
                                try {
                                    // Determine if any phone numbers across the entire collection remain
                                    // without a final status.  We cannot rely solely on rowsWithPhone
                                    // here because the DataTable pagination or prior runs may have
                                    // affected which rows are included.  A row still counts as
                                    // requiring processing if it contains a phone number and its
                                    // whatsapp_status is blank, "started" or any other non‑final
                                    // value (excluding "available" and "not available").
                                    const blanks = [];
                                    const rowsAll = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
                                    for (let ii = 0; ii < rowsAll.length; ii++) {
                                        const r = rowsAll[ii];
                                        // Skip rows without a phone number
                                        if (!r || !r.phone) continue;
                                        const st = String(r.whatsapp_status || '').toLowerCase();
                                        if (st === 'available' || st === 'not available') {
                                            continue;
                                        }
                                        blanks.push(ii);
                                    }
                                    if (blanks.length > 0) {
                                        // Initialise the retry counter if undefined.  This
                                        // counter persists across automatic retries and is
                                        // not reset when the user manually invokes
                                        // whatsappCheck().
                                        if (typeof $scope.waRetryCount === 'undefined') {
                                            $scope.waRetryCount = 0;
                                        }
                                        // Continue retrying blank statuses until all numbers
                                        // are resolved or until a high retry threshold is
                                        // reached.  Do not mark blanks as "Not available" here;
                                        // instead allow additional passes to attempt actual
                                        // lookups.  When the retry threshold is exceeded,
                                        // stop trying further and leave the blanks unresolved.
                                        const RETRY_LIMIT = 5;
                                        if ($scope.waRetryCount < RETRY_LIMIT) {
                                            $scope.waRetryCount++;
                                            // Clear the isChecking flag so the new run can start.
                                            $scope.local.isCheckingWhatsapp = false;
                                            // Save current state before retrying to persist partial results.
                                            if (typeof $scope.saveLocal === 'function') {
                                                $scope.saveLocal();
                                            }
                                            // Schedule another pass after a short delay.  Flag this
                                            // invocation as an auto‑retry so whatsappCheck() does
                                            // not reset the retry counter.
                                            setTimeout(() => {
                                                try {
                                                    $scope.waAutoRetry = true;
                                                    $scope.whatsappCheck();
                                                } catch (e) {
                                                    console.warn('whatsappCheck: error during automatic retry', e);
                                                }
                                            }, 500);
                                            return;
                                        } else {
                                            // Too many retries without resolving blanks.  Do not
                                            // show the completion popup; instead notify the user
                                            // that some numbers could not be processed.  Leave
                                            // unresolved statuses blank so they are obvious in
                                            // the grid.
                                            $scope.local.isCheckingWhatsapp = false;
                                            if ($scope.whatsappProgress) {
                                                // Do not force progress to 100% as the run is
                                                // incomplete.  Leave the progress bar at its
                                                // current value.
                                            }
                                            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                                $scope.snackbar.show('Some numbers could not be processed. Please resume the check.');
                                            }
                                            if (typeof $scope.saveLocal === 'function') {
                                                $scope.saveLocal();
                                            }
                                            updateDataTable($scope.local);
                                            return;
                                        }
                                    }
                                    // At this point either no blanks remain or we have
                                    // filled them with Not available after exhausting
                                    // retries.  Mark the run as complete and display
                                    // the completion message.
                                    $scope.local.isCheckingWhatsapp = false;
                                    // Ensure the progress bar reflects completion.
                                    if ($scope.whatsappProgress) {
                                        $scope.whatsappProgress.completed = $scope.whatsappProgress.total;
                                        $scope.whatsappProgress.percent = 100;
                                    }
                                    if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                        $scope.snackbar.show('WhatsApp number check completed.');
                                    }
                                    if (typeof $scope.saveLocal === 'function') {
                                        $scope.saveLocal();
                                    }
                                    updateDataTable($scope.local);
                                } catch (finalErr) {
                                    console.warn('whatsappCheck: error during finalisation', finalErr);
                                    $scope.local.isCheckingWhatsapp = false;
                                    if (typeof $scope.saveLocal === 'function') {
                                        $scope.saveLocal();
                                    }
                                }
                            });
                            return;
                        }
                    // rowsWithPhone contains only rows that still require
                    // checking, so there is no need to skip over rows with
                    // final statuses here.
                    const start = index;
                    // Resolve the row index and row object from rowsWithPhone.
                    const idxRow = rowsWithPhone[start];
                    const row = Array.isArray($scope.local.collect) ? $scope.local.collect[idxRow] : undefined;
                    const digits = row && row._waDigits ? row._waDigits : null;
                    if (!digits) {
                        // No digits found for this row; mark as not available and continue.
                        $scope.$apply(() => {
                            if (row) {
                                row.whatsapp_status = 'Not available';
                            }
                            try {
                                if (typeof $scope.saveLocal === 'function') {
                                    $scope.saveLocal();
                                }
                                updateDataTable($scope.local);
                            } catch (err) {
                                console.warn('whatsappCheck: failed to mark missing digits row', err);
                            }
                        });
                        index++;
                        setTimeout(handleBatch, delayMs);
                        return;
                    }
                    // Mark this row as started before sending to the content script.
                    (function markStarted() {
                        $scope.$apply(() => {
                            if (row) {
                                row.whatsapp_status = 'Started';
                            }
                            try {
                                if (typeof $scope.saveLocal === 'function') {
                                    $scope.saveLocal();
                                }
                                updateDataTable($scope.local);
                            } catch (err) {
                                console.warn('whatsappCheck: failed to mark row as started', err);
                            }
                        });
                    })();
                    try {
                        chrome.tabs.get(currentTabId, function(tabInfo) {
                            if (chrome.runtime.lastError || !tabInfo) {
                                console.warn('whatsappCheck: current tab invalid before sending batch', chrome.runtime.lastError);
                                reacquireTabAndContinue();
                                return;
                            }
                            chrome.tabs.sendMessage(currentTabId, { action: 'checkPhones', numbers: [digits] }, function(res) {
                                if (chrome.runtime.lastError) {
                                    const err = chrome.runtime.lastError;
                                    console.warn('whatsappCheck: error sending phone batch', err);
                                    const msg = String(err && err.message || '').toLowerCase();
                                    if (msg.includes('no tab with id') || msg.includes('receiving end does not exist') || msg.includes('could not establish connection')) {
                                        // The tab may have closed or the content script may not be ready.
                                        // Wait for the tab to finish loading and retry the batch.  If the
                                        // tab disappears, reacquire or create a new tab and resume.
                                        waitForTabReady(currentTabId, function(ready) {
                                            if (ready) {
                                                setTimeout(() => {
                                                    handleBatch();
                                                }, 1000);
                                            } else {
                                                reacquireTabAndContinue();
                                            }
                                        });
                                        return;
                                    }
                                    // On communication errors, treat this row as not available.
                                    const fallback = [{ exists: false }];
                                    updateResults(fallback, start);
                                    $scope.$apply(() => {
                                        $scope.local.isCheckingWhatsapp = false;
                                        if ($scope.whatsappProgress && $scope.whatsappProgress.total > 0) {
                                            $scope.whatsappProgress.completed = $scope.whatsappProgress.total;
                                            $scope.whatsappProgress.percent = 100;
                                        }
                                        if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                            $scope.snackbar.show('Unable to communicate with WhatsApp Web.');
                                        }
                                        $scope.saveLocal();
                                    });
                                    return;
                                }
                                const results = res && Array.isArray(res.results) ? res.results : [{ exists: false }];
                                updateResults(results, start);
                                // Move to the next row for the next iteration.
                                index++;
                                setTimeout(handleBatch, delayMs);
                            });
                        });
                    } catch (sendErr) {
                        console.warn('whatsappCheck: unexpected error before send', sendErr);
                        reacquireTabAndContinue();
                    }
                };
                handleBatch();
            }

            // Perform login check.  If logged in, begin batch processing.  Retry
            // injection if no receiver is found.  Use a finite number of attempts.
            function performLoginAndCheck(tabId, attempts = 10) {
                try {
                    chrome.tabs.sendMessage(tabId, { action: 'checkLogin' }, function(res) {
                        if (chrome.runtime.lastError) {
                            console.warn('whatsappCheck: no receiver yet', chrome.runtime.lastError);
                            // When the content script is not yet ready, wait for the tab to
                            // finish loading and retry.  Avoid reinjecting the bridge here;
                            // that is handled when the tab first loads.  Decrement
                            // the attempts counter to avoid infinite loops.  If the tab
                            // disappears, attempt to find or create a new WhatsApp tab.
                            if (attempts > 0) {
                                waitForTabReady(tabId, function(ready) {
                                    if (ready) {
                                        setTimeout(() => performLoginAndCheck(tabId, attempts - 1), 1000);
                                    } else {
                                        // Tab is not ready or was closed; start over
                                        try {
                                            findOrCreateTab();
                                        } catch (e) {
                                            console.warn('whatsappCheck: failed to reacquire tab during login retry', e);
                                            $scope.$apply(() => {
                                                // rowsWithPhone contains row indexes; update each row's status via index
                                                rowsWithPhone.forEach(idx => {
                                                    const rowObj = $scope.local.collect && typeof idx === 'number' ? $scope.local.collect[idx] : null;
                                                    if (rowObj) {
                                                        rowObj.whatsapp_status = 'Failed';
                                                    }
                                                });
                                                $scope.local.isCheckingWhatsapp = false;
                                                if ($scope.whatsappProgress && $scope.whatsappProgress.total > 0) {
                                                    $scope.whatsappProgress.completed = $scope.whatsappProgress.total;
                                                    $scope.whatsappProgress.percent = 100;
                                                }
                                                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                                    $scope.snackbar.show('Unable to reach WhatsApp Web.');
                                                }
                                                try {
                                                    updateDataTable($scope.local);
                                                } catch (e2) {
                                                    console.warn('whatsappCheck: failed to refresh grid on receiver exhaustion', e2);
                                                }
                                                $scope.saveLocal();
                                            });
                                        }
                                    }
                                });
                            } else {
                                // Exhausted retries: fail and mark rows as Failed
                                $scope.$apply(() => {
                                    // rowsWithPhone contains row indexes; update each row's status via index
                                    rowsWithPhone.forEach(idx => {
                                        const rowObj = $scope.local.collect && typeof idx === 'number' ? $scope.local.collect[idx] : null;
                                        if (rowObj) {
                                            rowObj.whatsapp_status = 'Failed';
                                        }
                                    });
                                    $scope.local.isCheckingWhatsapp = false;
                                    if ($scope.whatsappProgress && $scope.whatsappProgress.total > 0) {
                                        $scope.whatsappProgress.completed = $scope.whatsappProgress.total;
                                        $scope.whatsappProgress.percent = 100;
                                    }
                                    if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                        $scope.snackbar.show('WhatsApp Web is not responding. Please reload the page and try again.');
                                    }
                                    try {
                                        updateDataTable($scope.local);
                                    } catch (e) {
                                        console.warn('whatsappCheck: failed to refresh grid on receiver exhaustion', e);
                                    }
                                    $scope.saveLocal();
                                });
                            }
                            return;
                        }
                        if (!res || !res.loggedIn) {
                            // If the user is not logged in, immediately stop the process and
                            // notify them via a clear error message.  Do not schedule
                            // retries or leave the progress bar active.  Clear any
                            // outstanding progress and leave row statuses blank so it is
                            // obvious that the check did not run.
                            $scope.$apply(() => {
                                // Reset row statuses for remaining entries
                                // Reset row statuses for remaining entries using indexes
                                rowsWithPhone.forEach(idx => {
                                    const rowObj = $scope.local.collect && typeof idx === 'number' ? $scope.local.collect[idx] : null;
                                    if (rowObj) {
                                        rowObj.whatsapp_status = '';
                                    }
                                });
                                // Reset progress indicators
                                if ($scope.whatsappProgress) {
                                    $scope.whatsappProgress.total = 0;
                                    $scope.whatsappProgress.completed = 0;
                                    $scope.whatsappProgress.percent = 0;
                                }
                                // Clear flags so the UI knows the check has ended
                                $scope.local.pausedWhatsapp = false;
                                $scope.local.isCheckingWhatsapp = false;
                                $scope.local.stopWhatsappCheck = false;
                                // Display an explicit not‑logged‑in message.  Avoid generic
                                // wording so users know why the check ended.
                                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                    $scope.snackbar.show('WhatsApp not logged in');
                                }
                                try {
                                    updateDataTable($scope.local);
                                } catch (e) {
                                    console.warn('whatsappCheck: failed to refresh grid after login check', e);
                                }
                                if (typeof $scope.saveLocal === 'function') {
                                    $scope.saveLocal();
                                }
                            });
                            return;
                        }
                        // logged in
                        processBatches(tabId);
                    });
                } catch (err) {
                    console.warn('whatsappCheck: error sending login message', err);
                    $scope.$apply(() => {
                        $scope.local.isCheckingWhatsapp = false;
                        if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                            $scope.snackbar.show('Failed to communicate with WhatsApp Web.');
                        }
                        $scope.saveLocal();
                    });
                }
            }

            // Find or open a WhatsApp Web tab.  Do not cache the tab ID; always
            // query for existing tabs.  If no tab is found, open one and prompt
            // the user to log in.
            function findOrCreateTab() {
                try {
                    chrome.tabs.query({ url: ['https://web.whatsapp.com/*', 'https://*.whatsapp.com/*'] }, function(tabs) {
                        if (chrome.runtime.lastError) {
                            console.warn('whatsappCheck: error querying tabs', chrome.runtime.lastError);
                            $scope.$apply(() => {
                                $scope.local.isCheckingWhatsapp = false;
                                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                    $scope.snackbar.show('Failed to find WhatsApp Web tab.');
                                }
                                $scope.saveLocal();
                            });
                            return;
                        }
                        if (tabs && tabs.length > 0) {
                            // Use the first existing tab and do not activate it.  Rather than
                            // injecting immediately and starting the login check, wait for the
                            // tab to finish loading and then begin the process via
                            // startProcessWithTab().  This avoids sending messages to
                            // tabs that have not yet finished loading the content script.
                            const tabId = tabs[0].id;
                            startProcessWithTab(tabId);
                        } else {
                            // No WhatsApp tab open; create one in the background.  Do not
                            // activate it so the user’s current tab remains focused.  Once
                            // created, wait for it to load and then inject the bridge and
                            // start processing.  If creation fails, mark rows as failed.
                            chrome.tabs.create({ url: 'https://web.whatsapp.com/', active: false }, function(newTab) {
                                if (newTab && newTab.id != null) {
                                    const newTabId = newTab.id;
                                    // Wait for the tab to load before injecting and starting.
                                    startProcessWithTab(newTabId);
                                } else {
                                    $scope.$apply(() => {
                                    // rowsWithPhone contains row indexes; update each row's status via index
                                    rowsWithPhone.forEach(idx => {
                                        const rowObj = $scope.local.collect && typeof idx === 'number' ? $scope.local.collect[idx] : null;
                                        if (rowObj) {
                                            rowObj.whatsapp_status = 'Failed';
                                        }
                                    });
                                        $scope.local.isCheckingWhatsapp = false;
                                        if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                                            $scope.snackbar.show('Unable to open WhatsApp Web.');
                                        }
                                        try {
                                            updateDataTable($scope.local);
                                        } catch (e) {
                                            console.warn('whatsappCheck: failed to refresh grid after tab creation failure', e);
                                        }
                                        $scope.saveLocal();
                                    });
                                }
                            });
                        }
                    });
                } catch (err) {
                    console.warn('whatsappCheck: error during tab lookup or creation', err);
                    $scope.$apply(() => {
                        $scope.local.isCheckingWhatsapp = false;
                        // rowsWithPhone contains row indexes; update each row's status via index
                        rowsWithPhone.forEach(idx => {
                            const rowObj = $scope.local.collect && typeof idx === 'number' ? $scope.local.collect[idx] : null;
                            if (rowObj) {
                                rowObj.whatsapp_status = 'Failed';
                            }
                        });
                        if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                            $scope.snackbar.show('Failed to open WhatsApp Web.');
                        }
                        try {
                            updateDataTable($scope.local);
                        } catch (e) {
                            console.warn('whatsappCheck: failed to refresh grid after tab error', e);
                        }
                        $scope.saveLocal();
                    });
                }
            }
            // Start process by finding or creating a tab
            findOrCreateTab();
        } catch (err) {
            console.warn('whatsappCheck: unexpected error', err);
            if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                $scope.snackbar.show('An error occurred during WhatsApp check.');
            }
            $scope.local.isCheckingWhatsapp = false;
            $scope.saveLocal();
        }
    };

    /**
     * Cancel an ongoing WhatsApp number check.  Sets a flag that
     * causes the current batch processor to abort after the current
     * number finishes.  When invoked while a check is in progress,
     * remaining numbers are marked as Cancelled and the progress bar
     * completes.
     */
    $scope.stopWhatsappCheck = function() {
        try {
            if ($scope.local.isCheckingWhatsapp) {
                $scope.local.stopWhatsappCheck = true;
                if ($scope.snackbar && typeof $scope.snackbar.show === 'function') {
                    $scope.snackbar.show('Stopping WhatsApp number check...');
                }
            }
        } catch (err) {
            console.warn('stopWhatsappCheck: error stopping WhatsApp check', err);
        }
    };

    /**
     * Toggle the WhatsApp number check.  When a check is not currently
     * running this will start a new session by invoking whatsappCheck().  If
     * a check is already in progress it will request cancellation via
     * stopWhatsappCheck().  This mirrors the Start/Stop behaviour of the
     * main scraper button so that users only need to click one control to
     * begin or end the WhatsApp lookup process.
     */
    $scope.toggleWhatsappCheck = function() {
        try {
            // If already checking, request a stop.  Otherwise begin a new check.
            if ($scope.local.isCheckingWhatsapp) {
                $scope.stopWhatsappCheck();
            } else {
                $scope.whatsappCheck();
            }
        } catch (err) {
            console.warn('toggleWhatsappCheck: error toggling WhatsApp check', err);
        }
    };

    /**
     * Resume a paused WhatsApp number check.  When invoked this function
     * simply calls whatsappCheck again.  The whatsappCheck logic
     * automatically skips rows that already have a final status and
     * reprocesses any rows marked as Cancelled.  The paused flag is
     * cleared within whatsappCheck.  If no check is currently running
     * this will start a new session; if a check is in progress the
     * resume request is ignored.
     */
    $scope.resumeWhatsappCheck = function() {
        try {
            if (!$scope.local.isCheckingWhatsapp) {
                $scope.whatsappCheck();
            }
        } catch (err) {
            console.warn('resumeWhatsappCheck: error resuming WhatsApp check', err);
        }
    };

    /**
     * Start the WA number check using the local-only workflow.
     *
     * This function collects all phone numbers from the current
     * local.collect array, normalises them to remove non-digits and
     * leading zeros, and sends a message to the background service
     * worker to begin processing.  Each row's index is used as the
     * rowId so that results can be mapped back onto the grid.  Prior
     * statuses are cleared before starting.  If no phone numbers are
     * found a snackbar message is displayed.
     */
    /**
     * Initiate or stop a WhatsApp number check.
     *
     * When not currently running a WA check this function gathers all
     * phone numbers from the current table, clears any existing WA
     * status fields, resets the progress counters and sends a
     * start_wa_check message to the background service worker.  While
     * a WA check is in progress the same button acts as a cancel
     * control.  Clicking during an active check sends a stop_wa_check
     * message and immediately resets the UI state.  Progress is
     * tracked via waTotal and waFinished, and waChecking indicates
     * whether a check is currently running.
     */
    const WA_COUNTRY_DIAL_CODES = {
        'afghanistan': '93', 'albania': '355', 'algeria': '213', 'american samoa': '1', 'andorra': '376',
        'angola': '244', 'anguilla': '1', 'antigua and barbuda': '1', 'argentina': '54', 'armenia': '374',
        'aruba': '297', 'australia': '61', 'austria': '43', 'azerbaijan': '994', 'bahamas': '1',
        'bahrain': '973', 'bangladesh': '880', 'barbados': '1', 'belarus': '375', 'belgium': '32',
        'belize': '501', 'benin': '229', 'bermuda': '1', 'bhutan': '975', 'bolivia': '591',
        'bolivia, plurinational state of': '591', 'bosnia and herzegovina': '387', 'botswana': '267',
        'brazil': '55', 'brunei darussalam': '673', 'bulgaria': '359', 'burkina faso': '226', 'burundi': '257',
        'cabo verde': '238', 'cambodia': '855', 'cameroon': '237', 'canada': '1', 'cayman islands': '1',
        'central african republic': '236', 'chad': '235', 'chile': '56', 'china': '86', 'colombia': '57',
        'comoros': '269', 'congo': '242', 'congo, the democratic republic of the': '243', 'costa rica': '506',
        'croatia': '385', 'cuba': '53', 'cyprus': '357', 'czechia': '420', "côte d'ivoire": '225',
        'denmark': '45', 'djibouti': '253', 'dominica': '1', 'dominican republic': '1', 'ecuador': '593',
        'egypt': '20', 'el salvador': '503', 'equatorial guinea': '240', 'eritrea': '291', 'estonia': '372',
        'eswatini': '268', 'ethiopia': '251', 'fiji': '679', 'finland': '358', 'france': '33',
        'french guiana': '594', 'french polynesia': '689', 'gabon': '241', 'gambia': '220', 'georgia': '995',
        'germany': '49', 'ghana': '233', 'gibraltar': '350', 'greece': '30', 'greenland': '299',
        'grenada': '1', 'guadeloupe': '590', 'guam': '1', 'guatemala': '502', 'guinea': '224',
        'guinea-bissau': '245', 'guyana': '592', 'haiti': '509', 'honduras': '504', 'hong kong': '852',
        'hungary': '36', 'iceland': '354', 'india': '91', 'bharat': '91', 'indonesia': '62',
        'iran, islamic republic of': '98', 'iraq': '964', 'ireland': '353', 'israel': '972', 'italy': '39',
        'jamaica': '1', 'japan': '81', 'jordan': '962', 'kazakhstan': '7', 'kenya': '254',
        'kiribati': '686', 'korea, republic of': '82', 'south korea': '82', 'kuwait': '965', 'kyrgyzstan': '996',
        "lao people's democratic republic": '856', 'latvia': '371', 'lebanon': '961', 'lesotho': '266',
        'liberia': '231', 'libya': '218', 'liechtenstein': '423', 'lithuania': '370', 'luxembourg': '352',
        'macao': '853', 'madagascar': '261', 'malawi': '265', 'malaysia': '60', 'maldives': '960',
        'mali': '223', 'malta': '356', 'marshall islands': '692', 'martinique': '596', 'mauritania': '222',
        'mauritius': '230', 'mexico': '52', 'micronesia, federated states of': '691', 'moldova, republic of': '373',
        'monaco': '377', 'mongolia': '976', 'montenegro': '382', 'morocco': '212', 'mozambique': '258',
        'myanmar': '95', 'namibia': '264', 'nauru': '674', 'nepal': '977', 'netherlands': '31',
        'new caledonia': '687', 'new zealand': '64', 'nicaragua': '505', 'niger': '227', 'nigeria': '234',
        'north macedonia': '389', 'norway': '47', 'oman': '968', 'pakistan': '92', 'palau': '680',
        'palestine, state of': '970', 'panama': '507', 'papua new guinea': '675', 'paraguay': '595',
        'peru': '51', 'philippines': '63', 'poland': '48', 'portugal': '351', 'puerto rico': '1',
        'qatar': '974', 'romania': '40', 'russian federation': '7', 'russia': '7', 'rwanda': '250',
        'saudi arabia': '966', 'senegal': '221', 'serbia': '381', 'seychelles': '248', 'sierra leone': '232',
        'singapore': '65', 'slovakia': '421', 'slovenia': '386', 'solomon islands': '677', 'somalia': '252',
        'south africa': '27', 'south sudan': '211', 'spain': '34', 'sri lanka': '94', 'sudan': '249',
        'suriname': '597', 'sweden': '46', 'switzerland': '41', 'syrian arab republic': '963',
        'taiwan, province of china': '886', 'tajikistan': '992', 'tanzania, united republic of': '255',
        'thailand': '66', 'timor-leste': '670', 'togo': '228', 'tonga': '676', 'trinidad and tobago': '1',
        'tunisia': '216', 'turkmenistan': '993', 'türkiye': '90', 'turkey': '90', 'uganda': '256',
        'ukraine': '380', 'united arab emirates': '971', 'uae': '971', 'united kingdom': '44', 'uk': '44',
        'united states': '1', 'usa': '1', 'us': '1', 'uruguay': '598', 'uzbekistan': '998',
        'vanuatu': '678', 'venezuela, bolivarian republic of': '58', 'viet nam': '84', 'vietnam': '84',
        'yemen': '967', 'zambia': '260', 'zimbabwe': '263'
    };

    function waCountryDialPrefix() {
        const country = String(($scope.local && ($scope.local.country || ($scope.local.apifySettings && $scope.local.apifySettings.countryFilter))) || 'India').trim().toLowerCase();
        return WA_COUNTRY_DIAL_CODES[country] || '91';
    }

    function waNormalizeDigits(value) {
        let digits = String(value || '').replace(/\D/g, '').replace(/^0+/, '');
        return digits;
    }

    function waNumberForApi(rawInput) {
        const rawStr = String(rawInput || '').trim();
        const hasLeadingPlus = rawStr.startsWith('+');
        let digits = rawStr.replace(/\D/g, '');
        if (!digits) return '';
        if (hasLeadingPlus && digits.length >= 8 && digits.length <= 15) {
            return digits;
        }
        digits = digits.replace(/^0+/, '');
        if (!digits) return '';
        const prefix = waCountryDialPrefix() || '91';
        if (prefix === '91') {
            if (/^91\d{10}$/.test(digits)) return digits;
            if (/^\d{10}$/.test(digits)) return '91' + digits;
            if (digits.length > 10 && digits.slice(-10).match(/^[6-9]\d{9}$/)) return '91' + digits.slice(-10);
        }
        if (prefix && !digits.startsWith(prefix) && digits.length <= 10) {
            return prefix + digits;
        }
        return digits;
    }

    function waNumberForE164(rawInput) {
        const apiDigits = waNumberForApi(rawInput);
        return apiDigits ? ('+' + apiDigits.replace(/^\++/, '')) : '';
    }

    function waNormalizePhoneForDisplay(value) {
        return waNumberForE164(value);
    }

    function waResultKey(value) {
        const digits = waNormalizeDigits(value);
        if (!digits) return '';
        const prefix = waCountryDialPrefix() || '91';
        if (digits.startsWith('91') && digits.length === 12) return digits.slice(2);
        if (prefix && digits.startsWith(prefix) && digits.length > prefix.length + 6) return digits.slice(prefix.length);
        return digits;
    }

    function waSafeJson(value) {
        if (value === undefined || value === null) return '';
        if (typeof value === 'string') return value;
        if (typeof value === 'number' || typeof value === 'boolean') return String(value);
        try { return JSON.stringify(value); } catch (e) { return String(value); }
    }

    function waParseJsonMaybe(value) {
        if (!value) return null;
        if (typeof value === 'object') return value;
        if (typeof value !== 'string') return null;
        try { return JSON.parse(value); } catch (e) { return null; }
    }

    function waSchemaProperties(schema) {
        schema = waParseJsonMaybe(schema) || schema || {};
        if (schema.data) schema = waParseJsonMaybe(schema.data.inputSchema) || schema.data.inputSchema || schema.data;
        if (schema.inputSchema) schema = waParseJsonMaybe(schema.inputSchema) || schema.inputSchema;
        if (schema.schema) schema = waParseJsonMaybe(schema.schema) || schema.schema;
        if (schema.properties && typeof schema.properties === 'object') return schema.properties;
        return {};
    }

    function waAddSchemaInputVariants(variants, schema, clean, withPlus, prefix) {
        const props = waSchemaProperties(schema);
        const names = Object.keys(props || {});
        if (!names.length) return;
        const phoneNames = names.filter(name => /phone|mobile|number|contact|whatsapp|wa|input|text|list/i.test(name));
        const countryNames = names.filter(name => /country(code)?|dial(code)?|calling(code)?/i.test(name));
        const proxyName = names.find(name => /proxy/i.test(name));
        const addCommon = payload => {
            countryNames.forEach(name => {
                const prop = props[name] || {};
                const type = String(prop.type || '').toLowerCase();
                if (/code|dial|calling/i.test(name) || type === 'integer' || type === 'number') payload[name] = prefix || '91';
                else payload[name] = (($scope.local && $scope.local.country) || 'India');
            });
            if (proxyName && !payload[proxyName]) payload[proxyName] = { useApifyProxy: true };
            return payload;
        };
        phoneNames.forEach(name => {
            const prop = props[name] || {};
            const type = String(prop.type || '').toLowerCase();
            const itemType = prop.items && String(prop.items.type || '').toLowerCase();
            const list = /noPlus|raw|digits/i.test(name) ? clean : withPlus;
            if (type === 'string') {
                variants.push(addCommon({ [name]: list.join('\n') }));
                variants.push(addCommon({ [name]: list.join(',') }));
            } else if (type === 'array' && itemType === 'object') {
                variants.push(addCommon({ [name]: list.map((n, idx) => ({ phone: n, number: n, phoneNumber: n, mobile: n, name: 'Contact ' + (idx + 1) })) }));
            } else {
                variants.push(addCommon({ [name]: list }));
                variants.push(addCommon({ [name]: clean }));
            }
        });
    }

    function waPushUniqueVariant(out, seen, payload) {
        try {
            const key = JSON.stringify(payload);
            if (!seen.has(key)) { seen.add(key); out.push(payload); }
        } catch (e) { out.push(payload); }
    }

    function waBuildInputVariants(numbers, config) {
        const clean = Array.from(new Set((numbers || []).map(waNumberForApi).filter(Boolean)));
        const withPlus = clean.map(n => n.startsWith('+') ? n : '+' + n);
        const prefix = waCountryDialPrefix() || '91';
        const variants = [];
        const schemaVariants = [];
        waAddSchemaInputVariants(schemaVariants, config && config.inputSchema, clean, withPlus, prefix);
        const common = [
            // Many Apify WhatsApp validators require nested snake_case input,
            // for example: { input: { phone_numbers: [...] } }. Keep these first
            // so the known required field is satisfied before trying legacy names.
            { input: { phone_numbers: withPlus, country_code: prefix } },
            { input: { phone_numbers: clean, country_code: prefix } },
            { input: { phone_numbers: withPlus } },
            { input: { phone_numbers: clean } },
            { input: { phone_numbers: withPlus.join('\n'), country_code: prefix } },
            { input: { phone_numbers: clean.join('\n'), country_code: prefix } },
            { input: { numbers: withPlus, countryCode: prefix } },
            { input: { numbers: clean, countryCode: prefix } },
            { input: { phones: withPlus, countryCode: prefix } },
            { input: { phones: clean, countryCode: prefix } },
            { phone_numbers: withPlus, country_code: prefix },
            { phone_numbers: clean, country_code: prefix },
            { phone_numbers: withPlus },
            { phone_numbers: clean },
            { phone_numbers: withPlus.join('\n'), country_code: prefix },
            { phone_numbers: clean.join('\n'), country_code: prefix },
            { phone_number: withPlus.join('\n'), country_code: prefix },
            ...schemaVariants,
            { phoneNumbers: withPlus, countryCode: prefix },
            { numbers: withPlus, countryCode: prefix },
            { phones: withPlus, countryCode: prefix },
            { mobileNumbers: withPlus, countryCode: prefix },
            { whatsappNumbers: withPlus, countryCode: prefix },
            { contacts: withPlus.map((n, idx) => ({ phone: n, number: n, phoneNumber: n, name: 'Contact ' + (idx + 1) })), countryCode: prefix },
            { phoneNumbers: withPlus },
            { numbers: withPlus },
            { phones: withPlus },
            { mobileNumbers: withPlus },
            { whatsappNumbers: withPlus },
            { contacts: withPlus.map((n, idx) => ({ phone: n, number: n, phoneNumber: n, name: 'Contact ' + (idx + 1) })) },
            { phoneNumbers: clean, countryCode: prefix },
            { numbers: clean, countryCode: prefix },
            { phones: clean, countryCode: prefix },
            { phoneNumbers: clean },
            { numbers: clean },
            { phones: clean },
            { phone: withPlus.join('\n'), countryCode: prefix },
            { phones: withPlus.join('\n'), countryCode: prefix },
            { numbers: withPlus.join('\n'), countryCode: prefix },
            { phoneNumbers: withPlus.join('\n'), countryCode: prefix },
            { input: withPlus.join('\n'), countryCode: prefix },
            { text: withPlus.join('\n'), countryCode: prefix },
            { data: withPlus.join('\n'), countryCode: prefix },
            { phoneNumbers: withPlus.join('\n') },
            { input: withPlus.join('\n') },
            { numbers: clean.join('\n') }
        ];
        const seen = new Set();
        common.forEach(payload => waPushUniqueVariant(variants, seen, payload));
        return variants;
    }

    function waEncodeActorId(actorId) {
        let id = String(actorId || '').trim();
        try {
            if (/^https?:\/\//i.test(id)) {
                const url = new URL(id);
                const parts = url.pathname.split('/').filter(Boolean);
                const idx = parts.indexOf('acts');
                if (idx >= 0 && parts[idx + 1]) id = decodeURIComponent(parts[idx + 1]);
            }
        } catch (e) {}
        id = id.replace(/^https?:\/\/api\.apify\.com\/v2\/acts\//i, '').replace(/\/runs.*$/i, '');
        id = id.replace(/^\/+|\/+$/g, '');
        if (id.includes('/') && !id.includes('~')) id = id.split('/').slice(0, 2).join('~');
        return encodeURIComponent(id);
    }

    function waExtractApifyError(payload, text, response) {
        const candidates = [];
        if (payload) {
            candidates.push(payload.message);
            if (payload.error && typeof payload.error === 'object') {
                candidates.push(payload.error.message, payload.error.type, payload.error.details, payload.error);
            } else {
                candidates.push(payload.error);
            }
            if (payload.data && typeof payload.data === 'object') {
                candidates.push(payload.data.message, payload.data.error, payload.data.statusMessage);
            }
        }
        candidates.push(text);
        for (const item of candidates) {
            const msg = waSafeJson(item).trim();
            if (msg && msg !== '{}' && msg !== '[]') return msg;
        }
        return (response.status + ' ' + response.statusText).trim();
    }

    function waIsInputSchemaError(err) {
        const msg = err && err.message ? err.message : String(err || '');
        return (err && err.status === 400) || /input|schema|required|invalid|property|field|must have|type mismatch|not allowed|validation/i.test(msg);
    }

    async function waProviderProxy(config, operation, payload) {
        const licence = await apiLiveGetStoredLicence();
        const key = licence && licence.key ? String(licence.key).trim() : '';
        if (!key) throw new Error('Please activate your licence first.');
        const provider = String(config && config.provider || 'apifywpapi').trim().toLowerCase();
        const response = await apiLiveCallAppsScript('providerProxy', {
            key,
            provider,
            keyRow: parseInt(config && (config.apiKeyRow || config.apifyKeyRow), 10) || 0,
            operation,
            payload: payload || {}
        });
        if (!response || response.status !== 'ok') {
            const err = new Error('Apify WP API error: ' + ((response && (response.message || response.reason)) || 'secure provider proxy failed'));
            err.status = parseInt(response && response.httpStatus, 10) || 0;
            err.payload = response && response.data;
            throw err;
        }
        return response.data;
    }

    async function waApifyRequest(url, options, token) {
        throw new Error('Direct Apify requests are disabled in PocketLeads v82. Use secure server proxy.');
    }

    async function waFetchActorInputSchema(config) {
        if (!config || !(config.apiKeyRow || config.apifyKeyRow)) return null;
        try {
            const payload = await waProviderProxy(config, 'getInputSchema', {});
            const data = payload && payload.data ? payload.data : payload;
            const schema = (data && (data.inputSchema || data.input_schema || data.schema)) || data;
            const parsed = waParseJsonMaybe(schema) || schema;
            if (parsed && Object.keys(waSchemaProperties(parsed)).length) return parsed;
        } catch (e) {}
        return null;
    }

    async function waStartApifyRun(config, numbers) {
        if (!config || !(config.apiKeyRow || config.apifyKeyRow)) throw new Error('No active Apify WP API provider found. Sheet me Provider = apify wp api, API Key and Source ID/Actor ID fill karo.');
        if (!config.inputSchema) config.inputSchema = await waFetchActorInputSchema(config).catch(() => null);
        const variants = waBuildInputVariants(numbers, config);
        let lastError = null;
        for (let i = 0; i < variants.length; i += 1) {
            try {
                const payload = await waProviderProxy(config, 'runActor', { input: variants[i], maxItems: Math.max(0, numbers && numbers.length || 0) });
                const run = payload && payload.data ? payload.data : payload;
                if (run && run.id) return run;
                throw new Error('Apify WP API did not return run ID.');
            } catch (err) {
                lastError = err;
                if (!waIsInputSchemaError(err) || i === variants.length - 1) throw err;
            }
        }
        throw lastError || new Error('Apify WP API actor could not be started.');
    }

    function waDatasetIdFromRun(run) {
        return (run && (run.defaultDatasetId ||
            (run.storageIds && run.storageIds.datasets && run.storageIds.datasets.default) ||
            (run.storageIds && run.storageIds.defaultDatasetId))) || '';
    }

    async function waPollRun(config, runId, onPartial, expectedTotal) {
        const started = Date.now();
        const maxMs = Math.max(60000, Math.min(180000, parseInt(config && (config.waMaxWaitMs || config.maxWaitMs), 10) || 120000));
        let lastRun = null;
        let lastPartialRead = 0;
        let lastDatasetId = '';
        let lastReadAt = 0;
        while (Date.now() - started < maxMs) {
            if ($scope.waApiStopRequested) throw new Error('WA API check stopped by user.');
            const payload = await waProviderProxy(config, 'getRun', { runId });
            const run = payload && payload.data ? payload.data : payload;
            lastRun = run;
            const status = String(run && run.status || '').toUpperCase();
            const datasetId = waDatasetIdFromRun(run);
            if (datasetId) lastDatasetId = datasetId;
            const now = Date.now();
            if (datasetId && typeof onPartial === 'function' && now - lastReadAt >= 1200) {
                lastReadAt = now;
                try {
                    const partial = await waFetchDatasetItems(config, datasetId, Math.max(100, expectedTotal || 100));
                    const parsedCount = waCollectParsedResults(partial).length;
                    if (parsedCount > lastPartialRead || partial.length > lastPartialRead) {
                        lastPartialRead = Math.max(parsedCount, partial.length, lastPartialRead);
                        await onPartial(partial, run);
                    }
                } catch (partialErr) {
                    console.warn('WA API partial dataset read failed', partialErr);
                }
            }
            $scope.safeApply(() => {
                const seconds = Math.max(1, Math.round((Date.now() - started) / 1000));
                $scope.waApiStatusText = 'Apify WP API: ' + (status || 'RUNNING') + ' · ' + seconds + 's' + (lastPartialRead ? ' · live ' + lastPartialRead : '');
            });
            if (['SUCCEEDED', 'FAILED', 'ABORTED', 'TIMED-OUT'].includes(status)) {
                if (status !== 'SUCCEEDED') throw new Error('Apify WP API actor failed: ' + status);
                return run;
            }
            await new Promise(resolve => setTimeout(resolve, 700));
        }
        if (lastRun && lastDatasetId && lastPartialRead) {
            lastRun._partialTimeout = true;
            lastRun.defaultDatasetId = lastRun.defaultDatasetId || lastDatasetId;
            return lastRun;
        }
        throw new Error('Apify WP API is still running and no result came within ' + Math.round(maxMs / 1000) + ' sec. Try fewer numbers or check actor speed in Apify.');
    }

    async function waFetchDatasetItems(config, datasetId, limit) {
        if (!datasetId) return [];
        const payload = await waProviderProxy(config, 'getDatasetItems', { datasetId, offset: 0, limit: Math.max(100, limit || 100) });
        return Array.isArray(payload) ? payload : [];
    }

    function waKeyValueStoreIdFromRun(run) {
        return (run && (run.defaultKeyValueStoreId ||
            (run.storageIds && run.storageIds.keyValueStores && run.storageIds.keyValueStores.default) ||
            (run.storageIds && run.storageIds.defaultKeyValueStoreId))) || '';
    }

    async function waFetchRunOutput(config, run) {
        const storeId = waKeyValueStoreIdFromRun(run);
        if (!storeId) return [];
        try {
            const payload = await waProviderProxy(config, 'getKeyValueOutput', { storeId });
            if (Array.isArray(payload)) return payload;
            if (payload && typeof payload === 'object') return [payload];
        } catch (e) {
            const msg = String((e && e.message) || e || '');
            if (!/record was not found|404/i.test(msg)) console.info('WA API optional OUTPUT read skipped:', msg);
        }
        return [];
    }

    function waFlattenResultItems(items) {
        const out = [];
        const seen = new WeakSet();
        const usefulKey = /result|results|data|item|items|output|outputs|contact|contacts|phone|phones|number|numbers|mobile|valid|invalid|whatsapp|wa|exists|registered|records/i;
        function visit(value, depth) {
            if (depth > 7 || value === null || typeof value === 'undefined') return;
            if (Array.isArray(value)) {
                value.forEach(v => visit(v, depth + 1));
                return;
            }
            if (typeof value !== 'object') return;
            if (seen.has(value)) return;
            seen.add(value);
            out.push(value);
            Object.keys(value).forEach(key => {
                const child = value[key];
                if (child && typeof child === 'object' && usefulKey.test(key)) visit(child, depth + 1);
            });
        }
        visit(items, 0);
        return out;
    }

    function waLooksLikePhoneKey(key) {
        const d = waNormalizeDigits(key);
        return d.length >= 8 && d.length <= 15;
    }

    function waObjectPhoneMapResults(obj) {
        const out = [];
        if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return out;
        Object.keys(obj).forEach(key => {
            if (!waLooksLikePhoneKey(key)) return;
            const value = obj[key];
            const statusValue = (value && typeof value === 'object') ? waDeepFindStatus(value, 0) : value;
            out.push({ key: waResultKey(key), status: waStatusFromValue(statusValue, value), raw: waSafeJson({ [key]: value }).slice(0, 500), noKeyEligible: false });
        });
        return out;
    }

    function waLooksLikeWaRecord(item) {
        if (!item || typeof item !== 'object' || Array.isArray(item)) return false;
        const keys = Object.keys(item).join(' ').toLowerCase();
        if (/^status id actid actorid startedat finishedat buildid defaultdatasetid defaultkeyvaluestoreid/.test(keys)) return false;
        if (/\b(defaultdatasetid|defaultkeyvaluestoreid|actid|actorid|buildid|startedat|finishedat|stats|usage)\b/.test(keys) && !/phone|mobile|number|whatsapp|wa|contact/.test(keys)) return false;
        return /phone|mobile|number|whatsapp|wa|valid|registered|exists|available|contact|result/.test(keys);
    }

    function waDeepFindPhone(value, depth) {
        if (depth > 6 || value === null || typeof value === 'undefined') return '';
        if (typeof value === 'string' || typeof value === 'number') {
            const d = waNormalizeDigits(value);
            return d.length >= 8 && d.length <= 15 ? d : '';
        }
        if (Array.isArray(value)) {
            for (const entry of value) {
                const found = waDeepFindPhone(entry, depth + 1);
                if (found) return found;
            }
            return '';
        }
        if (typeof value !== 'object') return '';
        const preferred = ['phone_number','phone_numbers','phoneNumber','phone','number','mobile','mobileNumber','inputPhoneNumber','input_phone_number','whatsappNumber','waNumber','contact','query','input','value'];
        for (const key of preferred) {
            if (Object.prototype.hasOwnProperty.call(value, key)) {
                const found = waDeepFindPhone(value[key], depth + 1);
                if (found) return found;
            }
        }
        for (const key of Object.keys(value)) {
            if (waLooksLikePhoneKey(key)) return waNormalizeDigits(key);
            if (/phone|mobile|number|contact|whatsapp|wa|input|query/i.test(key)) {
                const found = waDeepFindPhone(value[key], depth + 1);
                if (found) return found;
            }
        }
        return '';
    }

    function waDeepFindStatus(value, depth) {
        if (depth > 6 || value === null || typeof value === 'undefined') return undefined;
        if (typeof value !== 'object') return value;
        if (Array.isArray(value)) {
            for (const entry of value) {
                const st = waDeepFindStatus(entry, depth + 1);
                if (typeof st !== 'undefined') return st;
            }
            return undefined;
        }
        // IMPORTANT: phone validators often return { valid: true } even when the
        // WhatsApp result is separate (for example { whatsappCapable: false }).
        // Always read explicit WhatsApp fields before generic phone-valid fields.
        const preferred = ['activated','Activated','whatsappCapable','isWhatsappCapable','isWhatsAppCapable','hasWhatsapp','hasWhatsApp','whatsappAvailable','isWhatsapp','isWhatsApp','is_on_whatsapp','onWhatsApp','is_on_wa','onWa','whatsapp','whatsappExists','wa_status','whatsapp_status','canReceiveMessage','can_receive_message','isRegisteredOnWhatsapp','is_registered_on_whatsapp','available','isAvailable','isRegistered','registered','exists','isValid','valid','result','status','message','is_valid','is_registered','is_available','isBusiness','business'];
        for (const key of preferred) {
            if (Object.prototype.hasOwnProperty.call(value, key)) return value[key];
        }
        for (const key of Object.keys(value)) {
            if (/valid|exist|registered|whatsapp|available|status|result|message/i.test(key)) {
                const st = value[key];
                if (typeof st !== 'object' || st === null) return st;
                const nested = waDeepFindStatus(st, depth + 1);
                if (typeof nested !== 'undefined') return nested;
            }
        }
        return undefined;
    }

    function waExplicitWhatsappStatus(item, depth) {
        if (depth > 6 || item === null || typeof item === 'undefined') return '';
        if (Array.isArray(item)) {
            for (const entry of item) {
                const st = waExplicitWhatsappStatus(entry, depth + 1);
                if (st) return st;
            }
            return '';
        }
        if (typeof item !== 'object') return '';
        const directKeys = ['activated','Activated','whatsappCapable','isWhatsappCapable','isWhatsAppCapable','hasWhatsapp','hasWhatsApp','whatsappAvailable','whatsappExists','isWhatsapp','isWhatsApp','is_on_whatsapp','onWhatsApp','onWa','is_on_wa','canReceiveMessage','can_receive_message','isRegisteredOnWhatsapp','is_registered_on_whatsapp'];
        for (const key of directKeys) {
            if (Object.prototype.hasOwnProperty.call(item, key)) {
                const value = item[key];
                if (value === true) return 'Available';
                if (value === false) return 'Not available';
                const txt = String(value === undefined || value === null ? '' : value).trim().toLowerCase();
                if (/^(true|yes|1|available|active|registered|exists|capable|on whatsapp|found)$/i.test(txt)) return 'Available';
                if (/^(false|no|0|unavailable|not available|inactive|not registered|not found|not capable)$/i.test(txt)) return 'Not available';
                if (/not.*whatsapp|no.*whatsapp|not.*registered|not.*capable|unavailable|invalid/.test(txt)) return 'Not available';
                if (/whatsapp.*true|on whatsapp|registered.*whatsapp|capable|available/.test(txt)) return 'Available';
            }
        }
        // Some actors return a generic `whatsapp` object/string. Read it, but
        // do not let unrelated `valid:true` override a WhatsApp-specific false.
        if (Object.prototype.hasOwnProperty.call(item, 'whatsapp')) {
            const value = item.whatsapp;
            if (value === true) return 'Available';
            if (value === false) return 'Not available';
            if (value && typeof value === 'object') {
                const st = waExplicitWhatsappStatus(value, depth + 1);
                if (st) return st;
            } else {
                const txt = String(value === undefined || value === null ? '' : value).trim().toLowerCase();
                if (/not.*whatsapp|no.*whatsapp|false|unavailable|not registered|not found/.test(txt)) return 'Not available';
                if (/true|available|registered|exists|on whatsapp/.test(txt)) return 'Available';
            }
        }
        for (const key of Object.keys(item)) {
            if (/whatsapp|wa/i.test(key)) {
                const child = item[key];
                if (child && typeof child === 'object') {
                    const st = waExplicitWhatsappStatus(child, depth + 1);
                    if (st) return st;
                }
            }
        }
        return '';
    }

    function waStatusFromValue(statusValue, item) {
        const explicitWa = waExplicitWhatsappStatus(item, 0);
        if (explicitWa) return explicitWa;
        const statusText = String(statusValue === undefined || statusValue === null ? '' : statusValue).trim().toLowerCase();
        // Do not treat generic phone-validation fields as WhatsApp availability
        // when there is no explicit WhatsApp field in the actor output.
        if (statusValue === true || /^(true|yes|valid|registered|exists|available|active|on whatsapp|found)$/i.test(statusText)) return 'Available';
        if (statusValue === false || /^(false|no|invalid|not registered|not_registered|not exists|not_exists|unavailable|not available|not_available|inactive|failed|fail|error|not found)$/i.test(statusText)) return 'Not available';
        const full = statusText || waSafeJson(item).toLowerCase();
        if (/no whatsapp|not on whatsapp|does not exist|not found|not registered|invalid|unavailable/i.test(full)) return 'Not available';
        if (/whatsapp.*true|on whatsapp|registered.*whatsapp|whatsapp.*available|whatsapp.*exists/i.test(full)) return 'Available';
        if (/registered|valid|available|exists/i.test(full) && /whatsapp|wa/i.test(full)) return 'Available';
        return 'Unknown';
    }

    function waParseResultItem(item) {
        item = item || {};
        const rawNumber = waDeepFindPhone(item, 0);
        const statusValue = waDeepFindStatus(item, 0);
        const finalStatus = waStatusFromValue(statusValue, item);
        const hasStatus = typeof statusValue !== 'undefined';
        const raw = waSafeJson(item).slice(0, 800);
        return { key: waResultKey(rawNumber), status: finalStatus, raw: raw, hasStatus: hasStatus, noKeyEligible: !rawNumber && hasStatus && finalStatus !== 'Unknown' && waLooksLikeWaRecord(item) };
    }

    function waArrayStatusGroupResults(root) {
        const out = [];
        const seen = new WeakSet();
        function statusFromKey(key) {
            const k = String(key || '').toLowerCase();
            if (/invalid|not[_ -]?registered|not[_ -]?found|not[_ -]?exist|unavailable|failed|errors?/.test(k)) return 'Not available';
            if (/valid|registered|exists?|available|on[_ -]?(whatsapp|wa)|whatsapp[_ -]?numbers?/.test(k)) return 'Available';
            return '';
        }
        function visit(value, depth) {
            if (depth > 6 || !value || typeof value !== 'object') return;
            if (seen.has(value)) return;
            seen.add(value);
            if (Array.isArray(value)) { value.forEach(v => visit(v, depth + 1)); return; }
            Object.keys(value).forEach(key => {
                const child = value[key];
                const st = statusFromKey(key);
                if (st && Array.isArray(child)) {
                    child.forEach(entry => {
                        const phone = waDeepFindPhone(entry, 0) || (waLooksLikePhoneKey(entry) ? waNormalizeDigits(entry) : '');
                        if (phone) out.push({ key: waResultKey(phone), status: st, raw: waSafeJson({ [key]: entry }).slice(0, 500), hasStatus: true, noKeyEligible: false });
                    });
                } else if (child && typeof child === 'object') {
                    visit(child, depth + 1);
                }
            });
        }
        visit(root, 0);
        return out;
    }

    function waCollectParsedResults(resultItems) {
        const flat = waFlattenResultItems(resultItems || []);
        const out = [];
        const seen = new Set();
        function pushParsed(parsed) {
            if (!parsed) return;
            if (!parsed.noKeyEligible && (!parsed.key || (!parsed.hasStatus && !parsed.status))) return;
            const id = (parsed.key || 'idx') + '|' + parsed.status + '|' + parsed.raw;
            if (!seen.has(id)) { seen.add(id); out.push(parsed); }
        }
        waArrayStatusGroupResults(resultItems || []).forEach(pushParsed);
        flat.forEach(item => {
            waObjectPhoneMapResults(item).forEach(pushParsed);
            pushParsed(waParseResultItem(item));
        });
        return out;
    }

    function waCommitDashboardRows(targets) {
        try {
            const targetRows = [];
            (Array.isArray(targets) ? targets : []).forEach(item => {
                const row = item && item.row ? item.row : item;
                if (row && typeof row === 'object' && !targetRows.includes(row)) targetRows.push(row);
            });
            if (!targetRows.length) return;
            targetRows.forEach((row, idx) => {
                try { ensureDashboardRowKey(row, idx); } catch (e) {}
                try {
                    const displayPhone = waNormalizePhoneForDisplay(rowPhoneValue(row));
                    if (displayPhone) row.phone_number = displayPhone;
                } catch (e) {}
                try {
                    if (productsStore && typeof productsStore.update === 'function' && row.cid) {
                        const updateResult = productsStore.update(row.cid, row);
                        if (updateResult && typeof updateResult.catch === 'function') updateResult.catch(function(){});
                    }
                } catch (e) {
                    try { if (productsStore && row.cid) productsStore.push([{ type: 'update', key: row.cid, data: row }]); } catch (e2) {}
                }
                try {
                    if (dataGrid && row.cid && typeof dataGrid.getRowIndexByKey === 'function') {
                        const rIdx = dataGrid.getRowIndexByKey(row.cid);
                        if (rIdx >= 0 && typeof dataGrid.cellValue === 'function') {
                            dataGrid.cellValue(rIdx, 'whatsapp_status', row.whatsapp_status || '');
                            dataGrid.cellValue(rIdx, 'phone_number', row.phone_number || '');
                        }
                    }
                } catch (e) {}
            });
        } catch (err) {
            console.warn('WA dashboard direct row commit failed', err);
        }
    }

    function waRefreshDashboardNow() {
        try {
            let rows = [];
            if ($scope.local && Array.isArray($scope.local.collect)) {
                rows = safeCollectRows($scope.local);
                // Keep the original collection objects updated, but rebuild the grid
                // store from the latest array. DevExtreme push updates can silently
                // miss rows when cid was created after the grid was built; rebuilding
                // the ArrayStore guarantees WhatsApp Status leaves "Checking via API...".
                $scope.local.collect = rows;
            }
            if (typeof $scope.saveLocal === 'function') $scope.saveLocal();
            if (productsStore && rows.length && typeof DevExpress !== 'undefined' && DevExpress.data && DevExpress.data.ArrayStore) {
                try {
                    refreshColumnList(rows);
                    productsStore = new DevExpress.data.ArrayStore({ key: 'cid', data: rows });
                } catch (storeErr) {
                    console.warn('WA dashboard store rebuild failed, falling back to push update', storeErr);
                    try { updateDataTable($scope.local); } catch (pushErr) {}
                }
            } else if (productsStore && $scope.local) {
                try { updateDataTable($scope.local); } catch (pushErr) {}
            }
            if (dataGrid) {
                try { dataGrid.option('dataSource', { store: productsStore, reshapeOnPush: true }); } catch (e1) {}
                try { if (dataGrid.getDataSource && dataGrid.getDataSource()) dataGrid.getDataSource().reload(); } catch (e0) {}
                try { if (dataGrid.refresh) dataGrid.refresh(); } catch (e2) {}
                try { if (dataGrid.repaint) dataGrid.repaint(); } catch (e3) {}
            }
            try { refreshDashboardMetricCounts(rows); } catch (e5) {}
            try { $scope.$applyAsync(); } catch (e4) {}
        } catch (e) {
            console.warn('WA dashboard refresh failed', e);
        }
    }

    function waSetRowStatus(row, status, raw, providerName) {
        if (!row) return false;
        const previous = row.whatsapp_status;
        row.whatsapp_status = status || 'Unknown';
        row.whatsapp_api_raw = raw || '';
        row.whatsapp_checked_at = new Date().toISOString();
        row.whatsapp_api_provider = providerName || row.whatsapp_api_provider || 'NumberChecker.AI';
        const displayPhone = waNormalizePhoneForDisplay(rowPhoneValue(row));
        if (displayPhone) row.phone_number = displayPhone;
        return previous !== row.whatsapp_status;
    }

    function waIsPendingStatus(status) {
        const text = String(status || '').trim().toLowerCase();
        return !text || /checking via api|queued|pending|running|starting|processing|api started/.test(text);
    }

    function waApplyResultsToBatch(resultItems, batchItems, byKey, seenRows) {
        const parsedList = waCollectParsedResults(resultItems || []);
        let updated = 0;
        const pending = (batchItems || []).filter(item => item && item.row && !seenRows.has(item.row));
        parsedList.forEach(parsed => {
            if (!parsed || !parsed.key) return;
            const keys = [parsed.key];
            const prefix = waCountryDialPrefix();
            if (prefix && parsed.key.startsWith(prefix) && parsed.key.length > prefix.length + 6) keys.push(parsed.key.slice(prefix.length));
            if (prefix && !parsed.key.startsWith(prefix) && parsed.key.length <= 10) keys.push(prefix + parsed.key);
            keys.filter(Boolean).forEach(key => {
                (byKey[key] || []).forEach(row => {
                    if (!row) return;
                    if (waSetRowStatus(row, parsed.status, parsed.raw) || !seenRows.has(row)) updated += 1;
                    seenRows.add(row);
                });
            });
        });
        const noKeyList = parsedList.filter(p => p && !p.key && p.noKeyEligible);
        if (noKeyList.length) {
            pending.forEach((item, idx) => {
                if (seenRows.has(item.row)) return;
                const parsed = noKeyList[idx];
                if (!parsed) return;
                waSetRowStatus(item.row, parsed.status, parsed.raw);
                seenRows.add(item.row);
                updated += 1;
            });
        }
        // Some Apify actors return only a list of booleans/status objects without
        // returning the phone number. In that case, apply results by original input
        // order so the dashboard never remains blank after a successful run.
        if (parsedList.length) {
            (batchItems || []).forEach((item, idx) => {
                if (!item || !item.row || seenRows.has(item.row)) return;
                const parsed = parsedList[idx];
                if (!parsed) return;
                waSetRowStatus(item.row, parsed.status || 'Unknown', parsed.raw);
                seenRows.add(item.row);
                updated += 1;
            });
        }
        if (updated) {
            waCommitDashboardRows(batchItems || []);
            waRefreshDashboardNow();
        }
        return updated;
    }

    async function waRequestSingleProviderConfig(providerName, preferNext, excludeRows) {
        excludeRows = Array.isArray(excludeRows) ? excludeRows.filter(Boolean) : [];
        const flow = window.PocketLeadsApifyFlow;
        if (flow && flow.ApiBackendManager && typeof flow.ApiBackendManager.getConfig === 'function') {
            return await flow.ApiBackendManager.getConfig(!!preferNext, providerName, excludeRows);
        }
        const licence = await apiLiveGetStoredLicence();
        const key = licence && licence.key ? String(licence.key).trim() : '';
        if (!key) throw new Error('Please activate your licence first.');
        const data = await apiLiveCallAppsScript('getApiConfig', { key, preferNext: !!preferNext, provider: providerName, excludeRows: excludeRows.join(',') });
        if (!data || data.status !== 'ok') {
            if (data && data.status === 'expired') throw new Error(`Licence expired${data.expiryDate ? ' on ' + data.expiryDate : ''}. Contact ${data.supportEmail || PocketLeadsConfig.supportEmail} to renew.`);
            if (data && data.status === 'credits_exhausted') throw new Error('Your scraping/verification credits are exhausted. Upgrade your plan or contact samimn7890@gmail.com.');
            if (data && data.status === 'inactive') throw new Error('This licence is inactive. Contact samimn7890@gmail.com.');
            if (data && data.status === 'no_api_key') {
                const noKeyErr = new Error('No active ' + (providerName === 'numberchecker' ? 'NumberChecker.AI' : 'WhatsApp API') + ' key configured in Admin Sheet.');
                noKeyErr.code = 'NO_ELIGIBLE_PROVIDER';
                throw noKeyErr;
            }
            if (data && data.status === 'invalid' && !data.backend) throw new Error('Apps Script old version hai. ZIP ke apps_script_code.js ko paste karke Deploy > Manage deployments > Edit > New version > Deploy karo.');
            throw new Error((data && data.message) || 'Unable to get WhatsApp API setup from Admin Sheet.');
        }
        return {
            provider: String(data.provider || providerName).trim().toLowerCase(),
            apiToken: '',
            actorId: '',
            sourceId: '',
            secureProxy: data.secureProxy === true,
            apiKeyRow: parseInt(data.keyRow, 10) || 0,
            apifyKeyRow: parseInt(data.keyRow, 10) || 0,
            apiUsageBefore: parseInt(data.usageCount, 10) || 0,
            apiUsageLimit: Math.max(0, Number(data.usageLimit) || 0)
        };
    }

    async function waGetApiConfig(preferNext, excludeRows) {
        let ncError = null;
        try {
            return await waRequestSingleProviderConfig('numberchecker', preferNext, excludeRows);
        } catch (err) {
            ncError = err;
            if (!/NO_ELIGIBLE_PROVIDER|No active NumberChecker|temporarily unavailable|no usable configured row/i.test(String((err && (err.code || err.message)) || ''))) {
                throw err;
            }
        }
        try {
            return await waRequestSingleProviderConfig('apifywpapi', preferNext, excludeRows);
        } catch (fallbackErr) {
            throw ncError || fallbackErr;
        }
    }

    async function waStartNumberCheckerTask(config, e164Numbers) {
        if (!config || !(config.apiKeyRow || config.apifyKeyRow)) {
            throw new Error('No active NumberChecker.AI API key found in Admin Sheet. Set Provider = numberchecker and paste your X-API-Key.');
        }
        const prefix = waCountryDialPrefix() || '91';
        const payload = await waProviderProxy(config, 'createTask', {
            numbers: e164Numbers,
            countryCode: prefix,
            taskType: 'ws'
        });
        const taskObj = (payload && payload.data && typeof payload.data === 'object') ? payload.data : payload;
        const taskId = String((taskObj && (taskObj.task_id || taskObj.taskId || taskObj.id)) || '').trim();
        if (!taskId) {
            throw new Error('NumberChecker.AI did not return a task_id.');
        }
        return { taskId, raw: taskObj };
    }

    async function waPollNumberCheckerTask(config, taskId, expectedTotal) {
        const started = Date.now();
        const maxMs = Math.max(90000, Math.min(240000, parseInt(config && (config.waMaxWaitMs || config.maxWaitMs), 10) || 180000));
        while (Date.now() - started < maxMs) {
            if ($scope.waApiStopRequested) throw new Error('WA API check stopped by user.');
            const payload = await waProviderProxy(config, 'getTask', { taskId });
            const task = (payload && payload.data && typeof payload.data === 'object') ? payload.data : (payload || {});
            const status = String(task.status || 'processing').trim().toLowerCase();
            const successCount = parseInt(task.success, 10) || 0;
            const totalCount = parseInt(task.total, 10) || expectedTotal || 0;
            $scope.safeApply(() => {
                const seconds = Math.max(1, Math.round((Date.now() - started) / 1000));
                const progressStr = successCount > 0 ? (' · ' + successCount + '/' + totalCount) : '';
                $scope.waApiStatusText = 'NumberChecker.AI: ' + status.toUpperCase() + progressStr + ' · ' + seconds + 's';
            });
            if (status === 'exported') {
                let items = Array.isArray(task.items) ? task.items : [];
                const resultUrl = String(task.result_url || task.resultUrl || '').trim();
                if (!items.length && resultUrl) {
                    const dl = await waProviderProxy(config, 'getTaskResult', { resultUrl, taskId });
                    const dlObj = (dl && dl.data && typeof dl.data === 'object') ? dl.data : (dl || {});
                    if (Array.isArray(dlObj.items)) items = dlObj.items;
                }
                return { status: 'exported', taskId, items, resultUrl, raw: task };
            }
            if (status === 'failed' || status === 'error') {
                throw new Error('NumberChecker.AI task failed: ' + (task.message || status));
            }
            await new Promise(resolve => setTimeout(resolve, 1400));
        }
        throw new Error('NumberChecker.AI verification timed out after ' + Math.round(maxMs / 1000) + 's. Try again with a smaller batch.');
    }

    async function waReportApiUsage(config, usedCount) {
        const count = Math.max(0, parseInt(usedCount, 10) || 0);
        if (!count || !config) return null;
        const flow = window.PocketLeadsApifyFlow;
        if (flow && flow.ApiBackendManager && typeof flow.ApiBackendManager.reportUsage === 'function') {
            return await flow.ApiBackendManager.reportUsage(config, count);
        }
        const licence = await apiLiveGetStoredLicence();
        const key = licence && licence.key ? String(licence.key).trim() : '';
        if (!key) return null;
        return await apiLiveCallAppsScript('reportApiUsage', {
            key,
            keyRow: config.apiKeyRow || config.apifyKeyRow || 0,
            usedCount: count
        });
    }

    function waShouldTryNextProvider(err) {
        const msg = String((err && err.message) || err || '').toLowerCase();
        // Try another active NumberChecker.AI / Apify WP API row when the current key fails,
        // rejects input, times out, or hits API/account/balance errors.
        return /numberchecker|apify|actor|failed|aborted|timed-out|timeout|input|schema|required|invalid|not found|record was not found|dataset|permission|unauthorized|forbidden|insufficient|balance|401|402|403|limit|rate|429|500|502|503|504|no result|still running/.test(msg);
    }

    $scope.waNumberCheck = async function() {
        if ($scope.waChecking) {
            $scope.waApiStopRequested = true;
            $scope.waChecking = false;
            $scope.waApiMode = false;
            $scope.waApiStatusText = 'Stopping WA API check...';
            return;
        }
        try {
            $scope.local.collect=await getCompleteRowsForExport();
            const rows = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
            const items = [];
            const byKey = {};
            rows.forEach((row, idx) => {
                if (!row || typeof row !== 'object') return;
                ensureDashboardRowKey(row, idx);
                const rawPhone = rowPhoneValue(row);
                const digits = waNormalizeDigits(rawPhone);
                if (!digits) return;
                const e164Number = waNumberForE164(rawPhone);
                const apiNumber = waNumberForApi(rawPhone);
                try { row.phone_number = e164Number || waNormalizePhoneForDisplay(rawPhone) || rawPhone; } catch (e) {}
                const currentStatus = String(row.whatsapp_status || '').toLowerCase();
                const final = currentStatus === 'available' || currentStatus === 'not available';
                if (final) return;
                const key = waResultKey(apiNumber);
                const item = { row, rowId: idx, digits, apiNumber, e164Number, key };
                items.push(item);
                const last10 = digits.length > 10 ? digits.slice(-10) : '';
                [key, waResultKey(digits), apiNumber, e164Number, digits, last10].filter(Boolean).forEach(k => {
                    if (!byKey[k]) byKey[k] = [];
                    if (!byKey[k].includes(row)) byKey[k].push(row);
                });
            });
            if (!items.length) {
                $scope.snackbar.show('No pending phone numbers to check.');
                return;
            }
            items.forEach(item => {
                item.row.whatsapp_status = 'Checking via API...';
                item.row.whatsapp_api_raw = '';
            });
            $scope.waApiMode = true;
            $scope.waApiStopRequested = false;
            $scope.waChecking = true;
            $scope.waLoginWaiting = false;
            $scope.waFinished = 0;
            $scope.waTotal = items.length;
            $scope.waApiStatusText = 'Getting NumberChecker.AI API from Admin Sheet...';
            $scope.suppressScrapingComplete = true;
            $scope.scrapingCompletePending = false;
            waCommitDashboardRows(items);
            waRefreshDashboardNow();

            const seenRows = new Set();
            let usedCount = items.length;
            const allNumbers = items.map(x => x.apiNumber);
            const allE164Numbers = items.map(x => x.e164Number || ('+' + x.apiNumber));
            let config = null;
            let finishedRun = null;
            let lastApiError = null;
            let success = false;
            const triedRows = [];
            const maxAttempts = 5;
            for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
                try {
                    config = await waGetApiConfig(attempt > 0, triedRows);
                    const rowNo = config && (config.apiKeyRow || config.apifyKeyRow) ? (config.apiKeyRow || config.apifyKeyRow) : 0;
                    if (rowNo && !triedRows.includes(rowNo)) triedRows.push(rowNo);
                    const isNumberChecker = String(config && config.provider || '').toLowerCase() === 'numberchecker';
                    if (isNumberChecker) {
                        const dialCode = waCountryDialPrefix() || '91';
                        $scope.safeApply(() => {
                            $scope.waApiStatusText = 'NumberChecker.AI: Submitting ' + items.length + ' numbers (with +' + dialCode + ' country code)...';
                        });
                        waRefreshDashboardNow();
                        const startedTask = await waStartNumberCheckerTask(config, allE164Numbers);
                        const exportedTask = await waPollNumberCheckerTask(config, startedTask.taskId, items.length);
                        finishedRun = exportedTask;
                        if (Array.isArray(exportedTask.items) && exportedTask.items.length) {
                            waApplyResultsToBatch(exportedTask.items, items, byKey, seenRows);
                            $scope.safeApply(() => {
                                $scope.waFinished = Math.min(items.length, seenRows.size);
                            });
                        }
                        success = true;
                        break;
                    } else {
                        $scope.safeApply(() => {
                            $scope.waApiStatusText = 'WA API actor ' + (attempt + 1) + ' started for ' + items.length + ' numbers. Dashboard will update live.';
                        });
                        waRefreshDashboardNow();

                        const run = await waStartApifyRun(config, allNumbers);
                        const partialHandler = async partialItems => {
                            const updated = waApplyResultsToBatch(partialItems, items, byKey, seenRows);
                            if (updated) {
                                $scope.safeApply(() => {
                                    $scope.waFinished = Math.min(items.length, seenRows.size);
                                    $scope.waApiStatusText = 'WA API live: ' + $scope.waFinished + '/' + items.length + ' updated';
                                });
                                waRefreshDashboardNow();
                            }
                        };
                        finishedRun = await waPollRun(config, run.id, partialHandler, items.length + 100);
                        const datasetId = waDatasetIdFromRun(finishedRun);
                        let finalItems = [];
                        if (datasetId) {
                            $scope.safeApply(() => { $scope.waApiStatusText = 'Reading final WA API results...'; });
                            finalItems = await waFetchDatasetItems(config, datasetId, items.length + 500);
                            waApplyResultsToBatch(finalItems, items, byKey, seenRows);
                        }
                        const outputItems = await waFetchRunOutput(config, finishedRun);
                        if (outputItems.length) waApplyResultsToBatch(outputItems, items, byKey, seenRows);
                        success = true;
                        break;
                    }
                } catch (apiErr) {
                    lastApiError = apiErr;
                    console.warn('WA API attempt failed', apiErr);
                    const canTryNext = waShouldTryNextProvider(apiErr) && attempt < maxAttempts - 1;
                    if (!canTryNext) throw apiErr;
                    $scope.safeApply(() => {
                        $scope.waApiStatusText = 'Current WA API key failed, trying next active key from Admin Sheet...';
                    });
                    await new Promise(resolve => setTimeout(resolve, 500));
                }
            }
            if (!success) throw lastApiError || new Error('WhatsApp API verification failed.');

            const timedOut = finishedRun && finishedRun._partialTimeout;
            let forcedFinal = 0;
            items.forEach(item => {
                if (!item || !item.row) return;
                const stillPending = waIsPendingStatus(item.row.whatsapp_status);
                if (!seenRows.has(item.row) || stillPending) {
                    waSetRowStatus(
                        item.row,
                        timedOut ? 'Pending / Timeout' : 'No result',
                        timedOut ? 'Actor was still running; no matching result returned within dashboard wait time.' : 'No matching result row returned by Apify dataset.'
                    );
                    seenRows.add(item.row);
                    forcedFinal += 1;
                }
            });
            waCommitDashboardRows(items);
            waRefreshDashboardNow();
            try {
                await waReportApiUsage(config, usedCount || items.length);
            } catch (usageErr) { console.warn('WA API usage report failed', usageErr); }
            $scope.safeApply(() => {
                $scope.waChecking = false;
                $scope.waApiMode = false;
                $scope.waPendingComplete = false;
                $scope.waFinished = items.length;
                const remainingPending = items.filter(x => x && x.row && waIsPendingStatus(x.row.whatsapp_status)).length;
                $scope.waApiStatusText = 'WA API check completed: ' + (items.length - remainingPending) + '/' + items.length + ' numbers finalized on dashboard.';
                waCommitDashboardRows(items);
                waRefreshDashboardNow();
                $scope.snackbar.show('WA number check completed: dashboard status finalized.');
            });
        } catch (err) {
            console.warn('waNumberCheck API error', err);
            const msg = err && err.message ? err.message : String(err);
            ($scope.local.collect || []).forEach(row => {
                if (row && /checking via api|queued|pending/i.test(String(row.whatsapp_status || ''))) row.whatsapp_status = '';
            });
            $scope.safeApply(() => {
                $scope.waChecking = false;
                $scope.waApiMode = false;
                $scope.waApiStatusText = msg;
                waRefreshDashboardNow();
                $scope.snackbar.show(msg);
            });
        }
    };

        /**
     * Listener for WA check updates sent from the background service worker.
     * When a message of type 'wa_check_update' is received the
     * corresponding row's whatsapp_status field is updated.  The
     * status strings returned from the background script ('REGISTERED'
     * or 'NOT_REGISTERED') are converted into human-friendly values
     * ('Available' / 'Not available').  Unknown or custom statuses are
     * displayed verbatim.  After updating the row the grid is
     * refreshed.
     */
    chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
        try {
            // v87 canonical realtime feed from the background ResultStore writer.
            // This bypasses chrome.storage preview/debounce latency entirely.
            if (msg && msg.action === 'PL_RESULT_STORE_DELTA' && Array.isArray(msg.rows)) {
                const currentRunId = $scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.runEventId;
                if (msg.runId && ($scope.startLaunchPending || !currentRunId)) {
                    $scope.startLaunchPending = false;
                    if ($scope.local) {
                        if (!$scope.local.apifyQueue) $scope.local.apifyQueue = {};
                        $scope.local.apifyQueue.runEventId = msg.runId;
                        $scope.local.apifyQueue.status = 'running';
                    }
                } else if (msg.runId && currentRunId && msg.runId !== currentRunId) {
                    return;
                }
                if (/^(stopped|cleared)$/.test(String($scope.local && $scope.local.apifyQueue && $scope.local.apifyQueue.status || ''))) return;
                $scope.$evalAsync(() => {
                    try {
                        if (!$scope.local) return;
                        if (!Array.isArray($scope.local.collect)) $scope.local.collect = [];
                        const rows = $scope.local.collect;
                        const indexByKey = new Map();
                        const keyOf = (row, idx) => String((row && (row.place_id || row.cid || row.map_link || row.phone || ((row.company_name || row.name || '') + '|' + (row.address || '')))) || ('row_' + idx));
                        rows.forEach((row, idx) => indexByKey.set(keyOf(row, idx), idx));
                        msg.rows.forEach((incoming, idx) => {
                            if (!incoming || typeof incoming !== 'object') return;
                            normalizeDashboardRow(incoming);
                            ensureDashboardRowKey(incoming, rows.length + idx);
                            const key = keyOf(incoming, rows.length + idx);
                            if (key && indexByKey.has(key)) rows[indexByKey.get(key)] = Object.assign({}, rows[indexByKey.get(key)], incoming);
                            else { indexByKey.set(key, rows.length); rows.push(incoming); }
                        });
                        $scope.local.collect = dedupeDashboardRows(rows).slice(-250);
                        const total = Math.max(parseInt(msg.total, 10) || 0, parseInt($scope._monotonicResultCount, 10) || 0, $scope.local.collect.length);
                        $scope.local.resultStoreCount = Math.max(parseInt($scope.local.resultStoreCount, 10) || 0, total);
                        $scope._monotonicResultCount = $scope.local.resultStoreCount;
                        $scope.local.collectIsPreview = $scope.local.collect.length < $scope.local.resultStoreCount;
                        $scope.resultStoreHydrated = true;
                        refreshDashboardMetricCounts($scope.local.collect);
                        // Authoritative live write: never depend on a second async
                        // chrome.storage read to initialise the grid. That old race
                        // was the reason KPI/unique count could move while rows only
                        // appeared after a manual dashboard refresh.
                        const deferHiddenMobileGrid = ($scope.viewMode === 'mobile' && !$scope.mobileDataDrawerOpen && PocketLeadsRunState.isRunning($scope.local));
                        if (!deferHiddenMobileGrid) {
                            if (!dataGrid || !productsStore) buildDataTable($scope.local);
                            if (productsStore && typeof productsStore.setRows === 'function') {
                                const liveRows = safeCollectRows($scope.local);
                                productsStore.setRows(liveRows);
                                syncGridTrackingFromRows(liveRows);
                            } else {
                                insertIntoDataTable($scope.local);
                                updateDataTable($scope.local);
                            }
                        }
                        lastCollectDataCount = $scope.local.collect.length;
                        lastCollectUiSignature = computeCollectUiSignature($scope.local.collect);
                        try { $scope.updateUIState(); } catch (e) {}
                        if ($scope.local.collect.length < Math.min(250, $scope.local.resultStoreCount) && typeof $scope.syncLiveCanonicalTable === 'function') {
                            $scope.syncLiveCanonicalTable($scope.local.resultStoreCount);
                        }
                    } catch (deltaUiErr) {
                        console.warn('PL_RESULT_STORE_DELTA UI update failed', deltaUiErr);
                    }
                });
                if (typeof sendResponse === 'function') sendResponse({ status: 'received' });
                return;
            }

            // Handle realtime updates from fast mode scraping.  The content script
            // sends a 'fast_update' message with a single row of data whenever
            // a new business is collected.  This branch inserts the row
            // directly into the local.collect array and refreshes the grid
            // without requiring the Maps tab to be active.  By updating
            // Angular’s model and the DataGrid here, the dashboard shows
            // results even when the search tab is hidden.
            // Unified handler for fast_mode updates.  Content scripts may send
            // messages via $box.sendToAll() (using an 'event' property) or
            // directly via chrome.runtime.sendMessage() (using either
            // 'action' or 'event').  Check both fields so the dashboard
            // responds to updates regardless of how they were sent.
            if (msg && (msg.action === 'fast_update' || msg.event === 'fast_update') && msg.data) {
                $scope.$evalAsync(() => {
                    try {
                        // Initialise collect array if missing
                        if (!$scope.local.collect) {
                            $scope.local.collect = [];
                        }
                        const rows = $scope.local.collect;
                        // Skip if this cid already exists
                        let duplicate = false;
                        if (msg.data.cid) {
                            duplicate = rows.some(item => item && item.cid === msg.data.cid);
                        }
                        if (!duplicate) {
                            rows.push(msg.data);
                            // Persist changes to storage
                            if (typeof $scope.saveLocal === 'function') {
                                $scope.saveLocal();
                            }
                            // Ensure the data grid exists.  If not, build and insert all rows.
                            if (typeof dataGrid !== 'undefined' && dataGrid) {
                                // Preserve scroll position during refresh
                                let scrollTop = 0;
                                try {
                                    const scrollable = dataGrid.getScrollable && dataGrid.getScrollable();
                                    if (scrollable && typeof scrollable.scrollTop === 'function') {
                                        scrollTop = scrollable.scrollTop();
                                    }
                                } catch (err) {
                                    // ignore scroll capture errors
                                }
                                insertIntoDataTable($scope.local);
                                updateDataTable($scope.local);
                                // Refresh the grid to reflect the new row
                                try {
                                    dataGrid.refresh && dataGrid.refresh();
                                } catch (err) {
                                    console.warn('fast_update: failed to refresh dataGrid', err);
                                }
                                // Restore previous scroll position
                                try {
                                    const scrollable2 = dataGrid.getScrollable && dataGrid.getScrollable();
                                    if (scrollable2 && typeof scrollable2.scrollTo === 'function') {
                                        scrollable2.scrollTo({ top: scrollTop });
                                    }
                                } catch (err) {
                                    // ignore scroll restore errors
                                }
                                // Update count tracker
                                lastCollectDataCount = rows.length;
                            } else {
                                // Data grid not yet built
                                lastCollectDataCount = 0;
                                buildDataTable();
                                insertIntoDataTable($scope.local);
                                lastCollectDataCount = rows.length;
                            }
                            // Update UI state such as progress bars and buttons
                            if (typeof $scope.updateUIState === 'function') {
                                $scope.updateUIState();
                            }
                        }
                    } catch (fastErr) {
                        console.warn('fast_update: error updating UI', fastErr);
                    }
                });
                // Respond to the sender (optional)
                if (typeof sendResponse === 'function') {
                    sendResponse({ status: 'received' });
                }
                return;
            }
            if (msg && msg.action === 'wa_check_update' && typeof msg.rowId !== 'undefined') {
                // Ignore updates when a WA check is not running.  This
                // prevents stale updates from a previous run after the
                // user has cancelled.
                if (!$scope.waChecking) {
                    return;
                }
                // Hide the login waiting prompt once a real update arrives.
                $scope.waLoginWaiting = false;
                const idx = msg.rowId;
                const statusStr = (msg.status || '').toString();
                const rows = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
                if (rows[idx]) {
                    // Convert machine status into a user‑friendly label
                    let formatted;
                    const low = statusStr.toLowerCase();
                    if (low === 'registered') {
                        formatted = 'Available';
                    } else if (low === 'not_registered' || low === 'not registered') {
                        formatted = 'Not available';
                    } else if (low === 'unknown') {
                        // Leave blank when the status is unknown.  This occurs
                        // when a lookup fails due to the user not being
                        // logged in or a communication error.  Showing an
                        // empty value avoids confusing "UNKNOWN" labels.
                        formatted = '';
                    } else {
                        formatted = statusStr;
                    }
                    rows[idx].whatsapp_status = formatted;
                    // Persist change and refresh grid
                    try {
                        if (typeof $scope.saveLocal === 'function') {
                            $scope.saveLocal();
                        }
                        updateDataTable($scope.local);
                    } catch (e) {
                        console.warn('wa_check_update: failed to refresh grid', e);
                    }
                    // Update progress counters.  Only count each row once
                    // even if multiple updates arrive (e.g. retries).  If
                    // msg.finished and msg.total are provided use them
                    // directly.  Otherwise compute finished by counting
                    // unique rows processed.
                        /*
                         * Updating progress counters inside a digest can throw
                         * a $rootScope:inprog error if $apply is invoked while
                         * Angular is already processing an update cycle.  Use
                         * safeApply (defined on the scope) to detect the
                         * current phase and either call the function directly
                         * or wrap it in $apply as appropriate.  This avoids
                         * nested $apply/$digest errors when WA updates arrive
                         * during other UI updates (e.g. scrolling or grid
                         * refreshes).
                         */
                        $scope.safeApply(() => {
                            try {
                                const cid = rows[idx] && rows[idx].cid;
                                // Only mark this cid as completed for progress if the status is final.
                                if (cid && !$scope.waCompletedIds[cid] && (rows[idx].whatsapp_status === 'Available' || rows[idx].whatsapp_status === 'Not available')) {
                                    $scope.waCompletedIds[cid] = true;
                                    // Remove this cid from the enqueued set as it is no longer pending.
                                    if ($scope.waEnqueuedIds[cid]) {
                                        delete $scope.waEnqueuedIds[cid];
                                    }
                                    // Mark the row index as completed for backwards compatibility.
                                    $scope.waCompletedRows[idx] = true;
                                    // Remove the row index from the enqueued rows map.
                                    if ($scope.waEnqueuedRows[idx]) {
                                        delete $scope.waEnqueuedRows[idx];
                                    }
                                }
                                // Update finished count based on unique completed IDs.
                                $scope.waFinished = Object.keys($scope.waCompletedIds).length;
                            } catch (progressErr) {
                                console.warn('wa_check_update: error updating progress', progressErr);
                            }
                            // Do not automatically mark the check as finished based solely on counts.
                            // Completion will be handled when the background run signals completion.
                        });
                }
            }
            // When the background script signals completion of the WA
            // check we mark the UI as idle.  This message arrives
            // regardless of whether the run finished normally or was
            // cancelled by the user.
            if (msg && msg.action === 'wa_check_complete') {
                // When the WA check finishes, determine whether there are
                // additional numbers to process.  Do not reset the local
                // progress counters based on the message's finished/total
                // values; instead use the existing waFinished/waTotal.  This
                // ensures that progress remains cumulative across runs during
                // an active scraping session.  Only on explicit stop/reset or
                // after scraping has ended will the progress be finalised.
                $scope.$evalAsync(() => {
                    try {
                        // Identify pending numbers: phone numbers whose cid has not
                        // yet been processed and is not currently enqueued.  Use
                        // stable cid identifiers to avoid rechecking numbers when
                        // row order changes.  Normalise phone numbers to digits.
                        const rows = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
                        const pending = [];
                        // Identify numbers whose status is not final (blank or interim).  Iterate through
                        // all rows in order so that unresolved entries near the top are processed first.
                        rows.forEach((row, idx) => {
                            const raw = row && row.phone ? String(row.phone).trim() : '';
                            if (!raw) return;
                            let digits = raw.replace(/\D/g, '');
                            digits = digits.replace(/^0+/, '');
                            if (!digits) return;
                            // Skip rows that already have a final status
                            if (row && (row.whatsapp_status === 'Available' || row.whatsapp_status === 'Not available')) {
                                return;
                            }
                            pending.push({ number: digits, rowId: idx });
                        });
                        if (pending.length > 0) {
                            // Start a new WA run with the remaining unresolved numbers.  Continue
                            // from the existing progress counters.  Reset the pending completion flag.
                            $scope.waChecking = true;
                            $scope.waPendingComplete = false;
                            // Reset the enqueued rows and identifiers, then populate
                            $scope.waEnqueuedRows = {};
                            $scope.waEnqueuedIds = {};
                            pending.forEach(item => {
                                const rowIdx = item.rowId;
                                const row = rows[rowIdx];
                                if (row && row.cid) {
                                    $scope.waEnqueuedIds[row.cid] = true;
                                }
                                $scope.waEnqueuedRows[rowIdx] = true;
                            });
                            // Do not update waTotal here.  New phone numbers will be
                            // accounted for via onLocalChange.  Pending numbers represent
                            // existing rows and should not change the session total.
                            try {
                                chrome.runtime.sendMessage({ action: 'start_wa_check', items: pending }, function() {});
                            } catch (err) {
                                console.warn('wa_check_complete: failed to restart WA run', err);
                            }
                        } else {
                            // No unresolved numbers remain.  If scraping is still active, enter a
                            // pending state and wait for new numbers to arrive via onLocalChange.
                            if ($scope.scrapingActive) {
                                $scope.waPendingComplete = true;
                                $scope.waChecking = false;
                            } else {
                                // Scraping is no longer active, complete the WA run.  Ensure
                                // progress counters reflect final values based on completed IDs.
                                $scope.waChecking = false;
                                $scope.waPendingComplete = false;
                                $scope.waFinished = Object.keys($scope.waCompletedIds).length;
                                // Update waTotal to reflect the current number of discovered phone numbers
                                $scope.waTotal = Object.keys($scope.waDiscoveredIds).length;
                                // Show the WA completion popup exactly once
                                $scope.handleWaCheckComplete($scope.waFinished, $scope.waTotal);
                                // If a scraping completion was suppressed earlier, now is
                                // the appropriate time to display it.
                                if ($scope.scrapingCompletePending) {
                                    $scope.scrapingCompletePending = false;
                                    try {
                                        $scope.handleScrapingComplete();
                                    } catch (scrapeCompleteErr) {
                                        console.warn('Failed to show suppressed scraping completion after WA', scrapeCompleteErr);
                                    }
                                }
                            }
                        }
                    } catch (completeErr) {
                        console.warn('wa_check_complete: error handling completion', completeErr);
                        // Fallback to showing the completion popup to avoid leaving
                        // the UI in an inconsistent state.  Use local counts.
                        try {
                            $scope.waChecking = false;
                            $scope.waPendingComplete = false;
                            // Ensure finished reflects completed IDs.  Do not modify
                            // waTotal here; it already represents the number of
                            // discovered phone numbers in the session.
                            $scope.waFinished = Object.keys($scope.waCompletedIds).length;
                            $scope.handleWaCheckComplete($scope.waFinished, $scope.waTotal);
                        } catch (fallbackErr) {
                            console.warn('wa_check_complete: fallback completion handler failed', fallbackErr);
                        }
                    }
                });
            }

            // When the background script reports that a WA run was
            // cancelled, reset the UI without showing a completion
            // popup.  Display a snackbar message instead.  This
            // message indicates that the user stopped the run.
            if (msg && msg.action === 'wa_check_cancelled') {
                // Use safeApply to avoid nested digest when cancelling WA run
                $scope.safeApply(() => {
                    // A WA run was cancelled (typically after the user pressed stop).
                    // Do not clear completed IDs so that progress persists for the
                    // current scraping session.  Only clear enqueued sets so that
                    // pending numbers are re-queued on the next start.
                    $scope.waChecking = false;
                    $scope.waLoginWaiting = false;
                    $scope.waPendingComplete = false;
                    $scope.waEnqueuedRows = {};
                    $scope.waEnqueuedIds = {};
                    // Recompute finished based on completed IDs to keep counters
                    // accurate.  Do not modify waTotal.
                    $scope.waFinished = Object.keys($scope.waCompletedIds).length;
                    // Recompute the total number of discovered phone numbers.
                    $scope.waTotal = Object.keys($scope.waDiscoveredIds).length;
                });
                try {
                    // Do not show the bottom snackbar when the user cancels.
                    // A desktop notification will still be sent by the
                    // background script, and the progress counters will be
                    // updated to reflect the partial run.
                } catch (err) {
                    // Suppress errors
                }
            }

            // When the background script reports that the extension is waiting
            // for the user to log in.  Set waLoginWaiting so the UI can
            // display a helpful message.  Initialize progress to zero and
            // assign the total from the message if provided.
            if (msg && msg.action === 'wa_check_login_waiting') {
                // Use safeApply to update UI during login waiting without nested digest
                $scope.safeApply(() => {
                    $scope.waChecking = true;
                    $scope.waLoginWaiting = true;
                    // Preserve the current finished/total counts while waiting for login.
                    $scope.waFinished = Object.keys($scope.waCompletedIds).length;
                    $scope.waTotal = Object.keys($scope.waDiscoveredIds).length;
                });
            }
            // When login has been detected after waiting, hide the login prompt.
            if (msg && msg.action === 'wa_check_login_success') {
                // Use safeApply to update login waiting flag without nested digest
                $scope.safeApply(() => {
                    $scope.waLoginWaiting = false;
                });
            }
            // When the background script reports that login failed (timed out or
            // user cancelled) reset the UI and show a warning notification.
            if (msg && msg.action === 'wa_check_login_failed') {
                // Login failed (user not logged in).  Stop the WA check, reset
                // progress counters and clear any temporary statuses.  Notify
                // the user with a clear message indicating the cause.
                $scope.safeApply(() => {
                    $scope.waChecking = false;
                    $scope.waLoginWaiting = false;
                    // Reset all session-scoped progress counters on login failure
                    $scope.waCompletedRows = {};
                    $scope.waEnqueuedRows = {};
                    $scope.waCompletedIds = {};
                    $scope.waEnqueuedIds = {};
                    $scope.waDiscoveredIds = {};
                    $scope.waFinished = 0;
                    $scope.waTotal = 0;
                    // Clear temporary whatsapp_status values on all rows so it
                    // is obvious that no check was performed.
                    const rows = Array.isArray($scope.local.collect) ? $scope.local.collect : [];
                    rows.forEach(r => {
                        if (r) {
                            r.whatsapp_status = '';
                        }
                    });
                });
                try {
                    // Do not display the bottom snackbar when login fails.  A
                    // desktop notification is dispatched via the background
                    // script and the UI reflects the stopped state.
                } catch (err) {
                    // Suppress errors
                }
            }
        } catch (e) {
            console.warn('wa_check_update: error handling update', e);
        }
    });

});

// Jquery Data Table
// Hold a reference to the DevExtreme grid instance.  This is
// initialised on first load and re‑initialised whenever we rebuild
// the grid.  Using a module level variable allows us to persist
// settings such as the current page size across rebuilds.
var dataGrid = null;
// Underlying data store used by the DevExtreme data grid.  The
// ArrayStore is re‑created whenever the local.collect array
// changes.
var productsStore  = null;
// Track the previous number of rows inserted into the grid.  This
// prevents duplicate insert operations and reduces flicker when
// repeatedly pushing new items into the grid.
var lastCollectDataCount = 0;
var lastCollectUiSignature = '';
var lastCollectRowKeys = new Set();
var lastCollectRowHashes = new Map();

function computeCollectUiSignature(rows) {
    rows = Array.isArray(rows) ? rows : [];
    let hash = 2166136261;
    for (let i = 0; i < rows.length; i += 1) {
        const row = rows[i] || {};
        const text = [row.cid, row.place_id, row.company_name, row.name, row.phone, row.phone_number, row.email_1, row.email, row.website, row.address, row.category, row.whatsapp_status, row.wa_status, row.facebook, row.instagram, row.linkedin, row.twitter, row.youtube].join('|');
        for (let j = 0; j < text.length; j += 1) {
            hash ^= text.charCodeAt(j);
            hash = Math.imul(hash, 16777619);
        }
    }
    return rows.length + ':' + (hash >>> 0);
}
// Remember the last selected page size for the results grid.  When
// the user chooses 25/50/100 from the pager this value is updated.
// On subsequent rebuilds the same value is reused instead of
// defaulting back to 25.  Without this the grid resets to 25
// whenever new data arrives, causing the pager to jump back and
// triggering a distracting blink.
var currentPageSize = 25;
var lastColumnSignature = columnList.join("|");

function ensureDashboardRowKey(row, idx) {
    if (!row || typeof row !== 'object') return '';
    if (row.cid) return row.cid;
    const phone = waNormalizeDigitsSafe(rowPhoneValue(row));
    const base = row.place_id || row.map_link || row.company_name || row.website || phone || ('row_' + (idx || 0));
    row.cid = 'pl_' + String(base).replace(/[^a-zA-Z0-9]+/g, '_').slice(0, 80) + '_' + String(idx || 0);
    return row.cid;
}

function waNormalizeDigitsSafe(value) {
    return String(value || '').replace(/\D/g, '').replace(/^0+/, '');
}

function dedupeDashboardRows(rows) {
    const input = Array.isArray(rows) ? rows : [];
    const seen = new Set();
    return input.filter((row, index) => {
        if (!row || typeof row !== 'object') return false;
        const key = String(row.place_id || row.placeId || row.cid || row.map_link || row.phone ||
            ((row.company_name || row.name || '') + '|' + (row.address || row.formattedAddress || '')) || ('row_' + index));
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

function safeCollectRows(local){
    const rows = local && Array.isArray(local.collect) ? local.collect : [];
    repairLegacyProviderSources(rows, local);
    return rows.filter(row => row && typeof row === 'object').map((row, idx) => {
        normalizeDashboardRow(row);
        ensureDashboardRowKey(row, idx);
        return row;
    });
}

function gridRowHash(row) {
    try { return JSON.stringify(row || {}); } catch (e) { return String(row || ''); }
}

function insertIntoDataTable(local){
    if (!productsStore) return;
    const rows = safeCollectRows(local);
    const inserts = [];
    rows.forEach((row, idx) => {
        if (!row || typeof row !== 'object') return;
        const key = String(ensureDashboardRowKey(row, idx));
        const hash = gridRowHash(row);
        if (!lastCollectRowKeys.has(key)) {
            lastCollectRowKeys.add(key);
            lastCollectRowHashes.set(key, hash);
            inserts.push({ type: 'insert', data: row });
        } else if (!lastCollectRowHashes.has(key)) {
            lastCollectRowHashes.set(key, hash);
        }
    });
    lastCollectDataCount = rows.length;
    if (!inserts.length) return;
    try {
        productsStore.push(inserts);
    } catch (err) {
        console.debug('[PocketLeads] Batched grid insert deferred', err);
    }
}

function updateDataTable(local){
    if (!productsStore) return;
    const rows = safeCollectRows(local);
    const updates = [];
    rows.forEach((row, idx) => {
        if (!row || typeof row !== 'object') return;
        const key = String(ensureDashboardRowKey(row, idx));
        const hash = gridRowHash(row);
        const previous = lastCollectRowHashes.get(key);
        if (lastCollectRowKeys.has(key) && previous && previous !== hash) {
            lastCollectRowHashes.set(key, hash);
            updates.push({ type: 'update', key, data: row });
        }
    });
    if (!updates.length) return;
    try {
        productsStore.push(updates);
        if (dataGrid && dataGrid.refresh) dataGrid.refresh();
    } catch (err) {
        console.debug('[PocketLeads] Batched grid update deferred', err);
    }
}

function enableGridDragScroll(rootElement) {
    try {
        const root = rootElement && rootElement.jquery ? rootElement[0] : rootElement;
        if (!root || root.__pocketLeadsDragScrollBound) return;
        root.__pocketLeadsDragScrollBound = true;
        let active = false;
        let moved = false;
        let startX = 0;
        let startY = 0;
        let startLeft = 0;
        let startTop = 0;
        let scroller = null;
        const findScroller = target => {
            const rowsView = target && target.closest ? target.closest('.dx-datagrid-rowsview') : null;
            return rowsView ? rowsView.querySelector('.dx-scrollable-container') : root.querySelector('.dx-datagrid-rowsview .dx-scrollable-container');
        };
        root.addEventListener('mousedown', function(e) {
            if (e.button !== 0) return;
            const tag = String((e.target && e.target.tagName) || '').toLowerCase();
            if (['a', 'button', 'input', 'textarea', 'select', 'label'].includes(tag)) return;
            scroller = findScroller(e.target);
            if (!scroller) return;
            active = true;
            moved = false;
            startX = e.clientX;
            startY = e.clientY;
            startLeft = scroller.scrollLeft;
            startTop = scroller.scrollTop;
        }, true);
        document.addEventListener('mousemove', function(e) {
            if (!active || !scroller) return;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            if (!moved && Math.abs(dx) + Math.abs(dy) < 5) return;
            moved = true;
            root.classList.add('grid-dragging');
            scroller.scrollLeft = startLeft - dx;
            scroller.scrollTop = startTop - dy;
            e.preventDefault();
        }, true);
        document.addEventListener('mouseup', function() {
            if (active) root.classList.remove('grid-dragging');
            active = false;
            moved = false;
            scroller = null;
        }, true);
        root.addEventListener('wheel', function(e) {
            const sc = findScroller(e.target);
            if (!sc) return;
            if (Math.abs(e.deltaX) > Math.abs(e.deltaY) || e.shiftKey) {
                sc.scrollLeft += e.deltaX || e.deltaY;
                e.preventDefault();
            }
        }, { passive: false });
    } catch (err) {
        console.warn('enableGridDragScroll failed', err);
    }
}

let liveGridRenderEpoch = 0;

function syncGridTrackingFromRows(rows){
    const list = Array.isArray(rows) ? rows : [];
    lastCollectRowKeys = new Set();
    lastCollectRowHashes = new Map();
    list.forEach((row, idx) => {
        const key = String(ensureDashboardRowKey(row, idx));
        lastCollectRowKeys.add(key);
        lastCollectRowHashes.set(key, gridRowHash(row));
    });
    lastCollectDataCount = list.length;
    lastCollectUiSignature = computeCollectUiSignature(list);
}

function buildDataTable(sourceLocal){
    const render = local => {
        local = local || {};
        const container = document.getElementById('gridContainer');
        if (!container || !window.PocketLeadsLightGrid) return;
        const rows = safeCollectRows(local);
        const cols = buildColumnListFromRows(rows);
        if (dataGrid && dataGrid.__pocketLeadsLightGrid && productsStore) {
            productsStore.setRows(rows);
            syncGridTrackingFromRows(rows);
            // Columns may expand when the first rich provider row arrives.
            const nextColumnSignature = cols.join('|');
            if (nextColumnSignature !== lastColumnSignature && dataGrid && typeof dataGrid.setColumns === 'function') {
                try { dataGrid.setColumns(cols); } catch (e) {}
                lastColumnSignature = nextColumnSignature;
            }
            return;
        }
        try { if (dataGrid && typeof dataGrid.dispose === 'function') dataGrid.dispose(); } catch (e) {}
        productsStore = window.PocketLeadsLightGrid.createStore(rows, (row, idx) => String(ensureDashboardRowKey(row, idx)));
        syncGridTrackingFromRows(rows);
        dataGrid = window.PocketLeadsLightGrid.mount(container, {
            store: productsStore,
            columns: cols,
            pageSize: currentPageSize,
            load: query => new Promise((resolve,reject)=>chrome.runtime.sendMessage({action:'result_store_query',query},r=>{if(chrome.runtime.lastError||!r?.ok)reject(Error('Results unavailable. Retry.'));else resolve(r);})),
            values: column => new Promise((resolve,reject)=>chrome.runtime.sendMessage({action:'result_store_query',query:{facet:column,limit:1}},r=>{if(chrome.runtime.lastError||!r?.ok)reject(Error('Filter values unavailable'));else resolve(r.values||[]);}))
        });
        if (dataGrid) dataGrid.__pocketLeadsLightGrid = true;
        lastColumnSignature = cols.join('|');
    };

    // Live/storage listeners already hold the newest merged model. Use it
    // synchronously so a stale storage callback can never overwrite a fresh
    // IndexedDB delta. Initial page load still hydrates from storage normally.
    if (sourceLocal && typeof sourceLocal === 'object') {
        // Any direct model is newer than an in-flight initial storage read.
        liveGridRenderEpoch += 1;
        render(sourceLocal);
        return;
    }
    const requestedAtEpoch = liveGridRenderEpoch;
    $box.getLocal(local => {
        // If a live delta/storage listener rendered while this async read was
        // pending, the callback is stale and must never replace fresher rows.
        if (liveGridRenderEpoch !== requestedAtEpoch) return;
        render(local);
    });
}
// On Window Load
$(()=>{    
    buildDataTable();
    
    // Removed the legacy interval that injected the "Results per page" label.
    // The label is now added once via the DataGrid's onContentReady hook to
    // avoid flicker and scroll jumps during scraping.

});

/* ---------------------------------------------------------------------------
 * Licence Modal Logic
 *
 * The following self‑invoking function implements a non‑blocking licence
 * activation modal overlay on top of the dashboard.  It mirrors the
 * functionality of popup/license.js but is adapted for an embedded modal.
 * When the extension loads it checks chrome.storage for an active licence.
 * If none is found the modal is displayed.  The modal validates input
 * client‑side, fetches the public IP, posts activation/release requests to
 * the Apps Script backend and stores licence state in chrome.storage.local.
 * It also exposes helper functions on the window object so that the
 * Angular controller can trigger a release from the navbar.
 * -------------------------------------------------------------------------*/
(function() {
    // The URL of the deployed Apps Script backend.  This must match the
    // endpoint configured in your Google Apps Script project.  The same
    // constant is defined in popup/license.js.  Update in one place
    // whenever your backend URL changes.
    const APPS_SCRIPT_URL = PocketLeadsConfig.endpoint;
    const LICENSE_SUPPORT_EMAIL = PocketLeadsConfig.supportEmail;

    // v99 license performance layer
    let backendRequestCache = new Map();
    let lastPingCache = null;
    let lastPingAt = 0;
    let licenceActivationInProgress = null;
    let licenceSessionValidated = false;

    /**
     * Retrieve the stored licence object from chrome.storage.local.
     *
     * @param {function(Object|undefined)} callback Invoked with the licence
     *        object or undefined if no licence is stored.
     */
    function getStoredLicence(callback) {
        try {
            chrome.storage.local.get('license', (res) => {
                callback(res.license);
            });
        } catch (err) {
            console.error('Error reading licence from storage', err);
            callback(undefined);
        }
    }

    /**
     * Persist the given licence to chrome.storage.local.  Passing null
     * removes the entry entirely.
     *
     * @param {Object|null} licence
     */
    function setStoredLicence(licence) {
        try {
            if (!licence) {
                chrome.storage.local.remove(['license','pocketleadsAccount','pocketleadsPreparedRoute','pocketleadsPreflightState']);
            } else {
                chrome.storage.local.set({ license: licence });
            }
        } catch (err) {
            console.error('Error saving licence to storage', err);
        }
    }

    /**
     * Obtain the user's public IPv4 address from ipify.org.  On error
     * the promise rejects.
     *
     * @returns {Promise<string>}
     */
    async function getInstallationId() {
        const saved = (await PocketLeadsAccount.read()).license;
        if (saved && saved.installationId) return saved.installationId;
        // Mobile-safe identity generation. Some Chrome mobile environments
        // expose restricted device APIs that may never resolve. Never block
        // licence activation on fingerprint collection.
        try {
            if (window.PocketLeadsDeviceIdentity && typeof window.PocketLeadsDeviceIdentity.get === 'function') {
                const identity = await Promise.race([
                    window.PocketLeadsDeviceIdentity.get(),
                    new Promise(resolve => setTimeout(() => resolve(null), 1500))
                ]);
                const id = String(identity && identity.id || '').trim();
                if (id) return id;
            }
        } catch (e) {}
        const existing = localStorage.getItem('pl_mobile_fallback_device_id');
        if (existing) return existing;
        const fallback = 'pl_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2);
        try { localStorage.setItem('pl_mobile_fallback_device_id', fallback); } catch (e) {}
        return fallback;
    }


    // Legacy-only fallback for releasing pre-v82 IP-bound activations.
    async function fetchPublicIP() {
        const resp = await fetch('https://api.ipify.org?format=json');
        const json = await resp.json();
        if (!json || !json.ip) throw new Error('Invalid IP response');
        return json.ip;
    }

    /**
     * Send a JSON POST request to the Apps Script backend.  The payload
     * must include an action ('activate' or 'release'), the licence key
     * and the public IP.  Returns the parsed JSON response or undefined
     * if parsing fails.
     *
     * @param {string} action
     * @param {string} key
     * @param {string} ip
     * @returns {Promise<Object|undefined>}
     */
    async function callBackend(action, key, deviceId, legacyIp, legacyDeviceId) {
        return PocketLeadsAccount.request(action, key, deviceId, legacyIp, legacyDeviceId);
    }

    async function migrateLicenceDeviceIfNeeded(lic) {
        if (!lic || !lic.key) return lic;
        const stableDeviceId = await getInstallationId();
        if (!stableDeviceId) return lic;
        const previousDeviceId = String(lic.installationId || '').trim();
        if (previousDeviceId === stableDeviceId && Number(lic.identityVersion || 0) >= 2) return lic;
        const ping = await callBackend('ping', '', '', '');
        if (!ping || ping.status !== 'ok' || ping.physicalDeviceLicensing !== true) return lic;
        let legacyIp = '';
        try { legacyIp = await fetchPublicIP(); } catch (e) {}
        const resp = await callBackend('activate', lic.key, stableDeviceId, legacyIp, previousDeviceId);
        if (!resp || resp.status !== 'ok') return lic;
        const updated = Object.assign({}, lic, {
            active: true,
            installationId: stableDeviceId,
            identityVersion: 2,
            devices: resp.count != null ? resp.count : lic.devices,
            expiryDate: resp.expiryDate || lic.expiryDate || '',
            googleMapsCredit: resp.googleMapsCredit != null ? resp.googleMapsCredit : lic.googleMapsCredit,
            structuredCredit: resp.structuredCredit != null ? resp.structuredCredit : lic.structuredCredit,
            purchaseCredit: resp.purchaseCredit != null ? resp.purchaseCredit : lic.purchaseCredit,
            supportEmail: resp.supportEmail || LICENSE_SUPPORT_EMAIL
        });
        setStoredLicence(updated);
        return updated;
    }

    /**
     * Display the licence modal overlay.  Before showing, update the UI
     * based on the currently stored licence to show either the login or
     * logged section.
     */
    function showLicenseModal() {
        const overlay=document.getElementById('licenseOverlay');
        getStoredLicence(lic=>{updateModalUI(lic);if(overlay)overlay.style.display='flex';});
    }

    /**
     * Hide the licence modal overlay.
     */
    function hideLicenseModal() {
        const overlay = document.getElementById('licenseOverlay');
        if (overlay && licenceSessionValidated) {
            overlay.style.display = 'none';
        }
    }

    /**
     * Update the modal UI to reflect the given licence object.  If the
     * licence is active, hide the login section and display the logged
     * section along with the device count.  If inactive, show the login
     * form and reset inputs.
     *
     * @param {Object|undefined} lic
     */
    function updateModalUI(lic) {
        const loginSec = document.getElementById('loginSection');
        const loggedSec = document.getElementById('loggedSection');
        const deviceCountEl = document.getElementById('deviceCountModal');
        const planMetaEl = document.getElementById('licensePlanMetaModal');
        if (!loginSec || !loggedSec) {
            return;
        }
        if (lic && lic.active) {
            loginSec.style.display = 'none';
            loggedSec.style.display = 'block';
            if (deviceCountEl) deviceCountEl.textContent = lic.devices != null ? lic.devices : '0';
            if (planMetaEl) {
                const fmt = value => value == null || value === '' ? 'Unavailable' : String(value).toLowerCase() === 'unlimited' ? 'Unlimited' : String(value);
                const expiry = lic.expiryDate ? `Valid until: ${lic.expiryDate}` : 'Validity: ' + (lic.validityLabel || 'Server managed');
                planMetaEl.textContent = `${expiry} • Available Credit: ${fmt(lic.availableCredit)} • Purchased Credit: ${fmt(lic.purchasedCredit)}`;
            }
            // Update angular scope values to keep navbar in sync
            try {
                const $scope = angular.element(document.body).scope();
                $scope.$applyAsync(() => {
                    $scope.licenseActive = true;
                    $scope.licenseDevices = lic.devices != null ? lic.devices : 0;
                });
            } catch (err) {
                // ignore if Angular is not ready
            }
        } else {
            loginSec.style.display = 'block';
            loggedSec.style.display = 'none';
            if (deviceCountEl) deviceCountEl.textContent = '0';
            if (planMetaEl) planMetaEl.textContent = '';
            const input = document.getElementById('licenseKeyInputModal');
            if (input) input.value = '';
            try {
                const $scope = angular.element(document.body).scope();
                $scope.$applyAsync(() => {
                    $scope.licenseActive = false;
                    $scope.licenseDevices = 0;
                });
            } catch (err) {
                // ignore
            }
        }
        // Hide any previous error and spinner
        const errEl = document.getElementById('licenseErrorModal');
        const spinner = document.getElementById('spinnerModal');
        const submitBtn = document.getElementById('submitButtonModal');
        const keyInput = document.getElementById('licenseKeyInputModal');
        if (errEl) errEl.style.display = 'none';
        if (spinner) spinner.style.display = 'none';
        if (submitBtn) submitBtn.disabled = false;
        if (keyInput) keyInput.disabled = false;
        const logoutBtn = document.getElementById('logoutButtonModal');
        if (logoutBtn) logoutBtn.disabled = false;
    }

    /**
     * Release the stored licence via the backend.  Returns a promise that
     * resolves on success or rejects on error.  On success the local
     * licence entry is removed.
     *
     * @returns {Promise<void>}
     */
    async function releaseLicenceInternal() {
        return new Promise((resolve, reject) => {
            getStoredLicence(async (lic) => {
                if (!lic || !lic.key) {
                    // No licence to release; simply remove any stored data
                    licenceSessionValidated = false;
                    setStoredLicence(null);
                    resolve();
                    return;
                }
                try {
                    let installationId = String(lic.installationId || '');
                    let legacyIp = '';
                    if (!installationId) legacyIp = await fetchPublicIP();
                    const resp = await callBackend('release', lic.key, installationId, legacyIp);
                    if (resp && resp.status === 'ok') {
                        licenceSessionValidated = false;
                        setStoredLicence(null);
                        resolve();
                    } else {
                        reject(new Error('Release failed'));
                    }
                } catch (err) {
                    reject(err);
                }
            });
        });
    }

    // Expose functions so Angular controller can call them
    window.showLicenseModal = showLicenseModal;
    window.hideLicenseModal = hideLicenseModal;
    window.releaseLicenceInternal = releaseLicenceInternal;

    // When the document is ready, initialise the modal logic
    $(function() {
        // Cached confirmed state is display-only; server preflight protects paid actions.
        const initialOverlay = document.getElementById('licenseOverlay');
        if (initialOverlay) initialOverlay.style.display = 'none';
        getStoredLicence(async lic => {
            if (lic && (lic.active || lic.validating) && lic.key) {
                licenceSessionValidated = true;
                if (lic.validating) { lic = Object.assign({},lic,{active:true,validating:false}); setStoredLicence(lic); }
                updateModalUI(lic); hideLicenseModal();
                try {
                    const status = await PocketLeadsAccount.refresh({maxAgeMs:30000});
                    const latest = (await PocketLeadsAccount.read()).license;
                    if (latest && latest.active) { updateModalUI(latest); hideLicenseModal(); }
                    else if (latest && !latest.active) { licenceSessionValidated=false; updateModalUI(latest); if(initialOverlay) initialOverlay.style.display='flex'; }
                } catch (_) { /* Account panel exposes retry; keep confirmed cached UI. */ }
            } else { updateModalUI(null); if(initialOverlay) initialOverlay.style.display='flex'; }
        });
        chrome.storage.onChanged.addListener((changes,area)=>{
            if(area!=='local'||!changes.license)return;
            const lic=changes.license.newValue;
            licenceSessionValidated=!!(lic&&lic.active);
            updateModalUI(lic);
            if(initialOverlay)initialOverlay.style.display=licenceSessionValidated?'none':'flex';
        });

        // Listen for events broadcast from the background script.  When
        // 'open_license_modal' is received we refresh the modal UI from
        // storage and display it.  Using $box.on ensures the event is
        // routed through the extension's internal messaging bus.
        try {
            $box.on((evt, data) => {
                if (evt === 'open_license_modal') {
                    getStoredLicence((lic) => {
                        updateModalUI(lic);
                        showLicenseModal();
                    });
                }
            });
        } catch (err) {
            console.warn('Failed to register open_license_modal listener', err);
        }

        // Bind activation handler
        $('#submitButtonModal').on('click', async function() {
            const errEl = $('#licenseErrorModal');
            errEl.hide();
            const input = $('#licenseKeyInputModal');
            const key = (input.val() || '').trim().toUpperCase();
            input.val(key);
            const regex = /^[A-Z]{5}-\d{5}$/;
            if (!regex.test(key)) {
                errEl.text('Invalid license key format.').show();
                return;
            }
            const submitBtn = $('#submitButtonModal');
            let activationInstallationId = '';
            submitBtn.prop('disabled', true);
            input.prop('disabled', true);
            $('#spinnerModal').show();
            try {
                // Prevent duplicate taps on slow mobile networks from creating
                // multiple Apps Script executions.
                if (licenceActivationInProgress) {
                    const existing = await licenceActivationInProgress;
                    if (existing) return;
                }
                licenceActivationInProgress = (async () => {
                    activationInstallationId = await Promise.race([
                        getInstallationId(),
                        new Promise((_, reject) => setTimeout(() => reject(new Error('Device identity timeout')), 3000))
                    ]);
                    const legacyIp = '';
                    const previousLicence = await new Promise(resolve => getStoredLicence(resolve));
                    const previousDeviceId = previousLicence && String(previousLicence.key || '').toUpperCase() === key ? String(previousLicence.installationId || '') : '';
                    // Do not perform a separate ping before activation. Apps Script cold
                    // starts make this extra round trip painful on mobile networks.
                    // The activate endpoint already validates backend and licence state.
                    return await callBackend('activate', key, activationInstallationId, legacyIp, previousDeviceId);
                })();
                const resp = await licenceActivationInProgress;
                if (!resp || !resp.status) {
                    errEl.text('Network error. Please try again.').show();
                } else if (resp.status === 'ok') {
                    const count = (resp.count != null ? resp.count : 1);
                    const storedLicence = {
                        key: key, active: true, devices: count, installationId: activationInstallationId, identityVersion: 2,
                        expiryDate: resp.expiryDate || '',
                        googleMapsCredit: resp.googleMapsCredit != null ? resp.googleMapsCredit : null,
                        structuredCredit: resp.structuredCredit != null ? resp.structuredCredit : null,
                        purchaseCredit: resp.purchaseCredit != null ? resp.purchaseCredit : null,
                        supportEmail: resp.supportEmail || LICENSE_SUPPORT_EMAIL
                    };
                    // Shared worker has persisted the complete account before returning.
                    Object.assign(storedLicence, (await PocketLeadsAccount.read()).license);
                    try { chrome.runtime.sendMessage({ action: 'pocketleads_warm_backend', reason: 'licence_activation', force: false }, function(){ void chrome.runtime.lastError; }); } catch (e) {}
                    licenceSessionValidated = true;
                    updateModalUI(storedLicence);
                    hideLicenseModal();
                } else if (resp.status === 'expired') {
                    errEl.text(`This licence expired${resp.expiryDate ? ' on ' + resp.expiryDate : ''}. Contact ${resp.supportEmail || LICENSE_SUPPORT_EMAIL} to renew.`).show();
                } else if (resp.status === 'inactive') {
                    errEl.text('This licence is inactive. Please contact admin.').show();
                } else if (resp.status === 'invalid') {
                    const reason = String(resp.reason || '');
                    if (/missing_key_or_(?:ip|device)|old_backend|backend/i.test(reason)) {
                        errEl.text('Backend version mismatch. Deploy the included apps_script_code.js v33 and update the existing web-app deployment.').show();
                    } else if (reason === 'licence_not_found') {
                        errEl.text('License key was not found in the configured licence sheet. Check the key and Apps Script spreadsheet deployment.').show();
                    } else {
                        errEl.text('License validation failed' + (reason ? ': ' + reason : '.')).show();
                    }
                } else if (resp.status === 'denied') {
                    const reason = String(resp.reason || '');
                    if (/device|installation/i.test(reason)) errEl.text('This device is not authorized for this licence. Activate it if fewer than 3 devices are currently active.').show();
                    else errEl.text('This licence already has 3 active devices. Release one device before activating a new device.').show();
                } else {
                    errEl.text('Unknown response from server.').show();
                }
            } catch (err) {
                console.error('Error during licence activation', err);
                errEl.text(err && err.message ? err.message : 'Network error. Please try again.').show();
            } finally {
                licenceActivationInProgress = null;
                $('#spinnerModal').hide();
                submitBtn.prop('disabled', false);
                input.prop('disabled', false);
            }
        });

        // Bind release handler inside modal
        $('#logoutButtonModal').on('click', async function() {
            if (!window.confirm('Log out and release this licence from this device?')) return;
            $('#licenseErrorModal').hide();
            $('#spinnerModal').show();
            const logoutBtn = $('#logoutButtonModal');
            logoutBtn.prop('disabled', true);
            try {
                await releaseLicenceInternal();
                licenceSessionValidated = false;
                showLicenseModal();
                getStoredLicence((lic) => {
                    updateModalUI(lic);
                });
            } catch (err) {
                console.error('Error releasing licence', err);
                $('#licenseErrorModal').text('Error releasing licence.').show();
            } finally {
                $('#spinnerModal').hide();
                logoutBtn.prop('disabled', false);
            }
        });
    });

    // Automatically close any open search tab when the dashboard (this
    // extension page) is about to be unloaded.  This listener runs
    // once when the script is evaluated and remains registered for the
    // lifetime of the page.  It retrieves the persisted local model via
    // $box.getLocal to find the stored searchTabId and removes that tab
    // using chrome.tabs.remove if it exists.  Running this cleanup on
    // unload prevents stray Google search pages from remaining open
    // when the user closes the dashboard or reloads the extension.
    try {
        window.addEventListener('beforeunload', function() {
            try {
                if (typeof $box !== 'undefined' && $box && typeof $box.getLocal === 'function') {
                    $box.getLocal(local => {
                        try {
                            const id = local && local._taskManager && local._taskManager.searchTabId;
                            if (id && chrome && chrome.tabs && typeof chrome.tabs.remove === 'function') {
                                chrome.tabs.remove(id, function() {
                                    if (chrome.runtime && chrome.runtime.lastError) {
                                        console.warn('beforeunload: tab remove error', chrome.runtime.lastError);
                                    }
                                });
                            }
                        } catch (err2) {
                            console.warn('beforeunload: failed to close search tab', err2);
                        }
                    });
                }
            } catch (err) {
                console.warn('beforeunload: error retrieving local', err);
            }
        });
    } catch (err) {
        console.warn('Failed to register beforeunload listener', err);
    }

    // -----------------------------------------------------------------------
    // Initialise DevExtreme DropDownBox for the country selector (single‑select)
    //
    // The dashboard includes a country selector in the sidebar.  To provide a
    // searchable single‑select dropdown without checkboxes, we initialise a
    // DevExtreme DropDownBox on the #countryDropDown element.  The dropdown
    // embeds a dxList configured for single selection.  When the user
    // selects a country, we update local.countries (stored as a one‑element
    // array) and local.country (the first and only selection for backward
    // compatibility) and persist the change via saveLocal().
    try {
        $(function() {
            /*
             * Define a mapping of ISO country names to their corresponding flag
             * emoji.  The keys in this object correspond to the country
             * names used throughout the dashboard (including certain ISO
             * synonym forms) and the values are the Unicode regional
             * indicator symbols that render as flags.  This mapping is used
             * by the country selector to prepend the correct flag for each
             * option.  If a flag is not found for a given name, an empty
             * string is returned.  The mapping is attached to the global
             * `window.countryFlags` so that it can be reused elsewhere if
             * needed.
             *
             * NOTE: This extension now also defines a separate mapping
             * window.countryIsoCodes (see below) which maps each country
             * name to its ISO‑3166 alpha‑2 code.  That mapping is used to
             * display real flag icons via Semantic UI's flag sprites.  The
             * emoji map is retained for backwards compatibility and may be
             * used elsewhere in the dashboard.
             */
            if (!window.countryFlags) {
                window.countryFlags = {
                    "Afghanistan": "\uD83C\uDDE6\uD83C\uDDEB",
                    "Albania": "\uD83C\uDDE6\uD83C\uDDF1",
                    "Algeria": "\uD83C\uDDE9\uD83C\uDDFF",
                    "American Samoa": "\uD83C\uDDE6\uD83C\uDDF8",
                    "Andorra": "\uD83C\uDDE6\uD83C\uDDE9",
                    "Angola": "\uD83C\uDDE6\uD83C\uDDF4",
                    "Anguilla": "\uD83C\uDDE6\uD83C\uDDEE",
                    "Antarctica": "\uD83C\uDDE6\uD83C\uDDF6",
                    "Antigua and Barbuda": "\uD83C\uDDE6\uD83C\uDDEC",
                    "Argentina": "\uD83C\uDDE6\uD83C\uDDF7",
                    "Armenia": "\uD83C\uDDE6\uD83C\uDDF2",
                    "Aruba": "\uD83C\uDDE6\uD83C\uDDFC",
                    "Australia": "\uD83C\uDDE6\uD83C\uDDFA",
                    "Austria": "\uD83C\uDDE6\uD83C\uDDF9",
                    "Azerbaijan": "\uD83C\uDDE6\uD83C\uDDFF",
                    "Bahamas": "\uD83C\uDDE7\uD83C\uDDF8",
                    "Bahrain": "\uD83C\uDDE7\uD83C\uDDED",
                    "Bangladesh": "\uD83C\uDDE7\uD83C\uDDE9",
                    "Barbados": "\uD83C\uDDE7\uD83C\uDDE7",
                    "Belarus": "\uD83C\uDDE7\uD83C\uDDFE",
                    "Belgium": "\uD83C\uDDE7\uD83C\uDDEA",
                    "Belize": "\uD83C\uDDE7\uD83C\uDDF9",
                    "Benin": "\uD83C\uDDE7\uD83C\uDDEF",
                    "Bermuda": "\uD83C\uDDE7\uD83C\uDDF2",
                    "Bhutan": "\uD83C\uDDE7\uD83C\uDDF9",
                    "Bolivia, Plurinational State of": "\uD83C\uDDE7\uD83C\uDDF4",
                    "Bonaire, Sint Eustatius and Saba": "\uD83C\uDDE7\uD83C\uDDF6",
                    "Bosnia and Herzegovina": "\uD83C\uDDE7\uD83C\uDDE8",
                    "Botswana": "\uD83C\uDDE7\uD83C\uDDFC",
                    "Bouvet Island": "\uD83C\uDDE7\uD83C\uDDFB",
                    "Brazil": "\uD83C\uDDE7\uD83C\uDDFA",
                    "British Indian Ocean Territory": "\uD83C\uDDEE\uD83C\uDDF4",
                    "Brunei Darussalam": "\uD83C\uDDE7\uD83C\uDDF3",
                    "Bulgaria": "\uD83C\uDDE7\uD83C\uDDEC",
                    "Burkina Faso": "\uD83C\uDDE7\uD83C\uDDEB",
                    "Burundi": "\uD83C\uDDE7\uD83C\uDDEE",
                    "Cabo Verde": "\uD83C\uDDE8\uD83C\uDDFB",
                    "Cambodia": "\uD83C\uDDF0\uD83C\uDDED",
                    "Cameroon": "\uD83C\uDDE8\uD83C\uDDF2",
                    "Canada": "\uD83C\uDDE8\uD83C\uDDE6",
                    "Cayman Islands": "\uD83C\uDDF0\uD83C\uDDFE",
                    "Central African Republic": "\uD83C\uDDE8\uD83C\uDDF3",
                    "Chad": "\uD83C\uDDF9\uD83C\uDDE9",
                    "Chile": "\uD83C\uDDE8\uD83C\uDDF1",
                    "China": "\uD83C\uDDE8\uD83C\uDDF3",
                    "Christmas Island": "\uD83C\uDDE8\uD83C\uDDFD",
                    "Cocos (Keeling) Islands": "\uD83C\uDDE8\uD83C\uDDEC",
                    "Colombia": "\uD83C\uDDE8\uD83C\uDDF4",
                    "Comoros": "\uD83C\uDDF0\uD83C\uDDF2",
                    "Congo": "\uD83C\uDDE8\uD83C\uDDEC",
                    "Congo, The Democratic Republic of the": "\uD83C\uDDE8\uD83C\uDDF4",
                    "Cook Islands": "\uD83C\uDDE8\uD83C\uDDF0",
                    "Costa Rica": "\uD83C\uDDE8\uD83C\uDDF7",
                    "Croatia": "\uD83C\uDDED\uD83C\uDDF7",
                    "Cuba": "\uD83C\uDDE8\uD83C\uDDFA",
                    "Curaçao": "\uD83C\uDDE8\uD83C\uDDFC",
                    "Cyprus": "\uD83C\uDDF2\uD83C\uDDFE",
                    "Czechia": "\uD83C\uDDE9\uD83C\uDDF9",
                    "Côte d'Ivoire": "\uD83C\uDDEE\uD83C\uDDF7",
                    "Denmark": "\uD83C\uDDE9\uD83C\uDDF0",
                    "Djibouti": "\uD83C\uDDE9\uD83C\uDDEF",
                    "Dominica": "\uD83C\uDDE9\uD83C\uDDF2",
                    "Dominican Republic": "\uD83C\uDDE9\uD83C\uDDF4",
                    "Ecuador": "\uD83C\uDDEA\uD83C\uDDE8",
                    "Egypt": "\uD83C\uDDEA\uD83C\uDDEC",
                    "El Salvador": "\uD83C\uDDF2\uD83C\uDDF8",
                    "Equatorial Guinea": "\uD83C\uDDEC\uD83C\uDDF6",
                    "Eritrea": "\uD83C\uDDEA\uD83C\uDDF7",
                    "Estonia": "\uD83C\uDDEA\uD83C\uDDFA",
                    "Eswatini": "\uD83C\uDDFF\uD83C\uDDF8",
                    "Ethiopia": "\uD83C\uDDEA\uD83C\uDDF9",
                    "Falkland Islands (Malvinas)": "\uD83C\uDDEB\uD83C\uDDF0",
                    "Faroe Islands": "\uD83C\uDDEB\uD83C\uDDF4",
                    "Fiji": "\uD83C\uDDEB\uD83C\uDDEF",
                    "Finland": "\uD83C\uDDEB\uD83C\uDDEE",
                    "France": "\uD83C\uDDEB\uD83C\uDDF7",
                    "French Guiana": "\uD83C\uDDEC\uD83C\uDDEB",
                    "French Polynesia": "\uD83C\uDDF5\uD83C\uDDEB",
                    "French Southern Territories": "\uD83C\uDDF9\uD83C\uDDEB",
                    "Gabon": "\uD83C\uDDEC\uD83C\uDDF2",
                    "Gambia": "\uD83C\uDDEC\uD83C\uDDF2",
                    "Georgia": "\uD83C\uDDEC\uD83C\uDDEA",
                    "Germany": "\uD83C\uDDE9\uD83C\uDDEA",
                    "Ghana": "\uD83C\uDDEC\uD83C\uDDDD",
                    "Gibraltar": "\uD83C\uDDEC\uD83C\uDDEE",
                    "Greece": "\uD83C\uDDEC\uD83C\uDDF7",
                    "Greenland": "\uD83C\uDDEC\uD83C\uDDEB",
                    "Grenada": "\uD83C\uDDEC\uD83C\uDDE9",
                    "Guadeloupe": "\uD83C\uDDEC\uD83C\uDDEB",
                    "Guam": "\uD83C\uDDEC\uD83C\uDDF8",
                    "Guatemala": "\uD83C\uDDEC\uD83C\uDDF9",
                    "Guernsey": "\uD83C\uDDEC\uD83C\uDDED",
                    "Guinea": "\uD83C\uDDEC\uD83C\uDDF3",
                    "Guinea-Bissau": "\uD83C\uDDEC\uD83C\uDDFC",
                    "Guyana": "\uD83C\uDDEC\uD83C\uDDFE",
                    "Haiti": "\uD83C\uDDED\uD83C\uDDF9",
                    "Heard Island and McDonald Islands": "\uD83C\uDDED\uD83C\uDDF0",
                    "Holy See (Vatican City State)": "\uD83C\uDDFB\uD83C\uDDEA",
                    "Honduras": "\uD83C\uDDED\uD83C\uDDF3",
                    "Hong Kong": "\uD83C\uDDED\uD83C\uDDF0",
                    "Hungary": "\uD83C\uDDED\uD83C\uDDFA",
                    "Iceland": "\uD83C\uDDEE\uD83C\uDDF8",
                    "India": "\uD83C\uDDEE\uD83C\uDDF3",
                    "Indonesia": "\uD83C\uDDEE\uD83C\uDDE9",
                    "Iran, Islamic Republic of": "\uD83C\uDDEE\uD83C\uDDF7",
                    "Iraq": "\uD83C\uDDEE\uD83C\uDDFA",
                    "Ireland": "\uD83C\uDDEE\uD83C\uDDEA",
                    "Isle of Man": "\uD83C\uDDEE\uD83C\uDDEC",
                    "Israel": "\uD83C\uDDEE\uD83C\uDDF1",
                    "Italy": "\uD83C\uDDEE\uD83C\uDDF9",
                    "Jamaica": "\uD83C\uDDEF\uD83C\uDDF2",
                    "Japan": "\uD83C\uDDEF\uD83C\uDDF5",
                    "Jersey": "\uD83C\uDDEF\uD83C\uDDED",
                    "Jordan": "\uD83C\uDDEF\uD83C\uDDF4",
                    "Kazakhstan": "\uD83C\uDDDF\uD83C\uDDF0",
                    "Kenya": "\uD83C\uDDDF\uD83C\uDDEA",
                    "Kiribati": "\uD83C\uDDDF\uD83C\uDDEE",
                    "Korea, Democratic People's Republic of": "\uD83C\uDDF0\uD83C\uDDF5",
                    "Korea, Republic of": "\uD83C\uDDF0\uD83C\uDDF7",
                    "Kuwait": "\uD83C\uDDDF\uD83C\uDDFC",
                    "Kyrgyzstan": "\uD83C\uDDDF\uD83C\uDDEC",
                    "Lao People's Democratic Republic": "\uD83C\uDDF1\uD83C\uDDFA",
                    "Latvia": "\uD83C\uDDF1\uD83C\uDDFB",
                    "Lebanon": "\uD83C\uDDF1\uD83C\uDDEE",
                    "Lesotho": "\uD83C\uDDF1\uD83C\uDDF8",
                    "Liberia": "\uD83C\uDDF1\uD83C\uDDF7",
                    "Libya": "\uD83C\uDDF1\uD83C\uDDFF",
                    "Liechtenstein": "\uD83C\uDDF1\uD83C\uDDEE",
                    "Lithuania": "\uD83C\uDDF1\uD83C\uDDF9",
                    "Luxembourg": "\uD83C\uDDF1\uD83C\uDDFA",
                    "Macao": "\uD83C\uDDF2\uD83C\uDDF4",
                    "Madagascar": "\uD83C\uDDF2\uD83C\uDDDA",
                    "Malawi": "\uD83C\uDDF2\uD83C\uDDFC",
                    "Malaysia": "\uD83C\uDDF2\uD83C\uDDFE",
                    "Maldives": "\uD83C\uDDF2\uD83C\uDDFA",
                    "Mali": "\uD83C\uDDF2\uD83C\uDDF1",
                    "Malta": "\uD83C\uDDF2\uD83C\uDDDF",
                    "Marshall Islands": "\uD83C\uDDF2\uD83C\uDDF8",
                    "Martinique": "\uD83C\uDDF2\uD83C\uDDEC",
                    "Mauritania": "\uD83C\uDDF2\uD83C\uDDDF",
                    "Mauritius": "\uD83C\uDDF2\uD83C\uDDEA",
                    "Mayotte": "\uD83C\uDDFE\uD83C\uDDF9",
                    "Mexico": "\uD83C\uDDF2\uD83C\uDDFD",
                    "Micronesia, Federated States of": "\uD83C\uDDEB\uD83C\uDDFA",
                    "Moldova, Republic of": "\uD83C\uDDF2\uD83C\uDDE9",
                    "Monaco": "\uD83C\uDDF2\uD83C\uDDE8",
                    "Mongolia": "\uD83C\uDDF2\uD83C\uDDF3",
                    "Montenegro": "\uD83C\uDDF2\uD83C\uDDEA",
                    "Montserrat": "\uD83C\uDDF2\uD83C\uDDF8",
                    "Morocco": "\uD83C\uDDF2\uD83C\uDDE6",
                    "Mozambique": "\uD83C\uDDF2\uD83C\uDDFF",
                    "Myanmar": "\uD83C\uDDF2\uD83C\uDDF2",
                    "Namibia": "\uD83C\uDDF3\uD83C\uDDE6",
                    "Nauru": "\uD83C\uDDF3\uD83C\uDDF7",
                    "Netherlands": "\uD83C\uDDF3\uD83C\uDDF1",
                    "New Caledonia": "\uD83C\uDDF3\uD83C\uDDE8",
                    "New Zealand": "\uD83C\uDDF3\uD83C\uDDFF",
                    "Nicaragua": "\uD83C\uDDF3\uD83C\uDDF7",
                    "Niger": "\uD83C\uDDF3\uD83C\uDDEA",
                    "Nigeria": "\uD83C\uDDF3\uD83C\uDDEC",
                    "Niue": "\uD83C\uDDF3\uD83C\uDDFC",
                    "Norfolk Island": "\uD83C\uDDF3\uD83C\uDDEB",
                    "North Macedonia": "\uD83C\uDDF2\uD83C\uDDF0",
                    "Northern Mariana Islands": "\uD83C\uDDF2\uD83C\uDDF5",
                    "Norway": "\uD83C\uDDF3\uD83C\uDDF4",
                    "Oman": "\uD83C\uDDF4\uD83C\uDDF4",
                    "Pakistan": "\uD83C\uDDDF\uD83C\uDDF6",
                    "Palau": "\uD83C\uDDF5\uD83C\uDDFD",
                    "Palestine, State of": "\uD83C\uDDF5\uD83C\uDDF8",
                    "Panama": "\uD83C\uDDDF\uD83C\uDDE6",
                    "Papua New Guinea": "\uD83C\uDDDF\uD83C\uDDEC",
                    "Paraguay": "\uD83C\uDDF5\uD83C\uDDFE",
                    "Peru": "\uD83C\uDDF5\uD83C\uDDEA",
                    "Philippines": "\uD83C\uDDF5\uD83C\uDDED",
                    "Pitcairn": "\uD83C\uDDF5\uD83C\uDDF3",
                    "Poland": "\uD83C\uDDF5\uD83C\uDDF1",
                    "Portugal": "\uD83C\uDDF5\uD83C\uDDF9",
                    "Puerto Rico": "\uD83C\uDDF5\uD83C\uDDF7",
                    "Qatar": "\uD83C\uDDF6\uD83C\uDDE6",
                    "Romania": "\uD83C\uDDF7\uD83C\uDDF4",
                    "Russian Federation": "\uD83C\uDDF7\uD83C\uDDFA",
                    "Rwanda": "\uD83C\uDDF7\uD83C\uDDFC",
                    "Réunion": "\uD83C\uDDF7\uD83C\uDDEA",
                    "Saint Barthélemy": "\uD83C\uDDE7\uD83C\uDDF1",
                    "Saint Helena, Ascension and Tristan da Cunha": "\uD83C\uDDF8\uD83C\uDDED",
                    "Saint Kitts and Nevis": "\uD83C\uDDF0\uD83C\uDDF3",
                    "Saint Lucia": "\uD83C\uDDF1\uD83C\uDDE9",
                    "Saint Martin (French part)": "\uD83C\uDDF0\uD83C\uDDF4",
                    "Saint Pierre and Miquelon": "\uD83C\uDDF5\uD83C\uDDED",
                    "Saint Vincent and the Grenadines": "\uD83C\uDDF1\uD83C\uDDE8",
                    "Samoa": "\uD83C\uDDDF\uD83C\uDDF8",
                    "San Marino": "\uD83C\uDDF8\uD83C\uDDEE",
                    "Sao Tome and Principe": "\uD83C\uDDF8\uD83C\uDDF2",
                    "Saudi Arabia": "\uD83C\uDDEA\uD83C\uDDF0",
                    "Senegal": "\uD83C\uDDE9\uD83C\uDDF8",
                    "Serbia": "\uD83C\uDDF7\uD83C\uDDF8",
                    "Seychelles": "\uD83C\uDDF8\uD83C\uDDED",
                    "Sierra Leone": "\uD83C\uDDF8\uD83C\uDDF1",
                    "Singapore": "\uD83C\uDDEE\uD83C\uDDF7",
                    "Sint Maarten (Dutch part)": "\uD83C\uDDF8\uD83C\uDDDF",
                    "Slovakia": "\uD83C\uDDF8\uD83C\uDDF0",
                    "Slovenia": "\uD83C\uDDF8\uD83C\uDDEE",
                    "Solomon Islands": "\uD83C\uDDF8\uD83C\uDDDF",
                    "Somalia": "\uD83C\uDDF8\uD83C\uDDDC",
                    "South Africa": "\uD83C\uDDFF\uD83C\uDDEC",
                    "South Georgia and the South Sandwich Islands": "\uD83C\uDDE5\uD83C\uDDEB",
                    "South Sudan": "\uD83C\uDDF8\uD83C\uDDF8",
                    "Spain": "\uD83C\uDDEA\uD83C\uDDF8",
                    "Sri Lanka": "\uD83C\uDDF1\uD83C\uDDF0",
                    "St. Barthélemy": "\uD83C\uDDE7\uD83C\uDDF1",
                    "Sudan": "\uD83C\uDDF8\uD83C\uDDE9",
                    "Suriname": "\uD83C\uDDF8\uD83C\uDDE7",
                    "Svalbard and Jan Mayen": "\uD83C\uDDF8\uD83C\uDDED",
                    "Sweden": "\uD83C\uDDF8\uD83C\uDDEA",
                    "Switzerland": "\uD83C\uDDE8\uD83C\uDDED",
                    "Syrian Arab Republic": "\uD83C\uDDF4\uD83C\uDDE6",
                    "Taiwan, Province of China": "\uD83C\uDDF9\uD83C\uDDFC",
                    "Tajikistan": "\uD83C\uDDF9\uD83C\uDDEC",
                    "Tanzania, United Republic of": "\uD83C\uDDF9\uD83C\uDDFF",
                    "Thailand": "\uD83C\uDDF9\uD83C\uDDED",
                    "Timor-Leste": "\uD83C\uDDF9\uD83C\uDDF1",
                    "Togo": "\uD83C\uDDF9\uD83C\uDDEC",
                    "Tokelau": "\uD83C\uDDF9\uD83C\uDDF0",
                    "Tonga": "\uD83C\uDDF9\uD83C\uDDF4",
                    "Trinidad and Tobago": "\uD83C\uDDF9\uD83C\uDDF9",
                    "Tunisia": "\uD83C\uDDF9\uD83C\uDDF3",
                    "Turkmenistan": "\uD83C\uDDF9\uD83C\uDDF2",
                    "Turks and Caicos Islands": "\uD83C\uDDF4\uD83C\uDDF0",
                    "Tuvalu": "\uD83C\uDDF9\uD83C\uDDFC",
                    "Türkiye": "\uD83C\uDDF9\uD83C\uDDF7",
                    "Uganda": "\uD83C\uDDFE\uD83C\uDDEC",
                    "Ukraine": "\uD83C\uDDFA\uD83C\uDDE6",
                    "United Arab Emirates": "\uD83C\uDDE6\uD83C\uDDEA",
                    "United Kingdom": "\uD83C\uDDEC\uD83C\uDDE7",
                    "United States": "\uD83C\uDDFA\uD83C\uDDF8",
                    "United States Minor Outlying Islands": "\uD83C\uDDFA\uD83C\uDDF2",
                    "Uruguay": "\uD83C\uDDFA\uD83C\uDDFE",
                    "Uzbekistan": "\uD83C\uDDFA\uD83C\uDDEC",
                    "Vanuatu": "\uD83C\uDDFA\uD83C\uDDFA",
                    "Venezuela, Bolivarian Republic of": "\uD83C\uDDFA\uD83C\uDDF9",
                    "Viet Nam": "\uD83C\uDDFB\uD83C\uDDF3",
                    "Virgin Islands, British": "\uD83C\uDDFB\uD83C\uDDEC",
                    "Virgin Islands, U.S.": "\uD83C\uDDFA\uD83C\uDDEE",
                    "Wallis and Futuna": "\uD83C\uDDFB\uD83C\uDDEB",
                    "Western Sahara": "\uD83C\uDDEA\uD83C\uDDE9",
                    "Yemen": "\uD83C\uDDFE\uD83C\uDDEA",
                    "Zambia": "\uD83C\uDDF5\uD83C\uDDFC",
                    "Zimbabwe": "\uD83C\uDDF5\uD83C\uDDF0",
                    "Åland Islands": "\uD83C\uDDE6\uD83C\uDDF9"
                };

            /*
             * Define a mapping from country names to their ISO‑3166 alpha‑2
             * codes.  These codes are used with Semantic UI's flag sprite
             * classes to render real flag icons (see the itemTemplate in
             * initializeCountryDropDown below).  If a name cannot be found
             * or mapped, the code will be left blank and no icon will be
             * rendered.  This mapping is attached to the global
             * window.countryIsoCodes so that it can be reused elsewhere if
             * needed.  The mapping below was generated programmatically
             * using pycountry and includes fallbacks for common aliases and
             * multi‑word names.
             */
            if (!window.countryIsoCodes) {
                window.countryIsoCodes = {
                    "Aruba": "aw",
                    "Afghanistan": "af",
                    "Angola": "ao",
                    "Anguilla": "ai",
                    "Åland Islands": "ax",
                    "Albania": "al",
                    "Andorra": "ad",
                    "United Arab Emirates": "ae",
                    "Argentina": "ar",
                    "Armenia": "am",
                    "American Samoa": "as",
                    "Antarctica": "aq",
                    "French Southern Territories": "tf",
                    "Antigua and Barbuda": "ag",
                    "Australia": "au",
                    "Austria": "at",
                    "Azerbaijan": "az",
                    "Burundi": "bi",
                    "Belgium": "be",
                    "Benin": "bj",
                    "Bonaire, Sint Eustatius and Saba": "bq",
                    "Burkina Faso": "bf",
                    "Bangladesh": "bd",
                    "Bulgaria": "bg",
                    "Bahrain": "bh",
                    "Bahamas": "bs",
                    "Bosnia and Herzegovina": "ba",
                    "Saint Barthélemy": "bl",
                    "Belarus": "by",
                    "Belize": "bz",
                    "Bermuda": "bm",
                    "Bolivia, Plurinational State of": "bo",
                    "Brazil": "br",
                    "Barbados": "bb",
                    "Brunei Darussalam": "bn",
                    "Bhutan": "bt",
                    "Bouvet Island": "bv",
                    "Botswana": "bw",
                    "Central African Republic": "cf",
                    "Canada": "ca",
                    "Cocos (Keeling) Islands": "cc",
                    "Switzerland": "ch",
                    "Chile": "cl",
                    "China": "cn",
                    "Côte d'Ivoire": "ci",
                    "Cameroon": "cm",
                    "Congo, The Democratic Republic of the": "cd",
                    "Congo": "cg",
                    "Cook Islands": "ck",
                    "Colombia": "co",
                    "Comoros": "km",
                    "Cabo Verde": "cv",
                    "Costa Rica": "cr",
                    "Cuba": "cu",
                    "Curaçao": "cw",
                    "Christmas Island": "cx",
                    "Cayman Islands": "ky",
                    "Cyprus": "cy",
                    "Czechia": "cz",
                    "Germany": "de",
                    "Djibouti": "dj",
                    "Dominica": "dm",
                    "Denmark": "dk",
                    "Dominican Republic": "do",
                    "Algeria": "dz",
                    "Ecuador": "ec",
                    "Egypt": "eg",
                    "Eritrea": "er",
                    "Western Sahara": "eh",
                    "Spain": "es",
                    "Estonia": "ee",
                    "Ethiopia": "et",
                    "Finland": "fi",
                    "Fiji": "fj",
                    "Falkland Islands (Malvinas)": "fk",
                    "France": "fr",
                    "Faroe Islands": "fo",
                    "Micronesia, Federated States of": "fm",
                    "Gabon": "ga",
                    "United Kingdom": "gb",
                    "Georgia": "ge",
                    "Guernsey": "gg",
                    "Ghana": "gh",
                    "Gibraltar": "gi",
                    "Guinea": "gn",
                    "Guadeloupe": "gp",
                    "Gambia": "gm",
                    "Guinea-Bissau": "gw",
                    "Equatorial Guinea": "gq",
                    "Greece": "gr",
                    "Grenada": "gd",
                    "Greenland": "gl",
                    "Guatemala": "gt",
                    "French Guiana": "gf",
                    "Guam": "gu",
                    "Guyana": "gy",
                    "Hong Kong": "hk",
                    "Heard Island and McDonald Islands": "hm",
                    "Honduras": "hn",
                    "Croatia": "hr",
                    "Haiti": "ht",
                    "Hungary": "hu",
                    "Indonesia": "id",
                    "Isle of Man": "im",
                    "India": "in",
                    "British Indian Ocean Territory": "io",
                    "Ireland": "ie",
                    "Iran, Islamic Republic of": "ir",
                    "Iraq": "iq",
                    "Iceland": "is",
                    "Israel": "il",
                    "Italy": "it",
                    "Jamaica": "jm",
                    "Jersey": "je",
                    "Jordan": "jo",
                    "Japan": "jp",
                    "Kazakhstan": "kz",
                    "Kenya": "ke",
                    "Kyrgyzstan": "kg",
                    "Cambodia": "kh",
                    "Kiribati": "ki",
                    "Saint Kitts and Nevis": "kn",
                    "Korea, Republic of": "kr",
                    "Kuwait": "kw",
                    "Lao People's Democratic Republic": "la",
                    "Lebanon": "lb",
                    "Liberia": "lr",
                    "Libya": "ly",
                    "Saint Lucia": "lc",
                    "Liechtenstein": "li",
                    "Sri Lanka": "lk",
                    "Lesotho": "ls",
                    "Lithuania": "lt",
                    "Luxembourg": "lu",
                    "Latvia": "lv",
                    "Macao": "mo",
                    "Saint Martin (French part)": "mf",
                    "Morocco": "ma",
                    "Monaco": "mc",
                    "Moldova, Republic of": "md",
                    "Madagascar": "mg",
                    "Maldives": "mv",
                    "Mexico": "mx",
                    "Marshall Islands": "mh",
                    "North Macedonia": "mk",
                    "Mali": "ml",
                    "Malta": "mt",
                    "Myanmar": "mm",
                    "Montenegro": "me",
                    "Mongolia": "mn",
                    "Northern Mariana Islands": "mp",
                    "Mozambique": "mz",
                    "Mauritania": "mr",
                    "Montserrat": "ms",
                    "Martinique": "mq",
                    "Mauritius": "mu",
                    "Malawi": "mw",
                    "Malaysia": "my",
                    "Mayotte": "yt",
                    "Namibia": "na",
                    "New Caledonia": "nc",
                    "Niger": "ne",
                    "Norfolk Island": "nf",
                    "Nigeria": "ng",
                    "Nicaragua": "ni",
                    "Niue": "nu",
                    "Netherlands": "nl",
                    "Norway": "no",
                    "Nauru": "nr",
                    "New Zealand": "nz",
                    "Oman": "om",
                    "Pakistan": "pk",
                    "Panama": "pa",
                    "Pitcairn": "pn",
                    "Peru": "pe",
                    "Philippines": "ph",
                    "Palau": "pw",
                    "Papua New Guinea": "pg",
                    "Poland": "pl",
                    "Puerto Rico": "pr",
                    "Korea, Democratic People's Republic of": "kp",
                    "Portugal": "pt",
                    "Paraguay": "py",
                    "Palestine, State of": "ps",
                    "French Polynesia": "pf",
                    "Qatar": "qa",
                    "Réunion": "re",
                    "Romania": "ro",
                    "Russian Federation": "ru",
                    "Rwanda": "rw",
                    "Saudi Arabia": "sa",
                    "Sudan": "sd",
                    "Senegal": "sn",
                    "Singapore": "sg",
                    "South Georgia and the South Sandwich Islands": "gs",
                    "Saint Helena, Ascension and Tristan da Cunha": "sh",
                    "Svalbard and Jan Mayen": "sj",
                    "Solomon Islands": "sb",
                    "Sierra Leone": "sl",
                    "El Salvador": "sv",
                    "San Marino": "sm",
                    "Somalia": "so",
                    "Saint Pierre and Miquelon": "pm",
                    "Serbia": "rs",
                    "South Sudan": "ss",
                    "Sao Tome and Principe": "st",
                    "Suriname": "sr",
                    "Slovakia": "sk",
                    "Slovenia": "si",
                    "Sweden": "se",
                    "Eswatini": "sz",
                    "Sint Maarten (Dutch part)": "sx",
                    "Seychelles": "sc",
                    "Syrian Arab Republic": "sy",
                    "Turks and Caicos Islands": "tc",
                    "Chad": "td",
                    "Togo": "tg",
                    "Thailand": "th",
                    "Tajikistan": "tj",
                    "Tokelau": "tk",
                    "Turkmenistan": "tm",
                    "Timor-Leste": "tl",
                    "Tonga": "to",
                    "Trinidad and Tobago": "tt",
                    "Tunisia": "tn",
                    "Türkiye": "tr",
                    "Tuvalu": "tv",
                    "Taiwan, Province of China": "tw",
                    "Tanzania, United Republic of": "tz",
                    "Uganda": "ug",
                    "Ukraine": "ua",
                    "United States Minor Outlying Islands": "um",
                    "Uruguay": "uy",
                    "United States": "us",
                    "Uzbekistan": "uz",
                    "Holy See (Vatican City State)": "va",
                    "Saint Vincent and the Grenadines": "vc",
                    "Venezuela, Bolivarian Republic of": "ve",
                    "Virgin Islands, British": "vg",
                    "Virgin Islands, U.S.": "vi",
                    "Viet Nam": "vn",
                    "Vanuatu": "vu",
                    "Wallis and Futuna": "wf",
                    "Samoa": "ws",
                    "Yemen": "ye",
                    "South Africa": "za",
                    "Zambia": "zm",
                    "Zimbabwe": "zw"
                };
            }
            }
            /**
             * Initialise a DevExtreme DropDownBox on the given DOM element.
             * This helper encapsulates the logic for retrieving the data source,
             * loading any saved selection and configuring the drop‑down list.  It is
             * invoked both when the dropdown element is present at page load and
             * when it appears later (e.g. inside the navbar via ng‑include).
             *
             * @param {HTMLElement} domEl The DOM element on which to instantiate the DropDownBox.
             */
            function initializeCountryDropDown(domEl) {
                try {
                    // Obtain the Angular scope from the country‑select container, if available.
                    const scopeElem = document.querySelector('.country-select');
                    const scope = scopeElem ? angular.element(scopeElem).scope() : null;

                    // Determine the data source using global fallbacks first, then the Angular scope.
                    let dataSrc = [];
                    if (window.countryList && Array.isArray(window.countryList) && window.countryList.length) {
                        dataSrc = window.countryList;
                    } else if (scope && Array.isArray(scope.countries) && scope.countries.length) {
                        dataSrc = scope.countries;
                    } else {
                        /*
                         * Fallback: use a static list of country names identical to $scope.countries.
                         * We mirror the ISO 3166 derived list defined in $scope.countries above.  This ensures
                         * the dropdown is populated with all countries even if window.countryList or
                         * scope.countries are unavailable at initialisation time.  Do not alter the order or
                         * content of this array unless you update $scope.countries accordingly.
                         */
                        dataSrc = [
                            "Aruba", "Afghanistan", "Angola", "Anguilla", "Åland Islands", "Albania", "Andorra", "United Arab Emirates", "Argentina",
                            "Armenia", "American Samoa", "Antarctica", "French Southern Territories", "Antigua and Barbuda", "Australia", "Austria",
                            "Azerbaijan", "Burundi", "Belgium", "Benin", "Bonaire, Sint Eustatius and Saba", "Burkina Faso", "Bangladesh", "Bulgaria",
                            "Bahrain", "Bahamas", "Bosnia and Herzegovina", "Saint Barthélemy", "Belarus", "Belize", "Bermuda",
                            "Bolivia, Plurinational State of", "Brazil", "Barbados", "Brunei Darussalam", "Bhutan", "Bouvet Island", "Botswana",
                            "Central African Republic", "Canada", "Cocos (Keeling) Islands", "Switzerland", "Chile", "China", "Côte d'Ivoire",
                            "Cameroon", "Congo, The Democratic Republic of the", "Congo", "Cook Islands", "Colombia", "Comoros", "Cabo Verde",
                            "Costa Rica", "Cuba", "Curaçao", "Christmas Island", "Cayman Islands", "Cyprus", "Czechia", "Germany", "Djibouti",
                            "Dominica", "Denmark", "Dominican Republic", "Algeria", "Ecuador", "Egypt", "Eritrea", "Western Sahara", "Spain",
                            "Estonia", "Ethiopia", "Finland", "Fiji", "Falkland Islands (Malvinas)", "France", "Faroe Islands",
                            "Micronesia, Federated States of", "Gabon", "United Kingdom", "Georgia", "Guernsey", "Ghana", "Gibraltar", "Guinea",
                            "Guadeloupe", "Gambia", "Guinea-Bissau", "Equatorial Guinea", "Greece", "Grenada", "Greenland", "Guatemala",
                            "French Guiana", "Guam", "Guyana", "Hong Kong", "Heard Island and McDonald Islands", "Honduras", "Croatia", "Haiti",
                            "Hungary", "Indonesia", "Isle of Man", "India", "British Indian Ocean Territory", "Ireland", "Iran, Islamic Republic of",
                            "Iraq", "Iceland", "Israel", "Italy", "Jamaica", "Jersey", "Jordan", "Japan", "Kazakhstan", "Kenya", "Kyrgyzstan",
                            "Cambodia", "Kiribati", "Saint Kitts and Nevis", "Korea, Republic of", "Kuwait", "Lao People's Democratic Republic",
                            "Lebanon", "Liberia", "Libya", "Saint Lucia", "Liechtenstein", "Sri Lanka", "Lesotho", "Lithuania", "Luxembourg",
                            "Latvia", "Macao", "Saint Martin (French part)", "Morocco", "Monaco", "Moldova, Republic of", "Madagascar", "Maldives",
                            "Mexico", "Marshall Islands", "North Macedonia", "Mali", "Malta", "Myanmar", "Montenegro", "Mongolia",
                            "Northern Mariana Islands", "Mozambique", "Mauritania", "Montserrat", "Martinique", "Mauritius", "Malawi", "Malaysia",
                            "Mayotte", "Namibia", "New Caledonia", "Niger", "Norfolk Island", "Nigeria", "Nicaragua", "Niue", "Netherlands",
                            "Norway", "Nauru", "New Zealand", "Oman", "Pakistan", "Panama", "Pitcairn", "Peru", "Philippines", "Palau",
                            "Papua New Guinea", "Poland", "Puerto Rico", "Korea, Democratic People's Republic of", "Portugal", "Paraguay",
                            "Palestine, State of", "French Polynesia", "Qatar", "Réunion", "Romania", "Russian Federation", "Rwanda", "Saudi Arabia",
                            "Sudan", "Senegal", "Singapore", "South Georgia and the South Sandwich Islands", "Saint Helena, Ascension and Tristan da Cunha",
                            "Svalbard and Jan Mayen", "Solomon Islands", "Sierra Leone", "El Salvador", "San Marino", "Somalia",
                            "Saint Pierre and Miquelon", "Serbia", "South Sudan", "Sao Tome and Principe", "Suriname", "Slovakia", "Slovenia",
                            "Sweden", "Eswatini", "Sint Maarten (Dutch part)", "Seychelles", "Syrian Arab Republic", "Turks and Caicos Islands", "Chad",
                            "Togo", "Thailand", "Tajikistan", "Tokelau", "Turkmenistan", "Timor-Leste", "Tonga", "Trinidad and Tobago", "Tunisia",
                            "Türkiye", "Tuvalu", "Taiwan, Province of China", "Tanzania, United Republic of", "Uganda", "Ukraine",
                            "United States Minor Outlying Islands", "Uruguay", "United States", "Uzbekistan", "Holy See (Vatican City State)",
                            "Saint Vincent and the Grenadines", "Venezuela, Bolivarian Republic of", "Virgin Islands, British", "Virgin Islands, U.S.",
                            "Viet Nam", "Vanuatu", "Wallis and Futuna", "Samoa", "Yemen", "South Africa", "Zambia", "Zimbabwe"
                        ];
                    }

                    // Determine any previously saved selections.  Prefer the Angular scope if available.
                    let savedSelection = [];
                    if (scope && scope.local) {
                        if (Array.isArray(scope.local.countries) && scope.local.countries.length) {
                            savedSelection = scope.local.countries.slice();
                        } else if (scope.local.country) {
                            savedSelection = [scope.local.country];
                        }
                    } else {
                        if (Array.isArray(window.localCountries) && window.localCountries.length) {
                            savedSelection = window.localCountries.slice();
                        } else if (window.localCountry) {
                            savedSelection = [window.localCountry];
                        }
                    }

                    // If no saved selection, default to India if present; otherwise use the first item.
                    if (!savedSelection || savedSelection.length === 0) {
                        if (dataSrc.indexOf('India') !== -1) {
                            savedSelection = ['India'];
                        } else if (dataSrc.length > 0) {
                            savedSelection = [dataSrc[0]];
                        } else {
                            savedSelection = [];
                        }
                    }

                    /*
                     * Helper to update the local model and persist via saveLocal().
                     * This keeps the array of selected countries under local.countries and
                     * sets local.country to the first selected item for backward
                     * compatibility.  The selected value may be an object (with a
                     * `name` property) or a simple string; we normalise to the country
                     * name before persisting.
                     */
                    function persistSelection(selected) {
                        let selectionArray;
                        if (Array.isArray(selected)) {
                            selectionArray = selected.map(function(item) {
                                return (item && typeof item === 'object' && item.name) ? item.name : item;
                            });
                        } else if (selected) {
                            selectionArray = [ (selected && typeof selected === 'object' && selected.name) ? selected.name : selected ];
                        } else {
                            selectionArray = [];
                        }
                        if (scope) {
                            if (!scope.local) scope.local = {};
                            scope.local.countries = selectionArray.slice();
                            scope.local.country = selectionArray.length ? selectionArray[0] : '';
                            if (typeof scope.saveLocal === 'function') {
                                scope.saveLocal();
                            }
                            scope.$applyAsync();
                        } else {
                            window.localCountries = selectionArray.slice();
                            window.localCountry = selectionArray.length ? selectionArray[0] : '';
                        }
                    }

                    // Build a data source of objects with name, flag emoji and ISO code.
                    // Each item includes:
                    //   - `name`: the country name
                    //   - `flag`: a fallback emoji (from window.countryFlags) used only if no ISO code exists
                    //   - `code`: the ISO‑3166 alpha‑2 code (lowercase) used with Semantic UI's flag icons
                    //   - `display`: the plain country name (we avoid prepending the emoji here because
                    //               the actual icon will be rendered by the item template via <i class="flag xx"></i>)
                    const items = dataSrc.map(function(name) {
                        const flagEmoji = (window.countryFlags && window.countryFlags[name]) || '';
                        const isoCode = (window.countryIsoCodes && window.countryIsoCodes[name]) || '';
                        return {
                            name: name,
                            flag: flagEmoji,
                            code: isoCode,
                            display: name
                        };
                    });

                    // Convert the saved selection (array of names) into the
                    // corresponding objects from the items array.  If the
                    // selection cannot be resolved (e.g. name missing), leave it
                    // undefined so that the dropdown displays the default.
                    const selectedObjects = (savedSelection && savedSelection.length)
                        ? items.filter(function(item) { return savedSelection.indexOf(item.name) !== -1; })
                        : [];

                    // Define options for the DropDownBox.  For a single‑select
                    // configuration we bind the value to the selected country name
                    // (valueExpr) and provide a custom displayExpr to show the
                    // flag and name in the input.  The embedded dxList uses the
                    // same items array and a custom itemTemplate to render
                    // country flags.  When the selection changes we update the
                    // DropDownBox value and persist the chosen country via
                    // persistSelection().
                    const options = {
                        dataSource: items,
                        valueExpr: 'name',
                        displayExpr: function(item) {
                            if (!item) return '';
                            return item.display;
                        },
                        // Use the first saved selection as the initial value
                        value: (selectedObjects.length) ? selectedObjects[0].name : null,
                        placeholder: '',
                        contentTemplate: function(e, contentElement) {
                            const $listContainer = $('<div>');
                            new DevExpress.ui.dxList($listContainer.get(0), {
                                dataSource: items,
                                selectionMode: 'single',
                                // Provide the selected object in an array
                                selectedItems: selectedObjects,
                                searchEnabled: true,
                                searchMode: 'contains',
                                searchExpr: 'name',
                                searchEditorOptions: {
                                    placeholder: ''
                                },
                                showSelectionControls: false,
                                // Custom item template to render a real flag icon and name.
                                // We use Semantic UI's flag sprite by adding the ISO code as a class.
                                // When no ISO code is available, we fall back to rendering the emoji stored in
                                // itemData.flag within a simple <span>.  The .country-item class suppresses
                                // the generic pseudo‑icon defined in custom-styles.css.
                                itemTemplate: function(itemData, itemIndex, itemElement) {
                                    // Render the real flag icon when an ISO code is available.  If no code
                                    // exists for a given name we fall back to a generic Material Icons
                                    // flag glyph.  Emoji flags are no longer used to avoid mixing icon
                                    // styles.  The .country-item class suppresses the generic pseudo
                                    // element defined in custom-styles.css.
                                    let $icon;
                                    if (itemData.code) {
                                        $icon = $('<i>').addClass('flag').addClass(itemData.code);
                                    } else {
                                        // Use Material Icons 'flag' glyph as a fallback when no ISO code is available
                                        $icon = $('<span>').addClass('material-icons').text('flag');
                                    }
                                    const $name = $('<span>').addClass('country-name').text(itemData.name);
                                    $(itemElement).addClass('country-item');
                                    $(itemElement).empty().append($icon).append($name);
                                },
                                onSelectionChanged: function(args) {
                                    const selectedItems = args.component.option('selectedItems');
                                    const selectedObj = (Array.isArray(selectedItems) && selectedItems.length) ? selectedItems[0] : null;
                                    // Reflect selection in the DropDownBox value.
                                    e.component.option('value', selectedObj ? selectedObj.name : null);
                                    // Persist using the object (persistSelection will normalise to name)
                                    persistSelection(selectedObj);
                                    // Close the drop‑down after a selection is made.
                                    if (typeof e.component.close === 'function') {
                                        e.component.close();
                                    }
                                }
                            });
                            $(contentElement).append($listContainer);
                        },
                        onValueChanged: function(e) {
                            const val = e.value;
                            persistSelection(val);
                        }
                    };

                    // Instantiate the DropDownBox using DevExtreme if available; fall back to
                    // jQuery plugin method when appropriate.
                    if (typeof DevExpress !== 'undefined' && DevExpress.ui && DevExpress.ui.dxDropDownBox) {
                        new DevExpress.ui.dxDropDownBox(domEl, options);
                    } else if (typeof $(domEl).dxDropDownBox === 'function') {
                        $(domEl).dxDropDownBox(options);
                    } else {
                        console.warn('DevExtreme DropDownBox plugin not found; country list will not render');
                    }

                    // Persist the initial selection to storage so that default values are saved when
                    // none were previously provided.
                    persistSelection(savedSelection);
                } catch (initErr) {
                    console.warn('Error while initialising DevExtreme country dropdown', initErr);
                }
            }

            // Look for a country dropdown rendered at page load and initialise it.
            const $dropDown = $('#countryDropDown');
            if ($dropDown.length) {
                initializeCountryDropDown($dropDown.get(0));
            }

            // After attempting initialisation on any existing #countryDropDown, schedule
            // a fallback initialiser.  This runs periodically to detect when the
            // element is added to the DOM (e.g. via ng-include) and applies the
            // configuration.  Once the dropdown is created or after a maximum
            // number of attempts, the interval is cleared.
            try {
                var _plReinitAttempts = 0;
                var _plReinitMax = 20;
                var _plReinitInterval = setInterval(function() {
                    _plReinitAttempts++;
                    var navEl = document.getElementById('countryDropDown');
                    if (navEl && typeof $(navEl).dxDropDownBox === 'function') {
                        var isInitialized;
                        try {
                            isInitialized = !!$(navEl).data('dxDropDownBox');
                        } catch (errCheck) {
                            isInitialized = false;
                        }
                        if (!isInitialized) {
                            initializeCountryDropDown(navEl);
                        }
                        // Stop polling once the element exists (whether initialised now or previously).
                        clearInterval(_plReinitInterval);
                    } else if (_plReinitAttempts >= _plReinitMax) {
                        // Give up after max attempts if the element never appears.
                        clearInterval(_plReinitInterval);
                    }
                }, 500);
            } catch (_plErr) {
                console.warn('Failed to schedule fallback initialiser for country dropdown', _plErr);
            }
        });
    } catch (err) {
        console.warn('Failed to initialise DevExtreme country dropdown', err);
    }

})();
