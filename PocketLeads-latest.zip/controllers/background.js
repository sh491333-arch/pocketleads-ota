if (!(typeof document !== 'undefined' && typeof location !== 'undefined' && /^(chrome|kiwi|edge|brave|opera|moz)-extension:$/i.test(location.protocol) && !window.__plInProcessAndroid)) {
importScripts(chrome.runtime.getURL('/libs/result-query.js'));
importScripts(chrome.runtime.getURL('/libs/run-state.js'));
importScripts(chrome.runtime.getURL('/libs/request-journal.js'));
importScripts(chrome.runtime.getURL('/config/runtime.js'));
importScripts(chrome.runtime.getURL('/libs/account.js'));
importScripts(chrome.runtime.getURL('/libs/ghost-parser.js'));
importScripts(chrome.runtime.getURL('/libs/profile-tab.js'));
importScripts(chrome.runtime.getURL('/libs/chromeBox.js'))
importScripts(chrome.runtime.getURL('/controllers/localModel.js'))
importScripts(chrome.runtime.getURL('/libs/TaskManager.js'))
importScripts(chrome.runtime.getURL('/libs/deviceIdentity.js'))
importScripts(chrome.runtime.getURL('/controllers/TaskManagerContainer.js'))

// -------------------------------------------------------------------
// Ghost extraction uses one direct Place-ID navigation in hidden offscreen iframes.
// Do not fall back to visible Chrome tabs: failures are reported and the queue is resumable.
const GHOST_OFFSCREEN_PATH = 'offscreen.html';
let ghostOffscreenCreatePromise = null;
let ghostOffscreenEnsurePromise = null;
let ghostOffscreenEnsureGeneration = -1;
let ghostLifecycle = Promise.resolve();
function queueGhostLifecycle(task) {
    const operation = ghostLifecycle.then(task, task);
    ghostLifecycle = operation.catch(() => null);
    return operation;
}

async function hasGhostOffscreenDocument() {
    try {
        if (chrome.runtime && typeof chrome.runtime.getContexts === 'function') {
            const contexts = await chrome.runtime.getContexts({
                contextTypes: ['OFFSCREEN_DOCUMENT'],
                documentUrls: [chrome.runtime.getURL(GHOST_OFFSCREEN_PATH)]
            });
            return Array.isArray(contexts) && contexts.length > 0;
        }
    } catch (err) {}
    try {
        if (chrome.offscreen && typeof chrome.offscreen.hasDocument === 'function') {
            return await chrome.offscreen.hasDocument();
        }
    } catch (err) {}
    if (self.clients && self.clients.matchAll) {
        const clients = await self.clients.matchAll();
        return clients.some(c => c.url === chrome.runtime.getURL(GHOST_OFFSCREEN_PATH));
    }
    return false;
}

const GHOST_CONTENT_SCRIPT_ID = 'pocketleads-ghost-profile-frame';
const GHOST_MAP_MATCHES = [
    'https://www.google.com/maps*',
    'https://www.google.co.in/maps*',
    'https://maps.google.com/*',
    'https://maps.google.co.in/*'
];
let ghostContentScriptPromise = null;

async function ensureGhostContentScript() {
    if (!chrome.scripting || typeof chrome.scripting.registerContentScripts !== 'function') {
        throw new Error('Chrome scripting API is unavailable for Ghost Mode.');
    }
    if (ghostContentScriptPromise) return ghostContentScriptPromise;
    ghostContentScriptPromise = (async () => {
        try {
            const registered = await chrome.scripting.getRegisteredContentScripts({ ids: [GHOST_CONTENT_SCRIPT_ID] });
            const current = Array.isArray(registered) ? registered.find(item => item.id === GHOST_CONTENT_SCRIPT_ID) : null;
            if (current && JSON.stringify(current.js) === JSON.stringify(['libs/ghost-parser.js','ghost-profile-frame.js']) && current.runAt === 'document_start' && current.persistAcrossSessions === true && current.allFrames === true && JSON.stringify((current.matches || []).slice().sort()) === JSON.stringify(GHOST_MAP_MATCHES.slice().sort())) return;
            if (current) {
                try { await chrome.scripting.unregisterContentScripts({ ids: [GHOST_CONTENT_SCRIPT_ID] }); } catch (e) {}
            }
        } catch (err) {}
        try {
            await chrome.scripting.registerContentScripts([{
                id: GHOST_CONTENT_SCRIPT_ID,
                matches: GHOST_MAP_MATCHES,
                js: ['libs/ghost-parser.js', 'ghost-profile-frame.js'],
                runAt: 'document_start',
                allFrames: true,
                persistAcrossSessions: true
            }]);
        } catch (err) {
            if (!/already registered|duplicate/i.test(String(err && err.message || err))) throw err;
        }
    })().finally(() => { ghostContentScriptPromise = null; });
    return ghostContentScriptPromise;
}

async function ensureGhostOffscreenDocument() {
    const requestedGeneration = ghostRequestGeneration;
    await ensureGhostContentScript();
    if (requestedGeneration !== ghostRequestGeneration) throw new Error('Ghost Mode initialization cancelled.');
    // Hot path: once the hidden document exists, do not serialize every profile
    // through the lifecycle queue. That was a hidden source of 20-30s first-result
    // latency under a 60-place workload.
    if (await hasGhostOffscreenDocument()) return;
    if (ghostOffscreenEnsurePromise && ghostOffscreenEnsureGeneration === requestedGeneration) return ghostOffscreenEnsurePromise;
    const pendingEnsure = queueGhostLifecycle(async () => {
        if (requestedGeneration !== ghostRequestGeneration) throw new Error('Ghost Mode initialization cancelled.');
        if (await hasGhostOffscreenDocument()) return;
        if (requestedGeneration !== ghostRequestGeneration) throw new Error('Ghost Mode initialization cancelled.');
        if (!chrome.offscreen || typeof chrome.offscreen.createDocument !== 'function') {
            throw new Error('Chrome Offscreen API is unavailable. Please use Chrome 109 or newer.');
        }
        if (!ghostOffscreenCreatePromise) {
            ghostOffscreenCreatePromise = chrome.offscreen.createDocument({
                url: GHOST_OFFSCREEN_PATH,
                reasons: ['DOM_PARSER', 'DOM_SCRAPING', 'IFRAME_SCRIPTING'],
                justification: 'Run Google Maps profile DOM extraction in a hidden iframe without opening visible tabs.'
            }).finally(() => { ghostOffscreenCreatePromise = null; });
        }
        await ghostOffscreenCreatePromise;
    }).finally(() => {
        if (ghostOffscreenEnsurePromise === pendingEnsure) {
            ghostOffscreenEnsurePromise = null;
            ghostOffscreenEnsureGeneration = -1;
        }
    });
    ghostOffscreenEnsurePromise = pendingEnsure;
    ghostOffscreenEnsureGeneration = requestedGeneration;
    return pendingEnsure;
}

async function ghostMessage(message, timeoutMs=115000) {
    return new Promise((resolve, reject) => {
        const timer=setTimeout(()=>reject(new Error('Ghost Mode response timed out. Resume the saved queue.')),timeoutMs);
        chrome.runtime.sendMessage(Object.assign({target:'pocketleads_offscreen'},message), response => {
            clearTimeout(timer);
            const last = chrome.runtime.lastError;
            if (last || !response || !response.ok) {
                const error = new Error(last && last.message || response && response.error || 'Ghost Mode did not respond.');
                error.ghostAttemptsExhausted = !!(response && response.ghostAttemptsExhausted);
                reject(error);
            } else resolve(response);
        });
    });
}
let ghostRequestGeneration=0,ghostActiveRequests=0,ghostWaiters=[],ghostLegacyCleanupPromise=null,ghostLegacyCleanupDone=false;
const GHOST_PROFILE_CONCURRENCY=2;
const GHOST_TAB_MAX_URLS=50;
const activeGhostTabIds=new Set();
const ghostWorkerPool=[];
function canUseDirectPlaceTab(){
    return Boolean(typeof chrome!=="undefined"&&chrome&&chrome.tabs&&typeof chrome.tabs.create==="function"&&typeof chrome.tabs.remove==="function"&&chrome.scripting&&typeof chrome.scripting.executeScript==="function");
}
function wakeGhostWaiters(){
    while(ghostActiveRequests<GHOST_PROFILE_CONCURRENCY&&ghostWaiters.length){
        const waiter=ghostWaiters.shift();
        if(waiter.token!==ghostRequestGeneration){waiter.reject(new Error("Ghost Mode request cancelled."));continue;}
        ghostActiveRequests++;waiter.resolve();
    }
}
function acquireGhostSlot(token){
    if(token!==ghostRequestGeneration)return Promise.reject(new Error("Ghost Mode request cancelled."));
    if(ghostActiveRequests<GHOST_PROFILE_CONCURRENCY){ghostActiveRequests++;return Promise.resolve();}
    return new Promise((resolve,reject)=>ghostWaiters.push({token,resolve,reject}));
}
function releaseGhostSlot(){ghostActiveRequests=Math.max(0,ghostActiveRequests-1);wakeGhostWaiters();}
function cancelGhostWaiters(){for(const waiter of ghostWaiters.splice(0))waiter.reject(new Error("Ghost Mode request cancelled."));}
function createGhostTabSafe(createProps){
    return new Promise((resolve,reject)=>{
        try{
            let settled=false;
            const done=(tab,err)=>{
                if(settled)return;
                settled=true;
                if(err||!tab||!Number.isInteger(tab.id))reject(err||new Error("Unable to open background Google Maps profile tab."));
                else resolve(tab);
            };
            const maybe=chrome.tabs.create(createProps,tab=>{
                const err=chrome.runtime&&chrome.runtime.lastError?new Error(chrome.runtime.lastError.message||String(chrome.runtime.lastError)):null;
                done(tab,err);
            });
            if(maybe&&typeof maybe.then==="function")maybe.then(tab=>done(tab,null),err=>done(null,err));
        }catch(err){reject(err);}
    });
}
function updateGhostTabSafe(tabId,updateProps){
    return new Promise((resolve,reject)=>{
        if(!Number.isInteger(tabId)||tabId<=0||!chrome.tabs||typeof chrome.tabs.update!=="function")return resolve(null);
        try{
            let settled=false;
            const done=(tab,err)=>{
                if(settled)return;
                settled=true;
                if(err)reject(err);
                else resolve(tab||null);
            };
            const maybe=chrome.tabs.update(tabId,updateProps,tab=>{
                const err=chrome.runtime&&chrome.runtime.lastError?new Error(chrome.runtime.lastError.message||String(chrome.runtime.lastError)):null;
                done(tab,err);
            });
            if(maybe&&typeof maybe.then==="function")maybe.then(tab=>done(tab,null),err=>done(null,err));
        }catch(err){reject(err);}
    });
}
function getGhostTabSafe(tabId){
    return new Promise(resolve=>{
        if(!Number.isInteger(tabId)||tabId<=0||!chrome.tabs||typeof chrome.tabs.get!=="function")return resolve(null);
        try{
            let settled=false;
            const done=tab=>{if(!settled){settled=true;resolve(tab||null);}};
            const maybe=chrome.tabs.get(tabId,tab=>{
                const err=chrome.runtime&&chrome.runtime.lastError;
                done(err?null:(tab||null));
            });
            if(maybe&&typeof maybe.then==="function")maybe.then(done,()=>done(null));
        }catch(_){resolve(null);}
    });
}
function removeGhostTabSafe(tabId){
    if(!Number.isInteger(tabId)||tabId<=0)return Promise.resolve();
    activeGhostTabIds.delete(tabId);
    for(let i=ghostWorkerPool.length-1;i>=0;i--){
        if(ghostWorkerPool[i].tabId===tabId)ghostWorkerPool.splice(i,1);
    }
    if(typeof chrome==="undefined"||!chrome||!chrome.tabs||typeof chrome.tabs.remove!=="function")return Promise.resolve();
    return new Promise(resolve=>{
        try{
            let settled=false;
            const done=()=>{if(!settled){settled=true;resolve();}};
            const maybe=chrome.tabs.remove(tabId,()=>{
                try{void (chrome.runtime&&chrome.runtime.lastError);}catch(_){}
                done();
            });
            if(maybe&&typeof maybe.then==="function")maybe.then(done,done);
        }catch(_){resolve();}
    });
}
async function closeActiveGhostTabs(){
    const poolIds=ghostWorkerPool.splice(0).map(w=>w.tabId);
    const ids=[...new Set([...activeGhostTabIds,...poolIds])];
    activeGhostTabIds.clear();
    if(!ids.length)return;
    await Promise.allSettled(ids.map(removeGhostTabSafe));
}
function execInGhostTab(options){
    return new Promise(resolve=>{
        try{
            let settled=false;
            const done=res=>{if(!settled){settled=true;resolve(Array.isArray(res)?res:null);}};
            const maybe=chrome.scripting.executeScript(options,res=>{
                const err=chrome.runtime&&chrome.runtime.lastError;
                done(err?null:res);
            });
            if(maybe&&typeof maybe.then==="function")maybe.then(done,()=>done(null));
        }catch(_){resolve(null);}
    });
}
function unthrottleGhostTabMainWorld(){
    try{
        if(window.__plGhostUnthrottled)return;
        window.__plGhostUnthrottled=true;
        Object.defineProperty(document,"hidden",{configurable:true,get:()=>false});
        Object.defineProperty(document,"visibilityState",{configurable:true,get:()=>"visible"});
        document.hasFocus=()=>true;
        window.requestAnimationFrame=cb=>setTimeout(()=>{try{cb(performance.now());}catch(_){}},16);
        window.cancelAnimationFrame=id=>clearTimeout(id);
        window.open=()=>null;
        document.dispatchEvent(new Event("visibilitychange"));
    }catch(_){}
}
function prepareTabForNextPlaceUrl(nextUrl,nextPlaceId){
    try{
        window.__plTargetPlaceId=String(nextPlaceId||"");
        window.__plFirstTitleAt=0;
        window.__plConsentClicked=false;
        document.title="";
        document.querySelectorAll("h1.DUwDvf, .DUwDvf, [class*=\"fontHeadlineLarge\"], [data-attrid=\"title\"], div[role=\"main\"]").forEach(el=>{
            try{
                el.setAttribute("data-pl-stale","1");
                if(el.tagName==="H1"||el.classList.contains("DUwDvf"))el.textContent="";
            }catch(_){}
        });
        if(nextUrl)window.location.replace(nextUrl);
    }catch(_){}
}
async function acquireReusableGhostTab(url,placeId){
    let slotEntry=ghostWorkerPool.find(w=>!w.busy);
    if(slotEntry){
        slotEntry.busy=true;
        const existingTab=await getGhostTabSafe(slotEntry.tabId);
        if(!existingTab||existingTab.active){
            const staleId=slotEntry.tabId;
            activeGhostTabIds.delete(staleId);
            const idx=ghostWorkerPool.indexOf(slotEntry);
            if(idx>=0)ghostWorkerPool.splice(idx,1);
            slotEntry=null;
        }else if(slotEntry.count>=GHOST_TAB_MAX_URLS){
            // Rotate tab after 50 URLs: open new tab first, then close old tab immediately.
            const oldTabId=slotEntry.tabId;
            const freshTab=await createGhostTabSafe({url,active:false});
            activeGhostTabIds.add(freshTab.id);
            slotEntry.tabId=freshTab.id;
            slotEntry.count=1;
            activeGhostTabIds.delete(oldTabId);
            await removeGhostTabSafe(oldTabId);
            return {slotEntry,tabId:freshTab.id,reused:false};
        }else{
            // Reuse existing tab by replacing the URL in-place (no new tab created).
            slotEntry.count+=1;
            await execInGhostTab({target:{tabId:slotEntry.tabId},func:prepareTabForNextPlaceUrl,args:[url,placeId]});
            if(chrome.tabs&&typeof chrome.tabs.update==="function"){
                await updateGhostTabSafe(slotEntry.tabId,{url}).catch(()=>null);
            }
            return {slotEntry,tabId:slotEntry.tabId,reused:true};
        }
    }
    const tab=await createGhostTabSafe({url,active:false});
    activeGhostTabIds.add(tab.id);
    const createdEntry={tabId:tab.id,count:1,busy:true};
    ghostWorkerPool.push(createdEntry);
    return {slotEntry:createdEntry,tabId:tab.id,reused:false};
}
function probeGhostTabDom(payload){
    payload=payload||{};
    const text=v=>String(v||"").replace(/\s+/g," ").trim();
    const href=String(location&&location.href||"");
    if(!href||href==="about:blank"||/^chrome-error:/i.test(href))return {status:"loading"};
    const wantedId=String(payload.placeId||"").trim();
    if(wantedId&&href.includes("place_id:")&&!href.includes(encodeURIComponent(wantedId))&&!href.includes(wantedId)){
        return {status:"loading"};
    }
    if(document.querySelector("#captcha-form, iframe[src*=\"recaptcha\"]")||/\/sorry(?:\/|$)/i.test(String(location.pathname||""))){
        return {status:"blocked",error:"GOOGLE_ACCESS_BLOCKED: Google requires verification or CAPTCHA."};
    }
    const consentBtn=document.querySelector("form[action*=\"consent\"] button, button[aria-label*=\"Accept all\" i], button[aria-label*=\"Reject all\" i]");
    if(consentBtn&&!window.__plConsentClicked){
        window.__plConsentClicked=true;
        try{consentBtn.click();}catch(_){}
        return {status:"loading"};
    }
    const bodySample=text(document.body&&(document.body.innerText||document.body.textContent)||"").slice(0,25000);
    if(/unusual traffic from your computer network/i.test(bodySample)){
        return {status:"blocked",error:"GOOGLE_ACCESS_BLOCKED: Google detected unusual traffic."};
    }
    const first=(root,selectors)=>{
        if(!root||typeof root.querySelector!=="function")return null;
        for(const s of selectors){const n=root.querySelector(s);if(n)return n;}
        return null;
    };
    const nodeText=n=>text(n&&(n.getAttribute&&n.getAttribute("aria-label")||n.getAttribute&&n.getAttribute("title")||n.textContent));
    const genericTitle=v=>!v||/^(google|search|search results|google maps|explore|maps|results|before you continue to google|loading\.\.\.)$/i.test(v)||/^https?:\/\//i.test(v);
    const digitsOrPlus=v=>{
        const raw=text(v).replace(/^\s*(?:Phone|Telephone|Call)\s*:?\s*/i,"").replace(/^tel:/i,"").replace(/^phone:tel:/i,"");
        const m=raw.match(/\+?\d[\d\s().\-–—]{5,}\d/);
        return (m?m[0]:raw).replace(/(?!^\+)\D/g,"");
    };
    const extractPhone=n=>{
        if(!n)return "";
        const cands=[n.getAttribute&&n.getAttribute("data-item-id"),n.getAttribute&&n.getAttribute("aria-label"),n.getAttribute&&n.getAttribute("href"),n.getAttribute&&n.getAttribute("title"),nodeText(n),n.textContent];
        for(const c of cands){
            const d=digitsOrPlus(c);
            if(d.replace(/\D/g,"").length>=7)return d;
        }
        return "";
    };
    const unwrapWebsite=rawHref=>{
        const raw=text(rawHref);
        if(!raw)return "";
        try{
            const u=new URL(raw,"https://www.google.com");
            if(/^(?:www\.)?google\.(?:com|co\.in)$/i.test(u.hostname)&&u.pathname==="/url"){
                const q=u.searchParams.get("q")||u.searchParams.get("url")||"";
                if(q)return unwrapWebsite(q);
            }
            if(/^https?:$/.test(u.protocol)&&!/(^|\.)(google\.(com|co\.in)|gstatic\.com|googleusercontent\.com)$/i.test(u.hostname))return u.href;
        }catch(_){}
        return "";
    };
    const root=document.querySelector("div[role=\"main\"]:not([data-pl-stale=\"1\"])")||document.querySelector("div[role=\"main\"]")||document.body;
    if(!root)return {status:"loading"};
    const titleNode=first(root,["h1.DUwDvf:not([data-pl-stale=\"1\"])",".DUwDvf:not([data-pl-stale=\"1\"])","[class*=\"fontHeadlineLarge\"]:not([data-pl-stale=\"1\"])","[data-attrid=\"title\"]:not([data-pl-stale=\"1\"])","h1[aria-label]:not([data-pl-stale=\"1\"])","h1:not([data-pl-stale=\"1\"])"])||first(document,["h1.DUwDvf:not([data-pl-stale=\"1\"])",".DUwDvf:not([data-pl-stale=\"1\"])","[class*=\"fontHeadlineLarge\"]:not([data-pl-stale=\"1\"])","h1:not([data-pl-stale=\"1\"])"]);
    let companyName=nodeText(titleNode).replace(/\s*[-|–]\s*Google Maps\s*$/i,"").trim();
    if(genericTitle(companyName)){
        const docTitle=text(document.title).replace(/\s*[-|–]\s*Google Maps\s*$/i,"").trim();
        if(!genericTitle(docTitle)&&docTitle!==text(document.title))companyName=docTitle;
    }
    if(genericTitle(companyName)){
        if(window.PocketLeadsGhostParser&&typeof window.PocketLeadsGhostParser.fromHtml==="function"){
            try{
                const fallback=window.PocketLeadsGhostParser.fromHtml(document.documentElement.outerHTML,payload);
                if(fallback&&fallback.company_name)return {status:"ready",data:fallback};
            }catch(_){}
        }
        return {status:"loading"};
    }
    if(!window.__plFirstTitleAt)window.__plFirstTitleAt=Date.now();
    const titleWaitMs=Date.now()-window.__plFirstTitleAt;
    let address="";
    for(const sel of ["[data-item-id*=\"address\"]","[aria-label^=\"Address:\" i]","[data-tooltip*=\"Address\" i]","button[aria-label*=\"Address\" i]"]){
        for(const n of root.querySelectorAll(sel)){
            const val=nodeText(n).replace(/^Address\s*:?\s*/i,"").trim();
            if(val){address=val;break;}
        }
        if(address)break;
    }
    let phone="";
    for(const sel of ["[data-item-id*=\"phone\"]","a[href^=\"tel:\"]","[aria-label^=\"Phone:\" i]","[data-tooltip*=\"Phone\" i]","button[aria-label*=\"Phone\" i]","button[aria-label*=\"Call\" i]"]){
        for(const n of root.querySelectorAll(sel)){
            const p=extractPhone(n);
            if(p){phone=p;break;}
        }
        if(phone)break;
    }
    let website="";
    for(const sel of ["a[data-item-id*=\"authority\"]","a[aria-label*=\"Website\" i]","a[data-tooltip*=\"Website\" i]","[data-item-id*=\"authority\"] a[href]"]){
        for(const n of root.querySelectorAll(sel)){
            const w=unwrapWebsite(n.getAttribute("href")||n.href||"");
            if(w){website=w;break;}
        }
        if(website)break;
    }
    const ratingNode=first(root,["[aria-label*=\"stars\" i]","[aria-label*=\"Rated\" i]","[aria-label*=\"rating\" i]",".F7nice span[aria-hidden=\"true\"]"]);
    const reviewNode=first(root,["[aria-label*=\"reviews\" i]","[data-item-id*=\"review\"]",".F7nice span[aria-label*=\"review\" i]"]);
    const categoryNode=first(document,["button[jsaction*=\"category\"]","button.DkEaL","[data-attrid=\"kc:/local:alt_name\"]","[data-item-id*=\"category\"]"]);
    const statusNode=first(document,["[aria-label*=\"Open\" i]","[aria-label*=\"Closed\" i]","[data-item-id*=\"hours\"]"]);
    const hasDirections=!!first(root,["button[aria-label*=\"Directions\" i]","[data-item-id*=\"directions\"]"]);
    const ratingText=nodeText(ratingNode);
    const reviewText=nodeText(reviewNode);
    const statusText=nodeText(statusNode);
    const category=categoryNode?nodeText(categoryNode):"";
    const reviewMatch=ratingText.match(/[0-9]+(?:\.[0-9]+)?/);
    const totalReviewsMatch=text(reviewText).match(/[0-9][0-9,\.\s]{0,20}/);
    const totalReviews=totalReviewsMatch?totalReviewsMatch[0].replace(/[^0-9]/g,""):"";
    const hasCoreDetail=Boolean(address||phone||website);
    const hasSecondaryDetail=Boolean(category||reviewMatch||totalReviews||hasDirections);
    if(!hasCoreDetail&&!hasSecondaryDetail&&titleWaitMs<900){
        return {status:"loading"};
    }
    if(hasCoreDetail&&!(phone&&website)&&titleWaitMs<150){
        return {status:"loading"};
    }
    if(!hasCoreDetail&&hasSecondaryDetail&&titleWaitMs<450){
        return {status:"loading"};
    }
    const foundEmails=[];
    try{
        root.querySelectorAll("a[href^=\"mailto:\"]").forEach(n=>{
            const e=String(n.getAttribute("href")||"").replace(/^mailto:/i,"").split("?")[0].trim().toLowerCase();
            if(e&&e.includes("@")&&!foundEmails.includes(e))foundEmails.push(e);
        });
    }catch(_){}
    const pincodeMatch=address.match(/\b[1-9][0-9]{5}\b/);
    const pincode=pincodeMatch?pincodeMatch[0]:"";
    const parts=address.split(",").map(text).filter(Boolean);
    const regionParts=parts.map(p=>p.replace(/\b[1-9][0-9]{5}\b/g,"").trim()).filter(Boolean);
    if(/^(india|bharat)$/i.test(regionParts[regionParts.length-1]||""))regionParts.pop();
    const withoutPin=address.replace(/\b[1-9][0-9]{5}\b/g,"").replace(/\s*,\s*$/,"").trim();
    const placeId=String(payload.placeId||"").trim();
    const mapLink="https://www.google.com/maps/place/?q=place_id:"+encodeURIComponent(placeId);
    return {
        status:"ready",
        data:{
            company_name:companyName,
            website,
            phone,
            phone_number:phone,
            address:withoutPin,
            city:regionParts.length>1?regionParts[regionParts.length-2]:"",
            state:regionParts.length>1?regionParts[regionParts.length-1]:"",
            pincode,
            review:reviewMatch?reviewMatch[0]:"",
            total_reviews:totalReviews,
            category,
            categories:category,
            email_1:foundEmails.slice(0,5).join(", "),
            status:/temporar(?:ily)?\s+closed/i.test(statusText)?"Temporarily Closed":(/closed/i.test(statusText)?"Closed":(/open/i.test(statusText)?"Open":"Unknown")),
            place_id:placeId,
            cid:placeId,
            keyword:String(payload.keyword||""),
            location:String(payload.location||""),
            map_link:mapLink,
            source:"google_maps_place_id_profile_ghost",
            _ghost_strategy:"direct_place_tab_reused"
        }
    };
}
async function scrapeDirectPlaceTab(payload,token){
    const placeId=String(payload&&payload.placeId||"").trim();
    if(!placeId)throw new Error("Missing Google Place ID.");
    if(token!==ghostRequestGeneration)throw new Error("Ghost Mode request cancelled.");
    // Strictly 1 direct Place-ID URL attempt. Reuse worker tab up to 50 URLs, then rotate.
    const url="https://www.google.com/maps/place/?q=place_id:"+encodeURIComponent(placeId);
    const timeoutMs=Math.max(1500,Math.min(18000,Number(payload&&payload.timeoutMs)||14000));
    const startedAt=Date.now();
    let acquired=null;
    let tabHealthy=false;
    try{
        acquired=await acquireReusableGhostTab(url,placeId);
        const tabId=acquired.tabId;
        let unthrottled=false;
        while(Date.now()-startedAt<timeoutMs){
            if(token!==ghostRequestGeneration)throw new Error("Ghost Mode request cancelled.");
            const currentTab=await getGhostTabSafe(tabId);
            if(!currentTab)throw new Error("Google Maps profile tab closed before details finished loading.");
            if(/^https:\/\//i.test(String(currentTab.url||""))){
                if(!unthrottled){
                    unthrottled=true;
                    void execInGhostTab({target:{tabId},world:"MAIN",func:unthrottleGhostTabMainWorld});
                }
                const results=await execInGhostTab({target:{tabId},func:probeGhostTabDom,args:[payload]});
                const res=results&&results[0]&&results[0].result;
                if(res){
                    if(res.status==="blocked")throw new Error(res.error||"GOOGLE_ACCESS_BLOCKED: Google requires consent or verification.");
                    if(res.status==="ready"&&res.data&&String(res.data.company_name||"").trim()){
                        res.data._dom_elapsed_ms=Math.max(1,Date.now()-startedAt);
                        tabHealthy=true;
                        return res.data;
                    }
                }
            }
            await new Promise(r=>setTimeout(r,60));
        }
        throw new Error("Google Maps business details did not appear within "+timeoutMs+" ms.");
    }finally{
        if(acquired&&acquired.slotEntry){
            if(!tabHealthy||token!==ghostRequestGeneration){
                await removeGhostTabSafe(acquired.tabId);
            }else{
                acquired.slotEntry.busy=false;
            }
        }
    }
}
async function cleanupLegacyOwnedProfileTab(force){
    if(ghostLegacyCleanupDone&&!force)return;
    if(ghostLegacyCleanupPromise)return ghostLegacyCleanupPromise;
    ghostLegacyCleanupPromise=Promise.resolve().then(async()=>{
        // Close recorded and unrecorded inactive about:blank/Maps profile tabs.
        if(self.PocketLeadsProfileTab&&typeof self.PocketLeadsProfileTab.close==="function")await self.PocketLeadsProfileTab.close();
        ghostLegacyCleanupDone=true;
    }).finally(()=>{ghostLegacyCleanupPromise=null;});
    return ghostLegacyCleanupPromise;
}
async function requestGhostProfile(payload){
    payload=payload||{};
    const token=ghostRequestGeneration;
    await acquireGhostSlot(token);
    try{
        if(token!==ghostRequestGeneration)throw new Error("Ghost Mode request cancelled.");
        await cleanupLegacyOwnedProfileTab();
        if(token!==ghostRequestGeneration)throw new Error("Ghost Mode request cancelled.");
        if(canUseDirectPlaceTab()){
            const row=await scrapeDirectPlaceTab({...payload,timeoutMs:5500},token);
            if(token!==ghostRequestGeneration)throw new Error("Ghost Mode request cancelled.");
            if(!String(row&&row.company_name||"").trim())throw new Error("Ghost Mode single attempt returned no business name.");
            return row;
        }
        await ensureGhostOffscreenDocument();
        if(token!==ghostRequestGeneration)throw new Error("Ghost Mode request cancelled.");
        // One direct Place-ID URL and one navigation attempt in offscreen harness.
        const response=await ghostMessage({action:"PL_GHOST_SCRAPE_PROFILE",payload:{...payload,timeoutMs:8000}},9500);
        if(token!==ghostRequestGeneration)throw new Error("Ghost Mode request cancelled.");
        const row=response&&response.data||{};
        if(!String(row.company_name||"").trim())throw new Error("Ghost Mode single attempt returned no business name.");
        return row;
    }catch(error){
        if(error&&typeof error==="object")error.ghostAttemptsExhausted=true;
        throw error;
    }finally{releaseGhostSlot();}
}
async function prewarmGhostProfileEngine(){
    await cleanupLegacyOwnedProfileTab();
    if(!canUseDirectPlaceTab()){
        await ensureGhostOffscreenDocument();
    }
    return true;
}
function closeGhostOffscreenDocument(){
    ghostRequestGeneration++;ghostOffscreenEnsurePromise=null;ghostOffscreenEnsureGeneration=-1;cancelGhostWaiters();
    return Promise.all([closeActiveGhostTabs(),destroyGhostOffscreenDocument(),self.PocketLeadsProfileTab?.close().catch(()=>null)]).then(()=>{ghostLegacyCleanupDone=true;});
}
async function destroyGhostOffscreenDocument(){
    return queueGhostLifecycle(async()=>{
        try{
            if(chrome.offscreen&&typeof chrome.offscreen.closeDocument==="function"&&await hasGhostOffscreenDocument()){
                await ghostMessage({action:"PL_GHOST_CANCEL"},2500).catch(()=>null);
                await chrome.offscreen.closeDocument();
            }
        }catch(err){console.warn("Ghost Mode offscreen cleanup failed",err);}
    });
}
self.PocketLeadsGhostMode={
    request:requestGhostProfile,
    prewarm:prewarmGhostProfileEngine,
    close:closeGhostOffscreenDocument,
    cleanupTabs:()=>cleanupLegacyOwnedProfileTab(true),
    activeTabIds:activeGhostTabIds,
    isActiveTab:id=>activeGhostTabIds.has(Number(id)),
    getPoolSize:()=>ghostWorkerPool.length
};

/*
 * Global unhandledrejection handler
 *
 * In Manifest V3 service workers, unhandled promise rejections from
 * asynchronous Chrome API calls (e.g. chrome.runtime.sendMessage)
 * surface as uncaught errors in the console, even when callbacks
 * are provided.  When a message has no listener, Chrome rejects
 * the promise with an error like "Could not establish connection. Receiving
 * end does not exist".  To prevent these from surfacing in the
 * console and disrupting the user experience, install a global
 * unhandledrejection handler.  When the rejection reason indicates
 * a missing receiver we suppress the error via event.preventDefault().
 * For other unhandled rejections we still log a warning so unexpected
 * failures can be diagnosed.
 */
try {
    self.addEventListener('unhandledrejection', function(event) {
        try {
            const reason = event && event.reason ? String(event.reason) : '';
            if (reason.includes('Could not establish connection') || reason.includes('Receiving end does not exist')) {
                // Suppress unhandled promise rejection errors when no receiver exists
                event.preventDefault();
                return;
            }
            // Log other unhandled rejections for debugging
            console.warn('Unhandled promise rejection in background context:', reason);
        } catch (unhandledErr) {
            // If anything goes wrong while handling, suppress the rejection
            event.preventDefault();
        }
    });
} catch (e) {
    // Ignore inability to attach listener
}

/*
 * -------------------------------------------------------------------
 * Manifest V3 compatibility shim for background context
 *
 * The legacy chromeBox helper library (libs/chromeBox.js) calls
 * `chrome.extension.getBackgroundPage()` to obtain a reference to
 * the extension's background page.  In Manifest V3 there is no
 * persistent background page – instead, service workers are used.
 * Attempting to call getBackgroundPage in this environment throws
 * an "Extension context invalidated" error.  Previously, we patched
 * this in content scripts via libs/safeBg.js and controllers/content.js,
 * however the error can still surface when chromeBox is loaded via
 * importScripts() in this background service worker.  To ensure the
 * function does not throw, we wrap both chrome.extension.getBackgroundPage
 * and $box.getBackgroundPage in a try/catch here.  If an exception is
 * thrown we return undefined instead of propagating the error.
 */
try {
    // Patch the low‑level chrome API if present.  Wrap the original
    // getBackgroundPage to swallow MV3 errors and return undefined.
    if (chrome && chrome.extension && typeof chrome.extension.getBackgroundPage === 'function') {
        const __origGetBg = chrome.extension.getBackgroundPage;
        chrome.extension.getBackgroundPage = function(...args) {
            try {
                return __origGetBg.apply(this, args);
            } catch (err) {
                // In MV3 there is no background page; suppress the error
                return undefined;
            }
        };
    }
    // Patch the chromeBox helper if loaded.  $box is defined by
    // libs/chromeBox.js and exposes a getBackgroundPage() method that
    // forwards to chrome.extension.getBackgroundPage().  Wrap it to
    // prevent uncaught exceptions in the service worker.
    if (typeof $box !== 'undefined' && $box && typeof $box.getBackgroundPage === 'function') {
        const __origBoxGetBg = $box.getBackgroundPage;
        $box.getBackgroundPage = function() {
            try {
                return __origBoxGetBg();
            } catch (err) {
                return undefined;
            }
        };
    }
} catch (err) {
    // Ignore any errors during patching
}

let retryCount = 0;
const MAX_RETRIES = 3;

// Flag to ensure we only send a single completion notification per scraping
// session. Multiple parts of the extension can emit 'scraping_complete'
// messages; this prevents duplicate notifications and repeated tab cleanup.
let scrapingCompleteNotified = false;

// -------------------------------------------------------------------
// WA Number Check – single‑tab bulk checking
//
// This implementation mirrors the behaviour of the standalone WA
// number checker extension but operates entirely within the
// background service worker using chrome.scripting.executeScript.
// Only one WhatsApp Web tab is used for all checks.  Numbers are
// processed sequentially at a fixed rate (WA_RATE_MS).  Results are
// sent back to the dashboard as they are obtained along with
// progress information.  The user can cancel a run at any time.

// Delay between checks in milliseconds.  Reducing the delay from
// 2 seconds to 500 milliseconds improves the overall speed of
// bulk WhatsApp number checks.  A shorter delay means the next
// number is processed sooner after the previous result completes.
// Reduce the interval between consecutive WhatsApp checks to speed up large
// batches.  Previously each number was processed every 500 ms; lowering
// this to 200 ms reduces total processing time for hundreds of numbers
// while still spacing requests enough to avoid overloading WhatsApp.
// Reduce the delay between consecutive WhatsApp checks from 200 ms to 100 ms.
// This shortens the total processing time for large batches while still
// leaving a small gap between requests to avoid overloading WhatsApp.
// Further reduce the delay between WhatsApp checks to 80 ms.  This
// accelerates bulk lookups while still leaving a short pause
// between requests.  If you experience throttling you can increase
// this value slightly.
const WA_RATE_MS = 80;
// Additional delay (in milliseconds) before processing the first number in a
// WhatsApp number check run.  This compensates for WhatsApp Web taking
// several seconds to initialise its internal modules after login.  Without
// this delay the first lookup often returns UNKNOWN because the API is
// not yet ready.  Subsequent lookups use the normal rate defined by
// WA_RATE_MS.  Adjust this value if the first result still fails.
// Increase this delay to 7000ms (7 seconds) to allow WhatsApp to fully
// initialise.  User feedback indicated that the first result was
// consistently incorrect with shorter delays.
// Shorten the initial delay before the first WhatsApp lookup.  Allow
// WhatsApp Web a few seconds to initialise its internal modules, but
// reduce the wait from 7000 ms to 3000 ms to improve responsiveness.
// Shorten the initial delay before the first WhatsApp lookup.  A
// two‑second pause gives WhatsApp Web enough time to initialise its
// modules after login, but improves responsiveness compared to a
// three‑second delay.
const WA_FIRST_DELAY_MS = 2000;

// Maximum time (in milliseconds) to wait for the user to log in to
// WhatsApp Web before aborting a number check run.  Reduce this
// timeout to one minute to avoid long delays before checks begin.
// Reduce the login timeout from one minute to thirty seconds.  This
// prevents long waits if the user forgets to log in; the run will
// abort sooner and return control to the user.
const WA_LOGIN_TIMEOUT_MS = 30000;

// Interval (in milliseconds) between successive login status polls
// while waiting for the user to log in.  Poll more frequently to
// detect login sooner.  Two seconds balances responsiveness and
// overhead.  Reduce this to one second to further shorten the
// initial wait time.
// Poll login status every 500 ms instead of every second.  More
// frequent polling detects login sooner without significant overhead.
const WA_LOGIN_POLL_MS = 500;

// True while a WA bulk check is running.
let waChecking = false;
// Identifier of the current WA tab used for checks.  This is reused
// across runs until explicitly closed or replaced.
let waTabId = null;
// Queue of pending numbers to check.  Each entry has the form
// { number: '<digits>', rowId: <index> }.
let waQueue = [];
// Total numbers to process and how many have completed.  These
// values are updated for each run and sent back to the dashboard.
let waTotalCount = 0;
let waFinishedCount = 0;
// Flag set when the user requests cancellation.  When true the
// queue will not continue once the current number finishes.
let waStopRequested = false;

// ID of the tab from which the current WA check was initiated.  After
// reloading and focusing the WhatsApp tab we will return focus to this
// tab.  This helps ensure that the WhatsApp page finishes initialising
// while keeping the dashboard visible.  Reset to null when the run
// completes or is cancelled.
let waReturnTabId = null;

// Track whether the page bridge script has been injected into a
// given tab.  Using a map keyed by tabId avoids repeated injections
// when reusing the same WhatsApp tab across runs.  The bridge
// (whatsapp/pageBridge.js) exposes a simple API via postMessage
// allowing the content script to query WhatsApp contact existence
// through the internal WPP library.  Without injection the
// executeWaCheck function will fall back to returning UNKNOWN.
const waScriptLoadedForTab = {};

// Track whether the WhatsApp tab has been focused at least once.  In
// previous versions we only focused the tab on the first run to
// prevent repeated flashes.  However user feedback indicated that
// clicking the WA number check button should always switch to the
// WhatsApp tab so the user can log in immediately.  We retain the
// variable for future use but no longer use it to gate focusing.
let waHasFocused = false;

// Flag set when the current WA run was cancelled by the user.  When true
// finishWaSession() will send a wa_check_cancelled message instead of
// wa_check_complete.  This is reset at the start of each run and when
// finishing.
let waCancelled = false;

// Flag set when a WhatsApp login attempt fails.  When true
// finishWaSession() suppresses any completion or cancellation
// notifications.  This flag is reset at the start of each run and
// after the session finishes.  Without this guard the UI would
// incorrectly display a "completed" notification after a login
// failure.
let waLoginFailed = false;

// When a WhatsApp number check run is cancelled by the user we store
// the number of completed lookups in waResumeIndex.  On the next
// run we skip this many entries from the incoming list so the user
// can resume where they left off instead of starting over.  This
// value is reset after a successful run or when a login failure occurs.
let waResumeIndex = 0;

// Track the number of lookup attempts for each entry (number/rowId)
// during a single WhatsApp check run. When a lookup returns
// UNKNOWN (i.e. a blank status) we requeue the number up to a
// controlled limit (three total attempts) before marking it as
// NOT_REGISTERED. The key used here combines the normalised phone
// number and the row index to uniquely identify each row. This
// object is reset at the start of each run.
let waAttemptCounts = {};

/**
 * Inject the WhatsApp page bridge into the specified tab.  The
 * bridge defines a page‑context handler (window.message listener)
 * that processes contact existence queries forwarded by the
 * extension's content script.  Injection occurs only once per tab
 * and is idempotent.  If injection fails (due to CSP or other
 * restrictions) the subsequent checks will fall back to returning
 * UNKNOWN.
 *
 * @param {number} tabId The ID of the WhatsApp Web tab.
 * @param {function():void} cb Callback invoked after injection or
 *        immediately if already injected.
 */
function injectWaScript(tabId, cb) {
    // In this version of the extension, the WhatsApp helper scripts
    // (wa.js, api.js and pageBridge.js) are injected by the content
    // script itself via dynamic <script> tags.  We therefore do not
    // perform any programmatic injection from the background.  We
    // simply mark the script as loaded for this tab and proceed.
    try {
        if (!waScriptLoadedForTab[tabId]) {
            waScriptLoadedForTab[tabId] = true;
        }
    } catch (err) {
        // ignore assignment errors
    }
    try {
        cb();
    } catch (ignore) {}
}

/**
 * Poll the content script in the specified tab to determine whether
 * the user is logged into WhatsApp Web.  This repeatedly sends a
 * 'checkLogin' message via chrome.tabs.sendMessage until either
 * a logged‑in state is detected, the timeout elapses or a stop
 * request is made.  The callback receives true on success and
 * false on failure or timeout.
 *
 * @param {number} tabId The ID of the WhatsApp Web tab
 * @param {function(boolean):void} cb Callback invoked with login result
 */
function waitForLogin(tabId, cb) {
    const start = Date.now();
    function poll() {
        // Abort if the run has been cancelled or service worker state reset
        if (!waChecking || waStopRequested) {
            cb(false);
            return;
        }
        try {
            chrome.tabs.sendMessage(tabId, { action: 'checkLogin' }, function(response) {
                if (chrome.runtime.lastError) {
                    // If the content script hasn't loaded yet or other error
                    if (Date.now() - start >= WA_LOGIN_TIMEOUT_MS) {
                        cb(false);
                        return;
                    }
                    setTimeout(poll, WA_LOGIN_POLL_MS);
                    return;
                }
                try {
                    // If the content script explicitly reports loggedIn true, succeed.
                    if (response && response.loggedIn === true) {
                        cb(true);
                        return;
                    }
                    // If the response explicitly reports loggedIn false, do not abort
                    // immediately.  Some builds of WhatsApp Web expose contact APIs
                    // before authentication and our pageBridge may return loggedIn: false
                    // temporarily while initialising.  Continue polling until either
                    // loggedIn becomes true or the timeout elapses.
                    if (response && response.loggedIn === false) {
                        // fall through to continue polling
                    }
                } catch (err) {
                    // ignore malformed response
                }
                // Continue polling until timeout if no definitive answer
                if (Date.now() - start >= WA_LOGIN_TIMEOUT_MS) {
                    cb(false);
                    return;
                }
                setTimeout(poll, WA_LOGIN_POLL_MS);
            });
        } catch (e) {
            // On synchronous errors treat as failure after timeout
            if (Date.now() - start >= WA_LOGIN_TIMEOUT_MS) {
                cb(false);
                return;
            }
            setTimeout(poll, WA_LOGIN_POLL_MS);
        }
    }
    poll();
}

/**
 * Find or create a WhatsApp Web tab for running checks.  If a tab
 * already exists it is reused; otherwise a new inactive tab is
 * created.  The provided callback is invoked with the tab id when
 * ready.  On failure (e.g. tab creation error) the callback is
 * invoked with null.
 *
 * @param {function(number|null):void} cb
 */
function ensureWaTab(cb) {
    try {
        // If we already have a tab id, verify that it still exists.
        if (waTabId !== null) {
            chrome.tabs.get(waTabId, function(tab) {
                if (chrome.runtime.lastError || !tab) {
                    waTabId = null;
                    createTab(cb);
                } else {
                    // Existing tab is valid
                    cb(waTabId);
                }
            });
            return;
        }
    } catch (e) {
        // fall through to createTab
    }
    // If no existing waTabId, attempt to find an already open WhatsApp
    // tab before creating a new one.  This prevents opening multiple
    // WhatsApp windows when the user already has one logged in.
    try {
        chrome.tabs.query({ url: ['https://web.whatsapp.com/*', 'https://*.whatsapp.com/*'] }, function(tabs) {
            if (chrome.runtime.lastError) {
                // On error just create a fresh tab
                createTab(cb);
                return;
            }
            if (Array.isArray(tabs) && tabs.length > 0) {
                // Use the first existing WhatsApp tab
                try {
                    waTabId = tabs[0].id;
                } catch (e) {
                    waTabId = null;
                }
                if (waTabId !== null) {
                    cb(waTabId);
                    return;
                }
            }
            // No existing tab found, create new
            createTab(cb);
        });
    } catch (err) {
        createTab(cb);
    }
}

function createTab(cb) {
    try {
        chrome.tabs.create({ url: 'https://web.whatsapp.com', active: false }, function(tab) {
            if (tab && tab.id) {
                waTabId = tab.id;
                cb(waTabId);
            } else {
                cb(null);
            }
        });
    } catch (err) {
        cb(null);
    }
}

/**
 * Execute a WhatsApp number check within the page context using
 * chrome.scripting.executeScript.  The provided callback receives
 * the status string ('REGISTERED', 'NOT_REGISTERED' or 'UNKNOWN').
 * Errors are caught and result in 'UNKNOWN'.
 *
 * @param {string} number Normalised phone number (digits only)
 * @param {function(string):void} cb
 */
function executeWaCheck(number, cb) {
    try {
        // Ask the content script in the WhatsApp tab to check this
        // number.  The content script forwards the request to the
        // page bridge, and the response contains an array of results.
        chrome.tabs.sendMessage(waTabId, { action: 'checkPhones', numbers: [number] }, function(response) {
            let status = 'UNKNOWN';
            try {
                if (chrome.runtime.lastError || !response || !Array.isArray(response.results) || response.results.length === 0) {
                    status = 'UNKNOWN';
                } else {
                    const res = response.results[0];
                    // If the result includes an error flag then the lookup did
                    // not succeed (e.g. the user is not logged in or the
                    // page script was not injected).  In this case treat the
                    // status as UNKNOWN so the dashboard leaves the status
                    // blank instead of marking it as NOT_REGISTERED.
                    if (res && res.error) {
                        status = 'UNKNOWN';
                    } else if (res && typeof res.exists === 'boolean') {
                        status = res.exists ? 'REGISTERED' : 'NOT_REGISTERED';
                    } else {
                        status = 'UNKNOWN';
                    }
                }
            } catch (err) {
                status = 'UNKNOWN';
            }
            try { cb(status); } catch (ignore) {}
        });
    } catch (err) {
        try { cb('UNKNOWN'); } catch (ignore) {}
    }
}

/**
 * Run through the queue of pending numbers.  After each number
 * completes we update the progress counters, send the result to the
 * dashboard and schedule the next iteration after WA_RATE_MS.  If
 * the user has requested cancellation or the queue is empty the
 * session is finished and a completion message is dispatched.
 */
function runWaQueue() {
    // If cancelled or no items remain, finish
    if (!waChecking || waStopRequested || waQueue.length === 0) {
        finishWaSession();
        return;
    }
    const item = waQueue.shift();
    const number = String(item.number || '').replace(/\D/g, '');
    const rowId = item.rowId;
    // Determine delay for this lookup.  The first lookup uses
    // WA_FIRST_DELAY_MS to allow WhatsApp to finish initialising.  Subsequent
    // lookups proceed immediately.
    const initialDelay = (waFinishedCount === 0 ? WA_FIRST_DELAY_MS : 0);
    setTimeout(() => {
        executeWaCheck(number, (status) => {
            // Decide whether to requeue this number based on the returned status.
            let finalStatus = status;
            let requeue = false;
            try {
                // Normalise the returned status.  Treat blanks (empty string, null or undefined)
                // and the literal 'UNKNOWN' (case‑insensitive) as unresolved.  Any other
                // status is considered final.  A blank status occurs when the WhatsApp
                // content script fails to return a value or returns an empty string.
                let statNorm = '';
                if (typeof status === 'string') {
                    statNorm = status.trim().toUpperCase();
                } else if (status && typeof status === 'object' && status.status) {
                    // In case the API returns an object with a status field
                    statNorm = String(status.status).trim().toUpperCase();
                }
                // Determine unresolved statuses: either no string returned or explicitly 'UNKNOWN'
                if (!statNorm || statNorm === 'UNKNOWN') {
                    // Unique key combines normalised number and row index
                    const key = number + '_' + rowId;
                    const attempts = waAttemptCounts[key] || 0;
                    if (attempts < 2) {
                        // Increment attempt count and mark for requeue
                        waAttemptCounts[key] = attempts + 1;
                        requeue = true;
                    } else {
                        // After three total attempts (initial + two retries) mark as NOT_REGISTERED
                        finalStatus = 'NOT_REGISTERED';
                    }
                }
            } catch (attemptErr) {
                // On any error treat as unknown and requeue once
                try {
                    const key = number + '_' + rowId;
                    waAttemptCounts[key] = (waAttemptCounts[key] || 0) + 1;
                    requeue = true;
                } catch (ignore) {}
            }
            // Increment finished count for progress tracking
            waFinishedCount += 1;
            // Send update to the dashboard including progress and the final status
            try {
                chrome.runtime.sendMessage({ action: 'wa_check_update', number: number, rowId: rowId, status: finalStatus, finished: waFinishedCount, total: waTotalCount }, () => {
                    void chrome.runtime.lastError;
                });
            } catch (e) {}
            // If stop was requested, finish immediately
            if (waStopRequested) {
                finishWaSession();
                return;
            }
            // Requeue unresolved numbers at the front of the queue to prioritise them
            if (requeue) {
                try {
                    waQueue.unshift(item);
                } catch (err) {
                    waQueue.push(item);
                }
            }
            // If queue is empty after processing, finish the session
            if (waQueue.length === 0) {
                finishWaSession();
                return;
            }
            // Otherwise process the next number after the configured rate
            setTimeout(() => {
                runWaQueue();
            }, WA_RATE_MS);
        });
    }, initialDelay);
}

/**
 * Clean up after a WA bulk run completes or is cancelled.  This
 * resets state variables and notifies the dashboard that the run is
 * finished.  The WhatsApp tab is left open to allow the user to
 * remain logged in across runs.  If desired the tab could be
 * removed here.
 */
function finishWaSession() {
    const finished = waFinishedCount;
    const total = waTotalCount;
    // Copy the finished/total counts before resetting state variables
    waChecking = false;
    waStopRequested = false;
    // Always reset the resume index on finish.  We intentionally
    // disregard any previous progress so that subsequent runs always
    // start from the first unresolved number.  This ensures that
    // numbers at the top of the dataset are rechecked promptly rather
    // than being skipped due to earlier runs.
    waResumeIndex = 0;
    waQueue = [];
    waTotalCount = 0;
    waFinishedCount = 0;
    // Clear the return tab reference so that subsequent runs do not
    // attempt to refocus to an outdated tab.  This variable is set
    // when a new WA run starts and remains valid only for the
    // duration of that run.
    waReturnTabId = null;
    // Optionally close the WA tab on completion or cancellation.
    // Leave it open so the user remains logged in.  Uncomment the
    // following lines to close the tab automatically:
    // try {
    //     if (waTabId !== null) {
    //         chrome.tabs.remove(waTabId, () => {});
    //         waTabId = null;
    //     }
    // } catch (err) {}
    try {
        // If a login failure occurred, send a login_failed notification.
        // Without this branch the UI would not display any popup after a failed
        // login.  We reset the flags to ensure subsequent runs behave
        // normally.  Including finished/total counters provides additional
        // context if the UI wishes to display them.
        if (waLoginFailed) {
            try {
                // Provide a callback to consume any lastError. Without the callback
                // chrome.runtime.sendMessage would return a promise that rejects
                // when no listener is present, producing an uncaught error in MV3.
                chrome.runtime.sendMessage({ action: 'wa_check_login_failed', finished: finished, total: total }, () => {
                    void chrome.runtime.lastError;
                });
            } catch (err) {}
            waLoginFailed = false;
            // Reset waCancelled so it doesn't affect the next run
            waCancelled = false;
            return;
        }
        // Distinguish between a normal completion and a user‑cancelled run.
        try {
            if (waCancelled) {
                chrome.runtime.sendMessage({ action: 'wa_check_cancelled', finished: finished, total: total }, () => {
                    void chrome.runtime.lastError;
                });
            } else {
                chrome.runtime.sendMessage({ action: 'wa_check_complete', finished: finished, total: total }, () => {
                    void chrome.runtime.lastError;
                });
            }
        } catch (e) {}
    } catch (e) {}
    // Reset the cancellation flag for the next run
    waCancelled = false;
}

/*
 * -------------------------------------------------------------------
 * Keep‑alive ping for Manifest V3 service worker
 *
 * Chrome's Manifest V3 unloads service workers when idle.  Some
 * asynchronous operations (e.g. long running scraping sessions) may
 * inadvertently stop if the background context is suspended.  To
 * mitigate this, create a periodic alarm that fires every minute.
 * When the alarm triggers we execute a no‑op function which keeps
 * the service worker alive.  This mechanism is lightweight and
 * cross‑platform, functioning on both desktop and mobile browsers.
 */
try {
    // Create or reset the keepAlive alarm to run every minute.  The
    // period must be at least one minute per Chrome's API constraints.
    chrome.alarms.create('keepAlive', { periodInMinutes: 1 });
    chrome.alarms.onAlarm.addListener(function(alarm) {
        if (alarm && alarm.name === 'keepAlive') {
            // Perform a trivial operation.  Reading from storage is
            // sufficient to keep the service worker alive without
            // consuming significant resources.  Wrap in try/catch to
            // silence any errors that might occur if storage is
            // unavailable.
            try {
                chrome.storage.local.get(['status'], function() {
                    // Intentionally empty callback.
                });
            } catch (e) {
                // Ignore errors during the keep‑alive ping.
            }
        }
    });
} catch (keepAliveErr) {
    // Ignore if alarms API is unavailable (e.g. in MV2 or some mobile
    // environments).  Scraping will still function but may be subject
    // to service worker suspension.
}

/**
 * Determine whether the extension has a valid, active licence.
 *
 * The licence state is stored in chrome.storage.local under the key
 * 'license'.  A licence is considered active when the stored object has
 * an `active` flag set to true.  This helper returns a promise that
 * resolves to a boolean indicating the activation status.  Wrapping
 * chrome.storage.local.get in a Promise simplifies gating logic below.
 *
 * @returns {Promise<boolean>}
 */
function isActivated() {
    return new Promise((resolve) => {
        try {
            chrome.storage.local.get('license', function (res) {
                const lic = res && res.license;
                resolve(!!(lic && lic.active));
            });
        } catch (err) {
            // In the unlikely event of a storage error, treat the licence as
            // inactive so that scraping does not proceed accidentally.
            console.warn('Error checking licence activation', err);
            resolve(false);
        }
    });
}

// Helper: send a stop_scraping message to all tabs without relying on
// $box.sendToAll. This avoids issues when chromeBox's broadcast
// functions reference an undefined variable ("name").
function broadcastStopScraping() {
    try {
        chrome.tabs.query({}, function(tabs) {
            tabs.forEach(tab => {
                // Send a stop_scraping message to each tab with a callback. If the tab
                // has no listener, chrome.runtime.lastError will be set and the
                // callback will swallow the error, preventing unhandled promise
                // rejections.
                chrome.tabs.sendMessage(tab.id, { event: 'stop_scraping' }, function() {
                    if (chrome.runtime.lastError) {
                        // There is no receiver in this tab; ignore the error.
                    }
                });
            });
        });
    } catch (e) {
        console.warn('Failed to broadcast stop_scraping', e);
    }
}

// -------------------------------------------------------------------
// v89 hidden licence/provider preflight. Dashboard opens immediately while
// non-secret routing metadata warms in the service worker.
let pocketLeadsPreflightPromise = null;
async function warmPocketLeadsBackend(reason, force) {
    if(pocketLeadsPreflightPromise)return pocketLeadsPreflightPromise;
    pocketLeadsPreflightPromise=(async()=>{
        try {
            void prewarmGhostProfileEngine().catch(()=>null);
            await PocketLeadsAccount.refresh({maxAgeMs:30000,force:!!force});
            const state=await PocketLeadsAccount.read();
            const a=state.pocketleadsAccount;
            if(!state.license?.active || a?.key!==state.license.key || a?.route?.status!=='ok')return null;
            const rt=a.route;
            return {provider:rt.provider,secureProxy:true,apiKeyRow:rt.keyRow,apifyKeyRow:rt.keyRow,apiUsageBefore:rt.usageCount,apiUsageLimit:rt.usageLimit,apifyUsageLimit:rt.usageLimit,licenceCreditRemaining:rt.licenceCreditRemaining};
        } catch(_){return null;}
    })();
    try{return await pocketLeadsPreflightPromise;}finally{pocketLeadsPreflightPromise=null;}
}

// When the extension icon is clicked, determine whether a licence key has
// been activated.  If a valid licence exists, open the main dashboard
// (`views/index.html`).  Otherwise open the licence activation form
// (`popup/license.html`).  This replaces the previous behaviour that
// always opened the dashboard regardless of licence state.
chrome.action.onClicked.addListener(() => {
    // Open UI immediately; icon, dashboard and Start share a recent verified
    // route. Explicit refresh and all paid server calls remain authoritative.
    warmPocketLeadsBackend('extension_icon_refresh', false).catch(() => null);
    try {
        // Always open the main dashboard regardless of licence state.  The
        // dashboard includes a licence activation modal that will appear
        // automatically when the user has not yet activated their key.
        const target = 'views/index.html';
        const url = chrome.runtime.getURL(target);
        chrome.tabs.create({ url: url, active: true }, function(tab) {
            console.log('Opened dashboard tab ->', tab && tab.id);
        });
    } catch (err) {
        console.error('Failed to handle action click', err);
        // As a fallback, still attempt to open the dashboard
        try {
            const fallbackUrl = chrome.runtime.getURL('views/index.html');
            chrome.tabs.create({ url: fallbackUrl, active: true }, function(tab) {
                // Provide callback to handle potential errors (e.g. when tabs
                // cannot be created while dragging)
                if (chrome.runtime && chrome.runtime.lastError) {
                    console.warn('Failed to open dashboard fallback', chrome.runtime.lastError);
                }
            });
        } catch (fallbackErr) {
            console.warn('Failed to open dashboard fallback', fallbackErr);
        }
    }
});

// Licence activation/dashboard code can request the same hidden warm-up.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.action !== 'pocketleads_warm_backend') return;
    warmPocketLeadsBackend(message.reason || 'runtime_message', !!message.force)
        .then(async result => {
            sendResponse({ ok:true, provider:result && result.provider || '' });
        })
        .catch(err => sendResponse({ ok:false, error:String(err && err.message || err || '') }));
    return true;
});


// PocketLeads Support transport: keep Apps Script networking in the extension
// service worker so redirects/CORS do not break ticket creation from dashboard UI.
const POCKETLEADS_SUPPORT_ENDPOINT = PocketLeadsConfig.endpoint;
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message && message.action === 'pocketleads_fetch_website') {
        const isExtSender = !sender || !sender.id || sender.id === chrome.runtime.id || /^(?:chrome|kiwi|edge|moz)-extension:\/\//i.test(String(sender.url || ''));
        if (!isExtSender) { sendResponse({ ok: false, error: 'Extension pages only' }); return false; }
        (async () => {
            const rawUrl = String(message.url || '').trim();
            if (!rawUrl) { sendResponse({ ok: false, error: 'Missing URL' }); return; }
            const totalBudgetMs = Math.max(3000, Math.min(10000, Number(message.timeoutMs) || 6500));
            const startedAt = Date.now();
            const candidates = [];
            const pushCandidate = u => {
                const s = String(u || '').trim();
                if (s && !candidates.includes(s)) candidates.push(s);
            };
            pushCandidate(rawUrl);
            try {
                const parsed = new URL(rawUrl);
                const host = parsed.hostname;
                const altHost = /^www\./i.test(host) ? host.replace(/^www\./i, '') : ('www.' + host);
                const altHttps = new URL(rawUrl);
                altHttps.protocol = 'https:';
                altHttps.hostname = altHost;
                pushCandidate(altHttps.href);
                const primaryHttp = new URL(rawUrl);
                primaryHttp.protocol = 'http:';
                pushCandidate(primaryHttp.href);
                const altHttp = new URL(rawUrl);
                altHttp.protocol = 'http:';
                altHttp.hostname = altHost;
                pushCandidate(altHttp.href);
            } catch (e) {
                if (/^https:\/\//i.test(rawUrl)) pushCandidate(rawUrl.replace(/^https:\/\//i, 'http://'));
                else if (/^http:\/\//i.test(rawUrl)) pushCandidate(rawUrl.replace(/^http:\/\//i, 'https://'));
            }
            let bestFallback = null;
            for (let i = 0; i < candidates.length; i++) {
                const elapsed = Date.now() - startedAt;
                const remainingMs = totalBudgetMs - elapsed;
                if (i > 0 && remainingMs < 900) break;
                const candidate = candidates[i];
                const controller = new AbortController();
                const attemptTimeout = i === 0 ? Math.min(4500, totalBudgetMs) : Math.max(1200, Math.min(3500, remainingMs));
                const timer = setTimeout(() => { try { controller.abort(); } catch (e) {} }, attemptTimeout);
                try {
                    const response = await fetch(candidate, {
                        method: 'GET',
                        redirect: 'follow',
                        cache: 'no-store',
                        credentials: 'omit',
                        referrerPolicy: 'no-referrer',
                        headers: {
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                            'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
                            'Upgrade-Insecure-Requests': '1'
                        },
                        signal: controller.signal
                    });
                    const rawHtml = await response.text();
                    clearTimeout(timer);
                    const html = rawHtml && rawHtml.length > 450000 ? rawHtml.slice(0, 450000) : rawHtml;
                    if (html && html.length > 25) {
                        const finalUrl = response.url || candidate;
                        const hasUsefulSignal = /@|mailto:|facebook\.com|instagram\.com|linkedin\.com|twitter\.com|x\.com|youtube\.com|contact/i.test(html);
                        if ((response.ok && html.length > 80) || hasUsefulSignal) {
                            sendResponse({ ok: true, status: response.status, html, url: finalUrl });
                            return;
                        }
                        if (!bestFallback || html.length > bestFallback.html.length) {
                            bestFallback = { ok: true, status: response.status, html, url: finalUrl };
                        }
                    }
                } catch (e) {
                    clearTimeout(timer);
                }
            }
            if (bestFallback) {
                sendResponse(bestFallback);
                return;
            }
            sendResponse({ ok: false, error: 'Website unreachable' });
        })();
        return true;
    }
    if (!message || message.action !== 'pocketleads_support_request') return;
    if(sender.id!==chrome.runtime.id || !String(sender.url||'').startsWith(chrome.runtime.getURL(''))) {sendResponse({ok:false,error:'Extension pages only'});return;}
    (async () => {
        try {
            const method = String(message.method || 'GET').toUpperCase();
            const params = (message.params && typeof message.params === 'object') ? message.params : {};
            const url = new URL(POCKETLEADS_SUPPORT_ENDPOINT);
            const request = { method: method === 'POST' ? 'POST' : 'GET', redirect: 'follow', cache: 'no-store', credentials: 'omit' };
            if (request.method === 'POST') {
                request.headers = { 'Content-Type': 'text/plain;charset=UTF-8', 'Accept': 'application/json' };
                request.body = JSON.stringify(params);
            } else {
                Object.keys(params).forEach(key => url.searchParams.set(key, params[key] == null ? '' : String(params[key])));
            }
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), request.method === 'POST' ? 60000 : 20000);
            request.signal = controller.signal;
            let response;
            try { response = await fetch(url.toString(), request); }
            finally { clearTimeout(timer); }
            const text = await response.text();
            if (!response.ok) {
                sendResponse({ ok: false, status: response.status, error: `Support service returned HTTP ${response.status}. Verify the Apps Script deployment URL and access settings.` });
                return;
            }
            // Apps Script returns JSON for our actions. Parse it here so the
            // dashboard client never has to deal with redirect/CORS quirks.
            let data = null;
            if (text) {
                const trimmed = text.trim();
                // Accept a bare JSON object/array. Apps Script ContentService
                // responses start with '{' or '['. An HTML doctype means the
                // deployment URL changed or returned an error page.
                if (trimmed.charAt(0) === '{' || trimmed.charAt(0) === '[') {
                    try { data = JSON.parse(trimmed); } catch (e) { data = null; }
                } else if (/<html|<!doctype/i.test(trimmed)) {
                    sendResponse({ ok: false, error: 'The support backend returned an HTML page instead of JSON. The Apps Script deployment may need to be re-published with execute permissions.' });
                    return;
                }
            }
            sendResponse({ ok: true, status: response.status, text: text, data: data, finalUrl: response.url || '' });
        } catch (error) {
            sendResponse({ ok: false, error: String(error && error.message || error || 'Support request failed') });
        }
    })();
    return true;
});

// Lightweight MV3 recovery heartbeat. If Chrome suspends the service worker
// during a long run, the next alarm wakes it and resumes only when persisted
// state says the run is active and no controller instance is already running.
try {
    if (chrome.alarms && chrome.alarms.create) {
        chrome.alarms.create('pocketleads_engine_health', { periodInMinutes: 0.5 });
        chrome.alarms.onAlarm.addListener(alarm => {
            if (!alarm || alarm.name !== 'pocketleads_engine_health') return;
            try {
                const flow = self.PocketLeadsApifyFlow;
                if (!flow || !flow.DailyController || flow.DailyController.running) return;
                $box.getLocal(async local => {
                    const active = PocketLeadsRunState.isRunning(local);
                    const queue = (local && local.apifyQueue) || {};
                    let pendingJobs = Array.isArray(queue.placeIdQueue) && queue.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
                    // v82: local queue is only a bounded UI checkpoint. For large
                    // runs consult the authoritative IndexedDB jobs store before
                    // deciding that there is nothing left to resume.
                    if (!pendingJobs && queue.jobRunId && flow.JobStore && typeof flow.JobStore.hasPending === 'function') {
                        try { pendingJobs = await flow.JobStore.hasPending(queue.jobRunId); } catch (e) {}
                    }
                    const pendingTasks = Array.isArray(local && local.taskList) && local.taskList.length > 0;
                    if (active && (pendingJobs || pendingTasks)) {
                        flow.DailyController.start().catch(err => console.warn('Health recovery resume failed', err));
                    }
                });
            } catch (err) { console.warn('Health alarm check failed', err); }
        });
    }
} catch (alarmErr) {
    console.warn('Unable to initialise engine health alarm', alarmErr);
}

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Handle requests from content scripts or popup
    if (!message || typeof message !== 'object') {
        return;
    }
    if (message.action === 'PL_GHOST_STAGE') {
        if(sender.id!==chrome.runtime.id || sender.url!==chrome.runtime.getURL(GHOST_OFFSCREEN_PATH))return;
        const flow=self.PocketLeadsApifyFlow,controller=flow&&flow.DailyController;
        if(controller && message.runEventId===controller._runEventId && !controller.stopped && !controller.clearRequested){
            const label={fetch_html:'Loading business profile',iframe_dom:'Reading business details',retry:'Retrying profile'}[message.stage]||'Processing profile';
            controller.updateQueue({_expectedRunId:message.runEventId,ghostStage:message.stage,ghostAttempt:message.attempt,ghostPlaceId:message.placeId,
                statusMessage:'Ghost Mode: '+label+' (single navigation attempt).',
                ...(message.error?{lastProfileError:String(message.error).slice(0,300)}:{})}).catch(()=>{});
        }
        sendResponse({ok:true});return false;
    }
    if (message.action === 'PL_GHOST_HEARTBEAT') { sendResponse({ok:true}); return false; }
    if (message.action === 'ensure_engine_alive') {
        try {
            const flow = self.PocketLeadsApifyFlow;
            if (flow && flow.DailyController && !flow.DailyController.running && !flow.DailyController.stopped && !flow.DailyController.clearRequested) {
                $box.getLocal(local => {
                    try {
                        const active = PocketLeadsRunState.isRunning(local);
                        const pendingTasks = Array.isArray(local && local.taskList) && local.taskList.length > 0;
                        if (active && pendingTasks && !flow.DailyController.running) {
                            flow.DailyController.start().catch(err => console.warn('Screen-wake auto-resume failed', err));
                        }
                    } catch (_) {}
                });
            }
        } catch (_) {}
        try { sendResponse && sendResponse({ ok: true, running: !!(self.PocketLeadsApifyFlow && self.PocketLeadsApifyFlow.DailyController && self.PocketLeadsApifyFlow.DailyController.running) }); } catch (_) {}
        return false;
    }
    if (message.action === 'PL_GHOST_CLOSE') {
        closeGhostOffscreenDocument().then(() => sendResponse && sendResponse({ ok: true })).catch(err => sendResponse && sendResponse({ ok: false, error: String(err && err.message || err) }));
        return true;
    }
    if (message.action === 'result_store_query' || message.action === 'scrape_history_get_all' || message.action === 'scrape_history_get' || message.action === 'scrape_history_put' || message.action === 'scrape_history_update_meta' || message.action === 'scrape_history_delete' || message.action === 'scrape_history_clear' || message.action === 'result_store_get_all' || message.action === 'result_store_get_page' || message.action === 'result_store_count' || message.action === 'result_store_upsert' || message.action === 'result_store_clear') {
        (async () => {
            try {
                const flow = self.PocketLeadsApifyFlow;
                if (!flow || !flow.ResultStore) throw new Error('IndexedDB result store is not ready.');
                if (message.action === 'scrape_history_get_all') {
                    if (!flow.HistoryStore) throw new Error('IndexedDB history store is not ready.');
                    const sessions = await flow.HistoryStore.getAll();
                    sendResponse && sendResponse({ ok: true, sessions });
                } else if (message.action === 'scrape_history_get') {
                    if (!flow.HistoryStore) throw new Error('IndexedDB history store is not ready.');
                    const session = await flow.HistoryStore.get(message.id || '');
                    sendResponse && sendResponse({ ok: true, session });
                } else if (message.action === 'scrape_history_put') {
                    if (!flow.HistoryStore) throw new Error('IndexedDB history store is not ready.');
                    await flow.HistoryStore.put(message.session || null);
                    sendResponse && sendResponse({ ok: true });
                } else if (message.action === 'scrape_history_update_meta') {
                    if (!flow.HistoryStore) throw new Error('IndexedDB history store is not ready.');
                    await flow.HistoryStore.updateMeta(message.id || '', message.patch || {});
                    sendResponse && sendResponse({ ok: true });
                } else if (message.action === 'scrape_history_delete') {
                    if (!flow.HistoryStore) throw new Error('IndexedDB history store is not ready.');
                    await flow.HistoryStore.remove(message.id || '');
                    sendResponse && sendResponse({ ok: true });
                } else if (message.action === 'scrape_history_clear') {
                    if (!flow.HistoryStore) throw new Error('IndexedDB history store is not ready.');
                    await flow.HistoryStore.clear();
                    sendResponse && sendResponse({ ok: true });
                } else if (message.action === 'result_store_get_all') {
                    const rows = await flow.ResultStore.getAll();
                    sendResponse && sendResponse({ ok: true, rows, count: rows.length });
                } else if (message.action === 'result_store_query') {
                    const result = await flow.ResultStore.query(message.query || {});
                    sendResponse && sendResponse({ok:true,...result});
                } else if (message.action === 'result_store_get_page') {
                    const offset = Math.max(0, parseInt(message.offset, 10) || 0);
                    const limit = Math.max(1, Math.min(5000, parseInt(message.limit, 10) || 1000));
                    const rows = await flow.ResultStore.getPage(offset, limit);
                    const count = await flow.ResultStore.count();
                    sendResponse && sendResponse({ ok: true, rows, count, offset, limit });
                } else if (message.action === 'result_store_count') {
                    const count = await flow.ResultStore.count();
                    sendResponse && sendResponse({ ok: true, count });
                } else if (message.action === 'result_store_upsert') {
                    if (message.runId) {
                        const state = await new Promise(resolve => $box.getLocal(resolve));
                        const currentRun = state && state.apifyQueue && state.apifyQueue.runEventId;
                        if (message.runId !== currentRun || (flow.DailyController && flow.DailyController.clearRequested)) {
                            throw new Error('Result update belongs to a cleared or superseded extraction.');
                        }
                    }
                    const result = await flow.ResultStore.upsertMany(Array.isArray(message.rows) ? message.rows : []);
                    sendResponse && sendResponse({ ok: true, result });
                } else if (message.action === 'result_store_clear') {
                    await flow.ResultStore.clear();
                    if (flow.JobStore) await flow.JobStore.clear();
                    sendResponse && sendResponse({ ok: true });
                }
            } catch (err) {
                try { sendResponse && sendResponse({ ok: false, error: String(err && err.message || err) }); } catch (e) {}
            }
        })();
        return true;
    }
    if (message.action === "stop_scraping") {
        console.log("Stop scraping command received in background");
        (async () => {
            try {
                const flow = self.PocketLeadsApifyFlow;
                    if (message.clearData) {
                        try {
                            if (flow && flow.DailyController) {
                            flow.DailyController.stopped = true;
                            flow.DailyController.clearRequested = true;
                            if (flow.DailyController.cancelProgressiveFeed) flow.DailyController.cancelProgressiveFeed();
                            flow.DailyController.restartRequested = false;
                        }
                    } catch (e) {}
                    try { if (flow && flow.ProfileScraper) flow.ProfileScraper.closeAllTabs(); } catch (e) {}
                    try { await closeGhostOffscreenDocument(); } catch (e) {}
                    try { if (flow && flow.ResultStore) await flow.ResultStore.clear(); if (flow && flow.JobStore) await flow.JobStore.clear(); } catch (e) {}
                    // v90: Clear Data should not make the next Google run cold.
                    // Recreate/prewarm the hidden Maps engine immediately after reset.
                    warmPocketLeadsBackend('after_clear', true)
                        .then(() => null)
                        .catch(() => null);
                    $box.getLocal(local => {
                        local.status = false;
                        if (!local._taskManager) local._taskManager = {};
                        local._taskManager.isWorking = false;
                        local._taskManager.activeTask = null;
                        local.collect = [];
                        local.collectIsPreview = false;
                        local.resultStoreCount = 0;
                        local.resultStoreMigrated = true;
                        local.taskList = [];
                        local.scrapeStartedAt = '';
                        local.scrapeFinishedAt = '';
                        local.scrapeElapsedMs = 0;
                        local.runState = { status: 'ready' };
                        local.apifyQueue = {
                            status: 'idle', statusMessage: 'Cleared. Ready for a fresh run.',
                            startedAt: '', finishedAt: '', elapsedMs: 0,
                            currentQuery: '', currentProfileUrl: '', totalPlaceIds: 0,
                            totalApiResults: 0, totalTasks: 0, completedTasks: 0,
                            apiTasksTotal: 0, apiTasksDone: 0, apiTasksFailed: 0,
                            apiTasksSettled: 0, domTotal: 0, domProcessed: 0,
                            domPending: 0, domRunning: 0, scrapedCount: 0,
                            failedCount: 0, filteredCount: 0, duplicateSkippedCount: 0,
                            pendingPlaceIds: [], placeIdQueue: [], processing: null,
                            completed: [], failed: [], retryCount: {}, resumeAvailable: false,
                            producerDone: false, consumerDone: false, managedTabIds: [],
                            domConcurrency: 1, domSuccessStreak: 0, domSuccessRate: 0, domTransientErrors: 0,
                            lastUpdatedAt: new Date().toISOString()
                        };
                        local.apifySeenKeys = [];
                        local.apifyLastDatasetId = '';
                        local.apifyLastRunId = '';
                        $box.setLocal(local, { onSet: () => broadcastStopScraping() });
                    });
                } else if (flow && flow.DailyController && typeof flow.DailyController.stop === 'function') {
                    await flow.DailyController.stop();
                    broadcastStopScraping();
                } else {
                    $box.getLocal(local => {
                        local.status = false;
                        if (!local._taskManager) local._taskManager = {};
                        local._taskManager.isWorking = false;
                        local._taskManager.activeTask = 'openMap';
                        const stoppedAt = new Date().toISOString();
                        const q = Object.assign({}, local.apifyQueue || {});
                        q.status = 'stopped';
                        q.statusMessage = 'Scraping stopped safely. Click Resume to continue.';
                        q.resumeAvailable = true;
                        q.finishedAt = stoppedAt;
                        q.lastUpdatedAt = stoppedAt;
                        local.apifyQueue = q;
                        $box.setLocal(local, { onSet: () => broadcastStopScraping() });
                    });
                }
                try { TaskManager.randInterval.stop(); } catch (e) {}
                // DailyController.stop() emits the one dashboard stop event.
                try { sendResponse && sendResponse({ acknowledged: true }); } catch (e) {}
            } catch (err) {
                console.warn('stop_scraping failed', err);
                try { sendResponse && sendResponse({ acknowledged: false, error: String(err && err.message || err) }); } catch (e) {}
            }
        })();
        return true;
    }

    // NEW: open a new tab when requested from a content script.  This is
    // used to handle captcha or blocked pages.  We check that the URL
    // starts with http or https to prevent unexpected protocols.
    if (message.action === 'open_tab') {
        try {
            // Ghost Mode and provider result flows must never fall back to visible
            // Google Maps pages. Older content code can still emit open_tab after a
            // timeout; reject that stale request instead of leaving blank/profile tabs.
            const rawOpenUrl = String(message.url || '').trim();
            if (!rawOpenUrl || rawOpenUrl === 'about:blank' || /^chrome-error:\/\//i.test(rawOpenUrl)) {
                sendResponse && sendResponse({ acknowledged: false, error: 'Blank or error tabs are disabled.' });
                return true;
            }
            if (message.url && /^https?:\/\//.test(message.url)) {
                let requested = null;
                try { requested = new URL(message.url); } catch (_) {}
                const googleMapsRequest = !!requested && ((/^(?:www\.|maps\.)?google\.(?:com|co\.in)$/i.test(requested.hostname)
                    && (/^\/maps(?:\/|$)/i.test(requested.pathname) || /^\/sorry(?:\/|$)/i.test(requested.pathname)))
                    || /(^|\.)consent\.google\.(?:com|co\.in)$/i.test(requested.hostname));
                if (googleMapsRequest) {
                    sendResponse && sendResponse({ acknowledged: false, error: 'Visible Google Maps profile tabs are disabled. Ghost Mode uses one hidden Place-ID navigation.' });
                    return true;
                }
                // If chrome.tabs is unavailable (e.g. service worker suspended), fall back
                // to opening the URL via $box.openURL when available.  This ensures
                // a new tab is still opened even when the tabs API cannot be used.
                if (!chrome || !chrome.tabs || typeof chrome.tabs.create !== 'function') {
                    console.warn('chrome.tabs unavailable in background open_tab; using fallback');
                    if (typeof $box !== 'undefined' && typeof $box.openURL === 'function') {
                        try {
                            $box.openURL(message.url, { active: false });
                            // Attempt to refocus on mobile (best effort)
                            try {
                                chrome.runtime.getPlatformInfo(function(info) {
                                    if (info && info.os && info.os.toLowerCase() === 'android') {
                                        const pattern = 'chrome-extension://' + chrome.runtime.id + '/*';
                                        chrome.tabs && chrome.tabs.query({ url: pattern }, function(extTabs) {
                                            if (extTabs && extTabs.length > 0) {
                                                // Provide a callback to suppress errors when tabs cannot be edited
                                                chrome.tabs.update(extTabs[0].id, { active: true }, function() {
                                                    if (chrome.runtime && chrome.runtime.lastError) {
                                                        console.warn('Tab update error (open_tab fallback refocus)', chrome.runtime.lastError);
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            } catch (focusFallbackErr) {
                                console.warn('Failed to refocus after fallback open_tab', focusFallbackErr);
                            }
                            sendResponse && sendResponse({ acknowledged: true });
                        } catch (openErr) {
                            console.warn('Fallback open_tab failed', openErr);
                            sendResponse && sendResponse({ acknowledged: false, error: openErr && openErr.message });
                        }
                    } else {
                        sendResponse && sendResponse({ acknowledged: false, error: 'tabs API unavailable and no fallback' });
                    }
                    return true;
                }
                // Use the tabs API normally
                chrome.tabs.create({ url: message.url, active: false }, function(tab) {
                    console.log('Opened new tab from background:', tab && tab.id);
                    // Refocus the dashboard on mobile devices to prevent Chrome on
                    // Android from switching focus to the new tab.
                    try {
                        chrome.runtime.getPlatformInfo(function(info) {
                            if (info && info.os && info.os.toLowerCase() === 'android') {
                                const pattern = 'chrome-extension://' + chrome.runtime.id + '/*';
                                chrome.tabs.query({ url: pattern }, function(extTabs) {
                                    if (extTabs && extTabs.length > 0) {
                                        // Provide a callback to suppress tab update errors
                                        chrome.tabs.update(extTabs[0].id, { active: true }, function() {
                                            if (chrome.runtime && chrome.runtime.lastError) {
                                                console.warn('Tab update error (open_tab refocus)', chrome.runtime.lastError);
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    } catch (refocusErr) {
                        console.warn('Failed to refocus after open_tab', refocusErr);
                    }
                    sendResponse && sendResponse({ acknowledged: true });
                });
            } else {
                console.warn('Invalid open_tab request', message.url);
                sendResponse && sendResponse({ acknowledged: false, error: 'Invalid URL' });
            }
        } catch (err) {
            console.warn('Error handling open_tab request', err);
            sendResponse && sendResponse({ acknowledged: false, error: err && err.message });
        }
        return true;
    }

    // NEW: close the sender tab when requested.  We use sender.tab.id
    // to identify which tab to remove.  This avoids the restriction that
    // window.close() only works on windows opened by script.
    if (message.action === 'close_current_tab') {
        try {
            if (sender && sender.tab && sender.tab.id) {
                // Provide a callback to handle any errors (e.g. tab is being dragged)
                chrome.tabs.remove(sender.tab.id, function() {
                    if (chrome.runtime && chrome.runtime.lastError) {
                        console.warn('Failed to remove sender tab', chrome.runtime.lastError);
                    }
                });
            } else {
                console.warn('close_current_tab: sender.tab.id not available');
            }
        } catch (e) {
            console.warn('Failed to close tab via background', e);
        }
        // Acknowledge receipt
        try {
            sendResponse && sendResponse({ acknowledged: true });
        } catch (err) {}
        return true;
    }
});

// Listener for WA number check actions.  Handles starting and
// stopping of bulk checks.  When starting a new run the numbers
// array should be provided on message.items.  When stopping a run
// message.action should be 'stop_wa_check'.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    try {
        if (message && message.action === 'start_wa_check' && Array.isArray(message.items)) {
            // Do not start a new run if one is already in progress
            if (waChecking) {
                try { sendResponse && sendResponse({ started: false, error: 'already_running' }); } catch (e) {}
                return true;
            }
            // Prepare the queue with normalised numbers and rowIds.  A new
            // run always processes numbers from the beginning of the dataset.  We
            // intentionally ignore any previously stored resume index so that
            // unresolved numbers near the top of the list are rechecked first.
            waQueue = [];
            message.items.forEach(item => {
                const num = String(item.number || '').replace(/\D/g, '');
                waQueue.push({ number: num, rowId: item.rowId });
            });
            // Compute total count for this run and reset progress counters.
            waTotalCount = waQueue.length;
            // Reset finished count and resume index for the new run.
            waFinishedCount = 0;
            waResumeIndex = 0;
            // Reset attempt counts so each number starts fresh.
            waAttemptCounts = {};
            waChecking = true;
            waStopRequested = false;
            // Reset cancellation and login failure flags for this run
            waCancelled = false;
            waLoginFailed = false;
            // Remember the tab from which the WA check was initiated.  We
            // will temporarily focus the WhatsApp tab to ensure it
            // initialises correctly, then return focus to this tab.  Some
            // messages may originate from contexts without sender.tab;
            // guard against undefined values.
            try {
                if (sender && sender.tab && typeof sender.tab.id === 'number') {
                    waReturnTabId = sender.tab.id;
                } else {
                    waReturnTabId = null;
                }
            } catch (err) {
                waReturnTabId = null;
            }
            // Ensure we have a WhatsApp Web tab and start processing
                ensureWaTab((tabId) => {
                    if (!tabId) {
                        // If the tab could not be created or found, treat this as a
                        // login failure rather than a normal completion.  Setting
                        // waLoginFailed triggers the login_failed branch inside
                        // finishWaSession(), ensuring the UI shows a clear
                        // message rather than misreporting a completed run.  This
                        // avoids prematurely stopping scraping when WhatsApp
                        // cannot be opened (e.g. due to blocked pop‑ups).
                        waLoginFailed = true;
                        finishWaSession();
                    } else {
                    /*
                     * Reload the WhatsApp tab only if our helper scripts have not
                     * yet been injected.  The waScriptLoadedForTab map tracks
                     * whether injection occurred for each tab.  On the first run
                     * we reload to ensure the content script and page bridge are
                     * loaded; on subsequent runs we skip the reload so the user’s
                     * session is preserved and the process starts faster.
                     */
                    const injectAndWait = () => {
                        // Focus the WhatsApp tab so the user can observe progress.
                        try {
                        // Open the WhatsApp tab in the background so it does not steal
                        // focus from the scraping tab.  Keeping the Maps tab active
                        // allows scraping to continue uninterrupted while the WA check
                        // runs.  We deliberately set active:false rather than true.
                        chrome.tabs.update(tabId, { active: false }, function() {
                                waHasFocused = true;
                            });
                        } catch (focusErr) {
                            // Ignore focusing errors
                        }
                        // Inject helper scripts via the content script marker.  Once
                        // injected, notify the dashboard and wait for login.  When
                        // login succeeds start processing the queue after a short
                        // delay; on failure mark the run as failed and finish.
                    injectWaScript(tabId, () => {
                        try {
                            // Provide callback to avoid unhandled promise rejections when no listener exists
                            chrome.runtime.sendMessage({ action: 'wa_check_login_waiting', total: waTotalCount }, () => {
                                void chrome.runtime.lastError;
                            });
                        } catch (e) {}
                        waitForLogin(tabId, (loggedIn) => {
                            if (!loggedIn) {
                                waLoginFailed = true;
                                finishWaSession();
                            } else {
                                try {
                                    chrome.runtime.sendMessage({ action: 'wa_check_login_success' }, () => {
                                        void chrome.runtime.lastError;
                                    });
                                } catch (e) {}
                                setTimeout(() => {
                                    runWaQueue();
                                }, 2000);
                            }
                        });
                    });
                    };
                    if (!waScriptLoadedForTab[tabId]) {
                        // Force a reload once to ensure a clean state on the very first run.
                        try {
                            chrome.tabs.reload(tabId, { bypassCache: true }, function() {
                                injectAndWait();
                            });
                        } catch (err) {
                            // If reload fails (rare), proceed without reloading.
                            injectAndWait();
                        }
                    } else {
                        // Scripts are already injected; skip reload to avoid unnecessary refresh.
                        injectAndWait();
                    }
                }
            });
            try { sendResponse && sendResponse({ started: true }); } catch (e) {}
            return true;
        }
        if (message && message.action === 'stop_wa_check') {
            // Signal cancellation and finish the current session
            waStopRequested = true;
            // Mark the current run as cancelled so finishWaSession()
            // dispatches a cancellation message instead of a complete message
            waCancelled = true;
            // Immediately finish; runWaQueue or executeWaCheck callback will call finishWaSession
            // Reset state now to avoid starting new checks
            // The completion message will be sent from finishWaSession()
            try { sendResponse && sendResponse({ stopped: true }); } catch (e) {}
            return true;
        }

        // Append additional numbers to the active WA check queue.  When
        // waChecking is true new items can be pushed into the queue
        // on-the-fly via this message.  Items should be an array of
        // objects with number and rowId.  Duplicates are filtered
        // based on rowId and normalised number.  The total count is
        // incremented accordingly.  If no check is currently running
        // the request is ignored.
        if (message && message.action === 'append_wa_check' && Array.isArray(message.items)) {
            if (waChecking) {
                try {
                    message.items.forEach(item => {
                        if (!item) return;
                        const num = String(item.number || '').replace(/\D/g, '');
                        const rowId = typeof item.rowId === 'number' ? item.rowId : null;
                        // Skip invalid numbers
                        if (!num) return;
                        // Do not add if this rowId or number already exists in the queue or has been processed
                        let duplicate = false;
                        for (let i = 0; i < waQueue.length; i++) {
                            const q = waQueue[i];
                            if ((typeof q.rowId === 'number' && q.rowId === rowId) || (q.number === num)) {
                                duplicate = true;
                                break;
                            }
                        }
                        if (!duplicate) {
                            waQueue.push({ number: num, rowId: rowId });
                            waTotalCount += 1;
                        }
                    });
                } catch (appendErr) {
                    console.warn('Error appending WA queue', appendErr);
                }
            }
            try { sendResponse && sendResponse({ appended: true }); } catch (e) {}
            return true;
        }
    } catch (err) {
        // Suppress errors
    }
});

$box.on((event, data) => {
    console.log("Message received : " + event);

    if (event === "start") {
        // Warm Ghost Mode offscreen context and sweep any stray tabs in parallel
        // with preflight so Start enters extraction without cold-start delay.
        void prewarmGhostProfileEngine().catch(() => null);
        void cleanupLegacyOwnedProfileTab(true).catch(() => null);
        PocketLeadsAccount.preflight().then((active) => {
            if (!active) {
                console.warn('Scraping blocked: licence not activated');
                // Inform the dashboard to show the licence activation modal.
                try {
                    $box.send('open_license_modal');
                } catch (err) {
                    console.warn('Failed to dispatch open_license_modal', err);
                }
                // Notify the user through a browser notification as a fallback.
                try {
                    const licenceNotificationId = 'pocketleads_licence_required';
                    const licenceNotification = {
                        type: "basic",
                        iconUrl: chrome.runtime.getURL('assets/icons/icon.png'),
                        title: "Licence Required",
                        message: "Please activate your licence to start scraping."
                    };
                    chrome.notifications.clear(licenceNotificationId, () => {
                        void chrome.runtime.lastError;
                        chrome.notifications.create(licenceNotificationId, licenceNotification, () => {
                            void chrome.runtime.lastError;
                        });
                    });
                } catch (e) {
                    console.warn('Failed to show licence notification', e);
                }
                // Do not proceed with scraping.
                return;
            }
            console.log("Starting scraping in background...");
            // Reset completion notification flag for new session
            scrapingCompleteNotified = false;
            retryCount = 0;
            $box.getLocal(local => {
                /*
                 * When the user resumes after stopping a run, `_taskManager.activeTask`
                 * may still reference the last executed task while
                 * `_taskManager.isWorking` is false.  In that case we call
                 * TaskManager.startPendingTask to restore the session on the
                 * previously active task.  Otherwise, we begin fresh with
                 * 'openMap'.
                 */
                // v91 commercial gate: do NOT mark the run active here. The controller
                // first consumes the already-prepared source/credit decision and only
                // then transitions the persisted model to Running. This prevents a
                // zero-credit/expired licence from flashing progress or creating
                // failed pincode rows before the upgrade popup appears.
                if (!local._taskManager) local._taskManager = {};
                local.status = false;
                local.fastMode = false;
                local._taskManager.isWorking = false;
                local._taskManager.activeTask = 'openMap';
                $box.setLocal(local, {
                    onSet: () => {
                        if (TaskManager.container && typeof TaskManager.container.openMap === 'function') {
                            TaskManager.container.openMap();
                        } else if (TaskManager.container && typeof TaskManager.container.start === 'function') {
                            TaskManager.container.start();
                        } else {
                            console.warn('PocketLeads start controller is not ready.');
                        }
                    }
                });
            });
        }).catch(error => {
            const code=error.code||'ACCOUNT_PREFLIGHT';
            const errMsg=String(error&&error.message||error||'Unable to start extraction.');
            const upgradeRequired=code==='LICENSE_CREDIT_EXHAUSTED';
            chrome.storage.local.set({pocketleadsPreflightState:{status:'error',errorCode:code,upgradeRequired,message:errMsg,error:errMsg,preparedAt:Date.now()}});
            // Also persist into local.apifyQueue.liveSpyEvents so it appears in Live Spy & Diagnostics Logs
            try {
                $box.getLocal(local => {
                    if (!local) return;
                    if (!local.apifyQueue) local.apifyQueue = {};
                    const nowIsoStr = new Date().toISOString();
                    local.apifyQueue.lastErrorCode = code;
                    local.apifyQueue.lastErrorDetail = errMsg;
                    local.apifyQueue.lastErrorAt = nowIsoStr;
                    if (!Array.isArray(local.apifyQueue.liveSpyEvents)) local.apifyQueue.liveSpyEvents = [];
                    local.apifyQueue.liveSpyEvents.unshift({
                        ts: Date.now(),
                        iso: nowIsoStr,
                        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
                        level: 'error',
                        type: code,
                        provider: 'preflight',
                        query: String((Array.isArray(local.taskList) && local.taskList[0]) || 'Preflight Check'),
                        message: errMsg
                    });
                    if (local.apifyQueue.liveSpyEvents.length > 80) local.apifyQueue.liveSpyEvents = local.apifyQueue.liveSpyEvents.slice(0, 80);
                    $box.setLocal(local);
                });
            } catch (_) {}
            try{$box.send('scraping_error',{message:errMsg,errorCode:code,apiId:error&&error.apiId||'',keyRow:error&&error.keyRow||0,provider:error&&error.provider||'',upgradeRequired,supportEmail:PocketLeadsConfig.supportEmail});}catch(_){}
            chrome.notifications.create('pl_preflight',{type:'basic',iconUrl:chrome.runtime.getURL('assets/icons/icon.png'),title:'Unable to start',message:errMsg},()=>void chrome.runtime.lastError);
        });
        // Return here to prevent synchronous fall‑through.  All start
        // logic occurs asynchronously in the callback above.
        return;
    }

    if (event === "scrape_failed") {
        // Direct Google Places mode owns its managed tabs and retries internally.
        // Never close arbitrary user Google Maps tabs or open an unmanaged tab.
        console.warn('Legacy scrape_failed received; recycling only extension-managed Maps tabs.');
        try {
            const flow = self.PocketLeadsApifyFlow;
            if (flow && flow.ProfileScraper) flow.ProfileScraper.closeAllTabs();
            $box.getLocal(local => {
                const q = Object.assign({}, local.apifyQueue || {});
                const pending = Array.isArray(q.placeIdQueue) && q.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')));
                if (pending) {
                    q.status = 'memory_recovery';
                    q.statusMessage = 'Maps tab became unhealthy. Managed tab recycled; pending profiles remain checkpointed.';
                    q.resumeAvailable = !local.status;
                    q.managedTabIds = [];
                    q.lastUpdatedAt = new Date().toISOString();
                    local.apifyQueue = q;
                    $box.setLocal(local);
                }
            });
        } catch (err) {
            console.warn('Managed scrape_failed recovery failed', err);
        }
    }

    if (event === "stop") {
        console.log("Stop event called; routing through resumable controller stop");
        (async () => {
            try {
                const flow = self.PocketLeadsApifyFlow;
                if (message && message.clearData) {
                    try {
                        if (flow && flow.DailyController) {
                            flow.DailyController.stopped = true;
                            flow.DailyController.clearRequested = true;
                            if (flow.DailyController.cancelProgressiveFeed) flow.DailyController.cancelProgressiveFeed();
                            flow.DailyController.restartRequested = false;
                        }
                    } catch (e) {}
                    try { if (flow && flow.ProfileScraper) flow.ProfileScraper.closeAllTabs(); } catch (e) {}
                    try { await closeGhostOffscreenDocument(); } catch (e) {}
                    try { if (flow && flow.ResultStore) await flow.ResultStore.clear(); if (flow && flow.JobStore) await flow.JobStore.clear(); } catch (e) {}
                    $box.getLocal(local => {
                        local.status = false;
                        if (!local._taskManager) local._taskManager = {};
                        local._taskManager.isWorking = false;
                        local._taskManager.activeTask = null;
                        local.collect = [];
                        local.collectIsPreview = false;
                        local.resultStoreCount = 0;
                        local.resultStoreMigrated = true;
                        local.taskList = [];
                        local.scrapeStartedAt = '';
                        local.scrapeFinishedAt = '';
                        local.scrapeElapsedMs = 0;
                        local.runState = { status: 'ready' };
                        local.apifyQueue = Object.assign({}, local.apifyQueue || {}, {
                            status: 'idle', statusMessage: 'Cleared. Ready for a fresh run.',
                            startedAt: '', finishedAt: '', elapsedMs: 0,
                            totalTasks: 0, completedTasks: 0, apiTasksTotal: 0, apiTasksDone: 0,
                            apiTasksFailed: 0, apiTasksSettled: 0, domTotal: 0, domProcessed: 0,
                            domPending: 0, domRunning: 0, placeIdQueue: [], pendingPlaceIds: [],
                            resumeAvailable: false, producerDone: false, consumerDone: false,
                            domConcurrency: 1, domSuccessStreak: 0, domSuccessRate: 0, domTransientErrors: 0,
                            managedTabIds: [], processing: null, currentProfileUrl: '',
                            lastUpdatedAt: new Date().toISOString()
                        });
                        $box.setLocal(local, { onSet: () => broadcastStopScraping() });
                    });
                } else if (flow && flow.DailyController && typeof flow.DailyController.stop === 'function') {
                    await flow.DailyController.stop();
                    broadcastStopScraping();
                } else {
                    $box.getLocal(local => {
                        local.status = false;
                        if (!local._taskManager) local._taskManager = {};
                        local._taskManager.isWorking = false;
                        local._taskManager.activeTask = 'openMap';
                        const stoppedAt = new Date().toISOString();
                        const q = Object.assign({}, local.apifyQueue || {});
                        if (Array.isArray(q.placeIdQueue)) {
                            q.placeIdQueue = q.placeIdQueue.map(item => String(item && item.status || '').toLowerCase() === 'dom_running'
                                ? Object.assign({}, item, { status: 'retry_pending', lastUpdatedAt: stoppedAt }) : item);
                        }
                        q.status = 'stopped';
                        q.statusMessage = 'Scraping stopped safely. Click Resume to continue.';
                        q.resumeAvailable = true;
                        q.domRunning = 0;
                        q.processing = null;
                        q.currentProfileUrl = '';
                        q.finishedAt = stoppedAt;
                        q.lastUpdatedAt = stoppedAt;
                        local.apifyQueue = q;
                        $box.setLocal(local, { onSet: () => broadcastStopScraping() });
                    });
                }
                try { TaskManager.randInterval.stop(); } catch (e) {}
            } catch (err) {
                console.warn('Legacy stop event failed', err);
            }
        })();
    }
});

// Unified message handler for event‑based notifications.  When a
// content or popup script sends a message with an `event` property,
// acknowledge receipt by calling sendResponse.  Without this the
// message port will close prematurely causing chrome.runtime.lastError
// to be set to "The message port closed before a response was
// received.".  We respond synchronously here because the work is
// synchronous; if asynchronous operations were needed we would
// instead return true and call sendResponse later.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || typeof message !== 'object') {
        return;
    }
    if (message.event === "scraping_complete") {
        try {
            $box.getLocal(local => {
                try {
                    const queue = Object.assign({}, (local && local.apifyQueue) || {});
                    const placeJobs = Array.isArray(queue.placeIdQueue) ? queue.placeIdQueue : [];
                    const pendingPlaces = placeJobs.filter(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || ''))).length;
                    const tasksRemain = Array.isArray(local && local.taskList) && local.taskList.length > 0;
                    const apiTotal = Math.max(0, parseInt(queue.apiTasksTotal || queue.totalTasks, 10) || 0);
                    const apiSettled = Math.max(0, parseInt(queue.apiTasksSettled || queue.completedTasks, 10) || 0);
                    const apiIncomplete = apiTotal > 0 && apiSettled < apiTotal;
                    const domPending = Math.max(pendingPlaces, parseInt(queue.domPending, 10) || 0, parseInt(queue.domRunning, 10) || 0);
                    const googlePipeline = String(queue.provider || '').toLowerCase() === 'googlemaps' || placeJobs.length > 0 || /^google_pipeline/i.test(String(queue.status || ''));
                    const producerIncomplete = googlePipeline && apiTotal > 0 && queue.producerDone !== true;
                    const statusActive = !!(local && local.status);
                    const workingActive = !!(local && local._taskManager && local._taskManager.isWorking);
                    if (statusActive || workingActive || tasksRemain || apiIncomplete || domPending > 0 || producerIncomplete) {
                        console.warn('background: ignored premature scraping_complete', { tasksRemain, apiIncomplete, domPending, producerIncomplete });
                        try { sendResponse && sendResponse({ acknowledged: true, ignored: true, reason: 'work_remaining' }); } catch (e) {}
                        return;
                    }

                    if (!scrapingCompleteNotified) {
                        scrapingCompleteNotified = true;
                        local.status = false;
                        if (!local._taskManager) local._taskManager = {};
                        local._taskManager.isWorking = false;
                        local._taskManager.activeTask = null;
                        queue.status = queue.completedWithErrors ? 'completed_with_errors' : 'completed';
                        queue.statusMessage = queue.completedWithErrors ? 'Scraping complete with some failed/skipped records.' : 'Scraping complete.';
                        queue.resumeAvailable = false;
                        queue.producerDone = true;
                        queue.consumerDone = true;
                        queue.domPending = 0;
                        queue.domRunning = 0;
                        queue.processing = null;
                        queue.currentProfileUrl = '';
                        queue.finishedAt = queue.finishedAt || new Date().toISOString();
                        queue.lastUpdatedAt = new Date().toISOString();
                        local.apifyQueue = queue;
                        PocketLeadsRunState.apply(local);
                        $box.setLocal(local);
                        try { if (self.PocketLeadsApifyFlow && self.PocketLeadsApifyFlow.ProfileScraper) self.PocketLeadsApifyFlow.ProfileScraper.closeAllTabs(); } catch (e) {}
                        // Do not rebroadcast: the original runtime event already reached
                        // dashboard contexts. Rebroadcasting created duplicate popups.
                    }
                    try { sendResponse && sendResponse({ acknowledged: true, ignored: false }); } catch (e) {}
                } catch (guardErr) {
                    console.warn('background: completion guard failed; refusing unsafe completion', guardErr);
                    try { sendResponse && sendResponse({ acknowledged: false, ignored: true, reason: 'guard_failed' }); } catch (e) {}
                }
            });
        } catch (outerErr) {
            console.warn('background: error handling scraping_complete; refusing unsafe completion', outerErr);
            try { sendResponse && sendResponse({ acknowledged: false, ignored: true, reason: 'handler_failed' }); } catch (e) {}
        }
        return true;
    }

    if (message.event === "scraping_stopped") {
        // Update local storage
        try {
            $box.getLocal(local => {
                local.status = false;
                if (local._taskManager) {
                    local._taskManager.isWorking = false;
                }
                $box.setLocal(local);
            });
        } catch (err) {
            console.warn('Failed to update local status on scraping_stopped', err);
        }
        // Do not rebroadcast: the original runtime event already reached the
        // dashboard. The controller is the single owner of stop events.
        // Acknowledge receipt
        try {
            sendResponse && sendResponse({ acknowledged: true });
        } catch (err) {}
        return true;
    }
});


// Unified notification broker. Multiple dashboard tabs may request the same
// notification, so use a deterministic key and a cooldown instead of random IDs.
const pocketLeadsNotificationTimes = new Map();
function notificationKeyOf(request) {
  const raw = String((request && request.dedupeKey) || ((request && request.title) || '') + '|' + ((request && request.message) || '')).toLowerCase();
  let hash = 0;
  for (let i = 0; i < raw.length; i += 1) hash = ((hash << 5) - hash + raw.charCodeAt(i)) | 0;
  return 'pln_' + Math.abs(hash).toString(36);
}
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request && request.type === "notify") {
    const id = notificationKeyOf(request);
    const now = Date.now();
    const cooldownMs = Math.max(2000, parseInt(request.cooldownMs, 10) || 10000);
    const lastAt = pocketLeadsNotificationTimes.get(id) || 0;
    if (now - lastAt < cooldownMs) {
      try { sendResponse({ success: true, deduped: true }); } catch (e) {}
      return true;
    }
    pocketLeadsNotificationTimes.set(id, now);
    for (const [key, at] of pocketLeadsNotificationTimes.entries()) {
      if (now - at > 120000) pocketLeadsNotificationTimes.delete(key);
    }
    const options = {
      type: "basic",
      iconUrl: chrome.runtime.getURL("assets/icons/icon.png"),
      title: request.title || "Notification",
      message: request.message || ""
    };
    const create = () => chrome.notifications.create(id, options, () => {
      void chrome.runtime.lastError;
      try { sendResponse({ success: true, deduped: false }); } catch (e) {}
    });
    try {
      chrome.notifications.clear(id, () => {
        void chrome.runtime.lastError;
        create();
      });
    } catch (err) {
      create();
    }
    return true;
  }
});


// Clicking any PocketLeads system notification ("Scraping Complete", "Scraping Paused", etc.)
// focuses the existing PocketLeads dashboard tab or opens a new one.
if (typeof chrome !== 'undefined' && chrome.notifications && chrome.notifications.onClicked && typeof chrome.notifications.onClicked.addListener === 'function') {
  chrome.notifications.onClicked.addListener((notificationId) => {
    try {
      if (chrome.notifications && typeof chrome.notifications.clear === 'function') {
        chrome.notifications.clear(notificationId, () => { try { void chrome.runtime.lastError; } catch (_) {} });
      }
      const dashUrl = chrome.runtime.getURL('views/index.html');
      if (chrome.tabs && typeof chrome.tabs.query === 'function') {
        chrome.tabs.query({}, (tabs) => {
          try { void chrome.runtime.lastError; } catch (_) {}
          const existing = Array.isArray(tabs)
            ? tabs.find(t => t && typeof t.url === 'string' && t.url.indexOf(dashUrl) === 0)
            : null;
          if (existing && existing.id) {
            if (existing.windowId && chrome.windows && typeof chrome.windows.update === 'function') {
              chrome.windows.update(existing.windowId, { focused: true }, () => { try { void chrome.runtime.lastError; } catch (_) {} });
            }
            chrome.tabs.update(existing.id, { active: true }, () => {
              try { void chrome.runtime.lastError; } catch (_) {}
              try {
                chrome.runtime.sendMessage({ type: 'pl_notification_clicked', notificationId: String(notificationId || '') }, () => {
                  try { void chrome.runtime.lastError; } catch (_) {}
                });
              } catch (_) {}
            });
          } else if (chrome.tabs && typeof chrome.tabs.create === 'function') {
            chrome.tabs.create({ url: dashUrl, active: true }, () => { try { void chrome.runtime.lastError; } catch (_) {} });
          }
        });
      } else if (chrome.tabs && typeof chrome.tabs.create === 'function') {
        chrome.tabs.create({ url: dashUrl, active: true }, () => { try { void chrome.runtime.lastError; } catch (_) {} });
      }
    } catch (err) {
      console.warn('Notification click open failed', err);
    }
  });
}


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.action !== 'pocketleads_log_any_error') return;
  (async () => {
    try {
      const alertObj = message.alert || {};
      const st = await PocketLeadsAccount.read().catch(() => ({}));
      const lic = (st && st.license) || {};
      const acc = (st && st.pocketleadsAccount) || {};
      const key = String(alertObj.licenceKey || lic.key || acc.key || '').trim();
      const deviceId = String(lic.installationId || acc.deviceId || '').trim();
      if (!key || key === 'Active Licence') {
        sendResponse({ ok: false });
        return;
      }
      const errCode = String(alertObj.errorCode || 'EXTRACTION_ISSUE');
      const errMsg = String(alertObj.upstreamError || alertObj.message || 'Extraction issue');
      const payload = Object.assign({}, alertObj, {
        action: 'logApiError',
        key,
        deviceId,
        licenceKey: key,
        userName: String(alertObj.userName || acc.userName || lic.userName || ''),
        errorCode: errCode,
        upstreamError: errMsg
      });
      const r = await fetch(PocketLeadsConfig.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify(payload),
        cache: 'no-store'
      }).then(res => res.json()).catch(() => null);
      if (!r || r.status !== 'ok' || !r.logged) {
        const fallbackPayload = {
          action: 'submitTicket',
          key,
          deviceId,
          user: String(alertObj.userName || acc.userName || lic.userName || key),
          subject: `[AUTO ERROR LOG] ${errCode} (${alertObj.apiId || alertObj.provider || 'API'}) - Licence ${key}`.slice(0, 118),
          message: `AUTOMATIC EXTRACTION / API ERROR REPORT\nLicence Key: ${key}\nUser: ${alertObj.userName || acc.userName || 'N/A'}\nAPI ID / Route: ${alertObj.apiId || 'N/A'}\nProvider: ${alertObj.provider || 'auto'}\nError Code: ${errCode}\nQuery: ${alertObj.query || 'N/A'}\nDetail: ${errMsg}`.slice(0, 1950),
          requestId: 'auto-msg-' + key + '-' + errCode + '-' + String(Date.now()).slice(0, -4)
        };
        await fetch(PocketLeadsConfig.endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify(fallbackPayload),
          cache: 'no-store'
        }).catch(() => null);
      }
      sendResponse({ ok: true });
    } catch (_) {
      sendResponse({ ok: false });
    }
  })();
  return true;
});

}
