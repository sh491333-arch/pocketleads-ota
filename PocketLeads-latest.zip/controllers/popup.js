
var ngApp = angular.module("popupApp", []).config(function($sceProvider) {
  $sceProvider.enabled(false);
});

ngApp.controller("popupController", function($scope, $http,$sce) {
  
  $scope.developer = DEVELOPER_INFO;
  $scope.manifest = chrome.runtime.getManifest();
  $scope.welcome = WelcomeController.model;
  $scope.Tabs = Tabs;
  $scope.$fc = FoxCommon;
  $scope.$auth = Auth;
  $scope.$config = Config;
  
  $scope.loginPage = {
    email : "",
    password : "",
    isLoading : false,
  };
  
  $scope.local = $box.getDefaultLocalModel();
  
  $box.onLocalChange(data => {
    $box.getLocal(local => {
      $scope.$apply(() => {
        $scope.local = local;
      });
    });
  });
  
  $box.getLocal(local => {
    $scope.$apply(() => {
      $scope.local = { ...$scope.local, ...local };
    });
    
    $box.activeTab(tab => {
      $scope.$apply(() => {
        $scope.local.activeTabUrl = tab.url;
      });
    });
  });
  
  $scope.toggleTab = tab => {
    $scope.local.activeTab = tab;
    $scope.saveLocal();
    $scope.initiMaterialDesignComponents();
  };
  
  $scope.saveLocal = function() {
    $box.setLocal($scope.local);
  };
  
  $scope.send = function(action, data = {}) {
    $box.send(action, data);
  };
  
  $scope.saveUrlAsList = ()=>{
    $scope.local.urlList = $scope.local.urlListTextarea.split('\n').filter(x=>x.length);
    $scope.saveLocal();
  };
  
  $scope.initiMaterialDesignComponents = () => {
    MaterialDesignLite.init();
  };
  $scope.initiMaterialDesignComponents();
  
  // Licensing and login functionality removed.  The popup no longer
  // authenticates or activates a license key.  Provide stub handlers
  // that simply display a message to the user.  They were originally
  // triggered by login and logout buttons in the popup UI.
  $scope.login = () => {
    chrome.tabs.create({url:chrome.runtime.getURL('views/index.html')});
  };

  $scope.logout = () => {
    Auth.logout().then(()=>$scope.snackbar.show('License released.')).catch(e=>$scope.snackbar.show(e.message));
  };
  
  $scope.download = ()=>{
    $fc.downloadAs.text(JSON.stringify($scope.local.matchData),"bet365_collectedData");
  }
  
  $scope.clearData = () => {
    $scope.local.matchData = [];
    $scope.saveLocal();
    if (typeof $scope.refreshTable === "function") {
      $scope.refreshTable();
    }
    $scope.$applyAsync();
    $scope.snackbar.show("Extracted data cleared");
  };
  
  $scope.snackbar = {
    isShown : false,
    text: '',
    show:(text,closeAfterSec=3)=>{
      $scope.snackbar.text = text;
      $scope.snackbar.isShown = true;
      $scope.snackbar.closeAfter(closeAfterSec);
    },
    hide:()=>{
      $scope.snackbar.isShown = false;
    },
    closeAfter :(closeAfterSec)=>{
      setTimeout(()=>{
        $scope.$apply(()=>{
          $scope.snackbar.isShown = false;
        });
      },closeAfterSec*1000);
    }
  };
  
  $scope.init = ()=>{
    // Removed Auth.check – licensing is disabled in this build.  The
    // extension always operates in full mode and does not perform any
    // license validation.  We preserve the delay but perform no action.
    setTimeout(() => {
      /* no-op */
    }, $fc.randBetween(5000, 15000));

    setTimeout(() => {
      $scope.$apply(() => {
        $scope.showItemExtensionFooter = true;
      });
    }, 400);
  };
  
  // ---- Added scraping result handler ----
  $scope.handleScrapingResult = (status) => {
    if (status === "complete") {
      console.log("Scraping finished successfully!");
      // Terminal events are emitted only by the background controller.
      // This popup helper is UI-only and must not rebroadcast completion.
      $scope.snackbar.show("Scraping Complete!");
    } else if (status === "failed") {
      console.warn("Scraping failed or blocked!");
      // Failure state is owned by the controller; avoid another global event.
      $scope.snackbar.show("Scraping failed, retrying...");
    }
  };

  $scope.finishScraping = () => {
    $scope.handleScrapingResult("complete");
  };

  $scope.failScraping = () => {
    $scope.handleScrapingResult("failed");
  };

  $scope.init();
});
