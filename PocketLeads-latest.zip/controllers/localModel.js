$box.getDefaultLocalModel =  () => {
  let data = {
    
    _box : {
      localLogs : ""
    },
    
    _auth : {
      hasValidKey : false,
      licenseKey : ""
    },
    
    _stats : {
      appOpenCount : 0,
      tabsOpenCount : {},
    },
    
    _notifications : {
      last_show_notification_hash : "",
      list : []
    },
    
    _taskManager : {
      isWorking : false,
      activeTask : false,
      /**
       * ID of the currently open Google search tab created by the extension.
       * Stored so that subsequent queries can close the existing tab before
       * opening a new one.  Initialised to null.
       */
      searchTabId : null
    },
    
    _googleForm : {
      actionUrl : "",
      inputs : []
    },
    
    activeTabUrl: "",
    activeTab: "home",
    
    status : false, // CHANGED FROM true TO false
    
    swipeDirection :"right",
    delayLower : 10,
    delayUpper : 15,    
    // Base delay (in seconds) used for randomised pauses between
    // interactions during scraping.  A lower default of 1 second
    // provides a faster starting point while still introducing some
    // hesitation to mimic human behaviour.  Users can adjust this
    // value via the delay slider in the dashboard.
    delayTime : 1,
    
    collect : [],
    collectIsPreview: false,
    resultStoreCount: 0,
    resultStoreMigrated: false,
    keywordList : [],
    locationList : [],
    taskList:[],
    blackList : [],
    
    isScrapingEmail : false,

    /**
     * Indicates whether the extension is currently checking WhatsApp availability for
     * phone numbers.  This flag is used to disable the WhatsApp check button
     * during processing and to show appropriate status messages.  Defaults
     * to false.
     */
    isCheckingWhatsapp: false,

    /**
     * Stores the tab ID of the currently open WhatsApp Web tab created or
     * discovered by the extension.  Persisting this value allows the
     * extension to reuse an existing WhatsApp Web tab on subsequent
     * checks instead of always opening a new tab.  Initialised to null.
     */
    whatsappTabId: null,

    /**
     * When enabled the extension will attempt to scrape each Google Maps page
     * without opening individual business details.  If a phone number is
     * present directly in the list view, it will be extracted along with
     * basic details.  This significantly increases throughput on pages
     * where phone numbers are visible.  Disabled by default to preserve
     * compatibility with older layouts where phone numbers only appear in
     * the details panel.
     */
    // Old Normal/Fast modes are disabled. Keep the property for backward
    // compatibility with older saved settings, but the new TaskController
    // always uses the Apify direct dataset flow.
    fastMode: false,

    apifySettings: {
      provider: 'sheet-managed',
      apiKeyRow: 0,
      apiUsageLimit: 0,
      apifyKeyRow: 0,
      apifyUsageLimit: 0,
      // Provider limits: Scrappa one request; Serper pincode up to 7 pages; Google pincode up to 3.
      maxPagesPerSearch: 1,
      maxResultsPerSearch: 20,
      countryFilter: 'India',
      countryCodeFilter: 'IN',
      enforceCountryFilter: true,
      streamResults: true
    },

    apifyQueue: {
      status: 'idle',
      statusMessage: '',
      provider: '',
      startedAt: '',
      finishedAt: '',
      elapsedMs: 0,
      currentQuery: '',
      currentProfileUrl: '',
      totalPlaceIds: 0,
      totalApiResults: 0,
      currentPage: 0,
      totalPages: 0,
      totalTasks: 0,
      completedTasks: 0,
      apiTasksTotal: 0,
      apiTasksDone: 0,
      apiTasksFailed: 0,
      apiTasksSettled: 0,
      domTotal: 0,
      domProcessed: 0,
      domPending: 0,
      domRunning: 0,
      domSaved: 0,
      domFailed: 0,
      domSkipped: 0,
      apiSwitchCount: 0,
      scrapedCount: 0,
      failedCount: 0,
      filteredCount: 0,
      duplicateSkippedCount: 0,
      apiKeyRow: 0,
      apiUsageBefore: 0,
      apiUsageAfter: 0,
      apiUsageLimit: 0,
      apifyKeyRow: 0,
      apifyUsageBefore: 0,
      apifyUsageAfter: 0,
      apifyUsageLimit: 0,
      pendingPlaceIds: [],
      processing: null,
      completed: [],
      failed: [],
      retryCount: {},
      placeIdQueue: [],
      resumeAvailable: false,
      producerDone: false,
      consumerDone: false,
      domConcurrency: 1,
      domSuccessStreak: 0,
      domSuccessRate: 0,
      domTransientErrors: 0,
      lastCheckpointAt: '',
      resultStoreCount: 0,
      managedTabIds: []
    },
    showApifySettings: false,
    
    keywordTextarea : "",
    locationTextarea : "",
    activeQuery: "",
    activeKeyword : "",
    activeLocation : "",
    blackListTextarea : "",
    /**
     * The country selected by the user for Google Maps searches.  This
     * value is appended to each search query to refine results to the
     * specified country.  It defaults to "India" so that existing
     * workflows continue to target Indian businesses until the user
     * chooses another country.  Changing this value via the dashboard
     * persistently updates local storage and affects all subsequent
     * searches until modified again.
     */
    country: 'India',
    
    showLoginModal : false,

    /**
     * When true a modal is displayed to inform the user that the fast
     * scraping mode imposes a hard limit on the number of keywords and
     * locations.  The dashboard binds to this property to control the
     * visibility of the modal overlay.  It is initialised to false so
     * that the modal is hidden on first load.
     */
    showLimitModal: false,
    
  };
  return data;
};