> Historical document. Current release: START_HERE_10.15.0.md.

> Historical document. Current installation and behavior: START_HERE_10.14.0.md.

> Historical notes: START_HERE_10.13.2.md contains the current installation requirements, quota policy and known limitations.

# PocketLeads 10.13.1 — license race fix only

## Fixed

After a definitive inactive, expired, missing-license or revoked-device response, the worker now persists `requiresActivation: true` alongside `active: false`. It clears the prepared route, increments its request epoch, and rejects late success snapshots. The saved barrier survives worker/browser restart. Ordinary background refresh cannot clear it. Only a fresh, successful explicit activation started after the denial can clear it.

Rejected/superseded responses are also returned as non-success to activation and preflight callers, so the UI cannot treat a discarded response as accepted authorization. Network failures continue to preserve an existing valid activation.

After an administrator re-enables or renews a denied account, the user must submit the license again once. This is intentional; routine reopen for an already-valid account still uses the cached state.

## Validation

Five new race tests failed against 10.13.0, then passed against this fix:

1. Late provider success after each definitive denial type.
2. Refresh already in flight when account is disabled.
3. Saved denial surviving worker restart and subsequent successful refresh.
4. Ordinary refresh blocked, explicit successful activation allowed.
5. Activation already in flight before denial cannot return successful authorization.

All 34 existing and added regression tests pass. Tests use mocked Chrome/backend services. This is not live Chrome or deployed-backend certification. Existing export tests still have the coverage limitation identified by the audit.

## Install

Replace the existing unpacked extension folder and click Reload in Chrome Extensions. Keep the same extension installation to retain stored account data. If backend v34 from 10.13.0 is already deployed, this particular fix requires no backend redeployment: only account client code changed. If upgrading directly from an older backend, the original 10.13.0 backend deployment prerequisites still apply.

## Known unresolved findings

This targeted release does NOT fix the other four issues identified in the subsequent audit: Apify actor-start credit cap, Serper response-shape accounting gap, API row remaining limit_reached after concurrent refunds, and full export's fixed-column coverage. Do not treat this build as a production-ready certification.

Read UPDATE_10.13.0.md as historical deployment context, not as proof that those unresolved issues were corrected.
