# Comparison and merge decisions

Inputs compared: the uploaded **PocketLeads-v10.15.6-GHOST-PLACEID-FIX.zip** and the previously delivered **PocketLeads-v10.16.2-GHOST-FULL.zip**. The 10.16.2 source is the incremental base; the upload is a comparison source, not a replacement for newer recovery/credit code.

| Area | Decision |
| --- | --- |
| Uploaded Ghost frame entry | Adopted frame-only entry without brittle window.name / ancestorOrigins checks. Extension-origin, parent/source, nonce and newer document-token checks remain mandatory. |
| Uploaded Maps selectors | Adopted broader business heading and case-insensitive address/phone/website labels, data-item-id phone fallback and generic-title rejection in one shared parser. |
| Uploaded Place-ID links | Adopted actual search text plus query_place_id instead of literal `query=Google`. |
| Uploaded periodic challenge detection | Shared DOM waiter throttles mutation checks and checks challenge text once per second, reducing repeated body reads. |
| Uploaded credit labels | Activation popup and upgrade dialog now consistently show Available Credit and Purchased Credit. Existing profile DOM IDs stay aligned. |
| Uploaded two-frame worker pool | Not merged: it would conflict with the serial extraction queue and fresh-document safeguards. One hidden renderer or one owned tab runs at a time. |
| Uploaded older routing/account code | Not merged: it would remove the managed schema guard or weaken durable error/account handling. No legacy provider-key fallback is introduced. |
| Uploaded older request journal | Not merged: immutable attempt/request identities and duplicate-charge protection remain. |
| Uploaded older grid/hydration code | Not merged: newer FIFO updates, stale-generation guards, canonical hydration and storage errors remain. |
| Uploaded older backend/credit migration | Not merged: current single-file managed backend, authoritative common-credit reservation and recovery journals remain. No balances are summed or migrated. |
| New inactive-tab fallback | Isolated in libs/profile-tab.js; orchestrated by the existing worker bridge. Uses the shared parser and existing save path, not another dashboard/controller. |
| Startup optimization | Short-lived non-secret route reuse in the worker, shared refresh requests, one prewarm and fewer reads inside each locked backend reservation. Fresh paid authorization remains. |

## Why results could stay empty / slow

The earlier frame content script could exit before the handshake when identifying the parent through window.name / ancestorOrigins failed. Exact-case/limited selectors also missed alternative place-panel markup. When rendering failed, the worker retried three long hidden attempts with no active tab extraction path. Repeating that per Place ID caused lengthy empty progress.

The merged parser and handshake remove those local failure conditions. If Google still disallows embedding, the new bridge stops hidden work before using the authorized inactive-tab path. Failed embedding is remembered for the run. Live site behavior remains subject to native Chrome testing after installation.

Startup previously performed fresh account bootstraps again for icon, dashboard and Start when their requests did not overlap. One recently verified managed snapshot now serves preparation for those events; explicit refresh and server-side paid-request checks remain fresh. Reservations also previously read the assigned key pool twice while holding the same lock; one authoritative pool is now selected once within that operation.

## Ownership and data boundaries

- No visible-tab scraping runs concurrently with the hidden renderer.
- No user tab is searched for or reused. An extension-created tab that the user activates/navigates is relinquished.
- Chrome documentIds and a committed blank page separate profile documents. Late old-run responses are rejected after Stop/Clear.
- Session storage holds only owned tab metadata, never API keys. API secrets stay in the managed backend.
- One canonical ResultStore writes the extracted row before saved count/job state advances. Grid and CSV continue using it.
- Failed-final jobs from earlier iframe-only engines may get one upgraded attempt in a resumable extraction; this does not create another paid API request identity.
- No deployments, live paid API searches, Sheet writes or account/billing changes were performed for this update.
