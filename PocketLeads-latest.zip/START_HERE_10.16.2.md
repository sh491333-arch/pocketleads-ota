# PocketLeads 10.16.2 — Ghost Mode update

## Aapko kya karna hai

1. Existing extension folder ka backup lein, phir is ZIP ke **saare extension
   files** replace karein. Sirf Apps Script badalne se Ghost fixes install nahi
   hongi: offscreen.js, ghost-profile-frame.js, libs/ghost-parser.js aur worker
   bhi update hue hain.
2. Apps Script project mein root ka poora **apps_script_code.js** Code.gs mein
   paste karein. Purana separate managed.gs ho toh duplicate definitions ko
   backup ke baad hata dein; unrelated scripts preserve karein.
3. Existing **PL2_CONFIG, PL2_GENERATION, PL2_BILLING** Script Properties retain
   karein. Ye update balances, billing rates, API assignments ya licence limits
   reset nahi karta. Setup already successful hai toh dobara setup zaroori nahi.
4. Apps Script mein **Deploy → Manage deployments → existing deployment →
   Edit → New version → Deploy**. Same /exec URL rakhein. Naya URL use kiya hai
   toh extension config/runtime.js ka endpoint bhi wahi hona chahiye.
5. chrome://extensions par PocketLeads **Reload** karein. Dashboard dobara kholein.
   Extension uninstall ya saved data clear karna required nahi hai.
6. Ek small Google search se check karein. Google pehle chahiye toh user row ka
   Provider Priority `google_place,serper,scrappa` aur assigned Maps API ID valid
   hona chahiye. Common Available Credit positive hona chahiye.

**Simple setup check:** Apps Script editor ke function dropdown mein
`checkPocketLeadsSetup` select karke Run karein. Execution log mein configuration,
Sheets service aur billing status dikhega. Ye read-only hai; credit spend ya API
search nahi karta. Is output mein API keys nahi hoti.

## Ghost Mode mein changes

- Profile extraction iframe ke full load event ka wait nahi karti. Slow assets
  profile-ready handshake ko block nahi karte.
- First layer: bounded, 5-second, no-store HTML fetch and inert DOMParser.
- Second layer: JSON-only APP_INITIALIZATION_STATE parsing when a single explicit
  structured business record exists. Unknown positional arrays are not guessed.
- Third layer: hidden Maps iframe + content script + MutationObserver. Three
  total DOM attempts maximum; permanent failure skips the profile. Access
  challenges stop this provider and let the existing provider policy decide
  fallback; they are not retried for every remaining Place ID.
- A fresh iframe is used per profile. A document token plus request nonce binds
  replies to that exact page, including redirects after the first handshake.
- Service worker serializes Ghost requests. Whole offscreen document closes after
  20 profile attempts; next session waits 5 seconds. Ordinary profiles are paced
  2–4 seconds apart. These are resource/rate pacing measures, not a guarantee
  against Google blocking requests. The pacing does not delay Scrappa/Serper API
  result rendering.
- Stop cancels pending fetch/frame work and queued old-run requests. The durable
  job/request journals and existing Resume flow remain. Failed-final profiles
  are skipped as intended; use a new query after resolving an access problem.
- Results save to canonical IndexedDB before a job is marked saved. Existing
  paginated dashboard/CSV read that store; the UI does not run scraping DOM work.
- Each processed profile updates saved/failed/pending progress. Last extraction
  error remains visible, instead of turning failures into unexplained zero rows.
- Backend reports missing/invalid PL2_BILLING and several setup errors clearly.

## What remains the same

Licence activation, device count, expiry, common-credit reservation and recovery,
user provider order, API-key rotation, canonical results, history and exports.
Scrappa remains one page-0 call per query, maximum 200 results. Serper pincode
searches remain up to 7 pages. Partial usable results do not trigger fallback.
Existing dashboard files are views/index.html + controllers/index.js, worker is
controllers/background.js, and ResultStore/JobStore remain in
controllers/TaskManagerContainer.js. The extension was not replaced by a sample
popup/background project.

## Verification and limits

See tests/VALIDATION_10.16.2.md for exact results. The connected fixture runs
real hidden cross-origin DOM extraction, controller saving, Chromium IndexedDB
and grid rendering, including reopen. Chrome messaging is simulated in that
fixture. Native extension loading and live Google Maps could not be verified in
this environment; this package is not a certified live integration release.

Ghost code creates no visible Maps tabs and does not call the History API.
Offscreen documents are hidden extension pages, not incognito sessions. Fetch
uses no-store and omits cookies, but iframe subresources may still use browser
cache/cookies. A zero-cache guarantee is not available; this update does not
clear a customer's unrelated browser history/cache. Hidden frames are not
CAPTCHA-proof. No CAPTCHA/consent bypass or paid Places Details fallback is added.

Old START_HERE files and reports are historical; this file is current.
