/*
 * PocketLeads Ghost Mode profile frame.
 * This content script is intentionally small: it runs only in the hidden
 * Google Maps iframe created by offscreen.js and never opens a browser tab.
 */
(() => {
  const EXTENSION_ORIGIN = chrome.runtime.getURL('').replace(/\/$/, '');
  // Do not rely on window.name / ancestorOrigins surviving Google redirects.
  // Every message still requires the extension origin, parent and request token.
  if (window.top === window) return;
  if (window.__pocketLeadsGhostFrameInstalled) return;
  window.__pocketLeadsGhostFrameInstalled = true;

  const {parseProfile,waitForProfile}=PocketLeadsGhostParser;
  const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));

  const documentToken=crypto.randomUUID();
  let activeNonce = '', extracting = false;
  window.addEventListener('message', async event => {
    if (event.origin !== EXTENSION_ORIGIN || (event.source !== null && event.source !== window.parent)) return;
    const m = event.data;
    if (!m || typeof m.nonce !== 'string' || !m.nonce) return;
    if (m.type === 'PL_GHOST_HELLO') {
      if (!extracting) activeNonce = m.nonce;
      if (activeNonce === m.nonce) window.parent.postMessage({type:'PL_GHOST_READY',nonce:m.nonce,documentToken}, EXTENSION_ORIGIN);
      return;
    }
    if (m.type !== 'PL_GHOST_SCRAPE' || m.nonce !== activeNonce || m.documentToken!==documentToken || extracting) return;
    extracting = true;
    let result;
    try {
      await waitForProfile(document, m.payload && m.payload.timeoutMs);
      await wait(40);
      result = {ok:true,data:Object.assign(parseProfile(document, m.payload || {}), {_ghost_strategy:"iframe_dom"})};
    } catch(error) { result = {ok:false,error:String(error.message || error)}; }
    window.parent.postMessage(Object.assign({type:'PL_GHOST_RESULT',nonce:m.nonce,documentToken},result), EXTENSION_ORIGIN);
  });
})();
