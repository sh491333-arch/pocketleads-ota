> Historical document. Current release: START_HERE_10.15.0.md.

> Historical document. Current installation and behavior: START_HERE_10.14.0.md.

# PocketLeads 10.12.13

## Support Center rebuild

- Fixed the case-sensitive Apps Script URL typo that caused Support Center requests to return HTTP 404.
- Replaced the stacked tickets-and-form layout with two clear modes: ticket list and new-ticket composer.
- Added a fixed modal shell, fixed header, independently scrollable body and sticky form actions so Submit and Cancel remain reachable at short viewport heights.
- Kept New Ticket available even when ticket history cannot be loaded.
- Added ticket loading, empty, error and success states with clearer recovery text.
- Added attachment selection feedback and a Remove action.
- Preserved subject/message validation, 5 MB attachment validation, idempotent submission, private Drive upload, sheet URL storage, ticket refresh and ticket-detail viewing.

## Backend setup

The extension and support service now use the same Apps Script deployment URL. The web app must be deployed as **Execute as: Me** with access set to **Anyone**. Use the included `apps_script_code.js` and update the existing web-app deployment.
