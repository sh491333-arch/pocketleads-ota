# Managed backend deployment — 10.16.3

## Existing installation

The source retains the existing spreadsheet ID and deployed web-app URL.
The previously configured workbook is `Magic Licence Key`. Its two management tabs are
`User & API Assignment` and `API Key Management`, and the required headers
already exist. Setup automatically reuses these names; it also supports the
older `Sheet1` / `Sheet2` names. Do not rename or delete existing tabs merely
to match the examples.

A previous review reported "Anyone with the link — no sign-in required" sharing; this update did not recheck sharing.
Set the workbook containing API keys to Restricted for authorized administrators
before rollout; keys being absent from extension responses is not sufficient if the
management workbook itself is accessible to unintended readers. No sharing
permissions were changed in this update.

`PocketLeadsRequests`, `PocketLeadsChargedLeads` and the new
`PocketLeadsAttempts` are internal durable recovery journals, not additional
management sheets. Setup hides them. It preserves existing journal data and
does not delete support, legacy or unrelated tabs. Regular managed scraping
does not read the legacy Apify API configuration.

## Install server files

1. Open the existing Apps Script project connected to this deployment. Back up
   the current source, deployment version and Script Properties first.
2. Paste the ENTIRE `../apps_script_code.js` into the existing `Code.gs`.
   This is now the complete single-file backend, including managed routing.
   Remove any separately installed old `managed.gs` copy after backing it up;
   do not keep duplicate PocketLeads function definitions. Preserve unrelated
   project files. There is no second backend module to install.
3. Enable the Advanced Google Sheets v4 service, identifier **Sheets**. Merge
   `appsscript.json` with existing project settings; preserve any unrelated
   services. Its Drive scope is retained for existing support attachments.
4. If using other tab names, set Script Property `PL2_SHEET_NAMES` to JSON:
   `{"users":"User & API Assignment","keys":"API Key Management"}`.
5. Run `setupPocketLeadsManaged()` in the editor. It adds missing headers,
   extends the receipt storage, installs cache invalidation triggers and sets
   `PL2_CONFIG`. It does not reset balances, assign keys, migrate old credit
   buckets, change licence/device limits or alter expiry values.
6. Review each user's Available/Purchased Credit, assigned API IDs and Provider
   Priority. Existing reviewed balances must be retained. Never add old credit
   buckets together automatically. API IDs must be unique in key management;
   assignments are comma-separated. Priority accepts `google_place,serper,scrappa`
   or another explicit order. Trailing commas are ignored.
7. Configure **PL2_BILLING**, as below. Without a confirmed policy the backend
   fails closed, preventing an incorrectly billed paid request.
8. Run `checkPocketLeadsSetup()` for a read-only configuration/billing summary, then update the **existing** deployment
   to a new version, retaining its URL and existing access settings. If a new
   deployment URL is intentionally used, update `config/runtime.js` as well.
9. Complete the live checks in `../tests/VALIDATION_10.16.3.md` before rollout.

## Common-credit billing policy

Set Script Property `PL2_BILLING` to a JSON object with provider keys `scrappa`,
`serper` and `googlemaps`. Each policy has:

| Field | Meaning |
| --- | --- |
| confirmed | Must be true only after the operator verifies the provider plan |
| reserve | Maximum common-credit units that one upstream request may consume |
| success | Units consumed by a confirmed successful request |
| failure | Units consumed by a confirmed unsuccessful HTTP response |
| responseCredits | Optional; use Serper's validated integer `credits` response instead of fixed success units |

All amounts must be nonnegative integers and reserve must cover the maximum
possible billable cost. Calls, raw results returned and credits are independent
metrics. Results are **not** multiplied into a call charge. Purchased Credit
is an informational purchased total; scraping only changes Available Credit.
Zero Available Credit blocks new paid/provider calls, including a configured
zero-cost Google IDs search. Replaying an already-paid receipt remains allowed
for an active licence/device at zero balance.

`billing-policy.example.json` is an intentionally disabled template. Its numbers
are illustrative, not a statement of your provider prices or a ready-to-enable
production tariff. Verify actual subscription/endpoint behavior before setting
confirmed=true. Reserve enough for the largest expected Serper response charge
when using responseCredits=true. API keys belong only in the API Key Management
sheet; never paste them into the extension or this policy file.

## Cache and parallel processing

Edit/change triggers invalidate cached configuration. Programmatic Sheet changes
do not necessarily fire edit triggers: call `refreshPocketLeadsCache()` after
such administrative changes. Otherwise configuration expires within 60 seconds.
Licence, balance, assignment and key-status/call-limit rows are read again for
paid authorization; cache contents cannot authorize a credit spend.

Default concurrent upstream capacities are Scrappa 4, Serper 6 and Maps 4.
They are separate properties in PL2_CONFIG. Full lanes return PROVIDER_BUSY
before reservation and pause the affected client; Resume can try again. They
do not hold a global lock while a provider is running. Within one extraction,
providers run sequentially, once per provider, and partial usable results end
fallback. Google DOM extraction is serial across the hidden renderer and the owned inactive-tab fallback.

Counters, receipt state and credit are written in a single atomic Sheets batch
per financial transition. Provider HTTP calls run outside ScriptLock. This is
controlled concurrency, not a guarantee of 100 simultaneous Apps Script
executions. Quotas and deployment-owner limits must be measured during staged
live load testing. Do not increase lane limits blindly.

## Timeout, crash and request recovery

Never delete an unresolved receipt to retry a paid request. The request ID and
payload are durable and immutable. A timeout cannot prove that the provider
did not bill; the reservation remains held until confirmed. Fallback may use
remaining credit while that receipt is pending. Pending calls are not silently
resent on Resume, nor are reservations automatically refunded by age.

After checking provider logs, the administrator may run this editor-only
function with the actual values:

```js
reconcilePocketLeadsRequest(licenceKey, requestId, {
  providerConfirmed: true,
  creditsConsumed: confirmedCreditUnits,
  resultsReturned: confirmedRawResultCount,
  response: confirmedSafeResponse
});
```

The optional response must be the correct result object for that request. Do
not invent a successful response or return provider secrets. The operation is
idempotent, settles against the original reservation, and does not reinterpret
legacy billing receipts. If the confirmed cost exceeds reserve, investigate
and correct the policy; the helper will not silently debit an excess amount.

A crash between durable reservation and HTTP dispatch may leave a counted
attempt with no provider call. This cannot be resolved from elapsed time alone;
compare provider logs and reconcile as an interrupted attempt. Keep journal
backups and retain unresolved records through deployments and rollbacks.

## Google profile workflow and legacy modules

The offscreen extractor tries a 3-second bounded HTML fetch / safe JSON parser and one hidden iframe attempt. If embedding fails, it closes that renderer before switching to one owned inactive tab. The worker remembers the fallback for the run. Each tab profile is isolated by a blank-document navigation and Chrome documentId targeting; two bounded tab attempts are allowed after the first hidden attempt. Renderers recycle after 20 profiles; tabs also recycle after 2 minutes. Stop/Clear/completion cleans up extension-owned renderers. A tab the user activates or navigates is relinquished.

The Places search still requests only `places.id,nextPageToken`; profile fields come from the shared DOM adapter and enter the existing IndexedDB save flow. API-result counters represent IDs returned; processed/saved/failed profiles are separate job metrics. Consent/verification stops extraction. Inactive tabs may be visible in the tab strip and may create history/cache; this is not an incognito or CAPTCHA-proof feature.

This release shares a verified, non-secret route for up to 30 seconds between extension startup events. Manual refresh and paid authorization remain authoritative. Within a locked reservation the backend reuses its freshly read auth result and assigned-key pool instead of reading them again. It does not use cross-request cached credit for spending.

Native Chrome injection, live Maps markup/framing, production Sheets and actual provider billing must be checked after deployment. See the current validation report; fixture tests are not live integration certification.

Legacy activation/device/expiry and recovery handlers remain. The new regular
scraping contract routes only Google Places, Serper and Scrappa. Optional legacy
Apify/WhatsApp API paths are not certified under managed routing; do not promise
compatibility for these until their separate integration checks pass. Existing
local WhatsApp UI/source has not been rewritten.

## Rollback

Stop jobs first and preserve pending receipts. Restore the previous source and
deployment version together with the previous extension build. Review managed
reservations before disabling PL2_CONFIG or restoring any older credit columns.
Do not restore an old workbook balance over credit spent since the backup.
