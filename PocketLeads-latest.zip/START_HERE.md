# PocketLeads 10.16.3

Current installation and behavior: **START_HERE_10.16.3.md**.

Update both the full extension folder and the included single-file `apps_script_code.js` backend. Keep existing licence, credit balances and reviewed Script Properties. Deploy the backend yourself using the existing deployment URL, then reload the extension.

Merge review: **MERGE_REVIEW_10.16.3.md**.
Test results and live-integration limits: **tests/VALIDATION_10.16.3.md**.

Other versioned START_HERE/UPDATE files and test reports are historical.
