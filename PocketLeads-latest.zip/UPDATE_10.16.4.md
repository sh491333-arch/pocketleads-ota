# PocketLeads v10.16.4 release notes

## Fixes

- One direct Google Place-ID navigation: `https://www.google.com/maps/place/?q=place_id:<PLACE_ID>`.
- Removed visible Google Maps profile-tab fallback from the Ghost path; stale `open_tab` messages targeting Google Maps are now rejected.
- Added durable cleanup for tab IDs recorded by older versions. Cleanup is restricted to known IDs and safe inactive-tab URL types; active/user-navigated tabs are never closed.
- Cleanup now occurs before Start/Stop/Complete clear the saved legacy tab IDs, fixing a lifecycle ordering bug.
- Legacy profile URL builders and Place-ID parsers now understand the direct `q=place_id:` form.
- Keeps two bounded hidden Ghost workers, per-profile iframe disposal, immediate dashboard progress, Serper first-page save, and short Scrappa save batches.

## Not changed

- Provider Priority and backend routing policy, licence/device checks, API key assignment, credit reservation/settlement, result normalization, and IndexedDB save path.
- Serper/Scrappa provider calls are not blindly parallelized because server-side request receipts/credit accounting must stay consistent. Results are streamed as responses arrive. Actual provider/network latency is not controlled by the extension, so a real lead appearing within 10 seconds cannot be guaranteed.
- CAPTCHA, consent, and Google access controls are not bypassed.

## Verification

- `node --test tests/*.test.cjs`: 193 passed, 0 failed.
- Syntax check: all shipped `.js` and `.cjs` files passed `node --check`.
- Playwright/Chromium fixture and live Google Maps validation were not run because Playwright/Chromium is not available in this environment.
