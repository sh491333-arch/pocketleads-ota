> Historical document. Current release: START_HERE_10.15.0.md.

> Historical document. Current installation and behavior: START_HERE_10.14.0.md.

# PocketLeads 10.12.10 — Support Center & Sync Fix

## Root cause found
The support system and ticket sync were **not working because the client-side
JavaScript that drives the support center was missing** from the extension
package. The previous cleanup (v98) removed it along with "obsolete backup
files", leaving behind only:

- the **CSS** for the support modal (`.pl-support-modal`, `.pl-ticket-form-modal`, `.pl-ticket-detail-modal`, …) in `assets/css/custom-styles.css`
- the **Apps Script backend** (`submitSupportTicket_`, `getSupportTickets_`, `supportSheet_`) in `apps_script_code.js`
- the **MV3 service-worker transport** (`pocketleads_support_request` handler) in `controllers/background.js`

…but **no code in the dashboard that opens the modal, submits a ticket, or
lists/syncs existing tickets**. So clicking any "Support" button did nothing,
no ticket could be created, and the ticket list never synced from the backend.
This is exactly the "support system kaam nahi kar raha, sync nahi ho raha"
symptom.

## Fix applied

### 1. NEW: `assets/js/support-center.js` (self-contained support center)
A CSP-safe, dependency-free module that:
- Auto-injects the support modal + ticket-detail modal markup (matching the
  existing CSS classes) so it works even if `views/index.html` has no support
  markup.
- Adds a floating trigger button (bottom-right) **and** hooks into any
  existing trigger (`#plSupportBtn`, `.pl-support-trigger`, `[data-pl-support]`)
  plus a `pocketleads:open-support` custom event for Angular-injected buttons.
- Reads the **licence key + deviceId** from `chrome.storage.local` so requests
  are bound to the activated installation (the backend `doPost` enforces
  `deviceId` before `submitticket` / `getsupporttickets`).
- **Submits tickets** through the MV3 transport
  (`chrome.runtime.sendMessage({action:'pocketleads_support_request', method:'POST', …})`)
  with a `requestId` for backend idempotency (the Apps Script `submitSupportTicket_`
  uses `LockService` + the AttachmentURL column as the client request id).
- **Lists / syncs existing tickets** via the same transport with
  `action=getsupporttickets`, auto-refreshing every time the modal opens or the
  licence changes.
- Renders ticket rows with status badges (Open / Pending / Closed), empty
  state, error state, a new-ticket form (subject/message/email with the same
  length limits the backend enforces: 3–120 / 10–2000), and a ticket-detail
  modal. Escape / backdrop closes the modals.

### 2. `controllers/background.js` — robust response parsing (additive)
The `pocketleads_support_request` handler now parses the Apps Script JSON
response in the service worker and returns it as `data` (alongside the
existing `text`/`status`/`finalUrl`, so it is backward compatible). It also
detects HTML/error pages and returns a clear error instead of letting the
client choke on a non-JSON body. This removes the last redirect/CORS edge case
for the dashboard client.

## Install
1. Replace these files in your existing unpacked extension folder:
   - `assets/js/support-center.js`  (NEW)
   - `controllers/background.js`    (updated)
2. Add ONE script tag to `views/index.html`, near the other `<script>` tags
   in the `<body>` (e.g. after `custom-ui.js`):
   ```html
   <script src="/assets/js/support-center.js"></script>
   ```
   If your `views/index.html` already references support markup, the module
   adopts it automatically — you only need the script tag.
3. Go to `chrome://extensions`, click **Reload** on the extension.
4. Open the dashboard. A floating support button appears bottom-right; or use
   your existing navbar/profile "Support" button. Activate your licence if you
   have not — the support center needs an active key to open and sync tickets.

## Validation
- `node --check` passes for `assets/js/support-center.js` and
  `controllers/background.js`.
- Client params match the Apps Script contract exactly:
  `submitticket` → `{action, key, deviceId, subject, message, user, requestId}`
  with subject 3–120 / message 10–2000; `getsupporttickets` →
  `{action, key, deviceId}`. Response fields consumed (`ticketId`, `duplicate`,
  `ticket`, `tickets`, `count`) match `submitSupportTicket_` / `getSupportTickets_`.

## Note on live testing
Browser rendering, Apps Script deployment, and live ticket submission could not
be exercised in this sandbox. Before production use, verify: open support modal,
submit a ticket, refresh, open ticket detail, and confirm the ticket appears in
the backing Google Sheet "Tickets" tab. If the modal shows "The support backend
returned an HTML page instead of JSON", re-publish the Apps Script web app with
"Execute as: me" and "Who has access: Anyone".
