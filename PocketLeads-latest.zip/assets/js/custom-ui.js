// Custom UI behaviours for the dashboard.  This script must be
// included via <script src="/assets/js/custom-ui.js"></script> to comply
// with Chrome extension Content Security Policy (CSP).  It handles
// ripple effects on buttons and provides a multi-theme selector with
// event delegation so it still works after Angular renders the DOM.

document.addEventListener('DOMContentLoaded', function() {
  // Theme state is owned by pocketleads-theme.js.
  if (window.pocketleadsTheme) window.pocketleadsTheme.set(window.pocketleadsTheme.get());

  // Ripple effect on all buttons.  Creates a temporary span that
  // animates from the click point outward.
  var buttons = document.querySelectorAll('.btn');
  buttons.forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      var rect = btn.getBoundingClientRect();
      var ripple = document.createElement('span');
      var size = Math.max(rect.width, rect.height);
      ripple.classList.add('ripple');
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
      ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
      btn.appendChild(ripple);
      setTimeout(function() {
        ripple.remove();
      }, 600);
    });
  });

  // Theme selection using event delegation.  Clicking the palette
  // button toggles the dropdown.  Selecting an option updates
  // data-theme on the body and persists the choice.  Clicking
  // anywhere else hides the dropdown.
  document.addEventListener('click', function(e) {
    var themeDropdown = document.getElementById('themeDropdown');
    var paletteBtn = e.target.closest('#themeBtn');
    if (paletteBtn) {
      e.stopPropagation();
      if (themeDropdown) {
        themeDropdown.classList.toggle('show');
      }
      return;
    }
    // Theme option detection
    var themeItem = e.target.closest('.theme-item');
    if (themeItem && themeDropdown && themeDropdown.contains(themeItem)) {
      e.stopPropagation();
      var theme = themeItem.getAttribute('data-theme');
      if (theme) {
        applyDashboardTheme(theme);
      }
      themeDropdown.classList.remove('show');
      return;
    }
    // Keep theme dropdown open when clicking inside but not on a theme item
    if (themeDropdown && themeDropdown.contains(e.target)) {
      return;
    }

    // Settings dropdown logic
    var settingsDropdown = document.getElementById('settingsDropdown');
    var settingsBtn = e.target.closest('#settingsBtn');
    if (settingsBtn) {
      e.stopPropagation();
      if (settingsDropdown) {
        settingsDropdown.classList.toggle('show');
      }
      return;
    }
    // Keep settings dropdown open if clicking inside it
    if (settingsDropdown && settingsDropdown.contains(e.target)) {
      return;
    }

    // Clicked outside both dropdowns: close them
    if (themeDropdown) {
      themeDropdown.classList.remove('show');
    }
    if (settingsDropdown) {
      settingsDropdown.classList.remove('show');
    }
  }, false);
    // Contact us buttons within the settings dropdown.  When clicked
    // they reveal the associated hidden email address.  We use
    // querySelectorAll to attach to all such buttons (should there
    // be multiple in the future).  The email element is located
    // within the same dropdown container.
    var contactButtons = document.querySelectorAll('.contact-us-btn');
    contactButtons.forEach(function(btn) {
      btn.addEventListener('click', function(ev) {
        ev.stopPropagation();
        var email = btn.parentElement.querySelector('.contact-email');
        if (email) {
          email.style.display = (email.style.display === 'none' || email.style.display === '') ? 'block' : 'none';
        }
      });
    });

      // Privacy policy acknowledgement (two‑layer flow).
    // When a valid licence becomes active and the user has not yet
    // accepted the privacy policy, we first display a short summary
    // modal.  The user can click Continue or “Read full policy” to
    // view the full policy.  In the full modal the Accept button
    // remains disabled until the user scrolls to the bottom of the
    // content (with a small dwell time).  Acceptance metadata is
    // stored in chrome.storage.local for audit purposes and also
    // displayed in the Settings dropdown.
    (function() {
      var summaryModal = document.getElementById('privacyModal');
      var fullModal = document.getElementById('privacyFullModal');
      var summaryContinueBtn = document.getElementById('privacySummaryContinueBtn');
      var readFullLink = document.getElementById('privacyReadFullLink');
      var fullScroll = document.getElementById('privacyFullScroll');
      var progressBar = document.getElementById('privacyProgressBar');
      var fullAcceptBtn = document.getElementById('privacyFullAcceptBtn');
      var fullCancelBtn = document.getElementById('privacyFullCancelBtn');

        // Elements for the summary modal’s accessible acceptance flow.
        var summaryReadCheckbox = document.getElementById('privacySummaryReadCheckbox');
        var summaryAcceptBtn = document.getElementById('privacySummaryAcceptBtn');


        // Define the current policy version.  When this value changes,
        // users will be prompted to re‑accept the policy even if they
        // previously accepted an older version.
        var CURRENT_POLICY_VERSION = '2025-10-23';

        // Checkbox used as an accessibility fallback for users who
        // cannot scroll or prefer not to.  When checked, it indicates
        // the user has read the policy and triggers the accept logic.
        var readCheckbox = document.getElementById('privacyReadCheckbox');

      // Function to show summary modal if acceptance not yet recorded.
      function showSummaryIfNeeded() {
        if (summaryModal) {
          if (summaryReadCheckbox) summaryReadCheckbox.checked = false;
          if (summaryAcceptBtn) summaryAcceptBtn.disabled = true;
          summaryModal.style.display = 'flex';
        }
      }

      window.triggerPrivacyPolicyPrompt = function(forceShow) {
        if (forceShow) {
          try {
            localStorage.removeItem('privacyAccepted');
            if (chrome && chrome.storage && chrome.storage.local) {
              chrome.storage.local.remove('privacyAcceptance', function() {
                showSummaryIfNeeded();
              });
              return;
            }
          } catch (e) {}
          showSummaryIfNeeded();
          return;
        }
        maybeShowSummary();
      };

      // Update the acceptance record display in the settings dropdown.
      function updateAcceptanceRecordDisplay(record) {
        var recordEl = document.getElementById('privacyRecord');
        if (!recordEl) return;
        if (record && record.accepted) {
          var dateEl = document.getElementById('privacyRecordDate');
          var verEl = document.getElementById('privacyRecordVersion');
          var extEl = document.getElementById('privacyRecordExtVer');
          // Format timestamp in a human‑readable way (use locale string).
          try {
            var d = new Date(record.acceptedAt);
            dateEl.textContent = d.toLocaleString();
          } catch (e) {
            dateEl.textContent = record.acceptedAt;
          }
          verEl.textContent = record.policyVersion || '—';
          extEl.textContent = record.extensionVersion || '—';
          recordEl.style.display = 'block';
        } else {
          recordEl.style.display = 'none';
        }
      }

      // Retrieve acceptance record on load.
      function fetchAcceptanceRecord(callback) {
        try {
          if (chrome && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get('privacyAcceptance', function(res) {
              var rec = res && res.privacyAcceptance;
              callback(rec);
            });
          } else {
            // Fallback: nothing stored.
            callback(null);
          }
        } catch (err) {
          callback(null);
        }
      }

      // Show summary modal only after licence becomes active and no acceptance recorded.
      function maybeShowSummary() {
        fetchAcceptanceRecord(function(rec) {
          if (rec && rec.accepted && rec.userConfirmed === true) {
            // If the stored policy version matches the current one, we
            // consider it accepted and skip the prompt.  Otherwise
            // show the summary again to force re‑acceptance of the new
            // policy.  In either case update the record display.
            updateAcceptanceRecordDisplay(rec);
            if (rec.policyVersion === CURRENT_POLICY_VERSION) {
              return;
            }
          } else {
            // No acceptance record: hide any record display.
            updateAcceptanceRecordDisplay(null);
          }
          // Either not accepted or policy version is outdated; show summary.
          showSummaryIfNeeded();
        });
      }

      // Watch for licence activation.
      try {
        if (chrome && chrome.storage && chrome.storage.local) {
          // Check licence state on load
          chrome.storage.local.get('license', function(res) {
            var lic = res && res.license;
            if (lic && lic.active) {
              maybeShowSummary();
            }
          });
          // Listen for changes to licence state
          chrome.storage.onChanged.addListener(function(changes, areaName) {
            if (areaName === 'local' && changes.license) {
              var newLic = changes.license.newValue;
              if (newLic && newLic.active) {
                maybeShowSummary();
              }
            }
          });
        }
      } catch (err) {
        // If Chrome APIs are unavailable (e.g. content script), do nothing.
      }

      // Handler to open the full modal (called from summary).
      function openFullModal() {
        if (summaryModal) summaryModal.style.display = 'none';
        if (fullModal) {
          // Reset progress and disable Accept button
          if (progressBar) progressBar.style.width = '0%';
          if (fullAcceptBtn) fullAcceptBtn.disabled = true;
          // Reset scroll and dwell state
          scrolledToBottom = false;
          if (dwellTimer) {
            clearTimeout(dwellTimer);
            dwellTimer = null;
          }
          fullModal.style.display = 'flex';
        }
      }

      // Attach click handlers to summary continue and read link.
      if (summaryContinueBtn) {
        summaryContinueBtn.addEventListener('click', function(ev) {
          ev.stopPropagation();
          openFullModal();
        });
      }
      if (readFullLink) {
        readFullLink.addEventListener('click', function(ev) {
          ev.preventDefault();
          ev.stopPropagation();
          openFullModal();
        });
      }

      // Variables to track scroll progress and dwell timer.
      var scrolledToBottom = false;
      var dwellTimer = null;

      // Scroll progress tracking.
      if (fullScroll) {
        fullScroll.addEventListener('scroll', function() {
          var totalScrollable = fullScroll.scrollHeight - fullScroll.clientHeight;
          if (totalScrollable <= 0) {
            // Content fits; enable immediately.
            if (progressBar) progressBar.style.width = '100%';
            enableAcceptAfterDwell();
            return;
          }
          var progress = Math.min(1, fullScroll.scrollTop / totalScrollable);
          if (progressBar) {
            progressBar.style.width = (progress * 100) + '%';
          }
          if (progress >= 0.98 && !scrolledToBottom) {
            scrolledToBottom = true;
            enableAcceptAfterDwell();
          }
        });

        // Listen for keyboard navigation for accessibility.  If the user
        // presses the End key while focused on the scroll container, we
        // treat it as if they scrolled to the bottom.  Also handle
        // PageDown to accommodate alternate scroll shortcuts.
        fullScroll.addEventListener('keydown', function(e) {
          if (e.key === 'End' || e.key === 'PageDown') {
            // Mark as scrolled to bottom and update progress bar.
            if (!scrolledToBottom) {
              scrolledToBottom = true;
              if (progressBar) progressBar.style.width = '100%';
              enableAcceptAfterDwell();
            }
          }
        });
      }

      // Enable the Accept button immediately.  The dwell timer has been removed
      // so that once the user reaches the bottom of the policy (or uses
      // alternative accessibility mechanisms), the Accept button becomes
      // clickable without delay.
      function enableAcceptAfterDwell() {
        // Clear any existing timer and enable immediately.
        if (dwellTimer) {
          clearTimeout(dwellTimer);
          dwellTimer = null;
        }
        if (fullAcceptBtn) fullAcceptBtn.disabled = false;
      }

      // Handle Accept button click: record acceptance metadata.
      if (fullAcceptBtn) {
        fullAcceptBtn.addEventListener('click', function() {
          var now = new Date().toISOString();
          var policyVersion = CURRENT_POLICY_VERSION;
          var extensionVersion = 'unknown';
          try {
            var manifest = chrome.runtime.getManifest();
            extensionVersion = manifest && manifest.version;
          } catch (err) {}
          var record = {
            accepted: true,
            userConfirmed: true,
            acceptedAt: now,
            policyVersion: policyVersion,
            extensionVersion: extensionVersion
          };
          try {
            if (chrome && chrome.storage && chrome.storage.local) {
              chrome.storage.local.set({ privacyAcceptance: record }, function() {
                localStorage.setItem('privacyAccepted', 'true');
                updateAcceptanceRecordDisplay(record);
              });
            } else {
              localStorage.setItem('privacyAccepted', 'true');
            }
          } catch (err) {
            localStorage.setItem('privacyAccepted', 'true');
          }
          if (fullModal) fullModal.style.display = 'none';
        });
      }

      // Handle Cancel button click: return to summary.
      if (fullCancelBtn) {
        fullCancelBtn.addEventListener('click', function() {
          if (fullModal) fullModal.style.display = 'none';
          if (summaryModal) summaryModal.style.display = 'flex';
          // Reset state
          if (progressBar) progressBar.style.width = '0%';
          scrolledToBottom = false;
          if (dwellTimer) {
            clearTimeout(dwellTimer);
            dwellTimer = null;
          }
          if (fullAcceptBtn) fullAcceptBtn.disabled = true;
        });
      }

      // Immediately fetch acceptance record to show metadata in settings.
      fetchAcceptanceRecord(function(rec) {
        updateAcceptanceRecordDisplay(rec);
      });

      // If a read checkbox is present (accessibility fallback), allow
      // users to indicate they have read the policy without scrolling.
      if (readCheckbox) {
        readCheckbox.addEventListener('change', function() {
          if (readCheckbox.checked && !scrolledToBottom) {
            // Set progress bar to full and trigger dwell timer.
            scrolledToBottom = true;
            if (progressBar) progressBar.style.width = '100%';
            enableAcceptAfterDwell();
          }
          if (!readCheckbox.checked) {
            // If unchecked again, reset scroll state and disable Accept.
            scrolledToBottom = false;
            if (progressBar) progressBar.style.width = '0%';
            if (dwellTimer) {
              clearTimeout(dwellTimer);
              dwellTimer = null;
            }
            if (fullAcceptBtn) fullAcceptBtn.disabled = true;
          }
        });
      }

      // --- Summary modal acceptance logic ---
      // Listen for the summary read checkbox.  When the user checks
      // this box, enable or disable the Accept button immediately.
      if (summaryReadCheckbox && summaryAcceptBtn) {
        summaryReadCheckbox.addEventListener('change', function() {
          if (summaryReadCheckbox.checked) {
            summaryAcceptBtn.disabled = false;
          } else {
            summaryAcceptBtn.disabled = true;
          }
        });
      }

      // Handle click on the summary accept button.  This records
      // acceptance metadata immediately (without opening the full
      // policy) and hides the summary modal.  Users may still read
      // the full policy via the separate "Read full policy" button.
      if (summaryAcceptBtn) {
        summaryAcceptBtn.addEventListener('click', function() {
          // Only proceed if the button is enabled
          if (summaryAcceptBtn.disabled) return;
          var now = new Date().toISOString();
          var policyVersion = CURRENT_POLICY_VERSION;
          var extensionVersion = 'unknown';
          try {
            var manifest = chrome.runtime.getManifest();
            extensionVersion = manifest && manifest.version;
          } catch (err) {}
          var record = {
            accepted: true,
            userConfirmed: true,
            acceptedAt: now,
            policyVersion: policyVersion,
            extensionVersion: extensionVersion
          };
          try {
            if (chrome && chrome.storage && chrome.storage.local) {
              chrome.storage.local.set({ privacyAcceptance: record }, function() {
                localStorage.setItem('privacyAccepted', 'true');
                updateAcceptanceRecordDisplay(record);
              });
            } else {
              localStorage.setItem('privacyAccepted', 'true');
            }
          } catch (err) {
            localStorage.setItem('privacyAccepted', 'true');
          }
          // Hide the summary modal after acceptance
          if (summaryModal) summaryModal.style.display = 'none';
        });
      }
    })();
});

// Local icon fallback: no web-font dependency. This keeps legacy Material Icon markup
// usable while newer profile controls use inline SVGs directly.
(function(){
  'use strict';
  var MAP = {"play_arrow": "M8 5l11 7-11 7z", "stop": "M6 6h12v12H6z", "download": "M12 3v12m-5-5 5 5 5-5M5 16v5h14v-5", "phone_android": "M7 2h10v20H7zM10 18h4", "delete": "M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7m4-7v7", "history": "M3 11a9 9 0 1 1 2 7M3 4v7h7m2-4v6l4 2", "phone": "M5 3h4l2 5-3 2c2 3 3 4 6 6l2-3 5 2v4c-8 4-20-8-16-16z", "search": "M10 3a7 7 0 1 0 0 14 7 7 0 0 0 0-14m5 12 6 6", "close": "m5 5 14 14M5 19 19 5", "mail": "M3 5h18v14H3zM3 5l9 7 9-7", "refresh": "M20 10a8 8 0 1 0-2 8M20 3v7h-7", "hourglass_top": "M6 3h12M6 21h12M7 3v4l10 10v4M17 3v4L7 17v4", "chevron_left": "m15 5-7 7 7 7", "chevron_right": "m9 5 7 7-7 7", "add": "M12 4v16M4 12h16", "settings": "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2"};
  Object.assign(MAP, {"palette": "M12 3a9 9 0 1 0 0 18h2a2 2 0 0 0 0-4h-1a2 2 0 0 1 0-4h5c5 0 2-10-6-10z", "logout": "M9 3H3v18h6M9 12h12m-5-5 5 5-5 5", "person": "M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8M4 21v-2a8 8 0 0 1 16 0v2", "verified": "m4 12 5 5L20 6", "policy": "m12 2 8 4v7l-8 9-8-9V6z", "support_agent": "M4 14v-3a8 8 0 0 1 16 0v7h-6M3 11h4v7H3zM17 11h4v7h-4z", "description": "M5 2h9l5 5v15H5zM14 2v6h5M8 12h8M8 16h8", "inbox": "M3 4h18v16H3zM3 13h5l2 3h4l2-3h5", "more_vert": "M12 4v2m0 5v2m0 5v2", "filter_alt": "M3 4h18l-7 8v7l-4 2V12z", "groups": "M9 4a3 3 0 1 0 0 6 3 3 0 0 0 0-6M3 21v-4a6 6 0 0 1 12 0v4M17 4a3 3 0 0 1 0 6m1 3a5 5 0 0 1 3 5v3", "vpn_key": "M8 6a5 5 0 1 0 0 10 5 5 0 0 0 0-10M13 11h9v4h-4v-4", "visibility": "M2 12c6-10 14-10 20 0-6 10-14 10-20 0zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6", "grid_view": "M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z", "arrow_back": "M21 12H3m7-7-7 7 7 7"});
  MAP.article = MAP.description; MAP.play_circle = MAP.play_arrow;
  function applyOne(el){
    if (!el || el.nodeType !== 1 || !el.classList.contains('material-icons')) return;
    var raw = String(el.textContent || '').trim();
    if (!raw || raw.indexOf('{{') >= 0) return;
    var path = MAP[raw];
    if (!path) return;
    if(el.getAttribute('data-pl-icon-name') === raw) return;
    el.setAttribute('data-pl-icon-name', raw);
    el.setAttribute('aria-hidden', 'true');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="'+path+'"/></svg>';
    el.style.setProperty('--pl-icon', 'url("data:image/svg+xml,'+encodeURIComponent(svg)+'")');
  }
  function scan(root){
    try {
      if (root && root.matches && root.matches('.material-icons')) applyOne(root);
      var list = (root || document).querySelectorAll ? (root || document).querySelectorAll('.material-icons') : [];
      Array.prototype.forEach.call(list, applyOne);
    } catch(e){}
  }
  function start(){
    scan(document);
    try {
      var obs = new MutationObserver(function(mutations){
        for (var i = 0; i < mutations.length; i++) {
          var m = mutations[i];
          if (m.addedNodes && m.addedNodes.length) {
            for (var j = 0; j < m.addedNodes.length; j++) {
              var n = m.addedNodes[j];
              if (n.nodeType === 1) scan(n);
            }
          }
        }
      });
      obs.observe(document.documentElement || document.body, {subtree:true, childList:true});
    } catch(e){}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true}); else start();
})();

// Theme compatibility shim. The single source of truth is assets/js/pocketleads-theme.js.
(function(){
  if(window.pocketleadsTheme){
    window.applyDashboardTheme=window.pocketleadsTheme.set;
    window.updateThemeToggleIcon=function(theme){window.pocketleadsTheme.set(theme);};
    window.POCKETLEADS_THEMES=['dark','light'];
  }
})();


// Close buttons for privacy dialogs.  These only dismiss the UI; acceptance still uses the existing flow.
document.addEventListener('DOMContentLoaded',function(){
  var summary=document.getElementById('privacyModal'),full=document.getElementById('privacyFullModal');
  var sc=document.getElementById('privacySummaryCloseBtn'),fc=document.getElementById('privacyFullCloseBtn');
  if(sc&&summary)sc.addEventListener('click',function(){summary.style.display='none';});
  if(fc&&full)fc.addEventListener('click',function(){full.style.display='none';});
});


// v10.12.8: delegated tactile ripple for Angular-rendered buttons.
(function(){
  if (document.documentElement.dataset.plRippleBound === '1') return;
  document.documentElement.dataset.plRippleBound = '1';
  document.addEventListener('pointerdown', function(e){
    if (document.documentElement.getAttribute('data-view-mode') === 'mobile' || window.innerWidth <= 768) return;
    var target = e.target && e.target.closest ? e.target.closest('.btn, .ui.button, .pl-grid-clear-filters, .pl-grid-page-actions button') : null;
    if (!target || target.disabled || target.getAttribute('aria-disabled') === 'true') return;
    var rect = target.getBoundingClientRect();
    var ripple = document.createElement('span');
    var size = Math.max(rect.width, rect.height) * 1.15;
    ripple.className = 'pl-tactile-ripple';
    ripple.style.width = size + 'px';
    ripple.style.height = size + 'px';
    ripple.style.left = (e.clientX - rect.left - size/2) + 'px';
    ripple.style.top = (e.clientY - rect.top - size/2) + 'px';
    target.appendChild(ripple);
    window.setTimeout(function(){ if (ripple && ripple.parentNode) ripple.parentNode.removeChild(ripple); }, 520);
  }, false);
})();

