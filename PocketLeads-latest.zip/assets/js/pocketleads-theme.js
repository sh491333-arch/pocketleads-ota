(function(){
  'use strict';

  const KEY = 'dashboard-theme';
  const DEFAULT = 'dark';
  const allowed = new Set(['dark','light']);

  const VIEW_KEY = 'pocketleads-view-mode';
  const allowedViews = new Set(['desktop','mobile']);
  const root = document.documentElement;

  function normalize(value){
    const v = String(value || '').toLowerCase().trim();
    return allowed.has(v) ? v : DEFAULT;
  }

  function normalizeView(value){
    const v = String(value || '').toLowerCase().trim();
    return allowedViews.has(v) ? v : 'desktop';
  }

  function safeStorageGet(key){
    try { return localStorage.getItem(key || KEY); } catch (_) { return null; }
  }

  function read(){
    const stored = safeStorageGet(KEY);
    if(stored) return normalize(stored);

    const attr = root && root.getAttribute('data-theme');
    if(attr) return normalize(attr);

    return DEFAULT;
  }

  function readView(){
    const stored = safeStorageGet(VIEW_KEY);
    if(stored && allowedViews.has(String(stored).toLowerCase().trim())) {
      return normalizeView(stored);
    }
    const attr = root && root.getAttribute('data-view-mode');
    if(attr && allowedViews.has(String(attr).toLowerCase().trim())) {
      return normalizeView(attr);
    }
    try {
      if(window.innerWidth && window.innerWidth <= 768) return 'mobile';
    } catch (_) {}
    return 'desktop';
  }

  function syncToggle(button, theme){
    if(!button) return;
    const light = theme === 'light';
    button.classList.toggle('is-light', light);
    button.classList.toggle('is-dark', !light);
    button.setAttribute('aria-pressed', String(light));
    const label = light ? 'Switch to dark mode' : 'Switch to light mode';
    button.title = label;
    button.setAttribute('aria-label', label);

    const sun = button.querySelector('.pl-theme-icon-sun');
    const moon = button.querySelector('.pl-theme-icon-moon');
    if(sun) sun.setAttribute('aria-hidden', String(!light));
    if(moon) moon.setAttribute('aria-hidden', String(light));
  }

  function syncThemePills(theme){
    document.querySelectorAll('[data-pl-theme-mode]').forEach(function(btn){
      const mode = normalize(btn.getAttribute('data-pl-theme-mode'));
      const active = mode === theme;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', String(active));
    });
  }

  function syncViewPills(viewMode){
    document.querySelectorAll('[data-pl-view-mode]').forEach(function(btn){
      const mode = normalizeView(btn.getAttribute('data-pl-view-mode'));
      const active = mode === viewMode;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', String(active));
    });
  }

  function syncRadio(theme){
    document.querySelectorAll('input[name="theme"]').forEach(function(radio){
      radio.checked = normalize(radio.value) === theme;
    });
  }

  function paint(theme, persist){
    const value = normalize(theme);
    root.setAttribute('data-theme', value);
    if(document.body) document.body.setAttribute('data-theme', value);

    if(persist !== false){
      try { localStorage.setItem(KEY, value); } catch (_) {}
    }

    document.querySelectorAll('#plThemeToggle').forEach(function(button){
      syncToggle(button, value);
    });
    syncThemePills(value);
    syncRadio(value);

    document.dispatchEvent(new CustomEvent('pocketleads-theme-change', {detail:{theme:value}}));
    return value;
  }


  function applyViewportAndScaleForMode(mode) {
    try {
      const isDesktop = (mode === 'desktop');
      let meta = document.querySelector('meta[name="viewport"]');
      if (!meta && document.head) {
        meta = document.createElement('meta');
        meta.name = 'viewport';
        document.head.appendChild(meta);
      }
      const screenW = Math.min(
        (window.screen && window.screen.width) ? window.screen.width : 1200,
        (window.screen && window.screen.availWidth) ? window.screen.availWidth : 1200
      );
      const isPhoneOrSmallScreen = screenW > 0 && screenW <= 900;

      if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.setViewportMode === 'function') {
        try { window.AndroidChromeBridge.setViewportMode(isDesktop ? 'desktop' : 'mobile'); } catch (_) {}
      }

      if (isDesktop) {
        const targetDesktopW = 1200;
        const initScale = isPhoneOrSmallScreen
          ? Math.max(0.25, Math.min(0.95, Number((screenW / targetDesktopW).toFixed(3))))
          : 1.0;
        if (meta) {
          meta.setAttribute(
            'content',
            isPhoneOrSmallScreen
              ? ('width=' + targetDesktopW + ', initial-scale=' + initScale + ', minimum-scale=0.2, maximum-scale=5.0, user-scalable=yes')
              : 'width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes'
          );
        }
        const applyDesktopZoomFallback = function() {
          try {
            if (root.getAttribute('data-view-mode') !== 'desktop') return;
            const curInnerW = window.innerWidth || document.documentElement.clientWidth || screenW;
            if (isPhoneOrSmallScreen && curInnerW > 0 && curInnerW < 960) {
              // Browser kept narrow layout viewport (e.g. Kiwi Browser without 'Desktop site' checked)
              const zoomVal = Math.max(0.26, Math.min(0.95, Number((curInnerW / targetDesktopW).toFixed(4))));
              root.classList.add('pl-desktop-scaled-viewport');
              if (document.body) {
                document.body.style.width = targetDesktopW + 'px';
                document.body.style.minWidth = targetDesktopW + 'px';
                document.body.style.maxWidth = targetDesktopW + 'px';
                document.body.style.zoom = String(zoomVal);
                document.body.style.overflowX = 'hidden';
              }
            } else {
              root.classList.remove('pl-desktop-scaled-viewport');
              if (document.body) {
                document.body.style.width = '';
                document.body.style.minWidth = '';
                document.body.style.maxWidth = '';
                document.body.style.zoom = '';
                document.body.style.overflowX = '';
              }
            }
          } catch (_) {}
        };
        applyDesktopZoomFallback();
        setTimeout(applyDesktopZoomFallback, 60);
        setTimeout(applyDesktopZoomFallback, 220);
      } else {
        // Mobile Mode
        if (meta) {
          meta.setAttribute('content', 'width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=5.0, user-scalable=yes');
        }
        root.classList.remove('pl-desktop-scaled-viewport');
        const applyMobileZoomFallback = function() {
          try {
            if (root.getAttribute('data-view-mode') !== 'mobile') return;
            if (document.body) {
              document.body.style.width = '';
              document.body.style.minWidth = '';
              document.body.style.maxWidth = '';
              document.body.style.overflowX = '';
              const curInnerW = window.innerWidth || document.documentElement.clientWidth || screenW;
              // If user left Kiwi Browser 'Desktop site' checkbox enabled (curInnerW ~ 980 on a phone screen),
              // scale up mobile layout to fill the 980px viewport cleanly!
              if (isPhoneOrSmallScreen && curInnerW >= 780 && screenW <= 600) {
                const mobileZoom = Math.max(1.0, Math.min(2.8, Number((curInnerW / 390).toFixed(3))));
                document.body.style.zoom = String(mobileZoom);
              } else {
                document.body.style.zoom = '';
              }
            }
          } catch (_) {}
        };
        applyMobileZoomFallback();
        setTimeout(applyMobileZoomFallback, 60);
        setTimeout(applyMobileZoomFallback, 220);
      }
    } catch (_) {}
  }

  function paintView(viewMode, persist){
    const value = normalizeView(viewMode);
    root.setAttribute('data-view-mode', value);
    if(document.body) document.body.setAttribute('data-view-mode', value);

    if(persist !== false){
      try { localStorage.setItem(VIEW_KEY, value); } catch (_) {}
    }

    syncViewPills(value);
    applyViewportAndScaleForMode(value);
    document.dispatchEvent(new CustomEvent('pocketleads-view-mode-change', {detail:{viewMode:value}}));
    try {
      setTimeout(function(){ window.dispatchEvent(new Event('resize')); }, 30);
    } catch (_) {}
    return value;
  }

  function set(theme){ return paint(theme, true); }
  function toggle(){ return set(read() === 'light' ? 'dark' : 'light'); }

  function setView(viewMode){ return paintView(viewMode, true); }
  function toggleView(){ return setView(readView() === 'mobile' ? 'desktop' : 'mobile'); }

  // Expose one single theme & view-mode API for every extension page.
  window.pocketleadsTheme = {get:read, set:set, toggle:toggle, normalize:normalize};
  window.applyDashboardTheme = set;
  window.updateThemeToggleIcon = function(theme){ paint(theme, false); };
  window.POCKETLEADS_THEMES = ['dark','light'];

  window.pocketleadsViewMode = {get:readView, set:setView, toggle:toggleView, normalize:normalizeView};
  window.applyDashboardViewMode = setView;

  // Apply immediately to prevent a flash during startup.
  try {
    root.setAttribute('data-theme', read());
    root.setAttribute('data-view-mode', readView());
  } catch (_) {}

  // CRITICAL: navbar.html is injected by Angular after DOMContentLoaded.
  // Event delegation means the toggles work even when they did not exist
  // when this script first executed.
  if(!document.documentElement.dataset.plThemeClickBound){
    document.documentElement.dataset.plThemeClickBound = '1';
    document.addEventListener('click', function(event){
      const viewBtn = event.target.closest && event.target.closest('[data-pl-view-mode]');
      if(viewBtn){
        event.preventDefault();
        event.stopPropagation();
        setView(viewBtn.getAttribute('data-pl-view-mode'));
        return;
      }

      const themePillBtn = event.target.closest && event.target.closest('[data-pl-theme-mode]');
      if(themePillBtn){
        event.preventDefault();
        event.stopPropagation();
        set(themePillBtn.getAttribute('data-pl-theme-mode'));
        return;
      }

      const toggleButton = event.target.closest && event.target.closest('#plThemeToggle');
      if(toggleButton){
        event.preventDefault();
        event.stopPropagation();
        toggle();
        return;
      }

      const themeRadio = event.target.closest && event.target.closest('input[name="theme"]');
      if(themeRadio && themeRadio.value){
        set(themeRadio.value);
      }
    }, true);
  }

  // Re-sync dynamically inserted navbar controls. Observe only child additions
  // (not attributes) so our own updates can never create an observer loop.
  const observer = new MutationObserver(function(mutations){
    let relevant = false;
    for(const mutation of mutations){
      if(mutation.type !== 'childList') continue;
      for(const node of mutation.addedNodes){
        if(node.nodeType !== 1) continue;
        if((node.id === 'plThemeToggle') || (node.id === 'openProfilePanel') ||
           (node.hasAttribute && (node.hasAttribute('data-pl-view-mode') || node.hasAttribute('data-pl-theme-mode'))) ||
           (node.querySelector && (node.querySelector('#plThemeToggle') || node.querySelector('#openProfilePanel') || node.querySelector('[data-pl-view-mode]') || node.querySelector('[data-pl-theme-mode]')))){
          relevant = true;
          break;
        }
      }
      if(relevant) break;
    }
    if(relevant){
      paint(read(), false);
      paintView(readView(), false);
    }
  });
  try {
    observer.observe(document.documentElement, {childList:true, subtree:true});
  } catch (_) {}

  // Cross-page sync for storage changes.
  window.addEventListener('storage', function(event){
    if(event.key === KEY) paint(normalize(event.newValue || DEFAULT), false);
    if(event.key === VIEW_KEY) paintView(normalizeView(event.newValue || 'desktop'), false);
  });

  // Track OS preference only until the user has explicitly chosen a mode.
  try {
    const media = window.matchMedia('(prefers-color-scheme: light)');
    media.addEventListener && media.addEventListener('change', function(){
      if(!safeStorageGet(KEY)) paint(media.matches ? 'light' : 'dark', false);
    });
  } catch (_) {}

  window.addEventListener('resize', function(){ try { applyViewportAndScaleForMode(readView()); } catch (_) {} });
  function boot(){
    paint(read(), false);
    paintView(readView(), false);
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once:true});
  else boot();
})();
