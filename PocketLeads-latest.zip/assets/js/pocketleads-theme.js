(function(){
  'use strict';

  const KEY = 'dashboard-theme';
  const DEFAULT = 'dark';
  const allowed = new Set(['dark','light']);

  const VIEW_KEY = 'pocketleads-view-mode';
  const allowedViews = new Set(['desktop','mobile']);
  const root = document.documentElement;

  function normalize(value){
    const v = String(value || '').toLowerCase().trim();
    return allowed.has(v) ? v : DEFAULT;
  }

  function normalizeView(value){
    const v = String(value || '').toLowerCase().trim();
    return allowedViews.has(v) ? v : 'desktop';
  }

  function safeStorageGet(key){
    try { return localStorage.getItem(key || KEY); } catch (_) { return null; }
  }

  function read(){
    const stored = safeStorageGet(KEY);
    if(stored) return normalize(stored);

    const attr = root && root.getAttribute('data-theme');
    if(attr) return normalize(attr);

    return DEFAULT;
  }

  function readView(){
    const stored = safeStorageGet(VIEW_KEY);
    if(stored && allowedViews.has(String(stored).toLowerCase().trim())) {
      return normalizeView(stored);
    }
    const attr = root && root.getAttribute('data-view-mode');
    if(attr && allowedViews.has(String(attr).toLowerCase().trim())) {
      return normalizeView(attr);
    }
    try {
      if(window.innerWidth && window.innerWidth <= 768) return 'mobile';
    } catch (_) {}
    return 'desktop';
  }

  function syncToggle(button, theme){
    if(!button) return;
    const light = theme === 'light';
    button.classList.toggle('is-light', light);
    button.classList.toggle('is-dark', !light);
    button.setAttribute('aria-pressed', String(light));
    const label = light ? 'Switch to dark mode' : 'Switch to light mode';
    button.title = label;
    button.setAttribute('aria-label', label);

    const sun = button.querySelector('.pl-theme-icon-sun');
    const moon = button.querySelector('.pl-theme-icon-moon');
    if(sun) sun.setAttribute('aria-hidden', String(!light));
    if(moon) moon.setAttribute('aria-hidden', String(light));
  }

  function syncThemePills(theme){
    document.querySelectorAll('[data-pl-theme-mode]').forEach(function(btn){
      const mode = normalize(btn.getAttribute('data-pl-theme-mode'));
      const active = mode === theme;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', String(active));
    });
  }

  function syncViewPills(viewMode){
    document.querySelectorAll('[data-pl-view-mode]').forEach(function(btn){
      const mode = normalizeView(btn.getAttribute('data-pl-view-mode'));
      const active = mode === viewMode;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', String(active));
    });
  }

  function syncRadio(theme){
    document.querySelectorAll('input[name="theme"]').forEach(function(radio){
      radio.checked = normalize(radio.value) === theme;
    });
  }

  function paint(theme, persist){
    const value = normalize(theme);
    root.setAttribute('data-theme', value);
    if(document.body) document.body.setAttribute('data-theme', value);

    if(persist !== false){
      try { localStorage.setItem(KEY, value); } catch (_) {}
    }

    document.querySelectorAll('#plThemeToggle').forEach(function(button){
      syncToggle(button, value);
    });
    syncThemePills(value);
    syncRadio(value);

    document.dispatchEvent(new CustomEvent('pocketleads-theme-change', {detail:{theme:value}}));
    return value;
  }

  function paintView(viewMode, persist){
    const value = normalizeView(viewMode);
    root.setAttribute('data-view-mode', value);
    if(document.body) document.body.setAttribute('data-view-mode', value);

    if(persist !== false){
      try { localStorage.setItem(VIEW_KEY, value); } catch (_) {}
    }

    syncViewPills(value);
    document.dispatchEvent(new CustomEvent('pocketleads-view-mode-change', {detail:{viewMode:value}}));
    try {
      setTimeout(function(){ window.dispatchEvent(new Event('resize')); }, 30);
    } catch (_) {}
    return value;
  }

  function set(theme){ return paint(theme, true); }
  function toggle(){ return set(read() === 'light' ? 'dark' : 'light'); }

  function setView(viewMode){ return paintView(viewMode, true); }
  function toggleView(){ return setView(readView() === 'mobile' ? 'desktop' : 'mobile'); }

  // Expose one single theme & view-mode API for every extension page.
  window.pocketleadsTheme = {get:read, set:set, toggle:toggle, normalize:normalize};
  window.applyDashboardTheme = set;
  window.updateThemeToggleIcon = function(theme){ paint(theme, false); };
  window.POCKETLEADS_THEMES = ['dark','light'];

  window.pocketleadsViewMode = {get:readView, set:setView, toggle:toggleView, normalize:normalizeView};
  window.applyDashboardViewMode = setView;

  // Apply immediately to prevent a flash during startup.
  try {
    root.setAttribute('data-theme', read());
    root.setAttribute('data-view-mode', readView());
  } catch (_) {}

  // CRITICAL: navbar.html is injected by Angular after DOMContentLoaded.
  // Event delegation means the toggles work even when they did not exist
  // when this script first executed.
  if(!document.documentElement.dataset.plThemeClickBound){
    document.documentElement.dataset.plThemeClickBound = '1';
    document.addEventListener('click', function(event){
      const viewBtn = event.target.closest && event.target.closest('[data-pl-view-mode]');
      if(viewBtn){
        event.preventDefault();
        event.stopPropagation();
        setView(viewBtn.getAttribute('data-pl-view-mode'));
        return;
      }

      const themePillBtn = event.target.closest && event.target.closest('[data-pl-theme-mode]');
      if(themePillBtn){
        event.preventDefault();
        event.stopPropagation();
        set(themePillBtn.getAttribute('data-pl-theme-mode'));
        return;
      }

      const toggleButton = event.target.closest && event.target.closest('#plThemeToggle');
      if(toggleButton){
        event.preventDefault();
        event.stopPropagation();
        toggle();
        return;
      }

      const themeRadio = event.target.closest && event.target.closest('input[name="theme"]');
      if(themeRadio && themeRadio.value){
        set(themeRadio.value);
      }
    }, true);
  }

  // Re-sync dynamically inserted navbar controls. Observe only child additions
  // (not attributes) so our own updates can never create an observer loop.
  const observer = new MutationObserver(function(mutations){
    let relevant = false;
    for(const mutation of mutations){
      if(mutation.type !== 'childList') continue;
      for(const node of mutation.addedNodes){
        if(node.nodeType !== 1) continue;
        if((node.id === 'plThemeToggle') || (node.id === 'openProfilePanel') ||
           (node.hasAttribute && (node.hasAttribute('data-pl-view-mode') || node.hasAttribute('data-pl-theme-mode'))) ||
           (node.querySelector && (node.querySelector('#plThemeToggle') || node.querySelector('#openProfilePanel') || node.querySelector('[data-pl-view-mode]') || node.querySelector('[data-pl-theme-mode]')))){
          relevant = true;
          break;
        }
      }
      if(relevant) break;
    }
    if(relevant){
      paint(read(), false);
      paintView(readView(), false);
    }
  });
  try {
    observer.observe(document.documentElement, {childList:true, subtree:true});
  } catch (_) {}

  // Cross-page sync for storage changes.
  window.addEventListener('storage', function(event){
    if(event.key === KEY) paint(normalize(event.newValue || DEFAULT), false);
    if(event.key === VIEW_KEY) paintView(normalizeView(event.newValue || 'desktop'), false);
  });

  // Track OS preference only until the user has explicitly chosen a mode.
  try {
    const media = window.matchMedia('(prefers-color-scheme: light)');
    media.addEventListener && media.addEventListener('change', function(){
      if(!safeStorageGet(KEY)) paint(media.matches ? 'light' : 'dark', false);
    });
  } catch (_) {}

  function boot(){
    paint(read(), false);
    paintView(readView(), false);
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once:true});
  else boot();
})();
