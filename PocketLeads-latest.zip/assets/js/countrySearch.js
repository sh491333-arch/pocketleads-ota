/*
 * Country Search Filter
 *
 * This module adds search functionality to the country dropdown on the dashboard.
 * It listens for input events on the text field with ID `countrySearch` and
 * toggles the visibility of each <option> in the select element with ID
 * `countrySelect` based on whether the option's text contains the query.
 *
 * The blank placeholder option is always shown so users can clear their
 * selection or leave the field empty.  The script runs after jQuery has
 * loaded and the DOM is ready.
 */
(function() {
    // Ensure jQuery is available before executing.  Wrap in a DOM ready handler
    // to guarantee that the input and select elements exist when we bind events.
    if (typeof $ === 'undefined') {
        return;
    }
    $(function() {
        const $countryInput = $('#countrySearch');
        const $countrySelect = $('#countrySelect');
        if (!$countryInput.length || !$countrySelect.length) {
            return;
        }
        $countryInput.on('input', function() {
            const query = $(this).val().toLowerCase();
            $countrySelect.find('option').each(function() {
                const $opt = $(this);
                const text = $opt.text().toLowerCase();
                // Show the placeholder option and options that include the search string.
                if ($opt.val() === '' || text.indexOf(query) !== -1) {
                    $opt.show();
                } else {
                    $opt.hide();
                }
            });
        });
    });
})();