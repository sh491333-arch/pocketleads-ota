// This script attaches a click handler to the close button on the
// Privacy & Liability Policy page.  Because inline event handlers and
// scripts are disallowed by the extension Content Security Policy,
// the logic must be in an external file referenced by privacy.html.

document.addEventListener('DOMContentLoaded', function() {
  var btn = document.querySelector('.close-button');
  if (btn) {
    btn.addEventListener('click', function() {
      try { window.close(); } catch (_) {}
      setTimeout(function(){
        if (!document.hidden) {
          try { window.history.back(); } catch (_) {}
          setTimeout(function(){ if (!document.hidden) window.location.href='/views/index.html'; }, 140);
        }
      }, 100);
    });
  }
});