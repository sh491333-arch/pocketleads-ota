/*
 * PocketLeads Support Center — self-contained client module (v10.12.10).
 * -------------------------------------------------------------------------
 * This script wires the existing support-center CSS + Apps Script backend
 * (submitSupportTicket_ / getSupportTickets_) to the dashboard UI.
 *
 * It is CSP-safe (no eval, no inline handlers) and is intended to be loaded
 * in views/index.html via:
 *     <script src="/assets/js/support-center.js"></script>
 *
 * If the dashboard HTML already contains a #plSupportModal root, this module
 * adopts it; otherwise it auto-injects the markup so the feature works even
 * when the host page has no support markup at all.
 *
 * Ticket submission and ticket listing both travel through the MV3
 * service-worker transport (chrome.runtime.sendMessage action:
 * 'pocketleads_support_request') defined in controllers/background.js so that
 * Apps Script redirects/CORS never break the flow from a dashboard tab.
 *
 * Licence key + deviceId are read from chrome.storage.local so the support
 * requests are bound to the activated installation exactly as the backend
 * requires (doPost enforces deviceId before submitticket/getsupporttickets).
 */
(function () {
  'use strict';
  if (window.__plSupportCenterReady) return;
  window.__plSupportCenterReady = true;

  /* ------------------------------ icons -------------------------------- */
  var SVG = {
    support: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14v-3a8 8 0 0 1 16 0v7h-6M3 11h4v7H3zM17 11h4v7h-4z"/></svg>',
    refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10a8 8 0 1 0-2 8M20 3v7h-7"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v16M4 12h16"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 5 14 14M5 19 19 5"/></svg>',
    inbox: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h18v16H3zM3 13h5l2 3h4l2-3h5"/></svg>',
    chevron: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9 5 7 7-7 7"/></svg>',
    alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 1 21h22zM12 9v5M12 17v.01"/></svg>',
    send: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3l18 9-18 9 4-9-4-9z"/></svg>'
  };

  /* ------------------------------ state -------------------------------- */
  var state = {
    root: null,                 // the support modal element
    detailRoot: null,           // the ticket-detail modal element
    trigger: null,              // floating trigger button
    isOpen: false,
    tickets: [],
    loading: false,
    submitting: false,
    lastError: '',
    licence: null,              // { key, deviceId, email }
    bound: false
  };

  /* ------------------------------ helpers ------------------------------ */
  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function uuid() {
    // RFC4122 v4-ish client request id for backend idempotency
    try {
      if (crypto && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
    } catch (e) {}
    return 'rid-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function formatTime(value) {
    if (!value) return '';
    try {
      var d = value instanceof Date ? value : new Date(value);
      if (isNaN(d.getTime())) return String(value);
      return d.toLocaleString();
    } catch (e) { return String(value); }
  }

  function statusBadgeClass(status) {
    var s = String(status || 'Open').toLowerCase();
    if (/(closed|resolved|done|complete)/.test(s)) return 'is-closed';
    if (/(pending|waiting|hold|in progress|in-progress)/.test(s)) return 'is-pending';
    return 'is-open';
  }

  function statusLabel(status) {
    var s = String(status || 'Open').toLowerCase();
    if (/(closed|resolved|done|complete)/.test(s)) return 'Closed';
    if (/(pending|waiting|hold)/.test(s)) return 'Pending';
    return 'Open';
  }

  // Read the activated licence + device identity from chrome.storage.local.
  function loadLicence() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get(['license'], function (res) {
          var lic = res && res.license || null;
          resolve(lic);
        });
      } catch (e) { resolve(null); }
    });
  }

  // Send a request to the Apps Script backend via the MV3 service-worker
  // transport. The background handler (action: 'pocketleads_support_request')
  // performs the actual fetch so redirects/CORS never break the dashboard.
  function callSupport(action, params) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.runtime.sendMessage({
          action: 'pocketleads_support_request',
          method: 'GET',
          params: Object.assign({ action: action }, params || {})
        }, function (resp) {
          // Mark lastError handled (MV3 message port)
          try { void chrome.runtime.lastError; } catch (e) {}
          if (!resp) { reject(new Error('No response from service worker.')); return; }
          if (!resp.ok) { reject(new Error(resp.error || 'Support request failed.')); return; }
          // The transport returns { ok, status, text, finalUrl, data? }.
          // data is the parsed JSON when the background handler could parse it.
          if (resp.data != null && typeof resp.data === 'object') {
            resolve(resp.data);
            return;
          }
          var text = String(resp.text || '');
          if (!text) { reject(new Error('Empty response from backend.')); return; }
          try { resolve(JSON.parse(text)); }
          catch (e) { reject(new Error('Unexpected response from backend.')); }
        });
      } catch (e) { reject(e); }
    });
  }

  // Submit a ticket via POST through the same MV3 transport.
  function submitSupport(subject, message, email) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.runtime.sendMessage({
          action: 'pocketleads_support_request',
          method: 'POST',
          params: {
            action: 'submitticket',
            key: state.licence && state.licence.key || '',
            deviceId: state.licence && state.licence.installationId || '',
            subject: subject,
            message: message,
            user: email || (state.licence && state.licence.email) || '',
            requestId: uuid()
          }
        }, function (resp) {
          try { void chrome.runtime.lastError; } catch (e) {}
          if (!resp) { reject(new Error('No response from service worker.')); return; }
          if (!resp.ok) { reject(new Error(resp.error || 'Ticket submission failed.')); return; }
          if (resp.data != null && typeof resp.data === 'object') { resolve(resp.data); return; }
          var text = String(resp.text || '');
          try { resolve(JSON.parse(text)); }
          catch (e) { reject(new Error('Unexpected response from backend.')); }
        });
      } catch (e) { reject(e); }
    });
  }

  /* ------------------------------ markup ------------------------------ */
  var MODAL_HTML =
    '<div class="pl-support-modal" id="plSupportModal" hidden>' +
      '<div class="pl-support-backdrop" data-pl-action="close"></div>' +
      '<div class="pl-support-dialog" role="dialog" aria-modal="true" aria-labelledby="plSupportTitle">' +
        '<button class="pl-modal-x" type="button" data-pl-action="close" aria-label="Close">' + SVG.close + '</button>' +
        '<div class="pl-support-header">' +
          '<div>' +
            '<span class="pl-modal-kicker">POCKETLEADS SUPPORT</span>' +
            '<h2 id="plSupportTitle">Help &amp; Support</h2>' +
            '<p>Submit a ticket or track your existing requests. We typically respond within one business day.</p>' +
          '</div>' +
        '</div>' +
        '<div class="pl-support-body">' +
          '<div class="pl-support-toolbar">' +
            '<div>' +
              '<strong>Your Tickets</strong>' +
              '<small>Tickets are bound to your licence key</small>' +
            '</div>' +
            '<div class="pl-support-toolbar-actions">' +
              '<button class="pl-icon-action" type="button" data-pl-action="refresh" aria-label="Refresh tickets" title="Refresh">' + SVG.refresh + '</button>' +
              '<button class="pl-new-ticket-btn" type="button" data-pl-action="new">' + SVG.plus + '<span>New Ticket</span></button>' +
            '</div>' +
          '</div>' +
          '<div class="pl-support-status" id="plSupportStatus"></div>' +
          '<div class="pl-support-ticket-list" id="plSupportList"></div>' +
          '<div class="pl-ticket-form-modal" id="plSupportForm" hidden>' +
            '<div class="pl-form-title-wrap"><span class="pl-form-title">New Support Ticket</span><small>Describe your issue and we will get back to you.</small></div>' +
            '<label>Email <input type="email" id="plTicketEmail" placeholder="your@email.com" autocomplete="email"/></label>' +
            '<label>Subject <input type="text" id="plTicketSubject" maxlength="120" placeholder="Short summary of the issue"/></label>' +
            '<label>Message <textarea id="plTicketMessage" maxlength="2000" placeholder="Describe what happened, what you expected, and any error you saw."></textarea></label>' +
            '<div class="pl-form-actions">' +
              '<button class="pl-form-cancel" type="button" data-pl-action="cancel">Cancel</button>' +
              '<button class="pl-new-ticket-btn" type="button" data-pl-action="submit">' + SVG.send + '<span>Submit Ticket</span></button>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</div>';

  var DETAIL_HTML =
    '<div class="pl-ticket-detail-modal" id="plTicketDetail" hidden>' +
      '<div class="pl-support-backdrop" data-pl-action="close-detail"></div>' +
      '<div class="pl-ticket-detail-dialog" role="dialog" aria-modal="true" aria-labelledby="plDetailTitle">' +
        '<button class="pl-modal-x" type="button" data-pl-action="close-detail" aria-label="Close">' + SVG.close + '</button>' +
        '<div class="pl-ticket-detail-header">' +
          '<div>' +
            '<span class="pl-modal-kicker">TICKET</span>' +
            '<h3 id="plDetailTitle"></h3>' +
            '<div class="pl-detail-meta" id="plDetailMeta"></div>' +
          '</div>' +
        '</div>' +
        '<div class="pl-ticket-detail-body">' +
          '<div class="pl-detail-status-row"><span>Status</span><span class="pl-detail-status" id="plDetailStatus"></span></div>' +
          '<div class="pl-detail-section"><span class="pl-detail-label">Message</span><p id="plDetailMessage"></p></div>' +
          '<div class="pl-detail-section"><span class="pl-detail-label">Remarks</span><p id="plDetailRemarks"></p></div>' +
        '</div>' +
      '</div>' +
    '</div>';

  var FLOATING_BTN_HTML =
    '<button class="pl-floating-icon-btn" type="button" id="plSupportTrigger" ' +
      'aria-label="Support" title="Support" style="position:fixed;right:22px;bottom:22px;z-index:10040;">' + SVG.support + '</button>';

  /* ------------------------------ render ------------------------------ */
  function setStatus(text, kind) {
    var el = document.getElementById('plSupportStatus');
    if (!el) return;
    el.className = 'pl-support-status' + (kind ? ' is-' + kind : '');
    el.textContent = text || '';
  }

  function renderEmpty() {
    var list = document.getElementById('plSupportList');
    if (!list) return;
    list.innerHTML =
      '<div class="pl-empty-tickets">' +
        '<div class="pl-empty-icon">' + SVG.inbox + '</div>' +
        '<strong>No tickets yet</strong>' +
        '<small>Click “New Ticket” to start a conversation with support.</small>' +
      '</div>';
  }

  function renderError(message) {
    var list = document.getElementById('plSupportList');
    if (!list) return;
    list.innerHTML =
      '<div class="pl-ticket-error">' +
        '<strong>Could not load tickets</strong>' +
        '<small>' + escapeHtml(message || 'Please try again in a moment.') + '</small>' +
      '</div>';
  }

  function renderLicenceRequired() {
    var list = document.getElementById('plSupportList');
    if (!list) return;
    list.innerHTML =
      '<div class="pl-ticket-error">' +
        '<strong>Activate your licence first</strong>' +
        '<small>The support center needs an active licence key to open and sync tickets.</small>' +
      '</div>';
  }

  function renderTickets() {
    var list = document.getElementById('plSupportList');
    if (!list) return;
    if (!state.tickets.length) { renderEmpty(); return; }
    var html = state.tickets.map(function (t, idx) {
      return '<button class="pl-ticket-row" type="button" data-pl-ticket="' + idx + '">' +
        '<div class="pl-ticket-main">' +
          '<div class="pl-ticket-title">' + escapeHtml(t.subject || '(no subject)') + '</div>' +
          '<div class="pl-ticket-meta">' +
            '<span class="pl-ticket-id">' + escapeHtml(t.id || '') + '</span>' +
            '<span>' + escapeHtml(formatTime(t.timestamp)) + '</span>' +
          '</div>' +
          (t.message ? '<div class="pl-ticket-preview">' + escapeHtml(t.message) + '</div>' : '') +
        '</div>' +
        '<div class="pl-ticket-side">' +
          '<span class="pl-ticket-status-badge ' + statusBadgeClass(t.status) + '">' + escapeHtml(statusLabel(t.status)) + '</span>' +
          SVG.chevron +
        '</div>' +
      '</button>';
    }).join('');
    list.innerHTML = html;
  }

  function openDetail(ticket) {
    if (!state.detailRoot) return;
    document.getElementById('plDetailTitle').textContent = ticket.subject || '(no subject)';
    var meta = document.getElementById('plDetailMeta');
    meta.innerHTML = '<span>ID: ' + escapeHtml(ticket.id || '') + '</span>' +
      '<span>' + escapeHtml(formatTime(ticket.timestamp)) + '</span>' +
      (ticket.user ? '<span>' + escapeHtml(ticket.user) + '</span>' : '');
    var st = document.getElementById('plDetailStatus');
    st.className = 'pl-detail-status ' + statusBadgeClass(ticket.status);
    st.textContent = statusLabel(ticket.status);
    document.getElementById('plDetailMessage').textContent = ticket.message || '';
    document.getElementById('plDetailRemarks').textContent = ticket.remarks || '—';
    state.detailRoot.hidden = false;
    document.body.classList.add('pl-modal-open');
  }

  /* ------------------------------ actions ------------------------------ */
  function refreshTickets() {
    if (state.loading) return;
    if (!state.licence || !state.licence.key) {
      renderLicenceRequired();
      setStatus('Activate your licence to view tickets.', 'error');
      return;
    }
    state.loading = true;
    setStatus('Syncing tickets…');
    var refreshBtn = state.root.querySelector('[data-pl-action="refresh"]');
    if (refreshBtn) refreshBtn.classList.add('is-loading');
    callSupport('getsupporttickets', {
      key: state.licence.key,
      deviceId: state.licence.installationId || ''
    }).then(function (data) {
      state.tickets = (data && Array.isArray(data.tickets)) ? data.tickets : [];
      state.lastError = '';
      renderTickets();
      setStatus(state.tickets.length ? (state.tickets.length + ' ticket' + (state.tickets.length === 1 ? '' : 's') + ' synced.') : '', state.tickets.length ? 'success' : '');
    }).catch(function (err) {
      state.lastError = String(err && err.message || err);
      renderError(state.lastError);
      setStatus(state.lastError, 'error');
    }).then(function () {
      state.loading = false;
      if (refreshBtn) refreshBtn.classList.remove('is-loading');
    });
  }

  function toggleForm(show) {
    var form = document.getElementById('plSupportForm');
    if (!form) return;
    form.hidden = !show;
    if (show) {
      var email = document.getElementById('plTicketEmail');
      if (email && !email.value && state.licence && state.licence.email) email.value = state.licence.email;
      try { var s = document.getElementById('plTicketSubject'); if (s) s.focus(); } catch (e) {}
    }
  }

  function submitForm() {
    if (state.submitting) return;
    var subject = (document.getElementById('plTicketSubject') || {}).value || '';
    var message = (document.getElementById('plTicketMessage') || {}).value || '';
    var email = (document.getElementById('plTicketEmail') || {}).value || '';
    subject = String(subject).trim(); message = String(message).trim(); email = String(email).trim();
    if (subject.length < 3) { setStatus('Subject must be at least 3 characters.', 'error'); return; }
    if (message.length < 10) { setStatus('Message must be at least 10 characters.', 'error'); return; }
    if (!state.licence || !state.licence.key) { renderLicenceRequired(); setStatus('Activate your licence before submitting a ticket.', 'error'); return; }

    state.submitting = true;
    var submitBtn = state.root.querySelector('[data-pl-action="submit"]');
    if (submitBtn) { submitBtn.classList.add('is-loading'); submitBtn.disabled = true; }
    setStatus('Submitting ticket…');
    submitSupport(subject, message, email).then(function (data) {
      var dup = data && data.duplicate;
      var id = data && (data.ticketId || (data.ticket && data.ticket.id)) || '';
      setStatus((dup ? 'Ticket already received — ' : 'Ticket created — ') + (id ? id : '') , 'success');
      // Reset form and refresh the list so the new ticket appears.
      try {
        document.getElementById('plTicketSubject').value = '';
        document.getElementById('plTicketMessage').value = '';
      } catch (e) {}
      toggleForm(false);
      refreshTickets();
    }).catch(function (err) {
      setStatus(String(err && err.message || err), 'error');
    }).then(function () {
      state.submitting = false;
      if (submitBtn) { submitBtn.classList.remove('is-loading'); submitBtn.disabled = false; }
    });
  }

  function openModal() {
    if (!state.root) return;
    state.isOpen = true;
    state.root.hidden = false;
    document.body.classList.add('pl-modal-open');
    // Ensure we have the latest licence before listing. The licence may have
    // been activated in another tab since the dashboard was opened.
    loadLicence().then(function (lic) {
      state.licence = lic && lic.key ? {
        key: String(lic.key),
        installationId: String(lic.installationId || lic.deviceId || ''),
        email: String(lic.email || '')
      } : null;
      refreshTickets();
    });
  }

  function closeModal() {
    if (state.root) state.root.hidden = true;
    state.isOpen = false;
    toggleForm(false);
    // Only release the scroll lock when the detail modal is also closed.
    if (!state.detailRoot || state.detailRoot.hidden) {
      document.body.classList.remove('pl-modal-open');
    }
  }

  function closeDetail() {
    if (state.detailRoot) state.detailRoot.hidden = true;
    if (!state.isOpen) document.body.classList.remove('pl-modal-open');
  }

  /* ------------------------------ events ------------------------------ */
  function handleClick(e) {
    var row = e.target.closest && e.target.closest('[data-pl-ticket]');
    if (row && typeof row.getAttribute === 'function') {
      var idx = parseInt(row.getAttribute('data-pl-ticket'), 10);
      if (!isNaN(idx) && state.tickets[idx]) { openDetail(state.tickets[idx]); return; }
    }
    var actionEl = e.target.closest && e.target.closest('[data-pl-action]');
    if (!actionEl) return;
    var action = actionEl.getAttribute('data-pl-action');
    switch (action) {
      case 'close': closeModal(); break;
      case 'close-detail': closeDetail(); break;
      case 'refresh': refreshTickets(); break;
      case 'new': toggleForm(true); break;
      case 'cancel': toggleForm(false); break;
      case 'submit': submitForm(); break;
    }
  }

  function handleKey(e) {
    if (e.key === 'Escape') {
      if (state.detailRoot && !state.detailRoot.hidden) { closeDetail(); return; }
      if (state.isOpen) closeModal();
    }
  }

  /* ------------------------------ init -------------------------------- */
  function ensureInjected() {
    if (state.bound) return;
    state.bound = true;

    // Inject modals (adopt existing markup when the host page already has it).
    state.root = document.getElementById('plSupportModal');
    if (!state.root) {
      var host = document.createElement('div');
      host.innerHTML = MODAL_HTML;
      state.root = host.firstElementChild;
      (document.body || document.documentElement).appendChild(state.root);
    }
    state.detailRoot = document.getElementById('plTicketDetail');
    if (!state.detailRoot) {
      var dhost = document.createElement('div');
      dhost.innerHTML = DETAIL_HTML;
      state.detailRoot = dhost.firstElementChild;
      (document.body || document.documentElement).appendChild(state.detailRoot);
    }
    state.detailRoot.hidden = true;

    // Floating trigger button. Hidden if the host page already exposes its
    // own support trigger (data-pl-support / #plSupportBtn / .pl-support-trigger).
    if (!document.getElementById('plSupportTrigger') &&
        !document.querySelector('[data-pl-support], #plSupportBtn, .pl-support-trigger')) {
      var t = document.createElement('div');
      t.innerHTML = FLOATING_BTN_HTML;
      state.trigger = t.firstElementChild;
      (document.body || document.documentElement).appendChild(state.trigger);
    } else {
      state.trigger = document.querySelector('[data-pl-support], #plSupportBtn, .pl-support-trigger');
    }

    // Event wiring (delegation handles Angular-rendered buttons too).
    document.addEventListener('click', handleClick, false);
    document.addEventListener('keydown', handleKey, false);

    // Expose an imperative API for the dashboard navbar / profile panel.
    window.pocketleadsSupport = {
      open: openModal,
      close: closeModal,
      refresh: refreshTickets
    };
    // Allow inline triggers like <button onclick> in legacy markup.
    window.plOpenSupport = openModal;

    // Custom event hook for Angular-injected buttons that cannot call the
    // global directly (e.g. ng-click="$emit('pocketleads:open-support')").
    if (typeof window.addEventListener === 'function') {
      window.addEventListener('pocketleads:open-support', openModal);
    }
  }

  function start() {
    ensureInjected();
    // Pre-fetch the licence so the floating button knows whether to show a
    // hint. The actual ticket sync happens on open.
    loadLicence().then(function (lic) {
      state.licence = lic && lic.key ? {
        key: String(lic.key),
        installationId: String(lic.installationId || lic.deviceId || ''),
        email: String(lic.email || '')
      } : null;
    });
    // Keep the licence reference fresh if activated from another tab.
    try {
      chrome.storage.onChanged.addListener(function (changes, area) {
        if (area === 'local' && changes.license) {
          var lic = changes.license.newValue;
          state.licence = lic && lic.key ? {
            key: String(lic.key),
            installationId: String(lic.installationId || lic.deviceId || ''),
            email: String(lic.email || '')
          } : null;
          if (state.isOpen) refreshTickets();
        }
      });
    } catch (e) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
