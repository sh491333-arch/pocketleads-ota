(function(){
  var b=document.getElementById("termsCloseBtn");
  if(!b)return;
  b.addEventListener("click",function(){
    try{window.close();}catch(_){}
    setTimeout(function(){if(!document.hidden)window.location.href="/views/index.html";},120);
  });
})();
