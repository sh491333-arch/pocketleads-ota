(function(){
  var b=document.getElementById("termsCloseBtn");
  if(!b)return;
  b.addEventListener("click",function(){
    try{if(window.parent&&window.parent!==window&&typeof window.parent.__plCloseInAppDocModal==='function'){window.parent.__plCloseInAppDocModal();return;}}catch(_){}
    try{window.close();}catch(_){}
    setTimeout(function(){if(!document.hidden)window.location.href="/views/index.html";},120);
  });
})();
