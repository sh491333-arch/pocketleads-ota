// settings-page.js
//
// This script powers the standalone Settings page for PocketLeads.
// It is loaded as an external file to satisfy the Chrome extension
// content security policy which prohibits inline JavaScript.  The
// script initialises the controls on the page, populates the list
// of countries, loads the current configuration from storage, and
// persists changes when the user toggles options.  It also
// implements the navigation logic for returning to the dashboard
// and logging out.

// Immediately apply the saved theme on load.  We read from
// localStorage and set the data-theme attribute on the <body>
// element.  This ensures the colour palette is correctly applied
// before any flicker occurs.
(function applySavedTheme() {
  var savedTheme = localStorage.getItem('dashboard-theme') || (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark');
  var allowedThemes = ['dark','light'];
  if (allowedThemes.indexOf(savedTheme) === -1) savedTheme = 'dark';
  document.body.setAttribute('data-theme', savedTheme);
  localStorage.setItem('dashboard-theme', savedTheme);
})();

// Static list of countries used as a fallback when the dynamic
// country list cannot be fetched.  The list duplicates the one
// embedded in index.js and contains nearly every ISO-recognised
// country.  If you update this list in the main application,
// update it here as well.
const COUNTRY_NAMES = [
  "Aruba", "Afghanistan", "Angola", "Anguilla", "Åland Islands", "Albania", "Andorra", "United Arab Emirates", "Argentina",
  "Armenia", "American Samoa", "Antarctica", "French Southern Territories", "Antigua and Barbuda", "Australia", "Austria",
  "Azerbaijan", "Burundi", "Belgium", "Benin", "Bonaire, Sint Eustatius and Saba", "Burkina Faso", "Bangladesh", "Bulgaria",
  "Bahrain", "Bahamas", "Bosnia and Herzegovina", "Saint Barthélemy", "Belarus", "Belize", "Bermuda",
  "Bolivia, Plurinational State of", "Brazil", "Barbados", "Brunei Darussalam", "Bhutan", "Bouvet Island", "Botswana",
  "Central African Republic", "Canada", "Cocos (Keeling) Islands", "Switzerland", "Chile", "China", "Côte d'Ivoire",
  "Cameroon", "Congo, The Democratic Republic of the", "Congo", "Cook Islands", "Colombia", "Comoros", "Cabo Verde",
  "Costa Rica", "Cuba", "Curaçao", "Christmas Island", "Cayman Islands", "Cyprus", "Czechia", "Germany", "Djibouti",
  "Dominica", "Denmark", "Dominican Republic", "Algeria", "Ecuador", "Egypt", "Eritrea", "Western Sahara", "Spain",
  "Estonia", "Ethiopia", "Finland", "Fiji", "Falkland Islands (Malvinas)", "France", "Faroe Islands",
  "Micronesia, Federated States of", "Gabon", "United Kingdom", "Georgia", "Guernsey", "Ghana", "Gibraltar", "Guinea",
  "Guadeloupe", "Gambia", "Guinea-Bissau", "Equatorial Guinea", "Greece", "Grenada", "Greenland", "Guatemala",
  "French Guiana", "Guam", "Guyana", "Hong Kong", "Heard Island and McDonald Islands", "Honduras", "Croatia", "Haiti",
  "Hungary", "Indonesia", "Isle of Man", "India", "British Indian Ocean Territory", "Ireland", "Iran, Islamic Republic of",
  "Iraq", "Iceland", "Israel", "Italy", "Jamaica", "Jersey", "Jordan", "Japan", "Kazakhstan", "Kenya", "Kyrgyzstan",
  "Cambodia", "Kiribati", "Saint Kitts and Nevis", "Korea, Republic of", "Kuwait", "Lao People's Democratic Republic",
  "Lebanon", "Liberia", "Libya", "Saint Lucia", "Liechtenstein", "Sri Lanka", "Lesotho", "Lithuania", "Luxembourg",
  "Latvia", "Macao", "Saint Martin (French part)", "Morocco", "Monaco", "Moldova, Republic of", "Madagascar", "Maldives",
  "Mexico", "Marshall Islands", "North Macedonia", "Mali", "Malta", "Myanmar", "Montenegro", "Mongolia",
  "Northern Mariana Islands", "Mozambique", "Mauritania", "Montserrat", "Martinique", "Mauritius", "Malawi", "Malaysia",
  "Mayotte", "Namibia", "New Caledonia", "Niger", "Norfolk Island", "Nigeria", "Nicaragua", "Niue", "Netherlands",
  "Norway", "Nauru", "New Zealand", "Oman", "Pakistan", "Panama", "Pitcairn", "Peru", "Philippines", "Palau",
  "Papua New Guinea", "Poland", "Puerto Rico", "Korea, Democratic People's Republic of", "Portugal", "Paraguay",
  "Palestine, State of", "French Polynesia", "Qatar", "Réunion", "Romania", "Russian Federation", "Rwanda", "Saudi Arabia",
  "Sudan", "Senegal", "Singapore", "South Georgia and the South Sandwich Islands", "Saint Helena, Ascension and Tristan da Cunha",
  "Svalbard and Jan Mayen", "Solomon Islands", "Sierra Leone", "El Salvador", "San Marino", "Somalia",
  "Saint Pierre and Miquelon", "Serbia", "South Sudan", "Sao Tome and Principe", "Suriname", "Slovakia", "Slovenia",
  "Sweden", "Eswatini", "Sint Maarten (Dutch part)", "Seychelles", "Syrian Arab Republic", "Turks and Caicos Islands", "Chad",
  "Togo", "Thailand", "Tajikistan", "Tokelau", "Turkmenistan", "Timor-Leste", "Tonga", "Trinidad and Tobago", "Tunisia",
  "Türkiye", "Tuvalu", "Taiwan, Province of China", "Tanzania, United Republic of", "Uganda", "Ukraine",
  "United States Minor Outlying Islands", "Uruguay", "United States", "Uzbekistan", "Holy See (Vatican City State)",
  "Saint Vincent and the Grenadines", "Venezuela, Bolivarian Republic of", "Virgin Islands, British", "Virgin Islands, U.S.",
  "Viet Nam", "Vanuatu", "Wallis and Futuna", "Samoa", "Yemen", "South Africa", "Zambia", "Zimbabwe"
];

// DOM references
const countrySelectElement = document.getElementById('countrySelect');

// Populate the country <select> element with options.  We create an
// <option> for each country name and append it to the select.  This
// runs immediately because the script is loaded after the HTML.
function populateCountrySelect() {
  COUNTRY_NAMES.forEach(function(name) {
    var option = document.createElement('option');
    option.value = name;
    option.textContent = name;
    countrySelectElement.appendChild(option);
  });
}
populateCountrySelect();

// Load the saved settings from chrome.storage.local and localStorage.
// This function sets the state of radio buttons and select inputs
// based on previously persisted values.  If storage is unavailable
// (e.g. because the Settings page runs outside the extension
// context), defaults are applied.
function loadSettings() {
  // Default values until storage responds
  document.getElementById('scrapeWithPhone').checked = true;
  countrySelectElement.value = 'India';

  // Get the local model from chrome.storage.local
  try {
    chrome.storage.local.get('local', function(res) {
      var local = res && res.local ? res.local : {};
      // If fastMode is true, scraping without phone numbers is selected
      if (local.fastMode) {
        document.getElementById('scrapeWithoutPhone').checked = true;
      } else {
        document.getElementById('scrapeWithPhone').checked = true;
      }
      // Set the country if previously saved
      if (local.country) {
        countrySelectElement.value = local.country;
      }
    });
  } catch (err) {
    // If chrome.storage is not available, ignore and use defaults
  }
  // Theme selection from localStorage
  var theme = (window.pocketleadsTheme && window.pocketleadsTheme.get()) || localStorage.getItem('dashboard-theme') || 'dark';
  document.getElementById(theme === 'light' ? 'themeLight' : 'themeDark').checked = true;
}
loadSettings();

// Persist scraping mode changes back to chrome.storage.local.  We
// listen for change events on the radio inputs and update the
// fastMode flag on the local model accordingly.  When scraping
// without phone numbers is selected, fastMode becomes true.
document.querySelectorAll('input[name="scrapeMode"]').forEach(function(radio) {
  radio.addEventListener('change', function() {
    var modeValue = this.value;
    try {
      chrome.storage.local.get('local', function(res) {
        var local = res && res.local ? res.local : {};
        local.fastMode = (modeValue === 'without');
        chrome.storage.local.set({ local: local });
      });
    } catch (err) {
      // ignore if storage is unavailable
    }
  });
});

// Persist country changes when the select value changes.  We update
// the local model and save it back to storage.
countrySelectElement.addEventListener('change', function() {
  var selectedCountry = this.value;
  try {
    chrome.storage.local.get('local', function(res) {
      var local = res && res.local ? res.local : {};
      local.country = selectedCountry;
      chrome.storage.local.set({ local: local });
    });
  } catch (err) {
    // ignore if storage is unavailable
  }
});

// Theme changes are handled centrally by pocketleads-theme.js.

// Close the settings page using the extension window APIs where available.
document.getElementById('settingsCloseBtn')?.addEventListener('click', function() {
  try { if (window.parent && window.parent !== window && typeof window.parent.__plCloseInAppDocModal === 'function') { window.parent.__plCloseInAppDocModal(); return; } } catch (e) {}
  try { window.close(); } catch (e) {}
  setTimeout(function(){
    if(!document.hidden){ try{ history.back(); }catch(_){} setTimeout(function(){ if(!document.hidden) window.location.href='/views/index.html'; },140); }
  },100);
});

// Handle navigation back to the dashboard
document.getElementById('backBtn').addEventListener('click', function() {
  try { if (window.parent && window.parent !== window && typeof window.parent.__plCloseInAppDocModal === 'function') { window.parent.__plCloseInAppDocModal(); return; } } catch (_) {}
  window.location.href = '/views/index.html';
});

// Handle logout requests.  We send a message to the background
// script to perform the logout and licence release, then return to
// the dashboard regardless of success.  If messaging fails, we
// still navigate back to the dashboard.
document.getElementById('logoutBtn').addEventListener('click', function() {
  try {
    chrome.runtime.sendMessage({ action: 'logout' }, function() {
      window.location.href = '/views/index.html';
    });
  } catch (err) {
    window.location.href = '/views/index.html';
  }
});