# PocketLeads v10.16.4 — Ghost Mode Fast/Cleanup Patch

## Install

1. Stop any active scrape. Make a backup copy of the current extension folder.
2. Extract this ZIP to a new folder, open `chrome://extensions`, enable Developer mode, and load the extracted folder with **Load unpacked**. To retain the current extension's local data and licence, prefer replacing the files in the existing unpacked folder and pressing **Reload**, instead of installing a second copy. Do not run two PocketLeads copies at the same time.
3. Confirm the loaded extension displays version **10.16.4**. Do a small 5–10 lead test before using large queues.
4. No Apps Script deployment is required for this extension-only tab/URL/startup patch; keep your current managed Apps Script endpoint and licence/provider sheet setup.

## What changed

- Google Place IDs now use one direct URL only: `https://www.google.com/maps/place/?q=place_id:<PLACE_ID>`.
- The Ghost iframe performs one navigation per Place ID. It does not retry through alternate URL formats or create a visible Google Maps tab as fallback. Each iframe is removed when its request settles.
- Up to two hidden Ghost profile lanes process profiles. Serper and Scrappa retain their existing first-page/chunk streaming and provider routing. Provider network response time still depends on the provider/server/network; a result within exactly 10 seconds cannot be guaranteed externally.
- Start shows local progress immediately while it consumes the pre-prepared route. The API search itself still must receive a response before a real result row can be saved.
- Start, Stop, and Complete clean IDs recorded by older versions before those IDs are cleared. Only recorded, inactive tabs with `about:blank`, `chrome-error`, Google Maps profile/sorry, or Google consent URLs are eligible to close. Active tabs and tabs navigated to unrelated pages by the user are left alone.
- Stale content-script requests to open a visible Google Maps profile are rejected.
- Direct Place-ID parsing recognises `q=place_id:<ID>` in the extension's helpers.

## Important limitation

If an older version created blank tabs but never recorded their tab IDs in the saved queue or session, the extension cannot reliably distinguish those tabs from unrelated user tabs. Close those orphan tabs manually once. This build does not scan and close arbitrary user tabs.

Google consent/CAPTCHA/access challenges are reported rather than bypassed. There is no live Google Maps session in this test environment, so validate extraction on a small live query first.
