# PocketLeads 10.16.0 — integration candidate

This is the complete extension, incrementally updated from your uploaded
PocketLeads-v10.15.2-FIXED(1).zip. It includes the Apps Script source and tests.
The licence activation, device binding, expiry functions, existing extraction
adapters, history and export modules are retained.

**Deploy the included backend before enabling this extension for users.** This
build deliberately requires managed backend schema 2. Reloading the extension
alone does not install the server changes.

## Implemented

- Two management tabs: existing licence columns plus user assignments, exact
  provider priority, common credit and per-provider usage; one API key per row
  in the key-management tab. API secrets stay in the backend.
- Configuration cache with edit/change invalidation and bounded expiry. Credit,
  licence status and assignment rows are rechecked authoritatively.
- Separate provider capacity lanes; round-robin assigned keys; bounded
  sequential fallback; key cooldowns; no provider HTTP request inside the
  global financial lock.
- Atomic common-credit reservation, settlement, counters and durable receipts.
  Existing request/charged-lead journals remain for recovery compatibility.
- Scrappa: one page-0 search per query, maximum 200 results. Serper pincode:
  up to seven Maps pages. No city/text tile requirement.
- Google IDs-only search followed by the existing serial offscreen/hidden-frame
  profile extraction. Two frame attempts maximum, recycling after eight profiles
  or two minutes, duplicate skips and explicit consent/CAPTCHA/access errors.
- IndexedDB-backed counts and real row hydration, preserved rapid batches,
  pagination/scrolling, stale-run guards and recoverable persistence failures.
- Stable Angular history bindings, readable light/dark history, and elapsed
  time frozen on terminal states even when the dashboard stays closed overnight.
- Dashboard displays Available Credit and Purchased Credit only.

## Install / update

1. Back up the existing extension directory and Apps Script project. Export any
   important results before changing Chrome profiles or removing an extension.
2. Follow `backend/DEPLOYMENT.md`. Use the existing deployment and workbook;
   retain all existing licence/device fields, balances and ledger rows.
3. Extract this ZIP into the **same existing extension directory**. In
   `chrome://extensions`, click Reload. Keeping the existing installation/profile
   preserves its IndexedDB data and device identity. Do not uninstall first.
4. Check activation, account balances, provider order and the live validation
   checklist with a designated test licence before releasing to other users.

## Verification and remaining gates

152 automated checks passed, including managed routing, duplicate-charge
recovery, common credit, simulated concurrent reservations and dashboard
lifecycle regressions. Local Chromium reports cover 29 fixture checks across
dashboard/history, real IndexedDB/grid and hidden-frame messaging.

The live workbook headers were inspected and match the supported schema.
**This build has not been deployed or verified against paid providers or live
Google Maps. The 100-user test is a controlled simulation, not a live load test.**
Browser access to the workbook is currently signed out/view-only, so its Apps
Script project cannot be opened for deployment in this session.

See `tests/VALIDATION_10.16.0.md` for exact coverage and outstanding gates.
Older START_HERE / UPDATE documents and old test reports are historical; this
document and the 10.16.0 deployment instructions supersede them.
