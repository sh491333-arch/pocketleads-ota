> Historical document. Current release: START_HERE_10.15.0.md.

> Historical document. Current installation and behavior: START_HERE_10.14.0.md.

# PocketLeads 10.12.12

- Fixed licence activation failures caused by the dashboard aborting Apps Script after only 8 seconds.
- Activation and release requests now allow up to 60 seconds for Apps Script cold starts and spreadsheet operations.
- Licence status checks allow up to 30 seconds.
- Licence errors now show the actual timeout, HTTP status, invalid JSON, or Apps Script HTML/deployment problem instead of only `Network error. Please try again.`

The Apps Script web app must be deployed as **Execute as: Me** with access set to **Anyone**, and the existing deployment must be updated after changing `apps_script_code.js`.
