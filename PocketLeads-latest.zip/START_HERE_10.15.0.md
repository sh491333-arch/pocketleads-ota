# PocketLeads 10.15.0 — Unified pipeline and simpler state handling

## Required installation

1. Back up your current unpacked extension folder, Apps Script and spreadsheet.
2. Replace your Apps Script source with apps_script_code.js from this ZIP. Review/preserve SHEET_ID.
3. Deploy a NEW VERSION of your EXISTING web-app deployment. Backend version: 37_smooth_pipeline. Keep the existing URL; if it changes, update config/runtime.js.
4. Replace the unpacked extension files and Reload the SAME extension installation. Do not uninstall or clear extension storage. This preserves license, leads, queues and request receipts.
5. Reopen the dashboard. Use Start or Resume. Configure Purchase URL in the license sheet for an HTTPS checkout link; otherwise the purchase action uses support email.

The extension and backend must be updated together. No live deployment has been performed by this delivery.

## What changed

- Direct Google selection and structured-provider fallback both hand remaining tasks to runGooglePipeline -> processGoogleMapsBatch. The duplicate per-query Google DOM extraction implementation was removed. Saved jobs, IDs and results survive handoff.
- Removed unused warmup/getPreferredScrapeConfig methods and the separate long-lived backend route cache. Start reads the normalized account route; failover requests server selection. Prepared-route/preflight records remain compatibility/recovery mirrors, not another independent commercial authority.
- Added libs/request-journal.js. A logical request gets a random persisted jobId and requestId before network dispatch. Its original payload is immutable. Changing requested result limits or dedup exclusions on Resume reuses the stored payload/receipt; page tokens, offsets, query/geography, provider and run distinguish separate operations. Legacy pending receipts are imported using their original ID.
- Added libs/run-state.js. Worker writes map detailed queue activity to common ready/running/paused/awaiting_confirmation/credits_required/completed/failed states. Existing scheduler flags are compatibility mirrors. The old scheduler itself has not been replaced wholesale.
- Dashboard grid now requests filtered pages from IndexedDB through the worker. Global search, status, column-text and exact-value filters run across the stored dataset, not just the displayed page. The normal dashboard preview is bounded to 250 rows. Website/phone metrics are computed across saved rows when previewed.
- Bulk WhatsApp tools explicitly load their complete working dataset when invoked; they are not limited to the 250-row preview. This compatibility path can still use substantial memory on very large jobs. The visible grid remains paginated.
- Added libs/export-service.js. Export reads canonical result pages without hydrating/replacing the live dashboard/grid. Full Data and Filter Columns discover additional public fields actually saved in results, including nested values serialized as JSON. Private/internal and secret-like fields are excluded. Raw provider fields discarded before storage cannot be reconstructed by export.
- Exports reject missing pages or count changes rather than silently generating a partial file. Large export checks the prepared row count again. For a consistent final export, stop/wait for scraping first; same-count row edits are not protected by a database snapshot transaction.
- Backend owns provider cooldown timestamps and returns retryAfter. Client retains per-query attempted-row exclusions; duplicate client cooldown timing and health writes were removed. Known quota/auth failures and temporary rate limits remain separate from customer-credit failures.
- Request response chunks use one range write; new charged-lead records are appended in a batch. Dedup reads locate matching run entries first and read their column range rather than downloading the entire charged-leads sheet. Interleaved concurrent runs may share that bounded range.
- Service error popup includes Retry / Resume and Contact Support. Customer-credit popup retains Buy Credits, Refresh Balance and Download Saved Results.

## Authority and billing preserved

License/device/expiry validation, plan entitlements, customer credits, reservations and provider credentials remain server-controlled. License-race protection is retained. The client journal is a recovery aid, not commercial authority.

Structured and Google credit buckets remain separate. At initial selection the server can choose an entitled engine with balance. A confirmed customer-credit exhaustion during a job stops paid work. Google credits are still charged for returned billable Place IDs; they are not redefined as successful DOM-extracted leads.

The same recognized Place ID is not charged twice within a run across providers. Where no Place ID exists, exact normalized name+address is used; entries without a reliable identity remain billable. Universal fuzzy duplicate detection is not claimed.

## Recovery and operational limits

The durable server receipt and charged-lead sheets introduced in 10.14.0 remain in use. Keep them private and preserve unresolved receipts. The new client request journal is stored in a separate IndexedDB database, PocketLeadsRequests. Do not clear it while jobs can Resume.

A transport timeout checks the server receipt. Unknown completion remains paused rather than launching a duplicate paid request. Apps Script termination between reservation, provider completion and receipt commit may still need administrator reconciliation. This release does not turn Sheets into a transactional database or automatically retry uncertain actor launches.

One paid adapter request runs at a time; Google DOM consumers remain parallel. Filtered grid queries use a cursor over stored records and retain only the requested page, but large datasets still require scanning for filters/facets. No production throughput benchmark is claimed. Archive only completed/non-resumable historical receipt runs under your retention policy.

Auxiliary legacy provider integrations without request IDs retain prior compatibility; the new journal applies to the main background scraper. Existing export entitlement and plan-limit checks still apply.

## Verification

92 automated tests passed. 64 JS/CJS files passed syntax checks. Local HTML script references and ZIP integrity passed.

Tests include existing license/credit/routing regressions plus actual shared Google handoff, immutable request snapshots across restart, legacy receipt migration, failed journal writes, run-state transitions, public export-field discovery, incomplete export rejection, and actual IndexedDB-query method paging/filtering/facets with simulated cursor transport.

No installed Chrome/Chromium binary was available. No live browser rendering, real Google Maps DOM scraping, paid provider request, checkout, or deployed Apps Script end-to-end test was performed. Tests use simulated transport/storage; deploy to your own test setup and verify both engines before broad rollout. This is not a zero-bug or production-certification claim.

Earlier START_HERE/UPDATE notes and historical inventories are retained for reference. This document and tests/RELEASE_SHA256.json describe the current release.
