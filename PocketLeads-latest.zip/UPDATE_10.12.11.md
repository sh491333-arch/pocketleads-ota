> Historical document. Current release: START_HERE_10.15.0.md.

> Historical document. Current installation and behavior: START_HERE_10.14.0.md.

# PocketLeads 10.12.11

## Changes

- Licence activation is now a strict dashboard gate. The activation dialog has no close action and dashboard features remain blocked until the backend validates the licence for the current session.
- Profile Settings entry removed.
- Logout now asks for confirmation, releases the device licence, and returns to the licence submission screen.
- Support Center now uses one active client flow to prevent duplicate handlers and duplicate submissions.
- Support tickets accept one optional attachment up to 5 MB by file picker or drag and drop.
- Ticket attachments are stored in the Apps Script owner's `PocketLeads Support Attachments` Drive folder. The private Drive URL is written to the `AttachmentURL` column in the `Tickets` sheet.
- Ticket idempotency now uses a separate `RequestID` column. Existing nine-column ticket sheets are migrated automatically.

## Required backend deployment

Replace the deployed Google Apps Script project code with `apps_script_code.js`, save it, and update the existing web-app deployment. The first attachment upload will request Drive authorization for the script owner. Files remain private to the Drive owner unless that owner changes sharing permissions.
