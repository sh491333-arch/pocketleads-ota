/*
 * Content script injected into WhatsApp Web.
 *
 * This script acts as a bridge between the extension and the WhatsApp
 * page.  It forwards requests from the extension (such as "checkLogin"
 * and "checkPhones") to a page‑context script (pageBridge.js) via
 * window.postMessage and relays the responses back to the extension.
 * By delegating the actual lookup work to the page script, we avoid
 * manipulating WhatsApp’s user interface directly and instead rely on
 * the WPP API (or HTTP fallbacks) implemented in pageBridge.js.
 */

(function() {
    // Determine if this content script is running on a supported
    // WhatsApp Web domain.  We only handle messages when the
    // hostname ends with ".whatsapp.com" and contains "web" or
    // "consumer" (e.g. web.whatsapp.com, consumer.whatsapp.com).
    let allowedHost = false;
    try {
        const host = String(window.location && window.location.hostname || '');
        if (/(?:^|\.)whatsapp\.com$/.test(host) && /(web|consumer)/.test(host)) {
            allowedHost = true;
        }
    } catch (e) {
        allowedHost = false;
    }

    // -------------------------------------------------------------------
    // Page‑script injection
    //
    // The WhatsApp number checker requires access to WhatsApp's internal
    // APIs.  These APIs are only available in the page context (not the
    // isolated world of a content script).  We therefore inject our
    // helper scripts (wa.js, api.js and pageBridge.js) into the page by
    // dynamically creating <script> tags.  To avoid injecting too early
    // while the WhatsApp UI is still initialising we poll for common
    // container elements used by the site.  This mirrors the behaviour
    // of the standalone WA number checker extension, which waits until
    // the user interface has loaded before injecting its helpers.  If
    // the UI is not detected within a handful of attempts we inject
    // anyway.  Injection only occurs on supported WhatsApp domains and
    // only once per page load.
    let bridgeInjectionPromise = null;
    function ensureWhatsAppBridgeInjected() {
        if (!allowedHost) return Promise.resolve(false);
        if (bridgeInjectionPromise) return bridgeInjectionPromise;
        bridgeInjectionPromise = new Promise(resolve => {
            let injected = false;
            let attempts = 0;
            const maxAttempts = 10;
            const isUiReady = () => {
                try {
                    return !!(document.querySelector('#app') || document.querySelector('div[tabindex="-1"]') || document.body);
                } catch (e) { return false; }
            };
            const injectScripts = () => {
                if (injected) return;
                injected = true;
                const files = ['whatsapp/wa_preload.js', 'whatsapp/wa.js', 'whatsapp/pageBridge.js'];
                let loaded = 0;
                const done = () => {
                    loaded += 1;
                    if (loaded >= files.length) setTimeout(() => resolve(true), 250);
                };
                try {
                    files.forEach(file => {
                        const script = document.createElement('script');
                        script.async = false;
                        script.src = chrome.runtime.getURL(file);
                        script.onload = function() { try { this.remove(); } catch (e) {} done(); };
                        script.onerror = done;
                        (document.head || document.documentElement).appendChild(script);
                    });
                } catch (err) {
                    resolve(false);
                }
            };
            const poll = () => {
                if (isUiReady() || attempts >= maxAttempts) return injectScripts();
                attempts += 1;
                setTimeout(poll, 350);
            };
            poll();
        });
        return bridgeInjectionPromise;
    }

    // Map of pending requests awaiting responses from the page
    // context.  When we forward a request to the page via
    // window.postMessage we generate a unique id and store the
    // corresponding resolve and reject callbacks here.  When a
    // matching response arrives we look up the callbacks and
    // fulfil or reject the promise accordingly.
    const pending = new Map();
    let msgCounter = 1;

    // Timeout (in ms) for awaiting a response from the page context.  If
    // no response arrives within this window the promise returned from
    // postToPage() will reject, triggering fallback logic.  A shorter
    // timeout reduces the wait for login detection when the page
    // context is not yet injected.
    const RESPONSE_TIMEOUT_MS = 8000;

    // Listen for messages from the page context.  Only process
    // messages that have the flag { fromPage: true }.  Responses
    // include the original id and an action indicating the type of
    // response ("loginStatus" or "checkPhonesResult").
    window.addEventListener('message', (event) => {
        const data = event && event.data;
        if (!data || data.fromPage !== true) return;
        const id = data.id;
        if (!id || !pending.has(id)) return;
        const { resolve, reject, timeout } = pending.get(id);
        pending.delete(id);
        if (timeout) clearTimeout(timeout);
        try {
            if (data.action === 'loginStatus') {
                resolve({ loggedIn: !!data.loggedIn });
            } else if (data.action === 'checkPhonesResult') {
                const results = Array.isArray(data.results) ? data.results : [];
                resolve({ results });
            } else {
                reject(new Error('Unknown response action'));
            }
        } catch (err) {
            try { reject(err); } catch (ignore) {}
        }
    });

    /**
     * Post a message to the page context and return a promise that
     * resolves when a corresponding response arrives.  If posting
     * fails the promise is rejected immediately.
     *
     * @param {string} action Name of the action ("checkLogin" or "checkPhones").
     * @param {Object} payload Additional fields to include in the message.
     * @returns {Promise<any>}
     */
    function postToPage(action, payload) {
        return new Promise((resolve, reject) => {
            const id = 'wpmsg_' + (msgCounter++);
            // Create a timeout so that pending requests do not hang forever.
            const timeout = setTimeout(() => {
                if (pending.has(id)) {
                    pending.delete(id);
                    reject(new Error('timeout'));
                }
            }, RESPONSE_TIMEOUT_MS);
            pending.set(id, { resolve, reject, timeout });
            try {
                window.postMessage(Object.assign({}, payload, { fromExtension: true, id, action }), '*');
            } catch (e) {
                clearTimeout(timeout);
                pending.delete(id);
                reject(e);
            }
        });
    }

    // Listen for messages from the extension runtime.  When the
    // extension sends a "checkLogin" or "checkPhones" message, we
    // either respond immediately (if not on a supported host) or
    // forward the request to the page context.  We always return
    // true to indicate we intend to respond asynchronously.
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (!message || !message.action) return;
        // If not on an allowed host, always reply with fallback values.
        if (!allowedHost) {
            // When the content script is loaded on a non‑WhatsApp host we cannot
            // perform any lookups.  Explicitly return a loggedIn:false flag for
            // login checks and mark phone checks as errors.  Without the
            // error flag the dashboard interprets the fallback as
            // "Not available", which is misleading when the user is not
            // logged in.  See controllers/index.js:updateResults for how
            // error responses are handled (the UI leaves the status blank).
            if (message.action === 'checkLogin') {
                try { sendResponse({ loggedIn: false }); } catch (e) {}
                return true;
            }
            if (message.action === 'checkPhones') {
                const nums = Array.isArray(message.numbers) ? message.numbers : [];
                // Include error:true on fallback entries so the UI can
                // distinguish a network or login failure from an actual
                // "not registered" result.  exists is left false for
                // backwards compatibility but will be ignored when error is set.
                const results = nums.map(n => ({ phone: String(n || ''), exists: false, error: true }));
                try { sendResponse({ results }); } catch (e) {}
                return true;
            }
            return;
        }
        if (message.action === 'checkLogin') {
            // For login checks, forward the request to the page context so
            // that the pageBridge can interrogate the WPP API.  If the
            // forward fails (e.g. not injected yet) default to loggedIn:false.
            if (!allowedHost) {
                try { sendResponse({ loggedIn: false }); } catch (e) {}
                return true;
            }
            ensureWhatsAppBridgeInjected().then(ready => {
                if (!ready) throw new Error('WhatsApp bridge unavailable');
                return postToPage('checkLogin', {});
            }).then(res => {
                try { sendResponse({ loggedIn: !!(res && res.loggedIn) }); } catch (e) {}
            }).catch(() => {
                try { sendResponse({ loggedIn: false }); } catch (e) {}
            });
            return true;
        }
        if (message.action === 'checkPhones') {
            const numbers = Array.isArray(message.numbers) ? message.numbers : [];
            ensureWhatsAppBridgeInjected().then(ready => {
                if (!ready) throw new Error('WhatsApp bridge unavailable');
                return postToPage('checkPhones', { numbers });
            }).then(res => {
                try { sendResponse(res); } catch (e) {}
            }).catch(() => {
                // When the page context does not respond (e.g. injection not
                // ready or user not logged in) return an error for each
                // number rather than silently assuming "not registered".
                try {
                    const fallback = numbers.map(n => ({ phone: String(n || ''), exists: false, error: true }));
                    sendResponse({ results: fallback });
                } catch (e) {}
            });
            return true;
        }
    });
})();