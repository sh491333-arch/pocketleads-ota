/*
 * Content script for local WA number check.
 *
 * This script runs on both web.whatsapp.com/?__wa_check=<number> and
 * wa.me/<number> pages.  When invoked it attempts to determine
 * whether the provided phone number is registered with WhatsApp using
 * only client‑side checks.  It never transmits the number to any
 * external server.  Results are reported back to the background
 * service worker via chrome.runtime.sendMessage.
 */
(function() {
    /**
     * Note: The WA number checker extension includes its own copy of
     * `wa.js` which defines a `WPPMP` namespace.  Injecting this
     * library into the page can trigger errors when WhatsApp updates
     * its internal modules (e.g. missing getters or modules).  To
     * avoid these errors we no longer inject our copy of wa.js.  We
     * instead attempt to use any existing WPPMP or WPP implementations
     * exposed by WhatsApp Web.  If those are unavailable we fall back
     * to Store.Contact.queryExist or to wa.me checks.
     */
    function loadWppMp() {
        return Promise.resolve();
    }
    // Extract the phone number from the current URL.  The number may
    // appear in the ?__wa_check= query parameter on web.whatsapp.com or
    // as the path segment on wa.me.  Leading plus signs and other
    // non‑digit characters are stripped.
    function extractNumber() {
        try {
            const url = new URL(window.location.href);
            // __wa_check parameter on WhatsApp Web
            if (url.searchParams.has('__wa_check')) {
                const param = url.searchParams.get('__wa_check') || '';
                return String(param).replace(/\D/g, '');
            }
            // Path on wa.me (e.g. https://wa.me/1234567890)
            if (url.hostname === 'wa.me' || url.host === 'wa.me') {
                const path = url.pathname.replace(/^\//, '').split('?')[0];
                return String(path).replace(/\D/g, '');
            }
        } catch (e) {
            // ignore URL parsing errors
        }
        return null;
    }

    // Send a result to the background script.  A missing or falsy
    // status will be treated as 'UNKNOWN' by the service worker.
    function report(status, number) {
        const payload = {
            action: 'wa_check_result',
            number: number,
            status: status || 'UNKNOWN'
        };
        try {
            chrome.runtime.sendMessage(payload);
        } catch (e) {
            // ignore send errors
        }
    }

    const number = extractNumber();
    if (!number) {
        return;
    }

    // Attempt an internal check using WhatsApp Web's exposed modules.
    // This returns a promise resolving to 'REGISTERED', 'NOT_REGISTERED'
    // or null if the internal APIs are unavailable or inconclusive.
    async function internalCheck() {
        // Attempt to use any existing WPPMP contact API without injecting our own library.
        // If WPPMP.contact.queryExists is defined we treat a truthy return
        // value as REGISTERED and a falsy value or error as NOT_REGISTERED.
        try {
            if (
                window.WPPMP &&
                window.WPPMP.contact &&
                typeof window.WPPMP.contact.queryExists === 'function'
            ) {
                try {
                    const res = await window.WPPMP.contact.queryExists(number + '@c.us');
                    if (res) {
                        return 'REGISTERED';
                    }
                    return 'NOT_REGISTERED';
                } catch (e) {
                    // Treat errors as not registered
                    return 'NOT_REGISTERED';
                }
            }
        } catch (e) {
            // ignore
        }
        // Use the WPP library if available.  WPP.isRegistered returns
        // a boolean indicating whether the number is registered.
        try {
            if (window.WPP && typeof window.WPP.isRegistered === 'function') {
                try {
                    const res = await window.WPP.isRegistered(number);
                    if (res === true) return 'REGISTERED';
                    if (res === false) return 'NOT_REGISTERED';
                } catch (e) {
                    // ignore errors
                }
            }
        } catch (e) {
            // ignore WPP errors
        }
        // Fall back to native Store modules if present.  Some builds of
        // WhatsApp expose Store.WidFactory and Store.Contact.queryExist.
        try {
            if (
                window.Store &&
                window.Store.WidFactory &&
                typeof window.Store.WidFactory.createWid === 'function' &&
                window.Store.Contact &&
                typeof window.Store.Contact.queryExist === 'function'
            ) {
                const wid = window.Store.WidFactory.createWid(number);
                const result = await window.Store.Contact.queryExist(wid);
                if (result && typeof result === 'object') {
                    if (result.jid) return 'REGISTERED';
                    if (typeof result.exists !== 'undefined') {
                        return result.exists ? 'REGISTERED' : 'NOT_REGISTERED';
                    }
                } else if (result === true) {
                    return 'REGISTERED';
                } else if (result === false) {
                    return 'NOT_REGISTERED';
                }
            }
        } catch (e) {
            // ignore errors
        }
        // If none of the internal APIs are available we return null so
        // the service worker can fall back to wa.me.
        return null;
    }

    // Determine status on wa.me pages by inspecting the DOM.  The page
    // text differs for registered vs unregistered numbers.  Returns
    // 'REGISTERED', 'NOT_REGISTERED' or null if inconclusive.
    function checkWaMe() {
        try {
            const bodyText = document.body && document.body.innerText ? document.body.innerText.toLowerCase() : '';
            if (!bodyText) return null;
            // Error messages on invalid numbers
            if (
                bodyText.includes('phone number shared via url is invalid') ||
                bodyText.includes('not a valid') ||
                bodyText.includes('invalid phone') ||
                bodyText.includes("doesn't exist") ||
                bodyText.includes('does not exist')
            ) {
                return 'NOT_REGISTERED';
            }
            // Success messages inviting the user to chat
            if (
                bodyText.includes('continue to chat') ||
                bodyText.includes('use whatsapp') ||
                bodyText.includes('go to chat')
            ) {
                return 'REGISTERED';
            }
        } catch (e) {
            // ignore DOM errors
        }
        return null;
    }

    // Main check logic.  On web.whatsapp.com we attempt the internal
    // check and only report a result when successful.  The service
    // worker falls back to wa.me when this script reports nothing.
    async function run() {
        const host = window.location.hostname || '';
        if (/(?:^|\.)whatsapp\.com$/.test(host) && window.location.search.includes('__wa_check')) {
            const res = await internalCheck();
            if (res) {
                report(res, number);
            }
            return;
        }
        if (host === 'wa.me') {
            // Immediately attempt to determine status.  If inconclusive,
            // wait briefly for the page to fully load before checking again.
            const initial = checkWaMe();
            if (initial) {
                report(initial, number);
                return;
            }
            setTimeout(() => {
                const finalStatus = checkWaMe() || 'UNKNOWN';
                report(finalStatus, number);
            }, 1500);
            return;
        }
    }
    run();
})();