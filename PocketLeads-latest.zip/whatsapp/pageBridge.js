/*
 * Page‑context bridge for WhatsApp number checking.
 *
 * This script runs in the main page context of WhatsApp Web (world: MAIN)
 * and communicates with the extension’s content script via window.postMessage().
 * It uses the WPP API exposed on `window.WPP` to determine the login state
 * and to check if phone numbers are registered on WhatsApp.  The content
 * script injects this file and forwards messages from the extension to
 * this bridge.  Responses are posted back to the page and then relayed
 * back to the extension.
 */

(() => {
    /**
     * Wait until the WPP API has finished initialising.  Polls
     * `window.WPP.isReady` until it becomes truthy or until the
     * timeout expires.  Resolves with true if ready, false otherwise.
     *
     * @param {number} timeout Maximum wait time in milliseconds
     * @returns {Promise<boolean>}
     */
    function waitForWPPReady(timeout = 15000) {
        /*
         * Wait until either the WPPMP API (provided by wa.js) or
         * WhatsApp's internal Store modules have finished initialising.
         * We no longer rely on the official WPP library (api.js) and
         * now omit wa.js entirely.  Some builds of WhatsApp expose
         * contact.queryExists via WPPMP, while others provide
         * Store.Contact.queryExist.  We poll for either API and
         * resolve true when found, or false after the timeout expires.
         */
        return new Promise((resolve) => {
            const start = Date.now();
            (function check() {
                try {
                    // Ready if WPPMP.contact.queryExists is available
                    if (window.WPPMP && window.WPPMP.contact && typeof window.WPPMP.contact.queryExists === 'function') {
                        resolve(true);
                        return;
                    }
                } catch (e) {
                    // ignore and continue waiting
                }
                try {
                    // Ready if Store.Contact.queryExist and WidFactory.createWid are available
                    if (
                        window.Store &&
                        window.Store.Contact && typeof window.Store.Contact.queryExist === 'function' &&
                        window.Store.WidFactory && typeof window.Store.WidFactory.createWid === 'function'
                    ) {
                        resolve(true);
                        return;
                    }
                } catch (e) {
                    // ignore and continue waiting
                }
                if (Date.now() - start > timeout) {
                    resolve(false);
                    return;
                }
                setTimeout(check, 500);
            })();
        });
    }

    /**
     * Normalize a phone number by removing all non‑digit characters.
     *
     * @param {string} phone
     * @returns {string}
     */
    function normalizePhone(phone) {
        return String(phone || '').replace(/\D/g, '');
    }

    /**
     * Handle messages sent from the extension via window.postMessage().
     * Each message should include a unique `id` so that the content script
     * can correlate responses with requests.  Supported actions:
     *   - checkLogin: returns {id, action:'loginStatus', loggedIn:boolean}
     *   - checkPhones: returns {id, action:'checkPhonesResult', results:[{phone, exists}]}
     */
    async function handleExtensionMessage(event) {
        const data = event && event.data;
        if (!data || data.fromExtension !== true) return;
        const { action, id } = data;
        if (!id || !action) return;

        if (action === 'checkLogin') {
            // Wait for the WPPMP API to be ready.  Historically this
            // script assumed that a ready WPPMP implied an authenticated
            // session, however WhatsApp Web now exposes contact APIs
            // before the user has logged in.  To avoid false positives
            // we perform additional checks for user identifiers stored
            // in localStorage and for user objects exposed by internal
            // Store modules.  Only if a persistent identifier or
            // user object exists do we treat the session as logged in.
            const ready = await waitForWPPReady();
            let loggedIn = false;
            if (ready) {
                try {
                    // Attempt to read a stored WID from localStorage.  After
                    // a successful login WhatsApp stores either
                    // 'last-wid' (legacy) or 'last-wid-md' (multi‑device) in
                    // localStorage.  If either key is set to a non‑empty
                    // value we interpret the session as authenticated.
                    let wid = null;
                    try {
                        const lw = localStorage.getItem('last-wid');
                        const lmd = localStorage.getItem('last-wid-md');
                        const raw = lw || lmd;
                        if (raw) {
                            // Strip surrounding quotes which some builds
                            // include and trim whitespace.  Example: "123@c.us".
                            wid = String(raw).replace(/^"|"$/g, '').trim();
                        }
                    } catch (e) {
                        wid = null;
                    }
                    if (wid && wid.length > 0) {
                        loggedIn = true;
                    } else {
                        // Fallback to internal Store API detection.  On
                        // authenticated sessions WhatsApp exposes
                        // Store.User.getMeUser() or getMaybeMeUser() which
                        // return the current user.  If these methods
                        // exist and return a truthy value the user is logged in.
                        let me = null;
                        try {
                            if (window.Store && window.Store.User && typeof window.Store.User.getMeUser === 'function') {
                                me = window.Store.User.getMeUser();
                            } else if (window.Store && window.Store.User && typeof window.Store.User.getMaybeMeUser === 'function') {
                                me = window.Store.User.getMaybeMeUser();
                            }
                        } catch (e) {
                            me = null;
                        }
                        if (me) {
                            loggedIn = true;
                        } else {
                            // As a last resort, inspect the connection object
                            // exposed via WPPMP.  Some builds populate
                            // WPPMP.conn.user only after authentication.
                            try {
                                if (window.WPPMP && window.WPPMP.conn && window.WPPMP.conn.user) {
                                    loggedIn = true;
                                }
                            } catch (e) {
                                // ignore property access errors
                            }
                        }
                    }
                } catch (e) {
                    // On unexpected errors leave loggedIn false so that
                    // the extension prompts the user to log in.
                    loggedIn = false;
                }
            }
            window.postMessage({ fromPage: true, id: id, action: 'loginStatus', loggedIn: loggedIn }, '*');
            return;
        }

        if (action === 'checkPhones') {
            const numbers = Array.isArray(data.numbers) ? data.numbers : [];
            const results = [];
            // Ensure the WPP or Store APIs are loaded.  We also perform a
            // warm‑up query on a dummy number to prime internal modules.
            // WhatsApp's module loader occasionally throws a missing
            // `getFormattedPhone` error on the first call.  By issuing a
            // throwaway request we allow that error to occur before
            // processing real numbers, ensuring subsequent lookups work.
            await waitForWPPReady();
            try {
                const dummyDigits = '9990000000';
                const dummyJid = dummyDigits + '@c.us';
                if (window.WPPMP && window.WPPMP.contact && typeof window.WPPMP.contact.queryExists === 'function') {
                    // Warm up WPPMP by querying a dummy JID.  Ignore the result.
                    try {
                        await window.WPPMP.contact.queryExists(dummyJid);
                    } catch (err) {
                        // ignore warm‑up errors
                    }
                } else if (
                    window.Store &&
                    window.Store.WidFactory && typeof window.Store.WidFactory.createWid === 'function' &&
                    window.Store.Contact && typeof window.Store.Contact.queryExist === 'function'
                ) {
                    // Warm up Store.Contact by querying a dummy WID.  Ignore the result.
                    try {
                        const wid = window.Store.WidFactory.createWid(dummyDigits);
                        await window.Store.Contact.queryExist(wid);
                    } catch (err) {
                        // ignore warm‑up errors
                    }
                }
            } catch (warmErr) {
                // ignore any unexpected warm‑up exceptions
            }
            // Wait for the WPP/Store API to be ready before each number.  This
            // helps avoid missing results for the first number when the
            // WhatsApp internals are still initialising.
            for (const raw of numbers) {
                await waitForWPPReady();
                // Introduce a short delay before processing the very first number.
                // Even with waitForWPPReady() some builds of WhatsApp Web take
                // additional time to initialise their internal APIs.  Pausing
                // here helps ensure the first lookup does not return an
                // incorrect "not available" result.  Subsequent numbers
                // proceed without delay.
                if (results.length === 0) {
                    await new Promise((resolve) => setTimeout(resolve, 1000));
                }
                const phone = String(raw || '');
                const digits = normalizePhone(phone);
                let exists = false;
                if (digits) {
                    try {
                        // Try WPPMP first if available.
                        if (window.WPPMP && window.WPPMP.contact && typeof window.WPPMP.contact.queryExists === 'function') {
                            const jid = digits + '@c.us';
                            let res;
                            try {
                                res = await window.WPPMP.contact.queryExists(jid);
                            } catch (err) {
                                res = false;
                            }
                            // Interpret the result.  The response can be a boolean or an object
                            // with various truthy properties.  If no truthy indicator is found the
                            // result remains false.
                            if (typeof res === 'boolean') {
                                exists = res;
                            } else if (res && typeof res === 'object') {
                                if (res.jid || res.wid) {
                                    exists = true;
                                } else if (typeof res.exists === 'boolean') {
                                    exists = res.exists;
                                } else {
                                    exists = !!res;
                                }
                            } else {
                                exists = !!res;
                            }
                            // If the WPPMP lookup indicated the number is not registered (exists === false),
                            // perform a secondary lookup via the Store APIs if available.  Some
                            // environments report false for the first WPPMP query when internal
                            // modules are still initialising.  A second lookup via Store.Contact
                            // often yields the correct status.  We deliberately avoid this extra
                            // lookup when the WPPMP result is positive to minimise overhead.
                            if (!exists && window.Store &&
                                window.Store.WidFactory && typeof window.Store.WidFactory.createWid === 'function' &&
                                window.Store.Contact && typeof window.Store.Contact.queryExist === 'function'
                            ) {
                                try {
                                    const wid = window.Store.WidFactory.createWid(digits);
                                    const fallbackResult = await window.Store.Contact.queryExist(wid);
                                    if (fallbackResult && typeof fallbackResult === 'object') {
                                        if (fallbackResult.jid || fallbackResult.wid) {
                                            exists = true;
                                        } else if (typeof fallbackResult.exists === 'boolean') {
                                            exists = fallbackResult.exists;
                                        }
                                    } else if (fallbackResult === true) {
                                        exists = true;
                                    } else if (fallbackResult === false) {
                                        exists = false;
                                    }
                                } catch (fallbackErr) {
                                    // ignore fallback errors and keep exists as false
                                }
                            }
                        } else if (
                            window.Store &&
                            window.Store.WidFactory && typeof window.Store.WidFactory.createWid === 'function' &&
                            window.Store.Contact && typeof window.Store.Contact.queryExist === 'function'
                        ) {
                            // If WPPMP is unavailable, use the Store modules as a fallback.
                            const wid = window.Store.WidFactory.createWid(digits);
                            const result = await window.Store.Contact.queryExist(wid);
                            if (result && typeof result === 'object') {
                                if (result.jid || result.wid) {
                                    exists = true;
                                } else if (typeof result.exists === 'boolean') {
                                    exists = result.exists;
                                }
                            } else if (result === true) {
                                exists = true;
                            } else if (result === false) {
                                exists = false;
                            }
                        }
                    } catch (err) {
                        exists = false;
                    }
                }
                results.push({ phone: phone, exists: exists });
            }
            window.postMessage({ fromPage: true, id: id, action: 'checkPhonesResult', results: results }, '*');
            return;
        }
    }

    // Install one listener for messages from the extension
    window.addEventListener('message', handleExtensionMessage);
})();