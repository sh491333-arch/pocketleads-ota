/*
 * This file is adapted from the original WA number chacker extension's
 * inject.js.  It defines a helper function that will load the WPPMP
 * library into the WhatsApp Web page and expose a simple API for
 * checking if a phone number is registered.  When run in the page
 * context the script listens for messages posted from the content
 * script (see whatsapp/wa_check_content.js) and performs a query
 * using `WPPMP.contact.queryExists`.  Results are posted back to
 * the page so the content script can relay them to the background
 * service worker.
 *
 * The original WA number chacker code included additional UI
 * integration and storage handling which are not needed in this
 * adaptation.  Here we retain only the core functionality: given a
 * list of phone numbers (strings) the script will sequentially
 * evaluate each number and return an object describing whether
 * WhatsApp reports it as existing.  A small random delay is added
 * before each query to mimic the behaviour of the original extension
 * and to avoid overwhelming the page.
 */

(function() {
    // Helper: sleep for a random amount of time between minDelay and
    // maxDelay (in milliseconds).  Returns a promise that resolves
    // after the delay.  The `multiplier` parameter allows scaling
    // delays without changing the input values (see WA number chacker).
    function sleepRandom(minDelay, maxDelay, multiplier) {
        let delay = 0;
        if (maxDelay >= minDelay) {
            // Choose a random integer between minDelay and maxDelay,
            // multiply it and use as milliseconds
            delay = Math.floor(Math.random() * (maxDelay - minDelay + 1) + minDelay) * multiplier;
        }
        return new Promise((resolve) => setTimeout(resolve, delay));
    }

    // Perform a single existence check for a normalised phone number.
    // Returns a promise that resolves to true if the number is
    // registered on WhatsApp or false otherwise.  We wrap the call
    // in a try/catch so that any errors result in a false (not
    // registered) outcome.
    async function checkExists(digits) {
        // Wait up to ~500ms to avoid race conditions on page load
        await sleepRandom(1, 1, 500);
        try {
            if (window.WPPMP && window.WPPMP.contact && typeof window.WPPMP.contact.queryExists === 'function') {
                const res = await window.WPPMP.contact.queryExists(digits + '@c.us');
                return !!res;
            }
        } catch (err) {
            // ignore errors, will return false below
        }
        return false;
    }

    // Extract digits from a raw phone number string.  This replicates
    // the behaviour of the WA number chacker which removes all
    // non‑digits before checking.
    function normalise(raw) {
        const matches = String(raw || '').match(/\d+/g);
        return matches ? matches.join('') : '';
    }

    // Listen for messages from the content script.  Each message
    // expected here should have a `fromExtension` flag and an
    // `id` for correlation.  We only handle the `processNumbers`
    // action which carries an array of phone strings and will post
    // back an array of result objects.
    window.addEventListener('message', async function(event) {
        const data = event && event.data;
        if (!data || data.fromExtension !== true) return;
        if (data.action !== 'processNumbers' || !Array.isArray(data.numbers) || !data.id) return;
        const results = [];
        for (const raw of data.numbers) {
            const digits = normalise(raw);
            let exists = false;
            try {
                exists = await checkExists(digits);
            } catch (e) {
                exists = false;
            }
            results.push({ phone: raw, exists: exists });
        }
        try {
            window.postMessage({ fromPage: true, id: data.id, action: 'processNumbersResult', results: results }, '*');
        } catch (err) {
            // ignore failures
        }
    });
})();