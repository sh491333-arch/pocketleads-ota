/*
 * Preload script for WhatsApp Web.
 *
 * This script runs in the context of the WhatsApp Web page before
 * injecting the WPPMP library (wa.js).  Some modules referenced by
 * wa.js are missing in the latest WhatsApp builds (for example
 * `WAWebFrontendContactGetters.getFormattedPhone`), which causes
 * uncaught errors such as "Property getFormattedPhone was not found"
 * and "func is not an exported function" when the module loader
 * attempts to wrap undefined properties.  Additionally, wa.js will
 * attempt to send usage data to Google Analytics via the
 * `Tracker.collectURL` property, which violates the content security
 * policy in Chrome extensions and results in CSP errors.
 *
 * To mitigate these issues we predefine stub implementations for the
 * missing modules and disable the analytics URL before loading
 * wa.js.  These stubs return harmless defaults so that wa.js can
 * safely access them without throwing exceptions.  We guard access
 * with try/catch blocks to avoid further errors if WhatsApp changes
 * its internal structure.
 */

(() => {
  // Suppress known WhatsApp module loader warnings by filtering specific error messages.
  // Some builds of wa.js will log errors such as
  // "Property getFormattedPhone was not found" or "Module getIsMyContact was not found"
  // when optional modules are missing.  These warnings do not affect the
  // functionality of our extension but clutter the console and may impact
  // performance.  Intercept console.error and ignore these messages while
  // delegating all other errors to the original implementation.
  try {
    const originalConsoleError = console.error;
    console.error = function (...args) {
      try {
        const first = args && args[0];
        if (typeof first === 'string') {
          // Skip error messages relating to missing contact getter modules.
          if (first.includes('Property getFormattedPhone') ||
              first.includes('getIsMyContact') ||
              first.includes('getMentionName') ||
              /*
               * Ignore warnings about missing getSearchVerifiedName and getHeader.
               * Recent builds of WhatsApp Web reference these getters on
               * WAWebContactGetters. When the functions are absent the
               * module loader logs a "Property getSearchVerifiedName was not
               * found" or "Property getHeader was not found" message. These
               * are non‑fatal and handled by the stubs installed below.
               */
              first.includes('getSearchVerifiedName') ||
              first.includes('getHeader') ||
              first.includes('func is not an exported function') ||
              first.includes('multiple-uim-roots')) {
            return;
          }
        }
      } catch (e) {
        // ignore detection errors
      }
      return originalConsoleError.apply(this, args);
    };
  } catch (err) {
    // Ignore console patch errors
  }

  // Install a global error handler to silence non‑fatal UI errors reported by
  // WhatsApp’s ErrorUtils.  Some builds emit a "multiple-uim-roots" error
  // which is harmless but clutters the console.  By catching such errors
  // early we prevent them from propagating.  Other errors are passed
  // through to the browser’s default handler.
  try {
    window.addEventListener('error', function (event) {
      try {
        const msg = (event && event.message) || (event.error && event.error.message) || '';
        if (msg && msg.includes('multiple-uim-roots')) {
          event.stopImmediatePropagation();
          event.preventDefault();
        }
      } catch (e) {}
    }, true);
  } catch (e) {
    // ignore error handler setup failures
  }

  // Override React/WhatsApp ErrorUtils global handler to ignore benign
  // internal exceptions.  Some WhatsApp builds report a "multiple-uim-roots"
  // error through ErrorUtils which is harmless but clutters logs.  If
  // ErrorUtils exposes setGlobalHandler() we wrap the existing handler
  // to filter this message.  This will not prevent other errors from
  // being logged and should not affect functionality.
  try {
    if (window.ErrorUtils) {
      const eu = window.ErrorUtils;
      const origGet = typeof eu.getGlobalHandler === 'function' ? eu.getGlobalHandler : null;
      const origHandler = origGet ? origGet() : (eu._globalHandler || null);
      if (typeof eu.setGlobalHandler === 'function') {
        eu.setGlobalHandler((error, isFatal) => {
          try {
            const msg = error && error.message;
            if (msg && msg.includes('multiple-uim-roots')) {
              return;
            }
          } catch (e) {}
          try {
            if (origHandler) {
              return origHandler(error, isFatal);
            }
          } catch (ex) {}
        });
      }
    }
  } catch (err) {
    // ignore ErrorUtils override errors
  }
  try {
    // Ensure the namespace exists.  Some builds of WhatsApp omit
    // WAWebFrontendContactGetters entirely.  Define it if it does
    // not exist and provide a no‑op getFormattedPhone() method.
    if (typeof window.WAWebFrontendContactGetters !== 'object' || window.WAWebFrontendContactGetters === null) {
      window.WAWebFrontendContactGetters = {};
    }
    if (typeof window.WAWebFrontendContactGetters.getFormattedPhone !== 'function') {
      window.WAWebFrontendContactGetters.getFormattedPhone = function () {
        return '';
      };
    }
    // Also periodically ensure that getFormattedPhone remains defined.  Some
    // versions of WhatsApp reset this property after wa.js initialises,
    // leading to uncaught errors.  Use an interval to reassign the stub
    // method if it becomes undefined.  The interval is cleared after
    // several attempts to minimise overhead.
    (function ensureGetFormattedPhone() {
      let attempts = 0;
      const maxAttempts = 20;
      const interval = setInterval(() => {
        try {
          if (typeof window.WAWebFrontendContactGetters !== 'object' || window.WAWebFrontendContactGetters === null) {
            window.WAWebFrontendContactGetters = {};
          }
          if (typeof window.WAWebFrontendContactGetters.getFormattedPhone !== 'function') {
            window.WAWebFrontendContactGetters.getFormattedPhone = function () {
              return '';
            };
          }
        } catch (e) {}
        attempts++;
        if (attempts >= maxAttempts) {
          clearInterval(interval);
        }
      }, 1000);
    })();

    // Define additional stubs for new WhatsApp module getters.  Recent
    // versions of wa.js attempt to access getIsMyContact and
    // getMentionName from WAWebFrontendContactGetters.  When these
    // properties are undefined the module loader logs warnings and
    // defines empty getters on the module, causing unnecessary
    // exceptions.  Provide safe default implementations here and
    // periodically re‑apply them to handle resets performed by wa.js.
    try {
      if (typeof window.WAWebFrontendContactGetters.getIsMyContact !== 'function') {
        window.WAWebFrontendContactGetters.getIsMyContact = function () {
          return false;
        };
      }
      if (typeof window.WAWebFrontendContactGetters.getMentionName !== 'function') {
        window.WAWebFrontendContactGetters.getMentionName = function () {
          return '';
        };
      }
    } catch (e) {}
    (function ensureExtraGetters() {
      let attempts = 0;
      const maxAttempts = 20;
      const interval = setInterval(() => {
        try {
          if (typeof window.WAWebFrontendContactGetters !== 'object' || window.WAWebFrontendContactGetters === null) {
            window.WAWebFrontendContactGetters = {};
          }
          if (typeof window.WAWebFrontendContactGetters.getIsMyContact !== 'function') {
            window.WAWebFrontendContactGetters.getIsMyContact = function () {
              return false;
            };
          }
          if (typeof window.WAWebFrontendContactGetters.getMentionName !== 'function') {
            window.WAWebFrontendContactGetters.getMentionName = function () {
              return '';
            };
          }
        } catch (e) {}
        attempts++;
        if (attempts >= maxAttempts) {
          clearInterval(interval);
        }
      }, 1000);
    })();
    // Also provide stubs for WAWebContactGetters used by newer
    // WhatsApp builds.  The WPP library and wa.js reference
    // getSearchVerifiedName and getHeader on WAWebContactGetters when
    // available.  In some releases this namespace is missing or these
    // functions are undefined, causing "Property getSearchVerifiedName
    // was not found" and "Property getHeader was not found" warnings.
    // Define the namespace and stub methods if absent.  Reapply
    // periodically to handle resets performed by wa.js.
    try {
      if (typeof window.WAWebContactGetters !== 'object' || window.WAWebContactGetters === null) {
        window.WAWebContactGetters = {};
      }
      if (typeof window.WAWebContactGetters.getSearchVerifiedName !== 'function') {
        window.WAWebContactGetters.getSearchVerifiedName = function () {
          return '';
        };
      }
      if (typeof window.WAWebContactGetters.getHeader !== 'function') {
        window.WAWebContactGetters.getHeader = function () {
          return '';
        };
      }
    } catch (e) {}
    (function ensureContactGetters() {
      let attempts = 0;
      const maxAttempts = 20;
      const interval = setInterval(() => {
        try {
          if (typeof window.WAWebContactGetters !== 'object' || window.WAWebContactGetters === null) {
            window.WAWebContactGetters = {};
          }
          if (typeof window.WAWebContactGetters.getSearchVerifiedName !== 'function') {
            window.WAWebContactGetters.getSearchVerifiedName = function () {
              return '';
            };
          }
          if (typeof window.WAWebContactGetters.getHeader !== 'function') {
            window.WAWebContactGetters.getHeader = function () {
              return '';
            };
          }
        } catch (e) {}
        attempts++;
        if (attempts >= maxAttempts) {
          clearInterval(interval);
        }
      }, 1000);
    })();
  } catch (err) {
    // Silently ignore failures.  These stubs are best‑effort and
    // should never interrupt extension functionality.
  }
  try {
    // Stub the Google Analytics collection URL used by the Tracker
    // class in wa.js.  Setting this to an empty string prevents
    // wa.js from attempting to send data to https://www.google-analytics.com
    // which would otherwise violate the extension's CSP.
    if (window.Tracker && typeof window.Tracker.collectURL === 'string') {
      window.Tracker.collectURL = '';
    }
    // Intercept network requests to Google Analytics.  Override fetch
    // and navigator.sendBeacon to block any attempts to send data to
    // the GA measurement endpoint.  This prevents repeated CSP
    // violations from wa.js while still allowing other network
    // requests to proceed normally.  We wrap these functions only
    // once to minimise overhead.  A regular expression test is used
    // to match GA URLs.
    try {
      // Block both google-analytics.com endpoints and measurement requests
      // containing a GA measurement id (?tid=G-...).
      const blockURL = /google-analytics\.com\/g\/collect|[?&]tid=G-[A-Z0-9]+/;
      // Patch fetch
      if (typeof window.fetch === 'function' && !window.fetch.__gaBlocked) {
        const originalFetch = window.fetch;
        const patchedFetch = function(input, init) {
          try {
            const url = (typeof input === 'string') ? input : (input && input.url);
            if (url && blockURL.test(url)) {
              // Return a resolved Response to satisfy callers without
              // sending the request.  Use status 204 (No Content).
              return Promise.resolve(new Response(null, { status: 204, statusText: 'No Content' }));
            }
          } catch (e) {
            // ignore detection errors
          }
          return originalFetch.apply(this, arguments);
        };
        patchedFetch.__gaBlocked = true;
        window.fetch = patchedFetch;
      }
      // Patch sendBeacon
      if (navigator && typeof navigator.sendBeacon === 'function' && !navigator.sendBeacon.__gaBlocked) {
        const originalBeacon = navigator.sendBeacon.bind(navigator);
        const patchedBeacon = function(url, data) {
          try {
            if (url && blockURL.test(url)) {
              // Pretend the beacon was sent successfully without doing anything
              return true;
            }
          } catch (e) {
            // ignore detection errors
          }
          return originalBeacon.apply(this, arguments);
        };
        patchedBeacon.__gaBlocked = true;
        navigator.sendBeacon = patchedBeacon;
      }
      // Periodically clear Tracker.collectURL in case wa.js or
      // subsequent code resets it.  The interval ensures that any
      // reassignments are nullified within a few seconds.
      setInterval(() => {
        try {
          if (window.Tracker && typeof window.Tracker.collectURL === 'string' && window.Tracker.collectURL) {
            window.Tracker.collectURL = '';
          }
        } catch (e) {}
      }, 5000);
    } catch (netErr) {
      // ignore network patch errors
    }
  } catch (err) {
    // Ignore errors if Tracker is not yet defined.
  }

  try {
    // Register a fallback module for the missing getFormattedPhone function.  The
    // WPP library exposes an injectFallbackModule() helper that allows
    // extensions to provide implementations for missing modules or
    // functions.  Without this, the module loader in wa.js logs
    // "Property getFormattedPhone was not found" and may return
    // undefined on the first call.  Providing a fallback ensures the
    // loader finds this module and avoids throwing errors.
    const injectGetFormattedPhoneFallback = () => {
      try {
        if (window.WPP && typeof window.WPP.injectFallbackModule === 'function') {
          // Provide a fallback implementation that returns the contact's
          // formattedPhone property if available, or an empty string.  The
          // dynamic loader will use this module when the original
          // implementation is missing.
          window.WPP.injectFallbackModule('getFormattedPhone', {
            getFormattedPhone: (contact) => {
              try {
                return (contact && contact.formattedPhone) ? contact.formattedPhone : '';
              } catch (e) {
                return '';
              }
            }
          });
        }
      } catch (e) {
        // ignore injection errors
      }
    };
    // Attempt injection immediately and periodically afterwards in
    // case WPP loads after this script executes.  Limit retries to
    // avoid indefinite intervals.
    injectGetFormattedPhoneFallback();
    (function scheduleFallbackInjection() {
      let attempts = 0;
      const maxAttempts = 20;
      const interval = setInterval(() => {
        injectGetFormattedPhoneFallback();
        attempts++;
        if (attempts >= maxAttempts) {
          clearInterval(interval);
        }
      }, 1000);
    })();

    /*
     * Provide fallback modules for getSearchVerifiedName and getHeader.
     * When these functions are undefined in WhatsApp builds the WPP
     * library will attempt to load them via its dynamic loader and
     * produce warnings.  By injecting fallback modules we prevent
     * lookup errors and ensure calls return empty strings.  This code
     * mirrors the getFormattedPhone fallback above.
     */
    const injectAdditionalFallbacks = () => {
      try {
        if (window.WPP && typeof window.WPP.injectFallbackModule === 'function') {
          // Fallback for getSearchVerifiedName returns empty string by default.
          window.WPP.injectFallbackModule('getSearchVerifiedName', {
            getSearchVerifiedName: (contact) => {
              try {
                // Use contact.searchVerifiedName if available
                return (contact && contact.searchVerifiedName) ? contact.searchVerifiedName : '';
              } catch (e) {
                return '';
              }
            }
          });
          // Fallback for getHeader returns empty string.
          window.WPP.injectFallbackModule('getHeader', {
            getHeader: (contact) => {
              try {
                return (contact && contact.header) ? contact.header : '';
              } catch (e) {
                return '';
              }
            }
          });
        }
      } catch (e) {
        // Suppress injection errors
      }
    };
    // Execute fallback injection immediately and on intervals until WPP is ready
    injectAdditionalFallbacks();
    (function scheduleAdditionalFallbacks() {
      let attempts = 0;
      const maxAttempts = 20;
      const interval = setInterval(() => {
        injectAdditionalFallbacks();
        attempts++;
        if (attempts >= maxAttempts) {
          clearInterval(interval);
        }
      }, 1000);
    })();
  } catch (fallbackErr) {
    // Suppress any errors during fallback injection
  }
})();