/* PocketLeads OTA v40 Fast Loader — bypasses old APK android_core cache */
if (typeof window !== 'undefined' && !window.__pocketLeadsAndroidPolyfillV40Loaded) {
  try {
    var s = document.createElement('script');
    s.src = '/libs/pl-ota-bridge-v40.js';
    (document.head || document.documentElement).appendChild(s);
  } catch (_) {}
}
