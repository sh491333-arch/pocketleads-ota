// DEPLOY THIS COMPLETE FILE as Code.gs in the existing Apps Script project.
// It contains both the existing licence engine and managed provider routing.
// Do not also paste older copies of the backend or managed.gs into the project.
// Enable Advanced Sheets v4, run setupPocketLeadsManaged(), configure reviewed
// PL2_BILLING, then update the existing web-app deployment. See DEPLOYMENT.md.

/**
 * PocketLeads 10.16.2 — complete single-file Apps Script backend
 * ------------------------------------------------------------
 * Same Google Sheet file:
 *   Licence sheet = Sheet1 or any non-API sheet containing the licence key
 *   API sheet     = ApifyAPI / Apify API / API sheet containing Provider + API Key
 *
 * Licence sheet supported layouts:
 *   A: Serial, B: Licence/License Key, C: Count, D: Device IDs (legacy IPs also accepted), E: User Name, F: Status (optional)
 *   A: Serial, B: Licence/License Key, C: Count, D: Device IDs (legacy IPs also accepted), E: Status (old layout)
 *   OR A: Licence/License Key, B: Active Device Count, C: Device IDs, D: Status
 *   Header names are auto-detected when present. If no Status header exists, licence is treated as active.
 *
 * Licence Status column:
 *   active / enabled / yes / blank = allowed
 *   inactive / disabled / blocked / expired / suspend / no / false / off = blocked
 *
 * API sheet recommended columns:
 *   A: Provider              scrappa / googlemaps / serper / apify / numberchecker
 *   B: API Key               token/key (for NumberChecker.AI, paste X-API-Key here)
 *   C: Source ID             Apify Actor ID; optional task_type (ws / ws_business) for NumberChecker.AI
 *   D: Usage Count
 *   E: Status                active / inactive
 *   F: Usage Limit           admin enters a number or the text unlimited
 *   G: Last Used At
 *   H: Last Licence Key
 *   I: Notes
 *   J: API Request Count      actual upstream provider HTTP requests
 *   K: API Result Count       raw rows returned by provider (duplicates included)
 *   L: Unique Lead Count      new canonical dashboard leads reported by extension
 *
 * Old ApifyAPI layout is also supported:
 *   A: Apify API Token, B: Apify Actor ID, C: Usage Count, D: Status,
 *   E: Last Used At, F: Last Licence Key, G: Notes
 */

const SHEET_ID = '1nyVn-59Wu98UkIY8Alek5U9tMdYjteR8NZVrLC14oqY';
const MAX_DEVICES_PER_LICENCE = 3;
// Commercial values are configured on the server; no client default balance.
// v84: blank/missing Usage Limit means unlimited. Only an explicit positive
// numeric limit is enforced. This prevents an active provider row from being
// silently disabled after an arbitrary 1000-result default.
const UNLIMITED_USAGE_LIMIT = 999999999;
// Provider infrastructure quota only. Customer credits remain independent.
const DEFAULT_PROVIDER_USAGE_LIMIT = UNLIMITED_USAGE_LIMIT;
const API_SHEET_NAME = 'ApifyAPI';
const API_SHEET_ALIASES = ['apifyapi', 'apify api', 'apify_api', 'api', 'sheet2', 'api key management', 'apikeymanagement', 'numberchecker', 'numbercheckerapi'];
const BACKEND_NAME = 'PocketLeadsBackend';
const BACKEND_VERSION = 'v41_profile_fallback_routing';
const SUPPORT_EMAIL = 'samimn7890@gmail.com';

function managedBackendEnabled_(){return typeof pl2Enabled_==='function' && pl2Enabled_();}

function doGet(e) { return doPost(e); }

function doPost(e) {
  try {
    var params = parseParams_(e);
    var action = normalizeAction_(params.action || params.type || params.mode || '');
    var key = normalizeLicenceKey_(params.key || params.licenceKey || params.licenseKey || '');
    // v26: device identity is device-fingerprint based. `ip` remains accepted for older migrations.
    var deviceId = String(params.deviceId || params.installationId || params.ip || params.deviceIp || '').trim();
    var legacyIp = String(params.legacyIp || '').trim();
    var legacyDeviceId = String(params.legacyDeviceId || params.previousDeviceId || '').trim();

    if (action === 'ping' || action === 'status') {
      return json_({ status: 'ok', backend: BACKEND_NAME, version: BACKEND_VERSION, secureProxy: true, commercialLicensing: true, serverSideAccounting: true, apiMetricsV2: true, physicalDeviceLicensing: true, deviceIdentityVersion: 2, maxDevices: MAX_DEVICES_PER_LICENCE, supportEmail: SUPPORT_EMAIL });
    }

    if (action === 'getnotifications' || action === 'notifications') {
      return json_(getAdminNotifications_());
    }

    if (action === 'activate' || action === 'release') {
      if (!key || !deviceId) return json_({ status: 'invalid', reason: 'missing_key_or_device' });
      var licenceLock = LockService.getScriptLock();
      licenceLock.waitLock(25000);
      try {
        var activation = handleLicence_(action, key, deviceId, legacyIp, legacyDeviceId);
        if (action === 'activate' && activation.status === 'ok') activation.account = accountBootstrap_(findLicenceRow_(key), key);
        return json_(activation);
      }
      finally { try { licenceLock.releaseLock(); } catch (e0) {} }
    }

    if (action === 'logapierror' || action === 'reportapierror' || action === 'logextractionerror') {
      var optValid = key ? findLicenceRow_(key) : null;
      return json_(handleClientApiErrorReport_(params, key || 'NO_KEY', optValid));
    }
    if (!key) return json_({ status: 'invalid', reason: 'missing_licence_key' });
    var valid = findLicenceRow_(key);
    if (!valid || valid.row < 1) {
      return json_({ status: 'invalid', reason: 'licence_not_found', scannedSheets: getLicenceSheetNames_() });
    }
    var activeCheck = licenceStatusInfo_(valid);
    if (!activeCheck.active) return json_({ status: 'inactive', reason: 'licence_inactive', licenceStatus: activeCheck.value, sheetName: valid.sheet.getName(), row: valid.row, supportEmail: SUPPORT_EMAIL });

    // v24 commercial licence validity: an absolute date expires on that date's
    // end-of-day; duration text such as "6 months" or "1 year" is converted
    // once, on first authenticated use, to a fixed expiry date.
    var validityCheck = licenceValidityInfo_(valid, true);
    if (!validityCheck.active) return json_({ status: validityCheck.expired ? 'expired' : 'invalid', reason: validityCheck.reason || 'licence_expired', expiryDate: validityCheck.expiryDate || '', message: validityCheck.message || 'Licence validity has ended.', supportEmail: SUPPORT_EMAIL });

    // v23 security contract: operational backend actions are bound to an
    // installation that was explicitly activated for this licence. A leaked
    // licence string alone is therefore insufficient to use paid provider APIs.
    if (!deviceId) return json_({ status: 'denied', reason: 'missing_device_id', reactivationRequired: true });
    var deviceCheck = licenceDeviceInfo_(valid, deviceId);
    if (!deviceCheck.active) return json_({ status: 'denied', reason: 'device_not_activated', reactivationRequired: true, count: deviceCheck.count });

    if (action === 'getlicencestatus' || action === 'accountbootstrap') {
      return json_(accountBootstrap_(valid, key));
    }

    if (action === 'getapiconfig' || action === 'getapifyconfig') {
      // Read-only selection: do not hold a global lock during normal config reads.
      return json_(getActiveApiConfig_(params.preferNext === true || String(params.preferNext).toLowerCase() === 'true', key, params.provider || params.apiProvider || '', params.excludeRows || params.excludeRow || ''));
    }

    if (action === 'logapierror' || action === 'reportapierror' || action === 'logextractionerror') {
      return json_(handleClientApiErrorReport_(params, key, valid));
    }

    if (action === 'submitticket') {
      return json_(submitSupportTicket_(params, key));
    }

    if (action === 'getsupporttickets') {
      return json_(getSupportTickets_(key, deviceId));
    }

    if (managedBackendEnabled_()) {
      var reqProv = normalizeProvider_(params.provider || params.apiProvider || '', '', '', true);
      var isWaAuxProvider = (reqProv === 'numberchecker' || reqProv === 'apifywpapi');
      if (action === 'beginextraction') return json_(pl2Guard_(function(){return pl2Begin_(params,key);}));
      if (action === 'finishproviderattempt') return json_(pl2Guard_(function(){return pl2FinishAttempt_(params,key);}));
      if (action === 'providerrequeststatus' && !isWaAuxProvider) return json_(pl2Guard_(function(){return pl2Status_(params,key,valid);}));
      if (action === 'providerproxy' && !isWaAuxProvider) return json_(pl2Guard_(function(){return pl2Proxy_(params,key);}));
      if (action === 'reportleadmetrics' && !isWaAuxProvider) return json_(pl2Guard_(function(){return pl2ReportUniqueLeads_(params,key);}));
      if (/^(reportapiusage|reportapifyusage)$/.test(action) && !isWaAuxProvider) return json_({status:'ok',serverAccounted:true});
      if (/^markapi/.test(action) && !isWaAuxProvider) return json_({status:'denied',reason:'server_managed_provider_health'});
    }
    if (action === 'providerrequeststatus') return json_(providerRequestStatus_(params, key, valid));

    if (action === 'providerproxy') {
      // Network calls must never run while ScriptLock is held. This keeps concurrent
      // users from serialising behind a slow Scrappa/Serper/Apify/Google request.
      return json_(trackedProviderRequest_(params, key, valid));
    }

    if (action === 'reportleadmetrics') {
      var leadMetricLock = LockService.getScriptLock();
      leadMetricLock.waitLock(25000);
      try {
        return json_(reportLeadMetrics_(
          parseInt(params.keyRow, 10) || 0,
          Math.max(0, parseInt(params.uniqueAdded || params.uniqueLeadCount || params.savedCount, 10) || 0),
          String(params.eventId || params.metricEventId || ''),
          key,
          params,
          valid
        ));
      } finally { try { leadMetricLock.releaseLock(); } catch (eMetric) {} }
    }

    if (action === 'reportapiusage' || action === 'reportapifyusage') {
      var usageLock = LockService.getScriptLock();
      usageLock.waitLock(25000);
      try {
        var keyRow = parseInt(params.keyRow, 10) || 0;
        var usedCount = Math.max(0, parseInt(params.usedCount || params.count || params.resultsCount, 10) || 0);
        return json_(reportApiUsage_(keyRow, usedCount, key));
      } finally { try { usageLock.releaseLock(); } catch (e1) {} }
    }

    if (action === 'markapiproblem' || action === 'markapierror' || action === 'markapiblocked') {
      var problemLock = LockService.getScriptLock();
      problemLock.waitLock(25000);
      try { return json_(markApiProblem_(parseInt(params.keyRow, 10) || 0, params.rowStatus || params.statusValue || 'api_blocked', params.reason || params.message || 'api/config error', key)); }
      finally { try { problemLock.releaseLock(); } catch (e2) {} }
    }

    if (action === 'markapilimit' || action === 'markapifailed') {
      var limitLock = LockService.getScriptLock();
      limitLock.waitLock(25000);
      try { return json_(markApiLimit_(parseInt(params.keyRow, 10) || 0, params.reason || params.message || 'limit/error', key)); }
      finally { try { limitLock.releaseLock(); } catch (e3) {} }
    }

    return json_({ status: 'invalid', reason: 'unknown_action', action: action });
  } catch (err) {
    console.error(err && err.stack ? err.stack : err);
    if(action==='providerproxy' && params && params.requestId)return json_({status:'request_uncertain',errorCode:'REQUEST_UNCERTAIN',message:'Request requires reconciliation. Resume checks its receipt without duplicate execution.'});
    return json_({ status: 'error', message: String(err && err.message ? err.message : err) });
  }
}

function withMeta_(obj) {
  obj = obj || {};
  obj.backend = BACKEND_NAME;
  obj.version = BACKEND_VERSION;
  return obj;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(withMeta_(obj))).setMimeType(ContentService.MimeType.JSON);
}

function parseParams_(e) {
  if (e && e.postData && e.postData.contents) {
    try {
      var parsed = JSON.parse(e.postData.contents);
      if (parsed && typeof parsed === 'object') return parsed;
    } catch (err) {}
  }
  var p = (e && e.parameter) ? Object.assign({}, e.parameter) : {};
  if (p._pl_body) {
    try {
      var fromQuery = JSON.parse(p._pl_body);
      if (fromQuery && typeof fromQuery === 'object') return Object.assign(p, fromQuery);
    } catch (err2) {}
  }
  if (p.payload && typeof p.payload === 'string') {
    try { p.payload = JSON.parse(p.payload); } catch (err3) {}
  }
  if (p.autoBegin === 'true') p.autoBegin = true;
  if (p.fastRamProxy === 'true') p.fastRamProxy = true;
  if (p.keyRow) p.keyRow = Number(p.keyRow) || p.keyRow;
  return p;
}

function normalizeAction_(action) {
  var a = String(action || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  if (a === 'getapiconfig' || a === 'getconfig' || a === 'apiconfig' || a === 'getapikey') return 'getapiconfig';
  if (a === 'getapifyconfig' || a === 'apifyconfig') return 'getapifyconfig';
  if (a === 'reportapiusage' || a === 'reportusage' || a === 'usage' || a === 'updateusage') return 'reportapiusage';
  if (a === 'reportapifyusage') return 'reportapifyusage';
  if (a === 'reportleadmetrics' || a === 'reportuniqueleads' || a === 'uniqueleadcount' || a === 'leadmetrics') return 'reportleadmetrics';
  if (a === 'providerproxy' || a === 'proxyprovider' || a === 'secureproxy' || a === 'providerrequest') return 'providerproxy';
  if (a === 'submitticket' || a === 'ticket' || a === 'createsupportticket') return 'submitticket';
  if (a === 'getsupporttickets' || a === 'tickets' || a === 'supportstatus') return 'getsupporttickets';
  if (a === 'markapilimit' || a === 'marklimit' || a === 'apilimit' || a === 'markapifailed') return 'markapilimit';
  if (a === 'getlicencestatus' || a === 'licencestatus' || a === 'licenseinfo' || a === 'planstatus') return 'getlicencestatus';
  if (a === 'logapierror' || a === 'reportapierror' || a === 'logextractionerror' || a === 'reporterror') return 'logapierror';
  if (a === 'activate' || a === 'login') return 'activate';
  if (a === 'release' || a === 'logout') return 'release';
  if (a === 'ping' || a === 'status') return a;
  return a;
}

function normalizeLicenceKey_(key) {
  return String(key || '')
    .replace(/[​-‍⁠﻿ ]/g, '')
    .trim()
    .replace(/[‐‑‒–—―]/g, '-')
    .replace(/^[`'"<>{}\[\]()]+|[`'"<>{}\[\](),;]+$/g, '')
    .replace(/\s+/g, '')
    .toUpperCase();
}

function ss_() { return SpreadsheetApp.openById(SHEET_ID); }

function normalizeSheetName_(name) {
  return String(name || '').trim().toLowerCase().replace(/[\s_\-]+/g, ' ');
}

function compactSheetName_(name) {
  return normalizeSheetName_(name).replace(/\s+/g, '');
}

function sanitizeApiKey_(key) {
  var t = String(key || '').replace(/[\u200B-\u200D\uFEFF\u00A0]/g, '').trim();
  t = t.replace(/^[`'\"<>\[\]{}()]+|[`'\"<>\[\]{}(),;]+$/g, '').trim();
  t = t.replace(/^(x-api-key|x_api_key|api-key|apikey|api key|authorization)\s*[:=]\s*/i, '').trim();
  t = t.replace(/^(bearer|token)\s+/i, '').trim();
  var apify = t.match(/apify_[A-Za-z0-9_\-]{20,}/);
  if (apify) t = apify[0];
  t = t.replace(/\s+/g, '');
  return t;
}

function isApiSheetName_(name) {
  var n = normalizeSheetName_(name);
  var c = compactSheetName_(name);
  return API_SHEET_ALIASES.some(function(alias) {
    var a = normalizeSheetName_(alias);
    return n === a || c === a.replace(/\s+/g, '');
  }) || c.indexOf('apifyapi') >= 0 || n === 'apify api';
}

function headerIndex_(headers, patterns) {
  for (var c = 0; c < headers.length; c++) {
    var h = String(headers[c] || '').toLowerCase().trim();
    if (!h) continue;
    for (var p = 0; p < patterns.length; p++) {
      if (patterns[p].test(h)) return c + 1;
    }
  }
  return 0;
}

function looksLikeApiHeader_(row) {
  row = row || [];
  var providerCol = headerIndex_(row, [/^provider$/, /^api.*provider$/]);
  var apiKeyCol = headerIndex_(row, [/^api\s*key$/, /^api.*token$/, /^token$/, /scrappa.*key/, /serper.*key/, /apify.*token/, /google.*maps.*key/, /places.*key/, /number\s*checker.*key/, /whatsapp.*key/]);
  var actorCol = headerIndex_(row, [/source.*id/, /actor.*id/, /^actor$/, /^id$/]);
  var first = String(row[0] || '').toLowerCase().trim();
  var second = String(row[1] || '').toLowerCase().trim();
  return !!(apiKeyCol || (providerCol && headerIndex_(row, [/usage.*count/, /^usage$/, /^count$/])) || /apify.*token/.test(first) || (/token/.test(first) && /actor/.test(second)) || actorCol && /api/.test(row.join(' ').toLowerCase()));
}

function isApiSheet_(sh) {
  if (!sh) return false;
  if (isApiSheetName_(sh.getName())) return true;
  try {
    var lastCol = Math.max(1, sh.getLastColumn());
    if (sh.getLastRow() >= 1 && lastCol >= 2) {
      var header = sh.getRange(1, 1, 1, Math.min(lastCol, 12)).getValues()[0];
      if (looksLikeApiHeader_(header)) return true;
    }
  } catch (e) {}
  return false;
}

function getLicenceSheetNames_() {
  var ss = ss_();
  return ss.getSheets().filter(function(sh) { return !isApiSheet_(sh); }).map(function(sh) { return sh.getName(); });
}

function licenceSheet_() {
  var ss = ss_();
  var sheets = ss.getSheets();
  for (var i = 0; i < sheets.length; i++) {
    if (!isApiSheet_(sheets[i])) return sheets[i];
  }
  return sheets[0];
}

function findApiSheetByHeader_() {
  var ss = ss_();
  var sheets = ss.getSheets();
  for (var i = 0; i < sheets.length; i++) {
    var sh = sheets[i];
    if (isApiSheetName_(sh.getName())) return sh;
  }
  for (var j = 0; j < sheets.length; j++) {
    var sh2 = sheets[j];
    if (isApiSheet_(sh2)) return sh2;
  }
  return null;
}

function ensureApiMetricColumns_(sh) {
  if (!sh) return {};
  var lastCol = Math.max(1, sh.getLastColumn());
  var headers = sh.getRange(1, 1, 1, lastCol).getValues()[0] || [];
  var required = ['API Request Count', 'API Result Count', 'Unique Lead Count'];
  var normalized = headers.map(function(h) { return String(h || '').trim().toLowerCase(); });
  required.forEach(function(name) {
    if (normalized.indexOf(name.toLowerCase()) >= 0) return;
    lastCol += 1;
    sh.getRange(1, lastCol).setValue(name);
    headers.push(name);
    normalized.push(name.toLowerCase());
  });
  return {
    requestCountCol: normalized.indexOf('api request count') + 1,
    resultCountCol: normalized.indexOf('api result count') + 1,
    uniqueLeadCountCol: normalized.indexOf('unique lead count') + 1
  };
}

function apiSheet_() {
  var ss = ss_();
  var sh = ss.getSheetByName(API_SHEET_NAME) || findApiSheetByHeader_();
  if (!sh) sh = ss.insertSheet(API_SHEET_NAME);
  if (sh.getLastRow() === 0) {
    sh.appendRow(['Provider', 'API Key', 'Source ID', 'Usage Count', 'Status', 'Usage Limit', 'Last Used At', 'Last Licence Key', 'Notes', 'API Request Count', 'API Result Count', 'Unique Lead Count']);
  }
  ensureApiMetricColumns_(sh);
  return sh;
}

function detectLicenceLayout_(sheet) {
  var sh = sheet || licenceSheet_();
  var lastRow = sh.getLastRow();
  var lastCol = Math.max(6, sh.getLastColumn());
  var data = lastRow ? sh.getRange(1, 1, lastRow, lastCol).getValues() : [];

  var headerRow = 1;
  var keyCol = 2;
  var countCol = 3;
  var ipCol = 4;
  var statusCol = 0;
  var googleCreditCol = 0;
  var structuredCreditCol = 0;
  var validityCol = 0;
  var purchaseCreditCol = 0;
  var headerDetected = false;

  var maxHeaderRows = Math.min(8, data.length);
  for (var r = 0; r < maxHeaderRows; r++) {
    var row = data[r];
    var k = headerIndex_(row, [/licen[cs]e.*key/, /key.*licen[cs]e/, /^licen[cs]e$/, /^key$/, /magic.*key/]);
    if (k) {
      headerDetected = true;
      headerRow = r + 1;
      keyCol = k;
      countCol = headerIndex_(row, [/active.*device/, /device.*count/, /^count$/, /^devices?$/, /^active$/]) || (keyCol === 1 ? 2 : 3);
      ipCol = headerIndex_(row, [/^ips?$/, /ip.*address/, /device.*ip/, /installation.*id/]) || (keyCol === 1 ? 3 : 4);
      statusCol = headerIndex_(row, [/^status$/, /licen[cs]e.*status/, /active.*inactive/, /^enabled$/, /^permission$/]) || 0;
      googleCreditCol = headerIndex_(row, [/google.*maps.*(?:api.*)?credit/, /google.*(?:api.*)?credit/, /maps.*credit/]) || 0;
      structuredCreditCol = headerIndex_(row, [/serper.*apify.*credit/, /apify.*serper.*credit/, /structured.*credit/, /serper.*(?:and|&|\+)?\s*apify.*result/]) || 0;
      validityCol = headerIndex_(row, [/licen[cs]e.*valid/, /^validity$/, /expir(?:y|e).*date/, /^expiry$/, /^expires$/]) || 0;
      purchaseCreditCol = headerIndex_(row, [/purchase.*credit/, /purchased.*credit/, /credit.*purchase/, /top.?up.*credit/]) || 0;
      break;
    }
  }

  // v24: when a real header row exists, append the three commercial columns
  // if the admin has not added them yet. Existing columns are never moved.
  if (headerDetected) {
    var nextCol = Math.max(lastCol, sh.getLastColumn());
    if (!googleCreditCol) {
      googleCreditCol = ++nextCol;
      sh.getRange(headerRow, googleCreditCol).setValue('Google Maps API Credit');
    }
    if (!structuredCreditCol) {
      structuredCreditCol = ++nextCol;
      sh.getRange(headerRow, structuredCreditCol).setValue('Serper Apify API Credit');
    }
    if (!validityCol) {
      validityCol = ++nextCol;
      sh.getRange(headerRow, validityCol).setValue('Licence Validity');
    }
    if (!purchaseCreditCol) {
      purchaseCreditCol = ++nextCol;
      sh.getRange(headerRow, purchaseCreditCol).setValue('Purchase Credit');
    }
    lastCol = Math.max(lastCol, nextCol);
  } else {
    keyCol = 2;
    countCol = 3;
    ipCol = 4;
    statusCol = 5;
  }

  return {
    sheet: sh, data: data, headerRow: headerRow, keyCol: keyCol,
    countCol: countCol, ipCol: ipCol, statusCol: statusCol,
    googleCreditCol: googleCreditCol, structuredCreditCol: structuredCreditCol,
    validityCol: validityCol, purchaseCreditCol: purchaseCreditCol, lastCol: lastCol, headerDetected: headerDetected
  };
}
function findLicenceRowInSheet_(key, sh) {
  key = normalizeLicenceKey_(key);
  var meta = detectLicenceLayout_(sh);
  var data = meta.data;
  if (!key || !data.length) return null;

  for (var r = meta.headerRow; r < data.length; r++) {
    if (normalizeLicenceKey_(data[r][meta.keyCol - 1]) === key) {
      return { row: r + 1, sheet: meta.sheet, keyCol: meta.keyCol, countCol: meta.countCol, ipCol: meta.ipCol, statusCol: meta.statusCol, googleCreditCol: meta.googleCreditCol || 0, structuredCreditCol: meta.structuredCreditCol || 0, validityCol: meta.validityCol || 0, purchaseCreditCol: meta.purchaseCreditCol || 0 };
    }
  }

  // Fallback scan: any of the first 15 columns, useful when the key column was moved.
  var scanCols = Math.min(15, meta.lastCol);
  for (var rr = meta.headerRow; rr < data.length; rr++) {
    for (var c = 0; c < scanCols; c++) {
      if (normalizeLicenceKey_(data[rr][c]) === key) {
        var foundKeyCol = c + 1;
        var header = data[Math.max(0, meta.headerRow - 1)] || [];
        // Use Status only if a real Status header exists. Do not confuse User Name with Status.
        var statusCol = headerIndex_(header, [/^status$/, /licen[cs]e.*status/, /active.*inactive/, /^enabled$/, /^permission$/]) || 0;
        return {
          row: rr + 1,
          sheet: meta.sheet,
          keyCol: foundKeyCol,
          countCol: foundKeyCol === 1 ? 2 : 3,
          ipCol: foundKeyCol === 1 ? 3 : 4,
          statusCol: statusCol,
          googleCreditCol: headerIndex_(header, [/google.*maps.*(?:api.*)?credit/, /google.*(?:api.*)?credit/, /maps.*credit/]) || 0,
          structuredCreditCol: headerIndex_(header, [/serper.*apify.*credit/, /apify.*serper.*credit/, /structured.*credit/]) || 0,
          validityCol: headerIndex_(header, [/licen[cs]e.*valid/, /^validity$/, /expir(?:y|e).*date/, /^expiry$/, /^expires$/]) || 0,
          purchaseCreditCol: headerIndex_(header, [/purchase.*credit/, /purchased.*credit/, /credit.*purchase/, /top.?up.*credit/]) || 0
        };
      }
    }
  }
  return null;
}

function findLicenceRow_(key) {
  if(managedBackendEnabled_())return pl2User_(key);
  key = normalizeLicenceKey_(key);
  if (!key) return null;

  function scanOnce_() {
    var ss = ss_();
    var sheets = ss.getSheets();
    var licenceCandidates = sheets.filter(function(sh) { return !isApiSheet_(sh); });
    if (!licenceCandidates.length) licenceCandidates = sheets;
    for (var i = 0; i < licenceCandidates.length; i++) {
      var found = findLicenceRowInSheet_(key, licenceCandidates[i]);
      if (found) return found;
    }
    return null;
  }

  var first = scanOnce_();
  if (first) return first;
  // Formula-backed licence sheets can briefly expose an empty/stale value.
  // Flush and perform one small delayed rescan before returning not_found.
  try {
    SpreadsheetApp.flush();
    Utilities.sleep(200);
  } catch (e) {}
  return scanOnce_();
}


function parseCreditValue_(raw) {
  var text = String(raw === null || typeof raw === 'undefined' ? '' : raw).trim().toLowerCase();
  if (!text) return { unlimited: false, remaining: 0, valid: true, label: '0' };
  if (/^(unlimited|unlimited\s*credits?|lifetime|no\s*limit|infinite|inf|∞)$/i.test(text)) {
    return { unlimited: true, remaining: UNLIMITED_USAGE_LIMIT, valid: true, label: 'unlimited' };
  }
  var n = Number(text.replace(/,/g, ''));
  if (!isFinite(n) || n < 0 || Math.floor(n) !== n) return { unlimited: false, remaining: 0, valid: false, label: String(raw || '') };
  return { unlimited: false, remaining: Math.max(0, n), valid: true, label: String(Math.max(0, n)) };
}

function creditColumnForProvider_(found, provider) {
  var p = normalizeProvider_(provider, '', '', true);
  return p === 'googlemaps' ? (found.googleCreditCol || 0) : (found.structuredCreditCol || 0);
}

function licenceCreditInfo_(found, provider) {
  if(found && found.managed)return pl2Credit_(found);
  var col = creditColumnForProvider_(found, provider);
  var purchaseCol = found.purchaseCreditCol || 0;
  if (!col && !purchaseCol) return { unlimited: false, remaining: 0, valid: false, label: 'unconfigured', column: 0, purchaseRemaining: 0 };
  var info = col ? parseCreditValue_(found.sheet.getRange(found.row, col).getValue()) : { unlimited: false, remaining: 0, valid: true, label: '0' };
  var purchase = purchaseCol ? parseCreditValue_(found.sheet.getRange(found.row, purchaseCol).getValue()) : { unlimited: false, remaining: 0, valid: true, label: '0' };
  if (!info.valid || !purchase.valid) return { unlimited: false, remaining: 0, valid: false, label: 'invalid', column: col, purchaseColumn: purchaseCol, purchaseRemaining: 0 };
  if (info.unlimited || purchase.unlimited) info = { unlimited: true, remaining: UNLIMITED_USAGE_LIMIT, valid: true, label: 'unlimited' };
  else info.remaining = Math.max(0, info.remaining + purchase.remaining);
  info.column = col;
  info.purchaseColumn = purchaseCol;
  info.purchaseRemaining = purchase.unlimited ? UNLIMITED_USAGE_LIMIT : purchase.remaining;
  info.baseRemaining = info.unlimited ? UNLIMITED_USAGE_LIMIT : (col ? parseCreditValue_(found.sheet.getRange(found.row, col).getValue()).remaining : 0);
  info.columns = [purchaseCol, col].filter(function(value, index, values) { return value && values.indexOf(value) === index; });
  info.providerBucket = normalizeProvider_(provider, '', '', true) === 'googlemaps' ? 'googlemaps' : 'structured';
  return info;
}

function parseAbsoluteDate_(raw) {
  if (Object.prototype.toString.call(raw) === '[object Date]' && !isNaN(raw.getTime())) return new Date(raw.getTime());
  var t = String(raw === null || typeof raw === 'undefined' ? '' : raw).trim();
  var m = t.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
  if (m) return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), 23, 59, 59, 999);
  m = t.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
  if (m) return new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]), 23, 59, 59, 999);
  var parsed = new Date(t);
  return isNaN(parsed.getTime()) ? null : parsed;
}

function durationExpiryDate_(text, fromDate) {
  var t = String(text || '').trim().toLowerCase();
  var m = t.match(/^(\d+)\s*(years?|yrs?|y|months?|mos?|mo|m|days?|d)$/i);
  if (!m) return null;
  var amount = Math.max(1, parseInt(m[1], 10) || 0);
  var unit = String(m[2] || '').toLowerCase();
  var d = new Date((fromDate || new Date()).getTime());
  if (/^y/.test(unit)) d.setFullYear(d.getFullYear() + amount);
  else if (/^m/.test(unit)) d.setMonth(d.getMonth() + amount);
  else d.setDate(d.getDate() + amount);
  d.setHours(23, 59, 59, 999);
  return d;
}

function licenceValidityInfo_(found, initializeDuration) {
  if (!found || !found.validityCol) return { active: true, unlimited: true, expiryDate: '', label: 'unlimited' };
  var cell = null;
  var raw = Array.isArray(found.values) ? found.values[found.validityCol - 1] : (cell = found.sheet.getRange(found.row, found.validityCol)).getValue();
  var text = String(raw === null || typeof raw === 'undefined' ? '' : raw).trim();
  if (!text || /^(unlimited|lifetime|permanent|none|no\s*expiry|no\s*limit)$/i.test(text)) {
    return { active: true, unlimited: true, expiryDate: '', label: 'unlimited' };
  }
  var durationExpiry = durationExpiryDate_(text, new Date());
  var expiry = null;
  if (durationExpiry && initializeDuration) {
    expiry = durationExpiry;
    if (!cell) cell = found.sheet.getRange(found.row, found.validityCol);
    cell.setValue(expiry);
    try { cell.setNumberFormat('yyyy-mm-dd'); } catch (e) {}
    try { cell.setNote('PocketLeads: duration "' + text + '" started on first authenticated use and was converted to a fixed expiry date.'); } catch (e2) {}
  } else if (durationExpiry) {
    return { active: true, pendingDuration: true, expiryDate: '', label: text };
  } else {
    expiry = parseAbsoluteDate_(raw);
  }
  if (!expiry || isNaN(expiry.getTime())) {
    return { active: false, expired: false, reason: 'invalid_licence_validity', expiryDate: '', message: 'Licence Validity value is invalid. Use a date, 6 months, 1 year, 30 days, or unlimited.' };
  }
  // Date-only cells remain valid for the complete expiry day.
  expiry.setHours(23, 59, 59, 999);
  var expiryIso = Utilities.formatDate(expiry, Session.getScriptTimeZone() || 'GMT', 'yyyy-MM-dd');
  var nowMs = new Date().getTime();
  if (nowMs > expiry.getTime()) {
    return { active: false, expired: true, reason: 'licence_expired', expiryDate: expiryIso, daysRemaining: 0, message: 'Licence expired on ' + expiryIso + '.' };
  }
  var daysRemaining = Math.max(0, Math.ceil((expiry.getTime() - nowMs) / (1000 * 60 * 60 * 24)));
  return { active: true, unlimited: false, expiryDate: expiryIso, label: expiryIso, daysRemaining: daysRemaining };
}

function licenceCommercialStatus_(found, initializeValidity) {
  var validity = licenceValidityInfo_(found, !!initializeValidity);
  var googleCredit = licenceCreditInfo_(found, 'googlemaps');
  var structuredCredit = found.managed ? googleCredit : licenceCreditInfo_(found, 'serper');
  return {
    status: validity.active ? 'ok' : (validity.expired ? 'expired' : 'invalid'),
    reason: validity.reason || '',
    expiryDate: validity.expiryDate || '',
    daysRemaining: typeof validity.daysRemaining === 'number' ? validity.daysRemaining : null,
    validityLabel: validity.label || '',
    googleMapsCredit: !googleCredit.valid ? null : (googleCredit.unlimited ? 'unlimited' : googleCredit.remaining),
    structuredCredit: !structuredCredit.valid ? null : (structuredCredit.unlimited ? 'unlimited' : structuredCredit.remaining),
    purchaseCredit: found.purchaseCreditCol ? (function(){var raw=Array.isArray(found.values)?found.values[found.purchaseCreditCol-1]:found.sheet.getRange(found.row,found.purchaseCreditCol).getValue();var c=parseCreditValue_(raw);return !c.valid?null:c.unlimited?'unlimited':c.remaining;})() : 0,
    googleMapsCreditExhausted: !googleCredit.unlimited && googleCredit.remaining <= 0,
    structuredCreditExhausted: !structuredCredit.unlimited && structuredCredit.remaining <= 0,
    activeDevices: licenceDeviceInfo_(found, '').count,
    maxDevices: MAX_DEVICES_PER_LICENCE,
    physicalDeviceLicensing: true,
    supportEmail: SUPPORT_EMAIL
  };
}

function licenceStatusInfo_(found) {
  if (!found || !found.sheet || !found.statusCol) return { active: true, value: '' };
  var raw = Array.isArray(found.values) ? found.values[found.statusCol - 1] : found.sheet.getRange(found.row, found.statusCol).getValue();
  var value = String(raw === null || typeof raw === 'undefined' ? '' : raw).trim().toLowerCase();
  if (!value) return { active: true, value: '' };
  if (raw === false) return { active: false, value: 'false' };
  if (/^(inactive|in-active|disabled|disable|deactive|de-active|blocked|block|expired|suspended|suspend|no|false|off|0)$/i.test(value)) {
    return { active: false, value: String(raw) };
  }
  return { active: true, value: String(raw) };
}

function licenceDeviceInfo_(found, deviceId) {
  if (!found || !found.sheet || !found.ipCol) return { active: false, count: 0 };
  var rawIps = Array.isArray(found.values) ? found.values[found.ipCol - 1] : found.sheet.getRange(found.row, found.ipCol).getValue();
  var list = String(rawIps || '')
    .split(',')
    .map(function (s) { return s.trim(); })
    .filter(Boolean)
    .filter(function (item, pos, arr) { return arr.indexOf(item) === pos; });
  var clean = String(deviceId || '').trim();
  return { active: !!clean && list.indexOf(clean) >= 0, count: list.length };
}

function handleLicence_(action, key, deviceId, legacyIp, legacyDeviceId) {
  var found = findLicenceRow_(key);
  if (!found || found.row < 1) return { status: 'invalid', reason: 'licence_not_found', scannedSheets: getLicenceSheetNames_() };
  var activeInfo = licenceStatusInfo_(found);
  if (!activeInfo.active) return { status: 'inactive', reason: 'licence_inactive', licenceStatus: activeInfo.value, sheetName: found.sheet.getName(), row: found.row, supportEmail: SUPPORT_EMAIL };
  var validityInfo = licenceValidityInfo_(found, action === 'activate');
  if (!validityInfo.active) return { status: validityInfo.expired ? 'expired' : 'invalid', reason: validityInfo.reason || 'licence_expired', expiryDate: validityInfo.expiryDate || '', message: validityInfo.message || 'Licence validity has ended.', supportEmail: SUPPORT_EMAIL };

  var sh = found.sheet;
  var countCell = sh.getRange(found.row, found.countCol);
  var ipsCell = sh.getRange(found.row, found.ipCol);
  var ipList = String(ipsCell.getValue() || '')
    .split(',')
    .map(function (s) { return s.trim(); })
    .filter(Boolean)
    .filter(function (item, pos, arr) { return arr.indexOf(item) === pos; });

  var cleanDeviceId = String(deviceId || '').trim();
  var cleanLegacyIp = String(legacyIp || '').trim();
  var cleanLegacyDeviceId = String(legacyDeviceId || '').trim();

  if (action === 'activate') {
    var migrated = false;
    if (ipList.indexOf(cleanDeviceId) === -1) {
      // Smooth v81 -> v83 migration: if the same browser was previously
      // registered by public IP, replace that legacy slot with the persistent
      // installation ID rather than consuming an additional device slot.
      // v88: migrate the previous random installation UUID to the stable
      // physical-device fingerprint in-place. This keeps the same device slot
      // during normal extension update/reload/reinstall migration.
      var legacyDeviceIdx = cleanLegacyDeviceId ? ipList.indexOf(cleanLegacyDeviceId) : -1;
      var legacyIdx = legacyDeviceIdx >= 0 ? legacyDeviceIdx : (cleanLegacyIp ? ipList.indexOf(cleanLegacyIp) : -1);
      if (legacyIdx >= 0) {
        ipList[legacyIdx] = cleanDeviceId;
        migrated = true;
      } else {
        if (ipList.length >= MAX_DEVICES_PER_LICENCE) return { status: 'denied', reason: 'max_devices_reached', count: ipList.length, maxDevices: MAX_DEVICES_PER_LICENCE, deviceBound: true };
        ipList.push(cleanDeviceId);
      }
    }
    ipList = ipList.filter(Boolean).filter(function (item, pos, arr) { return arr.indexOf(item) === pos; });
    countCell.setValue(ipList.length);
    ipsCell.setValue(ipList.join(','));
    var commerce = licenceCommercialStatus_(found, false);
    return { status: 'ok', count: ipList.length, maxDevices: MAX_DEVICES_PER_LICENCE, physicalDeviceLicensing: true, migratedLegacyDevice: migrated, deviceBound: true, licenceStatus: activeInfo.value || 'active', sheetName: sh.getName(), row: found.row, expiryDate: commerce.expiryDate, validityLabel: commerce.validityLabel, googleMapsCredit: commerce.googleMapsCredit, structuredCredit: commerce.structuredCredit, purchaseCredit: commerce.purchaseCredit, supportEmail: SUPPORT_EMAIL };
  }

  if (action === 'release') {
    ipList = ipList.filter(function(item) { return item !== cleanDeviceId && (!cleanLegacyIp || item !== cleanLegacyIp); });
    countCell.setValue(ipList.length);
    ipsCell.setValue(ipList.join(','));
    return { status: 'ok', count: ipList.length, maxDevices: MAX_DEVICES_PER_LICENCE, physicalDeviceLicensing: true, deviceBound: true, licenceStatus: activeInfo.value || 'active', sheetName: sh.getName(), row: found.row };
  }

  return { status: 'invalid', reason: 'unknown_licence_action' };
}

function detectApiLayout_(headers) {
  var providerCol = headerIndex_(headers, [/^provider$/, /^api.*provider$/]);
  var sourceCol = headerIndex_(headers, [/source.*id/, /actor.*id/, /^actor$/, /^source\s*id$/, /^id$/]);
  var firstHeader = String(headers && headers[0] || '').toLowerCase().trim();
  var secondHeader = String(headers && headers[1] || '').toLowerCase().trim();
  var legacyApify = !providerCol && (/apify.*token/.test(firstHeader) || (/token/.test(firstHeader) && /actor/.test(secondHeader)));
  var apiKeyCol = legacyApify ? 1 : headerIndex_(headers, [/^api\s*key$/, /^api.*token$/, /^token$/, /scrappa.*key/, /serper.*key/, /apify.*token/, /google.*maps.*key/, /places.*key/, /number\s*checker.*key/, /whatsapp.*key/]);
  var usageCol = headerIndex_(headers, [/usage.*count/, /^usage$/, /^count$/, /result.*count/, /calls?\s*used/]);
  var statusCol = headerIndex_(headers, [/^status$/, /^active$/, /^enabled$/]);
  var limitCol = headerIndex_(headers, [/usage.*limit/, /^limit$/, /max.*usage/, /call\s*limit/]);
  var lastUsedCol = headerIndex_(headers, [/last.*used/]);
  var lastKeyCol = headerIndex_(headers, [/last.*licen[cs]e/]);
  var notesCol = headerIndex_(headers, [/notes?/, /remark/]);
  var requestCountCol = headerIndex_(headers, [/^api\s*request\s*count$/, /request.*count/, /api.*calls?/]);
  var resultCountCol = headerIndex_(headers, [/^api\s*result\s*count$/, /raw.*result.*count/, /provider.*result.*count/]);
  var uniqueLeadCountCol = headerIndex_(headers, [/^unique\s*lead\s*count$/, /dashboard.*lead.*count/, /saved.*lead.*count/]);

  if (!legacyApify && (providerCol || apiKeyCol)) {
    return {
      generic: true,
      providerCol: providerCol || 0,
      apiKeyCol: apiKeyCol || 2,
      sourceCol: sourceCol || 0,
      usageCol: usageCol || 4,
      statusCol: statusCol || 5,
      limitCol: limitCol || 0,
      lastUsedCol: lastUsedCol || 0,
      lastKeyCol: lastKeyCol || 0,
      notesCol: notesCol || 0,
      requestCountCol: requestCountCol || 0,
      resultCountCol: resultCountCol || 0,
      uniqueLeadCountCol: uniqueLeadCountCol || 0
    };
  }

  return {
    generic: false,
    providerCol: 0,
    apiKeyCol: 1,
    sourceCol: 2,
    usageCol: 3,
    statusCol: 4,
    limitCol: 0,
    lastUsedCol: 5,
    lastKeyCol: 6,
    notesCol: 7,
    requestCountCol: requestCountCol || 0,
    resultCountCol: resultCountCol || 0,
    uniqueLeadCountCol: uniqueLeadCountCol || 0
  };
}

function apiRowStatusAllowed_(statusValue) {
  var status = String(statusValue == null ? '' : statusValue).trim().toLowerCase();
  if (!status) return true;
  return /^(active|enabled|enable|yes|true|on|1)(?:\s|$|[-_:])/i.test(status);
}

function apiRowUsable_(status, usage, limit) {
  if (String(status).trim().toLowerCase()==='usage_limit_reached') return usage < limit;
  return apiRowStatusAllowed_(status);
}

function normalizeProvider_(provider, apiKey, sourceId, generic) {
  var raw = String(provider || '').trim().toLowerCase();
  var p = raw.replace(/[\s_.\-]+/g, '');
  var key = String(apiKey || '').trim().toLowerCase();
  var source = String(sourceId || '').trim().toLowerCase();
  if (p === 'scrappa' || p === 'scrappaco' || p === 'scrappaapi') return 'scrappa';
  if (p === 'serperdev' || p === 'googleserper') return 'serper';
  if (p === 'googlemaps' || p === 'googlemapsapi' || p === 'googleplaces' || p === 'googleplacesapi' || p === 'googlemap' || p === 'gmaps' || p === 'placesapi') return 'googlemaps';
  if (p === 'numberchecker' || p === 'numbercheckerai' || p === 'numbercheckerapi' || p === 'checknumber' || p === 'checknumberai' || p === 'nc' || p === 'ncapi' || p === 'ncwa' || p === 'ncwhatsapp' || p === 'numbercheckerwa' || p === 'numbercheckerwhatsapp') return 'numberchecker';
  if (p === 'whatsapp' || p === 'whatsappapi' || p === 'waapi' || p === 'wpapi' || p === 'whatsappverify' || p === 'waverify') {
    if (key.indexOf('apify_') === 0 || (source && !/^(ws|ws_business|ws_active|ws_avatar|whatsapp|default)$/i.test(source))) return 'apifywpapi';
    return 'numberchecker';
  }
  if (p === 'apifywpapi' || p === 'apifywaapi' || p === 'apifywhatsappapi' || p === 'apifywhatsapp') return 'apifywpapi';
  if (p === 'apify' || p === 'apifyactor') return 'apify';
  if (p) return p;
  if (!generic) return 'apify';
  if (key.indexOf('apify_') === 0 && /whatsapp|wa|wp/i.test(source)) return 'apifywpapi';
  if (key.indexOf('apify_') === 0) return 'apify';
  if (/^(ws|ws_business|ws_active|ws_avatar)$/i.test(source)) return 'numberchecker';
  if (source) return 'apify';
  return 'serper';
}

function parseUsageLimit_(rawValue, hasLimitColumn) {
  var text = String(rawValue == null ? '' : rawValue).trim().toLowerCase();
  if (/^(unlimited|no\s*limit|infinite|inf|∞)$/.test(text)) return { limit: UNLIMITED_USAGE_LIMIT, explicit: true };
  if (!hasLimitColumn || !text) return { limit: DEFAULT_PROVIDER_USAGE_LIMIT, explicit: false };
  var n = Number(text.replace(/,/g, ''));
  if (!isFinite(n) || n < 0 || Math.floor(n) !== n) return { limit: 0, explicit: false };
  return { limit: n, explicit: true };
}

function apiSheetDiagnostics_(data, layout, desired, excluded) {
  var d = { totalRows: 0, keyedRows: 0, activeRows: 0, underLimitRows: 0, providerRows: {}, rejected: { noKey: 0, sourceMissing: 0, unsupportedProvider: 0, providerMismatch: 0, inactive: 0, limitReached: 0, excluded: 0 } };
  for (var r = 1; r < data.length; r++) {
    d.totalRows++;
    var row = data[r];
    var sheetRow = r + 1;
    if (excluded && excluded[sheetRow]) { d.rejected.excluded++; continue; }
    var apiKey = sanitizeApiKey_(row[layout.apiKeyCol - 1]);
    if (!apiKey) { d.rejected.noKey++; continue; }
    d.keyedRows++;
    var sourceId = String(layout.sourceCol ? row[layout.sourceCol - 1] || '' : '').trim();
    var provider = normalizeProvider_(layout.providerCol ? row[layout.providerCol - 1] : '', apiKey, sourceId, layout.generic);
    d.providerRows[provider] = (d.providerRows[provider] || 0) + 1;
    if ((provider === 'apify' || provider === 'apifywpapi') && !sourceId) { d.rejected.sourceMissing++; continue; }
    if (provider !== 'apify' && provider !== 'apifywpapi' && provider !== 'numberchecker' && provider !== 'scrappa' && provider !== 'serper' && provider !== 'googlemaps') { d.rejected.unsupportedProvider++; continue; }
    if (desired && provider !== desired) { d.rejected.providerMismatch++; continue; }
    if (!apiRowUsable_(row[layout.statusCol - 1],Number(row[layout.usageCol-1])||0,parseUsageLimit_(layout.limitCol?row[layout.limitCol-1]:'',!!layout.limitCol).limit)) { d.rejected.inactive++; continue; }
    d.activeRows++;
    var usage = parseInt(row[layout.usageCol - 1], 10) || 0;
    var limitInfo = parseUsageLimit_(layout.limitCol ? row[layout.limitCol - 1] : '', !!layout.limitCol);
    if (usage >= limitInfo.limit) { d.rejected.limitReached++; continue; }
    d.underLimitRows++;
  }
  return d;
}

function providerUnavailableMessage_(d) {
  var r=d.rejected||{};
  if(!d.keyedRows)return 'No API provider key is configured. Ask the administrator to configure a provider row.';
  if(r.sourceMissing)return 'An Apify provider is missing its Actor ID. Configure the Actor ID or enable another provider.';
  if(r.limitReached)return 'Configured provider usage limits are reached, zero, or invalid. Ask the administrator to review Usage Count and Usage Limit.';
  if(r.inactive)return 'Configured provider rows are disabled or marked as blocked/limit_reached. Ask the administrator to review row Status and Notes.';
  if(r.unsupportedProvider)return 'A provider name is not recognized. Use scrappa, serper, apify, googlemaps, or numberchecker.';
  if(r.providerMismatch)return 'The requested provider has no usable configured row. Enable that provider or use automatic routing.';
  return 'No provider is eligible for this plan. Review Enabled Engines, provider configuration, and license credits.';
}

function parseExcludeRows_(value) {
  var out = {};
  if (value === null || typeof value === 'undefined' || value === '') return out;
  var arr = Array.isArray(value) ? value : String(value).split(/[,;|\s]+/);
  arr.forEach(function(v) {
    var n = parseInt(v, 10) || 0;
    if (n > 0) out[n] = true;
  });
  return out;
}

function getActiveApiConfig_(preferNext, licenceKey, desiredProvider, excludeRows) {
  var desiredRaw = String(desiredProvider || '').trim().toLowerCase();
  var desiredCompactCheck = desiredRaw.replace(/[\s_.\-]+/g, '');
  var isWaDesired = /^(numberchecker|numbercheckerai|numbercheckerapi|checknumber|checknumberai|nc|ncapi|ncwa|ncwhatsapp|numbercheckerwa|numbercheckerwhatsapp|apifywpapi|apifywaapi|apifywhatsappapi|apifywhatsapp|whatsapp|whatsappapi|waapi|wpapi|whatsappverify|waverify)$/.test(desiredCompactCheck);
  if(managedBackendEnabled_() && !isWaDesired)return pl2Guard_(function(){return pl2Route_(licenceKey,desiredProvider);});
  var sh = apiSheet_();
  var data = sh.getDataRange().getValues();
  if (!data.length) {
    sh.appendRow(['Provider', 'API Key', 'Source ID', 'Usage Count', 'Status', 'Usage Limit', 'Last Used At', 'Last Licence Key', 'Notes', 'API Request Count', 'API Result Count', 'Unique Lead Count']);
    data = sh.getDataRange().getValues();
  }
  var layout = detectApiLayout_(data[0] || []);
  var desired = desiredRaw;
  if (desired === 'auto') desired = '';
  if (desired === 'serperdev' || desired === 'google-serper') desired = 'serper';
  if (desired === 'googleplaces' || desired === 'google-maps' || desired === 'google-maps-api' || desired === 'gmaps' || desired === 'placesapi') desired = 'googlemaps';
  var desiredCompact = desired.replace(/[\s_.\-]+/g, '');
  if (/^(numberchecker|numbercheckerai|numbercheckerapi|checknumber|checknumberai|nc|ncapi|ncwa|ncwhatsapp|numbercheckerwa|numbercheckerwhatsapp|whatsapp|whatsappverify|waverify)$/.test(desiredCompact)) desired = 'numberchecker';
  else if (desiredCompact === 'apifywpapi' || desiredCompact === 'apifywaapi' || desiredCompact === 'apifywhatsappapi' || desiredCompact === 'apifywhatsapp' || desiredCompact === 'whatsappapi' || desiredCompact === 'waapi' || desiredCompact === 'wpapi') desired = 'apifywpapi';
  var excluded = parseExcludeRows_(excludeRows);
  var candidates = [];
  var licenceFound = licenceKey ? findLicenceRow_(licenceKey) : null;
  var policy = licenceFound ? accountPolicy_(licenceFound) : { engines: [], scraping: false };
  if(policy.maxResultsPerRequest===0)return {status:'denied',reason:'plan_limit_zero',message:'This plan has a zero per-request scraping limit. Contact support.'};
  var googleLicenceCredit = licenceFound ? licenceCreditInfo_(licenceFound, 'googlemaps') : { unlimited: true, remaining: UNLIMITED_USAGE_LIMIT, valid: true };
  var structuredLicenceCredit = licenceFound ? licenceCreditInfo_(licenceFound, 'serper') : { unlimited: true, remaining: UNLIMITED_USAGE_LIMIT, valid: true };
  var entitledGoogle = policy.engines.indexOf('googlemaps') >= 0;
  var entitledStructured = policy.engines.some(function(p){return /^(scrappa|serper|apify)$/.test(p);});
  if (policy.scraping && (entitledGoogle || entitledStructured) &&
      (!entitledGoogle || (googleLicenceCredit.valid && !googleLicenceCredit.unlimited && googleLicenceCredit.remaining <= 0)) &&
      (!entitledStructured || (structuredLicenceCredit.valid && !structuredLicenceCredit.unlimited && structuredLicenceCredit.remaining <= 0)))
    return {status:'credits_exhausted',reason:'licence_credits_exhausted',message:'Your scraping credits are exhausted. Buy credits to continue.',supportEmail:SUPPORT_EMAIL};
  // Count technically usable API rows before applying per-licence credits.
  // This lets auto mode distinguish "no provider configured" from "the only
  // configured provider exists but this customer's credit bucket is empty".
  var rowsBeforeLicenceCredit = { googlemaps: 0, structured: 0 };

  for (var r = 1; r < data.length; r++) {
    var row = data[r];
    var sheetRow = r + 1;
    if (excluded[sheetRow] || providerCooling_(sheetRow)) continue;
    var rawApiKey = String(row[layout.apiKeyCol - 1] || '').trim();
    var sourceId = String(layout.sourceCol ? row[layout.sourceCol - 1] || '' : '').trim();
    var apiKey = sanitizeApiKey_(rawApiKey);
    var provider = normalizeProvider_(layout.providerCol ? row[layout.providerCol - 1] : '', apiKey, sourceId, layout.generic);
    var usage = parseInt(row[layout.usageCol - 1], 10) || 0;
    var status = row[layout.statusCol - 1];
    var usageLimitInfo = parseUsageLimit_(layout.limitCol ? row[layout.limitCol - 1] : '', !!layout.limitCol);
    var usageLimit = usageLimitInfo.limit;
    if (!apiKey) continue;
    var engineAllowed = policy.engines.indexOf(provider) >= 0 || ((provider === 'numberchecker' || provider === 'apifywpapi') && (desired === provider) && policy.engines.length > 0);
    if (!policy.scraping || !engineAllowed) continue;
    if ((provider === 'apify' || provider === 'apifywpapi') && !sourceId) continue;
    if (provider !== 'apify' && provider !== 'apifywpapi' && provider !== 'numberchecker' && provider !== 'scrappa' && provider !== 'serper' && provider !== 'googlemaps') continue;
    // WhatsApp checker provider is selected only when dashboard explicitly asks
    // for provider = numberchecker or apifywpapi. Normal scraping auto-rotation
    // must not spend WA verification rows.
    if (!desired && (provider === 'apifywpapi' || provider === 'numberchecker')) continue;
    if (desired && provider !== desired) continue;
    if (!apiRowUsable_(status,usage,usageLimit)) continue;
    if (usage >= usageLimit) continue;
    if (provider === 'googlemaps') rowsBeforeLicenceCredit.googlemaps++;
    else if (provider === 'scrappa' || provider === 'serper' || provider === 'apify') rowsBeforeLicenceCredit.structured++;
    var licenceCredit = provider === 'googlemaps' ? googleLicenceCredit : structuredLicenceCredit;
    if (!licenceCredit.valid) continue;
    if (!licenceCredit.unlimited && licenceCredit.remaining <= 0) continue;
    candidates.push({ row: sheetRow, provider: provider, apiKey: apiKey, sourceId: sourceId, usage: usage, usageLimit: usageLimit, originalIndex: r });
  }

  if (!candidates.length && desired === 'numberchecker' && licenceFound && licenceFound.sheet) {
    try {
      var lSh = licenceFound.sheet;
      var lHeaders = lSh.getRange(1, 1, 1, Math.max(1, lSh.getLastColumn())).getValues()[0] || [];
      var ncCol = headerIndex_(lHeaders, [/number\s*checker.*key/, /numberchecker/, /whatsapp.*api.*key/, /wa.*api.*key/]);
      if (ncCol > 0) {
        var ncKey = sanitizeApiKey_(lSh.getRange(licenceFound.row, ncCol).getValue());
        if (!ncKey && lSh.getLastRow() >= 2) ncKey = sanitizeApiKey_(lSh.getRange(2, ncCol).getValue());
        if (ncKey) {
          candidates.push({ row: 900000 + licenceFound.row, provider: 'numberchecker', apiKey: ncKey, sourceId: 'ws', usage: 0, usageLimit: UNLIMITED_USAGE_LIMIT, originalIndex: 1 });
        }
      }
    } catch (eNc) {}
  }

  if (!candidates.length) {
    var diagnostics = apiSheetDiagnostics_(data, layout, desired, excluded);
    diagnostics.licenceCredits = {
      googlemaps: googleLicenceCredit.unlimited ? 'unlimited' : googleLicenceCredit.remaining,
      structured: structuredLicenceCredit.unlimited ? 'unlimited' : structuredLicenceCredit.remaining
    };
    var googleCreditExhausted = !googleLicenceCredit.unlimited && googleLicenceCredit.remaining <= 0;
    var structuredCreditExhausted = !structuredLicenceCredit.unlimited && structuredLicenceCredit.remaining <= 0;
    var requestedCredit = desired === 'googlemaps' ? googleLicenceCredit : (desired === 'scrappa' || desired === 'serper' || desired === 'apify' ? structuredLicenceCredit : null);
    var requestedRowsBeforeCredit = desired === 'googlemaps' ? rowsBeforeLicenceCredit.googlemaps : ((desired === 'scrappa' || desired === 'serper' || desired === 'apify') ? rowsBeforeLicenceCredit.structured : 0);
    var requestedCreditExhausted = requestedCredit && requestedRowsBeforeCredit > 0 && !requestedCredit.unlimited && requestedCredit.remaining <= 0;
    var anyTechnicalRow = rowsBeforeLicenceCredit.googlemaps > 0 || rowsBeforeLicenceCredit.structured > 0;
    var allTechnicalRowsBlockedByLicenceCredit = anyTechnicalRow
      && (rowsBeforeLicenceCredit.googlemaps === 0 || googleCreditExhausted)
      && (rowsBeforeLicenceCredit.structured === 0 || structuredCreditExhausted);
    if (requestedCreditExhausted || (!desired && allTechnicalRowsBlockedByLicenceCredit)) {
      diagnostics.rowsBeforeLicenceCredit = rowsBeforeLicenceCredit;
      return {
        status: 'credits_exhausted', reason: 'licence_credits_exhausted',
        message: 'Your scraping credits are exhausted. Upgrade your plan to continue.',
        supportEmail: SUPPORT_EMAIL, apiSheetName: sh.getName(), requestedProvider: desired || 'auto', diagnostics: diagnostics
      };
    }
    if (!policy.scraping) return {status:'denied',reason:'scraping_not_entitled',message:'Scraping is disabled for this plan. Contact support.'};
    if (!policy.engines.length) return {status:'denied',reason:'engine_not_entitled',message:'No scraping engine is enabled for this plan. Contact support.'};
    return {
      status: 'no_api_key',
      reason: 'no_eligible_provider_row', retryAfter:nextProviderRetry_(data.length),
      message: providerUnavailableMessage_(diagnostics),
      usageLimit: UNLIMITED_USAGE_LIMIT,
      supportEmail: SUPPORT_EMAIL,
      apiSheetName: sh.getName(),
      requestedProvider: desired || 'auto',
      diagnostics: diagnostics
    };
  }

  // Engine contract: when auto is requested, prefer complete structured rows.
  // Scrappa is first because Simple Search can return phone/address/site/place_id
  // in one request with up to 200 results. Then Serper, then Apify. Google Maps
  // remains the Place-ID/DOM fallback when no structured provider is usable.
  var primaryProvider;
  if (desired) {
    primaryProvider = desired;
  } else {
    var structuredPriority = { scrappa: 0, serper: 1, apify: 2 };
    var structured = candidates.filter(function(c) { return Object.prototype.hasOwnProperty.call(structuredPriority, c.provider); });
    primaryProvider = (structured.length ? structured : candidates).sort(function(a, b) {
      var ap = Object.prototype.hasOwnProperty.call(structuredPriority, a.provider) ? structuredPriority[a.provider] : 99;
      var bp = Object.prototype.hasOwnProperty.call(structuredPriority, b.provider) ? structuredPriority[b.provider] : 99;
      return ap - bp || a.usage - b.usage || a.originalIndex - b.originalIndex;
    })[0].provider;
  }
  var sameProvider = candidates.filter(function(c) { return c.provider === primaryProvider; });
  var pool = sameProvider.length ? sameProvider : candidates;
  pool.sort(function (a, b) { return a.usage - b.usage || a.row - b.row; });
  var chosen = pool[0];
  if (preferNext && pool.length > 1) chosen = pool[1];
  if (!desired && preferNext && pool.length === 1 && candidates.length > 1) {
    var alternate = candidates.filter(function(c) { return c.row !== chosen.row; }).sort(function(a, b) { return a.usage - b.usage || a.row - b.row; });
    if (alternate.length) chosen = alternate[0];
  }

  // Pure config reads do not write to the Sheet. Last-used metadata is updated
  // only after an actual proxied provider request, reducing Sheet I/O and races.
  return {
    status: 'ok',
    provider: chosen.provider,
    // SECURITY v22: provider credentials and actor/source IDs stay server-side.
    // Client receives only an opaque Sheet row selector and provider metadata.
    apiToken: '',
    actorId: '',
    sourceId: '',
    secureProxy: true,
    sourceConfigured: !!chosen.sourceId,
    keyRow: chosen.row,
    usageCount: chosen.usage,
    usageLimit: chosen.usageLimit,
    apiSheetName: sh.getName(),
    providerLabel: chosen.provider === 'scrappa' ? 'Scrappa' : (chosen.provider === 'serper' ? 'Serper' : (chosen.provider === 'apify' ? 'Apify' : (chosen.provider === 'googlemaps' ? 'Google Maps' : (chosen.provider === 'numberchecker' ? 'NumberChecker.AI' : chosen.provider)))),
    providerContract: 'sheet_authoritative_secure_proxy_v3',
    licenceCreditRemaining: chosen.provider === 'googlemaps'
      ? (googleLicenceCredit.unlimited ? 'unlimited' : googleLicenceCredit.remaining)
      : (structuredLicenceCredit.unlimited ? 'unlimited' : structuredLicenceCredit.remaining),
    supportEmail: SUPPORT_EMAIL,
    engine: chosen.provider === 'googlemaps' ? 'engine2_place_id_url_fallback' : 'engine1_structured_provider'
  };
}


function normalizeApifyActorId_(value) {
  var id = String(value || '').trim();
  if (!id) return '';
  // Regex-only URL parsing keeps this helper compatible with all Apps Script V8
  // deployments; no browser URL global is required.
  var apiMatch = id.match(/^https?:\/\/api\.apify\.com\/v2\/acts\/([^/?#]+)/i);
  if (apiMatch && apiMatch[1]) {
    try { id = decodeURIComponent(apiMatch[1]); } catch (e) { id = apiMatch[1]; }
  } else {
    var storeMatch = id.match(/^https?:\/\/(?:www\.)?apify\.com\/(?:store\/)?([^/?#]+)\/([^/?#]+)/i);
    if (storeMatch && storeMatch[1] && storeMatch[2]) id = storeMatch[1] + '/' + storeMatch[2];
  }
  id = id.replace(/^https?:\/\/api\.apify\.com\/v2\/acts\//i, '').replace(/\/runs.*$/i, '');
  id = id.replace(/^\/+|\/+$/g, '');
  if (id.indexOf('/') >= 0 && id.indexOf('~') < 0) id = id.split('/').slice(0, 2).join('~');
  return encodeURIComponent(id);
}

function getApiRowForProxy_(keyRow, desiredProvider) {
  if (keyRow > 900000 && normalizeProvider_(desiredProvider || '', '', '', true) === 'numberchecker') {
    var licRow = keyRow - 900000;
    var lSh = licenceSheet_();
    if (lSh && licRow >= 2 && licRow <= lSh.getLastRow()) {
      var lHeaders = lSh.getRange(1, 1, 1, Math.max(1, lSh.getLastColumn())).getValues()[0] || [];
      var ncCol = headerIndex_(lHeaders, [/number\s*checker.*key/, /numberchecker/, /whatsapp.*api.*key/, /wa.*api.*key/]);
      if (ncCol > 0) {
        var ncKey = sanitizeApiKey_(lSh.getRange(licRow, ncCol).getValue()) || sanitizeApiKey_(lSh.getRange(2, ncCol).getValue());
        if (ncKey) {
          return { sheet: lSh, layout: {}, row: [], keyRow: keyRow, apiKey: ncKey, sourceId: 'ws', provider: 'numberchecker', usage: 0, usageLimit: UNLIMITED_USAGE_LIMIT };
        }
      }
    }
  }
  var sh = apiSheet_();
  var lastRow = sh.getLastRow();
  if (!keyRow || keyRow < 2 || keyRow > lastRow) return { error: 'invalid_key_row' };
  var headers = sh.getRange(1, 1, 1, Math.max(9, sh.getLastColumn())).getValues()[0];
  var layout = detectApiLayout_(headers || []);
  var row = sh.getRange(keyRow, 1, 1, Math.max(9, sh.getLastColumn())).getValues()[0];
  var apiKey = sanitizeApiKey_(row[layout.apiKeyCol - 1]);
  var sourceId = String(layout.sourceCol ? row[layout.sourceCol - 1] || '' : '').trim();
  var provider = normalizeProvider_(layout.providerCol ? row[layout.providerCol - 1] : '', apiKey, sourceId, layout.generic);
  var requested = normalizeProvider_(desiredProvider || provider, '', '', true);
  var usage = parseInt(row[layout.usageCol - 1], 10) || 0;
  var usageLimitInfo = parseUsageLimit_(layout.limitCol ? row[layout.limitCol - 1] : '', !!layout.limitCol);
  var usageLimit = usageLimitInfo.limit;
  if (providerCooling_(keyRow)) return { error:'provider_cooldown' };
  if (!apiKey) return { error: 'api_key_missing' };
  if (!apiRowUsable_(row[layout.statusCol - 1],usage,usageLimit)) return { error: 'api_row_inactive' };
  if (usage >= usageLimit) return { error: 'api_limit_reached' };
  if (requested && provider !== requested) return { error: 'provider_mismatch', provider: provider };
  if ((provider === 'apify' || provider === 'apifywpapi') && !sourceId) return { error: 'source_id_missing' };
  return { sheet: sh, layout: layout, row: row, keyRow: keyRow, apiKey: apiKey, sourceId: sourceId, provider: provider, usage: usage, usageLimit: usageLimit };
}

function safeJsonParse_(text) {
  if (!text) return null;
  try { return JSON.parse(text); } catch (e) { return text; }
}

function fetchJsonProxy_(url, options) {
  var opts = options || {};
  opts.muteHttpExceptions = true;
  opts.followRedirects = true;
  var response = UrlFetchApp.fetch(url, opts);
  var code = response.getResponseCode();
  var text = response.getContentText() || '';
  var parsed = safeJsonParse_(text);
  if (code < 200 || code >= 300) {
    var detail = '';
    if (parsed && typeof parsed === 'object') {
      detail = (parsed.error && (parsed.error.message || parsed.error.status || parsed.error)) || parsed.message || '';
    }
    if (!detail && typeof parsed === 'string') detail = parsed.slice(0, 500);
    return { ok: false, httpStatus: code, message: String(detail || ('Provider HTTP ' + code)).slice(0, 800), data: parsed };
  }
  return { ok: true, httpStatus: code, data: parsed };
}

function normalizeNumberCheckerPhone_(rawPhone, defaultCountryCode) {
  var raw = String(rawPhone == null ? '' : rawPhone).trim();
  if (!raw) return '';
  var hasPlus = raw.charAt(0) === '+';
  var digits = raw.replace(/\D+/g, '');
  if (!digits) return '';
  var cc = String(defaultCountryCode == null ? '91' : defaultCountryCode).replace(/\D+/g, '') || '91';
  if (hasPlus && digits.length >= 8 && digits.length <= 15) {
    return '+' + digits;
  }
  digits = digits.replace(/^0+/, '');
  if (!digits) return '';
  if (cc === '91') {
    if (digits.length === 10) return '+91' + digits;
    if (digits.length === 12 && digits.indexOf('91') === 0) return '+' + digits;
  }
  if (cc && digits.indexOf(cc) !== 0 && digits.length <= 10) {
    return '+' + cc + digits;
  }
  return '+' + digits;
}

function fetchNumberCheckerMultipart_(url, apiKey, formFields, filePart) {
  var boundary = '----PocketLeadsNCBoundary' + new Date().getTime() + Math.floor(Math.random() * 100000);
  var parts = [];
  if (filePart && filePart.content != null) {
    parts.push(
      '--' + boundary + '\r\n' +
      'Content-Disposition: form-data; name="' + (filePart.fieldName || 'file') + '"; filename="' + (filePart.fileName || 'numbers.txt') + '"\r\n' +
      'Content-Type: ' + (filePart.contentType || 'text/plain; charset=utf-8') + '\r\n\r\n' +
      String(filePart.content) + '\r\n'
    );
  }
  var keys = Object.keys(formFields || {});
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    if (formFields[k] === undefined || formFields[k] === null) continue;
    parts.push(
      '--' + boundary + '\r\n' +
      'Content-Disposition: form-data; name="' + k + '"\r\n\r\n' +
      String(formFields[k]) + '\r\n'
    );
  }
  parts.push('--' + boundary + '--\r\n');
  var payloadBody = parts.join('');
  return fetchJsonProxy_(url, {
    method: 'post',
    contentType: 'multipart/form-data; boundary=' + boundary,
    headers: { 'X-API-Key': apiKey },
    payload: payloadBody
  });
}

function parseCsvLineSimple_(line, delimiter) {
  var out = [];
  var cur = '';
  var inQuotes = false;
  var delim = delimiter || ',';
  for (var i = 0; i < line.length; i++) {
    var ch = line.charAt(i);
    if (ch === '"') {
      if (inQuotes && line.charAt(i + 1) === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === delim && !inQuotes) {
      out.push(cur.trim());
      cur = '';
    } else {
      cur += ch;
    }
  }
  out.push(cur.trim());
  return out;
}

function parseNumberCheckerText_(text) {
  var raw = String(text == null ? '' : text).replace(/^\uFEFF/, '').trim();
  if (!raw) return [];
  if (raw.charAt(0) === '[' || raw.charAt(0) === '{') {
    var parsedJson = safeJsonParse_(raw);
    if (Array.isArray(parsedJson)) return parsedJson;
    if (parsedJson && typeof parsedJson === 'object') {
      if (Array.isArray(parsedJson.items)) return parsedJson.items;
      if (Array.isArray(parsedJson.results)) return parsedJson.results;
      if (Array.isArray(parsedJson.data)) return parsedJson.data;
    }
  }
  var lines = raw.split(/\r?\n/).map(function(l) { return l.trim(); }).filter(Boolean);
  if (!lines.length) return [];
  var firstLine = lines[0];
  var delimiter = firstLine.indexOf('\t') >= 0 && firstLine.indexOf(',') < 0 ? '\t' : (firstLine.indexOf(';') >= 0 && firstLine.indexOf(',') < 0 ? ';' : ',');
  var firstCols = parseCsvLineSimple_(firstLine, delimiter).map(function(h) { return h.replace(/^['"]+|['"]+$/g, '').trim(); });
  var lowerHeaders = firstCols.map(function(h) { return h.toLowerCase(); });
  var hasHeader = lowerHeaders.some(function(h) {
    return /^(number|phone|mobile|phone_number|activated|whatsapp|business|status|result|valid)$/i.test(h);
  });
  var items = [];
  var startRow = hasHeader ? 1 : 0;
  for (var r = startRow; r < lines.length; r++) {
    var cols = parseCsvLineSimple_(lines[r], delimiter);
    if (!cols.length) continue;
    var obj = {};
    if (hasHeader) {
      for (var c = 0; c < lowerHeaders.length; c++) {
        var key = lowerHeaders[c] || ('col_' + c);
        obj[key] = cols[c] !== undefined ? cols[c] : '';
      }
    } else {
      obj.number = cols[0] || '';
      obj.activated = cols[1] !== undefined ? cols[1] : 'yes';
    }
    var num = obj.number || obj.phone || obj.mobile || obj.phone_number || cols[0] || '';
    var act = obj.activated !== undefined ? obj.activated : (obj.whatsapp !== undefined ? obj.whatsapp : (obj.status !== undefined ? obj.status : (obj.result !== undefined ? obj.result : '')));
    obj.number = String(num).trim();
    if (act !== '') obj.activated = String(act).trim();
    if (obj.number) items.push(obj);
  }
  return items;
}

function parseNumberCheckerXlsxBlobs_(blobs) {
  if (!Array.isArray(blobs) || !blobs.length) return [];
  var sharedStrings = [];
  var sheetXml = '';
  for (var i = 0; i < blobs.length; i++) {
    var name = String(blobs[i].getName ? blobs[i].getName() : '');
    if (/sharedStrings\.xml$/i.test(name)) {
      var ssText = blobs[i].getDataAsString('UTF-8');
      var siMatches = ssText.match(/<si[\s>][\s\S]*?<\/si>/gi) || [];
      for (var s = 0; s < siMatches.length; s++) {
        var tMatches = siMatches[s].match(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/gi) || [];
        var combined = tMatches.map(function(t) { return t.replace(/<[^>]+>/g, ''); }).join('');
        sharedStrings.push(combined);
      }
    } else if (/worksheets\/sheet1\.xml$/i.test(name) || (!sheetXml && /worksheets\/sheet\d+\.xml$/i.test(name))) {
      sheetXml = blobs[i].getDataAsString('UTF-8');
    }
  }
  if (!sheetXml) return [];
  var rowMatches = sheetXml.match(/<row[\s>][\s\S]*?<\/row>/gi) || [];
  var tableLines = [];
  for (var r = 0; r < rowMatches.length; r++) {
    var cellMatches = rowMatches[r].match(/<c\s[^>]*?(?:\/>|>[\s\S]*?<\/c>)/gi) || [];
    var rowVals = [];
    for (var c = 0; c < cellMatches.length; c++) {
      var cellXml = cellMatches[c];
      var typeMatch = cellXml.match(/\bt="([^"]+)"/i);
      var cellType = typeMatch ? typeMatch[1] : '';
      var val = '';
      if (cellType === 'inlineStr') {
        var isMatch = cellXml.match(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/i);
        val = isMatch ? isMatch[1] : '';
      } else {
        var vMatch = cellXml.match(/<v>([\s\S]*?)<\/v>/i);
        var rawV = vMatch ? vMatch[1].trim() : '';
        if (cellType === 's') {
          var idx = parseInt(rawV, 10);
          val = (idx >= 0 && idx < sharedStrings.length) ? sharedStrings[idx] : rawV;
        } else {
          val = rawV;
        }
      }
      rowVals.push('"' + String(val).replace(/"/g, '""') + '"');
    }
    if (rowVals.length) tableLines.push(rowVals.join(','));
  }
  return parseNumberCheckerText_(tableLines.join('\n'));
}

function downloadAndParseNumberCheckerResult_(resultUrl, apiKey) {
  var cleanUrl = String(resultUrl || '').trim();
  if (!cleanUrl || !/^https?:\/\//i.test(cleanUrl)) return [];
  var opts = { method: 'get', muteHttpExceptions: true, followRedirects: true };
  var resp = UrlFetchApp.fetch(cleanUrl, opts);
  var code = resp.getResponseCode();
  if ((code === 401 || code === 403) && apiKey) {
    resp = UrlFetchApp.fetch(cleanUrl, { method: 'get', muteHttpExceptions: true, followRedirects: true, headers: { 'X-API-Key': apiKey } });
    code = resp.getResponseCode();
  }
  if (code < 200 || code >= 300) return [];
  try {
    if (typeof Utilities !== 'undefined' && typeof Utilities.unzip === 'function' && typeof resp.getBlob === 'function') {
      var blob = resp.getBlob();
      var cType = String(blob.getContentType ? blob.getContentType() : '').toLowerCase();
      var bName = String(blob.getName ? blob.getName() : '').toLowerCase();
      var isZip = /\.zip(\?|$)/i.test(cleanUrl) || /zip|octet-stream/.test(cType) || /\.zip$/.test(bName);
      if (isZip) {
        try {
          var unzipped = Utilities.unzip(blob);
          for (var i = 0; i < unzipped.length; i++) {
            var uName = String(unzipped[i].getName ? unzipped[i].getName() : '').toLowerCase();
            if (/\.(csv|txt|tsv|json)$/i.test(uName)) {
              var parsedCsv = parseNumberCheckerText_(unzipped[i].getDataAsString('UTF-8'));
              if (parsedCsv && parsedCsv.length) return parsedCsv;
            }
          }
          for (var j = 0; j < unzipped.length; j++) {
            var xName = String(unzipped[j].getName ? unzipped[j].getName() : '').toLowerCase();
            if (/\.xlsx$/i.test(xName)) {
              var innerXlsx = Utilities.unzip(unzipped[j]);
              var parsedXlsx = parseNumberCheckerXlsxBlobs_(innerXlsx);
              if (parsedXlsx && parsedXlsx.length) return parsedXlsx;
            }
          }
          if (unzipped.length) {
            var fallbackText = parseNumberCheckerText_(unzipped[0].getDataAsString('UTF-8'));
            if (fallbackText && fallbackText.length) return fallbackText;
          }
        } catch (zipErr) {}
      }
    }
  } catch (blobErr) {}
  var text = resp.getContentText ? resp.getContentText() : '';
  return parseNumberCheckerText_(text);
}

function redactProviderSecret_(value, secret) {
  if (!secret || value === null || typeof value === 'undefined') return value;
  try {
    var text = JSON.stringify(value);
    if (text.indexOf(secret) < 0) return value;
    text = text.split(secret).join('[REDACTED]');
    return JSON.parse(text);
  } catch (e) {
    if (typeof value === 'string') return String(value).split(secret).join('[REDACTED]');
    return value;
  }
}


function providerResultCap_(provider, operation, payload) {
  provider = normalizeProvider_(provider, '', '', true);
  operation = String(operation || '');
  payload = payload || {};
  if (provider === 'scrappa' && /^(simpleSearch|advancedSearch)$/.test(operation)) return Math.max(1, Math.min(200, parseInt(payload.limit, 10) || 20));
  if (provider === 'serper' && /^(maps|places|search)$/.test(operation)) return 20;
  if (provider === 'googlemaps' && operation === 'textSearch') {
    var body = payload.body || payload || {};
    return Math.max(1, Math.min(20, parseInt(body.pageSize, 10) || 20));
  }
  if ((provider === 'apify' || provider === 'apifywpapi') && /^(getDatasetItems|getRunDatasetItems)$/.test(operation)) {
    return Math.max(1, Math.min(1000, parseInt(payload.limit, 10) || 500));
  }
  return 0;
}

function reserveLicenceCredit_(found, provider, requestedCap, cfg) {
  var cap = Math.max(0, parseInt(requestedCap, 10) || 0);
  var info = licenceCreditInfo_(found, provider);
  if (!info.valid) return { error: 'invalid_licence_credit', reserved: 0, info: info };
  if (cap <= 0) return { reserved: 0, unlimited: info.unlimited, column: info.column };
  var lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    var purchase = info.purchaseColumn ? parseCreditValue_(found.sheet.getRange(found.row, info.purchaseColumn).getValue()) : { remaining: 0, valid: true, unlimited: false };
    var base = info.column ? parseCreditValue_(found.sheet.getRange(found.row, info.column).getValue()) : { remaining: 0, valid: true, unlimited: false };
    if (!purchase.valid || !base.valid) return { error: 'invalid_licence_credit', reserved: 0, info: info };
    var apiCell = cfg && cfg.layout && cfg.layout.usageCol ? cfg.sheet.getRange(cfg.keyRow,cfg.layout.usageCol) : null;
    var apiBefore = apiCell ? Math.max(0,Number(apiCell.getValue())||0) : 0;
    if (apiCell && cfg.usageLimit < UNLIMITED_USAGE_LIMIT) cap=Math.min(cap,Math.max(0,cfg.usageLimit-apiBefore));
    if(cap<=0)return {error:'api_limit_reached',reserved:0};
    function reserveApi(n){if(apiCell)apiCell.setValue(apiBefore+n);return apiCell?n:0;}
    if (purchase.unlimited || base.unlimited) return { reserved: cap, unlimited: true, column: info.column, apiReserved:reserveApi(cap) };
    var before = Math.max(0, (purchase.unlimited ? 0 : purchase.remaining) + (base.unlimited ? 0 : base.remaining));
    if (before <= 0) return { error: 'licence_credit_exhausted', reserved: 0, before: 0, afterReservation: 0, column: info.column };
    var remainingToReserve = Math.min(before, cap);
    var purchaseReserve = Math.min(purchase.unlimited ? 0 : purchase.remaining, remainingToReserve);
    var baseReserve = Math.max(0, remainingToReserve - purchaseReserve);
    if (info.purchaseColumn && purchaseReserve) found.sheet.getRange(found.row, info.purchaseColumn).setValue(purchase.remaining - purchaseReserve);
    if (info.column && baseReserve) found.sheet.getRange(found.row, info.column).setValue(base.remaining - baseReserve);
    return { reserved: remainingToReserve, apiReserved:reserveApi(remainingToReserve), unlimited: false, before: before, afterReservation: before - remainingToReserve, column: info.column, allocations: [{ column: info.purchaseColumn, amount: purchaseReserve }, { column: info.column, amount: baseReserve }] };
  } finally { try { lock.releaseLock(); } catch (e) {} }
}

function scrappaFingerprint_(item, dedupeMode) {
  item = item && typeof item === 'object' ? item : {};
  function norm(v) { return String(v == null ? '' : v).toLowerCase().replace(/\s+/g, ' ').trim(); }
  var place = item.place_id || item.placeId || item.placeID || item.googlePlaceId || item.googleMapsPlaceId || '';
  if (place) return 'place:' + norm(place);
  if (String(dedupeMode || '').toLowerCase() === 'place_id_only') return '';
  var businessId = item.scrappa_business_id || item.business_id || item.businessId || '';
  if (businessId) return 'scrappa_business:' + norm(businessId);
  var cid = item.cid || '';
  if (cid && norm(cid).length >= 6) return 'cid:' + norm(cid);
  var phones = item.phone_numbers || item.phoneNumbers || item.phones || '';
  var phone = Array.isArray(phones) ? (phones.filter(Boolean)[0] || '') : (phones || item.phone_number || item.phoneNumber || item.phone || '');
  phone = String(phone || '').replace(/\D+/g, '');
  var name = norm(item.company_name || item.companyName || item.name || item.title || '');
  var address = norm(item.address || item.full_address || item.fullAddress || item.formatted_address || item.formattedAddress || '');
  var website = norm(item.website || item.websiteUrl || item.websiteURL || item.domain || '');
  if (phone && name) return 'phone_name:' + phone + '|' + name;
  if (name && address) return 'name_address:' + name + '|' + address;
  if (website && name) return 'site_name:' + website + '|' + name;
  return '';
}

function filterUniqueScrappaItems_(items, excludeKeys, cap, dedupeMode) {
  var excluded = {};
  (Array.isArray(excludeKeys) ? excludeKeys : []).forEach(function(k) {
    k = String(k || '').trim();
    if (k) excluded[k] = true;
  });
  var seen = {};
  var out = [];
  var max = Math.max(0, parseInt(cap, 10) || 0);
  (Array.isArray(items) ? items : []).some(function(item) {
    var key = scrappaFingerprint_(item, dedupeMode);
    if (key && (excluded[key] || seen[key])) return false;
    if (key) seen[key] = true;
    out.push(item);
    return max > 0 && out.length >= max;
  });
  return out;
}

function trimAndCountProviderResults_(provider, operation, data, maxCount, payload) {
  var finiteCap = Math.max(0, parseInt(maxCount, 10) || 0);
  var hasFiniteCap = maxCount !== null && typeof maxCount !== 'undefined' && isFinite(Number(maxCount));
  var cap = hasFiniteCap ? finiteCap : UNLIMITED_USAGE_LIMIT;
  var count = 0;
  var rawCount = 0;
  if ((provider === 'apify' || provider === 'apifywpapi') && /^(getDatasetItems|getRunDatasetItems)$/.test(operation) && Array.isArray(data)) {
    rawCount = data.length;
    var arr = data.slice(0, cap);
    return { data: arr, count: arr.length, rawCount: rawCount };
  }
  if (provider === 'numberchecker' && data && typeof data === 'object') {
    var ncItems = Array.isArray(data.items) ? data.items : (data.data && Array.isArray(data.data.items) ? data.data.items : null);
    if (Array.isArray(ncItems)) {
      rawCount = ncItems.length;
      var trimmedNc = ncItems.slice(0, cap);
      var ncOut = Object.assign({}, data, { items: trimmedNc });
      return { data: ncOut, count: trimmedNc.length, rawCount: rawCount };
    }
    return { data: data, count: 0, rawCount: 0 };
  }
  if (provider === 'googlemaps' && operation === 'textSearch' && data && typeof data === 'object') {
    var g = Object.assign({}, data);
    var allPlaces = Array.isArray(data.places) ? data.places : [];
    rawCount = allPlaces.length;
    var places = allPlaces.slice(0, cap);
    g.places = places;
    return { data: g, count: places.length, rawCount: rawCount };
  }
  if (provider === 'scrappa' && /^(simpleSearch|advancedSearch)$/.test(operation) && data && typeof data === 'object') {
    var scrappaOut = Object.assign({}, data);
    var excludes = payload && Array.isArray(payload.excludeKeys) ? payload.excludeKeys : [];
    if (Array.isArray(data.items)) {
      rawCount = data.items.length;
      scrappaOut.items = filterUniqueScrappaItems_(data.items, excludes, cap, payload && payload.dedupeMode);
      return { data: scrappaOut, count: scrappaOut.items.length, rawCount: rawCount };
    }
    if (data.data && typeof data.data === 'object' && Array.isArray(data.data.items)) {
      rawCount = data.data.items.length;
      scrappaOut.data = Object.assign({}, data.data, { items: filterUniqueScrappaItems_(data.data.items, excludes, cap, payload && payload.dedupeMode) });
      return { data: scrappaOut, count: scrappaOut.data.items.length, rawCount: rawCount };
    }
    if (Array.isArray(data.results)) {
      rawCount = data.results.length;
      scrappaOut.results = filterUniqueScrappaItems_(data.results, excludes, cap, payload && payload.dedupeMode);
      return { data: scrappaOut, count: scrappaOut.results.length, rawCount: rawCount };
    }
  }
  if (provider === 'serper' && data && typeof data === 'object') {
    var out=Object.assign({},data), rows=[], seen={};
    var keys=['places','localResults','local_results','placesResults','places_results','mapsResults','maps_results','results','organic'];
    var singles=['place','placeInfo','place_info','result'];
    var recognized=false;
    function add(item){if(!item||typeof item!=='object')return;var id=String(item.placeId||item.place_id||item.cid||item.fid||'')+'|'+String(item.title||item.name||'')+'|'+String(item.address||item.formattedAddress||'');if(id==='||')id=JSON.stringify(item);if(!seen[id]){seen[id]=true;rows.push(item);}}
    function collect(obj){keys.forEach(function(k){if(Array.isArray(obj[k])){recognized=true;obj[k].forEach(add);}delete obj[k];});singles.forEach(function(k){if(obj[k]&&typeof obj[k]==='object'){recognized=true;add(obj[k]);}delete obj[k];});}
    collect(out);
    if(data.data&&typeof data.data==='object'&&!Array.isArray(data.data)){out.data=Object.assign({},data.data);collect(out.data);}
    if(!recognized)throw new Error('Unsupported Serper response shape. No result data delivered.');
    out.places=rows.slice(0,cap);
    return {data:out,count:out.places.length,rawCount:rows.length};
  }
  return { data: data, count: 0, rawCount: 0 };
}

function readMetricCellNumber_(sheet, row, col) {
  if (!sheet || !row || !col) return 0;
  return Math.max(0, parseInt(sheet.getRange(row, col).getValue(), 10) || 0);
}

function finalizeProviderAccounting_(cfg, found, licenceKey, reservation, actualCount, requestSucceeded, metricInfo) {
  var actual = Math.max(0, parseInt(actualCount, 10) || 0);
  var metrics = metricInfo || {};
  var requestDelta = Math.max(0, parseInt(metrics.requestCount, 10) || 0);
  var rawResultDelta = requestSucceeded ? Math.max(0, parseInt(metrics.rawResultCount, 10) || 0) : 0;
  var lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    ensureApiMetricColumns_(cfg.sheet);
    var headersNow = cfg.sheet.getRange(1, 1, 1, Math.max(12, cfg.sheet.getLastColumn())).getValues()[0];
    cfg.layout = detectApiLayout_(headersNow || []);

    var customerActual = actual;
    if (requestSucceeded && metrics.runId && Array.isArray(metrics.leadKeys) && metrics.leadKeys.length === actual)
      customerActual = recordUniqueCharges_(licenceKey, metrics.runId, metrics.leadKeys);
    var creditAfter = null;
    if (reservation && !reservation.unlimited) {
      var refund = requestSucceeded ? Math.max(0, (reservation.reserved || 0) - customerActual) : Math.max(0, reservation.reserved || 0);
      var allocations = Array.isArray(reservation.allocations) ? reservation.allocations.slice().reverse() : [{ column: reservation.column, amount: reservation.reserved || 0 }];
      allocations.forEach(function(allocation) {
        if (!refund || !allocation || !allocation.column || !allocation.amount) return;
        var creditCell = found.sheet.getRange(found.row, allocation.column);
        var currentCredit = parseCreditValue_(creditCell.getValue());
        if (!currentCredit.valid || currentCredit.unlimited) return;
        var creditRefund = Math.min(refund, allocation.amount);
        creditAfter = currentCredit.remaining + creditRefund;
        creditCell.setValue(creditAfter);
        refund -= creditRefund;
      });
    }

    var usageBefore = cfg.usage || 0;
    var usageAfter = usageBefore;
    if (cfg.layout.usageCol) {
      var usageCell = cfg.sheet.getRange(cfg.keyRow, cfg.layout.usageCol);
      var currentUsage = Math.max(0,Number(usageCell.getValue())||0);
      var apiReserved = reservation && reservation.apiReserved || 0;
      usageBefore = Math.max(0,currentUsage-apiReserved);
      usageAfter = usageBefore + (requestSucceeded ? actual : 0);
      if(apiReserved || (requestSucceeded && actual>0)) usageCell.setValue(usageAfter);
      if(cfg.layout.statusCol) {
        var statusCell=cfg.sheet.getRange(cfg.keyRow,cfg.layout.statusCol);
        var rowStatus=String(statusCell.getValue()||'').toLowerCase();
        var notes=cfg.layout.notesCol?String(cfg.sheet.getRange(cfg.keyRow,cfg.layout.notesCol).getValue()||''):'';
        if(cfg.usageLimit < UNLIMITED_USAGE_LIMIT && usageAfter>=cfg.usageLimit && apiRowStatusAllowed_(rowStatus)) statusCell.setValue('usage_limit_reached');
        else if(usageAfter<cfg.usageLimit && (rowStatus==='usage_limit_reached' || (apiReserved>0 && rowStatus==='limit_reached' && !/auto disabled/i.test(notes)))) statusCell.setValue('active');
      }
    }

    var requestBefore = readMetricCellNumber_(cfg.sheet, cfg.keyRow, cfg.layout.requestCountCol);
    var requestAfter = requestBefore;
    if (requestDelta > 0 && cfg.layout.requestCountCol) {
      requestAfter = requestBefore + requestDelta;
      cfg.sheet.getRange(cfg.keyRow, cfg.layout.requestCountCol).setValue(requestAfter);
    }
    var resultBefore = readMetricCellNumber_(cfg.sheet, cfg.keyRow, cfg.layout.resultCountCol);
    var resultAfter = resultBefore;
    if (rawResultDelta > 0 && cfg.layout.resultCountCol) {
      resultAfter = resultBefore + rawResultDelta;
      cfg.sheet.getRange(cfg.keyRow, cfg.layout.resultCountCol).setValue(resultAfter);
    }
    var uniqueLeadCount = readMetricCellNumber_(cfg.sheet, cfg.keyRow, cfg.layout.uniqueLeadCountCol);

    if (requestSucceeded) {
      if (cfg.layout.lastUsedCol) cfg.sheet.getRange(cfg.keyRow, cfg.layout.lastUsedCol).setValue(new Date());
      if (cfg.layout.lastKeyCol) cfg.sheet.getRange(cfg.keyRow, cfg.layout.lastKeyCol).setValue(licenceKey || '');
    }
    return {
      usageBefore: usageBefore,
      usageAfter: usageAfter,
      actualCount: actual,
      creditAfter: (function(){ var c = licenceCreditInfo_(found, cfg.provider); return c.unlimited ? 'unlimited' : c.remaining; })(),
      apiRequestBefore: requestBefore,
      apiRequestAfter: requestAfter,
      apiResultBefore: resultBefore,
      apiResultAfter: resultAfter,
      uniqueLeadCount: uniqueLeadCount
    };
  } finally { try { lock.releaseLock(); } catch (e) {} }
}

function metricEventCacheKey_(eventId) {
  var text = String(eventId || '').trim();
  if (!text) return '';
  var h1 = 2166136261;
  var h2 = 5381;
  for (var i = 0; i < text.length; i++) {
    var c = text.charCodeAt(i);
    h1 ^= c;
    h1 = Math.imul ? Math.imul(h1, 16777619) : ((h1 * 16777619) >>> 0);
    h2 = (((h2 << 5) + h2) ^ c) >>> 0;
  }
  return 'pl_leadmetric_' + (h1 >>> 0).toString(36) + '_' + (h2 >>> 0).toString(36);
}

function reportLeadMetrics_(keyRow, uniqueAdded, eventId, licenceKey, params, licenceFound) {
  var amount = Math.max(0, Math.min(50000, parseInt(uniqueAdded, 10) || 0));
  var creditToDeduct = (params && params.creditToDeduct !== undefined)
    ? Math.max(0, Math.min(50000, parseInt(params.creditToDeduct, 10) || 0))
    : amount;
  var shouldDeduct = !!(params && params.deductUniqueCredit);
  var cacheKey = metricEventCacheKey_(eventId);
  var cache = typeof CacheService !== 'undefined' ? CacheService.getScriptCache() : null;
  if (cache && cacheKey && cache.get(cacheKey)) {
    var foundDup = licenceFound || (licenceKey ? findLicenceRow_(licenceKey) : null);
    return { status: 'ok', serverAccounted: true, duplicateEvent: true, added: 0, uniqueAdded: 0, keyRow: keyRow, account: foundDup ? accountSnapshot_(foundDup) : null };
  }
  var before = 0, after = amount;
  if (keyRow) {
    var sh = apiSheet_();
    if (sh && keyRow >= 2 && keyRow <= sh.getLastRow()) {
      ensureApiMetricColumns_(sh);
      var headers = sh.getRange(1, 1, 1, Math.max(12, sh.getLastColumn())).getValues()[0];
      var layout = detectApiLayout_(headers || []);
      if (layout.uniqueLeadCountCol) {
        before = readMetricCellNumber_(sh, keyRow, layout.uniqueLeadCountCol);
        after = before + amount;
        if (amount > 0) sh.getRange(keyRow, layout.uniqueLeadCountCol).setValue(after);
      }
      if (layout.lastKeyCol && licenceKey) sh.getRange(keyRow, layout.lastKeyCol).setValue(licenceKey);
    }
  }
  var found = licenceFound || (licenceKey ? findLicenceRow_(licenceKey) : null);
  if (shouldDeduct && creditToDeduct > 0 && found) {
    var prov = normalizeProvider_((params && params.provider) || 'scrappa', '', '', true) || 'scrappa';
    try { consumeLicenceCredits_(found, prov, creditToDeduct); } catch (_) {}
    found = findLicenceRow_(licenceKey) || found;
  }
  if (cache && cacheKey) cache.put(cacheKey, '1', 21600);
  return { status: 'ok', serverAccounted: true, duplicateEvent: false, added: amount, uniqueAdded: amount, creditDeducted: shouldDeduct ? creditToDeduct : 0, before: before, uniqueLeadCount: after, keyRow: keyRow, account: found ? accountSnapshot_(found) : null };
}

function handleProviderProxy_(params, licenceKey, licenceFound) {
  var provider = normalizeProvider_(params.provider || params.apiProvider || '', '', '', true);
  var keyRow = parseInt(params.keyRow, 10) || 0;
  var operation = String(params.operation || params.op || '').trim();
  var payload = params.payload && typeof params.payload === 'object' ? params.payload : {};
  var payloadSize = 0;
  try { payloadSize = JSON.stringify(payload).length; } catch (e) { payloadSize = 999999999; }
  if (payloadSize > 262144) return { status: 'error', reason: 'payload_too_large', provider: provider, operation: operation };
  var cfg = getApiRowForProxy_(keyRow, provider);
  // v84: if the selected row became inactive/exhausted between config selection
  // and the actual request, recover on the server using another healthy row of
  // the SAME provider. Secrets remain server-side and the client does not need
  // an extra config round-trip.
  if (!params.requestId && cfg.error && /^(invalid_key_row|api_key_missing|api_row_inactive|api_limit_reached)$/.test(String(cfg.error))) {
    var replacement = getActiveApiConfig_(false, licenceKey, provider || 'auto', keyRow ? String(keyRow) : '');
    if (replacement && replacement.status === 'ok' && replacement.keyRow) {
      keyRow = parseInt(replacement.keyRow, 10) || keyRow;
      cfg = getApiRowForProxy_(keyRow, provider || replacement.provider);
    }
  }
  if (cfg.error) return {
    status: cfg.error === 'api_limit_reached' ? 'no_api_key' : 'error',
    reason: cfg.error,
    provider: cfg.provider || provider,
    keyRow: keyRow,
    message: 'Provider row is not usable: ' + cfg.error
  };
  provider = cfg.provider;
  licenceFound = licenceFound || findLicenceRow_(licenceKey);
  if (!licenceFound) return { status: 'invalid', reason: 'licence_not_found' };
  var policy = accountPolicy_(licenceFound);
  var isEntitledEngine = policy.engines.indexOf(provider) >= 0 || ((provider === 'numberchecker' || provider === 'apifywpapi') && policy.engines.length > 0);
  if (!policy.scraping || !isEntitledEngine) return { status: 'denied', reason: 'engine_not_entitled', message: 'This engine is not enabled for your plan.' };
  var providerCap = providerResultCap_(provider, operation, payload);
  if (policy.maxResultsPerRequest !== 'unlimited') providerCap = Math.min(providerCap, policy.maxResultsPerRequest);
  if (policy.maxResultsPerRequest === 0) return { status: 'denied', reason: 'plan_limit_zero' };
  var apiRemaining = cfg.usageLimit >= UNLIMITED_USAGE_LIMIT ? providerCap : Math.max(0, cfg.usageLimit - cfg.usage);
  var effectiveCap = providerCap > 0 ? Math.min(providerCap, apiRemaining) : 0;
  var creditInfo = licenceCreditInfo_(licenceFound, provider);
  if (!creditInfo.valid) return { status: 'credit_config_error', reason: 'invalid_licence_credit', provider: provider, supportEmail: SUPPORT_EMAIL, message: 'Licence credit value is invalid. Contact support.' };
  if (!creditInfo.unlimited && creditInfo.remaining <= 0) return { status: 'credits_exhausted', reason: 'licence_credit_exhausted', provider: provider, supportEmail: SUPPORT_EMAIL, message: 'Your scraping credits are exhausted. Upgrade your plan to continue.' };
  if (providerCap > 0 && !creditInfo.unlimited) effectiveCap = Math.min(effectiveCap || providerCap, creditInfo.remaining);
  if (providerCap > 0 && effectiveCap <= 0) return { status: 'credits_exhausted', reason: 'licence_credit_exhausted', provider: provider, supportEmail: SUPPORT_EMAIL, message: 'Your scraping credits are exhausted. Upgrade your plan to continue.' };

  // Reduce provider-side batch sizes where possible so the backend does not fetch
  // substantially more data than the licence/API row can legally consume.
  if (effectiveCap > 0) {
    if (provider === 'scrappa' && /^(simpleSearch|advancedSearch)$/.test(operation)) {
      payload.limit = Math.min(Math.max(1, parseInt(payload.limit, 10) || effectiveCap), effectiveCap);
    } else if (provider === 'googlemaps' && operation === 'textSearch') {
      payload.body = Object.assign({}, payload.body || payload, { pageSize: Math.min(20, effectiveCap) });
    } else if ((provider === 'apify' || provider === 'apifywpapi') && /^(getDatasetItems|getRunDatasetItems)$/.test(operation)) {
      payload.limit = Math.min(parseInt(payload.limit, 10) || effectiveCap, effectiveCap);
    } else if ((provider === 'apify' || provider === 'apifywpapi') && operation === 'runActor' && !creditInfo.unlimited) {
      var existingMax = Math.max(0, parseInt(payload.maxItems, 10) || 0);
      payload.maxItems = existingMax ? Math.min(existingMax, creditInfo.remaining) : creditInfo.remaining;
    }
  }

  if ((provider==='apify'||provider==='apifywpapi') && operation==='runActor') {
    var actorCaps=[];
    if(Number(payload.maxItems)>0)actorCaps.push(Math.floor(Number(payload.maxItems)));
    if(!creditInfo.unlimited)actorCaps.push(creditInfo.remaining);
    if(cfg.usageLimit<UNLIMITED_USAGE_LIMIT)actorCaps.push(Math.max(0,cfg.usageLimit-cfg.usage));
    if(policy.maxResultsPerRequest!=='unlimited')actorCaps.push(policy.maxResultsPerRequest);
    if(actorCaps.length)payload.maxItems=Math.min.apply(Math,actorCaps);
    if(actorCaps.length && payload.maxItems<=0)return {status:'credits_exhausted',reason:'actor_capacity_exhausted',message:'No credit or provider capacity remains for this actor.'};
  }
  var reservation = providerCap > 0 ? reserveLicenceCredit_(licenceFound, provider, effectiveCap, cfg) : { reserved: 0, unlimited: creditInfo.unlimited, column: creditInfo.column };
  if (reservation.error) return { status: reservation.error === 'licence_credit_exhausted' ? 'credits_exhausted' : 'credit_config_error', reason: reservation.error, provider: provider, supportEmail: SUPPORT_EMAIL, message: reservation.error === 'licence_credit_exhausted' ? 'Your scraping credits are exhausted. Upgrade your plan to continue.' : 'Licence credit value is invalid. Contact support.' };
  var result;
  var providerRequestCount = 0;
  function providerFetch_(url, options) {
    providerRequestCount += 1;
    var response=fetchJsonProxy_(url, options);
    if(operation!=='runActor' && response && [502,503,504].indexOf(Number(response.httpStatus))>=0){
      Utilities.sleep(250);providerRequestCount+=1;response=fetchJsonProxy_(url, options);
    }
    return response;
  }

  try {
    if (provider === 'scrappa') {
      if (!/^(simpleSearch|advancedSearch)$/.test(operation)) {
        result = { ok: false, httpStatus: 400, message: 'Unsupported Scrappa operation.', data: { reason: 'unsupported_operation' } };
      } else {
        var scrappaQuery = String(payload.query || '').trim();
        if (!scrappaQuery) {
          result = { ok: false, httpStatus: 400, message: 'Scrappa query is required.', data: { reason: 'missing_query' } };
        } else {
          var scrappaParams = [
            'query=' + encodeURIComponent(scrappaQuery),
            'limit=' + encodeURIComponent(Math.max(1, Math.min(200, parseInt(payload.limit, 10) || 20))),
            'page=' + encodeURIComponent(Math.max(0, parseInt(payload.page, 10) || 0)),
            'hl=' + encodeURIComponent(String(payload.hl || 'en'))
          ];
          if (payload.gl) scrappaParams.push('gl=' + encodeURIComponent(String(payload.gl).toLowerCase()));
          if (payload.google_domain) scrappaParams.push('google_domain=' + encodeURIComponent(String(payload.google_domain)));
          if (payload.fields) scrappaParams.push('fields=' + encodeURIComponent(String(payload.fields)));
          var scrappaEndpoint = 'simple-search';
          if (operation === 'advancedSearch') {
            var scrappaZoom = Math.max(3, Math.min(21, parseInt(payload.zoom, 10) || 14));
            var scrappaLat = parseFloat(payload.lat);
            var scrappaLon = parseFloat(payload.lon);
            if (!isFinite(scrappaLat) || !isFinite(scrappaLon)) {
              result = { ok: false, httpStatus: 400, message: 'Scrappa advanced search requires valid lat/lon.', data: { reason: 'missing_coordinates' } };
            } else {
              scrappaParams.push('zoom=' + encodeURIComponent(String(scrappaZoom)));
              scrappaParams.push('lat=' + encodeURIComponent(String(scrappaLat)));
              scrappaParams.push('lon=' + encodeURIComponent(String(scrappaLon)));
              scrappaEndpoint = 'advanced-search';
            }
          }
          if (!result) {
            var scrappaUrl = 'https://scrappa.co/api/maps/' + scrappaEndpoint + '?' + scrappaParams.join('&');
            var scrappaFetchOptions = {
              method: 'get',
              headers: { 'X-API-KEY': cfg.apiKey }
            };
            result = providerFetch_(scrappaUrl, scrappaFetchOptions);
            // v32: Scrappa documents HTTP 503 as a temporary/retryable upstream
            // condition. Retry once only after that definitive provider response.
            // Normal successful pincode searches still make exactly one request.
            // We intentionally do not retry auth/quota/validation errors here.
            if (result && !result.ok && parseInt(result.httpStatus, 10) === 503) {
              Utilities.sleep(450);
              result = providerFetch_(scrappaUrl, scrappaFetchOptions);
            }
          }
        }
      }
    } else if (provider === 'serper') {
      var serperOps = { maps: 'maps', places: 'places', search: 'search' };
      var endpoint = serperOps[operation];
      if (!endpoint) return { status: 'error', reason: 'unsupported_operation', provider: provider, operation: operation };
      result = providerFetch_('https://google.serper.dev/' + endpoint, {
        method: 'post',
        contentType: 'application/json',
        headers: { 'X-API-KEY': cfg.apiKey },
        payload: JSON.stringify(payload.body || payload)
      });
    } else if (provider === 'googlemaps') {
      if (operation !== 'textSearch') return { status: 'error', reason: 'unsupported_operation', provider: provider, operation: operation };
      result = providerFetch_('https://places.googleapis.com/v1/places:searchText', {
        method: 'post',
        contentType: 'application/json',
        headers: {
          'X-Goog-Api-Key': cfg.apiKey,
          // Cost/security guard is enforced server-side, never accepted from client.
          'X-Goog-FieldMask': 'places.id,nextPageToken'
        },
        payload: JSON.stringify(payload.body || payload)
      });
    } else if (provider === 'numberchecker') {
      var ncBaseUrl = 'https://api.numberchecker.ai';
      var ncTaskType = String(payload.taskType || payload.task_type || cfg.sourceId || 'ws').trim();
      if (!/^(ws|ws_business|ws_active|ws_avatar)$/i.test(ncTaskType)) ncTaskType = 'ws';
      if (operation === 'createTask' || operation === 'submitTask' || operation === 'runActor') {
        var rawList = Array.isArray(payload.numbers) ? payload.numbers : String(payload.numbers || payload.input || '').split(/[\r\n,;]+/);
        var defaultCc = String(payload.countryCode || payload.dialCode || '91').replace(/\D+/g, '') || '91';
        var seenNums = {};
        var normalizedNums = [];
        for (var ni = 0; ni < rawList.length; ni++) {
          var e164 = normalizeNumberCheckerPhone_(rawList[ni], defaultCc);
          if (e164 && !seenNums[e164]) {
            seenNums[e164] = true;
            normalizedNums.push(e164);
          }
        }
        if (!normalizedNums.length) {
          result = { ok: false, httpStatus: 400, message: 'No valid phone numbers provided for NumberChecker.AI verification.', data: { reason: 'empty_numbers' } };
        } else {
          providerRequestCount += 1;
          result = fetchNumberCheckerMultipart_(
            ncBaseUrl + '/v1/tasks',
            cfg.apiKey,
            { task_type: ncTaskType },
            { fieldName: 'file', fileName: 'numbers.txt', contentType: 'text/plain; charset=utf-8', content: normalizedNums.join('\n') + '\n' }
          );
          if (result && result.ok && result.data && typeof result.data === 'object') {
            var createdObj = (result.data.data && typeof result.data.data === 'object') ? result.data.data : result.data;
            result.data = Object.assign({}, createdObj, { submittedNumbers: normalizedNums.length, taskType: ncTaskType });
          }
        }
      } else if (operation === 'getTask' || operation === 'pollTask' || operation === 'getRun') {
        var taskId = String(payload.taskId || payload.task_id || payload.runId || '').trim();
        if (!taskId) {
          result = { ok: false, httpStatus: 400, message: 'task_id is required for NumberChecker.AI status check.', data: { reason: 'missing_task_id' } };
        } else {
          providerRequestCount += 1;
          result = fetchNumberCheckerMultipart_(
            ncBaseUrl + '/v1/gettasks',
            cfg.apiKey,
            { task_id: taskId },
            null
          );
          if (result && result.ok && result.data && typeof result.data === 'object') {
            var statusObj = (result.data.data && typeof result.data.data === 'object') ? result.data.data : result.data;
            var taskStatus = String(statusObj.status || '').toLowerCase();
            var resultUrl = String(statusObj.result_url || statusObj.resultUrl || '').trim();
            var items = Array.isArray(statusObj.items) ? statusObj.items : [];
            if (taskStatus === 'exported' && resultUrl && !items.length && !payload.skipDownload) {
              providerRequestCount += 1;
              items = downloadAndParseNumberCheckerResult_(resultUrl, cfg.apiKey);
            }
            result.data = Object.assign({}, statusObj, { status: taskStatus || statusObj.status, result_url: resultUrl, items: items });
          }
        }
      } else if (operation === 'getTaskResult' || operation === 'downloadResult') {
        var dlUrl = String(payload.resultUrl || payload.result_url || '').trim();
        if (!dlUrl) {
          result = { ok: false, httpStatus: 400, message: 'result_url is required.', data: { reason: 'missing_result_url' } };
        } else {
          providerRequestCount += 1;
          var dlItems = downloadAndParseNumberCheckerResult_(dlUrl, cfg.apiKey);
          result = { ok: true, httpStatus: 200, data: { status: 'exported', result_url: dlUrl, items: dlItems } };
        }
      } else if (operation === 'getBalance' || operation === 'balance') {
        result = providerFetch_(ncBaseUrl + '/v1/balance', {
          method: 'get',
          headers: { 'X-API-Key': cfg.apiKey }
        });
      } else {
        return { status: 'error', reason: 'unsupported_operation', provider: provider, operation: operation };
      }
    } else if (provider === 'apify' || provider === 'apifywpapi') {
      var actor = normalizeApifyActorId_(cfg.sourceId);
      var baseHeaders = { 'Authorization': 'Bearer ' + cfg.apiKey, 'Content-Type': 'application/json' };
      if (operation === 'runActor') {
        var q = ['waitForFinish=0'];
        var maxItems = Math.max(0, parseInt(payload.maxItems, 10) || 0);
        if (maxItems) q.push('maxItems=' + encodeURIComponent(maxItems));
        result = providerFetch_('https://api.apify.com/v2/acts/' + actor + '/runs?' + q.join('&'), {
          method: 'post', headers: baseHeaders, payload: JSON.stringify(payload.input || payload.body || {})
        });
      } else if (operation === 'getRun') {
        result = providerFetch_('https://api.apify.com/v2/actor-runs/' + encodeURIComponent(String(payload.runId || '')), { method: 'get', headers: baseHeaders });
      } else if (operation === 'getDatasetItems') {
        var datasetId = encodeURIComponent(String(payload.datasetId || ''));
        var offset = Math.max(0, parseInt(payload.offset, 10) || 0);
        var limit = Math.max(1, Math.min(1000, parseInt(payload.limit, 10) || 500));
        result = providerFetch_('https://api.apify.com/v2/datasets/' + datasetId + '/items?format=json&clean=true&offset=' + offset + '&limit=' + limit, { method: 'get', headers: baseHeaders });
      } else if (operation === 'getRunDatasetItems') {
        var runId = encodeURIComponent(String(payload.runId || ''));
        var roffset = Math.max(0, parseInt(payload.offset, 10) || 0);
        var rlimit = Math.max(1, Math.min(1000, parseInt(payload.limit, 10) || 500));
        result = providerFetch_('https://api.apify.com/v2/actor-runs/' + runId + '/dataset/items?format=json&clean=true&offset=' + roffset + '&limit=' + rlimit, { method: 'get', headers: baseHeaders });
      } else if (operation === 'getInputSchema') {
        result = providerFetch_('https://api.apify.com/v2/acts/' + actor + '/input-schema', { method: 'get', headers: baseHeaders });
        if (!result.ok) result = providerFetch_('https://api.apify.com/v2/acts/' + actor, { method: 'get', headers: baseHeaders });
      } else if (operation === 'getKeyValueOutput') {
        var storeId = encodeURIComponent(String(payload.storeId || ''));
        result = providerFetch_('https://api.apify.com/v2/key-value-stores/' + storeId + '/records/OUTPUT', { method: 'get', headers: baseHeaders });
      } else {
        return { status: 'error', reason: 'unsupported_operation', provider: provider, operation: operation };
      }
    } else {
      return { status: 'error', reason: 'unsupported_provider', provider: provider };
    }
  } catch (err) {
    finalizeProviderAccounting_(cfg, licenceFound, licenceKey, reservation, 0, false, { requestCount: providerRequestCount, rawResultCount: 0 });
    return { status: 'request_uncertain', errorCode:'REQUEST_UNCERTAIN', provider: provider, keyRow: cfg.keyRow, operation: operation, message: 'Provider completion could not be confirmed. Contact support with the request ID before retrying.' };
  }

  if (!result || !result.ok) {
    finalizeProviderAccounting_(cfg, licenceFound, licenceKey, reservation, 0, false, { requestCount: providerRequestCount, rawResultCount: 0 });
    var classified = classifyProviderFailure_(result);
    var upInfo = extractUpstreamErrorInfo_(result);
    if (classified === 'PROVIDER_QUOTA') markApiLimit_(cfg.keyRow, classified, licenceKey);
    if (classified === 'PROVIDER_AUTH') markApiProblem_(cfg.keyRow, 'api_blocked', classified, licenceKey);
    if (classified === 'PROVIDER_RATE_LIMIT' || classified === 'PROVIDER_UNAVAILABLE') coolProvider_(cfg.keyRow, classified === 'PROVIDER_RATE_LIMIT' ? 60 : 30);
    logApiErrorToSheet_({
      licenceKey: licenceKey,
      userName: licenceFound && licenceFound.userName || '',
      apiId: cfg && cfg.apiId || ('ROW-' + cfg.keyRow),
      keyRow: cfg.keyRow,
      provider: provider,
      httpStatus: result && result.httpStatus || 0,
      errorCode: classified,
      upstreamCode: upInfo.upstreamCode,
      upstreamMessage: redactProviderSecret_(upInfo.upstreamMessage || (result && result.message) || '', cfg.apiKey),
      query: extractPayloadQuery_(payload)
    });
    return { status: 'provider_error', errorCode: classified, upstreamCode: upInfo.upstreamCode, upstreamError: redactProviderSecret_(upInfo.upstreamMessage, cfg.apiKey), serverLoggedError: true, retryAfter:providerRetryAt_(cfg.keyRow), provider: provider, keyRow: cfg.keyRow, operation: operation, httpStatus: result && result.httpStatus || 0, message: redactProviderSecret_(result && result.message || 'Provider request failed.', cfg.apiKey), data: redactProviderSecret_(result && result.data, cfg.apiKey) };
  }
  // v94: for Scrappa, duplicate rows already seen by the same client run are
  // removed before accounting and before the response is returned. This keeps
  // Usage Count/licence-result credits aligned with unique leads instead of
  // repeatedly charging/counting overlapping pagination rows.
  var counted;
  try { counted=trimAndCountProviderResults_(provider, operation, result.data, providerCap > 0 ? reservation.reserved : null, payload); }
  catch(shapeError){finalizeProviderAccounting_(cfg,licenceFound,licenceKey,reservation,0,false,{requestCount:providerRequestCount,rawResultCount:0});return {status:'provider_error',reason:'unsupported_response_shape',errorCode:'PROVIDER_RESPONSE_INVALID',message:String(shapeError.message)};}
  var accounting = finalizeProviderAccounting_(cfg, licenceFound, licenceKey, reservation, counted.count, true, { requestCount: providerRequestCount, rawResultCount: counted.rawCount, runId:params.runId, leadKeys: billableLeadKeys_(provider,counted.data) });
  return { status: 'ok', secureProxy: true, provider: provider, keyRow: cfg.keyRow, operation: operation, httpStatus: result.httpStatus, data: redactProviderSecret_(counted.data, cfg.apiKey), returnedResultCount: counted.count, rawProviderResultCount: counted.rawCount, usageBefore: accounting.usageBefore, usageAfter: accounting.usageAfter, apiRequestCountAfter: accounting.apiRequestAfter, apiResultCountAfter: accounting.apiResultAfter, uniqueLeadCountAfter: accounting.uniqueLeadCount, licenceCreditAfter: accounting.creditAfter, account: accountSnapshot_(licenceFound), serverAccounted: true };
}

function markApiLimit_(keyRow, reason, licenceKey) {
  var sh = apiSheet_();
  if (!keyRow || keyRow < 2 || keyRow > sh.getLastRow()) return { status: 'invalid_key_row' };
  var headers = sh.getRange(1, 1, 1, Math.max(9, sh.getLastColumn())).getValues()[0];
  var layout = detectApiLayout_(headers || []);
  var usageLimitInfo = parseUsageLimit_(layout.limitCol ? sh.getRange(keyRow, layout.limitCol).getValue() : '', !!layout.limitCol);
  var usageLimit = usageLimitInfo.limit;
  if (layout.statusCol) sh.getRange(keyRow, layout.statusCol).setValue('limit_reached');
  // Usage Count is factual returned-result accounting in v24. Never fabricate
  // the count by forcing it to Usage Limit when a provider reports quota/billing failure.
  if (layout.lastUsedCol) sh.getRange(keyRow, layout.lastUsedCol).setValue(new Date());
  if (layout.lastKeyCol) sh.getRange(keyRow, layout.lastKeyCol).setValue(licenceKey || '');
  if (layout.notesCol) {
    var cleanReason = String(reason || 'limit/error').replace(/[\r\n]+/g, ' ').slice(0, 250);
    sh.getRange(keyRow, layout.notesCol).setValue('Auto disabled: ' + cleanReason + ' @ ' + new Date().toISOString());
  }
  return { status: 'ok', keyRow: keyRow, usageLimit: usageLimit, marked: 'limit_reached', apiSheetName: sh.getName() };
}

function markApiProblem_(keyRow, rowStatus, reason, licenceKey) {
  var sh = apiSheet_();
  if (!keyRow || keyRow < 2 || keyRow > sh.getLastRow()) return { status: 'invalid_key_row' };
  var headers = sh.getRange(1, 1, 1, Math.max(9, sh.getLastColumn())).getValues()[0];
  var layout = detectApiLayout_(headers || []);
  var safeStatus = String(rowStatus || 'api_blocked').trim().toLowerCase().replace(/[^a-z0-9_\-]/g, '_');
  if (!/^(api_blocked|api_error|auth_error|config_error|inactive)$/.test(safeStatus)) safeStatus = 'api_blocked';
  if (layout.statusCol) sh.getRange(keyRow, layout.statusCol).setValue(safeStatus);
  // Important: do NOT change Usage Count here. Blocked/restricted/not-enabled API errors are not quota usage.
  if (layout.lastUsedCol) sh.getRange(keyRow, layout.lastUsedCol).setValue(new Date());
  if (layout.lastKeyCol) sh.getRange(keyRow, layout.lastKeyCol).setValue(licenceKey || '');
  if (layout.notesCol) {
    var cleanReason = String(reason || 'api/config error').replace(/[\r\n]+/g, ' ').slice(0, 250);
    sh.getRange(keyRow, layout.notesCol).setValue('Auto disabled without usage change: ' + cleanReason + ' @ ' + new Date().toISOString());
  }
  return { status: 'ok', keyRow: keyRow, marked: safeStatus, apiSheetName: sh.getName() };
}

function reportApiUsage_(keyRow, usedCount, licenceKey) {
  // v24: usage is accounted atomically inside providerProxy immediately after a
  // successful provider response. This legacy endpoint is intentionally a
  // read-only snapshot so v84/v85 clients cannot double-count results.
  if (!keyRow) return { status: 'ok', before: 0, after: 0, usageLimit: UNLIMITED_USAGE_LIMIT, serverAccounted: true };
  var sh = apiSheet_();
  if (keyRow < 2 || keyRow > sh.getLastRow()) return { status: 'invalid_key_row' };
  var headers = sh.getRange(1, 1, 1, Math.max(9, sh.getLastColumn())).getValues()[0];
  var layout = detectApiLayout_(headers || []);
  var rowValues = sh.getRange(keyRow, 1, 1, Math.max(9, sh.getLastColumn())).getValues()[0];
  var usage = parseInt(rowValues[layout.usageCol - 1], 10) || 0;
  var usageLimitInfo = parseUsageLimit_(layout.limitCol ? rowValues[layout.limitCol - 1] : '', !!layout.limitCol);
  return { status: 'ok', keyRow: keyRow, before: usage, usedCount: 0, after: usage, usageLimit: usageLimitInfo.limit, limitReached: usageLimitInfo.limit < UNLIMITED_USAGE_LIMIT && usage >= usageLimitInfo.limit, apiSheetName: sh.getName(), serverAccounted: true };
}


// Helpdesk / Support Center v4: Drive attachments and a dedicated idempotency column.
var SUPPORT_HEADERS_=['TicketID','License','Subject','Message','User','Timestamp','Status','Remarks','AttachmentURL','RequestID'];
var SUPPORT_ATTACHMENT_FOLDER_NAME_='PocketLeads Support Attachments';
var SUPPORT_ATTACHMENT_MAX_BYTES_=5*1024*1024;

function supportSheet_(){
  var ss=ss_();
  var sh=ss.getSheetByName('Tickets') || ss.insertSheet('Tickets');
  ensureSupportSheet_(sh);
  return sh;
}

function normalizeHeader_(value){
  return String(value||'').toLowerCase().replace(/[^a-z0-9]/g,'');
}

function ensureSupportSheet_(sh){
  if(sh.getLastRow()===0){
    sh.getRange(1,1,1,SUPPORT_HEADERS_.length).setValues([SUPPORT_HEADERS_]);
    sh.setFrozenRows(1);
    return;
  }
  var width=Math.max(sh.getLastColumn(),SUPPORT_HEADERS_.length);
  var headers=sh.getRange(1,1,1,width).getValues()[0];
  var normalized=headers.map(normalizeHeader_);
  var canonical=SUPPORT_HEADERS_.map(normalizeHeader_);
  if(canonical.every(function(h){return normalized.indexOf(h)>=0;}))return;

  // Legacy Helpdesk layouts, including the previous nine-column canonical
  // layout where AttachmentURL was temporarily reused for RequestID.
  var legacy={
    subject:normalized.indexOf('subject'), message:normalized.indexOf('message'), user:normalized.indexOf('user'),
    ticketId:normalized.indexOf('ticketid'), license:normalized.indexOf('license'),
    timestamp:normalized.indexOf('timestamp'), status:normalized.indexOf('status'), remarks:normalized.indexOf('remarks'),
    attachment:normalized.indexOf('attachmenturl'), requestId:normalized.indexOf('requestid')
  };
  var looksLegacy=legacy.subject>=0 && legacy.message>=0 && legacy.timestamp>=0 && legacy.status>=0;
  if(!looksLegacy){
    if(sh.getLastRow()<=1){sh.clear();sh.getRange(1,1,1,SUPPORT_HEADERS_.length).setValues([SUPPORT_HEADERS_]);sh.setFrozenRows(1);}
    return;
  }

  var data=sh.getDataRange().getValues();
  var migrated=[SUPPORT_HEADERS_];
  for(var i=1;i<data.length;i++){
    var row=data[i]||[];
    if(row.every(function(v){return String(v||'').trim()==='';}))continue;
    var legacyDate=row[legacy.timestamp]||new Date();
    var stamp;
    try{stamp=Utilities.formatDate(new Date(legacyDate),Session.getScriptTimeZone(),'yyyyMMdd-HHmmss');}catch(e){stamp='ROW-'+i;}
    var oldAttachment=legacy.attachment>=0?String(row[legacy.attachment]||''):'';
    var oldRequestId=legacy.requestId>=0?String(row[legacy.requestId]||''):'';
    if(!oldRequestId && oldAttachment && !/^https?:\/\//i.test(oldAttachment)){oldRequestId=oldAttachment;oldAttachment='';}
    migrated.push([
      legacy.ticketId>=0?String(row[legacy.ticketId]||('LEGACY-'+stamp+'-'+i)):('LEGACY-'+stamp+'-'+i),
      legacy.license>=0?String(row[legacy.license]||''):'',String(row[legacy.subject]||''),String(row[legacy.message]||''),String(row[legacy.user]||''),
      legacyDate,String(row[legacy.status]||'Open'),String(row[legacy.remarks]||''),oldAttachment,oldRequestId
    ]);
  }
  sh.clearContents();
  sh.getRange(1,1,migrated.length,SUPPORT_HEADERS_.length).setValues(migrated);
  sh.setFrozenRows(1);
}

function saveSupportAttachment_(params,ticketId){
  var encoded=String(params.attachmentData||'').trim();
  if(!encoded)return {url:'',file:null};
  var name=String(params.attachmentName||'attachment').replace(/[\\\/\x00-\x1F\x7F]+/g,'_').trim().slice(0,140)||'attachment';
  if(!/\.(png|jpe?g|webp|pdf|txt|csv|log|docx?|xlsx?|zip)$/i.test(name))throw new Error('Unsupported attachment type.');
  encoded=encoded.replace(/^data:[^,]+,/i,'').replace(/\s+/g,'');
  if(encoded.length>Math.ceil(SUPPORT_ATTACHMENT_MAX_BYTES_*4/3)+8)throw new Error('Attachment must be 5 MB or smaller.');
  var bytes=Utilities.base64Decode(encoded);
  if(bytes.length>SUPPORT_ATTACHMENT_MAX_BYTES_)throw new Error('Attachment must be 5 MB or smaller.');
  var mime=String(params.attachmentType||'application/octet-stream').replace(/[\r\n]/g,'').slice(0,100)||'application/octet-stream';
  var folders=DriveApp.getFoldersByName(SUPPORT_ATTACHMENT_FOLDER_NAME_);
  var folder=folders.hasNext()?folders.next():DriveApp.createFolder(SUPPORT_ATTACHMENT_FOLDER_NAME_);
  var file=folder.createFile(Utilities.newBlob(bytes,mime,ticketId+'_'+name));
  file.setDescription('PocketLeads support attachment for '+ticketId);
  return {url:file.getUrl(),file:file};
}

function submitSupportTicket_(params,key){
  var lock=LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    var subject=String(params.subject||'').trim();
    var message=String(params.message||'').trim();
    if(subject.length<3)return {status:'invalid',message:'Subject must be at least 3 characters.'};
    if(message.length<10)return {status:'invalid',message:'Message must be at least 10 characters.'};
    if(subject.length>120)return {status:'invalid',message:'Subject is too long.'};
    if(message.length>2000)return {status:'invalid',message:'Message is too long.'};
    if(/^\[AUTO/i.test(subject)){
      try{
        logApiErrorToSheet_({
          forceCreateSheet: true,
          licenceKey: String(key||''),
          userName: String(params.user||params.userName||''),
          apiId: String(params.apiId||'AUTO_REPORT'),
          keyRow: Number(params.keyRow||0)||0,
          provider: String(params.provider||'auto'),
          httpStatus: Number(params.httpStatus||0)||0,
          errorCode: String(params.errorCode||subject.replace(/^\[AUTO[^\]]*\]\s*/i,'').slice(0,40)),
          upstreamCode: String(params.upstreamCode||''),
          upstreamMessage: String(params.upstreamError||message||'').slice(0,500),
          query: String(params.query||'')
        });
      }catch(_eAuto){}
    }
    var sh=supportSheet_();
    var requester=String(params.user||params.email||'').trim();
    var requestId=String(params.requestId||'').trim();
    var now=new Date();
    // Idempotency / retry protection: a network retry must never create two tickets.
    // Match a client request id first, then a very recent identical request as a
    // second safety net for older clients.
    var lastRow=sh.getLastRow();
    if(lastRow>1){
      var from=Math.max(2,lastRow-50+1), rows=sh.getRange(from,1,lastRow-from+1,SUPPORT_HEADERS_.length).getValues();
      for(var i=rows.length-1;i>=0;i--){
        var r=rows[i]||[], rowKey=String(r[1]||''), rowSubject=String(r[2]||''), rowMessage=String(r[3]||''), rowTime=r[5];
        if(rowKey!==String(key||''))continue;
        var oldTime=new Date(rowTime||0).getTime();
        var recent=(now.getTime()-oldTime)>=0 && (now.getTime()-oldTime)<=5*60*1000;
        if((requestId && String(r[9]||'')===requestId) || (!requestId && recent && rowSubject===subject && rowMessage===message)){
          return {status:'ok',ticketId:String(r[0]||''),duplicate:true,ticket:{id:String(r[0]||''),subject:rowSubject,message:rowMessage,user:String(r[4]||requester),timestamp:r[5]||now,status:String(r[6]||'Open'),remarks:String(r[7]||''),attachment:String(r[8]||'')}};
        }
      }
    }
    var id='T-'+Utilities.getUuid().slice(0,8).toUpperCase();
    var saved=saveSupportAttachment_(params,id);
    try{
      sh.appendRow([id,String(key||''),subject,message,requester,now,'Open','',saved.url,requestId]);
    }catch(appendError){
      if(saved.file){try{saved.file.setTrashed(true);}catch(cleanupError){}}
      throw appendError;
    }
    SpreadsheetApp.flush();
    return {status:'ok',ticketId:id,duplicate:false,ticket:{id:id,subject:subject,message:message,user:requester,timestamp:now,status:'Open',remarks:'',attachment:saved.url}};
  } finally {
    try{lock.releaseLock();}catch(_){ }
  }
}

function getSupportTickets_(key,deviceId){
  var sh=supportSheet_();
  var data=sh.getDataRange().getValues();
  var out=[];
  for(var i=1;i<data.length;i++){
    var row=data[i]||[];
    if(String(row[1]||'')!==String(key||''))continue;
    out.push({id:String(row[0]||''),subject:String(row[2]||''),message:String(row[3]||''),user:String(row[4]||''),timestamp:row[5]||'',status:String(row[6]||'Open'),remarks:String(row[7]||''),attachment:String(row[8]||'')});
  }
  out.sort(function(a,b){var at=new Date(a.timestamp||0).getTime(),bt=new Date(b.timestamp||0).getTime();return (isNaN(bt)?0:bt)-(isNaN(at)?0:at);});
  return {status:'ok',tickets:out,count:out.length};
}

// Optional licence-sheet columns. Defaults live here, never in the extension.
// Missing plan limit = server's explicit unlimited policy; zero always blocks.
function accountPolicy_(found) {
  if(found && found.managed)return pl2Policy_(found);
  var rows = found.sheet.getDataRange().getValues();
  var headers = [];
  for (var i=0;i<Math.min(found.row-1,10);i++) {
    if (headerIndex_(rows[i], [/licen[cs]e.*key/, /^key$/])) { headers=rows[i]; break; }
  }
  var values = rows[found.row-1] || [];
  function val(pattern, fallback) { var col=headerIndex_(headers,[pattern]); var value=col?values[col-1]:null; return value == null || String(value).trim()==='' ? fallback : value; }
  function enabled(value) {return !/^(false|no|off|disabled|0)$/i.test(String(value));}
  function limit(value) { if(String(value).toLowerCase()==='unlimited')return 'unlimited'; var n=Number(value);return isFinite(n)&&n>=0&&Math.floor(n)===n?n:0; }
  return {
    plan: String(val(/^plan(?: name)?$/, 'Configured plan')),
    userName: String(val(/^(?:user name|name|customer name)$/, '')),
    email: String(val(/^(?:email|email address)$/, '')),
    engines: String(val(/^(?:enabled engines|allowed providers)$/, 'googlemaps,serper,scrappa,apify,apifywpapi,numberchecker')).toLowerCase().split(',').map(function(x){return x.trim();}).filter(Boolean),
    scraping: enabled(val(/^scraping enabled$/, true)),
    export: enabled(val(/^export enabled$/, true)),
    maxResultsPerRequest: limit(val(/^max results per request$/, 'unlimited')),
    exportLimit: limit(val(/^export limit$/, 'unlimited')),
    purchaseUrl: String(val(/^purchase url$/, '')),
    supportEmail: String(val(/^support email$/, SUPPORT_EMAIL))
  };
}
function accountSnapshot_(found) {
  var commerce=licenceCommercialStatus_(found,false), policy=accountPolicy_(found);
  return Object.assign({},commerce,{
    schemaVersion: found.managed ? 2 : 1,
    availableCredit: found.managed ? commerce.structuredCredit : null,
    purchasedCredit: found.managed ? commerce.purchaseCredit : null,
    providerPriority: policy.priority || policy.engines, serverTime: Date.now(), plan:policy.plan,
    userName:policy.userName, email:policy.email,
    supportEmail:policy.supportEmail, purchaseUrl:policy.purchaseUrl,
    support:{email:policy.supportEmail}, engines:policy.engines,
    limits:{maxResultsPerRequest:policy.maxResultsPerRequest,exportLimit:policy.exportLimit},
    entitlements:{scraping:policy.scraping,export:policy.export}
  });
}
function accountBootstrap_(found,key) {
  var snapshot=accountSnapshot_(found);
  try { snapshot.route=getActiveApiConfig_(false,key,'auto',''); }
  catch(e){ snapshot.route={status:'error',reason:'provider_unavailable',message:'Provider configuration unavailable. Retry or contact support.'}; }
  return snapshot;
}


// v36: durable request receipts. Never expire an unresolved paid operation.
// Keep these sheets private; they contain result data, not provider credentials.
function requestLedger_() {
  var book=ss_(), sh=book.getSheetByName('PocketLeadsRequests');
  if(!sh){sh=book.insertSheet('PocketLeadsRequests');sh.appendRow(['Identity','Payload','State','Updated','Response chunks']);}
  return sh;
}
function ledgerHash_(text) {
  return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(text),Utilities.Charset.UTF_8).map(function(b){return ('0'+((b+256)%256).toString(16)).slice(-2);}).join('');
}
function ledgerEntry_(sh,identity) {
  var last=sh.getLastRow();if(last<2)return null;
  var hit=sh.getRange(2,1,last-1,1).createTextFinder(identity).matchEntireCell(true).findNext();
  if(!hit)return null;
  var row=hit.getRow();return {row:row,values:sh.getRange(row,1,1,sh.getLastColumn()).getValues()[0]};
}
function receiptResponse_(entry,found) {
  if(entry.values[2]!=='done' && entry.values[2]!=='retryable')return {status:'request_pending',errorCode:'REQUEST_PENDING',message:'Request is awaiting confirmation. Resume checks the existing request; support can reconcile interrupted operations.'};
  var data=JSON.parse(entry.values.slice(4).join(''));
  if(data.status==='ok'){data.account=accountSnapshot_(found);data.replayed=true;}
  return data;
}
function providerRequestStatus_(params,key,found) {
  if(!/^[a-f0-9]{64}$/.test(String(params.requestId||'')))return {status:'request_missing'};
  var sh=requestLedger_(),entry=ledgerEntry_(sh,ledgerHash_(key+'|'+params.requestId));
  return entry?receiptResponse_(entry,found):{status:'request_missing'};
}
function trackedProviderRequest_(params,key,found) {
  // Legacy auxiliary integrations remain supported; current scraper always sends receipts.
  if(!params.requestId)return handleProviderProxy_(params,key,found);
  if(!/^[a-f0-9]{64}$/.test(String(params.requestId)))return {status:'request_conflict',errorCode:'REQUEST_CONFLICT'};
  var identity=ledgerHash_(key+'|'+params.requestId);
  var signature=ledgerHash_(JSON.stringify([params.provider,params.keyRow,params.operation,params.payload]));
  var lock=LockService.getScriptLock(),sh,entry,row;
  lock.waitLock(25000);
  try {
    sh=requestLedger_();entry=ledgerEntry_(sh,identity);
    if(entry){
      if(entry.values[1]!==signature)return {status:'request_conflict',errorCode:'REQUEST_CONFLICT',message:'Request ID reused with a different payload.'};
      if(entry.values[2]!=='retryable' || Date.now()-Number(entry.values[3])<60000)return receiptResponse_(entry,found);
      row=entry.row;sh.getRange(row,3).setValue('pending');sh.getRange(row,4).setValue(Date.now());
    }else{sh.appendRow([identity,signature,'pending',Date.now(),'']);row=sh.getLastRow();}
  } finally {lock.releaseLock();}
  // No global lock is held across provider I/O or credit reservations.
  var result=handleProviderProxy_(params,key,found);
  result.requestId=params.requestId;
  if(result.status==='request_uncertain')return result;
  var text=JSON.stringify(result),chunks=[];
  for(var n=0;n<text.length;n+=40000)chunks.push(text.slice(n,n+40000));
  lock.waitLock(25000);
  try {
    if(sh.getMaxColumns()<chunks.length+4)sh.insertColumnsAfter(sh.getMaxColumns(),chunks.length+4-sh.getMaxColumns());
    // Response first, commit marker last. Interrupted writes remain pending.
    var width=Math.max(chunks.length,sh.getLastColumn()-4),values=[];
    for(var c=0;c<width;c++)values.push(chunks[c]||'');
    sh.getRange(row,5,1,width).setValues([values]);
    sh.getRange(row,4).setValue(result.status==='credits_exhausted'?0:Date.now());
    sh.getRange(row,3).setValue(result.status==='ok'?'done':'retryable');
  } finally {lock.releaseLock();}
  return result;
}
function classifyProviderFailure_(r) {
  var status=Number(r&&r.httpStatus)||0;
  if(status===429)return 'PROVIDER_RATE_LIMIT';
  if(status===402)return 'PROVIDER_QUOTA';
  if(status===401||status===403)return 'PROVIDER_AUTH';
  // Only an explicit upstream error code may classify quota; never customer-facing prose.
  var code=String(r&&r.data&&r.data.error&&(r.data.error.code||r.data.error.type)||'').toLowerCase();
  if(/^(insufficient_quota|quota_exceeded|billing_hard_limit_reached|credit_exhausted)$/.test(code))return 'PROVIDER_QUOTA';
  return 'PROVIDER_UNAVAILABLE';
}
function coolProvider_(row,seconds) { CacheService.getScriptCache().put('pl_provider_cool_'+row,String(Date.now()+seconds*1000),seconds); }
function providerRetryAt_(row){return typeof CacheService==='undefined'?0:Number(CacheService.getScriptCache().get('pl_provider_cool_'+row)||0);}
function providerCooling_(row) { return providerRetryAt_(row)>Date.now(); }
function nextProviderRetry_(count){var next=0;for(var row=2;row<=count;row++){var at=providerRetryAt_(row);if(at>Date.now()&&(!next||at<next))next=at;}return next;}


function billableLeadKeys_(provider,data) {
  var list=Array.isArray(data)?data:(data && (data.places||data.items||data.results||(data.data&&(data.data.items||data.data.places))));
  if(!Array.isArray(list))return null;
  return list.map(function(x){
    var id=x.place_id||x.placeId||x.google_place_id||(provider==='googlemaps'?x.id:'');
    if(id)return 'place:'+String(id).trim();
    var name=String(x.name||x.title||'').trim().toLowerCase();
    var address=String(x.address||x.formattedAddress||x.formatted_address||'').trim().toLowerCase();
    // No weak name-only dedup: two businesses can share a name.
    return name&&address?'business:'+name+'|'+address:null;
  });
}
function recordUniqueCharges_(key,runId,keys) {
  var book=ss_(),sh=book.getSheetByName('PocketLeadsChargedLeads');
  if(!sh){sh=book.insertSheet('PocketLeadsChargedLeads');sh.appendRow(['Run','Lead','Created']);}
  var run=ledgerHash_(key+'|'+String(runId)),seen={},last=sh.getLastRow();
  if(last>1){
    var matches=sh.getRange(2,1,last-1,1).createTextFinder(run).matchEntireCell(true).findAll();
    if(matches.length){
      var positions=matches.map(function(c){return c.getRow();}),first=Math.min.apply(null,positions),end=Math.max.apply(null,positions);
      sh.getRange(first,1,end-first+1,2).getValues().forEach(function(r){if(r[0]===run)seen[r[1]]=true;});
    }
  }
  var charged=0,added=[];
  keys.forEach(function(k){
    if(!k){charged++;return;}
    var hash=ledgerHash_(k);if(seen[hash])return;
    seen[hash]=true;charged++;added.push([run,hash,new Date()]);
  });
  if(added.length)sh.getRange(sh.getLastRow()+1,1,added.length,3).setValues(added);
  return charged;
}


// ===== INCLUDED MANAGED ROUTING MODULE — no separate file required =====
/** PocketLeads managed routing v2, included in this complete backend file.
 * Existing activation/device/expiry functions remain authoritative.
 * Only Sheet1 and Sheet2 are management sheets. Private journals are retained.
 * Credit + counters + receipt transitions use one atomic Sheets batchUpdate.
 * No provider fetch occurs while ScriptLock is held.
 */
var PL2_USER_COLUMNS = ['Scrappa API IDs','Serper API IDs','Maps API IDs','Provider Priority','Purchased Credit','Available Credit','Scrappa Calls','Scrappa Results','Serper Calls','Serper Results','Maps Calls','Maps Results','Last Used At'];
var PL2_KEY_COLUMNS = ['API ID','Provider','API Key','Status','Call Limit','Calls Used','Results Returned','Last Used At'];
var PL2_PROVIDERS = ['googlemaps','serper','scrappa'];
var PL2_PREFIX = {scrappa:'Scrappa',serper:'Serper',googlemaps:'Maps'};
function pl2Properties_(){return PropertiesService.getScriptProperties();}
function pl2Enabled_(){return !!pl2Properties_().getProperty('PL2_CONFIG');}
function pl2Config_(){var c=JSON.parse(pl2Properties_().getProperty('PL2_CONFIG')||'null');if(!c)throw Error('Managed backend setup required');return c;}
function pl2Error_(status,code,message){return {status:status,errorCode:code,reason:code.toLowerCase(),message:message};}
function pl2Guard_(fn){try{return fn();}catch(e){
  console.error('Managed backend operation failed: '+String(e.message||e).slice(0,200));
  if(e.pl2Public)return pl2Error_('configuration_error',e.pl2Code||'BACKEND_UNAVAILABLE',e.pl2Public);
  var known={
    'Invalid Provider Priority':'Provider Priority is missing or invalid. Use an explicit order such as google_place,serper,scrappa in the user row.',
    'Missing management sheet':'Management sheet not found. Check PL2_CONFIG sheet names and run setupPocketLeadsManaged in Apps Script.',
    'Invalid licence layout':'The user management sheet needs License Key and Available Credit headers in row 1.',
    'Duplicate management identity':'Duplicate licence or API ID found in management sheets. Each identity must have one row.',
    'Advanced Sheets service unavailable':'Enable Google Sheets API v4 in Apps Script Services.',
    'Managed backend setup required':'Run setupPocketLeadsManaged in Apps Script before scraping.'
  };
  return pl2Error_('configuration_error','BACKEND_UNAVAILABLE',known[String(e.message)]||'Backend configuration/storage unavailable. Check Apps Script access and management sheet settings.');
}}
function pl2BillingError_(provider,detail){var e=Error('Reviewed provider billing policy missing');e.pl2Code='BILLING_CONFIG_ERROR';e.pl2Public='PL2_BILLING: '+detail+' for '+provider+'. Open Apps Script > Project Settings > Script Properties and configure the reviewed billing rule. No new API call was sent.';return e;}
function pl2Provider_(p){var s=String(p||'').trim().toLowerCase().replace(/[\s_.\-]+/g,'_');if(/^(google_place|googleplaces|googlemaps|maps|google_place_api|google_maps|google_places|places_api)$/.test(s))return 'googlemaps';if(/^(scrappa|scrappa_api|scrappa_co|scrappa_maps)$/.test(s))return 'scrappa';if(/^(serper|serper_dev|serper_api|google_serper)$/.test(s))return 'serper';return s;}
function pl2List_(v){return String(v||'').split(/[,;\n\r|]+/).map(function(x){return x.trim();}).filter(function(x,i,a){return x&&a.indexOf(x)===i;});}
function pl2Headers_(sh){var h=sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0],m={};h.forEach(function(v,i){var name=String(v).trim();if(name){if(m[name])throw Error('Duplicate header: '+name);m[name]=i+1;}});return m;}
function pl2AppendColumns_(sh,names){var h=pl2Headers_(sh);names.forEach(function(n){if(!h[n]){var c=sh.getLastColumn()+1;if(c>sh.getMaxColumns())sh.insertColumnsAfter(sh.getMaxColumns(),c-sh.getMaxColumns());sh.getRange(1,c).setValue(n);h[n]=c;}});return h;}

// EDITOR ONLY: never exposed through doPost. Explicit balances/assignments must
// be reviewed by the admin; old buckets are NOT silently summed or spent twice.
function setupPocketLeadsManaged(){
  var lock=LockService.getScriptLock();lock.waitLock(10000);
  try{
    if(typeof Sheets==='undefined')throw Error('Enable the Advanced Google Sheets v4 service first.');
    var book=ss_(),props=pl2Properties_();
    // Reuse the deployed management tabs; never create duplicate management
    // sheets beside an existing installation or reset its balances.
    var names=JSON.parse(props.getProperty('PL2_SHEET_NAMES')||'null')||{
      users:book.getSheetByName('User & API Assignment')?'User & API Assignment':'Sheet1',
      keys:book.getSheetByName('API Key Management')?'API Key Management':'Sheet2'
    };
    var users=book.getSheetByName(names.users);if(!users)throw Error('Set PL2_SHEET_NAMES to the existing licence sheet and Sheet2 names.');
    var first=users.getRange(1,1,1,users.getLastColumn()).getValues()[0];
    if(!headerIndex_(first,[/licen[cs]e.*key/,/^key$/]))throw Error('Existing licence headers must be in row 1; preserve them.');
    pl2AppendColumns_(users,PL2_USER_COLUMNS);
    var keys=book.getSheetByName(names.keys);
    if(!keys){keys=book.insertSheet(names.keys);keys.appendRow(PL2_KEY_COLUMNS);}
    else pl2AppendColumns_(keys,PL2_KEY_COLUMNS);
    var journal=requestLedger_();if(journal.getMaxColumns()<64)journal.insertColumnsAfter(journal.getMaxColumns(),64-journal.getMaxColumns());
    var attempts=book.getSheetByName('PocketLeadsAttempts');
    if(!attempts){attempts=book.insertSheet('PocketLeadsAttempts');attempts.appendRow(['Identity','State']);}
    [journal,attempts,book.getSheetByName('PocketLeadsChargedLeads')].forEach(function(sh){if(sh&&sh.hideSheet)sh.hideSheet();});
    props.setProperty('PL2_CONFIG',JSON.stringify({users:names.users,keys:names.keys,ttl:60,laneLimits:{scrappa:4,serper:6,googlemaps:4},requestBudget:64}));
    if(!props.getProperty('PL2_BILLING')){
      props.setProperty('PL2_BILLING',JSON.stringify({scrappa:{confirmed:true,reserve:1,success:1,failure:0},serper:{confirmed:true,reserve:1,success:1,failure:0},googlemaps:{confirmed:true,reserve:0,success:0,failure:0}}));
    }
    refreshPocketLeadsCache();
  }finally{lock.releaseLock();}
  var triggers=ScriptApp.getProjectTriggers();
  ['pocketLeadsSheetEdit','pocketLeadsSheetChange'].forEach(function(fn){if(!triggers.some(function(t){return t.getHandlerFunction()===fn;})){var b=ScriptApp.newTrigger(fn).forSpreadsheet(SHEET_ID);if(fn==='pocketLeadsSheetEdit')b.onEdit().create();else b.onChange().create();}});
  return {status:'ok',message:'Columns ready. Set reviewed balances, assignments and PL2_BILLING before paid requests.'};
}
// EDITOR ONLY, read-only. Safe to share the output: no credentials or user rows.
function checkPocketLeadsSetup(){
  var report={backendVersion:'10.16.3',advancedSheets:typeof Sheets!=='undefined',configuration:'missing',sheets:{},billing:{}};
  try{var c=pl2Config_();report.configuration='ready';['users','keys'].forEach(function(k){var sh=ss_().getSheetByName(c[k]);report.sheets[k]=sh?'found':'missing';});}
  catch(e){report.configuration='missing or invalid; run setupPocketLeadsManaged';}
  PL2_PROVIDERS.forEach(function(p){try{pl2Billing_(p);report.billing[p]='configured';}catch(e){report.billing[p]='missing or invalid';}});
  console.log(JSON.stringify(report,null,2));return report;
}
function refreshPocketLeadsCache(){pl2Properties_().setProperty('PL2_GENERATION',String(Date.now())+'-'+Utilities.getUuid());}
function pocketLeadsSheetEdit(e){if(!e||!e.range)return;var c=pl2Config_(),name=e.range.getSheet().getName();if(name===c.users||name===c.keys)refreshPocketLeadsCache();}
function pocketLeadsSheetChange(){refreshPocketLeadsCache();}
function onEdit(e){try{pocketLeadsSheetEdit(e);}catch(_){}}
function pl2Cached_(key,loader){
  // Cache exceptions are fail-closed. A cache miss reloads authoritative data.
  var c=pl2Config_(),cache=CacheService.getScriptCache(),generation=pl2Properties_().getProperty('PL2_GENERATION')||'0';
  var k='pl2:'+generation+':'+key,value=cache.get(k);if(value)return JSON.parse(value);
  var data=loader();cache.put(k,JSON.stringify(data),c.ttl);return data;
}
function pl2Layout_(kind){return pl2Cached_('layout:'+kind,function(){var c=pl2Config_(),sh=ss_().getSheetByName(c[kind]);if(!sh)throw Error('Missing management sheet');return {name:sh.getName(),headers:pl2Headers_(sh)};});}
function pl2FindRow_(sh,col,value){
  if(sh.getLastRow()<2)return 0;
  var hits=sh.getRange(2,col,sh.getLastRow()-1,1).createTextFinder(String(value)).matchEntireCell(true).matchCase(false).findAll();
  if(hits.length>1)throw Error('Duplicate management identity');return hits.length?hits[0].getRow():0;
}
function pl2User_(key){
  key=normalizeLicenceKey_(key);var l=pl2Layout_('users'),sh=ss_().getSheetByName(l.name),h=l.headers;
  var names=Object.keys(h),header=[];names.forEach(function(n){header[h[n]-1]=n;});
  var kc=headerIndex_(header,[/licen[cs]e.*key/,/^key$/]);if(!kc||!h['Available Credit'])throw Error('Invalid licence layout');
  var at=pl2Cached_('user:'+ledgerHash_(key),function(){return {row:pl2FindRow_(sh,kc,key)};});
  if(!at.row)return null;
  var values=sh.getRange(at.row,1,1,sh.getLastColumn()).getValues()[0];
  if(normalizeLicenceKey_(values[kc-1])!==key){refreshPocketLeadsCache();return pl2User_(key);}
  return {row:at.row,sheet:sh,keyCol:kc,countCol:headerIndex_(header,[/active.*device/,/device.*count/,/^count$/])||(kc===1?2:3),ipCol:headerIndex_(header,[/^ips?$/, /device.*ids?/,/installation.*id/])||(kc===1?3:4),statusCol:headerIndex_(header,[/^status$/, /licen[cs]e.*status/]),validityCol:headerIndex_(header,[/licen[cs]e.*valid/,/^validity$/, /expir.*date/,/^expiry$/]),purchaseCreditCol:h['Purchased Credit'],availableCreditCol:h['Available Credit'],headers:h,values:values,managed:true};
}
function pl2Value_(u,name){return u.values[u.headers[name]-1];}
function pl2Policy_(u){
  function v(n,d){var value=pl2Value_(u,n);return value===undefined||value===''?d:value;}
  function limit(n){var value=v(n,'unlimited');if(value==='unlimited')return value;return /^\d+$/.test(String(value))?Number(value):0;}
  var priority=pl2List_(v('Provider Priority','')).map(pl2Provider_);
  if(!priority.length||priority.some(function(p){return PL2_PROVIDERS.indexOf(p)<0;})||new Set(priority).size!==priority.length)throw Error('Invalid Provider Priority');
  var allowed=pl2List_(v('Enabled Engines',priority.join(','))).map(pl2Provider_);
  return {plan:String(v('Plan','Configured plan')),userName:String(v('User Name','')),email:String(v('Email','')),engines:priority.filter(function(p){return allowed.indexOf(p)>=0;}),priority:priority,
    scraping:! /^(false|no|off|disabled|0)$/i.test(String(v('Scraping Enabled',true))),export:! /^(false|no|off|disabled|0)$/i.test(String(v('Export Enabled',true))),maxResultsPerRequest:limit('Max Results Per Request'),exportLimit:limit('Export Limit'),purchaseUrl:String(v('Purchase URL','')),supportEmail:String(v('Support Email',SUPPORT_EMAIL))};
}
function pl2Credit_(u){var raw=Array.isArray(u.values)?u.values[u.availableCreditCol-1]:u.sheet.getRange(u.row,u.availableCreditCol).getValue();var info=parseCreditValue_(raw);info.column=u.availableCreditCol;info.purchaseRemaining=0;info.purchaseColumn=0;return info;}
function pl2Auth_(key,device,needCredit){
  var u=pl2User_(key);if(!u)return {error:pl2Error_('invalid','LICENSE_INACTIVE','Licence not found.')};
  if(!licenceStatusInfo_(u).active)return {error:pl2Error_('inactive','LICENSE_INACTIVE','Licence inactive.')};
  var validity=licenceValidityInfo_(u,true);if(!validity.active)return {error:pl2Error_('expired','LICENSE_EXPIRED','Licence expired or validity invalid.')};
  if(device&&!licenceDeviceInfo_(u,device).active)return {error:pl2Error_('denied','LICENSE_INACTIVE','Device not activated.')};
  var balance=pl2Credit_(u);if(!balance.valid)return {error:pl2Error_('credit_config_error','LICENSE_CREDIT_CONFIG_ERROR','Available Credit is invalid.')};
  if(needCredit&&!balance.unlimited&&balance.remaining<=0)return {error:pl2Error_('credits_exhausted','LICENSE_CREDIT_EXHAUSTED','No Available Credit. Buy Credits to continue.')};
  return {user:u,credit:balance};
}
// Reuse the authoritative balance already read in this locked operation.
// This is never a cache lookup and never crosses a provider network call.
function pl2RequireCredit_(auth){
  if(auth.error)return auth;
  if(!auth.credit.unlimited&&auth.credit.remaining<=0)return {error:pl2Error_('credits_exhausted','LICENSE_CREDIT_EXHAUSTED','No Available Credit. Buy Credits to continue.')};
  return auth;
}
function pl2Keys_(u,provider){
  var ids=pl2List_(pl2Value_(u,PL2_PREFIX[provider]+' API IDs'));
  var l=pl2Layout_('keys'),sh=ss_().getSheetByName(l.name),h=l.headers,now=Date.now(),ready=[],softCooled=[];
  if(!ids.length||!sh||sh.getLastRow()<2)return [];
  var allRows=sh.getDataRange().getValues();
  var idCol=(h['API ID']||1)-1,provCol=(h.Provider||2)-1,keyCol=(h['API Key']||3)-1,statusCol=(h.Status||4)-1,limitCol=(h['Call Limit']||5)-1,usedCol=(h['Calls Used']||6)-1;
  ids.forEach(function(id){
    var cleanId=String(id||'').trim();
    if(!cleanId)return;
    var cleanLower=cleanId.toLowerCase();
    var matchedRow=0,r=null;
    for(var rowIdx=1;rowIdx<allRows.length;rowIdx++){
      var candidate=allRows[rowIdx];
      var cellId=String(candidate[idCol]==null?'':candidate[idCol]).trim();
      var cellKey=String(candidate[keyCol]==null?'':candidate[keyCol]).trim();
      if(cellId.toLowerCase()===cleanLower||(cellKey&&cellKey===cleanId)){
        if(matchedRow>0)throw Error('Duplicate management identity');
        matchedRow=rowIdx+1;
        r=candidate;
      }
    }
    if(!matchedRow||!r)return;
    var effectiveId=String(r[idCol]==null?'':r[idCol]).trim()||cleanId;
    var rowProv=pl2Provider_(r[provCol]);
    if(rowProv&&rowProv!==provider)return;
    var rawLimit=r[limitCol];
    var limit=String(rawLimit==null?'':rawLimit).replace(/,/g,'').trim().toLowerCase();
    var max=(!limit||/^(unlimited|no\s*limit|infinite|inf)$/i.test(limit))?UNLIMITED_USAGE_LIMIT:(/^\d+$/.test(limit)?Number(limit):0);
    var rawUsed=String(r[usedCol]==null?'0':r[usedCol]).replace(/,/g,'').trim();
    var used=rawUsed===''?0:Number(rawUsed);
    if(!Number.isSafeInteger(used)||used<0)used=Math.max(0,Math.floor(Number(rawUsed)||0));
    var rawStatus=String(r[statusCol]==null?'':r[statusCol]).trim().toLowerCase();
    var statusOk=apiRowStatusAllowed_(rawStatus)||(rawStatus==='usage_limit_reached'&&used<max);
    if(!statusOk||used>=max)return;
    var secret=sanitizeApiKey_(r[keyCol]);
    if(!secret)return;
    // Key cooldown by both API ID and secret hash so replacing the API Key inside an existing API ID row immediately clears any old cooldown!
    var coolById=Number(pl2Properties_().getProperty('pl2_cool:'+effectiveId)||0);
    var coolByKey=Number(pl2Properties_().getProperty('pl2_cool_k:'+ledgerHash_(effectiveId+'|'+secret))||0);
    var cool=Math.max(coolById,coolByKey);
    var item={id:effectiveId,provider:provider,sheet:sh,row:matchedRow,headers:h,apiKey:secret,usage:used,limit:max,values:r};
    if(cool<=now)ready.push(item);
    else softCooled.push(item);
  });
  return ready.length?ready:softCooled;
}
function pl2PublicRoute_(u,provider,k){return {status:'ok',provider:provider,managedRouting:true,providerPriority:pl2Policy_(u).engines,secureProxy:true,providerContract:'user_assigned_secure_proxy_v4',keyRow:k.row,apiId:k.id,usageCount:k.usage,usageLimit:k.limit,licenceCreditRemaining:pl2Credit_(u).remaining,apiToken:'',sourceId:'',actorId:''};}
function pl2Route_(key,desired){
  var a=pl2Auth_(key,'',true);if(a.error)return a.error;
  var u=a.user,policy=pl2Policy_(u);if(!policy.scraping||policy.maxResultsPerRequest===0)return pl2Error_('denied','LICENSE_INACTIVE','Scraping is disabled for this plan.');
  var order=policy.engines;if(desired&&desired!=='auto'){desired=pl2Provider_(desired);order=order.filter(function(p){return p===desired;});}
  for(var i=0;i<order.length;i++){var pool=pl2Keys_(u,order[i]);if(pool.length){pl2Billing_(order[i]);return pl2PublicRoute_(u,order[i],pool[0]);}}
  var assignedIds=order.map(function(p){return pl2Value_(u,PL2_PREFIX[p]+' API IDs');}).filter(Boolean).join(',');
  return Object.assign(pl2Error_('no_api_key','NO_ELIGIBLE_PROVIDER','No assigned API key is available. Check assignments, status, limits and cooldown.'),{
    apiId: assignedIds||'UNASSIGNED',
    keyRow: u.row||0,
    provider: order.join(',')||'scrappa'
  });
}
function pl2Billing_(provider){
  var policies;try{policies=JSON.parse(pl2Properties_().getProperty('PL2_BILLING')||'null');}catch(e){throw pl2BillingError_(provider,'invalid JSON');}
  var p=policies&&(policies[provider]||(provider==='googlemaps'&&policies.google_place));
  // Rates are owner-confirmed provider units. Never infer billable usage from
  // result counts. Google IDs-only may have zero cost; zero balance still stops.
  if(!p||p.confirmed!==true||!Number.isSafeInteger(p.success)||p.success<0||!Number.isSafeInteger(p.failure)||p.failure<0||!Number.isSafeInteger(p.reserve)||p.reserve<Math.max(p.success,p.failure))throw pl2BillingError_(provider,'missing, unconfirmed or invalid rule');
  return p;
}
function pl2Atomic_(changes){
  if(typeof Sheets==='undefined')throw Error('Advanced Sheets service unavailable');
  var requests=changes.map(function(c){return {updateCells:{range:{sheetId:c.sheet.getSheetId(),startRowIndex:c.row-1,endRowIndex:c.row,startColumnIndex:c.col-1,endColumnIndex:c.col-1+c.values.length},rows:[{values:c.values.map(function(v){var value=typeof v==='number'?{numberValue:v}:{stringValue:v==null?'':String(v)};return {userEnteredValue:value};})}],fields:'userEnteredValue'}};});
  var required={};changes.forEach(function(c){var id=c.sheet.getSheetId();if(!required[id]||required[id].row<c.row)required[id]={sheet:c.sheet,row:c.row};});
  Object.keys(required).forEach(function(id){var x=required[id];if(x.sheet.getMaxRows&&x.row>x.sheet.getMaxRows())requests.unshift({appendDimension:{sheetId:Number(id),dimension:'ROWS',length:Math.max(100,x.row-x.sheet.getMaxRows())}});});
  Sheets.Spreadsheets.batchUpdate({requests:requests},SHEET_ID);
  changes.forEach(function(c){
    try {
      if (c && c.sheet && c.sheet.getRange && Array.isArray(c.values) && c.values.length) {
        c.sheet.getRange(c.row, c.col, 1, c.values.length).setValues([c.values]);
      }
    } catch (_) {}
  });
}
function pl2Cell_(sheet,row,col,value){return {sheet:sheet,row:row,col:col,values:[value]};}
function pl2ReceiptChange_(sh,row,identity,signature,state,value){
  var text=JSON.stringify(value),chunks=[];for(var i=0;i<text.length;i+=35000)chunks.push(text.slice(i,i+35000));
  if(chunks.length>60)throw Error('Receipt too large');while(chunks.length<60)chunks.push('');
  return {sheet:sh,row:row,col:1,values:[identity,signature,state,Date.now()].concat(chunks)};
}
function pl2ReadReceipt_(key,id){var sh=requestLedger_(),entry=ledgerEntry_(sh,ledgerHash_(key+'|'+id));return {sheet:sh,entry:entry};}
function pl2ReceiptResult_(entry,u){
  var value=JSON.parse(entry.values.slice(4).join(''));
  if(entry.values[2]==='done'){value.replayed=true;value.account=accountSnapshot_(u);return value;}
  return pl2Error_('request_pending','REQUEST_PENDING','Request has a durable reservation. Resume checks this receipt; interrupted provider calls require reconciliation.');
}
function pl2Status_(params,key,u){var r=pl2ReadReceipt_(key,params.requestId);return r.entry?pl2ReceiptResult_(r.entry,u):{status:'request_missing'};}
function pl2Attempt_(key,id){
  if(!/^[a-f0-9]{64}$/.test(String(id||'')))throw Error('Invalid extraction identity');
  var sh=ss_().getSheetByName('PocketLeadsAttempts'),identity=ledgerHash_(key+'|'+id),at=pl2FindRow_(sh,1,identity);
  var nextRow=at;
  if(!nextRow){
    var last=sh.getLastRow();
    if(last>=1000){
      var props=pl2Properties_(),seq=Number(props.getProperty('pl2_att_ring')||0);
      nextRow=2+(seq%998);
      props.setProperty('pl2_att_ring',String(seq+1));
    }else{
      nextRow=last+1;
    }
  }
  return {sheet:sh,row:nextRow,identity:identity,state:at?JSON.parse(sh.getRange(at,2).getValue()):null};
}
function pl2AttemptChange_(a){return {sheet:a.sheet,row:a.row,col:1,values:[a.identity,JSON.stringify(a.state)]};}
function pl2NextRoute_(u,a,selection){
  var policy=pl2Policy_(u),fingerprint=ledgerHash_(JSON.stringify([policy.engines,PL2_PROVIDERS.map(function(p){return pl2Value_(u,PL2_PREFIX[p]+' API IDs');})]));
  if(a.state.mapping!==fingerprint)return pl2Error_('configuration_error','ROUTE_CHANGED','Assignments changed during this query. Start a new extraction to use the new priority.');
  if(a.state.done)return {status:'attempt_complete',usableResults:a.state.usable||0};
  if(a.state.calls>=pl2Config_().requestBudget)return pl2Error_('no_api_key','PROVIDER_FAILOVER_EXHAUSTED','Extraction request budget exhausted.');
  for(;a.state.index<a.state.order.length;a.state.index++){
    var provider=a.state.order[a.state.index],pool=pl2Keys_(u,provider);
    if(pool.length){
      var bill=pl2Billing_(provider);
      if(selection){selection.pool=pool;selection.billing=bill;}
      var chosenKey=pool[0];
      if(selection&&(selection.excludeKeyRow||selection.excludeApiId)){
        var altKeys=pool.filter(function(k){return k.row!==Number(selection.excludeKeyRow||0)&&k.id!==String(selection.excludeApiId||'');});
        if(altKeys.length){chosenKey=altKeys[0];}
        else if(a.state.index+1<a.state.order.length){a.state.tried.push(provider);continue;}
      }
      return Object.assign(pl2PublicRoute_(u,provider,chosenKey),{attemptId:a.state.id,poolSize:pool.length});
    }
    a.state.tried.push(provider);
  }
  var assignedIdsNext=(a&&a.state&&a.state.order||[]).map(function(p){return pl2Value_(u,PL2_PREFIX[p]+' API IDs');}).filter(Boolean).join(',');
  logApiErrorToSheet_({
    licenceKey: normalizeLicenceKey_(u&&u.key||''),
    userName: String(pl2Value_(u,'User Name')||''),
    apiId: assignedIdsNext||'POOL_EXHAUSTED',
    keyRow: (u&&u.row)||0,
    provider: (a&&a.state&&a.state.order||[]).join(',')||'auto',
    httpStatus: 0,
    errorCode: 'PROVIDER_FAILOVER_EXHAUSTED',
    upstreamCode: 'ALL_FAILED',
    upstreamMessage: 'All assigned providers failed or returned no usable results.',
    query: 'Begin / Failover Route'
  });
  return pl2Error_('no_api_key','PROVIDER_FAILOVER_EXHAUSTED','All assigned providers failed or returned no usable results.');
}
function pl2Begin_(params,key){
  var lock=LockService.getScriptLock();lock.waitLock(25000);
  try{
    var auth=pl2Auth_(key,params.deviceId,false);if(auth.error)return auth.error;
    var u=auth.user,policy=pl2Policy_(u);if(!policy.scraping||policy.maxResultsPerRequest===0)return pl2Error_('denied','LICENSE_INACTIVE','Scraping is disabled.');
    var a=pl2Attempt_(key,params.attemptId);
    if(a.state && a.state.done)return {status:'attempt_complete',usableResults:a.state.usable};
    if(a.state && a.state.lastRequest && a.state.lastRequest.provider===a.state.order[a.state.index]) {
      var previous=a.state.lastRequest;
      return {status:'ok',managedRouting:true,secureProxy:true,providerContract:'user_assigned_secure_proxy_v4',provider:previous.provider,keyRow:previous.keyRow,attemptId:params.attemptId,recoveryOnly:true};
    }
    auth=pl2RequireCredit_(auth);if(auth.error)return auth.error;
    var currentMapping=ledgerHash_(JSON.stringify([policy.engines,PL2_PROVIDERS.map(function(p){return pl2Value_(u,PL2_PREFIX[p]+' API IDs');})]));
    if(!a.state)a.state={id:params.attemptId,order:policy.engines,index:0,tried:[],calls:0,providerCalls:{},usable:0,done:false,createdAt:Date.now(),mapping:currentMapping};
    else if(!a.state.done && (a.state.mapping!==currentMapping || (params && params.resetExhaustedAttempt))){a.state.order=policy.engines;a.state.mapping=currentMapping;a.state.index=0;a.state.tried=[];a.state.providerCalls={};a.state.calls=0;}
    if(params&&params.failedApiId)try{pl2Properties_().setProperty('pl2_cool:'+String(params.failedApiId).trim(),String(Date.now()+120000));}catch(_){}
    var sel={excludeKeyRow:params&&params.failedKeyRow,excludeApiId:params&&params.failedApiId};
    var result=pl2NextRoute_(u,a,sel);pl2Atomic_([pl2AttemptChange_(a)]);return result;
  }finally{lock.releaseLock();}
}
function pl2FinishAttempt_(params,key){
  var lock=LockService.getScriptLock();lock.waitLock(25000);
  try{
    var auth=pl2Auth_(key,params.deviceId,false);if(auth.error)return auth.error;
    var u=auth.user,policy=pl2Policy_(u);
    var a=pl2Attempt_(key,params.attemptId);
    if(!a.state){
      var currentMapping=ledgerHash_(JSON.stringify([policy.engines,PL2_PROVIDERS.map(function(p){return pl2Value_(u,PL2_PREFIX[p]+' API IDs');})]));
      a.state={id:params.attemptId,order:policy.engines,index:0,tried:[],calls:1,providerCalls:{},usable:0,done:false,createdAt:Date.now(),mapping:currentMapping};
    }
    var p=pl2Provider_(params.provider);
    // Replayed finish from an old provider must not skip the new provider.
    if(a.state.done)return {status:'attempt_complete',usableResults:a.state.usable};
    if(a.state.order[a.state.index]===p){
      if(Number(params.usableResults)>0){a.state.done=true;a.state.usable=Math.floor(Number(params.usableResults));}
      else {a.state.tried.push(p);a.state.index++;}
    }
    pl2Atomic_([pl2AttemptChange_(a)]);
    if(a.state.done)return {status:'attempt_complete',usableResults:a.state.usable};
    auth=pl2RequireCredit_(auth);if(auth.error)return auth.error;
    var result=pl2NextRoute_(auth.user,a);pl2Atomic_([pl2AttemptChange_(a)]);return result;
  }finally{lock.releaseLock();}
}
function pl2Lane_(provider,requestId,release){
  var props=pl2Properties_(),name='pl2_lane:'+provider,list=JSON.parse(props.getProperty(name)||'[]'),now=Date.now();
  list=list.filter(function(x){return x.expires>now&&x.id!==requestId;});
  if(!release){if(list.length>=pl2Config_().laneLimits[provider])return false;list.push({id:requestId,expires:now+7*60*1000});}
  props.setProperty(name,JSON.stringify(list));return true;
}
function pl2RequestSpec_(provider,operation,payload,key,cap){
  payload=payload||{};var body=payload.body||payload;
  if(provider==='scrappa'){
    if(operation!=='simpleSearch'||!String(payload.query||'').trim()||Number(payload.page||0)!==0)throw Error('Scrappa supports one page-0 simple search per query');
    return {url:'https://scrappa.co/api/maps/simple-search?query='+encodeURIComponent(String(payload.query))+'&limit='+Math.min(200,cap)+'&page=0&hl='+encodeURIComponent(String(payload.hl||'en'))+(payload.gl?'&gl='+encodeURIComponent(payload.gl):'')+(payload.fields?'&fields='+encodeURIComponent(String(payload.fields)):''),options:{method:'get',headers:{'X-API-KEY':key}}};
  }
  if(provider==='serper'){
    if(operation!=='maps'||!String(body.q||'').trim())throw Error('Managed Serper supports Maps search');
    // Only allow search parameters, not arbitrary endpoint/headers.
    var data={q:String(body.q),page:Math.max(1,Math.min(50,Number(body.page)||1)),num:Math.min(20,cap)};
    ['gl','hl','ll','location'].forEach(function(n){if(body[n])data[n]=String(body[n]);});
    return {url:'https://google.serper.dev/maps',options:{method:'post',contentType:'application/json',headers:{'X-API-KEY':key},payload:JSON.stringify(data)}};
  }
  if(provider==='googlemaps'){
    if(operation!=='textSearch'||!String(body.textQuery||'').trim())throw Error('Unsupported Maps request');
    var g={textQuery:String(body.textQuery),pageSize:Math.min(20,cap)};if(body.pageToken)g.pageToken=String(body.pageToken);
    return {url:'https://places.googleapis.com/v1/places:searchText',options:{method:'post',contentType:'application/json',headers:{'X-Goog-Api-Key':key,'X-Goog-FieldMask':'places.id,nextPageToken'},payload:JSON.stringify(g)}};
  }
  throw Error('Unassigned provider');
}
function pl2Reserve_(params,key){
  var lock=LockService.getScriptLock();lock.waitLock(25000);
  try{
    var auth=pl2Auth_(key,params.deviceId,false);if(auth.error)return {response:auth.error};
    if(!/^[a-f0-9]{64}$/.test(String(params.requestId||'')))return {response:pl2Error_('request_conflict','REQUEST_CONFLICT','A durable request ID is required.')};
    var signature=ledgerHash_(JSON.stringify([params.provider,params.keyRow,params.operation,params.payload,params.attemptId]));
    var r=pl2ReadReceipt_(key,params.requestId),u=auth.user;
    if(r.entry){
      // Legacy receipt recovery is read-only. Do not reinterpret its billing.
      if(r.entry.values[1]!==signature){var oldsig=ledgerHash_(JSON.stringify([params.provider,params.keyRow,params.operation,params.payload]));if(r.entry.values[1]===oldsig)return {response:receiptResponse_(r.entry,u)};return {response:pl2Error_('request_conflict','REQUEST_CONFLICT','Request ID reused with different input.')};}
      return {response:pl2ReceiptResult_(r.entry,u)};
    }
    auth=pl2RequireCredit_(auth);if(auth.error)return {response:auth.error};u=auth.user;
    var policy=pl2Policy_(u);if(!policy.scraping||policy.maxResultsPerRequest===0)return {response:pl2Error_('denied','LICENSE_INACTIVE','Scraping disabled.')};
    var a=pl2Attempt_(key,params.attemptId);
    if(!a.state && params && params.autoBegin){
      a.state={id:params.attemptId,order:policy.engines,index:0,tried:[],calls:0,providerCalls:{},usable:0,done:false,createdAt:Date.now(),mapping:ledgerHash_(JSON.stringify([policy.engines,PL2_PROVIDERS.map(function(p){return pl2Value_(u,PL2_PREFIX[p]+' API IDs');})]))};
    }else if(a.state && !a.state.done && params && params.autoBegin && a.state.index>=a.state.order.length){
      a.state.index=0;a.state.tried=[];a.state.providerCalls={};a.state.calls=0;
    }
    if(!a.state)return {response:pl2Error_('denied','ROUTE_CHANGED','Begin this extraction before requesting a provider.')};
    var selection={},route=pl2NextRoute_(u,a,selection),provider=pl2Provider_(params.provider);
    if(route.status!=='ok'){
      if(params && params.autoBegin)try{pl2Atomic_([pl2AttemptChange_(a)]);}catch(_){}
      return {response:route};
    }
    if(route.provider!==provider){
      if(params && params.autoBegin)try{pl2Atomic_([pl2AttemptChange_(a)]);}catch(_){}
      return {response:Object.assign(pl2Error_('configuration_error','ROUTE_CHANGED','Provider is not the next assigned provider.'),{nextRoute:route})};
    }
    var paidCount=Number(a.state.providerCalls[provider]||0),max=provider==='scrappa'?((params&&params.autoBegin)?3:1):(provider==='googlemaps'?3:(/\b\d{6}\b/.test(String(params.payload&&params.payload.body&&params.payload.body.q||''))?7:50));
    if(paidCount>=max)return {response:pl2Error_('provider_error','PROVIDER_BUDGET','Provider page budget exhausted.')};
    var pool=selection.pool,props=pl2Properties_(),cursor=Number(props.getProperty('pl2_rr:'+provider)||0),chosen=pool[cursor%pool.length],bill=selection.billing;
    var cap=provider==='scrappa'?200:20;if(policy.maxResultsPerRequest!=='unlimited')cap=Math.min(cap,policy.maxResultsPerRequest);
    var spec=pl2RequestSpec_(provider,params.operation,params.payload,chosen.apiKey,cap);
    if(!auth.credit.unlimited&&auth.credit.remaining<bill.reserve)return {response:pl2Error_('credits_exhausted','LICENSE_CREDIT_EXHAUSTED','Not enough Available Credit to reserve this call. Buy Credits.')};
    var bypassLane=!!(params&&params._bypassLaneGate);
    if(!bypassLane&&!pl2Lane_(provider,ledgerHash_(key+'|'+params.requestId),false))return {response:Object.assign(pl2Error_('busy','PROVIDER_BUSY','Provider lane busy. Progress saved; retry shortly.'),{retryAfter:Date.now()+3000})};
    props.setProperty('pl2_rr:'+provider,String(cursor+1));
    var identity=ledgerHash_(key+'|'+params.requestId),lastReqRow=r.sheet.getLastRow(),row=lastReqRow+1;
    if(lastReqRow>=500){
      var reqSeq=Number(props.getProperty('pl2_req_ring')||0);
      for(var probe=0;probe<20;probe++){
        var cand=2+((reqSeq+probe)%498);
        var st=String(r.sheet.getRange(cand,3).getValue()||'');
        if(st!=='pending'){row=cand;reqSeq=reqSeq+probe+1;break;}
      }
      props.setProperty('pl2_req_ring',String(reqSeq));
    }
    var reservation={v:2,identity:identity,signature:signature,requestId:params.requestId,provider:provider,apiId:chosen.id,keyRow:chosen.row,userRow:u.row,creditColumn:u.availableCreditCol,reserved:bill.reserve,unlimited:auth.credit.unlimited,billing:bill,attemptId:params.attemptId,operation:params.operation,cap:cap,laneBypassed:bypassLane,createdAt:Date.now()};
    var changes=[];
    if(!auth.credit.unlimited)changes.push(pl2Cell_(u.sheet,u.row,u.availableCreditCol,auth.credit.remaining-bill.reserve));
    // Count attempted dispatches, including uncertain transport calls. No retry
    // occurs inside providerFetch. The same request receipt always replays.
    changes.push(pl2Cell_(chosen.sheet,chosen.row,chosen.headers['Calls Used'],chosen.usage+1));
    changes.push(pl2Cell_(chosen.sheet,chosen.row,chosen.headers['Last Used At'],new Date().toISOString()));
    var prefix=PL2_PREFIX[provider],uc=u.headers[prefix+' Calls'];
    changes.push(pl2Cell_(u.sheet,u.row,uc,Number(pl2Value_(u,prefix+' Calls')||0)+1));
    changes.push(pl2Cell_(u.sheet,u.row,u.headers['Last Used At'],new Date().toISOString()));
    a.state.calls++;a.state.providerCalls[provider]=paidCount+1;
    a.state.lastRequest={provider:provider,keyRow:params.keyRow,requestId:params.requestId};
    changes.push(pl2AttemptChange_(a),pl2ReceiptChange_(r.sheet,row,identity,signature,'pending',reservation));
    try{pl2Atomic_(changes);}catch(e){if(!bypassLane)pl2Lane_(provider,ledgerHash_(key+'|'+params.requestId),true);throw e;}
    return {reservation:reservation,receiptRow:row,receiptSheet:r.sheet,user:u,key:chosen,spec:spec};
  }finally{lock.releaseLock();}
}
function pl2Settle_(context,key,result,counted,billable,uncertain){
  var lock=LockService.getScriptLock();lock.waitLock(25000);
  try{
    var r=context.reservation,entry=ledgerEntry_(context.receiptSheet,r.identity);
    if(entry&&entry.values[2]==='done')return pl2ReceiptResult_(entry,context.user);
    var u=pl2User_(key),l=pl2Layout_('keys'),sh=ss_().getSheetByName(l.name),h=l.headers;
    var cachedKr=pl2Cached_('api:'+ledgerHash_(r.apiId),function(){return {row:pl2FindRow_(sh,h['API ID'],r.apiId)};});
    var kr=(cachedKr&&cachedKr.row)||pl2FindRow_(sh,h['API ID'],r.apiId);
    if(kr&&String(sh.getRange(kr,h['API ID']).getValue()).trim()!==r.apiId)kr=pl2FindRow_(sh,h['API ID'],r.apiId);
    if(!u||!kr)throw Error('Reserved account/key removed; manual reconciliation required');
    if(uncertain){if(!r.laneBypassed)pl2Lane_(r.provider,r.identity,true);return Object.assign(pl2Error_('provider_error','PROVIDER_TIMEOUT_UNCERTAIN','Provider timed out. Reservation retained for reconciliation; next assigned provider may run with remaining credit.'),{requestId:r.requestId,reservationPending:true});}
    if(!Number.isSafeInteger(billable)||billable<0||billable>r.reserved){if(!r.laneBypassed)pl2Lane_(r.provider,r.identity,true);return Object.assign(pl2Error_('request_uncertain','REQUEST_UNCERTAIN','Billing exceeded reservation; manual reconciliation required.'),{requestId:r.requestId,reservationPending:true});}
    var current=pl2Credit_(u);if(!current.valid)throw Error('Credit changed to an invalid value');
    var changes=[],prefix=PL2_PREFIX[r.provider],raw=counted?counted.rawCount:0;
    var settledCredit=(!r.unlimited&&!current.unlimited)?Math.max(0,current.remaining+r.reserved-billable):current.remaining;
    if(!r.unlimited&&!current.unlimited)changes.push(pl2Cell_(u.sheet,u.row,u.availableCreditCol,settledCredit));
    changes.push(pl2Cell_(sh,kr,h['Results Returned'],Number(sh.getRange(kr,h['Results Returned']).getValue()||0)+raw));
    var rc=u.headers[prefix+' Results'],nextUserResults=Number(pl2Value_(u,prefix+' Results')||0)+raw;
    changes.push(pl2Cell_(u.sheet,u.row,rc,nextUserResults));
    result.requestId=r.requestId;result.provider=r.provider;result.keyRow=kr;result.apiId=r.apiId;result.serverAccounted=true;
    result.creditsConsumed=billable;result.apiCalls=1;result.rawProviderResultCount=raw;result.returnedResultCount=counted?counted.count:0;
    changes.push(pl2ReceiptChange_(context.receiptSheet,context.receiptRow,r.identity,r.signature,'done',result));
    pl2Atomic_(changes);if(!r.laneBypassed)pl2Lane_(r.provider,r.identity,true);
    if(result.errorCode==='PROVIDER_AUTH'){
      pl2Properties_().setProperty('pl2_cool:'+r.apiId,String(Date.now()+120000));
      if(context&&context.key&&context.key.apiKey)pl2Properties_().setProperty('pl2_cool_k:'+ledgerHash_(r.apiId+'|'+context.key.apiKey),String(Date.now()+300000));
    }
    else if(result.status==='provider_error')pl2Properties_().setProperty('pl2_cool:'+r.apiId,String(Date.now()+(result.errorCode==='PROVIDER_RATE_LIMIT'?60000:30000)));
    if(Array.isArray(u.values)){
      if(!r.unlimited&&!current.unlimited&&u.availableCreditCol)u.values[u.availableCreditCol-1]=settledCredit;
      if(rc)u.values[rc-1]=nextUserResults;
    }
    result.account=accountSnapshot_(u);return result;
  }finally{lock.releaseLock();}
}
function pl2AccumulateFastDelta_(cache,kh,provider,apiId,calls,results,creditDebit){
  if(!cache)return {totalCalls:0,firstAt:Date.now()};
  var dKey='pl2_fdelta:'+kh,raw=cache.get(dKey),d=null;
  try{d=raw?JSON.parse(raw):null;}catch(_){d=null;}
  if(!d||typeof d!=='object')d={firstAt:Date.now(),totalCalls:0,creditDebit:0,uCalls:{},uResults:{},kCalls:{},kResults:{}};
  if(calls>0&&provider){
    d.totalCalls=(d.totalCalls||0)+calls;
    d.uCalls[provider]=(d.uCalls[provider]||0)+calls;
    if(apiId)d.kCalls[apiId]=(d.kCalls[apiId]||0)+calls;
  }
  if(results>0&&provider){
    d.uResults[provider]=(d.uResults[provider]||0)+results;
    if(apiId)d.kResults[apiId]=(d.kResults[apiId]||0)+results;
  }
  if(creditDebit>0){
    d.creditDebit=(d.creditDebit||0)+creditDebit;
  }
  try{cache.put(dKey,JSON.stringify(d),21600);}catch(_){}
  return d;
}

function pl2FlushFastDeltaLocked_(key,kh,cache,u,extraCreditDebit){
  var dKey='pl2_fdelta:'+kh,raw=cache?cache.get(dKey):null,d=null;
  try{d=raw?JSON.parse(raw):null;}catch(_){d=null;}
  var totalDebit=Math.max(0,Number((d&&d.creditDebit)||0)+Number(extraCreditDebit||0));
  var hasCounters=d&&(d.totalCalls>0||Object.keys(d.uCalls||{}).length>0||Object.keys(d.kCalls||{}).length>0);
  if(!totalDebit&&!hasCounters)return {deducted:0,flushedCalls:0};
  if(!u)u=pl2User_(key);
  if(!u)return {deducted:0,flushedCalls:0};
  var changes=[],nowIsoStr=new Date().toISOString(),actualDeducted=0;
  var current=pl2Credit_(u);
  if(totalDebit>0&&current&&current.valid&&!current.unlimited&&u.availableCreditCol){
    var nextVal=Math.max(0,current.remaining-totalDebit);
    actualDeducted=Math.max(0,current.remaining-nextVal);
    changes.push(pl2Cell_(u.sheet,u.row,u.availableCreditCol,nextVal));
    if(Array.isArray(u.values))u.values[u.availableCreditCol-1]=nextVal;
    if(cache){
      var gen=pl2Properties_().getProperty('PL2_GENERATION')||'0';
      try{cache.put('pl2_fc:'+gen+':'+kh,String(nextVal),180);}catch(_){}
    }
  }
  if(hasCounters){
    Object.keys(d.uCalls||{}).forEach(function(p){
      var cAdd=Number(d.uCalls[p]||0),rAdd=Number((d.uResults&&d.uResults[p])||0),pfx=PL2_PREFIX[p];
      if(!pfx)return;
      var uc=u.headers[pfx+' Calls'],rc=u.headers[pfx+' Results'];
      if(uc&&cAdd>0){
        var nextC=Number(pl2Value_(u,pfx+' Calls')||0)+cAdd;
        changes.push(pl2Cell_(u.sheet,u.row,uc,nextC));
        if(Array.isArray(u.values))u.values[uc-1]=nextC;
      }
      if(rc&&rAdd>0){
        var nextR=Number(pl2Value_(u,pfx+' Results')||0)+rAdd;
        changes.push(pl2Cell_(u.sheet,u.row,rc,nextR));
        if(Array.isArray(u.values))u.values[rc-1]=nextR;
      }
    });
    if(u.headers['Last Used At'])changes.push(pl2Cell_(u.sheet,u.row,u.headers['Last Used At'],nowIsoStr));
    var kIds=Object.keys(d.kCalls||{});
    if(kIds.length){
      var kl=pl2Layout_('keys'),ksh=ss_().getSheetByName(kl.name),khdr=kl.headers;
      kIds.forEach(function(apiId){
        var kcAdd=Number(d.kCalls[apiId]||0),krAdd=Number((d.kResults&&d.kResults[apiId])||0);
        if(!kcAdd&&!krAdd)return;
        var cachedKr=pl2Cached_('api:'+ledgerHash_(apiId),function(){return {row:pl2FindRow_(ksh,khdr['API ID'],apiId)};});
        var kr=(cachedKr&&cachedKr.row)||pl2FindRow_(ksh,khdr['API ID'],apiId);
        if(!kr)return;
        var kRowVals=ksh.getRange(kr,1,1,ksh.getLastColumn()).getValues()[0];
        if(kcAdd>0&&khdr['Calls Used']){
          changes.push(pl2Cell_(ksh,kr,khdr['Calls Used'],Number(kRowVals[khdr['Calls Used']-1]||0)+kcAdd));
        }
        if(krAdd>0&&khdr['Results Returned']){
          changes.push(pl2Cell_(ksh,kr,khdr['Results Returned'],Number(kRowVals[khdr['Results Returned']-1]||0)+krAdd));
        }
        if(khdr['Last Used At'])changes.push(pl2Cell_(ksh,kr,khdr['Last Used At'],nowIsoStr));
      });
    }
  }
  if(changes.length)pl2Atomic_(changes);
  if(cache){try{cache.put(dKey,JSON.stringify({firstAt:Date.now(),totalCalls:0,creditDebit:0,uCalls:{},uResults:{},kCalls:{},kResults:{}}),21600);}catch(_){}}
  return {deducted:actualDeducted,flushedCalls:(d&&d.totalCalls)||0};
}

function pl2FastProxy_(params,key){
  var cache=typeof CacheService!=='undefined'?CacheService.getScriptCache():null;
  if(!cache)return null;
  var props=pl2Properties_(),gen=props.getProperty('PL2_GENERATION')||'0';
  var normKey=normalizeLicenceKey_(key),kh=ledgerHash_(normKey);
  var fsKey='pl2_fs:'+gen+':'+kh,fcKey='pl2_fc:'+gen+':'+kh;
  var sess=null;
  try{var raw=cache.get(fsKey);if(raw)sess=JSON.parse(raw);}catch(_){sess=null;}
  if(!sess||sess.deviceId!==String(params.deviceId||'')){
    var auth=pl2Auth_(normKey,params.deviceId,false);
    if(auth.error)return auth.error;
    var u=auth.user,policy=pl2Policy_(u);
    if(!policy.scraping||policy.maxResultsPerRequest===0)return pl2Error_('denied','LICENSE_INACTIVE','Scraping disabled.');
    var pools={},billings={};
    policy.engines.forEach(function(eng){
      var kl=pl2Keys_(u,eng);
      if(kl&&kl.length){
        pools[eng]=kl.map(function(k){return {id:k.id,row:k.row,apiKey:k.apiKey,usage:k.usage,limit:k.limit};});
        billings[eng]=pl2Billing_(eng);
      }
    });
    var snap=accountSnapshot_(u);
    sess={
      gen:gen,
      row:u.row,
      deviceId:String(params.deviceId||''),
      unlimited:!!auth.credit.unlimited,
      baseCredit:Number(auth.credit.remaining||0),
      engines:policy.engines,
      maxResultsPerRequest:policy.maxResultsPerRequest,
      pools:pools,
      billings:billings,
      snapshot:snap
    };
    try{
      cache.put(fsKey,JSON.stringify(sess),60);
      if(!sess.unlimited&&cache.get(fcKey)===null)cache.put(fcKey,String(sess.baseCredit),180);
    }catch(_){}
  }
  var liveCred=sess.unlimited?UNLIMITED_USAGE_LIMIT:Number(cache.get(fcKey)??sess.baseCredit);
  if(!sess.unlimited&&liveCred<=0)return pl2Error_('credits_exhausted','LICENSE_CREDIT_EXHAUSTED','No Available Credit. Buy Credits to continue.');
  var provider=pl2Provider_(params.provider);
  var rawPool=(sess.pools&&sess.pools[provider])||[],now=Date.now(),ready=[],soft=[];
  var fastDeltaObj=null;
  try{var fdRaw=cache.get('pl2_fdelta:'+kh);if(fdRaw)fastDeltaObj=JSON.parse(fdRaw);}catch(_){}
  rawPool.forEach(function(k){
    var pendK=(fastDeltaObj&&fastDeltaObj.kCalls&&Number(fastDeltaObj.kCalls[k.id]))||0;
    if(k.limit>0&&(Number(k.usage||0)+pendK)>=k.limit)return;
    var cAt=Number(cache.get('pl2_fcool:'+k.id)||props.getProperty('pl2_cool:'+k.id)||0);
    if(cAt<=now)ready.push(k);
    else soft.push(k);
  });
  var pool=ready.length?ready:soft;
  if(!pool.length&&raw){
    refreshPocketLeadsCache();
    var freshAuth=pl2Auth_(normKey,params.deviceId,false);
    if(!freshAuth.error){
      var freshKl=pl2Keys_(freshAuth.user,provider);
      if(freshKl&&freshKl.length){
        pool=freshKl.map(function(k){return {id:k.id,row:k.row,apiKey:k.apiKey,usage:k.usage,limit:k.limit};});
        sess.pools[provider]=pool;
        try{cache.put(fsKey,JSON.stringify(sess),60);}catch(_){}
      }
    }
  }
  if(!pool.length){
    for(var ei=0;ei<(sess.engines||[]).length;ei++){
      var alt=sess.engines[ei];
      if(alt!==provider&&sess.pools&&sess.pools[alt]&&sess.pools[alt].length){
        var ak=sess.pools[alt][0];
        return Object.assign(pl2Error_('configuration_error','ROUTE_CHANGED','Provider switched to next healthy engine.'),{
          nextRoute:{status:'ok',provider:alt,managedRouting:true,secureProxy:true,providerContract:'user_assigned_secure_proxy_v4',keyRow:ak.row,apiId:ak.id,attemptId:params.attemptId}
        });
      }
    }
    logApiErrorToSheet_({licenceKey:normKey,userName:(sess&&sess.snapshot&&sess.snapshot.userName)||'',apiId:'POOL_EMPTY',keyRow:0,provider:provider,httpStatus:0,errorCode:'PROVIDER_FAILOVER_EXHAUSTED',upstreamCode:'NO_HEALTHY_KEY',upstreamMessage:'All assigned providers failed or returned no usable results.',query:extractPayloadQuery_(params&&params.payload)});
    return Object.assign(pl2Error_('no_api_key','PROVIDER_FAILOVER_EXHAUSTED','All assigned providers failed or returned no usable results.'),{serverLoggedError:true});
  }
  var rrKey='pl2_frr:'+provider,cursor=Number(cache.get(rrKey)||0);
  try{cache.put(rrKey,String(cursor+1),300);}catch(_){}
  var cap=provider==='scrappa'?200:20;
  if(sess.maxResultsPerRequest!=='unlimited')cap=Math.min(cap,sess.maxResultsPerRequest);
  if(!sess.unlimited&&isFinite(liveCred)&&liveCred>0&&liveCred<cap){
    cap=Math.max(1,Math.floor(liveCred));
  }
  var maxKeyTries=params.autoRotateKey?Math.min(5,Math.max(1,pool.length)):1;
  var chosen=pool[cursor%pool.length],response=null,lastCode='PROVIDER_UNAVAILABLE',totalAttemptsMade=0,reloadedLivePool=false;
  for(var kt=0;kt<maxKeyTries;kt++){
    chosen=pool[(cursor+kt)%pool.length];
    var spec=pl2RequestSpec_(provider,params.operation,params.payload,chosen.apiKey,cap);
    try{response=fetchJsonProxy_(spec.url,spec.options);}
    catch(e){
      logApiErrorToSheet_({licenceKey:normKey,userName:(sess&&sess.snapshot&&sess.snapshot.userName)||'',apiId:chosen.id,keyRow:chosen.row,provider:provider,httpStatus:0,errorCode:'PROVIDER_TIMEOUT_UNCERTAIN',upstreamCode:'TIMEOUT',upstreamMessage:String(e&&e.message||'Provider timed out.'),query:extractPayloadQuery_(params&&params.payload)});
      return Object.assign(pl2Error_('provider_error','PROVIDER_TIMEOUT_UNCERTAIN','Provider timed out.'),{requestId:params.requestId,serverLoggedError:true});
    }
    totalAttemptsMade++;
    if(response&&response.ok)break;
    lastCode=classifyProviderFailure_(response);
    var coolMs=lastCode==='PROVIDER_AUTH'?180000:(lastCode==='PROVIDER_RATE_LIMIT'?45000:20000);
    try{cache.put('pl2_fcool:'+chosen.id,String(Date.now()+coolMs),3600);}catch(_){}
    pl2AccumulateFastDelta_(cache,kh,provider,chosen.id,1,0,0);
    // If cached session was used and key failed, reload live sheet once in case admin just replaced/added a key in Google Sheets
    if(!reloadedLivePool&&raw&&params.autoRotateKey){
      reloadedLivePool=true;
      refreshPocketLeadsCache();
      var liveAuth=pl2Auth_(normKey,params.deviceId,false);
      if(!liveAuth.error){
        var liveKl=pl2Keys_(liveAuth.user,provider);
        if(liveKl&&liveKl.length){
          var freshPool=liveKl.map(function(k){return {id:k.id,row:k.row,apiKey:k.apiKey,usage:k.usage,limit:k.limit};}).filter(function(k){return k.apiKey!==chosen.apiKey;});
          if(freshPool.length){
            pool=freshPool;
            sess.pools[provider]=liveKl.map(function(k){return {id:k.id,row:k.row,apiKey:k.apiKey,usage:k.usage,limit:k.limit};});
            try{cache.put(fsKey,JSON.stringify(sess),60);}catch(_){}
            cursor=0;kt=-1;maxKeyTries=Math.min(5,pool.length);
          }
        }
      }
    }
  }
  if(!response||!response.ok){
    var nextEngineRoute=null;
    if(lastCode==='PROVIDER_AUTH'||lastCode==='PROVIDER_QUOTA'){
      for(var ei2=0;ei2<(sess.engines||[]).length;ei2++){
        var altEng=sess.engines[ei2];
        if(altEng!==provider&&sess.pools&&sess.pools[altEng]&&sess.pools[altEng].length){
          var ak2=sess.pools[altEng][0];
          nextEngineRoute={status:'ok',provider:altEng,managedRouting:true,secureProxy:true,providerContract:'user_assigned_secure_proxy_v4',keyRow:ak2.row,apiId:ak2.id,attemptId:params.attemptId};
          break;
        }
      }
    }
    var fastUpInfo=extractUpstreamErrorInfo_(response);
    var cleanUpMsg=redactProviderSecret_(fastUpInfo.upstreamMessage,chosen.apiKey);
    logApiErrorToSheet_({
      licenceKey: normKey,
      userName: (sess&&sess.snapshot&&sess.snapshot.userName)||'',
      apiId: chosen.id,
      keyRow: chosen.row,
      provider: provider,
      httpStatus: response&&response.httpStatus||0,
      errorCode: lastCode,
      upstreamCode: fastUpInfo.upstreamCode,
      upstreamMessage: cleanUpMsg,
      query: extractPayloadQuery_(params.payload)
    });
    var errOut={status:'provider_error',errorCode:lastCode,upstreamCode:fastUpInfo.upstreamCode,upstreamError:cleanUpMsg,serverLoggedError:true,httpStatus:response&&response.httpStatus||0,message:'Provider request failed ('+lastCode+').'+(cleanUpMsg?' '+cleanUpMsg:''),requestId:params.requestId,provider:provider,keyRow:chosen.row,apiId:chosen.id,serverAccounted:true,creditsConsumed:0,apiCalls:totalAttemptsMade||1};
    if(nextEngineRoute)errOut.nextRoute=nextEngineRoute;
    return errOut;
  }
  var counted;
  try{counted=trimAndCountProviderResults_(provider,params.operation,response.data,cap,params.payload);}
  catch(e){return {status:'provider_error',errorCode:'PROVIDER_RESPONSE_INVALID',message:'Provider returned an unsupported result shape.',requestId:params.requestId,provider:provider,keyRow:chosen.row,apiId:chosen.id};}
  counted.rawCount=pl2RawCount_(provider,response.data,counted.rawCount);
  var delta=pl2AccumulateFastDelta_(cache,kh,provider,chosen.id,1,counted.rawCount,0);
  if(delta.totalCalls>=18||(Date.now()-(delta.firstAt||0)>=25000)){
    var lock=LockService.getScriptLock();
    var gotLock=false;
    try{gotLock=typeof lock.tryLock==='function'?lock.tryLock(1200):false;}catch(_){gotLock=false;}
    if(gotLock){
      try{pl2FlushFastDeltaLocked_(normKey,kh,cache,null,0);}catch(_){}
      finally{try{lock.releaseLock();}catch(_){}}
    }
  }
  var outSnap=Object.assign({},sess.snapshot||{});
  if(!sess.unlimited){
    outSnap.availableCredit=liveCred;
    outSnap.structuredCredit=liveCred;
    outSnap.googleMapsCredit=liveCred;
  }
  return {
    status:'ok',
    secureProxy:true,
    httpStatus:response.httpStatus,
    data:redactProviderSecret_(counted.data,chosen.apiKey),
    requestId:params.requestId,
    provider:provider,
    keyRow:chosen.row,
    apiId:chosen.id,
    serverAccounted:true,
    creditsConsumed:0,
    apiCalls:1,
    rawProviderResultCount:counted.rawCount,
    returnedResultCount:counted.count,
    account:outSnap
  };
}

function pl2Proxy_(params,key){
  if(params&&params.fastRamProxy){
    var fastRes=pl2FastProxy_(params,key);
    if(fastRes)return fastRes;
  }
  var pName='';try{pName=pl2Provider_(params&&params.provider);}catch(_){}
  var laneLimit=pName?Number(pl2Config_().laneLimits[pName]||0):0;
  var proxyParams=(laneLimit>1&&params)?Object.assign({},params,{_bypassLaneGate:true}):params;
  var c=pl2Reserve_(proxyParams,key);if(c.response)return c.response;
  var response;
  try{response=fetchJsonProxy_(c.spec.url,c.spec.options);}catch(e){return pl2Settle_(c,key,null,null,0,true);}
  var r=c.reservation,bill=r.billing;
  if(!response||!response.ok){
    var code=classifyProviderFailure_(response);
    var pl2Up=extractUpstreamErrorInfo_(response);
    var cleanPl2Msg=redactProviderSecret_(pl2Up.upstreamMessage,c.key&&c.key.apiKey);
    logApiErrorToSheet_({
      licenceKey: normalizeLicenceKey_(key),
      userName: String(pl2Value_(c.user,'User Name')||''),
      apiId: r.apiId,
      keyRow: r.keyRow,
      provider: r.provider,
      httpStatus: response&&response.httpStatus||0,
      errorCode: code,
      upstreamCode: pl2Up.upstreamCode,
      upstreamMessage: cleanPl2Msg,
      query: extractPayloadQuery_(params&&params.payload)
    });
    return pl2Settle_(c,key,{status:'provider_error',errorCode:code,upstreamCode:pl2Up.upstreamCode,upstreamError:cleanPl2Msg,serverLoggedError:true,httpStatus:response&&response.httpStatus||0,message:'Provider request failed ('+code+').'+(cleanPl2Msg?' '+cleanPl2Msg:'')},null,bill.failure,false);
  }
  var cost=bill.success;
  if(bill.responseCredits===true){if(!Number.isSafeInteger(response.data&&response.data.credits)||response.data.credits<0)return pl2Settle_(c,key,null,null,0,true);cost=response.data.credits;}
  var counted;
  try{counted=trimAndCountProviderResults_(r.provider,r.operation,response.data,r.cap,params.payload);}
  catch(e){return pl2Settle_(c,key,{status:'provider_error',errorCode:'PROVIDER_RESPONSE_INVALID',message:'Provider returned an unsupported result shape.'},null,cost,false);}
  counted.rawCount=pl2RawCount_(r.provider,response.data,counted.rawCount);
  return pl2Settle_(c,key,{status:'ok',secureProxy:true,httpStatus:response.httpStatus,data:redactProviderSecret_(counted.data,c.key.apiKey)},counted,cost,false);
}

function pl2RawCount_(provider,data,fallback){
  if(Array.isArray(data))return data.length;
  var aliases=provider==='googlemaps'?['places']:provider==='scrappa'?['items','results']:['places','localResults','local_results','placesResults','places_results','mapsResults','maps_results','results','organic'];
  for(var i=0;i<aliases.length;i++){if(data&&Array.isArray(data[aliases[i]]))return data[aliases[i]].length;if(data&&data.data&&Array.isArray(data.data[aliases[i]]))return data.data[aliases[i]].length;}
  return fallback||0;
}
// Editor-only recovery. Require a provider-confirmed charge/result, not a guess.
// Never automatically replay or expire a pending paid request.
function reconcilePocketLeadsRequest(licenceKey,requestId,decision){
  if(!decision||decision.providerConfirmed!==true||!Number.isSafeInteger(decision.creditsConsumed))throw Error('Provider-confirmed billing decision required');
  var key=normalizeLicenceKey_(licenceKey),receipt=pl2ReadReceipt_(key,requestId);
  if(!receipt.entry)throw Error('Receipt not found');
  var u=pl2User_(key);if(receipt.entry.values[2]==='done')return pl2ReceiptResult_(receipt.entry,u);
  var r=JSON.parse(receipt.entry.values.slice(4).join(''));if(r.v!==2)throw Error('Legacy pending request requires legacy reconciliation; do not reinterpret its charge');
  var result=decision.response||{status:'provider_error',errorCode:'PROVIDER_RECONCILED',message:'Provider confirmed failed request.'};
  var count=Number(decision.resultsReturned||0);if(!Number.isSafeInteger(count)||count<0)throw Error('Invalid confirmed result count');
  result.reconciled=true;
  return pl2Settle_({reservation:r,receiptRow:receipt.entry.row,receiptSheet:receipt.sheet,user:u},key,result,{count:count,rawCount:count},decision.creditsConsumed,false);
}

function pl2ReportUniqueLeads_(params,key){
  var rawAdded=Math.max(0,Math.min(50000,parseInt(params&&(params.rawUniqueAdded!==undefined?params.rawUniqueAdded:(params.uniqueAdded||params.uniqueLeadCount||params.savedCount)),10)||0));
  var debitAmount=Math.max(0,Math.min(50000,parseInt(params&&(params.creditToDeduct!==undefined?params.creditToDeduct:(params.uniqueAdded||params.uniqueLeadCount||params.savedCount)),10)||0));
  var shouldDeduct=params&&params.deductUniqueCredit!==false;
  var normKey=normalizeLicenceKey_(key),kh=ledgerHash_(normKey);
  var cacheKey=metricEventCacheKey_(params&&(params.eventId||params.metricEventId)||"");
  var cache=typeof CacheService!=="undefined"?CacheService.getScriptCache():null;
  if(!rawAdded&&!debitAmount){
    if(cache&&params&&params.flushCounters){
      var fLock=LockService.getScriptLock();fLock.waitLock(25000);
      try{pl2FlushFastDeltaLocked_(normKey,kh,cache,null,0);}finally{fLock.releaseLock();}
    }
    return {status:"ok",serverAccounted:true,uniqueAdded:0,creditDeducted:0};
  }
  if(cache&&cacheKey&&cache.get(cacheKey)){
    var uDup=pl2User_(normKey);
    return {status:"ok",serverAccounted:true,duplicateEvent:true,uniqueAdded:0,creditDeducted:0,account:uDup?accountSnapshot_(uDup):null};
  }
  // Update live RAM credit immediately so concurrent pl2FastProxy_ calls see the deduction in 0ms
  if(cache&&shouldDeduct&&debitAmount>0){
    var gen=pl2Properties_().getProperty('PL2_GENERATION')||'0',fcKey='pl2_fc:'+gen+':'+kh;
    var curLive=cache.get(fcKey);
    if(curLive!==null&&/^-?\d+$/.test(String(curLive))){
      try{cache.put(fcKey,String(Math.max(0,Number(curLive)-debitAmount)),180);}catch(_){}
    }
  }
  var lock=LockService.getScriptLock();lock.waitLock(25000);
  try{
    if(cache&&cacheKey&&cache.get(cacheKey)){
      var uDup2=pl2User_(normKey);
      return {status:"ok",serverAccounted:true,duplicateEvent:true,uniqueAdded:0,creditDeducted:0,account:uDup2?accountSnapshot_(uDup2):null};
    }
    var u=pl2User_(normKey);
    if(!u)return {status:"ok",serverAccounted:true,uniqueAdded:0,creditDeducted:0};
    var flushRes=pl2FlushFastDeltaLocked_(normKey,kh,cache,u,shouldDeduct?debitAmount:0);
    var snapAfter=accountSnapshot_(u);
    var stAfter=licenceStatusInfo_(u),valAfter=licenceValidityInfo_(u,false),credAfter=pl2Credit_(u);
    if(cache&&(!stAfter.active||!valAfter.active||(!credAfter.unlimited&&credAfter.remaining<=0))){
      var genAfter=pl2Properties_().getProperty('PL2_GENERATION')||'0';
      try{cache.remove('pl2_fs:'+genAfter+':'+kh);}catch(_){}
    }
    if(cache&&cacheKey)cache.put(cacheKey,"1",21600);
    return {status:"ok",serverAccounted:true,uniqueAdded:rawAdded,creditDeducted:flushRes.deducted,creditExhausted:(!credAfter.unlimited&&credAfter.remaining<=0),licenceActive:(stAfter.active&&valAfter.active),account:snapAfter};
  }finally{lock.releaseLock();}
}


// Admin Broadcast Notifications & Ads (Synced from Google Sheets 'Notifications' tab)
var NOTIFICATIONS_HEADERS_ = ['ID', 'Title', 'Message', 'Type', 'CTA_Text', 'CTA_URL', 'Image_URL', 'Active', 'Created_At'];

function notificationSheet_() {
  var ss = ss_();
  var names = ['Notifications', 'Announcements', 'Ads', 'Updates'];
  var sh = null;
  for (var i = 0; i < names.length; i++) {
    sh = ss.getSheetByName(names[i]);
    if (sh) break;
  }
  if (!sh) {
    sh = ss.insertSheet('Notifications');
    sh.getRange(1, 1, 1, NOTIFICATIONS_HEADERS_.length).setValues([NOTIFICATIONS_HEADERS_]);
    sh.setFrozenRows(1);
    var nowStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'GMT+05:30', 'yyyy-MM-dd HH:mm');
    sh.appendRow(['N-101', 'Welcome to PocketLeads Pro v10.17!', 'Extract verified Google Maps B2B leads, emails & social media profiles (Facebook, Instagram, LinkedIn, X, YouTube) in one click.', 'update', 'Explore Dashboard', '', '', 'YES', nowStr]);
    sh.appendRow(['N-102', 'Special Pro Upgrade Offer — Extra Credits!', 'Need higher daily extraction limits or multi-PC agency seats? Upgrade your licence today for priority Turbo API routing.', 'offer', 'Get Offer Now', 'mailto:' + SUPPORT_EMAIL + '?subject=PocketLeads%20Special%20Upgrade%20Offer', '', 'YES', nowStr]);
  }
  return sh;
}

function getAdminNotifications_() {
  try {
    var sh = notificationSheet_();
    var data = sh.getDataRange().getValues();
    if (!data || data.length <= 1) return { status: 'ok', notifications: [], count: 0 };
    var headers = (data[0] || []).map(function(h) { return String(h || '').trim().toLowerCase().replace(/[^a-z0-9]/g, ''); });
    var idx = function(candidates, fallback) {
      for (var i = 0; i < candidates.length; i++) {
        var pos = headers.indexOf(candidates[i]);
        if (pos >= 0) return pos;
      }
      return fallback;
    };
    var cId = idx(['id', 'notifid', 'notificationid'], 0);
    var cTitle = idx(['title', 'heading', 'subject', 'headline'], 1);
    var cMsg = idx(['message', 'body', 'description', 'content', 'text'], 2);
    var cType = idx(['type', 'category', 'tag', 'badge'], 3);
    var cCtaText = idx(['ctatext', 'buttontext', 'button', 'actiontext', 'label'], 4);
    var cCtaUrl = idx(['ctaurl', 'url', 'link', 'buttonurl', 'href'], 5);
    var cImg = idx(['imageurl', 'image', 'banner', 'bannerurl', 'photo'], 6);
    var cActive = idx(['active', 'status', 'enabled', 'show'], 7);
    var cDate = idx(['createdat', 'date', 'timestamp', 'time'], 8);

    var list = [];
    for (var r = 1; r < data.length; r++) {
      var row = data[r] || [];
      var title = String(row[cTitle] || '').trim();
      var message = String(row[cMsg] || '').trim();
      if (!title && !message) continue;
      var activeVal = String(row[cActive] == null ? 'yes' : row[cActive]).trim().toLowerCase();
      if (/^(no|false|0|off|inactive|disabled|hidden|archived)$/.test(activeVal)) continue;
      list.push({
        id: String(row[cId] || ('row-' + r)).trim(),
        title: title || 'Announcement',
        message: message,
        type: String(row[cType] || 'update').trim().toLowerCase(),
        ctaText: String(row[cCtaText] || '').trim(),
        ctaUrl: String(row[cCtaUrl] || '').trim(),
        imageUrl: String(row[cImg] || '').trim(),
        createdAt: row[cDate] ? String(row[cDate]) : ''
      });
    }
    list.reverse();
    return { status: 'ok', notifications: list.slice(0, 30), count: list.length };
  } catch (err) {
    return { status: 'ok', notifications: [], count: 0, note: String(err && err.message || err) };
  }
}


// ============================================================================
// Automatic Upstream API Error Logger -> 'API Error Logs' Sheet + API Key Notes
// ============================================================================
var API_ERROR_LOG_HEADERS_ = ['Error ID', 'Timestamp', 'License Key', 'User Name', 'API ID', 'Key Row', 'Provider', 'HTTP Status', 'Error Code', 'API Error Message', 'Query', 'Status'];

function extractUpstreamErrorInfo_(response) {
  var msg = '';
  var code = '';
  if (response && response.data && typeof response.data === 'object') {
    var d = response.data;
    if (d.error && typeof d.error === 'object') {
      msg = String(d.error.message || d.error.description || d.error.status || '');
      code = String(d.error.code || d.error.status || d.code || '');
    } else if (typeof d.error === 'string') {
      msg = d.error;
      code = String(d.code || d.status || '');
    } else {
      msg = String(d.message || d.detail || d.reason || '');
      code = String(d.code || '');
    }
  } else if (response && typeof response.data === 'string') {
    msg = response.data.slice(0, 300);
  }
  if (!msg && response && response.message && !/^Provider HTTP \d+$/i.test(String(response.message))) {
    msg = String(response.message);
  }
  return {
    upstreamMessage: String(msg || '').replace(/[\r\n]+/g, ' ').trim().slice(0, 500),
    upstreamCode: String(code || '').replace(/[\r\n]+/g, ' ').trim().slice(0, 80)
  };
}

function extractPayloadQuery_(payload) {
  if (!payload || typeof payload !== 'object') return '';
  var body = payload.body || payload;
  return String(payload.query || body.q || body.textQuery || body.query || '').trim().slice(0, 200);
}

function logApiErrorToSheet_(info) {
  try {
    if (typeof SpreadsheetApp === 'undefined' || !info) return false;
    var book = ss_();
    if (!book || typeof book.getSheetByName !== 'function') return false;
    var licKey = String(info.licenceKey || '').trim();
    var apiId = String(info.apiId || '').trim();
    var httpStatus = Number(info.httpStatus || 0) || 0;
    var errCode = String(info.errorCode || 'API_ERROR').trim();
    var upCode = String(info.upstreamCode || '').trim();
    var upMsg = String(info.upstreamMessage || info.message || '').trim();
    var queryStr = String(info.query || '').trim();
    var userName = String(info.userName || '').trim();
    var keyRow = Number(info.keyRow || 0) || 0;
    var provider = String(info.provider || '').trim();

    var sh = book.getSheetByName('API Error Logs');
    if (!sh && info.forceCreateSheet && typeof book.insertSheet === 'function') {
      sh = book.insertSheet('API Error Logs');
      if (sh && typeof sh.getRange === 'function') {
        sh.getRange(1, 1, 1, API_ERROR_LOG_HEADERS_.length).setValues([API_ERROR_LOG_HEADERS_]);
        if (typeof sh.setFrozenRows === 'function') sh.setFrozenRows(1);
      }
    }
    if (!sh) return false;

    var now = new Date();
    var tz = (typeof Session !== 'undefined' && Session && typeof Session.getScriptTimeZone === 'function' && Session.getScriptTimeZone()) || 'GMT+05:30';
    var nowStr = (typeof Utilities !== 'undefined' && Utilities && typeof Utilities.formatDate === 'function')
      ? Utilities.formatDate(now, tz, 'yyyy-MM-dd HH:mm:ss')
      : now.toISOString();

    var fullCode = upCode && upCode.toUpperCase() !== errCode.toUpperCase() ? (errCode + ' (' + upCode + ')') : errCode;
    var cleanApiId = (apiId && !/^(PREFLIGHT_ROUTE|ROUTE|Assigned Route|Managed API|scrappa|serper|googlemaps|auto)$/i.test(apiId)) ? apiId : '';

    // Check existing 'Open' rows in 'API Error Logs' so the same user + errorCode NEVER creates duplicate rows!
    try {
      var lastRow = typeof sh.getLastRow === 'function' ? sh.getLastRow() : 0;
      if (lastRow >= 2 && typeof sh.getRange === 'function') {
        var startRow = Math.max(2, lastRow - 30);
        var numRows = lastRow - startRow + 1;
        var existingRows = sh.getRange(startRow, 1, numRows, 12).getValues();
        for (var rIdx = existingRows.length - 1; rIdx >= 0; rIdx--) {
          var ex = existingRows[rIdx] || [];
          var exLic = String(ex[2] || '').trim().toUpperCase();
          var exCode = String(ex[8] || '').trim().toUpperCase();
          var exStatus = String(ex[11] || 'Open').trim().toLowerCase();
          if (exLic === licKey.toUpperCase() && (exCode === fullCode.toUpperCase() || exCode.indexOf(errCode.toUpperCase()) === 0) && exStatus === 'open') {
            var sheetRowNum = startRow + rIdx;
            var bestApiId = cleanApiId || String(ex[4] || '').trim() || apiId || ('Row-' + keyRow);
            var bestQuery = (queryStr && !/^(Preflight|Start Extraction Preflight|Start \/ Extraction)/i.test(queryStr))
              ? queryStr
              : (String(ex[10] || '').trim() || queryStr);
            sh.getRange(sheetRowNum, 2).setValue(nowStr);
            if (bestApiId) sh.getRange(sheetRowNum, 5).setValue(bestApiId);
            if (bestQuery) sh.getRange(sheetRowNum, 11).setValue(bestQuery);
            return true;
          }
        }
      }
    } catch (_upErr) {}

    // Also guard in CacheService for 180s by (licKey + '|' + errCode) against concurrent requests
    var cache = (typeof CacheService !== 'undefined' && CacheService) ? CacheService.getScriptCache() : null;
    var dedupKey = 'pl_errlog2:' + ledgerHash_([licKey.toUpperCase(), errCode.toUpperCase()].join('|'));
    if (cache && cache.get(dedupKey)) return true;
    if (cache) { try { cache.put(dedupKey, '1', 180); } catch (_) {} }

    if (sh && typeof sh.appendRow === 'function') {
      var finalApiId = cleanApiId || apiId || ('Row-' + keyRow);
      var errId = 'ERR-' + (finalApiId || 'API') + '-' + (httpStatus || errCode) + '-' + String(now.getTime()).slice(-5);
      sh.appendRow([
        errId,
        nowStr,
        licKey,
        userName,
        finalApiId,
        keyRow || '',
        provider,
        httpStatus || '',
        fullCode,
        upMsg || ('Provider request failed (' + fullCode + ')'),
        queryStr || 'Extraction Task',
        'Open'
      ]);
    }

    // Also update 'API Key Management' Notes & Last Licence Key on that row so admin sees it right next to the API key
    var keySh = book.getSheetByName('API Key Management');
    if (keySh && keyRow >= 2 && keyRow <= keySh.getLastRow()) {
      var kHeaders = keySh.getRange(1, 1, 1, Math.max(12, keySh.getLastColumn())).getValues()[0] || [];
      var lastLicCol = 0, notesCol = 0;
      for (var c = 0; c < kHeaders.length; c++) {
        var hName = String(kHeaders[c] || '').trim().toLowerCase();
        if (hName === 'last licence key' || hName === 'last license key') lastLicCol = c + 1;
        if (hName === 'notes' || hName === 'note' || hName === 'error') notesCol = c + 1;
      }
      if (lastLicCol > 0 && licKey) keySh.getRange(keyRow, lastLicCol).setValue(licKey);
      if (notesCol > 0) {
        var noteText = '[HTTP ' + (httpStatus || '?') + (upCode ? ' ' + upCode : '') + '] ' + (upMsg || errCode) + ' | Licence: ' + licKey + (userName ? ' (' + userName + ')' : '') + ' @ ' + nowStr;
        keySh.getRange(keyRow, notesCol).setValue(noteText.slice(0, 300));
      }
    }
    return true;
  } catch (_) {
    return false;
  }
}

function handleClientApiErrorReport_(params, key, valid) {
  var userName = '';
  try {
    if (valid && valid.sheet) {
      var u = pl2User_(key);
      if (u) userName = String(pl2Value_(u, 'User Name') || '');
    }
  } catch (_) {}
  var logged = logApiErrorToSheet_({
    forceCreateSheet: true,
    licenceKey: key,
    userName: userName || String(params.userName || params.user || ''),
    apiId: String(params.apiId || ''),
    keyRow: Number(params.keyRow || 0),
    provider: String(params.provider || ''),
    httpStatus: Number(params.httpStatus || 0),
    errorCode: String(params.errorCode || 'PROVIDER_ERROR'),
    upstreamCode: String(params.upstreamCode || ''),
    upstreamMessage: String(params.upstreamError || params.message || ''),
    query: String(params.query || '')
  });
  return { status: 'ok', logged: logged };
}
