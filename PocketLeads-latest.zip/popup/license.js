// This script powers the licence activation page.  It handles format
// validation, communicates with a backend Apps Script and stores the
// licence state in chrome.storage.local.  When a licence is active the
// UI displays licence/plan status without exposing active-device counts. Device limits are enforced server-side.

(function() {
    // IMPORTANT: Replace the placeholder below with your deployed Apps
    // Script URL.  The Apps Script should implement a doPost handler
    // that accepts JSON of the form { action: 'activate' | 'release',
    // key: string, ip: string } and returns JSON with a status field.
    const APPS_SCRIPT_URL = PocketLeadsConfig.endpoint;
    const SUPPORT_EMAIL = PocketLeadsConfig.supportEmail;

    /**
     * Retrieve the stored licence information.  The callback receives
     * undefined if no licence is stored.
     *
     * @param {function(Object|undefined)} callback
     */
    function getStoredLicence(callback) {
        try {
            chrome.storage.local.get('license', result => {
                callback(result.license);
            });
        } catch (err) {
            // Should not happen in extension context, but log just in case
            console.error('Error reading licence from storage', err);
            callback(undefined);
        }
    }

    /**
     * Save the given licence object to storage.  If licence is null or
     * undefined the entry is removed.
     *
     * @param {Object|null|undefined} licence
     */
    function setStoredLicence(licence) {
        if (!licence) {
            chrome.storage.local.remove(['license','pocketleadsAccount','pocketleadsPreparedRoute','pocketleadsPreflightState']);
        } else {
            chrome.storage.local.set({ license: licence });
        }
    }

    /**
     * Fetch the public IPv4 address of the current user.  This uses
     * ipify.org to obtain an IP in JSON format.  On error the promise
     * rejects.
     *
     * @returns {Promise<string>}
     */
    async function getInstallationId() {
        try {
            const permId = String(localStorage.getItem('pl_permanent_device_id_v1') || '').trim();
            if (permId && permId.length >= 10) return permId;
        } catch (_) {}
        const saved = (await PocketLeadsAccount.read()).license;
        if (saved && saved.installationId) {
            try { localStorage.setItem('pl_permanent_device_id_v1', saved.installationId); } catch (_) {}
            return saved.installationId;
        }
        try {
            if (window.PocketLeadsDeviceIdentity && typeof window.PocketLeadsDeviceIdentity.get === 'function') {
                const identity = await Promise.race([
                    window.PocketLeadsDeviceIdentity.get(),
                    new Promise(resolve => setTimeout(() => resolve(null), 2000))
                ]);
                const id = String(identity && identity.id || '').trim();
                if (id) {
                    try { localStorage.setItem('pl_permanent_device_id_v1', id); } catch (_) {}
                    return id;
                }
            }
        } catch (_) {}
        const fallback = 'pl_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2);
        try { localStorage.setItem('pl_permanent_device_id_v1', fallback); } catch (_) {}
        return fallback;
    }


    // Legacy-only helper: old v81 activations were registered by public IP.
    // It is used only to release an old stored licence that has no installationId.
    async function fetchPublicIP() {
        const resp = await fetch('https://api.ipify.org?format=json');
        const json = await resp.json();
        if (!json || !json.ip) throw new Error('Invalid IP response');
        return json.ip;
    }

    /**
     * Send an activation or release request to the backend.  It posts a
     * JSON payload and expects a JSON response with at least a status
     * field.  In case of CORS or network failures the promise rejects.
     *
     * @param {string} action 'activate' or 'release'
     * @param {string} key
     * @param {string} ip
     * @returns {Promise<Object>}
     */
    async function callBackend(action, key, deviceId, legacyIp, legacyDeviceId) {
        return PocketLeadsAccount.request(action, key, deviceId, legacyIp, legacyDeviceId);
    }

    /**
     * Initialize the licence page.  This wires up click handlers and
     * displays either the activation form or the logged‑in state based
     * on stored licence information.
     */
    function init() {
        const loginSection = document.getElementById('loginSection');
        const loggedSection = document.getElementById('loggedSection');
        const submitButton = document.getElementById('submitButton');
        const licenseInput = document.getElementById('licenseKeyInput');
        const errorEl = document.getElementById('error');
        const spinner = document.getElementById('spinner');
        const logoutButton = document.getElementById('logoutButton');
        const deviceCountEl = document.getElementById('deviceCount');
        const licensePlanMetaEl = document.getElementById('licensePlanMeta');

        // Helper to show the login section
        function showLogin() {
            loginSection.style.display = 'block';
            loggedSection.style.display = 'none';
            const ps = document.getElementById('phoneStep');
            const os = document.getElementById('otpStep');
            if (ps) ps.style.display = 'block';
            if (os) os.style.display = 'none';
            const oi = document.getElementById('otpInput');
            if (oi) oi.value = '';
        }
        // Helper to show the logged section
        function formatCredit(value) {
            if (value === null || typeof value === 'undefined' || value === '') return 'Unavailable';
            if (String(value).toLowerCase() === 'unlimited') return 'Unlimited';
            const n = parseInt(value, 10);
            return Number.isFinite(n) ? n.toLocaleString() : String(value);
        }
        function showLogged(count, meta) {
            loginSection.style.display = 'none';
            loggedSection.style.display = 'block';
            if (deviceCountEl) deviceCountEl.textContent = count != null ? count : '0';
            meta = meta || {};
            if (licensePlanMetaEl) {
                const expiry = meta.expiryDate ? `Valid until: ${meta.expiryDate}` : 'Validity: ' + (meta.validityLabel || 'Server managed');
                const available = `Available Credit: ${formatCredit(meta.availableCredit)}`;
                const purchased = `Purchased Credit: ${formatCredit(meta.purchasedCredit)}`;
                licensePlanMetaEl.textContent = `${expiry} • ${available} • ${purchased}`;
            }
        }

        // Restore immediately and let the shared worker refresh in the background.
        getStoredLicence(lic=>{
            if(lic&&lic.active){showLogged(lic.devices,lic);PocketLeadsAccount.refresh({maxAgeMs:30000}).catch(()=>{});}
            else showLogin();
        });
        chrome.storage.onChanged.addListener((changes,area)=>{
            if(area!=='local'||!changes.license)return;
            const lic=changes.license.newValue;
            if(lic&&lic.active)showLogged(lic.devices,lic);else showLogin();
        });

        // Phone Number + 6-Digit OTP Flow (with Android Google SMS User Consent API)
        const phoneStep = document.getElementById('phoneStep');
        const otpStep = document.getElementById('otpStep');
        const legacyKeyStep = document.getElementById('legacyKeyStep');
        const phoneInput = document.getElementById('phoneInput');
        const otpInput = document.getElementById('otpInput');
        const sendOtpButton = document.getElementById('sendOtpButton');
        const verifyOtpButton = document.getElementById('verifyOtpButton');
        const resendOtpButton = document.getElementById('resendOtpButton');
        const changePhoneButton = document.getElementById('changePhoneButton');
        const toggleLegacyKeyButton = document.getElementById('toggleLegacyKeyButton');
        const backToPhoneButton = document.getElementById('backToPhoneButton');
        const otpSentInfo = document.getElementById('otpSentInfo');

        let popupOtpSession = { phone10: '', otpToken: '', resendTimer: null, resendLeft: 0 };

        function stopAndroidSmsConsentPopup() {
            try {
                if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.stopSmsUserConsent === 'function') {
                    window.AndroidChromeBridge.stopSmsUserConsent();
                }
            } catch (_) {}
        }
        function handleAutoFilledOtpPopup(otpCode) {
            const clean = String(otpCode || '').replace(/\D+/g, '').slice(0, 6);
            if (clean.length !== 6 || !otpStep || otpStep.style.display === 'none') return;
            if (otpInput) otpInput.value = clean;
            if (verifyOtpButton) verifyOtpButton.click();
        }
        function startAndroidSmsConsentPopup() {
            try {
                if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.startSmsUserConsentAsync === 'function') {
                    const cbId = 'pl_sms_otp_popup_' + Date.now();
                    window.__plNativeCallbacks = window.__plNativeCallbacks || {};
                    window.__plNativeCallbacks[cbId] = function(rawJson) {
                        try {
                            const res = typeof rawJson === 'string' ? JSON.parse(rawJson) : rawJson;
                            if (res && res.ok && res.otp) handleAutoFilledOtpPopup(String(res.otp));
                        } catch (_) {}
                    };
                    window.AndroidChromeBridge.startSmsUserConsentAsync(cbId);
                }
            } catch (_) {}
        }
        window.__onAndroidSmsOtpReceived = function(otpCode) { handleAutoFilledOtpPopup(otpCode); };

        function startPopupResendCountdown(seconds) {
            if (popupOtpSession.resendTimer) clearInterval(popupOtpSession.resendTimer);
            popupOtpSession.resendLeft = Math.max(1, Number(seconds) || 30);
            if (resendOtpButton) {
                resendOtpButton.disabled = true;
                resendOtpButton.textContent = 'Resend in ' + popupOtpSession.resendLeft + 's';
            }
            popupOtpSession.resendTimer = setInterval(() => {
                popupOtpSession.resendLeft--;
                if (popupOtpSession.resendLeft <= 0) {
                    clearInterval(popupOtpSession.resendTimer);
                    popupOtpSession.resendTimer = null;
                    if (resendOtpButton) {
                        resendOtpButton.disabled = false;
                        resendOtpButton.textContent = 'Resend OTP';
                    }
                } else if (resendOtpButton) {
                    resendOtpButton.disabled = true;
                    resendOtpButton.textContent = 'Resend in ' + popupOtpSession.resendLeft + 's';
                }
            }, 1000);
        }

        if (phoneInput) {
            phoneInput.addEventListener('input', () => {
                phoneInput.value = String(phoneInput.value || '').replace(/\D+/g, '').slice(0, 10);
            });
            phoneInput.addEventListener('keydown', e => {
                if (e.key === 'Enter' && sendOtpButton) { e.preventDefault(); sendOtpButton.click(); }
            });
        }
        if (otpInput) {
            otpInput.addEventListener('input', () => {
                otpInput.value = String(otpInput.value || '').replace(/\D+/g, '').slice(0, 6);
            });
            otpInput.addEventListener('keydown', e => {
                if (e.key === 'Enter' && verifyOtpButton) { e.preventDefault(); verifyOtpButton.click(); }
            });
        }
        if (toggleLegacyKeyButton) {
            toggleLegacyKeyButton.addEventListener('click', () => {
                stopAndroidSmsConsentPopup();
                errorEl.style.display = 'none';
                if (phoneStep) phoneStep.style.display = 'none';
                if (otpStep) otpStep.style.display = 'none';
                if (legacyKeyStep) legacyKeyStep.style.display = 'block';
                toggleLegacyKeyButton.style.display = 'none';
            });
        }
        if (backToPhoneButton) {
            backToPhoneButton.addEventListener('click', () => {
                errorEl.style.display = 'none';
                if (legacyKeyStep) legacyKeyStep.style.display = 'none';
                if (otpStep) otpStep.style.display = 'none';
                if (phoneStep) phoneStep.style.display = 'block';
                if (toggleLegacyKeyButton) toggleLegacyKeyButton.style.display = 'inline-block';
            });
        }
        if (changePhoneButton) {
            changePhoneButton.addEventListener('click', () => {
                stopAndroidSmsConsentPopup();
                if (popupOtpSession.resendTimer) { clearInterval(popupOtpSession.resendTimer); popupOtpSession.resendTimer = null; }
                popupOtpSession.otpToken = '';
                errorEl.style.display = 'none';
                if (otpInput) otpInput.value = '';
                if (otpStep) otpStep.style.display = 'none';
                if (phoneStep) phoneStep.style.display = 'block';
                if (toggleLegacyKeyButton) toggleLegacyKeyButton.style.display = 'inline-block';
                if (phoneInput) phoneInput.focus();
            });
        }

        async function triggerSendOtpPopup() {
            errorEl.style.display = 'none';
            const phone10 = String((phoneInput && phoneInput.value) || '').replace(/\D+/g, '').slice(-10);
            if (phoneInput) phoneInput.value = phone10;
            if (!/^[6-9]\d{9}$/.test(phone10)) {
                errorEl.textContent = 'Please enter a valid 10-digit Indian mobile number.';
                errorEl.style.display = 'block';
                return;
            }
            spinner.textContent = 'Checking number & sending OTP...';
            spinner.style.display = 'block';
            if (sendOtpButton) sendOtpButton.disabled = true;
            if (resendOtpButton) resendOtpButton.disabled = true;
            if (phoneInput) phoneInput.disabled = true;
            try {
                const installationId = await getInstallationId();
                const response = await PocketLeadsAccount.sendOtp(phone10, installationId);
                if (!response || !response.status) {
                    errorEl.textContent = 'Network error. Please check connection and try again.';
                    errorEl.style.display = 'block';
                } else if (response.status === 'ok' && response.otpSent) {
                    popupOtpSession.phone10 = phone10;
                    popupOtpSession.otpToken = String(response.otpToken || '');
                    if (otpSentInfo) otpSentInfo.textContent = 'OTP sent to +91 ' + phone10 + ' • Valid for 5 minutes';
                    if (phoneStep) phoneStep.style.display = 'none';
                    if (legacyKeyStep) legacyKeyStep.style.display = 'none';
                    if (toggleLegacyKeyButton) toggleLegacyKeyButton.style.display = 'none';
                    if (otpStep) otpStep.style.display = 'block';
                    if (otpInput) { otpInput.value = ''; otpInput.focus(); }
                    startPopupResendCountdown(response.resendAfterSec || 30);
                    startAndroidSmsConsentPopup();
                } else if (response.status === 'not_registered' || response.reason === 'phone_not_registered') {
                    errorEl.textContent = 'This phone number is not registered. Please contact admin.';
                    errorEl.style.display = 'block';
                } else if (response.status === 'inactive') {
                    errorEl.textContent = 'This account is inactive. Please contact admin.';
                    errorEl.style.display = 'block';
                } else if (response.status === 'expired') {
                    errorEl.textContent = `This licence expired${response.expiryDate ? ' on ' + response.expiryDate : ''}. Contact ${response.supportEmail || SUPPORT_EMAIL} to renew.`;
                    errorEl.style.display = 'block';
                } else {
                    errorEl.textContent = response.message || 'Unable to send OTP right now. Please try again.';
                    errorEl.style.display = 'block';
                }
            } catch (err) {
                errorEl.textContent = (err && err.message) || 'Network error while sending OTP.';
                errorEl.style.display = 'block';
            } finally {
                spinner.style.display = 'none';
                if (sendOtpButton) sendOtpButton.disabled = false;
                if (phoneInput) phoneInput.disabled = false;
                if (resendOtpButton && !popupOtpSession.resendTimer) resendOtpButton.disabled = false;
            }
        }

        if (sendOtpButton) sendOtpButton.addEventListener('click', triggerSendOtpPopup);
        if (resendOtpButton) resendOtpButton.addEventListener('click', triggerSendOtpPopup);

        if (verifyOtpButton) {
            verifyOtpButton.addEventListener('click', async () => {
                errorEl.style.display = 'none';
                const phone10 = popupOtpSession.phone10 || String((phoneInput && phoneInput.value) || '').replace(/\D+/g, '').slice(-10);
                const otpCode = String((otpInput && otpInput.value) || '').replace(/\D+/g, '').trim();
                if (otpInput) otpInput.value = otpCode;
                if (!/^\d{6}$/.test(otpCode)) {
                    errorEl.textContent = 'Please enter the 6-digit OTP.';
                    errorEl.style.display = 'block';
                    return;
                }
                spinner.textContent = 'Verifying OTP & activating account...';
                spinner.style.display = 'block';
                verifyOtpButton.disabled = true;
                if (otpInput) otpInput.disabled = true;
                try {
                    const installationId = await getInstallationId();
                    const previousStored = await new Promise(resolve => getStoredLicence(resolve));
                    const previousDeviceId = previousStored && previousStored.installationId ? String(previousStored.installationId) : '';
                    const response = await PocketLeadsAccount.verifyOtp(phone10, otpCode, popupOtpSession.otpToken, installationId, previousDeviceId);
                    if (!response || !response.status) {
                        errorEl.textContent = 'Network error. Please check connection and try again.';
                        errorEl.style.display = 'block';
                    } else if (response.status === 'ok') {
                        stopAndroidSmsConsentPopup();
                        if (popupOtpSession.resendTimer) { clearInterval(popupOtpSession.resendTimer); popupOtpSession.resendTimer = null; }
                        const count = response.count != null ? response.count : 1;
                        const stored = {
                            key: response.key || response.licenceKey || '',
                            phone: phone10,
                            active: true,
                            devices: count,
                            installationId: installationId,
                            identityVersion: 2,
                            expiryDate: response.expiryDate || '',
                            googleMapsCredit: response.googleMapsCredit != null ? response.googleMapsCredit : null,
                            structuredCredit: response.structuredCredit != null ? response.structuredCredit : null,
                            supportEmail: response.supportEmail || SUPPORT_EMAIL
                        };
                        Object.assign(stored, (await PocketLeadsAccount.read()).license);
                        try { chrome.runtime.sendMessage({ action: 'pocketleads_warm_backend', reason: 'licence_activation', force: false }, function(){ void chrome.runtime.lastError; }); } catch (e) {}
                        showLogged(count, stored);
                        window.location.href = chrome.runtime.getURL('views/index.html');
                    } else if (response.status === 'expired') {
                        errorEl.textContent = `This licence expired${response.expiryDate ? ' on ' + response.expiryDate : ''}. Contact ${response.supportEmail || SUPPORT_EMAIL} to renew.`;
                        errorEl.style.display = 'block';
                    } else if (response.status === 'inactive') {
                        errorEl.textContent = 'This licence is inactive. Please contact admin.';
                        errorEl.style.display = 'block';
                    } else if (response.status === 'denied') {
                        const reason = String(response.reason || '');
                        errorEl.textContent = /device|installation/i.test(reason)
                            ? 'This device is not authorized for this licence. Activate it if fewer than 3 devices are currently active.'
                            : 'This licence already has 3 active devices. Release one device before activating a new device.';
                        errorEl.style.display = 'block';
                    } else {
                        errorEl.textContent = response.message || 'Invalid or expired OTP. Please try again.';
                        errorEl.style.display = 'block';
                    }
                } catch (err) {
                    errorEl.textContent = (err && err.message) || 'Network error while verifying OTP.';
                    errorEl.style.display = 'block';
                } finally {
                    spinner.style.display = 'none';
                    verifyOtpButton.disabled = false;
                    if (otpInput) otpInput.disabled = false;
                }
            });
        }

        if (submitButton) submitButton.addEventListener('click', async () => {
            errorEl.style.display = 'none';
            const key = String(licenseInput.value || '')
                .replace(/[\u200B-\u200D\uFEFF\u00A0\s]+/g, '')
                .replace(/[\u2010-\u2015\u2212]/g, '-')
                .replace(/^[`'"<>{}\[\]()]+|[`'"<>{}\[\](),;]+$/g, '')
                .toUpperCase();
            // Enforce uppercase formatting in the input box
            licenseInput.value = key;
            const formatRegex = /^[A-Z0-9]{4,8}-[A-Z0-9]{4,8}$/;
            if (!formatRegex.test(key)) {
                errorEl.textContent = 'Invalid license key format.';
                errorEl.style.display = 'block';
                return;
            }
            // Show spinner and disable inputs while we process
            spinner.style.display = 'block';
            submitButton.disabled = true;
            licenseInput.disabled = true;
            try {
                const installationId = await getInstallationId();
                // v83 preflight: v82 requires the secure proxy backend. Old v81
                // deployments otherwise return missing_key_or_ip as status=invalid,
                // which misleadingly looked like a bad licence key.
                // Mobile fix: do not perform a blocking ping before activation.
                // Apps Script cold start on mobile can make this look like a stuck login.
                // The activate endpoint is the single source of truth.
                const previousStored = await new Promise(resolve => getStoredLicence(resolve));
                const previousDeviceId = previousStored && String(previousStored.key || '').toUpperCase() === key ? String(previousStored.installationId || '') : '';
                let legacyIp = '';
                
                const response = await callBackend('activate', key, installationId, legacyIp, previousDeviceId);
                spinner.style.display = 'none';
                submitButton.disabled = false;
                licenseInput.disabled = false;
                if (!response || !response.status) {
                    errorEl.textContent = 'Network error. Please check connection and try again.';
                    errorEl.style.display = 'block';
                    return;
                }
                if (response.status === 'ok') {
                    const count = response.count != null ? response.count : 1;
                    const stored = {
                        key: key, active: true, devices: count, installationId: installationId, identityVersion: 2,
                        expiryDate: response.expiryDate || '',
                        googleMapsCredit: response.googleMapsCredit != null ? response.googleMapsCredit : null,
                        structuredCredit: response.structuredCredit != null ? response.structuredCredit : null,
                        supportEmail: response.supportEmail || SUPPORT_EMAIL
                    };
                    // Shared worker has persisted the complete account before returning.
                    Object.assign(stored, (await PocketLeadsAccount.read()).license);
                    try { chrome.runtime.sendMessage({ action: 'pocketleads_warm_backend', reason: 'licence_activation', force: false }, function(){ void chrome.runtime.lastError; }); } catch (e) {}
                    showLogged(count, stored);
                    window.location.href=chrome.runtime.getURL('views/index.html');
                } else if (response.status === 'expired') {
                    errorEl.textContent = `This licence expired${response.expiryDate ? ' on ' + response.expiryDate : ''}. Contact ${response.supportEmail || SUPPORT_EMAIL} to renew.`;
                    errorEl.style.display = 'block';
                } else if (response.status === 'inactive') {
                    errorEl.textContent = 'This licence is inactive. Please contact admin.';
                    errorEl.style.display = 'block';
                } else if (response.status === 'invalid') {
                    const reason = String(response.reason || '');
                    if (/missing_key_or_(?:ip|device)|old_backend|backend/i.test(reason)) {
                        errorEl.textContent = 'Backend version mismatch. Deploy the included apps_script_code.js v24+ and update the existing web-app deployment.';
                    } else if (reason === 'licence_not_found') {
                        errorEl.textContent = 'License key was not found in the configured licence sheet. Check the key and Apps Script spreadsheet deployment.';
                    } else {
                        errorEl.textContent = 'License validation failed' + (reason ? ': ' + reason : '.');
                    }
                    errorEl.style.display = 'block';
                } else if (response.status === 'rate_limited') {
                    const waitS = Number(response.retryAfterSec || response.rateLimitWaitSec || 60);
                    errorEl.textContent = 'Too many login attempts. Please wait ' + waitS + ' seconds before trying again.';
                    errorEl.style.display = 'block';
                } else if (response.status === 'denied') {
                    const reason = String(response.reason || '');
                    errorEl.textContent = /device|installation/i.test(reason)
                        ? 'This device is not authorized for this licence. Activate it if fewer than 3 devices are currently active.'
                        : 'This licence already has 3 active devices. Release one device before activating a new device.';
                    errorEl.style.display = 'block';
                } else {
                    const detailMsg = String(response.message || response.error || response.reason || '').trim();
                    errorEl.textContent = detailMsg ? ('Server message: ' + detailMsg) : 'Unable to verify licence right now. Please check Admin Sheet configuration and retry.';
                    errorEl.style.display = 'block';
                    try {
                        if (typeof window.reportPocketLeadsErrorToAdminSheet === 'function') {
                            window.reportPocketLeadsErrorToAdminSheet({
                                licenceKey: key,
                                actionName: 'popup_activate',
                                errorCode: 'LOGIN_STATUS_' + String(response.status || 'UNKNOWN').toUpperCase(),
                                upstreamError: detailMsg || JSON.stringify(response)
                            });
                        }
                    } catch (_) {}
                }
            } catch (err) {
                console.error('Error during licence activation', err);
                spinner.style.display = 'none';
                submitButton.disabled = false;
                licenseInput.disabled = false;
                errorEl.textContent = err && err.message ? err.message : 'Network error. Please check connection and try again.';
                errorEl.style.display = 'block';
            }
        });

        // Release licence on logout click (1-click instant)
        logoutButton.addEventListener('click', async () => {
            errorEl.style.display = 'none';
            spinner.style.display = 'block';
            logoutButton.disabled = true;
            try {
                const lic = await new Promise(resolve=>getStoredLicence(resolve));
                {
                    if (!lic || !lic.key) {
                        spinner.style.display = 'none';
                        logoutButton.disabled = false;
                        errorEl.textContent = 'No licence active.';
                        errorEl.style.display = 'block';
                        return;
                    }
                    let installationId = String(lic.installationId || '');
                    let legacyIp = '';
                    if (!installationId) legacyIp = await fetchPublicIP();
                    const response = await callBackend('release', lic.key, installationId, legacyIp);
                    spinner.style.display = 'none';
                    logoutButton.disabled = false;
                    if (response && response.status === 'ok') {
                        // Remove local licence and show login form
                        setStoredLicence(null);
                        showLogin();
                    } else {
                        errorEl.textContent = 'Error releasing licence.';
                        errorEl.style.display = 'block';
                    }
                }
            } catch (err) {
                console.error('Error during licence release', err);
                spinner.style.display = 'none';
                logoutButton.disabled = false;
                errorEl.textContent = 'Network error. Please check connection and try again.';
                errorEl.style.display = 'block';
            }
        });
    }

    // Initialize after DOM is ready
    document.addEventListener('DOMContentLoaded', init);
})();
