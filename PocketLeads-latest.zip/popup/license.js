// This script powers the licence activation page.  It handles format
// validation, communicates with a backend Apps Script and stores the
// licence state in chrome.storage.local.  When a licence is active the
// UI displays licence/plan status without exposing active-device counts. Device limits are enforced server-side.

(function() {
    // IMPORTANT: Replace the placeholder below with your deployed Apps
    // Script URL.  The Apps Script should implement a doPost handler
    // that accepts JSON of the form { action: 'activate' | 'release',
    // key: string, ip: string } and returns JSON with a status field.
    const APPS_SCRIPT_URL = PocketLeadsConfig.endpoint;
    const SUPPORT_EMAIL = PocketLeadsConfig.supportEmail;

    /**
     * Retrieve the stored licence information.  The callback receives
     * undefined if no licence is stored.
     *
     * @param {function(Object|undefined)} callback
     */
    function getStoredLicence(callback) {
        try {
            chrome.storage.local.get('license', result => {
                callback(result.license);
            });
        } catch (err) {
            // Should not happen in extension context, but log just in case
            console.error('Error reading licence from storage', err);
            callback(undefined);
        }
    }

    /**
     * Save the given licence object to storage.  If licence is null or
     * undefined the entry is removed.
     *
     * @param {Object|null|undefined} licence
     */
    function setStoredLicence(licence) {
        if (!licence) {
            chrome.storage.local.remove(['license','pocketleadsAccount','pocketleadsPreparedRoute','pocketleadsPreflightState']);
        } else {
            chrome.storage.local.set({ license: licence });
        }
    }

    /**
     * Fetch the public IPv4 address of the current user.  This uses
     * ipify.org to obtain an IP in JSON format.  On error the promise
     * rejects.
     *
     * @returns {Promise<string>}
     */
    async function getInstallationId() {
        const saved = (await PocketLeadsAccount.read()).license;
        if (saved && saved.installationId) return saved.installationId;
        if (!window.PocketLeadsDeviceIdentity || typeof window.PocketLeadsDeviceIdentity.get !== 'function') {
            throw new Error('Device identity module unavailable');
        }
        const identity = await Promise.race([
            window.PocketLeadsDeviceIdentity.get(),
            new Promise((_, reject) => setTimeout(() => reject(new Error('Device identity timeout')), 4000))
        ]);
        const id = String(identity && identity.id || '').trim();
        if (!id) throw new Error('Device identity unavailable');
        return id;
    }


    // Legacy-only helper: old v81 activations were registered by public IP.
    // It is used only to release an old stored licence that has no installationId.
    async function fetchPublicIP() {
        const resp = await fetch('https://api.ipify.org?format=json');
        const json = await resp.json();
        if (!json || !json.ip) throw new Error('Invalid IP response');
        return json.ip;
    }

    /**
     * Send an activation or release request to the backend.  It posts a
     * JSON payload and expects a JSON response with at least a status
     * field.  In case of CORS or network failures the promise rejects.
     *
     * @param {string} action 'activate' or 'release'
     * @param {string} key
     * @param {string} ip
     * @returns {Promise<Object>}
     */
    async function callBackend(action, key, deviceId, legacyIp, legacyDeviceId) {
        return PocketLeadsAccount.request(action, key, deviceId, legacyIp, legacyDeviceId);
    }

    /**
     * Initialize the licence page.  This wires up click handlers and
     * displays either the activation form or the logged‑in state based
     * on stored licence information.
     */
    function init() {
        const loginSection = document.getElementById('loginSection');
        const loggedSection = document.getElementById('loggedSection');
        const submitButton = document.getElementById('submitButton');
        const licenseInput = document.getElementById('licenseKeyInput');
        const errorEl = document.getElementById('error');
        const spinner = document.getElementById('spinner');
        const logoutButton = document.getElementById('logoutButton');
        const deviceCountEl = document.getElementById('deviceCount');
        const licensePlanMetaEl = document.getElementById('licensePlanMeta');

        // Helper to show the login section
        function showLogin() {
            loginSection.style.display = 'block';
            loggedSection.style.display = 'none';
        }
        // Helper to show the logged section
        function formatCredit(value) {
            if (value === null || typeof value === 'undefined' || value === '') return 'Unavailable';
            if (String(value).toLowerCase() === 'unlimited') return 'Unlimited';
            const n = parseInt(value, 10);
            return Number.isFinite(n) ? n.toLocaleString() : String(value);
        }
        function showLogged(count, meta) {
            loginSection.style.display = 'none';
            loggedSection.style.display = 'block';
            if (deviceCountEl) deviceCountEl.textContent = count != null ? count : '0';
            meta = meta || {};
            if (licensePlanMetaEl) {
                const expiry = meta.expiryDate ? `Valid until: ${meta.expiryDate}` : 'Validity: ' + (meta.validityLabel || 'Server managed');
                const available = `Available Credit: ${formatCredit(meta.availableCredit)}`;
                const purchased = `Purchased Credit: ${formatCredit(meta.purchasedCredit)}`;
                licensePlanMetaEl.textContent = `${expiry} • ${available} • ${purchased}`;
            }
        }

        // Restore immediately and let the shared worker refresh in the background.
        getStoredLicence(lic=>{
            if(lic&&lic.active){showLogged(lic.devices,lic);PocketLeadsAccount.refresh({maxAgeMs:30000}).catch(()=>{});}
            else showLogin();
        });
        chrome.storage.onChanged.addListener((changes,area)=>{
            if(area!=='local'||!changes.license)return;
            const lic=changes.license.newValue;
            if(lic&&lic.active)showLogged(lic.devices,lic);else showLogin();
        });

        // Validate format and call backend on submit
        submitButton.addEventListener('click', async () => {
            errorEl.style.display = 'none';
            const key = (licenseInput.value || '').trim().toUpperCase();
            // Enforce uppercase formatting in the input box
            licenseInput.value = key;
            const formatRegex = /^[A-Z]{5}-\d{5}$/;
            if (!formatRegex.test(key)) {
                errorEl.textContent = 'Invalid license key format.';
                errorEl.style.display = 'block';
                return;
            }
            // Show spinner and disable inputs while we process
            spinner.style.display = 'block';
            submitButton.disabled = true;
            licenseInput.disabled = true;
            try {
                const installationId = await getInstallationId();
                // v83 preflight: v82 requires the secure proxy backend. Old v81
                // deployments otherwise return missing_key_or_ip as status=invalid,
                // which misleadingly looked like a bad licence key.
                // Mobile fix: do not perform a blocking ping before activation.
                // Apps Script cold start on mobile can make this look like a stuck login.
                // The activate endpoint is the single source of truth.
                const previousStored = await new Promise(resolve => getStoredLicence(resolve));
                const previousDeviceId = previousStored && String(previousStored.key || '').toUpperCase() === key ? String(previousStored.installationId || '') : '';
                let legacyIp = '';
                
                const response = await callBackend('activate', key, installationId, legacyIp, previousDeviceId);
                spinner.style.display = 'none';
                submitButton.disabled = false;
                licenseInput.disabled = false;
                if (!response || !response.status) {
                    errorEl.textContent = 'Network error. Please check connection and try again.';
                    errorEl.style.display = 'block';
                    return;
                }
                if (response.status === 'ok') {
                    const count = response.count != null ? response.count : 1;
                    const stored = {
                        key: key, active: true, devices: count, installationId: installationId, identityVersion: 2,
                        expiryDate: response.expiryDate || '',
                        googleMapsCredit: response.googleMapsCredit != null ? response.googleMapsCredit : null,
                        structuredCredit: response.structuredCredit != null ? response.structuredCredit : null,
                        supportEmail: response.supportEmail || SUPPORT_EMAIL
                    };
                    // Shared worker has persisted the complete account before returning.
                    Object.assign(stored, (await PocketLeadsAccount.read()).license);
                    try { chrome.runtime.sendMessage({ action: 'pocketleads_warm_backend', reason: 'licence_activation', force: false }, function(){ void chrome.runtime.lastError; }); } catch (e) {}
                    showLogged(count, stored);
                    window.location.href=chrome.runtime.getURL('views/index.html');
                } else if (response.status === 'expired') {
                    errorEl.textContent = `This licence expired${response.expiryDate ? ' on ' + response.expiryDate : ''}. Contact ${response.supportEmail || SUPPORT_EMAIL} to renew.`;
                    errorEl.style.display = 'block';
                } else if (response.status === 'inactive') {
                    errorEl.textContent = 'This licence is inactive. Please contact admin.';
                    errorEl.style.display = 'block';
                } else if (response.status === 'invalid') {
                    const reason = String(response.reason || '');
                    if (/missing_key_or_(?:ip|device)|old_backend|backend/i.test(reason)) {
                        errorEl.textContent = 'Backend version mismatch. Deploy the included apps_script_code.js v24+ and update the existing web-app deployment.';
                    } else if (reason === 'licence_not_found') {
                        errorEl.textContent = 'License key was not found in the configured licence sheet. Check the key and Apps Script spreadsheet deployment.';
                    } else {
                        errorEl.textContent = 'License validation failed' + (reason ? ': ' + reason : '.');
                    }
                    errorEl.style.display = 'block';
                } else if (response.status === 'denied') {
                    const reason = String(response.reason || '');
                    errorEl.textContent = /device|installation/i.test(reason)
                        ? 'This device is not authorized for this licence. Activate it if fewer than 3 devices are currently active.'
                        : 'This licence already has 3 active devices. Release one device before activating a new device.';
                    errorEl.style.display = 'block';
                } else {
                    errorEl.textContent = 'Unknown response from server.';
                    errorEl.style.display = 'block';
                }
            } catch (err) {
                console.error('Error during licence activation', err);
                spinner.style.display = 'none';
                submitButton.disabled = false;
                licenseInput.disabled = false;
                errorEl.textContent = err && err.message ? err.message : 'Network error. Please check connection and try again.';
                errorEl.style.display = 'block';
            }
        });

        // Release licence on logout click
        logoutButton.addEventListener('click', async () => {
            if (!window.confirm('Log out and release this licence from this device?')) return;
            errorEl.style.display = 'none';
            spinner.style.display = 'block';
            logoutButton.disabled = true;
            try {
                const lic = await new Promise(resolve=>getStoredLicence(resolve));
                {
                    if (!lic || !lic.key) {
                        spinner.style.display = 'none';
                        logoutButton.disabled = false;
                        errorEl.textContent = 'No licence active.';
                        errorEl.style.display = 'block';
                        return;
                    }
                    let installationId = String(lic.installationId || '');
                    let legacyIp = '';
                    if (!installationId) legacyIp = await fetchPublicIP();
                    const response = await callBackend('release', lic.key, installationId, legacyIp);
                    spinner.style.display = 'none';
                    logoutButton.disabled = false;
                    if (response && response.status === 'ok') {
                        // Remove local licence and show login form
                        setStoredLicence(null);
                        showLogin();
                    } else {
                        errorEl.textContent = 'Error releasing licence.';
                        errorEl.style.display = 'block';
                    }
                }
            } catch (err) {
                console.error('Error during licence release', err);
                spinner.style.display = 'none';
                logoutButton.disabled = false;
                errorEl.textContent = 'Network error. Please check connection and try again.';
                errorEl.style.display = 'block';
            }
        });
    }

    // Initialize after DOM is ready
    document.addEventListener('DOMContentLoaded', init);
})();
