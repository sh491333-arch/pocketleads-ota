// Licence-page compatibility helpers. Theme state is managed by the shared PocketLeads theme manager.
document.addEventListener('DOMContentLoaded',function(){
  document.querySelectorAll('.theme-item').forEach(function(item){ item.style.display='none'; });
});
