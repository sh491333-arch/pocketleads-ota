// When the popup is opened, determine whether a licence is active.  If a
// valid licence exists we launch the main dashboard UI; otherwise we
// present the licence activation form.  Because storage access is
// asynchronous, wrap the decision in a callback.
try {
    chrome.storage.local.get('license', function(res) {
        const lic = res && res.license;
        const hasLicence = lic && lic.active;
        const url = hasLicence
            ? chrome.runtime.getURL('/views/index.html')
            : chrome.runtime.getURL('/popup/license.html');
        $box.simplePopup(url, 'Title');
    });
} catch (err) {
    // If storage access fails for any reason, default to showing the
    // licence activation form.  This prevents the dashboard from
    // appearing without a licence.
    console.error('Error checking licence state', err);
    $box.simplePopup(chrome.runtime.getURL('/popup/license.html'), 'Title');
}