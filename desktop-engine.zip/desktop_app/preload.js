const { ipcRenderer } = require('electron');

window.__plIsDesktopApp = true;

function showChromeStyleDownloadBar(info) {
  try {
    if (typeof document === 'undefined' || !document.body || !info || !info.filePath) return;
    let bar = document.getElementById('pl-chrome-download-shelf');
    if (bar) bar.remove();

    bar = document.createElement('div');
    bar.id = 'pl-chrome-download-shelf';
    bar.style.cssText = 'position:fixed;bottom:14px;left:50%;transform:translateX(-50%);z-index:2147483647;width:min(680px,94vw);background:#111827;border:1px solid rgba(16,185,129,0.45);border-radius:14px;box-shadow:0 18px 48px rgba(0,0,0,0.72);padding:11px 15px;display:flex;align-items:center;justify-content:space-between;gap:12px;color:#F8FAFC;font-family:Inter,system-ui,sans-serif;';

    const esc = s => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    const isExcel = /\.xlsx?$/i.test(info.fileName || '');
    const badgeTxt = isExcel ? 'XLSX' : (/\.csv$/i.test(info.fileName || '') ? 'CSV' : 'FILE');

    bar.innerHTML =
      '<div style="display:flex;align-items:center;gap:11px;min-width:0;flex:1;">' +
        '<div style="width:38px;height:38px;border-radius:10px;background:rgba(16,185,129,0.18);border:1px solid rgba(16,185,129,0.45);display:flex;align-items:center;justify-content:center;color:#34D399;font-weight:900;font-size:11px;flex-shrink:0;">' + badgeTxt + '</div>' +
        '<div style="min-width:0;flex:1;">' +
          '<div style="font-size:13px;font-weight:800;color:#F8FAFC;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + esc(info.fileName) + '</div>' +
          '<div style="font-size:11px;color:#94A3B8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="' + esc(info.filePath) + '">✓ Saved to: ' + esc(info.folderPath || info.filePath) + '</div>' +
        '</div>' +
      '</div>' +
      '<div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">' +
        '<button type="button" id="plChromeDlOpenBtn" style="height:34px;padding:0 13px;border-radius:9px;border:1px solid rgba(16,185,129,0.5);background:linear-gradient(135deg,#10B981,#059669);color:#FFFFFF;font-size:12px;font-weight:800;cursor:pointer;">Open File</button>' +
        '<button type="button" id="plChromeDlFolderBtn" style="height:34px;padding:0 13px;border-radius:9px;border:1px solid rgba(148,163,184,0.3);background:#1E293B;color:#E2E8F0;font-size:12px;font-weight:700;cursor:pointer;">Show in Folder</button>' +
        '<button type="button" id="plChromeDlCloseBtn" style="width:32px;height:34px;border-radius:9px;border:1px solid rgba(148,163,184,0.2);background:transparent;color:#94A3B8;font-size:15px;font-weight:800;cursor:pointer;" title="Dismiss">✕</button>' +
      '</div>';

    document.body.appendChild(bar);

    document.getElementById('plChromeDlOpenBtn').onclick = function() {
      ipcRenderer.send('pl:openSpecificFile', info.filePath);
    };
    document.getElementById('plChromeDlFolderBtn').onclick = function() {
      ipcRenderer.send('pl:showFileInFolder', info.filePath);
    };
    document.getElementById('plChromeDlCloseBtn').onclick = function() {
      bar.remove();
    };
  } catch (_) {}
}

window.AndroidChromeBridge = {
  getManifestJson: function() {
    return ipcRenderer.sendSync('pl:getManifestJson');
  },
  getAllStorageJson: function() {
    return ipcRenderer.sendSync('pl:getAllStorageJson');
  },
  saveAllStorageJson: function(jsonStr) {
    ipcRenderer.send('pl:saveAllStorageJson', String(jsonStr || '{}'));
  },
  setStorageItem: function(key, valJson) {
    ipcRenderer.send('pl:setStorageItem', String(key || ''), String(valJson || 'null'));
  },
  setViewportMode: function(_mode) {
    // Desktop window uses native window sizing
  },
  createTab: function(url, active) {
    return ipcRenderer.sendSync('pl:createTab', String(url || ''), !!active);
  },
  getTab: function(tabId) {
    return ipcRenderer.sendSync('pl:getTab', Number(tabId));
  },
  updateTab: function(tabId, updatePropsJson) {
    return ipcRenderer.sendSync('pl:updateTab', Number(tabId), String(updatePropsJson || '{}'));
  },
  removeTab: function(tabId) {
    ipcRenderer.send('pl:removeTab', Number(tabId));
  },
  reloadTab: function(tabId) {
    ipcRenderer.send('pl:reloadTab', Number(tabId));
  },
  queryTabs: function(queryInfoJson) {
    return ipcRenderer.sendSync('pl:queryTabs', String(queryInfoJson || '{}'));
  },
  executeScriptInTab: function(tabId, funcSource, argsJson, filesJson, cbId) {
    ipcRenderer.send('pl:executeScriptInTab', Number(tabId), String(funcSource || ''), String(argsJson || '[]'), String(filesJson || '[]'), String(cbId || ''));
  },
  sendMessageToTab: function(tabId, messageJson, cbId) {
    ipcRenderer.send('pl:sendMessageToTab', Number(tabId), String(messageJson || '{}'), String(cbId || ''));
  },
  nativeFetchAsync: function(urlStr, method, headersJson, body, timeoutMs, cbId) {
    ipcRenderer.send('pl:nativeFetchAsync', String(urlStr || ''), String(method || 'GET'), String(headersJson || '{}'), String(body || ''), Number(timeoutMs || 65000), String(cbId || ''));
  },
  hasNativeDownloadNotification: function() {
    return true;
  },
  saveDownloadedFile: function(filename, mimeType, base64Data) {
    ipcRenderer.send('pl:saveDownloadedFile', String(filename || ''), String(mimeType || ''), String(base64Data || ''));
  },
  openLastDownloadedFile: function() {
    ipcRenderer.send('pl:openLastDownloadedFile');
  },
  chooseFolderToSaveLastFile: function() {
    ipcRenderer.send('pl:openLastDownloadedFile');
  },
  shareLastDownloadedFile: function() {
    ipcRenderer.send('pl:openLastDownloadedFile');
  },
  chooseFolderToSaveFileDirect: function(filename, mimeType, base64Data) {
    ipcRenderer.send('pl:saveDownloadedFile', String(filename || ''), String(mimeType || ''), String(base64Data || ''));
  },
  shareDownloadedFileDirect: function(filename, mimeType, base64Data) {
    ipcRenderer.send('pl:saveDownloadedFile', String(filename || ''), String(mimeType || ''), String(base64Data || ''));
  },
  setExtractionActive: function(_active, _statusText) {},
  cancelAllNotifications: function() {},
  fetchRenderedWebsiteDomAsync: function(urlStr, waitMs, cbId) {
    ipcRenderer.send('pl:fetchRenderedWebsiteDomAsync', String(urlStr || ''), Number(waitMs || 3500), String(cbId || ''));
  },
  clearBrowsingCache: function() {
    ipcRenderer.send('pl:clearBrowsingCache');
  },
  showNotification: function(_id, _title, _message) {
    // Suppress Windows "electron" OS toast notifications; handled via in-app UI
  }
};

ipcRenderer.on('pl:bridgeCallback', (_event, cbId, payloadJson) => {
  if (typeof window.__onAndroidBridgeCallback === 'function') {
    window.__onAndroidBridgeCallback(cbId, payloadJson);
  }
});

ipcRenderer.on('pl:downloadSaved', (_event, info) => {
  showChromeStyleDownloadBar(info);
});

ipcRenderer.on('pl:notificationClicked', (_event, id, title, message) => {
  if (typeof window.__onAndroidNotificationClicked === 'function') {
    window.__onAndroidNotificationClicked(id, title, message);
  }
});
