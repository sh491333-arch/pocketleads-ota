const { ipcRenderer } = require('electron');

window.AndroidWaTabBridge = {
  onTabMessageResponse: function(cbId, responseJson) {
    ipcRenderer.send('pl:waTabMessageResponse', String(cbId || ''), String(responseJson || 'null'));
  }
};
