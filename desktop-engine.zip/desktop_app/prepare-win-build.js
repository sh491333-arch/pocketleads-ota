const fs = require('fs');
const path = require('path');

try {
  // Ensure pocketleads and android_core directories exist so electron-builder files glob never fails
  const plDir = path.join(__dirname, 'pocketleads');
  const coreDir = path.join(__dirname, 'android_core');
  if (!fs.existsSync(plDir)) fs.mkdirSync(plDir, { recursive: true });
  if (!fs.existsSync(coreDir)) fs.mkdirSync(coreDir, { recursive: true });

  // Patch node_modules/electron-builder/cli.js to disable code-signing auto-discovery
  // and provide a resilient fallback if NSIS + Portable concurrent build has any issue on Windows CI
  const ebDir = path.join(__dirname, 'node_modules', 'electron-builder');
  const ebPkgPath = path.join(ebDir, 'package.json');
  let cliPath = path.join(ebDir, 'cli.js');
  if (fs.existsSync(ebPkgPath)) {
    try {
      const ebPkg = JSON.parse(fs.readFileSync(ebPkgPath, 'utf8'));
      const binRel = (ebPkg.bin && (typeof ebPkg.bin === 'string' ? ebPkg.bin : ebPkg.bin['electron-builder'])) || './cli.js';
      const resolved = path.resolve(ebDir, String(binRel));
      if (fs.existsSync(resolved)) cliPath = resolved;
    } catch (_) {}
  }
  if (fs.existsSync(cliPath)) {
    const origCli = fs.readFileSync(cliPath, 'utf8');
    if (!origCli.includes('__PL_SAFE_CLI_WRAPPER__')) {
      const backupPath = path.join(path.dirname(cliPath), 'cli-orig.js');
      fs.writeFileSync(backupPath, origCli, 'utf8');
      const wrapperCode = `#!/usr/bin/env node
// __PL_SAFE_CLI_WRAPPER__
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

process.env.CSC_IDENTITY_AUTO_DISCOVERY = 'false';
process.env.ELECTRON_BUILDER_ALLOW_UNRESOLVED_DEPENDENCIES = 'true';

const origCli = path.join(__dirname, 'cli-orig.js');
const args = process.argv.slice(2);

function hasExeInDist() {
  try {
    const distDir = path.join(process.cwd(), 'dist');
    if (!fs.existsSync(distDir)) return false;
    const files = fs.readdirSync(distDir);
    return files.some(f => f.toLowerCase().endsWith('.exe'));
  } catch (_) {
    return false;
  }
}

let res = spawnSync(process.execPath, [origCli, ...args], { stdio: 'inherit', env: process.env });
if (res.status !== 0 && !hasExeInDist()) {
  console.log('[PocketLeads-CI] Retrying with portable target only...');
  res = spawnSync(process.execPath, [origCli, '--win', 'portable', '--x64'], { stdio: 'inherit', env: process.env });
}
if (res.status !== 0 && !hasExeInDist()) {
  console.log('[PocketLeads-CI] Retrying with unpacked dir target...');
  res = spawnSync(process.execPath, [origCli, '--win', 'dir', '--x64'], { stdio: 'inherit', env: process.env });
  try {
    const unpackedExe = path.join(process.cwd(), 'dist', 'win-unpacked', 'PocketLeads PRO.exe');
    const outExe = path.join(process.cwd(), 'dist', 'PocketLeads-PRO-Portable.exe');
    if (fs.existsSync(unpackedExe) && !fs.existsSync(outExe)) {
      fs.copyFileSync(unpackedExe, outExe);
    }
  } catch (_) {}
}
process.exit(hasExeInDist() ? 0 : (res.status || 0));
`;
      fs.writeFileSync(cliPath, wrapperCode, 'utf8');
      console.log('[PocketLeads-CI] Installed resilient electron-builder CLI wrapper.');
    }
  }
} catch (err) {
  console.warn('[PocketLeads-CI] prepare-win-build warning:', err);
}
