/* PocketLeads OTA Fast Guard — avoids parsing 63KB twice on APK startup when v8 runtime is loaded */
if (typeof window !== 'undefined' && !window.__pocketLeadsAndroidPolyfillV5Loaded) {
  try {
    var s = document.createElement('script');
    s.src = '/chrome-ota-v8-runtime.js';
    document.head.appendChild(s);
  } catch (_) {}
}
