/*
 * PocketLeads PRO Android Native Runtime Polyfill & In-Process Engine (v5)
 * - In Desktop Chrome (chrome://extensions): Detects native Chrome MV3 environment and exits cleanly.
 * - In Android APK (https://pocketleads.local): Emulates all Chrome MV3 APIs directly in-process on
 *   the Main Thread with ZERO Web Worker dependency, 0ms message dispatch, and direct Native Bridge access.
 */
(function(globalScope) {
  'use strict';
  if (globalScope.__pocketLeadsAndroidPolyfillV40Loaded) return;
  globalScope.__pocketLeadsAndroidPolyfillV40Loaded = true;

  try {
    const isDesktopChromeExt = !globalScope.AndroidChromeBridge &&
      typeof globalScope.chrome !== 'undefined' &&
      globalScope.chrome.runtime &&
      globalScope.chrome.runtime.id &&
      globalScope.chrome.runtime.id !== 'pocketleads-android-pro' &&
      globalScope.chrome.storage &&
      globalScope.chrome.storage.local &&
      globalScope.chrome.storage.local.onChanged &&
      globalScope.location &&
      /^(chrome|kiwi|edge|brave|opera|moz)-extension:$/i.test(globalScope.location.protocol);
    if (isDesktopChromeExt) return;
  } catch (_) {}

  globalScope.__pocketLeadsAndroidPolyfillLoaded = true;
  globalScope.__pocketLeadsAndroidPolyfillV2Loaded = true;
  globalScope.__pocketLeadsAndroidPolyfillV3Loaded = true;
  globalScope.__pocketLeadsAndroidPolyfillV4Loaded = true;
  globalScope.__pocketLeadsAndroidPolyfillV5Loaded = true;
  globalScope.__plInProcessAndroid = true;

  if (globalScope.__plBgWorker) {
    try { globalScope.__plBgWorker.terminate(); } catch (_) {}
    globalScope.__plBgWorker = null;
  }

  if (typeof globalScope.importScripts !== 'function') {
    globalScope.importScripts = function() {};
  }

  const EXT_ID = 'pocketleads-android-pro';
  const DEFAULT_MANIFEST = {"name": "PocketLeads", "description": "PocketLeads: assigned provider routing, common credits, recoverable scraping and a canonical IndexedDB dashboard.", "version": "10.19.3", "manifest_version": 3, "background": {"service_worker": "controllers/background.js"}, "action": {"default_icon": "assets/icons/icon32.png", "default_title": "PocketLeads Extractor"}, "icons": {"16": "assets/icons/icon16.png", "32": "assets/icons/icon32.png", "48": "assets/icons/icon48.png", "128": "assets/icons/icon.png"}, "permissions": ["tabs", "offscreen", "declarativeNetRequestWithHostAccess", "storage", "unlimitedStorage", "notifications", "contextMenus", "scripting", "alarms", "system.cpu", "system.memory", "system.storage"], "host_permissions": ["https://*.google.com/*", "https://*.google.co.in/*", "http://foxoyo.store/*", "https://foxoyo.store/*", "https://api.ipify.org/*", "https://script.google.com/*", "https://script.googleusercontent.com/*", "*://*.whatsapp.com/*", "https://wa.me/*", "<all_urls>", "https://*/*", "http://*/*"], "declarative_net_request": {"rule_resources": [{"id": "ghost_mode", "enabled": true, "path": "rules/ghost-mode.json"}]}, "content_scripts": [{"matches": ["*://*.whatsapp.com/*"], "js": ["whatsapp/inject.js"], "run_at": "document_start", "all_frames": true}], "web_accessible_resources": [{"resources": ["views/privacy.html", "views/terms.html"], "matches": ["<all_urls>"]}, {"resources": ["whatsapp/wa_preload.js", "whatsapp/wa.js", "whatsapp/api.js", "whatsapp/pageBridge.js"], "matches": ["*://*.whatsapp.com/*"]}], "version_name": "10.19.3 White-Label Customer UI + Deduplicated Error Logs", "minimum_chrome_version": "109"};

  function getDynamicManifest() {
    try {
      if (globalScope.AndroidChromeBridge && typeof globalScope.AndroidChromeBridge.getManifestJson === 'function') {
        const raw = globalScope.AndroidChromeBridge.getManifestJson();
        if (raw) return JSON.parse(raw);
      }
    } catch (_) {}
    return DEFAULT_MANIFEST;
  }

  const MANIFEST = getDynamicManifest();

  function getBaseOrigin() {
    try {
      if (globalScope.location && globalScope.location.origin && globalScope.location.origin !== 'null') {
        return globalScope.location.origin;
      }
    } catch (_) {}
    return 'https://pocketleads.local';
  }

  function resolveExtUrl(relPath) {
    const clean = String(relPath || '').replace(/^\/+/, '');
    return getBaseOrigin() + '/' + clean;
  }

  let rpcCounter = 1;

  function hasNativeBridge() {
    return typeof globalScope.AndroidChromeBridge !== 'undefined' && globalScope.AndroidChromeBridge !== null;
  }

  const STORAGE_KEY_PREFIX = '__pl_chrome_storage_local__';
  const storageCache = {};
  const storageChangeListeners = [];
  const runtimeMessageListeners = [];
  const alarmListeners = [];
  const activeAlarms = new Map();

  function loadInitialStorageCache() {
    try {
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.getAllStorageJson === 'function') {
        const raw = globalScope.AndroidChromeBridge.getAllStorageJson();
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed === 'object') {
            Object.assign(storageCache, parsed);
          }
        }
      }
    } catch (e) {
      console.warn('[PocketLeads-Android] Native storage init warning:', e);
    }
    try {
      const localRaw = globalScope.localStorage && globalScope.localStorage.getItem(STORAGE_KEY_PREFIX);
      if (localRaw) {
        const parsed = JSON.parse(localRaw);
        if (parsed && typeof parsed === 'object') {
          for (const k of Object.keys(parsed)) {
            if (!(k in storageCache)) storageCache[k] = parsed[k];
          }
        }
      }
    } catch (_) {}

    if (storageCache.privacyAcceptance && storageCache.privacyAcceptance.accepted) {
      storageCache.privacyAcceptance.userConfirmed = true;
      try { if (globalScope.localStorage) globalScope.localStorage.setItem('privacyAccepted', 'true'); } catch (_) {}
    }

    // APK Close & Reopen Normalization:
    // If the APK was closed while extraction was active, stop the active flag on fresh boot
    // and preserve unfinished progress with resumeAvailable = true (or idle/completed if none).
    normalizeInterruptedSessionInCache();
  }

  function normalizeInterruptedSessionInCache() {
    try {
      let localObj = storageCache.local;
      if (typeof localObj === 'string') {
        try { localObj = JSON.parse(localObj); } catch (_) { localObj = null; }
      }
      if (!localObj || typeof localObj !== 'object') return;
      const q = localObj.apifyQueue || {};
      const wasRunning = !!(
        localObj.status ||
        (localObj._taskManager && localObj._taskManager.isWorking) ||
        /starting|preparing|resuming|searching|streaming|running|draining|switching|switched|backend_ready|scraping|processing|api_ready|enriching/i.test(String(q.status || ''))
      );
      if (!wasRunning) return;

      localObj.status = false;
      if (!localObj._taskManager || typeof localObj._taskManager !== 'object') {
        localObj._taskManager = { isWorking: false, activeTask: null, searchTabId: null };
      } else {
        localObj._taskManager.isWorking = false;
      }

      const rawSigStr = String(localObj.apifyTaskSignature || '');
      const sigList = /^v38sig:/i.test(rawSigStr) ? [] : rawSigStr.split(String.fromCharCode(10)).map(s => s.trim()).filter(Boolean);
      const doneCnt = Math.max(0, parseInt(q.completedTasks || q.apiTasksSettled, 10) || 0);
      const totCnt = Math.max(sigList.length, parseInt(q.totalTasks || localObj.apifyTaskTotal, 10) || 0);
      const hasPendProf = (Array.isArray(q.placeIdQueue) && q.placeIdQueue.some(item => /^(api_returned|pending|retry_pending|dom_running|dom_failed)$/i.test(String(item && item.status || '')))) || (Math.max(0, parseInt(q.domPending, 10) || 0) > 0);
      if ((!Array.isArray(localObj.taskList) || localObj.taskList.length === 0) && sigList.length > 0 && doneCnt < sigList.length) {
        localObj.taskList = sigList.slice(doneCnt);
      }
      const hasPendTasks = Array.isArray(localObj.taskList) && localObj.taskList.length > 0;
      const savedCnt = Math.max(parseInt(localObj.resultStoreCount, 10) || 0, Array.isArray(localObj.collect) ? localObj.collect.length : 0, parseInt(q.scrapedCount, 10) || 0);
      const isUnfinished = hasPendTasks || hasPendProf || (totCnt > 0 && doneCnt < totCnt) || (wasRunning && String(q.status || '').toLowerCase() !== 'completed');

      if (isUnfinished) {
        if ((!Array.isArray(localObj.taskList) || localObj.taskList.length === 0) && sigList.length > 0) {
          localObj.taskList = sigList.slice(Math.min(doneCnt, sigList.length - 1));
        }
        q.status = 'stopped';
        q.resumeAvailable = true;
        q.statusMessage = 'Extraction paused · Tap Resume to continue';
        q.domRunning = 0;
        q.processing = null;
        localObj._taskManager.activeTask = 'openMap';
      } else {
        q.status = savedCnt > 0 ? 'completed' : 'idle';
        q.resumeAvailable = false;
        q.domRunning = 0;
        q.processing = null;
        localObj._taskManager.activeTask = null;
      }
      try {
        const savedActiveMs = Math.max(
          0,
          parseInt(globalScope.localStorage && globalScope.localStorage.getItem('pl_stop_active_elapsed_ms'), 10) || 0,
          parseInt(q._activeElapsedMs || q.elapsedMs || localObj.scrapeElapsedMs, 10) || 0
        );
        q._activeElapsedMs = savedActiveMs;
        q.elapsedMs = savedActiveMs;
        q._lastActiveTickMs = 0;
        localObj.scrapeElapsedMs = savedActiveMs;
      } catch (_) {}
      localObj.apifyQueue = q;
      storageCache.local = localObj;
      storageCache.plPendingProviderRequest = null;
      const fullSnap = JSON.stringify(storageCache);
      try {
        if (globalScope.localStorage) {
          globalScope.localStorage.setItem(STORAGE_KEY_PREFIX, fullSnap);
        }
      } catch (_) {}
      try {
        if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.saveAllStorageJson === 'function') {
          globalScope.AndroidChromeBridge.saveAllStorageJson(fullSnap);
        }
      } catch (_) {}
    } catch (e) {
      console.warn('[PocketLeads-Android] normalizeInterruptedSessionInCache warning:', e);
    }
  }

  globalScope.__plPauseAndCheckpointOnClose = normalizeInterruptedSessionInCache;
  if (typeof globalScope.addEventListener === 'function') {
    globalScope.addEventListener('pagehide', normalizeInterruptedSessionInCache);
    globalScope.addEventListener('beforeunload', normalizeInterruptedSessionInCache);
  }
  loadInitialStorageCache();

  if (typeof document !== 'undefined') {
    try {
      const injectNgHideGuard = function() {
        const target = document.head || document.documentElement;
        if (!target || document.getElementById('pl-android-ng-hide-guard')) return;
        const styleEl = document.createElement('style');
        styleEl.id = 'pl-android-ng-hide-guard';
        // Only hide .ng-hide + enforce neutral #19212D/#AAB4C2/#333E4E on count badges and Map pills!
        styleEl.textContent = 'html, body, button, input, select, textarea, a { touch-action: manipulation; -webkit-tap-highlight-color: transparent; -webkit-font-smoothing: antialiased; } .ng-hide { display: none !important; } ' +
          '.pl-m-count-circle, .pl-m-count-circle.has-items, .pl-input-count-badge, ' +
          '.pl-m-pill-map, .pl-m-pill-map:hover, .pl-m-pill-map:active, .pl-m-pill-map:focus { ' +
          'background: #19212D !important; color: #AAB4C2 !important; border: 1px solid #333E4E !important; ' +
          'box-shadow: none !important; text-shadow: none !important; filter: none !important; } ' +
          '.pl-m-pill-map svg, .pl-m-pill-map span { color: #AAB4C2 !important; stroke: #AAB4C2 !important; box-shadow: none !important; filter: none !important; }';
        target.appendChild(styleEl);
      };
      injectNgHideGuard();
      document.addEventListener('DOMContentLoaded', injectNgHideGuard);
    } catch (_) {}

    const healDashboardAndViewMode = function() {
      try {
        if (!document.body) return;
        // 1. Remove ng-cloak from body and all elements so nothing stays hidden behind the blurred backdrop
        document.body.removeAttribute('ng-cloak');
        document.body.classList.remove('ng-cloak');
        const cloaked = document.querySelectorAll('[ng-cloak], .ng-cloak');
        for (let i = 0; i < cloaked.length; i++) {
          cloaked[i].removeAttribute('ng-cloak');
          cloaked[i].classList.remove('ng-cloak');
        }

        // 2. Detect whether this extension ZIP has .pl-mobile-shell (newer ZIPs) or not (older ZIPs)
        const mobileShell = document.querySelector('.pl-mobile-shell');
        if (!mobileShell) {
          // Older extension ZIP without .pl-mobile-shell: use desktop mode so main dashboard is visible
          if (document.documentElement.getAttribute('data-view-mode') !== 'desktop') {
            document.documentElement.setAttribute('data-view-mode', 'desktop');
          }
          if (document.body.getAttribute('data-view-mode') !== 'desktop') {
            document.body.setAttribute('data-view-mode', 'desktop');
          }
        } else {
          const isDesktopExe = !!(globalScope.__plIsDesktopApp || (globalScope.navigator && /Electron/i.test(globalScope.navigator.userAgent || '')));
          const defaultMode = isDesktopExe ? 'desktop' : 'mobile';
          const savedMode = (globalScope.localStorage && (globalScope.localStorage.getItem('pocketleads-view-mode') || globalScope.localStorage.getItem('pocketleads_view_mode'))) || defaultMode;
          if (document.documentElement.getAttribute('data-view-mode') !== savedMode) {
            document.documentElement.setAttribute('data-view-mode', savedMode);
          }
          if (document.body.getAttribute('data-view-mode') !== savedMode) {
            document.body.setAttribute('data-view-mode', savedMode);
          }
          if (savedMode === 'mobile') {
            const panes = mobileShell.querySelectorAll('.pl-m-tab-pane');
            if (panes.length > 0) {
              let anyVisible = false;
              for (let i = 0; i < panes.length; i++) {
                if (!panes[i].classList.contains('ng-hide') && panes[i].style.display !== 'none') {
                  anyVisible = true;
                  break;
                }
              }
              if (!anyVisible) {
                panes[0].classList.remove('ng-hide');
                panes[0].style.display = '';
              }
            }
          }
        }

        // 3. Ensure .app-container and .main-content are never stuck in .ng-hide (older ZIPs with activeTab=='login')
        const mainContainers = document.querySelectorAll('.app-container, .main-content');
        for (let i = 0; i < mainContainers.length; i++) {
          if (mainContainers[i].classList.contains('ng-hide')) {
            mainContainers[i].classList.remove('ng-hide');
          }
          if (mainContainers[i].style.display === 'none') {
            mainContainers[i].style.display = '';
          }
        }

        // 4. Sync Angular scope if available
        if (globalScope.angular && typeof globalScope.angular.element === 'function') {
          const ctrlEl = document.querySelector('[ng-controller]') || document.body;
          const scope = globalScope.angular.element(ctrlEl).scope();
          if (scope) {
            let changed = false;
            if (scope.local && (!scope.local.activeTab || scope.local.activeTab === 'login')) {
              scope.local.activeTab = 'home';
              changed = true;
            }
            if (mobileShell && !scope.mobileTab) {
              scope.mobileTab = 'home';
              changed = true;
            }
            if (storageCache.license && storageCache.license.active && !scope.licenseActive) {
              scope.licenseActive = true;
              changed = true;
            }
            if (changed && typeof scope.$applyAsync === 'function') {
              scope.$applyAsync();
            }
          }
        }
      } catch (_) {}
    };
    document.addEventListener('DOMContentLoaded', function() {
      healDashboardAndViewMode();
      setTimeout(healDashboardAndViewMode, 150);
      setTimeout(healDashboardAndViewMode, 600);
      setTimeout(healDashboardAndViewMode, 1500);
    });

    const installAngularSafeApply = function() {
      try {
        if (!globalScope.angular || !globalScope.angular.module) return false;
        const origModule = globalScope.angular.module;
        if (!origModule.__plSafeApplyPatched) {
          const wrappedModule = function(name, requires, configFn) {
            const mod = origModule.apply(this, arguments);
            if (requires && mod && typeof mod.config === 'function' && !mod.__plSafeApplyConfigured) {
              mod.__plSafeApplyConfigured = true;
              mod.config(['$provide', function($provide) {
                $provide.decorator('$rootScope', ['$delegate', function($delegate) {
                  const origApply = $delegate.$apply;
                  $delegate.$apply = function(fn) {
                    const phase = this.$root && this.$root.$$phase;
                    if (phase === '$apply' || phase === '$digest') {
                      if (fn) {
                        try { return this.$eval(fn); } catch (e) { console.warn('[PocketLeads-Android] safe $eval warning:', e); }
                      }
                      return;
                    }
                    return origApply.apply(this, arguments);
                  };
                  return $delegate;
                }]);
              }]);
            }
            return mod;
          };
          Object.assign(wrappedModule, origModule);
          wrappedModule.__plSafeApplyPatched = true;
          globalScope.angular.module = wrappedModule;
        }
        return true;
      } catch (_) {
        return false;
      }
    };
    installAngularSafeApply();
    const ngPoll = setInterval(function() {
      if (installAngularSafeApply()) clearInterval(ngPoll);
    }, 5);
    setTimeout(function() { clearInterval(ngPoll); }, 10000);
  }

  let _persistTimer = null;
  function fastCloneStorageVal(val, depth) {
    if (val === null || typeof val !== 'object') return val;
    const d = depth || 0;
    if (d > 2) return val;
    if (Array.isArray(val)) {
      if (d === 0) return val.map(x => fastCloneStorageVal(x, d + 1));
      return val.slice();
    }
    const out = {};
    const keys = Object.keys(val);
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      const v = val[k];
      if (v !== null && typeof v === 'object') {
        out[k] = fastCloneStorageVal(v, d + 1);
      } else {
        out[k] = v;
      }
    }
    return out;
  }

  function flushStorageCacheNow() {
    if (_persistTimer) {
      clearTimeout(_persistTimer);
      _persistTimer = null;
    }
    try {
      if (Array.isArray(storageCache.plSessionSkippedRecords) && storageCache.plSessionSkippedRecords.length > 250) {
        storageCache.plSessionSkippedRecords = storageCache.plSessionSkippedRecords.slice(-250);
      }
      const defLocal = storageCache.PocketLeads_local_default;
      if (defLocal && typeof defLocal === 'object') {
        if (Array.isArray(defLocal.taskList) && defLocal.taskList.length > 400) {
          defLocal.taskList = defLocal.taskList.slice(0, 400);
        }
        if (Array.isArray(defLocal.locationList) && defLocal.locationList.length > 500) {
          defLocal.locationList = defLocal.locationList.slice(0, 500);
        }
      }
      const serialized = JSON.stringify(storageCache);
      if (globalScope.localStorage) {
        globalScope.localStorage.setItem(STORAGE_KEY_PREFIX, serialized);
      }
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.saveAllStorageJson === 'function') {
        globalScope.AndroidChromeBridge.saveAllStorageJson(serialized);
      }
    } catch (e) {
      console.warn('[PocketLeads-Android] Failed to persist storage:', e);
    }
  }

  function persistStorageCache(immediate) {
    if (immediate) {
      flushStorageCacheNow();
      return;
    }
    if (_persistTimer) return;
    const defLocal = storageCache.PocketLeads_local_default;
    const isRunningNow = !!(defLocal && (defLocal.status || (defLocal._taskManager && defLocal._taskManager.isWorking)));
    _persistTimer = setTimeout(flushStorageCacheNow, isRunningNow ? 950 : 300);
  }

  function fireStorageChanged(changes, areaName) {
    if (!changes || !Object.keys(changes).length) return;
    setTimeout(() => {
      for (const fn of storageChangeListeners.slice()) {
        try { fn(changes, areaName || 'local'); } catch (e) { console.warn('storage.onChanged listener error', e); }
      }
    }, 0);
  }

  function applyStorageWriteLocal(items) {
    const changes = {};
    let forceImmediate = false;
    for (const [k, newVal] of Object.entries(items || {})) {
      const oldVal = storageCache[k];
      if (newVal === undefined) {
        delete storageCache[k];
      } else {
        storageCache[k] = fastCloneStorageVal(newVal, 0);
        if (k === 'PocketLeads_local_default' && newVal && typeof newVal === 'object') {
          const qStat = String((newVal.apifyQueue && newVal.apifyQueue.status) || '').toLowerCase();
          if (/^(stopped|completed|completed_with_errors|failed|paused_recoverable)$/.test(qStat)) {
            forceImmediate = true;
          }
        }
      }
      changes[k] = { oldValue: oldVal, newValue: storageCache[k] };
    }
    persistStorageCache(forceImmediate);
    fireStorageChanged(changes, 'local');
    return changes;
  }

  function applyStorageRemoveLocal(keys) {
    const keyList = Array.isArray(keys) ? keys : [keys];
    const changes = {};
    for (const k of keyList) {
      if (k in storageCache) {
        changes[k] = { oldValue: storageCache[k], newValue: undefined };
        delete storageCache[k];
      }
    }
    persistStorageCache(false);
    fireStorageChanged(changes, 'local');
  }

  function readFromStorageCache(keys) {
    if (keys === null || keys === undefined) {
      return fastCloneStorageVal(storageCache, 0);
    }
    if (typeof keys === 'string') {
      const res = {};
      if (keys in storageCache) res[keys] = fastCloneStorageVal(storageCache[keys], 0);
      return res;
    }
    if (Array.isArray(keys)) {
      const res = {};
      for (const k of keys) {
        if (k in storageCache) res[k] = fastCloneStorageVal(storageCache[k], 0);
      }
      return res;
    }
    if (typeof keys === 'object') {
      const res = {};
      for (const [k, defVal] of Object.entries(keys)) {
        res[k] = (k in storageCache) ? fastCloneStorageVal(storageCache[k], 0) : defVal;
      }
      return res;
    }
    return {};
  }

  const fallbackTabs = new Map();
  let fallbackTabCounter = 200;

  async function executeMainThreadRpc(method, args) {
    if (method === 'storage_get') {
      return readFromStorageCache(args[0]);
    }
    if (method === 'storage_set') {
      applyStorageWriteLocal(args[0] || {});
      return true;
    }
    if (method === 'storage_remove') {
      applyStorageRemoveLocal(args[0]);
      return true;
    }
    if (method === 'native_render_dom') {
      const [url, waitMs] = args;
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.fetchRenderedWebsiteDomAsync === 'function') {
        const effectiveWait = Math.max(1400, Math.min(4000, Number(waitMs) || 2200));
        return new Promise((resolve) => {
          const cbId = 'render_' + (rpcCounter++) + '_' + Date.now();
          const guardTimer = setTimeout(() => {
            if (globalScope.__plNativeCallbacks.has(cbId)) {
              globalScope.__plNativeCallbacks.delete(cbId);
              resolve({ ok: false, status: 0, error: 'Render DOM timeout' });
            }
          }, effectiveWait + 4000);
          globalScope.__plNativeCallbacks.set(cbId, (resJson) => {
            clearTimeout(guardTimer);
            globalScope.__plNativeCallbacks.delete(cbId);
            try { resolve(JSON.parse(resJson)); }
            catch (_) { resolve({ ok: false, status: 0, error: 'Invalid render JSON' }); }
          });
          globalScope.AndroidChromeBridge.fetchRenderedWebsiteDomAsync(
            String(url || ''),
            effectiveWait,
            cbId
          );
        });
      }
      return { ok: false, status: 0, error: 'Native DOM renderer unavailable' };
    }
    if (method === 'native_fetch') {
      const [url, httpMethod, headersObj, bodyStr, timeoutMs] = args;
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.nativeFetchAsync === 'function') {
        const effectiveTimeout = Math.max(2000, Math.min(65000, Number(timeoutMs) || (String(httpMethod || 'GET').toUpperCase() === 'GET' ? 6000 : 35000)));
        return new Promise((resolve) => {
          const cbId = 'fetch_' + (rpcCounter++) + '_' + Date.now();
          const guardTimer = setTimeout(() => {
            if (globalScope.__plNativeCallbacks.has(cbId)) {
              globalScope.__plNativeCallbacks.delete(cbId);
              resolve({ ok: false, status: 0, error: 'Native fetch timeout' });
            }
          }, effectiveTimeout + 500);
          globalScope.__plNativeCallbacks.set(cbId, (resJson) => {
            clearTimeout(guardTimer);
            globalScope.__plNativeCallbacks.delete(cbId);
            try { resolve(JSON.parse(resJson)); }
            catch (_) { resolve({ ok: false, status: 0, error: 'Invalid native fetch JSON' }); }
          });
          globalScope.AndroidChromeBridge.nativeFetchAsync(
            String(url || ''),
            String(httpMethod || 'GET'),
            JSON.stringify(headersObj || {}),
            bodyStr == null ? '' : String(bodyStr),
            effectiveTimeout,
            cbId
          );
        });
      }
      throw new Error('Native fetch unavailable outside APK');
    }
    if (method === 'tabs_create') {
      const props = args[0] || {};
      const url = String(props.url || 'about:blank');
      if (url.includes('/views/index.html')) {
        if (!globalScope.location.pathname.endsWith('/views/index.html')) {
          globalScope.location.href = resolveExtUrl('views/index.html');
        }
        return { id: 1, url: resolveExtUrl('views/index.html'), active: true, status: 'complete' };
      }
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.createTab === 'function') {
        const tabJson = globalScope.AndroidChromeBridge.createTab(url, !!props.active);
        const created = JSON.parse(tabJson);
        if (created && created.id) {
          fallbackTabs.set(Number(created.id), { id: Number(created.id), url, active: !!props.active, status: 'loading' });
        }
        return created;
      }
      const tabId = ++fallbackTabCounter;
      const tabObj = { id: tabId, url, active: !!props.active, status: 'complete' };
      fallbackTabs.set(tabId, tabObj);
      return tabObj;
    }
    if (method === 'tabs_get') {
      const tabId = Number(args[0]);
      if (tabId === 1) {
        return { id: 1, url: globalScope.location.href, active: true, status: 'complete' };
      }
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.getTab === 'function') {
        const tabJson = globalScope.AndroidChromeBridge.getTab(tabId);
        const parsed = (tabJson && tabJson !== 'null') ? JSON.parse(tabJson) : null;
        if (parsed) {
          fallbackTabs.set(tabId, parsed);
          return parsed;
        }
        return fallbackTabs.get(tabId) || null;
      }
      return fallbackTabs.get(tabId) || null;
    }
    if (method === 'tabs_update') {
      const tabId = Number(args[0]);
      const updateProps = args[1] || {};
      const cached = fallbackTabs.get(tabId);
      if (cached) {
        if (updateProps.url) cached.url = updateProps.url;
        if (typeof updateProps.active === 'boolean') cached.active = updateProps.active;
      }
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.updateTab === 'function') {
        const tabJson = globalScope.AndroidChromeBridge.updateTab(tabId, JSON.stringify(updateProps));
        const parsed = (tabJson && tabJson !== 'null') ? JSON.parse(tabJson) : null;
        return parsed || cached || { id: tabId, url: updateProps.url || '', active: !!updateProps.active, status: 'loading' };
      }
      return cached || { id: tabId, url: updateProps.url || '', active: !!updateProps.active, status: 'complete' };
    }
    if (method === 'tabs_remove') {
      const tabId = Number(args[0]);
      fallbackTabs.delete(tabId);
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.removeTab === 'function') {
        globalScope.AndroidChromeBridge.removeTab(tabId);
        return true;
      }
      return true;
    }
    if (method === 'tabs_reload') {
      const tabId = Number(args[0]);
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.reloadTab === 'function') {
        globalScope.AndroidChromeBridge.reloadTab(tabId);
        return true;
      }
      return true;
    }
    if (method === 'tabs_query') {
      const queryInfo = args[0] || {};
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.queryTabs === 'function') {
        const listJson = globalScope.AndroidChromeBridge.queryTabs(JSON.stringify(queryInfo));
        return listJson ? JSON.parse(listJson) : [];
      }
      const all = [{ id: 1, url: globalScope.location.href, active: true, status: 'complete' }, ...fallbackTabs.values()];
      return all;
    }
    if (method === 'tabs_send_message') {
      const tabId = Number(args[0]);
      const message = args[1];
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.sendMessageToTab === 'function') {
        return new Promise((resolve) => {
          const cbId = 'tabmsg_' + (rpcCounter++) + '_' + Date.now();
          globalScope.__plNativeCallbacks.set(cbId, (resJson) => {
            try { resolve(resJson ? JSON.parse(resJson) : undefined); } catch (_) { resolve(undefined); }
          });
          globalScope.AndroidChromeBridge.sendMessageToTab(tabId, JSON.stringify(message), cbId);
        });
      }
      return undefined;
    }
    if (method === 'scripting_execute') {
      const opts = args[0] || {};
      const tabId = opts.target && opts.target.tabId;
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.executeScriptInTab === 'function') {
        return new Promise((resolve) => {
          const cbId = 'exec_' + (rpcCounter++) + '_' + Date.now();
          globalScope.__plNativeCallbacks.set(cbId, (resJson) => {
            try {
              const parsed = (resJson && resJson !== 'undefined') ? JSON.parse(resJson) : null;
              resolve([{ result: parsed }]);
            } catch (_) {
              resolve([{ result: null }]);
            }
          });
          globalScope.AndroidChromeBridge.executeScriptInTab(
            Number(tabId || 0),
            opts.funcSource || '',
            JSON.stringify(opts.args || []),
            JSON.stringify(opts.files || []),
            cbId
          );
        });
      }
      return [{ result: null }];
    }
    if (method === 'notify_create') {
      const notifId = String(args[0] || '');
      const opts = args[1] || {};
      if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.showNotification === 'function') {
        globalScope.AndroidChromeBridge.showNotification(notifId, String(opts.title || 'PocketLeads'), String(opts.message || ''));
      }
      return notifId;
    }
    return null;
  }

  globalScope.__plNativeCallbacks = new Map();
  globalScope.__onAndroidBridgeCallback = function(cbId, payloadJson) {
    const fn = globalScope.__plNativeCallbacks.get(cbId);
    if (fn) {
      globalScope.__plNativeCallbacks.delete(cbId);
      try { fn(payloadJson); } catch (e) { console.warn('Native callback error:', e); }
    }
  };

  if (typeof globalScope.fetch === 'function' && !globalScope.fetch.__plWrappedV5) {
    const origFetch = globalScope.fetch.bind(globalScope);
    const wrappedFetch = async function(input, init) {
      const rawUrl = (typeof input === 'string') ? input : (input && input.url ? input.url : String(input));
      const isExternal = /^https?:\/\//i.test(rawUrl) && !rawUrl.startsWith(getBaseOrigin());
      if (init && init.signal && init.signal.aborted) {
        const abortErr = new Error('The operation was aborted.');
        abortErr.name = 'AbortError';
        throw abortErr;
      }
      const method = (init && init.method) ? String(init.method).toUpperCase() : 'GET';
      const isDirectNativeCandidate = isExternal && hasNativeBridge() &&
        typeof globalScope.AndroidChromeBridge.nativeFetchAsync === 'function' &&
        method === 'GET' &&
        !/script\.google\.com|googleusercontent\.com|googleapis\.com|ipify\.org|github\.com|githubusercontent\.com/i.test(rawUrl);

      const runNativeFetch = async () => {
        let headers = {};
        if (init && init.headers) {
          if (typeof init.headers.forEach === 'function') {
            init.headers.forEach((v, k) => { headers[k] = v; });
          } else if (typeof init.headers === 'object') {
            headers = Object.assign({}, init.headers);
          }
        }
        const body = (init && typeof init.body === 'string') ? init.body : '';
        const reqTimeout = Number(init && init.timeoutMs) || (method === 'GET' ? 5000 : 35000);
        const nat = await executeMainThreadRpc('native_fetch', [rawUrl, method, headers, body, reqTimeout]);
        if (nat && nat.status > 0) {
          const textBody = String(nat.body || '');
          return {
            ok: nat.status >= 200 && nat.status < 300,
            status: nat.status,
            url: nat.finalUrl || rawUrl,
            text: async () => textBody,
            json: async () => JSON.parse(textBody)
          };
        }
        throw new Error((nat && nat.error) || 'Native fetch failed');
      };

      if (isDirectNativeCandidate) {
        return await runNativeFetch();
      }
      try {
        return await origFetch(input, init);
      } catch (fetchErr) {
        if (!isExternal || (init && init.signal && init.signal.aborted)) throw fetchErr;
        try {
          return await runNativeFetch();
        } catch (_) {}
        throw fetchErr;
      }
    };
    wrappedFetch.__plWrappedV5 = true;
    globalScope.fetch = wrappedFetch;
  }

  function dispatchRuntimeMessageLocally(message, sender) {
    let handledAsync = false;
    let responded = false;
    return new Promise((resolve) => {
      const sendResponse = (replyPayload) => {
        if (responded) return;
        responded = true;
        resolve({ responded: true, payload: replyPayload });
      };
      for (const listener of runtimeMessageListeners.slice()) {
        try {
          const ret = listener(message, sender, sendResponse);
          if (ret === true) {
            handledAsync = true;
          } else if (ret && typeof ret.then === 'function') {
            handledAsync = true;
            ret.then(sendResponse).catch(() => sendResponse(undefined));
          }
        } catch (err) {
          console.warn('[PocketLeads-Android] runtime.onMessage listener error:', err);
        }
      }
      if (!handledAsync && !responded) {
        resolve({ responded: false, payload: undefined });
      } else if (handledAsync && !responded) {
        setTimeout(() => {
          if (!responded) resolve({ responded: false, payload: undefined });
        }, 65000);
      }
    });
  }

  const chromeObj = {};

  chromeObj.runtime = {
    id: EXT_ID,
    lastError: null,
    getManifest: function() {
      return MANIFEST;
    },
    getURL: function(path) {
      return resolveExtUrl(path);
    },
    getPlatformInfo: function(cb) {
      const info = { os: 'android', arch: 'arm64', nacl_arch: 'arm' };
      if (typeof cb === 'function') setTimeout(() => cb(info), 0);
      return Promise.resolve(info);
    },
    getContexts: function() {
      return Promise.resolve([]);
    },
    onInstalled: {
      addListener: function() {}
    },
    setUninstallURL: function() {},
    onMessage: {
      addListener: function(fn) {
        if (typeof fn === 'function' && !runtimeMessageListeners.includes(fn)) {
          runtimeMessageListeners.push(fn);
        }
      },
      removeListener: function(fn) {
        const idx = runtimeMessageListeners.indexOf(fn);
        if (idx >= 0) runtimeMessageListeners.splice(idx, 1);
      }
    },
    sendMessage: function(message, arg2, arg3) {
      let callback = null;
      if (typeof arg2 === 'function') callback = arg2;
      else if (typeof arg3 === 'function') callback = arg3;

      const sender = {
        id: EXT_ID,
        url: resolveExtUrl('views/index.html'),
        tab: { id: 1, url: resolveExtUrl('views/index.html'), active: true }
      };

      return new Promise((resolve) => {
        const finish = (reply) => {
          chromeObj.runtime.lastError = null;
          if (typeof callback === 'function') {
            setTimeout(() => {
              try { callback(reply); } catch (e) { console.warn('sendMessage callback error', e); }
            }, 0);
          }
          resolve(reply);
        };
        setTimeout(() => {
          dispatchRuntimeMessageLocally(message, sender).then(res => finish(res.payload));
        }, 0);
      });
    }
  };

  chromeObj.extension = {
    getBackgroundPage: function() { return undefined; },
    getURL: chromeObj.runtime.getURL
  };

  chromeObj.action = {
    onClicked: { addListener: function() {} },
    setBadgeText: function() {}
  };
  chromeObj.browserAction = chromeObj.action;

  const storageOnChangedObj = {
    addListener: function(fn) {
      if (typeof fn === 'function' && !storageChangeListeners.includes(fn)) {
        storageChangeListeners.push(fn);
      }
    },
    removeListener: function(fn) {
      const i = storageChangeListeners.indexOf(fn);
      if (i >= 0) storageChangeListeners.splice(i, 1);
    },
    hasListener: function(fn) {
      return storageChangeListeners.includes(fn);
    }
  };

  chromeObj.storage = {
    local: {
      get: function(keys, cb) {
        const res = readFromStorageCache(keys);
        const p = Promise.resolve(res);
        chromeObj.runtime.lastError = null;
        if (typeof cb === 'function') setTimeout(() => cb(res), 0);
        return p;
      },
      set: function(items, cb) {
        applyStorageWriteLocal(items || {});
        const p = Promise.resolve();
        chromeObj.runtime.lastError = null;
        if (typeof cb === 'function') setTimeout(() => cb(), 0);
        return p;
      },
      remove: function(keys, cb) {
        applyStorageRemoveLocal(keys);
        const p = Promise.resolve();
        chromeObj.runtime.lastError = null;
        if (typeof cb === 'function') setTimeout(() => cb(), 0);
        return p;
      },
      clear: function(cb) {
        const allKeys = Object.keys(storageCache);
        return chromeObj.storage.local.remove(allKeys, cb);
      },
      onChanged: storageOnChangedObj
    },
    session: {
      get: function(keys, cb) { return chromeObj.storage.local.get(keys, cb); },
      set: function(items, cb) { return chromeObj.storage.local.set(items, cb); },
      remove: function(keys, cb) { return chromeObj.storage.local.remove(keys, cb); },
      clear: function(cb) { return chromeObj.storage.local.clear(cb); },
      onChanged: storageOnChangedObj
    },
    sync: {
      get: function(keys, cb) { return chromeObj.storage.local.get(keys, cb); },
      set: function(items, cb) { return chromeObj.storage.local.set(items, cb); },
      remove: function(keys, cb) { return chromeObj.storage.local.remove(keys, cb); },
      clear: function(cb) { return chromeObj.storage.local.clear(cb); },
      onChanged: storageOnChangedObj
    },
    onChanged: storageOnChangedObj
  };

  chromeObj.tabs = {
    create: function(createProps, cb) {
      const p = executeMainThreadRpc('tabs_create', [createProps || {}]);
      p.then(tab => { if (typeof cb === 'function') setTimeout(() => cb(tab), 0); });
      return p;
    },
    get: function(tabId, cb) {
      const p = executeMainThreadRpc('tabs_get', [tabId]);
      p.then(tab => { if (typeof cb === 'function') setTimeout(() => cb(tab), 0); });
      return p;
    },
    update: function(tabId, updateProps, cb) {
      const p = executeMainThreadRpc('tabs_update', [tabId, updateProps || {}]);
      p.then(tab => { if (typeof cb === 'function') setTimeout(() => cb(tab), 0); });
      return p;
    },
    remove: function(tabIds, cb) {
      const id = Array.isArray(tabIds) ? tabIds[0] : tabIds;
      const p = executeMainThreadRpc('tabs_remove', [id]);
      p.then(() => { if (typeof cb === 'function') setTimeout(() => cb(), 0); });
      return p;
    },
    reload: function(tabId, reloadProps, cb) {
      const callback = typeof reloadProps === 'function' ? reloadProps : cb;
      const p = executeMainThreadRpc('tabs_reload', [tabId]);
      p.then(() => { if (typeof callback === 'function') setTimeout(() => callback(), 0); });
      return p;
    },
    query: function(queryInfo, cb) {
      const p = executeMainThreadRpc('tabs_query', [queryInfo || {}]);
      p.then(tabs => { if (typeof cb === 'function') setTimeout(() => cb(tabs || []), 0); });
      return p;
    },
    sendMessage: function(tabId, message, optionsOrCb, cb) {
      const callback = typeof optionsOrCb === 'function' ? optionsOrCb : cb;
      const p = executeMainThreadRpc('tabs_send_message', [tabId, message]);
      p.then(res => { if (typeof callback === 'function') setTimeout(() => callback(res), 0); });
      return p;
    }
  };

  const registeredContentScripts = new Map();
  chromeObj.scripting = {
    executeScript: function(options, cb) {
      const payload = {
        target: options && options.target || {},
        funcSource: (options && typeof options.func === 'function') ? options.func.toString() : '',
        args: (options && Array.isArray(options.args)) ? options.args : [],
        files: (options && Array.isArray(options.files)) ? options.files : [],
        world: (options && options.world) || 'MAIN'
      };
      const p = executeMainThreadRpc('scripting_execute', [payload]);
      p.then(res => { if (typeof cb === 'function') setTimeout(() => cb(res), 0); });
      return p;
    },
    registerContentScripts: function(scripts, cb) {
      for (const s of (scripts || [])) {
        if (s && s.id) registeredContentScripts.set(s.id, s);
      }
      if (typeof cb === 'function') setTimeout(() => cb(), 0);
      return Promise.resolve();
    },
    getRegisteredContentScripts: function(filter, cb) {
      const list = [...registeredContentScripts.values()];
      if (typeof cb === 'function') setTimeout(() => cb(list), 0);
      return Promise.resolve(list);
    },
    unregisterContentScripts: function(filter, cb) {
      if (filter && Array.isArray(filter.ids)) {
        for (const id of filter.ids) registeredContentScripts.delete(id);
      } else {
        registeredContentScripts.clear();
      }
      if (typeof cb === 'function') setTimeout(() => cb(), 0);
      return Promise.resolve();
    }
  };

  chromeObj.offscreen = {
    hasDocument: function() { return Promise.resolve(true); },
    createDocument: function() { return Promise.resolve(); },
    closeDocument: function() { return Promise.resolve(); }
  };

  chromeObj.alarms = {
    create: function(name, alarmInfo) {
      const alarmName = typeof name === 'string' ? name : 'default_alarm';
      const info = (typeof name === 'object' ? name : alarmInfo) || { periodInMinutes: 1 };
      if (activeAlarms.has(alarmName)) clearInterval(activeAlarms.get(alarmName));
      const periodMs = Math.max(15000, Number(info.periodInMinutes || 1) * 60000);
      const timer = setInterval(() => {
        for (const fn of alarmListeners.slice()) {
          try { fn({ name: alarmName }); } catch (_) {}
        }
      }, periodMs);
      activeAlarms.set(alarmName, timer);
    },
    onAlarm: {
      addListener: function(fn) {
        if (typeof fn === 'function' && !alarmListeners.includes(fn)) alarmListeners.push(fn);
      }
    },
    clear: function(name, cb) {
      if (activeAlarms.has(name)) {
        clearInterval(activeAlarms.get(name));
        activeAlarms.delete(name);
      }
      if (typeof cb === 'function') setTimeout(() => cb(true), 0);
      return Promise.resolve(true);
    }
  };

  const notificationClickListeners = [];
  let pendingBackgroundNotification = null;

  globalScope.__onAndroidNotificationClicked = function(notifId, notifTitle, notifMessage) {
    try {
      const cleanId = String(notifId || 'pocketleads_scrape_status');
      pendingBackgroundNotification = null;
      for (const fn of notificationClickListeners.slice()) {
        try { fn(cleanId); } catch (_) {}
      }
      for (const fn of runtimeMessageListeners.slice()) {
        try {
          fn({
            type: 'pl_notification_clicked',
            notificationId: cleanId,
            title: String(notifTitle || ''),
            message: String(notifMessage || '')
          }, { id: EXT_ID }, function() {});
        } catch (_) {}
      }
      if (globalScope.angular && typeof globalScope.angular.element === 'function' && typeof document !== 'undefined') {
        const ctrlEl = document.querySelector('[ng-controller="indexController"]') || document.querySelector('[ng-controller]') || document.body;
        const scope = ctrlEl ? globalScope.angular.element(ctrlEl).scope() : null;
        if (scope) {
          if (cleanId.indexOf('dl_') === 0) {
            if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.openLastDownloadedFile === 'function') {
              globalScope.AndroidChromeBridge.openLastDownloadedFile();
              return;
            }
            if (typeof globalScope.__openLastExportedExcelViewer === 'function') {
              globalScope.__openLastExportedExcelViewer();
              return;
            }
          }
          const combined = (cleanId + ' ' + String(notifTitle || '') + ' ' + String(notifMessage || '')).toLowerCase();
          if (/licence_required|license_required/i.test(combined) && typeof globalScope.showLicenseModal === 'function') {
            globalScope.showLicenseModal();
            return;
          }
          const count = Number((scope.local && (scope.local.resultStoreCount || (scope.local.collect && scope.local.collect.length))) || 0);
          const targetTab = (count > 0 || /complete|extracted|lead|wa_check/i.test(combined)) ? (count > 0 ? 'leads' : 'progress') : 'progress';
          const applyTab = function() {
            if (typeof scope.setMobileTab === 'function') {
              scope.setMobileTab(targetTab);
            } else {
              scope.mobileTab = targetTab;
            }
          };
          if (typeof scope.$evalAsync === 'function') {
            scope.$evalAsync(applyTab);
          } else {
            applyTab();
          }
        }
      }
    } catch (e) {
      console.warn('[PocketLeads-Android] Notification click handler warning:', e);
    }
  };

  if (typeof document !== 'undefined') {
    document.addEventListener('visibilitychange', function() {
      if (!document.hidden && pendingBackgroundNotification) {
        const pending = pendingBackgroundNotification;
        pendingBackgroundNotification = null;
        if (Date.now() - pending.ts < 600000) {
          setTimeout(function() {
            globalScope.__onAndroidNotificationClicked(pending.id, pending.title, pending.message);
          }, 120);
        }
      }
    });
  }

  chromeObj.notifications = {
    create: function(idOrOpts, optsOrCb, maybeCb) {
      let id = typeof idOrOpts === 'string' ? idOrOpts : ('notif_' + Date.now());
      let opts = typeof idOrOpts === 'object' ? idOrOpts : (optsOrCb || {});
      let cb = typeof optsOrCb === 'function' ? optsOrCb : maybeCb;
      if (typeof document !== 'undefined' && document.hidden) {
        pendingBackgroundNotification = {
          id: id,
          title: String(opts.title || ''),
          message: String(opts.message || ''),
          ts: Date.now()
        };
      }
      executeMainThreadRpc('notify_create', [id, opts]).then(() => {
        if (typeof cb === 'function') setTimeout(() => cb(id), 0);
      });
    },
    clear: function(id, cb) {
      if (typeof cb === 'function') setTimeout(() => cb(true), 0);
    },
    onClicked: {
      addListener: function(fn) {
        if (typeof fn === 'function' && !notificationClickListeners.includes(fn)) {
          notificationClickListeners.push(fn);
        }
      },
      removeListener: function(fn) {
        const idx = notificationClickListeners.indexOf(fn);
        if (idx >= 0) notificationClickListeners.splice(idx, 1);
      },
      hasListener: function(fn) {
        return notificationClickListeners.includes(fn);
      }
    }
  };

  chromeObj.system = {
    cpu: {
      getInfo: function(cb) {
        const info = { numOfProcessors: 8, archName: 'arm64', modelName: 'Android ARMv8 Processor', features: ['neon'] };
        if (typeof cb === 'function') setTimeout(() => cb(info), 0);
      }
    },
    memory: {
      getInfo: function(cb) {
        const info = { capacity: 8589934592, availableCapacity: 4294967296 };
        if (typeof cb === 'function') setTimeout(() => cb(info), 0);
      }
    },
    storage: {
      getInfo: function(cb) {
        const info = [{ id: 'android-internal', name: 'Internal Storage', type: 'fixed', capacity: 137438953472 }];
        if (typeof cb === 'function') setTimeout(() => cb(info), 0);
      }
    }
  };

  chromeObj.permissions = {
    contains: function(perms, cb) {
      if (typeof cb === 'function') setTimeout(() => cb(true), 0);
      return Promise.resolve(true);
    },
    request: function(perms, cb) {
      if (typeof cb === 'function') setTimeout(() => cb(true), 0);
      return Promise.resolve(true);
    }
  };

  chromeObj.contextMenus = {
    create: function() {},
    onClicked: { addListener: function() {} }
  };

  chromeObj.windows = {
    create: function(props, cb) {
      if (props && props.url) {
        globalScope.location.href = props.url;
      }
      if (typeof cb === 'function') setTimeout(() => cb({ id: 1 }), 0);
    }
  };

  try {
    Object.defineProperty(globalScope, 'chrome', {
      value: chromeObj,
      writable: true,
      configurable: true
    });
  } catch (_) {
    globalScope.chrome = chromeObj;
  }

  if (typeof globalScope.URL !== 'undefined' && typeof globalScope.HTMLAnchorElement !== 'undefined' && !globalScope.HTMLAnchorElement.prototype.click.__plWrappedV40) {
    const blobStore = new Map();
    const origCreateObjectURL = globalScope.URL.createObjectURL.bind(globalScope.URL);
    globalScope.URL.createObjectURL = function(obj) {
      const url = origCreateObjectURL(obj);
      if (obj instanceof Blob) {
        blobStore.set(url, obj);
      }
      return url;
    };

    let lastDownloadedBlobInfo = null;

    const triggerNativeOrWebShareFile = async function(info, preferNativeOpen) {
      info = info || lastDownloadedBlobInfo;
      if (!info) return false;
      try {
        if (preferNativeOpen && hasNativeBridge() && typeof globalScope.AndroidChromeBridge.openLastDownloadedFile === 'function') {
          globalScope.AndroidChromeBridge.openLastDownloadedFile();
          return true;
        }
      } catch (_) {}
      try {
        if (globalScope.navigator && typeof globalScope.navigator.share === 'function' && info.blob) {
          const fileObj = new File([info.blob], info.fileName, { type: info.mimeType || 'application/octet-stream' });
          if (!globalScope.navigator.canShare || globalScope.navigator.canShare({ files: [fileObj] })) {
            await globalScope.navigator.share({
              files: [fileObj],
              title: info.fileName
            });
            return true;
          }
        }
      } catch (_) {}
      return false;
    };

    globalScope.__openMobileCrmInApp = function(htmlContent, fileName) {
      try {
        if (typeof document === 'undefined' || !document.body) return;
        const cleanName = String(fileName || 'PocketLeads_Mobile_CRM.html');
        const crmBlob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
        lastDownloadedBlobInfo = { fileName: cleanName, blob: crmBlob, mimeType: 'text/html' };

        let existing = document.getElementById('pl-inapp-crm-overlay');
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.id = 'pl-inapp-crm-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483645;background:#07111F;display:flex;flex-direction:column;width:100vw;height:100vh;height:100dvh;font-family:Inter,system-ui,sans-serif;';

        const topBar = document.createElement('div');
        topBar.style.cssText = 'height:54px;padding:0 12px;background:#0B1628;border-bottom:1px solid rgba(148,163,184,0.2);display:flex;align-items:center;justify-content:space-between;gap:10px;flex-shrink:0;';
        topBar.innerHTML =
          '<button type="button" id="plCrmBackBtn" style="height:34px;padding:0 11px;border-radius:10px;border:1px solid rgba(255,255,255,0.16);background:#15233B;color:#F8FAFC;font-size:12px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:5px;">← Back</button>' +
          '<div style="flex:1;min-width:0;text-align:center;">' +
            '<div style="font-size:13px;font-weight:800;color:#F8FAFC;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">PocketLeads CRM</div>' +
          '</div>' +
          '<div style="display:inline-flex;align-items:center;gap:6px;">' +
            '<button type="button" id="plCrmDownloadBtn" style="height:34px;padding:0 10px;border-radius:10px;border:1px solid rgba(16,185,129,0.45);background:linear-gradient(135deg,#10B981,#059669);color:#FFFFFF;font-size:11.5px;font-weight:800;cursor:pointer;display:inline-flex;align-items:center;gap:4px;">⬇ Save</button>' +
            '<button type="button" id="plCrmShareTopBtn" style="height:34px;padding:0 10px;border-radius:10px;border:1px solid rgba(56,189,248,0.45);background:rgba(14,165,233,0.2);color:#38bdf8;font-size:11.5px;font-weight:800;cursor:pointer;display:inline-flex;align-items:center;gap:4px;">📤 Share</button>' +
          '</div>';

        const iframe = document.createElement('iframe');
        iframe.style.cssText = 'flex:1;width:100%;border:0;background:#07111F;';
        iframe.onload = function() {
          try {
            if (iframe.contentWindow && globalScope.AndroidChromeBridge) {
              iframe.contentWindow.AndroidChromeBridge = globalScope.AndroidChromeBridge;
            }
          } catch (_) {}
        };
        iframe.srcdoc = htmlContent;

        overlay.appendChild(topBar);
        overlay.appendChild(iframe);
        document.body.appendChild(overlay);

        document.getElementById('plCrmBackBtn').onclick = function() {
          overlay.remove();
        };
        document.getElementById('plCrmDownloadBtn').onclick = function() {
          if (hasNativeBridge() && typeof globalScope.AndroidChromeBridge.saveDownloadedFile === 'function') {
            const reader = new FileReader();
            reader.onloadend = function() {
              const dataUrl = String(reader.result || '');
              const idx = dataUrl.indexOf('base64,');
              const b64 = idx >= 0 ? dataUrl.slice(idx + 7) : '';
              globalScope.AndroidChromeBridge.saveDownloadedFile(cleanName, 'text/html', b64);
              showTopSlideDownloadBar(cleanName, crmBlob, 'text/html', b64);
            };
            reader.readAsDataURL(crmBlob);
          }
        };
        document.getElementById('plCrmShareTopBtn').onclick = function() {
          if (hasNativeBridge()) {
            const reader = new FileReader();
            reader.onloadend = function() {
              const dataUrl = String(reader.result || '');
              const idx = dataUrl.indexOf('base64,');
              const b64 = idx >= 0 ? dataUrl.slice(idx + 7) : '';
              const bridge = globalScope.AndroidChromeBridge;
              if (typeof bridge.shareDownloadedFileDirect === 'function') {
                bridge.shareDownloadedFileDirect(cleanName, 'text/html', b64);
              } else if (typeof bridge.shareLastDownloadedFile === 'function') {
                bridge.saveDownloadedFile(cleanName, 'text/html', b64);
                setTimeout(() => { try { bridge.shareLastDownloadedFile(); } catch (_) {} }, 320);
              } else if (typeof bridge.openLastDownloadedFile === 'function') {
                bridge.saveDownloadedFile(cleanName, '*/*', b64);
                setTimeout(() => { try { bridge.openLastDownloadedFile(); } catch (_) {} }, 350);
              }
            };
            reader.readAsDataURL(crmBlob);
          } else {
            triggerNativeOrWebShareFile(lastDownloadedBlobInfo, true);
          }
        };
      } catch (e) {
        console.warn('[PocketLeads-Android] Mobile CRM viewer error:', e);
      }
    };

    globalScope.__openLastExportedExcelViewer = function(customInfo) {
      try {
        if (typeof document === 'undefined' || !document.body) return;
        const info = customInfo || lastDownloadedBlobInfo || {};
        const sheet = globalScope.__plLastExportedSheet || null;
        if (!sheet || !Array.isArray(sheet.headers) || !Array.isArray(sheet.rows)) {
          triggerNativeOrWebShareFile(info, true);
          return;
        }
        const escHtml = s => String(s == null ? '' : s)
          .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        const colLetter = i => {
          let s = '', n = i + 1;
          while (n > 0) { s = String.fromCharCode(65 + ((n - 1) % 26)) + s; n = Math.floor((n - 1) / 26); }
          return s;
        };

        let existing = document.getElementById('pl-inapp-excel-viewer');
        if (existing) existing.remove();

        const modal = document.createElement('div');
        modal.id = 'pl-inapp-excel-viewer';
        modal.style.cssText = 'position:fixed;inset:0;z-index:2147483644;background:#080F1E;color:#F8FAFC;display:flex;flex-direction:column;width:100vw;height:100vh;height:100dvh;font-family:Inter,system-ui,sans-serif;';

        const fileName = String(info.fileName || sheet.filename || 'PocketLeads_Export.xlsx');
        const letterThs = '<th style="position:sticky;top:0;left:0;z-index:8;background:#1E293B;color:#94A3B8;font-size:10px;padding:6px 8px;border-bottom:1px solid #334155;border-right:1px solid #334155;text-align:center;">#</th>' +
          sheet.headers.map((h, i) => '<th style="position:sticky;top:0;z-index:6;background:#1E293B;color:#34D399;font-size:10.5px;font-weight:800;padding:6px 10px;border-bottom:1px solid #334155;border-right:1px solid #334155;text-align:center;">' + colLetter(i) + '</th>').join('');
        const labelThs = '<th style="position:sticky;top:27px;left:0;z-index:8;background:#0F172A;color:#CBD5E1;font-size:11px;padding:9px 8px;border-bottom:2px solid #10B981;border-right:1px solid #334155;text-align:center;">Row</th>' +
          sheet.headers.map(h => '<th style="position:sticky;top:27px;z-index:6;background:#0F172A;color:#F8FAFC;font-size:11.5px;font-weight:800;padding:9px 12px;border-bottom:2px solid #10B981;border-right:1px solid #26334D;text-align:left;white-space:nowrap;">' + escHtml(h) + '</th>').join('');

        const bodyTrs = sheet.rows.map((r, rIdx) => {
          const bg = (rIdx % 2 === 0) ? '#0B1324' : '#101A30';
          const tds = r.map(val => {
            const v = String(val == null ? '' : val);
            if (/^https?:\/\//i.test(v)) {
              return '<td style="padding:8px 12px;background:' + bg + ';border-bottom:1px solid #1E293B;border-right:1px solid #1E293B;white-space:nowrap;max-width:240px;overflow:hidden;text-overflow:ellipsis;"><a href="' + escHtml(v) + '" target="_blank" style="color:#38BDF8;text-decoration:underline;">' + escHtml(v) + '</a></td>';
            }
            return '<td style="padding:8px 12px;background:' + bg + ';color:#E2E8F0;border-bottom:1px solid #1E293B;border-right:1px solid #1E293B;white-space:nowrap;max-width:260px;overflow:hidden;text-overflow:ellipsis;">' + escHtml(v || '—') + '</td>';
          }).join('');
          return '<tr class="pl-xl-row"><td style="position:sticky;left:0;z-index:4;background:#152036;color:#94A3B8;font-weight:700;font-size:11px;text-align:center;padding:8px;border-bottom:1px solid #1E293B;border-right:1px solid #334155;">' + (rIdx + 1) + '</td>' + tds + '</tr>';
        }).join('');

        modal.innerHTML =
          '<div style="padding:10px 12px;background:linear-gradient(135deg,#06281E 0%,#0B172A 100%);border-bottom:1px solid rgba(16,185,129,0.35);display:flex;align-items:center;justify-content:space-between;gap:8px;flex-shrink:0;flex-wrap:wrap;">' +
            '<div style="display:flex;align-items:center;gap:9px;min-width:0;flex:1;">' +
              '<div style="width:36px;height:36px;border-radius:10px;background:rgba(16,185,129,0.2);border:1px solid rgba(16,185,129,0.5);display:flex;align-items:center;justify-content:center;color:#10B981;font-weight:900;font-size:14px;flex-shrink:0;">XLS</div>' +
              '<div style="min-width:0;flex:1;">' +
                '<div style="font-size:13px;font-weight:800;color:#F8FAFC;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + escHtml(fileName) + '</div>' +
                '<div style="font-size:11px;color:#34D399;font-weight:600;">✓ Saved in Downloads (' + Number(sheet.totalCount || sheet.rows.length) + ' rows)</div>' +
              '</div>' +
            '</div>' +
            '<div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">' +
              '<button type="button" id="plXlOpenAppBtn" style="height:34px;padding:0 11px;border-radius:9px;border:1px solid rgba(16,185,129,0.5);background:linear-gradient(135deg,#10B981,#059669);color:#FFFFFF;font-size:11.5px;font-weight:800;cursor:pointer;">📤 Open / Share File</button>' +
              '<button type="button" id="plXlCopyBtn" style="height:34px;padding:0 10px;border-radius:9px;border:1px solid rgba(255,255,255,0.16);background:#1E293B;color:#E2E8F0;font-size:11.5px;font-weight:700;cursor:pointer;">📋 Copy</button>' +
              '<button type="button" id="plXlCloseBtn" style="height:34px;padding:0 11px;border-radius:9px;border:1px solid rgba(255,255,255,0.16);background:#152033;color:#F8FAFC;font-size:12px;font-weight:800;cursor:pointer;">✕</button>' +
            '</div>' +
          '</div>' +
          '<div style="padding:8px 12px;background:#0D1526;border-bottom:1px solid #1E293B;display:flex;align-items:center;gap:8px;flex-shrink:0;">' +
            '<input type="search" id="plXlSearchInput" placeholder="Search in exported Excel sheet..." style="flex:1;height:34px;border-radius:9px;border:1px solid #263554;background:#080F1E;color:#F8FAFC;padding:0 11px;font-size:12px;outline:none;">' +
          '</div>' +
          '<div style="flex:1;min-height:0;overflow:auto;-webkit-overflow-scrolling:touch;background:#080F1E;">' +
            '<table style="border-collapse:separate;border-spacing:0;width:max-content;min-width:100%;font-size:12px;">' +
              '<thead><tr>' + letterThs + '</tr><tr>' + labelThs + '</tr></thead>' +
              '<tbody id="plXlTbody">' + bodyTrs + '</tbody>' +
            '</table>' +
          '</div>';

        document.body.appendChild(modal);

        document.getElementById('plXlCloseBtn').onclick = function() { modal.remove(); };
        document.getElementById('plXlOpenAppBtn').onclick = async function() {
          const opened = await triggerNativeOrWebShareFile(info, true);
          if (!opened) {
            if (typeof globalScope.showTopStatusToast === 'function') {
              globalScope.showTopStatusToast('✓ Saved in Downloads: ' + fileName, 'success');
            }
          }
        };
        document.getElementById('plXlCopyBtn').onclick = function() {
          const btn = document.getElementById('plXlCopyBtn');
          const TAB = String.fromCharCode(9), NL = String.fromCharCode(10); const tsv = sheet.headers.join(TAB) + NL + sheet.rows.map(r => r.map(c => String(c == null ? '' : c).replace(/\s+/g, ' ')).join(TAB)).join(NL);
          if (globalScope.navigator && globalScope.navigator.clipboard && globalScope.navigator.clipboard.writeText) {
            globalScope.navigator.clipboard.writeText(tsv).then(() => { btn.textContent = '✓ Copied!'; setTimeout(() => { btn.textContent = '📋 Copy'; }, 1800); });
          }
        };
        const searchIn = document.getElementById('plXlSearchInput');
        if (searchIn) {
          searchIn.oninput = function() {
            const q = String(searchIn.value || '').trim().toLowerCase();
            const trs = modal.querySelectorAll('#plXlTbody .pl-xl-row');
            for (let i = 0; i < trs.length; i++) {
              const txt = trs[i].textContent.toLowerCase();
              trs[i].style.display = (!q || txt.indexOf(q) >= 0) ? '' : 'none';
            }
          };
        }
      } catch (e) {
        console.warn('[PocketLeads-Android] Excel viewer error:', e);
      }
    };

    const showTopSlideDownloadBar = function(fileName, blobObj, mimeType, base64Payload) {
      try {
        if (typeof document === 'undefined' || !document.body) return;
        let bar = document.getElementById('pl-top-download-slidebar');
        if (bar) bar.remove();
        bar = document.createElement('div');
        bar.id = 'pl-top-download-slidebar';
        bar.style.cssText = 'position:fixed;bottom:68px;left:50%;transform:translateX(-50%);z-index:2147483646;width:min(420px,calc(100vw - 20px));background:linear-gradient(135deg,#0f172a 0%,#1e293b 100%);border:1px solid rgba(16,185,129,0.55);border-radius:14px;box-shadow:0 16px 42px rgba(0,0,0,0.75);padding:10px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px;color:#f8fafc;font-family:system-ui,-apple-system,sans-serif;box-sizing:border-box;';
        const safeName = String(fileName || 'PocketLeads_Export.xlsx').replace(/[<>&"]/g, '');
        const cleanMime = String(mimeType || 'text/csv').split(';')[0];
        bar.innerHTML =
          '<div style="min-width:0;flex:1;">' +
            '<div style="font-size:12px;font-weight:800;color:#34d399;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">✓ Ready: ' + safeName + '</div>' +
            '<div style="font-size:10.5px;color:#94a3b8;">Choose folder to save · Tap Share to send file</div>' +
          '</div>' +
          '<div style="display:inline-flex;align-items:center;gap:5px;flex-shrink:0;">' +
            '<button type="button" id="plSlideDlOpenBtn" style="height:30px;padding:0 9px;border-radius:8px;border:1px solid rgba(16,185,129,0.5);background:#10b981;color:#fff;font-size:11px;font-weight:800;cursor:pointer;">Open</button>' +
            '<button type="button" id="plSlideDlFolderBtn" style="height:30px;padding:0 9px;border-radius:8px;border:1px solid rgba(251,191,36,0.45);background:rgba(245,158,11,0.18);color:#fde68a;font-size:11px;font-weight:800;cursor:pointer;" title="Save as to folder in phone storage">💾 Save as</button>' +
            '<button type="button" id="plSlideDlShareBtn" style="height:30px;padding:0 9px;border-radius:8px;border:1px solid rgba(56,189,248,0.45);background:rgba(14,165,233,0.2);color:#38bdf8;font-size:11px;font-weight:800;cursor:pointer;">📤 Share</button>' +
            '<button type="button" id="plSlideDlCloseBtn" style="width:24px;height:30px;border-radius:8px;border:0;background:transparent;color:#94a3b8;font-size:14px;font-weight:800;cursor:pointer;">✕</button>' +
          '</div>';
        document.body.appendChild(bar);
        const autoTimer = setTimeout(() => { try { if (bar && bar.parentNode) bar.remove(); } catch (_) {} }, 12000);

        const withBase64 = function(cb) {
          if (base64Payload && typeof base64Payload === 'string' && base64Payload.length > 0) {
            cb(base64Payload);
            return;
          }
          if (blobObj instanceof Blob) {
            const r = new FileReader();
            r.onloadend = function() {
              const d = String(r.result || '');
              const idx = d.indexOf('base64,');
              cb(idx >= 0 ? d.slice(idx + 7) : '');
            };
            r.readAsDataURL(blobObj);
            return;
          }
          cb('');
        };

        bar.addEventListener('click', function(ev) { ev.stopPropagation(); });
        bar.addEventListener('touchstart', function(ev) { ev.stopPropagation(); }, { passive: true });

        const openBtn = document.getElementById('plSlideDlOpenBtn');
        if (openBtn) {
          openBtn.onclick = function(ev) {
            if (ev) { ev.preventDefault(); ev.stopPropagation(); }
            try {
              if (globalScope.AndroidChromeBridge && typeof globalScope.AndroidChromeBridge.openLastDownloadedFile === 'function') {
                globalScope.AndroidChromeBridge.openLastDownloadedFile();
              }
            } catch (_) {}
          };
        }
        const triggerUniversalShare = function(fName, mType, bObj, b64Str) {
          const bridge = globalScope.AndroidChromeBridge;
          // 1. New APK (v10.19.35+ with ShareFileProvider): call shareDownloadedFileDirect
          if (bridge && typeof bridge.shareDownloadedFileDirect === 'function' && b64Str) {
            bridge.shareDownloadedFileDirect(fName, mType, b64Str);
            return;
          }
          // 2. Old APK / WebView: use Web Share API Level 2 (navigator.share with File)
          //    which natively opens the Android Share Sheet (WhatsApp, Gmail, Drive, Telegram)!
          if (globalScope.navigator && typeof globalScope.navigator.share === 'function' && bObj) {
            try {
              const shareFile = new File([bObj], fName, { type: mType || 'application/octet-stream' });
              if (!globalScope.navigator.canShare || globalScope.navigator.canShare({ files: [shareFile] })) {
                globalScope.navigator.share({
                  files: [shareFile],
                  title: fName
                }).catch(function(err) {
                  if (err && err.name === 'AbortError') return;
                  if (bridge && typeof bridge.openLastDownloadedFile === 'function') {
                    if (b64Str && typeof bridge.saveDownloadedFile === 'function') {
                      bridge.saveDownloadedFile(fName, mType, b64Str);
                      setTimeout(function() { try { bridge.openLastDownloadedFile(); } catch (_) {} }, 280);
                    } else {
                      bridge.openLastDownloadedFile();
                    }
                  }
                });
                return;
              }
            } catch (_) {}
          }
          // 3. Fallback for Old APK WebViews without navigator.share({files}): save to Downloads & open system app chooser!
          if (bridge && typeof bridge.openLastDownloadedFile === 'function') {
            if (b64Str && typeof bridge.saveDownloadedFile === 'function') {
              bridge.saveDownloadedFile(fName, mType, b64Str);
              setTimeout(function() { try { bridge.openLastDownloadedFile(); } catch (_) {} }, 280);
            } else {
              bridge.openLastDownloadedFile();
            }
          }
        };

        const openOldApkSaveAsModal = function(fName, mType, bObj, b64Str) {
          try {
            let oldM = document.getElementById('pl-old-apk-saveas-modal');
            if (oldM) oldM.remove();
            oldM = document.createElement('div');
            oldM.id = 'pl-old-apk-saveas-modal';
            oldM.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(4,9,20,0.82);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;padding:16px;font-family:Inter,system-ui,sans-serif;';
            oldM.innerHTML =
              '<div style="width:min(390px,100%);background:#0F172A;border:1px solid rgba(56,189,248,0.4);border-radius:16px;padding:18px;box-shadow:0 20px 50px rgba(0,0,0,0.85);color:#F8FAFC;">' +
                '<div style="font-size:15px;font-weight:800;margin-bottom:4px;color:#38BDF8;">💾 Save as to Phone Storage</div>' +
                '<div style="font-size:11.5px;color:#94A3B8;margin-bottom:12px;">Choose folder &amp; file name to save in your phone storage:</div>' +
                '<label style="display:block;font-size:11px;font-weight:700;color:#CBD5E1;margin-bottom:4px;">Storage Folder</label>' +
                '<select id="plSaveAsFolderSel" style="width:100%;height:38px;border-radius:10px;border:1px solid #334155;background:#1E293B;color:#F8FAFC;padding:0 10px;font-size:12.5px;margin-bottom:10px;outline:none;">' +
                  '<option value="">📁 Internal Storage / Downloads (Default)</option>' +
                  '<option value="PocketLeads_Exports_">📁 Downloads / PocketLeads_Exports</option>' +
                  '<option value="CRM_Leads_">📁 Downloads / CRM_Leads</option>' +
                '</select>' +
                '<label style="display:block;font-size:11px;font-weight:700;color:#CBD5E1;margin-bottom:4px;">File Name</label>' +
                '<input id="plSaveAsNameInput" type="text" value="' + fName.replace(/"/g, '&quot;') + '" style="width:100%;height:38px;border-radius:10px;border:1px solid #334155;background:#1E293B;color:#F8FAFC;padding:0 10px;font-size:12.5px;margin-bottom:14px;box-sizing:border-box;outline:none;" />' +
                '<div style="display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;">' +
                  '<button type="button" id="plSaveAsCancelBtn" style="height:36px;padding:0 12px;border-radius:10px;border:1px solid #334155;background:transparent;color:#94A3B8;font-size:12px;font-weight:700;cursor:pointer;">Cancel</button>' +
                  '<button type="button" id="plSaveAsShareAppBtn" style="height:36px;padding:0 12px;border-radius:10px;border:1px solid rgba(56,189,248,0.45);background:rgba(14,165,233,0.18);color:#38BDF8;font-size:12px;font-weight:800;cursor:pointer;">📤 Share / Drive</button>' +
                  '<button type="button" id="plSaveAsConfirmBtn" style="height:36px;padding:0 14px;border-radius:10px;border:0;background:linear-gradient(135deg,#10B981,#059669);color:#FFFFFF;font-size:12px;font-weight:800;cursor:pointer;">💾 Save Here</button>' +
                '</div>' +
              '</div>';
            document.body.appendChild(oldM);
            document.getElementById('plSaveAsCancelBtn').onclick = function() { oldM.remove(); };
            document.getElementById('plSaveAsShareAppBtn').onclick = function() {
              const prefix = String(document.getElementById('plSaveAsFolderSel').value || '');
              const customN = String(document.getElementById('plSaveAsNameInput').value || fName).trim() || fName;
              const finalN = prefix + customN;
              oldM.remove();
              triggerUniversalShare(finalN, mType, bObj, b64Str);
            };
            document.getElementById('plSaveAsConfirmBtn').onclick = function() {
              const prefix = String(document.getElementById('plSaveAsFolderSel').value || '');
              const customN = String(document.getElementById('plSaveAsNameInput').value || fName).trim() || fName;
              const finalN = prefix + customN;
              oldM.remove();
              const bridge = globalScope.AndroidChromeBridge;
              if (bridge && typeof bridge.saveDownloadedFile === 'function' && b64Str) {
                bridge.saveDownloadedFile(finalN, mType, b64Str);
                if (typeof globalScope.showTopStatusToast === 'function') {
                  globalScope.showTopStatusToast('✓ Saved to Downloads/' + finalN, 'success');
                }
              }
            };
          } catch (_) {}
        };

        const triggerUniversalSaveAs = function(fName, mType, bObj, b64Str) {
          const bridge = globalScope.AndroidChromeBridge;
          // 1. New APK (v10.19.35+): native Android ACTION_CREATE_DOCUMENT folder picker
          if (bridge && typeof bridge.chooseFolderToSaveFileDirect === 'function' && b64Str) {
            bridge.chooseFolderToSaveFileDirect(fName, mType, b64Str);
            return;
          }
          // 2. Desktop / Web File System Access API
          if (typeof globalScope.showSaveFilePicker === 'function' && bObj) {
            globalScope.showSaveFilePicker({ suggestedName: fName }).then(async function(handle) {
              const writable = await handle.createWritable();
              await writable.write(bObj);
              await writable.close();
              if (typeof globalScope.showTopStatusToast === 'function') {
                globalScope.showTopStatusToast('✓ Saved: ' + fName, 'success');
              }
            }).catch(function() {});
            return;
          }
          // 3. Old APK: open our interactive Save-As dialog + save to Downloads
          openOldApkSaveAsModal(fName, mType, bObj, b64Str);
        };

        const folderBtn = document.getElementById('plSlideDlFolderBtn');
        if (folderBtn) {
          folderBtn.onclick = function(ev) {
            if (ev) { ev.preventDefault(); ev.stopPropagation(); }
            withBase64(function(b64) {
              triggerUniversalSaveAs(safeName, cleanMime, blobObj, b64);
            });
          };
        }
        const shareBtn = document.getElementById('plSlideDlShareBtn');
        if (shareBtn) {
          shareBtn.onclick = function(ev) {
            if (ev) { ev.preventDefault(); ev.stopPropagation(); }
            withBase64(function(b64) {
              triggerUniversalShare(safeName, cleanMime, blobObj, b64);
            });
          };
        }
        const closeBtn = document.getElementById('plSlideDlCloseBtn');
        if (closeBtn) {
          closeBtn.onclick = function() {
            clearTimeout(autoTimer);
            bar.remove();
          };
        }
      } catch (_) {}
    };

    const handleDirectBlobExport = function(blob, rawFilename) {
      if (!blob) return false;
      const cleanDlName = String(rawFilename || 'PocketLeads_Export.xlsx');
      const cleanMime = /\.xlsx$/i.test(cleanDlName)
        ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        : (/\.csv$/i.test(cleanDlName) ? 'text/csv' : (/\.html?$/i.test(cleanDlName) ? 'text/html' : (String(blob.type || 'application/octet-stream').split(';')[0])));
      lastDownloadedBlobInfo = { fileName: cleanDlName, blob: blob, mimeType: cleanMime };

      const reader = new FileReader();
      const shouldShareImmediately = !!globalScope.__plShareNextDownload;
      globalScope.__plShareNextDownload = false;
      globalScope.__plChooseFolderNextDownload = false;
      reader.onloadend = function() {
        const dataUrl = String(reader.result || '');
        const base64Idx = dataUrl.indexOf('base64,');
        const base64Data = base64Idx >= 0 ? dataUrl.slice(base64Idx + 7) : '';
        const bridge = globalScope.AndroidChromeBridge;
        if (shouldShareImmediately) {
          if (bridge && typeof bridge.shareDownloadedFileDirect === 'function') {
            bridge.shareDownloadedFileDirect(cleanDlName, cleanMime, base64Data);
          } else if (globalScope.navigator && typeof globalScope.navigator.share === 'function') {
            try {
              if (bridge && typeof bridge.saveDownloadedFile === 'function') {
                bridge.saveDownloadedFile(cleanDlName, cleanMime, base64Data);
              }
              const fileObj = new File([blob], cleanDlName, { type: cleanMime });
              globalScope.navigator.share({ files: [fileObj], title: cleanDlName }).catch(function(err) {
                if (err && err.name === 'AbortError') return;
                if (bridge && typeof bridge.openLastDownloadedFile === 'function') {
                  bridge.openLastDownloadedFile();
                }
              });
            } catch (_) {
              if (bridge && typeof bridge.saveDownloadedFile === 'function') {
                bridge.saveDownloadedFile(cleanDlName, cleanMime, base64Data);
                setTimeout(function() { try { bridge.openLastDownloadedFile(); } catch (_) {} }, 300);
              }
            }
          } else if (bridge && typeof bridge.saveDownloadedFile === 'function') {
            bridge.saveDownloadedFile(cleanDlName, cleanMime, base64Data);
            setTimeout(function() { try { if (typeof bridge.openLastDownloadedFile === 'function') bridge.openLastDownloadedFile(); } catch (_) {} }, 300);
          }
          if (!globalScope.__plIsDesktopApp) {
            showTopSlideDownloadBar(cleanDlName, blob, cleanMime, base64Data);
          }
          return;
        }
        // Normal Download:
        // - In New APK (v10.19.35+), saveDownloadedFile saves to Downloads AND opens native ACTION_CREATE_DOCUMENT folder picker
        // - In Old APK (pre-v10.19.35), saveDownloadedFile saves to Downloads, and showTopSlideDownloadBar lets user tap Open / Save as / Share immediately!
        if (bridge && typeof bridge.saveDownloadedFile === 'function') {
          bridge.saveDownloadedFile(cleanDlName, cleanMime, base64Data);
        }
        if (!globalScope.__plIsDesktopApp) {
          showTopSlideDownloadBar(cleanDlName, blob, cleanMime, base64Data);
        }
      };
      reader.readAsDataURL(blob);
      return true;
    };
    globalScope.__plHandleDirectDownloadAndShare = handleDirectBlobExport;

    const origAnchorClick = globalScope.__plOrigNativeAnchorClick || globalScope.HTMLAnchorElement.prototype.click;
    globalScope.__plOrigNativeAnchorClick = origAnchorClick;
    const wrappedAnchorClick = function() {
      const href = String(this.href || '');
      const downloadName = this.getAttribute('download') || this.download;
      if (href.startsWith('blob:') && downloadName && hasNativeBridge() && typeof globalScope.AndroidChromeBridge.saveDownloadedFile === 'function') {
        const blob = blobStore.get(href);
        if (blob) {
          handleDirectBlobExport(blob, String(downloadName));
          return;
        }
      }
      return origAnchorClick.apply(this, arguments);
    };
    wrappedAnchorClick.__plWrappedV5 = true;
    wrappedAnchorClick.__plWrappedV40 = true;
    globalScope.HTMLAnchorElement.prototype.click = wrappedAnchorClick;
  }


  globalScope.__plClearRuntimeCaches = function() {
    try {
      if (typeof blobStore !== 'undefined' && blobStore && typeof blobStore.forEach === 'function') {
        blobStore.forEach(function(_, url) {
          try { if (origRevokeObjectURL) origRevokeObjectURL(url); } catch (_) {}
        });
        blobStore.clear();
      }
    } catch (_) {}
    try {
      if (typeof virtualTabs !== 'undefined' && virtualTabs && typeof virtualTabs.forEach === 'function') {
        const toClose = [];
        virtualTabs.forEach(function(tab, id) {
          const u = String(tab && tab.url || '').toLowerCase();
          if (!u.includes('whatsapp.com')) toClose.push(id);
        });
        toClose.forEach(function(id) {
          virtualTabs.delete(id);
          try {
            if (globalScope.AndroidChromeBridge && typeof globalScope.AndroidChromeBridge.removeTab === 'function') {
              globalScope.AndroidChromeBridge.removeTab(id);
            }
          } catch (_) {}
        });
      }
    } catch (_) {}
    try {
      if (globalScope.AndroidChromeBridge && typeof globalScope.AndroidChromeBridge.clearBrowsingCache === 'function') {
        globalScope.AndroidChromeBridge.clearBrowsingCache();
      }
    } catch (_) {}
  };

  setTimeout(function() {
    try {
      const now = new Date();
      const timeStr = now.toTimeString().slice(0, 8) + '.' + String(now.getMilliseconds()).padStart(3, '0');
      chromeObj.runtime.sendMessage({
        action: 'PL_LIVE_SPY_EVENT',
        event: {
          id: 'init-' + Date.now(),
          time: timeStr,
          iso: now.toISOString(),
          type: 'ENGINE_READY',
          level: 'info',
          message: 'PocketLeads Android Self-Patching Engine v5 Active (v' + ((MANIFEST && MANIFEST.version) || '10.19.3') + ').'
        },
        snapshot: {
          updatedAt: now.toISOString(),
          updatedTime: timeStr,
          lastEventType: 'ENGINE_READY',
          lastMessage: 'PocketLeads Android Self-Patching Engine v5 Active.'
        }
      });
    } catch (_) {}
  }, 1200);
})(typeof self !== 'undefined' ? self : window);


  // Part 3 #6: Safe localStorage QuotaExceededError Guard (prevents 5,000-lead sessions from throwing QuotaExceededError)
  try {
    if (typeof Storage !== 'undefined' && Storage.prototype && !Storage.prototype.__plQuotaGuardInstalled) {
      const origSetItem = Storage.prototype.setItem;
      Storage.prototype.__plQuotaGuardInstalled = true;
      Storage.prototype.setItem = function(key, value) {
        const k = String(key || '');
        let v = String(value == null ? '' : value);
        // Never allow a single non-essential localStorage key > 1.8 MB to blow the 5 MB WebView quota
        if (v.length > 1800000 && !/license|licence|device_install_id|custom_export_preset/i.test(k)) {
          try {
            const parsed = JSON.parse(v);
            if (parsed && typeof parsed === 'object') {
              if (Array.isArray(parsed.collect) && parsed.collect.length > 120) {
                parsed.collect = parsed.collect.slice(0, 120);
                parsed.collectIsPreview = true;
              }
              if (Array.isArray(parsed._scrapeHistory) && parsed._scrapeHistory.length > 15) {
                parsed._scrapeHistory = parsed._scrapeHistory.slice(0, 15).map(h => Object.assign({}, h, { rows: [] }));
              }
              v = JSON.stringify(parsed);
            }
          } catch (_) {
            return;
          }
        }
        try {
          return origSetItem.call(this, k, v);
        } catch (quotaErr) {
          try {
            const protectedRx = /license|licence|device_install_id|custom_export_preset|user_selected_country|sound_vibrate|theme|view_mode/i;
            const keysToRemove = [];
            for (let i = 0; i < this.length; i++) {
              const existingKey = this.key(i);
              if (existingKey && !protectedRx.test(existingKey) && existingKey !== k) {
                keysToRemove.push(existingKey);
              }
            }
            keysToRemove.forEach(rk => { try { this.removeItem(rk); } catch (_) {} });
            return origSetItem.call(this, k, v);
          } catch (_) {}
        }
      };
    }
  } catch (_) {}
