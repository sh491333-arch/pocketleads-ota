(function(){
'use strict';

const APPS_SCRIPT_URL=PocketLeadsConfig.endpoint;
const $=id=>document.getElementById(id);
let accountLoadPromise=null;
let ticketsLoadPromise=null;
let initialized=false;
let ticketAttachmentFile=null;
const MAX_ATTACHMENT_BYTES=5*1024*1024;
const ALLOWED_ATTACHMENT_EXTENSIONS=/\.(png|jpe?g|webp|pdf|txt|csv|log|docx?|xlsx?|zip)$/i;

function readLicense(){
  return new Promise(resolve=>{
    try{chrome.storage.local.get('license',r=>resolve(r&&r.license||null));}
    catch(_){resolve(null);}
  });
}

function parseSupportText(text,status=200){
  const clean=String(text||'').replace(/^\uFEFF/,'').trim();
  if(!clean) throw new Error(`Support service returned an empty response (HTTP ${status}).`);
  const candidates=[clean];
  const first=clean.indexOf('{'), last=clean.lastIndexOf('}');
  if(first>=0&&last>first)candidates.push(clean.slice(first,last+1));
  for(const candidate of candidates){
    try{
      const parsed=JSON.parse(candidate);
      if(parsed && typeof parsed==='object')return parsed;
      if(typeof parsed==='string'){try{return JSON.parse(parsed);}catch(_){}}
    }catch(_){}
  }
  const title=(clean.match(/<title[^>]*>([\s\S]*?)<\/title>/i)||[])[1];
  const hint=String(title||clean).replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim().slice(0,180);
  throw new Error(`Support service returned an unexpected response (HTTP ${status}).${hint?` ${hint}`:''}`);
}

function sendSupportViaRuntime(params,method='GET'){
  return new Promise((resolve,reject)=>{
    try{
      chrome.runtime.sendMessage({action:'pocketleads_support_request',method,params},response=>{
        const runtimeError=chrome.runtime.lastError;
        if(runtimeError)return reject(new Error(runtimeError.message||'Support transport unavailable.'));
        if(!response||!response.ok)return reject(new Error(response&&response.error||'Support transport unavailable.'));
        try{resolve(parseSupportText(response.text,response.status));}catch(error){reject(error);}
      });
    }catch(error){reject(error);}
  });
}

async function directSupportRequest(params,method='GET'){
  const url=new URL(APPS_SCRIPT_URL);
  const request={method,redirect:'follow',cache:'no-store',credentials:'omit'};
  if(method==='POST'){
    request.headers={'Content-Type':'text/plain;charset=utf-8','Accept':'application/json'};
    request.body=JSON.stringify(params);
  }else{
    Object.keys(params).forEach(key=>url.searchParams.set(key,params[key]==null?'':String(params[key])));
  }
  const controller=new AbortController();request.signal=controller.signal;
  const timer=setTimeout(()=>controller.abort(),PocketLeadsConfig.accountTimeoutMs);
  let response,text;
  try{response=await fetch(url.toString(),request);text=await response.text();}finally{clearTimeout(timer);}
  if(!response.ok)throw new Error(`Support service returned HTTP ${response.status}. Verify the Apps Script deployment URL and access settings.`);
  return parseSupportText(text,response.status);
}

async function backend(action,payload){
  const license=await readLicense();
  if(!license||!license.key||!license.installationId) throw new Error('Activate your licence before using Support Center.');
  const body=Object.assign({
    action,
    key:license.key,
    deviceId:license.installationId,
    user:license.userName||license.user||'',
    email:license.email||''
  },payload||{});

  // Service-worker transport is primary. It avoids cross-origin response and
  // Google Apps Script redirect edge cases in extension pages.
  const method=action==='submitticket'?'POST':'GET';
  let data;
  let firstError=null;
  try{data=await sendSupportViaRuntime(body,method);}catch(error){firstError=error;}
  if(!data){
    try{data=await directSupportRequest(body,method);}catch(error){
      const reason=error&&error.message?error.message:String(error||'');
      if(firstError && /unexpected|empty response/i.test(reason)) throw error;
      throw new Error('Unable to connect to the support service. Check your internet connection and try again.');
    }
  }
  if(!data||data.status!=='ok'){
    const reason=data&&(data.message||data.reason||data.error);
    throw new Error(reason||'Support service rejected the request.');
  }
  return data;
}

function setSupportStatus(message,error=false,success=false){
  const node=$('plSupportStatus');
  if(!node)return;
  node.textContent=message||'';
  node.classList.toggle('is-error',!!error);
  node.classList.toggle('is-success',!!message&&!error&&!!success);
}
function formatDate(value){
  if(!value)return '—';
  const date=new Date(value);
  if(Number.isNaN(date.getTime()))return String(value);
  return new Intl.DateTimeFormat(undefined,{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(date);
}
function statusClass(status){
  const s=String(status||'open').toLowerCase();
  if(/resolved|closed|complete|done/.test(s))return 'is-closed';
  if(/pending|progress|waiting|hold/.test(s))return 'is-pending';
  return 'is-open';
}
function validateAttachment(file){
  if(!file)return;
  if(file.size>MAX_ATTACHMENT_BYTES)throw new Error('Attachment must be 5 MB or smaller.');
  if(!ALLOWED_ATTACHMENT_EXTENSIONS.test(file.name||''))throw new Error('Unsupported attachment type. Use an image, PDF, text, CSV, log, Office file or ZIP.');
}
function updateAttachmentUI(file){
  const meta=$('plTicketAttachmentMeta'),name=$('plTicketAttachmentName'),drop=$('plTicketDropZone');
  if(meta){
    meta.hidden=!file;
  }
  if(name)name.textContent=file?`${file.name} (${Math.max(1,Math.ceil(file.size/1024)).toLocaleString()} KB)`:'';
  if(drop)drop.classList.toggle('has-file',!!file);
}
function selectAttachment(file){
  try{
    validateAttachment(file);
    ticketAttachmentFile=file||null;
    updateAttachmentUI(ticketAttachmentFile);
    setSupportStatus('');
  }catch(error){
    ticketAttachmentFile=null;
    const input=$('plTicketAttachment');if(input)input.value='';
    updateAttachmentUI(null);
    setSupportStatus(error.message,true);
  }
}
function resetTicketForm(form){
  if(form)form.reset();
  ticketAttachmentFile=null;
  updateAttachmentUI(null);
}
function readAttachment(file){
  if(!file)return Promise.resolve(null);
  validateAttachment(file);
  return new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onerror=()=>reject(new Error('Could not read the selected attachment.'));
    reader.onload=()=>{
      const value=String(reader.result||''),comma=value.indexOf(',');
      if(comma<0)return reject(new Error('Could not encode the selected attachment.'));
      resolve({attachmentName:file.name,attachmentType:file.type||'application/octet-stream',attachmentData:value.slice(comma+1)});
    };
    reader.readAsDataURL(file);
  });
}
function renderTickets(tickets){
  const root=$('plSupportTicketList'),count=$('plTicketCount');
  if(!root)return;
  const list=(Array.isArray(tickets)?tickets:[]).filter(t=>t&&!/^\[(PL_CLOUD_BACKUP|AUTO ERROR LOG)/i.test(String(t.subject||''))).slice(0,50);
  root.textContent='';
  if(count)count.textContent=list.length?`${list.length} recent request${list.length===1?'':'s'}`:'No requests yet';
  if(!list.length){
    root.innerHTML='<div class="pl-empty-tickets"><div class="pl-empty-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v8A2.5 2.5 0 0 1 17.5 17H13l-3.4 3v-3H6.5A2.5 2.5 0 0 1 4 14.5v-8Z"/><path d="M8 9h8M8 12h5"/></svg></div><strong>No support tickets yet</strong><small>Tell us what you need and your request will appear here.</small></div>';
    return;
  }
  list.forEach(ticket=>{
    const row=document.createElement('button');
    row.type='button';row.className='pl-ticket-row';
    row.innerHTML='<div class="pl-ticket-main"><div class="pl-ticket-title"></div><div class="pl-ticket-meta"><span class="pl-ticket-id"></span><span class="pl-ticket-date"></span></div><div class="pl-ticket-preview"></div></div><div class="pl-ticket-side"><span class="pl-ticket-status-badge"></span><svg class="pl-ticket-chevron" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg></div>';
    row.querySelector('.pl-ticket-title').textContent=ticket.subject||'Support ticket';
    row.querySelector('.pl-ticket-id').textContent=ticket.id||'Ticket';
    row.querySelector('.pl-ticket-date').textContent=formatDate(ticket.timestamp);
    row.querySelector('.pl-ticket-preview').textContent=ticket.message||'No message';
    const badge=row.querySelector('.pl-ticket-status-badge');badge.textContent=ticket.status||'Open';badge.classList.add(statusClass(ticket.status));
    row.addEventListener('click',()=>showTicketDetail(ticket));
    root.appendChild(row);
  });
}
function setElementHiddenState(el, hidden, openDisplay) {
  if (!el) return;
  el.hidden = !!hidden;
  if (hidden) {
    el.setAttribute('hidden', '');
    el.style.setProperty('display', 'none', 'important');
  } else {
    el.removeAttribute('hidden');
    el.style.setProperty('display', openDisplay || 'block', 'important');
  }
}
function showTicketDetail(ticket){
  const modal=$('plTicketDetailModal');if(!modal)return;
  $('plTicketDetailId').textContent=ticket.id||'—';
  $('plTicketDetailDate').textContent=formatDate(ticket.timestamp);
  $('plTicketDetailSubject').textContent=ticket.subject||'Support ticket';
  $('plTicketDetailMessage').textContent=ticket.message||'No message';
  const status=$('plTicketDetailStatus');status.textContent=ticket.status||'Open';status.className='pl-detail-status '+statusClass(ticket.status);
  $('plTicketDetailRemarks').textContent=ticket.remarks||'No reply yet. Our support team will update this ticket here.';
  const attachmentWrap=$('plTicketDetailAttachmentWrap'),attachmentLink=$('plTicketDetailAttachment');
  const attachmentUrl=/^https:\/\//i.test(String(ticket.attachment||''))?String(ticket.attachment):'';
  if(attachmentWrap)attachmentWrap.hidden=!attachmentUrl;
  if(attachmentLink){attachmentLink.href=attachmentUrl||'#';attachmentLink.textContent=attachmentUrl?'Open attachment':'No attachment';}
  modal.style.setProperty('z-index', '2147482750', 'important');
  setElementHiddenState(modal, false, 'flex');
  document.body.classList.add('pl-modal-open');
}
function closeTicketDetail(){
  const modal=$('plTicketDetailModal');
  if(modal) setElementHiddenState(modal, true, 'flex');
  if(!($('plSupportModal')&&!$('plSupportModal').hidden))document.body.classList.remove('pl-modal-open');
}
function setSupportModal(open){
  const modal=$('plSupportModal'),panel=$('plProfilePanel'),notifPanel=$('plNotificationsPanel');if(!modal)return;
  modal.style.setProperty('z-index', '2147482700', 'important');
  setElementHiddenState(modal, !open, 'flex');
  if(open){
    if(panel)setPanelOpen(panel,false);
    if(notifPanel&&!notifPanel.hidden) {
      notifPanel.classList.remove('is-open');
      setElementHiddenState(notifPanel, true, 'flex');
    }
    document.body.classList.add('pl-modal-open');
    setTicketComposer(false);
    setSupportStatus('');
    loadTickets(true);
  }else{
    closeTicketDetail();
    setTicketComposer(false);
    setSupportStatus('');
    document.body.classList.remove('pl-modal-open');
  }
}
function setTicketComposer(open){
  const form=$('plTicketFormModal'),listView=$('plTicketListView'),body=document.querySelector('#plSupportModal .pl-support-body');
  if(form) setElementHiddenState(form, !open, 'block');
  if(listView) setElementHiddenState(listView, !!open, 'block');
  if(!open)resetTicketForm(form);
  if(body)body.scrollTop=0;
  if(open)requestAnimationFrame(()=>$('plTicketSubjectModal')?.focus());
}
function setPanelOpen(panel,open){
  const targetPanel = panel || $('plProfilePanel');
  if(!targetPanel)return;
  if(open && typeof window.__plEnsureCloudSignInMenuItem === 'function') {
    try { window.__plEnsureCloudSignInMenuItem(); } catch (_) {}
  }
  targetPanel.style.setProperty('z-index', '2147482650', 'important');
  setElementHiddenState(targetPanel, !open, 'block');
  targetPanel.classList.toggle('is-open', !!open);
  const trigger=$('openProfilePanel');
  if(trigger)trigger.setAttribute('aria-expanded',String(!!open));
}
async function loadTickets(force=false){
  if(ticketsLoadPromise)return ticketsLoadPromise;
  ticketsLoadPromise=(async()=>{
    const refresh=$('plTicketRefreshBtn');if(refresh)refresh.classList.add('is-loading');
    const count=$('plTicketCount'),root=$('plSupportTicketList');
    if(count)count.textContent='Loading requests…';
    if(root&&!root.children.length)root.innerHTML='<div class="pl-ticket-loading"><span></span><strong>Loading tickets</strong><small>Syncing your support history…</small></div>';
    try{const result=await backend('getsupporttickets');if($('plSupportStatus')?.classList.contains('is-error'))setSupportStatus('');renderTickets(result.tickets||[]);return result.tickets||[];}
    catch(error){setSupportStatus(error.message,true);if(count)count.textContent='Sync failed';if(root)root.innerHTML='<div class="pl-ticket-error"><strong>Could not load tickets</strong><small>You can still create a new ticket, or verify the Apps Script deployment and press Refresh.</small></div>';return[];}
    finally{if(refresh)refresh.classList.remove('is-loading');ticketsLoadPromise=null;}
  })();
  return ticketsLoadPromise;
}
function renderAccount(account,license){
  const a=account||{}, l=license||{};
  const fmt=v=>v==='unlimited'?'Unlimited':v==null?'Unavailable':Number(v).toLocaleString();
  const put=(id,text)=>{if($(id))$(id).textContent=text;};
  put('plCreditAvailable',fmt(a.availableCredit));
  put('plCreditTotal',fmt(a.purchasedCredit));
  put('plPlanName',a.plan||'Plan unavailable');
  put('plAccountStatus',a.syncState==='error'?'Refresh failed — Retry':l.active?(a.expiryDate?'Active until '+a.expiryDate:'License active'):'License inactive');
  put('plUserName',a.userName||l.userName||'PocketLeads User');
  const trigger=document.querySelector('.pl-profile-trigger-name');if(trigger)trigger.textContent=a.userName||'My Profile';
  const retry=$('plAccountRetry');if(retry)retry.hidden=a.syncState!=='error';
  const support=$('plAccountSupport');if(support)support.href='mailto:'+(a.supportEmail||PocketLeadsConfig.supportEmail);
  const upgrade=$('plAccountUpgrade');if(upgrade){let url;try{url=new URL(a.purchaseUrl);}catch(_){}upgrade.href=url?.protocol==='https:'?url.href:'mailto:'+(a.supportEmail||PocketLeadsConfig.supportEmail)+'?subject=PocketLeads%20credits%20and%20upgrade';}
}
async function loadAccount(force=false){
 if(accountLoadPromise)return accountLoadPromise;
 accountLoadPromise=(async()=>{
  const cached=await PocketLeadsAccount.read();renderAccount(cached.pocketleadsAccount,cached.license);
  if(!cached.license?.active)return;
  if(!force && cached.pocketleadsAccount?.syncState==='ready' && Date.now()-cached.pocketleadsAccount.syncedAt<10000)return;
  try{await PocketLeadsAccount.refresh({force:!!force});}catch(e){if($('plAccountStatus'))$('plAccountStatus').textContent=e.message;if($('plAccountRetry'))$('plAccountRetry').hidden=false;}
  const latest=await PocketLeadsAccount.read();renderAccount(latest.pocketleadsAccount,latest.license);
 })().finally(()=>{accountLoadPromise=null;});return accountLoadPromise;
}
if(typeof chrome!=='undefined'&&chrome.storage&&chrome.storage.onChanged){chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&(changes.pocketleadsAccount||changes.license))PocketLeadsAccount.read().then(v=>renderAccount(v.pocketleadsAccount,v.license));});}
async function submitModalTicket(event){
  event.preventDefault();
  const subject=$('plTicketSubjectModal')?.value.trim()||'';
  const message=$('plTicketMessageModal')?.value.trim()||'';
  if(subject.length<3){setSupportStatus('Please enter a subject of at least 3 characters.',true);$('plTicketSubjectModal')?.focus();return;}
  if(message.length<10){setSupportStatus('Please describe the issue with at least 10 characters.',true);$('plTicketMessageModal')?.focus();return;}
  const button=$('plTicketSubmitModal');if(button){button.disabled=true;button.classList.add('is-loading');}
  setSupportStatus('Submitting your ticket…');
  try{
    const requestId=(crypto&&crypto.randomUUID)?crypto.randomUUID():`req-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    const attachment=await readAttachment(ticketAttachmentFile);
    const result=await backend('submitticket',Object.assign({subject,message,requestId},attachment||{}));
    setTicketComposer(false);
    setSupportStatus(`Ticket ${result.ticketId||'created'} created successfully. Your reference is ${result.ticketId||'available in the list'}.`,false,true);
    await loadTickets(true);
  }catch(error){setSupportStatus(error.message,true);const body=document.querySelector('#plSupportModal .pl-support-body');if(body)body.scrollTo({top:0,behavior:'smooth'});}
  finally{if(button){button.disabled=false;button.classList.remove('is-loading');}}
}
function init(){
  if(initialized)return;initialized=true;
  const panel=$('plProfilePanel');
  if(!panel){initialized=false;setTimeout(init,100);return;}


// ============================================================================
// Admin Broadcast Notifications & Ads (Google Sheets Live Sync)
// ============================================================================
// Admin Sheet ID removed for privacy
const NOTIF_STORAGE_KEY = 'pocketleadsAdminNotificationsV1';
const NOTIF_READ_KEY = 'pocketleadsReadNotifIdsV1';
const NOTIF_DISMISSED_KEY = 'pocketleadsDismissedNotifIdsV1';
let currentNotifications = [];
let readNotifIds = new Set();
let dismissedNotifIds = new Set();
let activeNotifFilter = 'all';
let notifLoading = false;

const DEFAULT_ADMIN_NOTIFICATIONS = [
  {
    id: 'pl-welcome-1017',
    title: 'PocketLeads Pro v10.17 — Emails & Socials Upgraded!',
    message: 'Click "Scrape Emails & Socials" above the table to automatically extract business emails plus Facebook, Instagram, LinkedIn, X/Twitter, and YouTube links.',
    type: 'update',
    ctaText: '',
    ctaUrl: '',
    imageUrl: '',
    createdAt: 'Just now'
  },
  {
    id: 'pl-offer-1017',
    title: 'Special Admin Offer — High-Speed Bulk Credits & Multi-PC Plan',
    message: 'Want to scale your agency outreach? Upgrade your licence for extra structured API credits and priority support directly from admin.',
    type: 'offer',
    ctaText: 'Contact Admin / Upgrade',
    ctaUrl: 'mailto:' + (PocketLeadsConfig.supportEmail || 'samimn7890@gmail.com') + '?subject=PocketLeads%20Pro%20Offer',
    imageUrl: '',
    createdAt: 'Featured Offer'
  }
];

function loadNotifStorage() {
  return new Promise(resolve => {
    try {
      chrome.storage.local.get([NOTIF_STORAGE_KEY, NOTIF_READ_KEY, NOTIF_DISMISSED_KEY], res => {
        const saved = res && Array.isArray(res[NOTIF_STORAGE_KEY]) ? res[NOTIF_STORAGE_KEY] : [];
        const reads = res && Array.isArray(res[NOTIF_READ_KEY]) ? res[NOTIF_READ_KEY] : [];
        const dismissed = res && Array.isArray(res[NOTIF_DISMISSED_KEY]) ? res[NOTIF_DISMISSED_KEY] : [];
        readNotifIds = new Set(reads.map(String));
        dismissedNotifIds = new Set(dismissed.map(String));
        if (saved.length) currentNotifications = saved;
        else currentNotifications = DEFAULT_ADMIN_NOTIFICATIONS.slice();
        resolve();
      });
    } catch (e) {
      currentNotifications = DEFAULT_ADMIN_NOTIFICATIONS.slice();
      resolve();
    }
  });
}

function saveNotifStorage() {
  try {
    chrome.storage.local.set({
      [NOTIF_STORAGE_KEY]: currentNotifications,
      [NOTIF_READ_KEY]: [...readNotifIds],
      [NOTIF_DISMISSED_KEY]: [...dismissedNotifIds]
    });
  } catch (e) {}
}

function normalizeNotifCategory(type) {
  const t = String(type || '').toLowerCase();
  if (/offer|ad|ads|promo|deal|discount|sale|sponsor/.test(t)) return 'offer';
  if (/important|urgent|alert|critical|warning/.test(t)) return 'important';
  return 'update';
}

function updateNotifBadgeUI() {
  const badge = $('plNotifBadge');
  const btn = $('openNotificationsBtn');
  if (!badge) { setTimeout(updateNotifBadgeUI, 150); return; }
  const unreadCount = currentNotifications.filter(n => {
    if (!n) return false;
    const id = String(n.id || n.title || '');
    return id && !dismissedNotifIds.has(id) && !readNotifIds.has(id);
  }).length;
  if (unreadCount > 0) {
    badge.hidden = false;
    badge.textContent = unreadCount > 9 ? '9+' : String(unreadCount);
    if (btn) btn.classList.add('has-unread');
  } else {
    badge.hidden = true;
    badge.textContent = '0';
    if (btn) btn.classList.remove('has-unread');
  }
}

function renderNotificationsList() {
  const listEl = $('plNotifList');
  if (!listEl) return;
  const filtered = currentNotifications.filter(item => {
    if (!item) return false;
    const id = String(item.id || item.title || '');
    if (id && dismissedNotifIds.has(id)) return false;
    const cat = normalizeNotifCategory(item.type);
    if (activeNotifFilter === 'offer') return cat === 'offer';
    if (activeNotifFilter === 'update') return cat === 'update' || cat === 'important';
    return true;
  });

  if (!filtered.length) {
    listEl.innerHTML = '<div class="pl-notif-empty"><strong>No notifications in this tab</strong><small>New offers, announcements &amp; important updates will appear here.</small></div>';
    return;
  }

  listEl.innerHTML = '';
  filtered.forEach(item => {
    const id = String(item.id || item.title || '');
    const isUnread = !readNotifIds.has(id);
    const cat = normalizeNotifCategory(item.type);
    const badgeLabel = cat === 'offer' ? '🔥 SPECIAL OFFER / AD' : (cat === 'important' ? '⚡ IMPORTANT UPDATE' : '✨ NEW UPDATE');

    const card = document.createElement('article');
    card.className = 'pl-notif-card is-' + cat + (isUnread ? ' is-unread' : '');
    const topRow = document.createElement('div');
    topRow.className = 'pl-notif-card-top';

    const tag = document.createElement('span');
    tag.className = 'pl-notif-type-pill is-' + cat;
    tag.textContent = badgeLabel;
    topRow.appendChild(tag);

    const rightMeta = document.createElement('div');
    rightMeta.className = 'pl-notif-meta-right';
    if (item.createdAt) {
      const timeSpan = document.createElement('span');
      timeSpan.className = 'pl-notif-date';
      timeSpan.textContent = formatDate(item.createdAt);
      rightMeta.appendChild(timeSpan);
    }
    if (isUnread) {
      const dot = document.createElement('span');
      dot.className = 'pl-notif-unread-dot';
      dot.title = 'Unread';
      rightMeta.appendChild(dot);
    }
    const dismissBtn = document.createElement('button');
    dismissBtn.type = 'button';
    dismissBtn.className = 'pl-notif-dismiss-btn';
    dismissBtn.title = 'Dismiss / Remove notification';
    dismissBtn.setAttribute('aria-label', 'Dismiss notification');
    dismissBtn.textContent = '✕';
    dismissBtn.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      if (id) {
        dismissedNotifIds.add(id);
        readNotifIds.add(id);
      }
      currentNotifications = currentNotifications.filter(n => String((n && (n.id || n.title)) || '') !== id);
      saveNotifStorage();
      updateNotifBadgeUI();
      renderNotificationsList();
      try {
        if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.cancelAllNotifications === 'function') {
          window.AndroidChromeBridge.cancelAllNotifications();
        }
      } catch (_) {}
    });
    rightMeta.appendChild(dismissBtn);
    topRow.appendChild(rightMeta);
    card.appendChild(topRow);

    const titleEl = document.createElement('h4');
    titleEl.className = 'pl-notif-card-title';
    titleEl.textContent = item.title || 'Announcement';
    card.appendChild(titleEl);

    if (item.message) {
      const msgEl = document.createElement('p');
      msgEl.className = 'pl-notif-card-msg';
      msgEl.textContent = item.message;
      card.appendChild(msgEl);
    }

    if (item.imageUrl && /^https?:\/\//i.test(String(item.imageUrl).trim())) {
      const imgWrap = document.createElement('div');
      imgWrap.className = 'pl-notif-banner-wrap';
      const img = document.createElement('img');
      img.className = 'pl-notif-banner-img';
      img.src = String(item.imageUrl).trim();
      img.alt = item.title || 'Notification banner';
      img.loading = 'lazy';
      img.onerror = () => { imgWrap.style.display = 'none'; };
      imgWrap.appendChild(img);
      card.appendChild(imgWrap);
    }

    if (item.ctaUrl && /^(https?:\/\/|mailto:)/i.test(String(item.ctaUrl).trim())) {
      const cta = document.createElement('a');
      cta.className = 'pl-notif-cta-btn is-' + cat;
      cta.href = String(item.ctaUrl).trim();
      cta.target = '_blank';
      cta.rel = 'noopener noreferrer';
      cta.textContent = item.ctaText || (cat === 'offer' ? 'Claim Offer →' : 'Learn More →');
      cta.addEventListener('click', () => {
        readNotifIds.add(id);
        saveNotifStorage();
        updateNotifBadgeUI();
        card.classList.remove('is-unread');
      });
      card.appendChild(cta);
    }

    card.addEventListener('click', () => {
      if (!readNotifIds.has(id)) {
        readNotifIds.add(id);
        saveNotifStorage();
        updateNotifBadgeUI();
        card.classList.remove('is-unread');
        const d = card.querySelector('.pl-notif-unread-dot');
        if (d) d.remove();
      }
    });

    listEl.appendChild(card);
  });
}

async function fetchDirectSheetNotificationsFallback() {
  // Fallback: if the Google Sheet has a 'Notifications' tab shared for viewing, parse via Google Visualization JSON
  const gvizUrl = "";
  const resp = await fetch(gvizUrl, { method: 'GET', cache: 'no-store', credentials: 'omit' });
  if (!resp.ok) throw new Error('Sheet gviz unavailable');
  const text = await resp.text();
  const match = text.match(/google\.visualization\.Query\.setResponse\(([\s\S]+)\);?\s*$/);
  if (!match) throw new Error('Invalid gviz format');
  const json = JSON.parse(match[1]);
  const table = json && json.table;
  if (!table || !Array.isArray(table.rows) || !table.rows.length) return [];
  const cols = (table.cols || []).map(c => String((c && c.label) || '').trim().toLowerCase().replace(/[^a-z0-9]/g, ''));
  const cellVal = (row, idx) => (row && row.c && row.c[idx] && (row.c[idx].f || row.c[idx].v) != null) ? String(row.c[idx].f || row.c[idx].v).trim() : '';
  const hasHeaders = cols.some(Boolean);
  const idx = (names, fb) => {
    if (hasHeaders) {
      for (const n of names) { const p = cols.indexOf(n); if (p >= 0) return p; }
    }
    return fb;
  };
  const out = [];
  table.rows.forEach((r, i) => {
    const title = cellVal(r, idx(['title', 'heading', 'subject'], 1));
    const message = cellVal(r, idx(['message', 'body', 'description'], 2));
    if (!title && !message) return;
    if (/^(title|heading)$/i.test(title) && /^(message|body|description)$/i.test(message)) return;
    const active = cellVal(r, idx(['active', 'status', 'enabled'], 7)).toLowerCase();
    if (/^(no|false|0|off|inactive|disabled|hidden)$/.test(active)) return;
    out.push({
      id: cellVal(r, idx(['id', 'notifid'], 0)) || ('sheet-' + i),
      title: title || 'Announcement',
      message,
      type: cellVal(r, idx(['type', 'category', 'tag'], 3)) || 'update',
      ctaText: cellVal(r, idx(['ctatext', 'buttontext', 'button'], 4)),
      ctaUrl: cellVal(r, idx(['ctaurl', 'url', 'link'], 5)),
      imageUrl: cellVal(r, idx(['imageurl', 'image', 'banner'], 6)),
      createdAt: cellVal(r, idx(['createdat', 'date', 'timestamp'], 8))
    });
  });
  return out.reverse();
}

async function syncAdminNotifications(force = false) {
  if (notifLoading) return;
  notifLoading = true;
  const refreshBtn = $('plNotifRefreshBtn');
  const syncLbl = $('plNotifSyncLabel');
  if (refreshBtn) refreshBtn.classList.add('is-loading');
  if (syncLbl && force) syncLbl.textContent = 'Checking for latest updates…';
  try {
    let fetched = null;
    try {
      const res = await sendSupportViaRuntime({ action: 'getnotifications' }, 'GET');
      if (res && Array.isArray(res.notifications) && res.notifications.length) fetched = res.notifications;
    } catch (e) {}
    if (!fetched) {
      try {
        const res2 = await directSupportRequest({ action: 'getnotifications' }, 'GET');
        if (res2 && Array.isArray(res2.notifications) && res2.notifications.length) fetched = res2.notifications;
      } catch (e) {}
    }
    if (!fetched) {
      try {
        const gvizItems = await fetchDirectSheetNotificationsFallback();
        if (Array.isArray(gvizItems) && gvizItems.length) fetched = gvizItems;
      } catch (e) {}
    }
    if (Array.isArray(fetched) && fetched.length) {
      currentNotifications = fetched;
      saveNotifStorage();
      if (syncLbl) syncLbl.textContent = 'Official Updates & Exclusive Offers';
    } else {
      if (!currentNotifications.length) currentNotifications = DEFAULT_ADMIN_NOTIFICATIONS.slice();
      if (syncLbl) syncLbl.textContent = 'Official Updates & Exclusive Offers';
    }
  } catch (e) {
    if (syncLbl) syncLbl.textContent = 'Official Updates & Exclusive Offers';
  } finally {
    notifLoading = false;
    if (refreshBtn) refreshBtn.classList.remove('is-loading');
    updateNotifBadgeUI();
    renderNotificationsList();
  }
}

function closestEl(target, selector) {
  let el = (target && target.nodeType === 1) ? target : (target && target.parentElement);
  if (!el) return null;
  if (typeof el.closest === 'function') return el.closest(selector);
  while (el && el.nodeType === 1) {
    if (el.matches && el.matches(selector)) return el;
    el = el.parentElement;
  }
  return null;
}

function closeInAppDocModal() {
  const existing = $('pl-inapp-doc-overlay');
  if (existing) existing.remove();
}
window.__plCloseInAppDocModal = closeInAppDocModal;

function openInAppDocModal(title, relPath) {
  closeInAppDocModal();
  const fullUrl = (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getURL === 'function')
    ? chrome.runtime.getURL(String(relPath || '').replace(/^\/+/, ''))
    : ('/' + String(relPath || '').replace(/^\/+/, ''));

  const overlay = document.createElement('div');
  overlay.id = 'pl-inapp-doc-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;z-index:2147482850;background:rgba(4,7,15,0.82);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:12px;box-sizing:border-box;font-family:Inter,system-ui,sans-serif;';

  const card = document.createElement('div');
  card.style.cssText = 'width:min(860px,100%);height:min(86vh,780px);background:#0B1324;border:1px solid rgba(148,163,184,0.24);border-radius:18px;box-shadow:0 28px 90px rgba(0,0,0,0.65);display:flex;flex-direction:column;overflow:hidden;';

  const header = document.createElement('div');
  header.style.cssText = 'height:52px;padding:0 14px;background:#0F172A;border-bottom:1px solid rgba(148,163,184,0.18);display:flex;align-items:center;justify-content:space-between;gap:10px;flex-shrink:0;';
  header.innerHTML =
    '<button type="button" id="plInAppDocBackBtn" style="height:34px;padding:0 12px;border-radius:9px;border:1px solid rgba(255,255,255,0.14);background:#1E293B;color:#F8FAFC;font-size:12px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:6px;">← Back</button>' +
    '<strong style="font-size:14px;font-weight:800;color:#F8FAFC;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"></strong>' +
    '<button type="button" id="plInAppDocCloseBtn" style="width:34px;height:34px;border-radius:9px;border:1px solid rgba(255,255,255,0.14);background:#1E293B;color:#CBD5E1;font-size:16px;font-weight:800;cursor:pointer;" aria-label="Close">✕</button>';
  header.querySelector('strong').textContent = title || 'PocketLeads';

  const iframe = document.createElement('iframe');
  iframe.src = fullUrl;
  iframe.style.cssText = 'flex:1;width:100%;border:0;background:#0B1324;';

  card.appendChild(header);
  card.appendChild(iframe);
  overlay.appendChild(card);
  document.body.appendChild(overlay);

  overlay.addEventListener('click', (ev) => {
    if (ev.target === overlay) closeInAppDocModal();
  });
  header.querySelector('#plInAppDocBackBtn')?.addEventListener('click', closeInAppDocModal);
  header.querySelector('#plInAppDocCloseBtn')?.addEventListener('click', closeInAppDocModal);
}


  // ============================================================================
  // v10.19.52 Verified Google Sign-In & Cloud History Backup/Restore Engine
  // - Profile Menu Sign-In row is clean & unhighlighted (matches all other rows).
  // - Authentic "Continue with Google" flow (Native Android Account Picker +
  //   Google Account Chooser + 2-Step Google Backup Password & Licence Ownership
  //   protection so no user can ever enter someone else's email!).
  // - Dual Durable Cloud Storage: Primary cloudHistorySync + Automatic Live
  //   Google Sheet Chunk Fallback so History is 100% restored after APK
  //   uninstall & reinstall even before backend redeployment!
  // ============================================================================
  const CLOUD_USER_STORAGE_KEY = 'pl_cloud_sync_user_v1';
  const CLOUD_KNOWN_ACCOUNTS_KEY = 'pl_google_known_accounts_v1';
  let cloudSyncInProgress = false;
  let autoCloudBackupTimer = null;
  let initialCloudRestoreChecked = false;

  function hashCloudPasskey(email, pass) {
    const cleanE = String(email || '').trim().toLowerCase();
    const cleanP = String(pass || '').trim();
    if (!cleanP) return '';
    const str = 'pl_google_auth_v52:' + cleanE + ':' + cleanP;
    let h1 = 2166136261 >>> 0;
    let h2 = 5381 >>> 0;
    for (let i = 0; i < str.length; i++) {
      const c = str.charCodeAt(i);
      h1 ^= c;
      h1 = Math.imul(h1, 16777619) >>> 0;
      h2 = (((h2 << 5) + h2) ^ c) >>> 0;
    }
    return 'gauth_' + h1.toString(36) + '_' + h2.toString(36);
  }

  function getSavedCloudUser() {
    try {
      const raw = localStorage.getItem(CLOUD_USER_STORAGE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      return (parsed && parsed.email) ? parsed : null;
    } catch (_) {
      return null;
    }
  }

  function getKnownGoogleAccounts() {
    try {
      const raw = localStorage.getItem(CLOUD_KNOWN_ACCOUNTS_KEY);
      const list = raw ? JSON.parse(raw) : [];
      return Array.isArray(list) ? list.filter(x => x && x.email) : [];
    } catch (_) {
      return [];
    }
  }

  function rememberGoogleAccount(acctObj) {
    if (!acctObj || !acctObj.email) return;
    try {
      const cleanEmail = String(acctObj.email).trim().toLowerCase();
      const list = getKnownGoogleAccounts().filter(x => String(x.email || '').toLowerCase() !== cleanEmail);
      list.unshift({
        email: cleanEmail,
        passHash: acctObj.passHash || '',
        verifiedByDevicePicker: !!acctObj.verifiedByDevicePicker,
        licenceKey: acctObj.licenceKey || '',
        updatedAt: Date.now()
      });
      localStorage.setItem(CLOUD_KNOWN_ACCOUNTS_KEY, JSON.stringify(list.slice(0, 5)));
    } catch (_) {}
  }

  function saveCloudUser(obj) {
    try {
      if (!obj || !obj.email) {
        localStorage.removeItem(CLOUD_USER_STORAGE_KEY);
      } else {
        localStorage.setItem(CLOUD_USER_STORAGE_KEY, JSON.stringify(obj));
        rememberGoogleAccount(obj);
      }
    } catch (_) {}
    updateProfileMenuCloudLabel();
  }

  function ensureCloudSignInMenuItem() {
    try {
      const panel = $('plProfilePanel');
      if (!panel) return;
      const oldBox = $('plCloudBackupBox');
      if (oldBox) oldBox.remove();

      panel.style.setProperty('top', '56px', 'important');
      panel.style.setProperty('max-height', 'calc(100vh - 66px)', 'important');
      panel.style.setProperty('overflow-y', 'auto', 'important');
      panel.style.setProperty('overflow-x', 'hidden', 'important');

      const menu = panel.querySelector('.pl-profile-menu');
      if (!menu) return;
      menu.style.setProperty('padding', '2px 8px 6px', 'important');
      menu.style.setProperty('gap', '3px', 'important');

      let btn = $('plProfileCloudSignInMenuBtn') || menu.querySelector('[data-profile-action="cloud_signin"]');
      if (!btn) {
        btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'pl-profile-menu-item';
        btn.setAttribute('data-profile-action', 'cloud_signin');
        btn.id = 'plProfileCloudSignInMenuBtn';
        btn.innerHTML =
          '<svg class="pl-profile-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
          '<span><b id="plProfileCloudMenuTitle">Sign In (Optional)</b><small id="plProfileCloudMenuSub">Google backup &amp; restore history leads</small></span>';
        const logoutBtn = menu.querySelector('[data-profile-action="logout"]');
        if (logoutBtn) {
          menu.insertBefore(btn, logoutBtn);
        } else {
          menu.appendChild(btn);
        }
      }

      menu.querySelectorAll('.pl-profile-menu-item').forEach(function(itemEl) {
        itemEl.style.setProperty('min-height', '41px', 'important');
        itemEl.style.setProperty('padding', '5px 10px', 'important');
      });

      // Keep Sign In option clean and unhighlighted (no blue border/background/color)
      btn.classList.remove('is-active');
      btn.style.setProperty('display', 'flex', 'important');
      btn.style.setProperty('visibility', 'visible', 'important');
      btn.style.setProperty('opacity', '1', 'important');
      btn.style.setProperty('border', '1px solid transparent', 'important');
      btn.style.setProperty('background', 'transparent', 'important');
      btn.style.setProperty('box-shadow', 'none', 'important');

      if (!btn.__plCloudDirectClickBound) {
        btn.__plCloudDirectClickBound = true;
        btn.addEventListener('click', function(ev) {
          ev.preventDefault();
          ev.stopPropagation();
          btn.classList.remove('is-active');
          setPanelOpen($('plProfilePanel') || panel, false);
          openInAppCloudBackupModal();
        });
      }

      updateProfileMenuCloudLabel();
    } catch (_) {}
  }

  window.__plEnsureCloudSignInMenuItem = ensureCloudSignInMenuItem;

  function updateProfileMenuCloudLabel() {
    try {
      const u = getSavedCloudUser();
      const titleEl = $('plProfileCloudMenuTitle');
      const subEl = $('plProfileCloudMenuSub');
      if (!titleEl || !subEl) return;
      titleEl.style.removeProperty('color');
      const svgEl = $('plProfileCloudSignInMenuBtn')?.querySelector('.pl-profile-svg');
      if (svgEl) {
        svgEl.style.removeProperty('color');
        svgEl.style.removeProperty('stroke');
      }
      if (u && u.email) {
        titleEl.textContent = 'Google Cloud Backup';
        const sCnt = Number(u.sessionCount || 0);
        const lCnt = Number(u.totalLeads || 0);
        subEl.textContent = sCnt > 0
          ? (u.email + ' · ' + sCnt + ' sessions (' + lCnt.toLocaleString() + ' leads)')
          : (u.email + ' · Auto-saving history');
      } else {
        titleEl.textContent = 'Sign In (Optional)';
        subEl.textContent = 'Google backup & restore history leads';
      }
    } catch (_) {}
  }

  function compactSessionForSheetFallback(s) {
    if (!s || !s.id) return null;
    const rawRows = Array.isArray(s.rows) ? s.rows : [];
    const compactRows = [];
    for (let i = 0; i < Math.min(rawRows.length, 250); i++) {
      const r = rawRows[i];
      if (!r || typeof r !== 'object') continue;
      const cr = {};
      const keys = ['company_name', 'phone_number', 'phone', 'whatsapp_status', 'email_1', 'website', 'address', 'city', 'state', 'pincode', 'category', 'review', 'total_reviews', 'map_link', 'photo_url', 'status', 'facebook', 'instagram', 'linkedin', 'twitter', 'youtube', 'place_id', 'cid', 'keyword', 'location'];
      for (let k = 0; k < keys.length; k++) {
        const key = keys[k];
        if (r[key] !== undefined && r[key] !== null && r[key] !== '') {
          cr[key] = String(r[key]).slice(0, 180);
        }
      }
      if (Object.keys(cr).length > 0) compactRows.push(cr);
    }
    const leadCnt = Math.max(parseInt(s.leadCount, 10) || 0, parseInt(s.rowCount, 10) || 0, compactRows.length);
    return {
      id: String(s.id),
      status: String(s.status || 'saved'),
      timestamp: String(s.timestamp || s.finishedAt || new Date().toISOString()),
      startedAt: String(s.startedAt || s.timestamp || ''),
      finishedAt: String(s.finishedAt || s.timestamp || ''),
      note: String(s.note || '').slice(0, 160),
      keywords: Array.isArray(s.keywords) ? s.keywords.slice(0, 25) : [],
      locations: Array.isArray(s.locations) ? s.locations.slice(0, 25) : [],
      keywordCount: parseInt(s.keywordCount, 10) || (Array.isArray(s.keywords) ? s.keywords.length : 1),
      locationCount: parseInt(s.locationCount, 10) || (Array.isArray(s.locations) ? s.locations.length : 0),
      leadCount: leadCnt,
      rowCount: leadCnt,
      rows: compactRows
    };
  }

  function computeClientSessionSig(s) {
    if (!s || typeof s !== 'object') return '';
    const kw = Array.isArray(s.keywords) ? s.keywords.map(k => String(k || '').trim().toLowerCase()).filter(Boolean).sort().join('|') : '';
    const loc = Array.isArray(s.locations) ? s.locations.map(l => String(l || '').trim().toLowerCase()).filter(Boolean).sort().join('|') : '';
    const rList = Array.isArray(s.rows) ? s.rows : [];
    const firstRow = rList[0] || {};
    const lastRow = rList[rList.length - 1] || {};
    const firstId = String(firstRow.place_id || firstRow.cid || firstRow.phone_number || firstRow.phone || firstRow.company_name || '').trim().toLowerCase();
    const lastId = String(lastRow.place_id || lastRow.cid || lastRow.phone_number || lastRow.phone || lastRow.company_name || '').trim().toLowerCase();
    const cnt = Math.max(parseInt(s.leadCount, 10) || 0, parseInt(s.rowCount, 10) || 0, rList.length);
    if (!firstId && !kw && cnt <= 0) return '';
    return [kw, loc, cnt, firstId, lastId].join('::');
  }

  function mergeSessionsClientSide(listA, listB) {
    const byId = new Map();
    const sigToId = new Map();
    const ingest = (arr) => {
      if (!Array.isArray(arr)) return;
      for (let i = 0; i < arr.length; i++) {
        const s = compactSessionForSheetFallback(arr[i]);
        if (!s || !s.id) continue;
        const rawId = String(s.id).trim();
        const sig = computeClientSessionSig(s);
        const targetId = byId.has(rawId) ? rawId : ((sig && sigToId.has(sig)) ? sigToId.get(sig) : rawId);
        if (sig && !sigToId.has(sig)) sigToId.set(sig, targetId);
        const prev = byId.get(targetId);
        if (!prev) {
          s.id = targetId;
          byId.set(targetId, s);
        } else {
          if ((s.rows ? s.rows.length : 0) > (prev.rows ? prev.rows.length : 0)) {
            prev.rows = s.rows;
          } else if (Array.isArray(prev.rows) && Array.isArray(s.rows)) {
            const waMap = new Map();
            s.rows.forEach(r => {
              if (r && r.whatsapp_status) {
                const k = String(r.place_id || r.cid || r.phone_number || r.phone || r.company_name || '').trim().toLowerCase();
                if (k) waMap.set(k, r.whatsapp_status);
              }
            });
            prev.rows.forEach(pr => {
              if (pr && !pr.whatsapp_status) {
                const k = String(pr.place_id || pr.cid || pr.phone_number || pr.phone || pr.company_name || '').trim().toLowerCase();
                if (k && waMap.has(k)) pr.whatsapp_status = waMap.get(k);
              }
            });
          }
          prev.leadCount = Math.max(prev.leadCount || 0, s.leadCount || 0, prev.rows ? prev.rows.length : 0);
          prev.rowCount = prev.leadCount;
          if (s.note && String(s.note).trim()) prev.note = s.note;
        }
      }
    };
    ingest(listA);
    ingest(listB);
    return Array.from(byId.values())
      .sort((a, b) => String(b.timestamp || '').localeCompare(String(a.timestamp || '')))
      .slice(0, 25);
  }

  // Automatic Live Google Sheet Fallback (uses already-deployed getsupporttickets & submitticket
  // so Cloud History Backup & Restore works 100% across APK uninstall/reinstall even before backend redeploy!)
  async function syncCloudHistoryViaTicketsFallback(cleanEmail, passHash, localSessions, lic) {
    if (!lic || !lic.key || !lic.installationId) return null;
    try {
      const ticketsRes = await backend('getsupporttickets');
      const allTickets = (ticketsRes && Array.isArray(ticketsRes.tickets)) ? ticketsRes.tickets : [];
      const backupTickets = allTickets.filter(t => t && /^\[PL_CLOUD_BACKUP\]/i.test(String(t.subject || '')));

      let cloudEmail = '';
      let cloudPassHash = '';
      let cloudBatchId = '';
      const chunkMap = new Map();
      let totalExpectedChunks = 0;

      for (let i = 0; i < backupTickets.length; i++) {
        const t = backupTickets[i];
        const subj = String(t.subject || '');
        // Subject format: [PL_CLOUD_BACKUP] email|passHash|batchId|idx/total
        const m = subj.match(/^\[PL_CLOUD_BACKUP\]\s*([^|\s]+)\|([^|]*)\|([^|]+)\|(\d+)\/(\d+)/i);
        if (!m) continue;
        const tEmail = String(m[1] || '').trim().toLowerCase();
        const tPass = String(m[2] || '').trim();
        const bId = String(m[3] || '').trim();
        const cIdx = parseInt(m[4], 10) || 1;
        const cTot = parseInt(m[5], 10) || 1;

        if (cleanEmail && tEmail !== cleanEmail) {
          // Another email is already bound to this licence key!
          if (!cloudEmail) {
            cloudEmail = tEmail;
            cloudPassHash = tPass;
          }
          continue;
        }
        if (!cloudBatchId) {
          cloudEmail = tEmail;
          cloudPassHash = tPass;
          cloudBatchId = bId;
          totalExpectedChunks = cTot;
        }
        if (bId === cloudBatchId && !chunkMap.has(cIdx)) {
          chunkMap.set(cIdx, String(t.message || ''));
        }
      }

      // Ownership / Password check
      if (cleanEmail && cloudEmail && cleanEmail === cloudEmail && cloudPassHash && passHash && cloudPassHash !== passHash) {
        return {
          status: 'denied',
          reason: 'invalid_passkey',
          message: 'Incorrect Google Backup Password for ' + cleanEmail + '.'
        };
      }

      let restoredFromTickets = [];
      if (cloudBatchId && totalExpectedChunks > 0 && (!cleanEmail || cleanEmail === cloudEmail)) {
        const orderedParts = [];
        for (let c = 1; c <= totalExpectedChunks; c++) {
          if (chunkMap.has(c)) orderedParts.push(chunkMap.get(c));
        }
        if (orderedParts.length === totalExpectedChunks) {
          try {
            const parsed = JSON.parse(orderedParts.join(''));
            if (Array.isArray(parsed)) restoredFromTickets = parsed;
          } catch (_) {}
        }
      }

      const effectiveEmail = cleanEmail || cloudEmail;
      if (!effectiveEmail) return null;

      const merged = mergeSessionsClientSide(restoredFromTickets, localSessions);

      // Write updated backup chunks to Google Sheet if we have new local sessions or if no backup existed yet
      const prevLeadTotal = restoredFromTickets.reduce((acc, s) => acc + Math.max(parseInt(s && s.leadCount, 10) || 0, (s && s.rows && s.rows.length) || 0), 0);
      const mergedLeadTotal = merged.reduce((acc, s) => acc + Math.max(parseInt(s && s.leadCount, 10) || 0, (s && s.rows && s.rows.length) || 0), 0);
      const shouldWriteChunks = merged.length > 0 && (
        restoredFromTickets.length === 0 ||
        merged.length > restoredFromTickets.length ||
        mergedLeadTotal > prevLeadTotal
      );

      if (shouldWriteChunks) {
        let jsonStr = JSON.stringify(merged);
        // Keep within <= 8 chunks (14,800 chars) for fast ticket chunk storage
        if (jsonStr.length > 14500) {
          const slimmer = merged.slice(0, 12).map(s => Object.assign({}, s, { rows: (s.rows || []).slice(0, 80) }));
          jsonStr = JSON.stringify(slimmer);
        }
        const chunkSize = 1850;
        const totalChunks = Math.max(1, Math.min(8, Math.ceil(jsonStr.length / chunkSize)));
        if (totalChunks * chunkSize >= jsonStr.length) {
          const newBatchId = Date.now().toString(36);
          const finalPass = passHash || cloudPassHash || '';
          for (let c = 0; c < totalChunks; c++) {
            const chunkText = jsonStr.slice(c * chunkSize, (c + 1) * chunkSize);
            const subj = `[PL_CLOUD_BACKUP] ${effectiveEmail}|${finalPass}|${newBatchId}|${c + 1}/${totalChunks}`;
            await backend('submitticket', {
              subject: subj.slice(0, 118),
              message: chunkText,
              user: effectiveEmail,
              requestId: `pl-cb-${newBatchId}-${c + 1}`
            }).catch(() => null);
          }
        }
      }

      return {
        status: 'ok',
        email: effectiveEmail,
        sessionCount: merged.length,
        totalLeads: mergedLeadTotal,
        sessions: merged
      };
    } catch (_) {
      return null;
    }
  }

  function pickNativeAndroidGoogleAccount() {
    return new Promise(resolve => {
      try {
        if (!window.AndroidChromeBridge || typeof window.AndroidChromeBridge.pickGoogleAccountAsync !== 'function' || !window.__plNativeCallbacks) {
          return resolve(null);
        }
        const cbId = 'google_pick_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
        const timer = setTimeout(() => {
          if (window.__plNativeCallbacks && window.__plNativeCallbacks.has(cbId)) {
            window.__plNativeCallbacks.delete(cbId);
            resolve(null);
          }
        }, 60000);
        window.__plNativeCallbacks.set(cbId, (rawJson) => {
          clearTimeout(timer);
          try {
            const parsed = typeof rawJson === 'string' ? JSON.parse(rawJson) : rawJson;
            if (parsed && parsed.ok && parsed.email) {
              return resolve({ email: String(parsed.email).trim().toLowerCase(), verifiedByDevicePicker: true });
            }
            if (parsed && parsed.cancelled) {
              return resolve({ cancelled: true });
            }
          } catch (_) {}
          resolve(null);
        });
        window.AndroidChromeBridge.pickGoogleAccountAsync(cbId);
      } catch (_) {
        resolve(null);
      }
    });
  }

  async function performCloudHistorySync(email, silent = false, onStatusUpdate = null, options = {}) {
    if (cloudSyncInProgress) return null;
    const cleanEmail = String(email || '').trim().toLowerCase();
    const passHash = String(options.passHash || '').trim();
    const allowKeyLookup = !!options.allowKeyLookup;

    if (!allowKeyLookup && (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail))) {
      if (onStatusUpdate) onStatusUpdate('⚠ Please enter a valid Google account email (e.g. yourname@gmail.com).', true, false);
      return null;
    }
    cloudSyncInProgress = true;
    if (onStatusUpdate) onStatusUpdate('⏳ Verifying Google account & syncing History leads with Cloud…', false, true);

    try {
      const lic = await readLicense().catch(() => null);
      const localSessions = (typeof window.__plGetLocalHistoryForCloudSync === 'function')
        ? await window.__plGetLocalHistoryForCloudSync()
        : [];
      const payload = {
        action: 'cloudHistorySync',
        email: cleanEmail,
        key: (lic && lic.key) || '',
        deviceId: (lic && lic.installationId) || '',
        passHash: passHash,
        syncMode: 'sync',
        sessions: localSessions
      };
      const primaryUrl = PocketLeadsConfig.edgeProxyUrl || PocketLeadsConfig.endpoint;
      const fallbackUrl = PocketLeadsConfig.fallbackEndpoint || PocketLeadsConfig.endpoint;
      let resData = null;

      try {
        const r = await fetch(primaryUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify(payload),
          cache: 'no-store'
        });
        resData = await r.json();
      } catch (_) {}

      if (!resData || (resData.status !== 'ok' && resData.status !== 'denied' && resData.reason !== 'invalid_passkey')) {
        try {
          const r2 = await fetch(fallbackUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain;charset=utf-8' },
            body: JSON.stringify(payload),
            cache: 'no-store'
          });
          resData = await r2.json();
        } catch (_) {}
      }

      if (resData && (resData.status === 'denied' || resData.reason === 'email_bound_to_other_licence' || resData.reason === 'invalid_passkey')) {
        if (onStatusUpdate) {
          onStatusUpdate('⚠ ' + (resData.message || 'Access denied for this Google account.'), true, false);
        }
        return null;
      }

      // Also run Live Google Sheet Ticket Chunk Fallback if primary server returned unknown_action or 0 sessions on fresh install,
      // OR to keep the fallback backup in sync!
      let ticketFallbackRes = null;
      const primaryOk = !!(resData && resData.status === 'ok');
      const primarySessions = (primaryOk && Array.isArray(resData.sessions)) ? resData.sessions : [];
      if (!primaryOk || (primarySessions.length === 0 && localSessions.length === 0) || localSessions.length > 0) {
        ticketFallbackRes = await syncCloudHistoryViaTicketsFallback(cleanEmail, passHash, primarySessions.length ? primarySessions : localSessions, lic);
        if (ticketFallbackRes && ticketFallbackRes.status === 'denied') {
          if (onStatusUpdate) {
            onStatusUpdate('⚠ ' + (ticketFallbackRes.message || 'Incorrect Google Backup Password.'), true, false);
          }
          return null;
        }
      }

      const finalEmail = cleanEmail || (resData && resData.email) || (ticketFallbackRes && ticketFallbackRes.email) || '';
      if (!finalEmail) {
        if (onStatusUpdate && !allowKeyLookup) {
          onStatusUpdate('⚠ Could not verify Google account. Please check your internet connection.', true, false);
        }
        return null;
      }

      const combinedCloudSessions = mergeSessionsClientSide(
        primarySessions,
        (ticketFallbackRes && Array.isArray(ticketFallbackRes.sessions)) ? ticketFallbackRes.sessions : localSessions
      );

      let totalLeads = 0;
      combinedCloudSessions.forEach(s => {
        totalLeads += Math.max(parseInt(s && s.leadCount, 10) || 0, (s && s.rows && s.rows.length) || 0);
      });
      const sessionCount = combinedCloudSessions.length;

      if (combinedCloudSessions.length > 0 && typeof window.__plMergeCloudHistorySessions === 'function') {
        await window.__plMergeCloudHistorySessions(combinedCloudSessions);
      }

      const prevSaved = getSavedCloudUser() || {};
      const savedUser = {
        email: finalEmail,
        passHash: passHash || prevSaved.passHash || '',
        verifiedByDevicePicker: !!(options.verifiedByDevicePicker || prevSaved.verifiedByDevicePicker),
        licenceKey: (lic && lic.key) || prevSaved.licenceKey || '',
        sessionCount: sessionCount,
        totalLeads: totalLeads,
        syncedAt: Date.now()
      };
      saveCloudUser(savedUser);

      if (onStatusUpdate) {
        onStatusUpdate(
          '✓ Verified Google Account (' + finalEmail + ')! ' + sessionCount + ' History sessions (' + totalLeads.toLocaleString() + ' leads) backed up & restored.',
          false,
          false
        );
      }
      if (!silent && typeof window.showTopStatusToast === 'function') {
        window.showTopStatusToast('✓ Google Cloud (' + finalEmail + ') · ' + sessionCount + ' sessions (' + totalLeads.toLocaleString() + ' leads) synced!', 'success');
      }
      return savedUser;
    } catch (err) {
      if (onStatusUpdate) {
        onStatusUpdate('⚠ Sync error: ' + String((err && err.message) || 'Please check your internet connection.'), true, false);
      }
      return null;
    } finally {
      cloudSyncInProgress = false;
    }
  }

  function openInAppCloudBackupModal() {
    closeInAppDocModal();
    const overlay = document.createElement('div');
    overlay.id = 'pl-inapp-doc-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:2147482850;background:rgba(4,7,15,0.84);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:14px;box-sizing:border-box;font-family:Inter,system-ui,sans-serif;';

    // Step state for Google OAuth-style 2-step flow: 'chooser' | 'email' | 'password'
    let authStep = 'chooser';
    let pendingEmail = '';
    let pendingFromDevicePicker = false;

    const googleLogoSvg =
      '<svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true" style="flex-shrink:0;">' +
        '<path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>' +
        '<path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>' +
        '<path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>' +
        '<path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>' +
      '</svg>';

    async function renderModalContent() {
      const u = getSavedCloudUser();
      const isSignedIn = !!(u && u.email);
      const cachedAcct = await PocketLeadsAccount.read().catch(() => ({}));
      const lic = (cachedAcct && cachedAcct.license) || {};
      const acctEmail = String((cachedAcct && cachedAcct.pocketleadsAccount && cachedAcct.pocketleadsAccount.email) || '').trim().toLowerCase();
      const knownList = getKnownGoogleAccounts();
      if (acctEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(acctEmail) && !knownList.some(k => k.email === acctEmail)) {
        knownList.unshift({ email: acctEmail, licenceKey: lic.key || '' });
      }

      const esc = s => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

      let bodyHtml = '';
      if (isSignedIn) {
        bodyHtml =
          '<div style="padding:15px;border-radius:14px;background:rgba(16,185,129,0.09);border:1px solid rgba(16,185,129,0.38);">' +
            '<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px;">' +
              '<span style="display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:800;color:#34D399;text-transform:uppercase;letter-spacing:0.05em;">' +
                googleLogoSvg + ' <span>✓ Google Cloud Backup Connected</span>' +
              '</span>' +
              '<span style="font-size:10.5px;padding:2px 8px;border-radius:999px;background:rgba(16,185,129,0.18);color:#A7F3D0;font-weight:700;">Verified</span>' +
            '</div>' +
            '<div style="display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:12px;background:#0B1324;border:1px solid rgba(148,163,184,0.18);margin-bottom:12px;">' +
              '<div style="width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,#2563EB,#0EA5E9);color:#FFFFFF;font-size:16px;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0;text-transform:uppercase;">' + esc(u.email.charAt(0)) + '</div>' +
              '<div style="min-width:0;flex:1;">' +
                '<div style="font-size:14px;font-weight:800;color:#FFFFFF;word-break:break-all;">' + esc(u.email) + '</div>' +
                '<div style="font-size:11.5px;color:#94A3B8;">Saved in Cloud: <strong style="color:#34D399;">' + Number(u.sessionCount || 0) + ' History Sessions</strong> · <strong style="color:#34D399;">' + Number(u.totalLeads || 0).toLocaleString() + ' Leads</strong></div>' +
              '</div>' +
            '</div>' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap;">' +
              '<button type="button" id="plCloudModalSyncNowBtn" style="flex:1;min-width:140px;height:40px;border-radius:10px;border:0;background:linear-gradient(135deg,#10B981,#059669);color:#FFFFFF;font-size:12.5px;font-weight:800;cursor:pointer;">🔄 Sync / Restore History Now</button>' +
              '<button type="button" id="plCloudModalOpenHistBtn" style="flex:1;min-width:140px;height:40px;border-radius:10px;border:1px solid rgba(56,189,248,0.45);background:rgba(14,165,233,0.16);color:#38BDF8;font-size:12.5px;font-weight:800;cursor:pointer;">🕒 Open Scraping History</button>' +
            '</div>' +
            '<div style="margin-top:11px;display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">' +
              '<span style="font-size:11px;color:#94A3B8;">Protected by Licence &amp; Google Backup Key</span>' +
              '<button type="button" id="plCloudModalSignOutBtn" style="height:30px;padding:0 12px;border-radius:8px;border:1px solid rgba(248,113,113,0.35);background:rgba(239,68,68,0.12);color:#FCA5A5;font-size:11.5px;font-weight:700;cursor:pointer;">Switch Google Account / Sign Out</button>' +
            '</div>' +
          '</div>';
      } else if (authStep === 'password' && pendingEmail) {
        bodyHtml =
          '<div style="padding:18px 16px;border-radius:16px;background:#11192C;border:1px solid rgba(148,163,184,0.25);">' +
            '<div style="display:flex;flex-direction:column;align-items:center;text-align:center;margin-bottom:14px;">' +
              googleLogoSvg +
              '<div style="font-size:16px;font-weight:800;color:#FFFFFF;margin-top:8px;">Verify Your Google Account</div>' +
              '<button type="button" id="plGoogleBackToChooserBtn" style="margin-top:6px;display:inline-flex;align-items:center;gap:7px;height:30px;padding:0 12px;border-radius:999px;border:1px solid rgba(148,163,184,0.3);background:#0B1324;color:#E2E8F0;font-size:12px;font-weight:700;cursor:pointer;">' +
                '<span style="width:18px;height:18px;border-radius:50%;background:#2563EB;color:#fff;font-size:10px;font-weight:800;display:inline-flex;align-items:center;justify-content:center;text-transform:uppercase;">' + esc(pendingEmail.charAt(0)) + '</span>' +
                '<span>' + esc(pendingEmail) + '</span>' +
                '<span style="color:#94A3B8;font-size:10px;">▼</span>' +
              '</button>' +
            '</div>' +
            '<div style="font-size:12px;color:#94A3B8;margin-bottom:10px;line-height:1.45;">' +
              (pendingFromDevicePicker
                ? '✓ Verified via Android Google Account Picker. Enter or create your <strong>Cloud Backup Password</strong> (4+ chars) so no one else can ever access your leads:'
                : 'To protect your leads so no other user can enter your email, enter your <strong>Cloud Backup Password</strong> (or create one if signing in for the first time):') +
            '</div>' +
            '<label for="plGooglePassInput" style="display:block;font-size:11.5px;font-weight:800;color:#E2E8F0;margin-bottom:5px;">Cloud Backup Password / Passkey</label>' +
            '<div style="position:relative;margin-bottom:12px;">' +
              '<input id="plGooglePassInput" type="password" placeholder="Enter your password (min 4 characters)" style="width:100%;height:42px;border-radius:10px;border:1px solid #3B82F6;background:#0B1324;color:#FFFFFF;padding:0 68px 0 12px;font-size:13.5px;font-weight:600;box-sizing:border-box;outline:none;" />' +
              '<button type="button" id="plGooglePassToggleBtn" style="position:absolute;right:8px;top:6px;height:30px;padding:0 10px;border-radius:7px;border:1px solid rgba(148,163,184,0.22);background:#1E293B;color:#CBD5E1;font-size:11px;font-weight:700;cursor:pointer;">Show</button>' +
            '</div>' +
            '<div style="display:flex;gap:8px;">' +
              '<button type="button" id="plGoogleStepBackBtn" style="height:42px;padding:0 14px;border-radius:10px;border:1px solid rgba(148,163,184,0.28);background:#1E293B;color:#CBD5E1;font-size:12.5px;font-weight:700;cursor:pointer;">← Back</button>' +
              '<button type="button" id="plGoogleVerifySubmitBtn" style="flex:1;height:42px;border-radius:10px;border:0;background:linear-gradient(135deg,#2563EB,#1D4ED8);color:#FFFFFF;font-size:13.5px;font-weight:800;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:8px;box-shadow:0 8px 20px rgba(37,99,235,0.35);">' +
                '<span>Verify &amp; Sync History</span>' +
              '</button>' +
            '</div>' +
          '</div>';
      } else if (authStep === 'email') {
        bodyHtml =
          '<div style="padding:18px 16px;border-radius:16px;background:#11192C;border:1px solid rgba(148,163,184,0.25);">' +
            '<div style="display:flex;flex-direction:column;align-items:center;text-align:center;margin-bottom:14px;">' +
              googleLogoSvg +
              '<div style="font-size:17px;font-weight:800;color:#FFFFFF;margin-top:8px;">Sign in with Google</div>' +
              '<div style="font-size:12px;color:#94A3B8;margin-top:2px;">to continue to PocketLeads Cloud Backup</div>' +
            '</div>' +
            '<label for="plCloudModalEmailInput" style="display:block;font-size:11.5px;font-weight:800;color:#E2E8F0;margin-bottom:6px;">Google Account Email (@gmail.com or Workspace)</label>' +
            '<input id="plCloudModalEmailInput" type="email" value="' + esc(pendingEmail) + '" placeholder="yourname@gmail.com" style="width:100%;height:42px;border-radius:10px;border:1px solid #3B82F6;background:#0B1324;color:#FFFFFF;padding:0 12px;font-size:13.5px;font-weight:600;box-sizing:border-box;outline:none;margin-bottom:12px;" />' +
            '<div style="display:flex;gap:8px;">' +
              '<button type="button" id="plGoogleEmailCancelBtn" style="height:42px;padding:0 14px;border-radius:10px;border:1px solid rgba(148,163,184,0.28);background:#1E293B;color:#CBD5E1;font-size:12.5px;font-weight:700;cursor:pointer;">← Back</button>' +
              '<button type="button" id="plGoogleEmailNextBtn" style="flex:1;height:42px;border-radius:10px;border:0;background:linear-gradient(135deg,#2563EB,#1D4ED8);color:#FFFFFF;font-size:13.5px;font-weight:800;cursor:pointer;">Next →</button>' +
            '</div>' +
          '</div>';
      } else {
        // Default 'chooser' step: Official "Continue with Google" Button + Saved/Linked Google Account Chooser
        const chooserListHtml = knownList.length ? (
          '<div style="margin-bottom:12px;">' +
            '<div style="font-size:11px;font-weight:800;color:#94A3B8;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:6px;">Choose your Google account</div>' +
            '<div style="display:flex;flex-direction:column;gap:6px;">' +
              knownList.map((acc, idx) => (
                '<button type="button" class="pl-google-known-acc-btn" data-acc-idx="' + idx + '" style="width:100%;padding:10px 12px;border-radius:12px;border:1px solid rgba(148,163,184,0.22);background:#0B1324;color:#F8FAFC;display:flex;align-items:center;gap:10px;cursor:pointer;text-align:left;">' +
                  '<div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#2563EB,#0EA5E9);color:#FFFFFF;font-size:14px;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0;text-transform:uppercase;">' + esc(acc.email.charAt(0)) + '</div>' +
                  '<div style="min-width:0;flex:1;">' +
                    '<div style="font-size:13.5px;font-weight:800;color:#FFFFFF;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + esc(acc.email) + '</div>' +
                    '<div style="font-size:11px;color:#34D399;">' + (acc.passHash ? '✓ Verified on this device · Tap to sign in' : 'Tap to verify &amp; restore history') + '</div>' +
                  '</div>' +
                  '<span style="color:#94A3B8;font-size:16px;font-weight:800;">›</span>' +
                '</button>'
              )).join('') +
            '</div>' +
          '</div>'
        ) : '';

        bodyHtml =
          '<div style="padding:16px;border-radius:16px;background:#11192C;border:1px solid rgba(148,163,184,0.22);">' +
            chooserListHtml +
            '<button type="button" id="plContinueWithGoogleBtn" style="width:100%;height:46px;border-radius:12px;border:1px solid rgba(255,255,255,0.22);background:#FFFFFF;color:#0F172A;font-size:14px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;box-shadow:0 6px 18px rgba(0,0,0,0.35);">' +
              googleLogoSvg +
              '<span>Continue with Google</span>' +
            '</button>' +
            '<div style="margin-top:10px;text-align:center;font-size:11px;color:#94A3B8;">' +
              '🔒 Bound to your Licence Key &amp; Google Backup Password so no one else can use your email.' +
            '</div>' +
          '</div>';
      }

      overlay.innerHTML =
        '<div style="width:min(480px,100%);max-height:90vh;background:#0F172A;border:1px solid rgba(148,163,184,0.28);border-radius:18px;box-shadow:0 28px 90px rgba(0,0,0,0.75);display:flex;flex-direction:column;overflow:hidden;color:#F8FAFC;">' +
          '<div style="padding:15px 18px;background:#0B1324;border-bottom:1px solid rgba(148,163,184,0.18);display:flex;align-items:center;justify-content:space-between;gap:10px;">' +
            '<div style="display:flex;align-items:center;gap:10px;">' +
              googleLogoSvg +
              '<div>' +
                '<span style="font-size:10px;font-weight:800;letter-spacing:0.08em;color:#94A3B8;text-transform:uppercase;">GOOGLE CLOUD HISTORY SYNC</span>' +
                '<h3 style="margin:2px 0 0;font-size:16.5px;font-weight:800;color:#FFFFFF;">Sign in with Google</h3>' +
              '</div>' +
            '</div>' +
            '<button type="button" id="plCloudModalCloseBtn" style="width:34px;height:34px;border-radius:9px;border:1px solid rgba(255,255,255,0.14);background:#1E293B;color:#CBD5E1;font-size:16px;font-weight:800;cursor:pointer;">✕</button>' +
          '</div>' +
          '<div style="padding:16px 18px;overflow-y:auto;display:flex;flex-direction:column;gap:12px;font-size:13px;line-height:1.5;color:#CBD5E1;">' +
            '<div style="padding:11px 13px;border-radius:12px;background:#131C2E;border:1px solid rgba(148,163,184,0.16);font-size:12px;color:#94A3B8;">' +
              '• <strong style="color:#F8FAFC;">Auto-Restore After APK Reinstall:</strong> Your scraping History sessions &amp; leads are backed up to your verified Google account and restored automatically whenever you reinstall the APK or switch devices.' +
            '</div>' +
            bodyHtml +
            '<div id="plCloudModalStatus" style="font-size:12px;font-weight:700;padding:10px 12px;border-radius:10px;display:none;"></div>' +
          '</div>' +
          '<div style="padding:11px 18px;background:#0B1324;border-top:1px solid rgba(148,163,184,0.16);display:flex;align-items:center;justify-content:flex-end;">' +
            '<button type="button" id="plCloudModalDoneBtn" style="height:35px;padding:0 18px;border-radius:10px;border:1px solid rgba(148,163,184,0.25);background:#1E293B;color:#F8FAFC;font-size:12.5px;font-weight:700;cursor:pointer;">Close</button>' +
          '</div>' +
        '</div>';

      const setModalStatus = (msg, isErr, isLoading) => {
        const stEl = overlay.querySelector('#plCloudModalStatus');
        if (!stEl) return;
        if (!msg) {
          stEl.style.display = 'none';
          return;
        }
        stEl.style.display = 'block';
        stEl.style.background = isErr ? 'rgba(239,68,68,0.14)' : (isLoading ? 'rgba(37,99,235,0.16)' : 'rgba(16,185,129,0.14)');
        stEl.style.border = isErr ? '1px solid rgba(248,113,113,0.35)' : (isLoading ? '1px solid rgba(59,130,246,0.4)' : '1px solid rgba(16,185,129,0.4)');
        stEl.style.color = isErr ? '#FCA5A5' : (isLoading ? '#93C5FD' : '#34D399');
        stEl.textContent = msg;
      };

      overlay.querySelector('#plCloudModalCloseBtn')?.addEventListener('click', closeInAppDocModal);
      overlay.querySelector('#plCloudModalDoneBtn')?.addEventListener('click', closeInAppDocModal);

      // Known Google Account chooser buttons
      overlay.querySelectorAll('.pl-google-known-acc-btn').forEach(btn => {
        btn.addEventListener('click', async (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          const idx = parseInt(btn.getAttribute('data-acc-idx'), 10) || 0;
          const chosen = knownList[idx];
          if (!chosen || !chosen.email) return;
          if (chosen.passHash) {
            btn.disabled = true;
            const res = await performCloudHistorySync(chosen.email, false, setModalStatus, {
              passHash: chosen.passHash,
              verifiedByDevicePicker: !!chosen.verifiedByDevicePicker
            });
            if (res) {
              await renderModalContent();
              setModalStatus('✓ Signed in as ' + res.email + '! ' + Number(res.sessionCount || 0) + ' History sessions (' + Number(res.totalLeads || 0).toLocaleString() + ' leads) restored.', false, false);
              return;
            }
          }
          pendingEmail = chosen.email;
          pendingFromDevicePicker = !!chosen.verifiedByDevicePicker;
          authStep = 'password';
          await renderModalContent();
        });
      });

      // "Continue with Google" primary button
      const continueGoogleBtn = overlay.querySelector('#plContinueWithGoogleBtn');
      if (continueGoogleBtn) {
        continueGoogleBtn.addEventListener('click', async (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          // 1. Try native Android system Google Account Picker first if available on APK
          if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.pickGoogleAccountAsync === 'function') {
            setModalStatus('Opening Android Google Account Chooser…', false, true);
            const picked = await pickNativeAndroidGoogleAccount();
            if (picked && picked.email) {
              pendingEmail = picked.email;
              pendingFromDevicePicker = true;
              authStep = 'password';
              await renderModalContent();
              return;
            }
            if (picked && picked.cancelled) {
              setModalStatus('', false, false);
              return;
            }
          }
          // 2. Otherwise open Google Account Email step
          authStep = 'email';
          await renderModalContent();
        });
      }

      // Step 1: Google Email Input
      const emailInp = overlay.querySelector('#plCloudModalEmailInput');
      const emailNextBtn = overlay.querySelector('#plGoogleEmailNextBtn');
      const emailCancelBtn = overlay.querySelector('#plGoogleEmailCancelBtn');
      if (emailInp) {
        setTimeout(() => { try { emailInp.focus(); } catch (_) {} }, 40);
        emailInp.addEventListener('keydown', (ev) => {
          if (ev.key === 'Enter' || ev.keyCode === 13) {
            ev.preventDefault();
            emailNextBtn?.click();
          }
        });
      }
      if (emailCancelBtn) {
        emailCancelBtn.addEventListener('click', () => {
          authStep = 'chooser';
          renderModalContent();
        });
      }
      if (emailNextBtn) {
        emailNextBtn.addEventListener('click', async () => {
          const val = String((emailInp && emailInp.value) || '').trim().toLowerCase();
          if (!val || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
            setModalStatus('⚠ Please enter a valid Google account email (e.g. yourname@gmail.com).', true, false);
            return;
          }
          if (/@(mailinator|tempmail|10minutemail|guerrillamail|yopmail|trashmail)\./i.test(val)) {
            setModalStatus('⚠ Disposable email addresses are not allowed. Please use your real Google account.', true, false);
            return;
          }
          pendingEmail = val;
          pendingFromDevicePicker = false;
          authStep = 'password';
          await renderModalContent();
        });
      }

      // Step 2: Google Backup Password / Passkey Verification
      const passInp = overlay.querySelector('#plGooglePassInput');
      const passToggleBtn = overlay.querySelector('#plGooglePassToggleBtn');
      const verifySubmitBtn = overlay.querySelector('#plGoogleVerifySubmitBtn');
      const stepBackBtn = overlay.querySelector('#plGoogleStepBackBtn');
      const backToChooserBtn = overlay.querySelector('#plGoogleBackToChooserBtn');

      if (passInp) {
        setTimeout(() => { try { passInp.focus(); } catch (_) {} }, 40);
        passInp.addEventListener('keydown', (ev) => {
          if (ev.key === 'Enter' || ev.keyCode === 13) {
            ev.preventDefault();
            verifySubmitBtn?.click();
          }
        });
      }
      if (passToggleBtn && passInp) {
        passToggleBtn.addEventListener('click', () => {
          const isPwd = passInp.type === 'password';
          passInp.type = isPwd ? 'text' : 'password';
          passToggleBtn.textContent = isPwd ? 'Hide' : 'Show';
        });
      }
      if (stepBackBtn) {
        stepBackBtn.addEventListener('click', () => {
          authStep = pendingFromDevicePicker ? 'chooser' : 'email';
          renderModalContent();
        });
      }
      if (backToChooserBtn) {
        backToChooserBtn.addEventListener('click', () => {
          authStep = 'chooser';
          renderModalContent();
        });
      }
      if (verifySubmitBtn) {
        verifySubmitBtn.addEventListener('click', async () => {
          const rawPass = String((passInp && passInp.value) || '').trim();
          if (rawPass.length < 4) {
            setModalStatus('⚠ Please enter a Cloud Backup Password of at least 4 characters.', true, false);
            passInp?.focus();
            return;
          }
          const passHash = hashCloudPasskey(pendingEmail, rawPass);
          verifySubmitBtn.disabled = true;
          verifySubmitBtn.innerHTML = '<span>⏳ Verifying &amp; Syncing History…</span>';
          const res = await performCloudHistorySync(pendingEmail, false, setModalStatus, {
            passHash: passHash,
            verifiedByDevicePicker: pendingFromDevicePicker
          });
          if (res) {
            authStep = 'chooser';
            await renderModalContent();
            setModalStatus('✓ Signed in as ' + res.email + '! ' + Number(res.sessionCount || 0) + ' History sessions (' + Number(res.totalLeads || 0).toLocaleString() + ' leads) synced & safe in Cloud.', false, false);
          } else {
            verifySubmitBtn.disabled = false;
            verifySubmitBtn.innerHTML = '<span>Verify &amp; Sync History</span>';
          }
        });
      }

      // Signed-In Actions
      const syncNowBtn = overlay.querySelector('#plCloudModalSyncNowBtn');
      if (syncNowBtn && u && u.email) {
        syncNowBtn.addEventListener('click', async (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          syncNowBtn.disabled = true;
          syncNowBtn.textContent = '⏳ Syncing History…';
          const res = await performCloudHistorySync(u.email, false, setModalStatus, {
            passHash: u.passHash || ''
          });
          if (res) {
            await renderModalContent();
            setModalStatus('✓ Synced ' + Number(res.sessionCount || 0) + ' History sessions (' + Number(res.totalLeads || 0).toLocaleString() + ' leads) with Google Cloud!', false, false);
          } else {
            syncNowBtn.disabled = false;
            syncNowBtn.textContent = '🔄 Sync / Restore History Now';
          }
        });
      }

      const openHistBtn = overlay.querySelector('#plCloudModalOpenHistBtn');
      if (openHistBtn) {
        openHistBtn.addEventListener('click', (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          closeInAppDocModal();
          if (typeof window.__plOpenScrapingHistoryFromCloud === 'function') {
            window.__plOpenScrapingHistoryFromCloud();
          }
        });
      }

      const signOutBtn = overlay.querySelector('#plCloudModalSignOutBtn');
      if (signOutBtn) {
        signOutBtn.addEventListener('click', async (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          saveCloudUser(null);
          authStep = 'chooser';
          await renderModalContent();
          setModalStatus('Signed out of Google Cloud Backup. You can sign in again anytime.', false, false);
        });
      }
    }

    document.body.appendChild(overlay);
    overlay.addEventListener('click', (ev) => { if (ev.target === overlay) closeInAppDocModal(); });
    void renderModalContent();
  }

  window.openInAppCloudBackupModal = openInAppCloudBackupModal;
  window.__plScheduleAutoCloudBackup = function() {
    const u = getSavedCloudUser();
    if (!u || !u.email) return;
    if (autoCloudBackupTimer) clearTimeout(autoCloudBackupTimer);
    autoCloudBackupTimer = setTimeout(function() {
      autoCloudBackupTimer = null;
      const curU = getSavedCloudUser();
      if (curU && curU.email) {
        void performCloudHistorySync(curU.email, true, null, { passHash: curU.passHash || '' });
      }
    }, 2500);
  };

  async function tryAutomaticCloudHistoryRestoreOnBoot() {
    if (initialCloudRestoreChecked) return;
    const lic = await readLicense().catch(() => null);
    if (!lic || !lic.key || !lic.active) return;
    initialCloudRestoreChecked = true;
    const u = getSavedCloudUser();
    if (u && u.email) {
      await performCloudHistorySync(u.email, true, null, { passHash: u.passHash || '' });
      return;
    }
    // Even on a fresh APK reinstall before the user opens the Sign-In modal, check if their activated Licence Key
    // already has a linked Google Cloud History backup and restore it automatically!
    const acctState = await PocketLeadsAccount.read().catch(() => ({}));
    const linkedEmail = String((acctState && acctState.pocketleadsAccount && acctState.pocketleadsAccount.email) || '').trim().toLowerCase();
    await performCloudHistorySync(linkedEmail, true, null, { allowKeyLookup: true });
  }

  ensureCloudSignInMenuItem();
  setTimeout(ensureCloudSignInMenuItem, 600);
  setTimeout(ensureCloudSignInMenuItem, 2000);
  setInterval(ensureCloudSignInMenuItem, 4000);
  setTimeout(function() {
    ensureCloudSignInMenuItem();
    void tryAutomaticCloudHistoryRestoreOnBoot();
  }, 2800);
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && (changes.license || changes.pocketleadsAccount)) {
        const newLic = changes.license && changes.license.newValue;
        if (newLic && newLic.active) {
          initialCloudRestoreChecked = false;
          setTimeout(() => { void tryAutomaticCloudHistoryRestoreOnBoot(); }, 1200);
        }
      }
    });
  }


function openInAppGuideModal() {
  closeInAppDocModal();
  const guideUrl = String(window.POCKETLEADS_GUIDE_URL || '').trim();
  if (guideUrl && /^https?:\/\//i.test(guideUrl)) {
    window.open(guideUrl, '_blank', 'noopener');
    return;
  }
  const overlay = document.createElement('div');
  overlay.id = 'pl-inapp-doc-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;z-index:2147482850;background:rgba(4,7,15,0.82);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:14px;box-sizing:border-box;font-family:Inter,system-ui,sans-serif;';
  overlay.innerHTML =
    '<div style="width:min(580px,100%);max-height:88vh;background:#0F172A;border:1px solid rgba(255,101,31,0.35);border-radius:18px;box-shadow:0 28px 90px rgba(0,0,0,0.65);display:flex;flex-direction:column;overflow:hidden;color:#F8FAFC;">' +
      '<div style="padding:16px 18px;background:linear-gradient(135deg,rgba(255,101,31,0.16),transparent 65%),#0B1324;border-bottom:1px solid rgba(148,163,184,0.18);display:flex;align-items:center;justify-content:space-between;gap:10px;">' +
        '<div><span style="font-size:10.5px;font-weight:800;letter-spacing:0.08em;color:#FF7A1A;text-transform:uppercase;">QUICK-START WORKFLOW</span><h3 style="margin:3px 0 0;font-size:18px;font-weight:800;color:#FFFFFF;">How to Use PocketLeads PRO</h3></div>' +
        '<button type="button" id="plGuideCloseBtn" style="width:34px;height:34px;border-radius:9px;border:1px solid rgba(255,255,255,0.14);background:#1E293B;color:#CBD5E1;font-size:16px;font-weight:800;cursor:pointer;">✕</button>' +
      '</div>' +
      '<div style="padding:18px;overflow-y:auto;display:flex;flex-direction:column;gap:12px;font-size:13px;line-height:1.55;color:#CBD5E1;">' +
        '<div style="padding:12px 14px;border-radius:12px;background:#131C2E;border:1px solid rgba(148,163,184,0.16);"><strong style="color:#F8FAFC;display:block;margin-bottom:3px;">1. Enter Keywords &amp; Target Locations</strong>Select your target Country, enter one or more business keywords (e.g., <em>Real Estate Agency</em>, <em>Dentist</em>) and target cities/pin codes (one per line).</div>' +
        '<div style="padding:12px 14px;border-radius:12px;background:#131C2E;border:1px solid rgba(148,163,184,0.16);"><strong style="color:#F8FAFC;display:block;margin-bottom:3px;">2. Start Extraction &amp; Track Progress</strong>Click <strong>Start Extraction</strong>. PocketLeads automatically fetches verified business listings, phone numbers, ratings, websites, and Google Maps profiles—and saves every lead automatically.</div>' +
        '<div style="padding:12px 14px;border-radius:12px;background:#131C2E;border:1px solid rgba(148,163,184,0.16);"><strong style="color:#F8FAFC;display:block;margin-bottom:3px;">3. WhatsApp Check &amp; Email / Social Enrichment</strong>Use <strong>Verify WhatsApp</strong> to check which phone numbers are active on WhatsApp, and <strong>Scrape Emails &amp; Socials</strong> to extract business emails plus Facebook, Instagram, LinkedIn, X, and YouTube links.</div>' +
        '<div style="padding:12px 14px;border-radius:12px;background:#131C2E;border:1px solid rgba(148,163,184,0.16);"><strong style="color:#F8FAFC;display:block;margin-bottom:3px;">4. Export to Excel, CSV, or Mobile CRM</strong>Click <strong>Export</strong> to download your leads as a formatted Excel (<code>.xlsx</code>) workbook, CSV file, or interactive <strong>Mobile CRM</strong> app.</div>' +
      '</div>' +
      '<div style="padding:12px 18px;background:#0B1324;border-top:1px solid rgba(148,163,184,0.16);display:flex;align-items:center;justify-content: flex-end;gap:10px;">' +
        '<button type="button" id="plGuideSupportBtn" style="height:36px;padding:0 14px;border-radius:10px;border:1px solid rgba(255,255,255,0.16);background:#1E293B;color:#F8FAFC;font-size:12.5px;font-weight:700;cursor:pointer;">Need Help? Open Support</button>' +
        '<button type="button" id="plGuideDoneBtn" style="height:36px;padding:0 16px;border-radius:10px;border:0;background:linear-gradient(135deg,#FF7A1A,#EA580C);color:#FFFFFF;font-size:12.5px;font-weight:800;cursor:pointer;">Got It</button>' +
      '</div>' +
    '</div>';
  document.body.appendChild(overlay);
  overlay.addEventListener('click', (ev) => { if (ev.target === overlay) closeInAppDocModal(); });
  overlay.querySelector('#plGuideCloseBtn')?.addEventListener('click', closeInAppDocModal);
  overlay.querySelector('#plGuideDoneBtn')?.addEventListener('click', closeInAppDocModal);
  overlay.querySelector('#plGuideSupportBtn')?.addEventListener('click', () => {
    closeInAppDocModal();
    setSupportModal(true);
  });
}

function setNotifPanelOpen(open) {
  const notifPanel = $('plNotificationsPanel');
  const profilePanel = $('plProfilePanel');
  const trigger = $('openNotificationsBtn');
  if (!notifPanel) return;
  notifPanel.style.setProperty('z-index', '2147482600', 'important');
  setElementHiddenState(notifPanel, !open, 'flex');
  notifPanel.classList.toggle('is-open', !!open);
  if (trigger) trigger.setAttribute('aria-expanded', String(!!open));
  if (open) {
    if (profilePanel && !profilePanel.hidden) setPanelOpen(profilePanel, false);
    renderNotificationsList();
    syncAdminNotifications(false);
  }
}

  loadNotifStorage().then(() => {
    updateNotifBadgeUI();
    renderNotificationsList();
    syncAdminNotifications(false);
  });

  // Navbar is rendered asynchronously through Angular ng-include.
  // Use capture-phase delegated handling so the notification & profile triggers
  // always work even when buttons are inserted after initialisation or inside
  // containers that stop event propagation.
  document.addEventListener('click', function(e) {
    const curPanel = $('plProfilePanel') || panel;
    const notifPanel = $('plNotificationsPanel');

    const notifTrigger = closestEl(e.target, '#openNotificationsBtn');
    if (notifTrigger && notifPanel) {
      e.preventDefault();
      e.stopPropagation();
      const shouldOpenNotif = notifPanel.hidden || !notifPanel.classList.contains('is-open');
      setNotifPanelOpen(shouldOpenNotif);
      return;
    }

    const notifTab = closestEl(e.target, '[data-notif-filter]');
    if (notifTab && notifPanel && notifPanel.contains(notifTab)) {
      e.preventDefault();
      e.stopPropagation();
      activeNotifFilter = notifTab.getAttribute('data-notif-filter') || 'all';
      notifPanel.querySelectorAll('.pl-notif-tab').forEach(btn => btn.classList.toggle('is-active', btn === notifTab));
      renderNotificationsList();
      return;
    }

    const profileTrigger = closestEl(e.target, '#openProfilePanel');
    if (profileTrigger && curPanel) {
      e.preventDefault();
      e.stopPropagation();
      if (notifPanel && !notifPanel.hidden) setNotifPanelOpen(false);
      const shouldOpen = curPanel.hidden || !curPanel.classList.contains('is-open');
      setPanelOpen(curPanel, shouldOpen);
      if (shouldOpen) loadAccount(true);
      return;
    }

    const acctStatusBox = closestEl(e.target, '.pl-account-status');
    if (acctStatusBox && curPanel && curPanel.contains(acctStatusBox)) {
      e.preventDefault();
      e.stopPropagation();
      readLicense().then(lic => {
        if (!lic || !lic.active) {
          setPanelOpen(curPanel, false);
          if (typeof window.showLicenseModal === 'function') window.showLicenseModal();
        } else {
          if ($('plAccountStatus')) $('plAccountStatus').textContent = 'Refreshing account…';
          loadAccount(true);
        }
      });
      return;
    }

    const acctSupportLink = closestEl(e.target, '#plAccountSupport');
    if (acctSupportLink && curPanel && curPanel.contains(acctSupportLink)) {
      e.preventDefault();
      e.stopPropagation();
      setSupportModal(true);
      return;
    }

    const item = closestEl(e.target, '[data-profile-action]');
    if (item && curPanel && curPanel.contains(item)) {
      e.preventDefault();
      e.stopPropagation();
      const action = item.getAttribute('data-profile-action');
      if (action === 'close') { setPanelOpen(curPanel, false); return; }
      curPanel.querySelectorAll('.pl-profile-menu-item').forEach(btn => btn.classList.toggle('is-active', action === 'profile' && btn === item));
      if (action === 'profile') {
        try { curPanel.scrollTo({ top: 0, behavior: 'smooth' }); } catch (_) { curPanel.scrollTop = 0; }
        readLicense().then(lic => {
          if (!lic || !lic.active) {
            setPanelOpen(curPanel, false);
            if (typeof window.showLicenseModal === 'function') window.showLicenseModal();
          } else {
            if ($('plAccountStatus')) $('plAccountStatus').textContent = 'Refreshing account…';
            loadAccount(true);
          }
        });
        return;
      }
      if (action === 'support') { setSupportModal(true); return; }
      if (action === 'settings') {
        setPanelOpen(curPanel, false);
        openInAppDocModal('PocketLeads Settings', 'settings-page.html');
        return;
      }
      if (action === 'privacy') {
        setPanelOpen(curPanel, false);
        openInAppDocModal('Privacy & Liability Policy', 'views/privacy.html');
        return;
      }
      if (action === 'terms') {
        setPanelOpen(curPanel, false);
        openInAppDocModal('PocketLeads Terms of Use', 'views/terms.html');
        return;
      }
      if (action === 'guide') {
        setPanelOpen(curPanel, false);
        openInAppGuideModal();
        return;
      }
      if (action === 'cloud_signin') {
        setPanelOpen(curPanel, false);
        openInAppCloudBackupModal();
        return;
      }
      if (action === 'logout') {
        setPanelOpen(curPanel, false);
        const logoutBtn = $('logoutButtonModal');
        if (logoutBtn) logoutBtn.click();
        return;
      }
    }

    const openTrigger = $('openProfilePanel');
    if (curPanel && !curPanel.hidden && !curPanel.contains(e.target) && (!openTrigger || !openTrigger.contains(e.target))) {
      setPanelOpen(curPanel, false);
    }
    const openNotifBtn = $('openNotificationsBtn');
    if (notifPanel && !notifPanel.hidden && !notifPanel.contains(e.target) && (!openNotifBtn || !openNotifBtn.contains(e.target))) {
      setNotifPanelOpen(false);
    }
  }, true);
  $('plNotifCloseBtn')?.addEventListener('click',()=>setNotifPanelOpen(false));
  $('plNotifRefreshBtn')?.addEventListener('click',()=>syncAdminNotifications(true));
  $('plNotifMarkReadBtn')?.addEventListener('click',()=>{
    currentNotifications.forEach(n=>{if(n&&(n.id||n.title))readNotifIds.add(String(n.id||n.title));});
    saveNotifStorage();
    updateNotifBadgeUI();
    renderNotificationsList();
  });
  $('plNotifClearAllBtn')?.addEventListener('click',()=>{
    currentNotifications.forEach(n=>{
      if(n&&(n.id||n.title)){
        const id=String(n.id||n.title);
        dismissedNotifIds.add(id);
        readNotifIds.add(id);
      }
    });
    currentNotifications=[];
    saveNotifStorage();
    updateNotifBadgeUI();
    renderNotificationsList();
    try {
      if (window.AndroidChromeBridge && typeof window.AndroidChromeBridge.cancelAllNotifications === 'function') {
        window.AndroidChromeBridge.cancelAllNotifications();
      }
    } catch (_) {}
  });
  $('plNewTicketBtn')?.addEventListener('click',()=>{setSupportStatus('');setTicketComposer(true);});
  $('plTicketRefreshBtn')?.addEventListener('click',()=>loadTickets(true));
  $('plTicketFormModal')?.addEventListener('submit',submitModalTicket);
  $('plTicketFormModal')?.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();setTicketComposer(false);setSupportStatus('');}});
  $('plTicketCancelModal')?.addEventListener('click',()=>{setTicketComposer(false);setSupportStatus('');});
  $('plTicketFormCloseBtn')?.addEventListener('click',()=>{setTicketComposer(false);setSupportStatus('');});
  const attachmentInput=$('plTicketAttachment'),dropZone=$('plTicketDropZone');
  attachmentInput?.addEventListener('change',()=>selectAttachment(attachmentInput.files&&attachmentInput.files[0]));
  dropZone?.addEventListener('click',event=>{event.preventDefault();attachmentInput?.click();});
  dropZone?.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();attachmentInput?.click();}});
  ['dragenter','dragover'].forEach(type=>dropZone?.addEventListener(type,event=>{event.preventDefault();dropZone.classList.add('is-dragging');}));
  ['dragleave','drop'].forEach(type=>dropZone?.addEventListener(type,event=>{event.preventDefault();dropZone.classList.remove('is-dragging');if(type==='drop')selectAttachment(event.dataTransfer&&event.dataTransfer.files&&event.dataTransfer.files[0]);}));
  $('plTicketAttachmentRemove')?.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();ticketAttachmentFile=null;if(attachmentInput)attachmentInput.value='';updateAttachmentUI(null);});
  $('plSupportCloseBtn')?.addEventListener('click',()=>setSupportModal(false));
  $('plSupportBackdrop')?.addEventListener('click',()=>setSupportModal(false));
  $('plTicketDetailClose')?.addEventListener('click',closeTicketDetail);
  $('plTicketDetailBackdrop')?.addEventListener('click',closeTicketDetail);
  document.addEventListener('keydown',e=>{
    if(e.key!=='Escape')return;
    const curPanel = $('plProfilePanel') || panel;
    const notifPanel = $('plNotificationsPanel');
    if($('pl-inapp-doc-overlay')) closeInAppDocModal();
    else if($('plTicketDetailModal')&&!$('plTicketDetailModal').hidden)closeTicketDetail();
    else if($('plSupportModal')&&!$('plSupportModal').hidden)setSupportModal(false);
    else if(curPanel && !curPanel.hidden)setPanelOpen(curPanel,false);
    else if(notifPanel && !notifPanel.hidden)setNotifPanelOpen(false);
  });
  let lastFocusAccountLoadAt = Date.now();
  function loadAccountOnResumeThrottled() {
    if (Date.now() - lastFocusAccountLoadAt < 45000) return;
    lastFocusAccountLoadAt = Date.now();
    setTimeout(() => loadAccount(false), 600);
  }
  $('plAccountRetry')?.addEventListener('click',()=>{ lastFocusAccountLoadAt = Date.now(); loadAccount(true); });
  window.addEventListener('focus', loadAccountOnResumeThrottled, { passive: true });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) loadAccountOnResumeThrottled(); }, { passive: true });
  loadAccount(true);

  // ============================================================================
  // Server Down / API Maintenance Popup Modal & Auto Sheet Error Reporter
  // ============================================================================
  let lastShownServerDownId = '';
  let currentServerDownAlert = null;
  const reportedErrorSignatures = new Set();

  async function ensureApiErrorLoggedInSheet(alertObj) {
    if (!alertObj || typeof alertObj !== 'object') return;
    const lic = await readLicense();
    const licKey = String((alertObj && alertObj.licenceKey) || (lic && lic.key) || '').trim();
    if (!licKey || licKey === 'Active Licence') return;
    const errMsg = String(alertObj.upstreamError || alertObj.message || 'Extraction error').trim();
    const errCode = String(alertObj.errorCode || 'EXTRACTION_ISSUE').trim().toUpperCase();
    // Deduplicate by (licKey + '|' + errCode) within 5 minutes so the sheet never gets flooded with duplicate rows!
    const dedupSig = licKey.toUpperCase() + '|' + errCode;
    const nowMs = Date.now();
    try {
      const lastSentMap = JSON.parse(localStorage.getItem('pl_errlog_dedup_v2') || '{}');
      if (lastSentMap[dedupSig] && (nowMs - Number(lastSentMap[dedupSig]) < 300000)) return;
      lastSentMap[dedupSig] = nowMs;
      localStorage.setItem('pl_errlog_dedup_v2', JSON.stringify(lastSentMap));
    } catch (_) {
      if (reportedErrorSignatures.has(dedupSig)) return;
      reportedErrorSignatures.add(dedupSig);
    }
    let loggedOk = false;
    try {
      const res = await backend('logapierror', Object.assign({}, alertObj, { licenceKey: licKey, errorCode: errCode, upstreamError: errMsg }));
      if (res && res.status === 'ok' && res.logged) loggedOk = true;
    } catch (_) {}
    if (!loggedOk) {
      try {
        const dedupReqId = 'auto-err-' + licKey + '-' + errCode;
        const subj = `[AUTO ERROR LOG] ${errCode} (${alertObj.apiId || alertObj.provider || 'API'}) - Licence ${licKey}`.slice(0, 118);
        const msg = [
          'AUTOMATIC EXTRACTION / API ERROR REPORT',
          'Licence Key: ' + licKey,
          'User Name: ' + (alertObj.userName || (lic && lic.userName) || 'N/A'),
          'API ID: ' + (alertObj.apiId || 'N/A') + (alertObj.keyRow ? ' (Row ' + alertObj.keyRow + ')' : ''),
          'Provider: ' + (alertObj.provider || 'auto'),
          'HTTP Status: ' + (alertObj.httpStatus || '0'),
          'Error Code: ' + errCode + (alertObj.upstreamCode ? ' (' + alertObj.upstreamCode + ')' : ''),
          'Search Query: ' + (alertObj.query || 'Extraction Task'),
          'Error Detail: ' + errMsg
        ].join('\n').slice(0, 1950);
        await backend('submitticket', {
          subject: subj,
          message: msg,
          user: alertObj.userName || (lic && lic.userName) || licKey,
          requestId: dedupReqId,
          apiId: alertObj.apiId || '',
          keyRow: alertObj.keyRow || 0,
          provider: alertObj.provider || '',
          httpStatus: alertObj.httpStatus || 0,
          errorCode: errCode,
          upstreamError: errMsg,
          query: alertObj.query || ''
        });
      } catch (_2) {}
    }
  }

  async function showServerDownModal(alertObj) {
    const modal = $('plServerDownModal');
    if (!modal || !alertObj) return;
    currentServerDownAlert = alertObj;
    // Do not interrupt user with duplicate Server Down modal; log silently and let dashboard handle network/status alerts cleanly.
    const lic = await readLicense().catch(() => null);
    const licKeySilent = String(alertObj.licenceKey || (lic && lic.key) || '').trim();
    if (licKeySilent) void ensureApiErrorLoggedInSheet(Object.assign({}, alertObj, { licenceKey: licKeySilent }));
  }

  function closeServerDownModal() {
    const modal = $('plServerDownModal');
    if (modal) modal.hidden = true;
    if (!($('plSupportModal') && !$('plSupportModal').hidden)) {
      document.body.classList.remove('pl-modal-open');
    }
    try { chrome.storage.local.remove('plServerDownAlert'); } catch (_) {}
  }

  async function openSupportFromServerDown() {
    const alertObj = currentServerDownAlert || {};
    const lic = await readLicense();
    const licKey = String(alertObj.licenceKey || (lic && lic.key) || '');
    const refId = 'REF-' + String(alertObj.timestamp || Date.now()).slice(-5);
    const queryStr = String(alertObj.query || 'Current extraction task').replace(/~in~/g, ' in ');
    const timeStr = String(alertObj.timeText || formatDate(alertObj.timestamp || Date.now()));

    closeServerDownModal();
    setSupportModal(true);
    setTicketComposer(true);

    const subjInput = $('plTicketSubjectModal');
    const msgInput = $('plTicketMessageModal');
    if (subjInput) {
      subjInput.value = `Support Request [${refId}] - Licence ${licKey}`.slice(0, 118);
    }
    if (msgInput) {
      msgInput.value = [
        'Hello Support Team,',
        '',
        'I am facing a temporary service interruption while extracting leads. Please check and resolve my account:',
        '• Licence Key: ' + (licKey || 'N/A'),
        '• Reference ID: ' + refId,
        '• Search Task: ' + (queryStr || 'N/A'),
        '• Time: ' + timeStr,
        '',
        'Please resolve this issue as soon as possible.'
      ].join('\n');
    }
    setSupportStatus('Details pre-filled! Attach a screenshot (optional) and click Submit Ticket — our team will resolve your issue.', false, true);
  }

  $('plSdCloseBtn')?.addEventListener('click', closeServerDownModal);
  $('plSdTopCloseBtn')?.addEventListener('click', closeServerDownModal);
  $('plServerDownBackdrop')?.addEventListener('click', closeServerDownModal);
  $('plSdRaiseSupportBtn')?.addEventListener('click', openSupportFromServerDown);
  $('plSdOpenSupportCenterBtn')?.addEventListener('click', () => {
    closeServerDownModal();
    setSupportModal(true);
    setTicketComposer(false);
    loadTickets(true);
  });
  $('plSdCopyBtn')?.addEventListener('click', async () => {
    const alertObj = currentServerDownAlert || {};
    const lic = await readLicense();
    const licKey = String(alertObj.licenceKey || (lic && lic.key) || '');
    const refId = 'REF-' + String(alertObj.timestamp || Date.now()).slice(-5);
    const text = [
      'PocketLeads Support Reference',
      'Licence Key: ' + (licKey || 'N/A'),
      'Reference ID: ' + refId,
      'Search Task: ' + (alertObj.query || 'N/A'),
      'Status: Please resolve this extraction issue for my account.',
      'Time: ' + (alertObj.timeText || new Date().toLocaleString())
    ].join('\n');
    try {
      await navigator.clipboard.writeText(text);
      const btn = $('plSdCopyBtn');
      if (btn) {
        const prev = btn.textContent;
        btn.textContent = '✓ Copied!';
        setTimeout(() => { btn.textContent = prev; }, 1800);
      }
    } catch (_) {}
  });

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === 'pl_server_down_alert' && msg.alert) {
        showServerDownModal(msg.alert);
      }
    });
  }

  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes.plServerDownAlert && changes.plServerDownAlert.newValue) {
        const alertVal = changes.plServerDownAlert.newValue;
        if (alertVal && (!alertVal.timestamp || (Date.now() - Number(alertVal.timestamp) < 120000))) {
          showServerDownModal(alertVal);
        }
      }
    });
  }

  window.PocketLeadsShowServerDownPopup = showServerDownModal;
  window.PocketLeadsLogAnyIssueToSheet = ensureApiErrorLoggedInSheet;
  window.PocketLeadsOpenSupportWithIssue = async function(issueObj) {
    const info = issueObj || currentServerDownAlert || {};
    const lic = await readLicense();
    const licKey = String(info.licenceKey || (lic && lic.key) || '');
    const refId = String(info.refId || ('REF-' + String(Date.now()).slice(-5)));
    const queryStr = String(info.query || 'Current extraction task').replace(/~in~/g, ' in ');
    const timeStr = String(info.timeText || formatDate(Date.now()));
    closeServerDownModal();
    setSupportModal(true);
    setTicketComposer(true);
    const subjInput = $('plTicketSubjectModal');
    const msgInput = $('plTicketMessageModal');
    if (subjInput) {
      subjInput.value = `Support Request [${refId}] - Licence ${licKey}`.slice(0, 118);
    }
    if (msgInput) {
      msgInput.value = [
        'Hello Support Team,',
        '',
        'I am facing an issue while extracting leads. Please check and resolve my account:',
        '• Licence Key: ' + (licKey || 'N/A'),
        '• Reference ID: ' + refId,
        '• Search Task: ' + (queryStr || 'N/A'),
        '• Time: ' + timeStr,
        '',
        'Please resolve this issue as soon as possible.'
      ].join('\n');
    }
    setSupportStatus('Details pre-filled! Attach a screenshot (optional) and click Submit Ticket — our team will resolve your issue.', false, true);
  };
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
